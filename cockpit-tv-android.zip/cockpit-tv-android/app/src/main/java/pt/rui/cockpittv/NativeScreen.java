package pt.rui.cockpittv;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Ecrã de canais 100% nativo (Fase 1, opcional): lista à esquerda, vídeo ao centro e botões por baixo.
 * Só usa o leitor nativo (NativePlayer). A página (WebView) fica por baixo, parada, até saíres.
 */
final class NativeScreen {
    interface Host { void js(String kind, String msg); }

    private static final class Item { String name = "", logo = "", group = "", url = "", ref = "", epg = "", kind = "live"; long start = 0; }

    /** Caixa do vídeo: mantém 16:9 e nunca ocupa mais do que a altura disponível menos a reserva (botões + guia). */
    private static final class VideoHolder extends FrameLayout {
        int reserve = 0;
        VideoHolder(Activity a) { super(a); }
        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            int w = MeasureSpec.getSize(wSpec);
            int availH = MeasureSpec.getSize(hSpec);
            int h = w * 9 / 16;
            if (availH > 0 && h > availH - reserve) {
                h = Math.max(availH - reserve, 120);
                w = h * 16 / 9;
            }
            setMeasuredDimension(w, h);
            int cw = MeasureSpec.makeMeasureSpec(w, MeasureSpec.EXACTLY), ch = MeasureSpec.makeMeasureSpec(h, MeasureSpec.EXACTLY);
            for (int i = 0; i < getChildCount(); i++) getChildAt(i).measure(cw, ch);
        }
    }

    private final Activity act;
    private final FrameLayout root;
    private final NativePlayer np;
    private final Host host;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newFixedThreadPool(3);
    private final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(80);

    private final ArrayList<Item> items = new ArrayList<Item>();
    private int index = -1, retries = 0;
    private boolean triedTs = false, full = false, closed = false, firstStart = true;

    private FrameLayout screen;
    private LinearLayout main, right, row1, row2, row3;
    private ListView list;
    private LinearLayout listBox, videoRow;
    private VideoHolder holder, holder2;
    private TextView title, epg, loading, loading2, btnAspect, btnFull, btnGroup, btnDual;
    private EditText search;
    private final ArrayList<Integer> vis = new ArrayList<Integer>();
    private String query = "", groupFilter = "";
    private NativePlayer np2;
    private boolean dual = false;
    private int active = 0, index2 = -1, retries2 = 0;
    private BaseAdapter adapter;

    private static final String[] ASP = {"fit", "zoom", "stretch", "16:9", "4:3", "21:9"};
    private static final String[] ASP_L = {"Ajustar", "Zoom", "Esticar", "16:9", "4:3", "21:9"};
    private int aspIdx = 0;

    NativeScreen(Activity act, FrameLayout root, NativePlayer np, Host host) {
        this.act = act;
        this.root = root;
        this.np = np;
        this.host = host;
    }

    private int dp(int v) { return (int) (v * act.getResources().getDisplayMetrics().density + 0.5f); }

    /* ------------------------------------------------------------ abrir / fechar */
    void open(String json, int start) {
        try {
            JSONArray a = new JSONArray(json);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item();
                it.name = o.optString("name");
                it.logo = o.optString("logo");
                it.group = o.optString("group");
                it.url = o.optString("url");
                it.ref = o.optString("ref");
                it.epg = o.optString("epg");
                it.kind = o.optString("kind", "live");
                it.start = o.optLong("start", 0);
                if (it.url.length() > 0) items.add(it);
            }
        } catch (Throwable e) {
            Toast.makeText(act, "Lista inválida: " + e, Toast.LENGTH_LONG).show();
            return;
        }
        if (items.isEmpty()) return;
        buildVis();
        build();
        np.prepareViews();
        root.addView(screen, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        np.bringBoxToFront();
        applyOrientation();
        np.setAspect(ASP[aspIdx], ASP_L[aspIdx]);
        play(Math.max(0, Math.min(start, items.size() - 1)));
        ui.postDelayed(posRun, 5000);
        selectInList(index);
    }

    boolean isOpen() { return !closed && screen != null; }

    void close() {
        if (closed) return;
        reportPos();
        closed = true;
        ui.removeCallbacksAndMessages(null);
        try { np.setFull(false); } catch (Throwable ignored) { }
        try { np.stop(); } catch (Throwable ignored) { }
        try { if (np2 != null) { np2.stop(); np2.rect(0, 0, 1, 1, false); } } catch (Throwable ignored) { }
        try { root.removeView(screen); } catch (Throwable ignored) { }
        pool.shutdownNow();
        host.js("nscreen:closed", index >= 0 && index < items.size() ? items.get(index).url : "");
    }

    /** Botão Voltar: primeiro sai do ecrã total, depois fecha. */
    boolean onBack() {
        if (full) { setFull(false); return true; }
        close();
        return true;
    }

    /** Teclas do comando (TV): cima/baixo muda de canal fora do ecrã total. */
    boolean onKey(KeyEvent ev) {
        if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
        int k = ev.getKeyCode();
        if (full) {
            if (k == KeyEvent.KEYCODE_CHANNEL_UP || k == KeyEvent.KEYCODE_DPAD_UP) { step(-1); return true; }
            if (k == KeyEvent.KEYCODE_CHANNEL_DOWN || k == KeyEvent.KEYCODE_DPAD_DOWN) { step(1); return true; }
            if (k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER) { setFull(false); return true; }
        }
        if (k == KeyEvent.KEYCODE_CHANNEL_UP) { step(-1); return true; }
        if (k == KeyEvent.KEYCODE_CHANNEL_DOWN) { step(1); return true; }
        return false;
    }

    /* ------------------------------------------------------------ interface */
    private GradientDrawable round(int color, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    private TextView button(String text, View.OnClickListener l) {
        TextView b = new TextView(act);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15f);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setMaxLines(1);
        b.setPadding(dp(4), dp(10), dp(4), dp(10));
        /* o texto encolhe para caber no botão (telemóvel na vertical tem 5 botões por linha) */
        if (android.os.Build.VERSION.SDK_INT >= 26) b.setAutoSizeTextTypeUniformWithConfiguration(9, 15, 1, android.util.TypedValue.COMPLEX_UNIT_SP);
        else b.setTextSize(12f);
        b.setFocusable(true);
        b.setClickable(true);
        StateListDrawable sl = new StateListDrawable();
        GradientDrawable focus = round(0xFF2F7DD1, 12);
        focus.setStroke(dp(2), Color.WHITE);
        sl.addState(new int[]{android.R.attr.state_focused}, focus);
        sl.addState(new int[]{android.R.attr.state_pressed}, round(0xFF2F7DD1, 12));
        sl.addState(new int[]{}, round(0xFF1B2B47, 12));
        b.setBackground(sl);
        b.setOnClickListener(l);
        return b;
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(act);
        r.setOrientation(LinearLayout.HORIZONTAL);
        return r;
    }

    private void addBtn(LinearLayout r, TextView b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        r.addView(b, lp);
    }

    private void build() {
        screen = new FrameLayout(act);
        screen.setBackgroundColor(0xFF0B1220);
        screen.setKeepScreenOn(true);
        screen.setClickable(true);   /* não deixa toques passarem para a página */

        main = new LinearLayout(act);

        list = new ListView(act);
        list.setDivider(null);
        list.setBackgroundColor(0xFF111B2E);
        list.setSelector(new android.graphics.drawable.ColorDrawable(0x332F7DD1));
        adapter = new BaseAdapter() {
            @Override public int getCount() { return vis.size(); }
            @Override public Object getItem(int i) { return items.get(vis.get(i)); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View v, ViewGroup parent) {
                Row r;
                if (v == null) { r = new Row(act); v = r; } else r = (Row) v;
                int ix = vis.get(i);
                r.bind(items.get(ix), ix == index || (dual && ix == index2));
                return v;
            }
        };
        list.setAdapter(adapter);
        listBox = new LinearLayout(act);
        listBox.setOrientation(LinearLayout.VERTICAL);
        listBox.setBackgroundColor(0xFF111B2E);
        LinearLayout sr = row();
        search = new EditText(act);
        search.setHint("🔍 Pesquisar");
        search.setHintTextColor(0xFF8DA2BD);
        search.setTextColor(Color.WHITE);
        search.setTextSize(14f);
        search.setSingleLine(true);
        search.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void onTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void afterTextChanged(Editable e) { query = e.toString().trim().toLowerCase(); buildVis(); adapter.notifyDataSetChanged(); }
        });
        btnGroup = button("☰ Todos", v -> pickGroup());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        sr.addView(search, sp);
        sr.addView(btnGroup, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        sr.setPadding(dp(4), dp(4), dp(4), dp(4));
        listBox.addView(sr, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        listBox.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        if (items.size() < 2) sr.setVisibility(View.GONE);
        buildVis();
        list.setOnItemClickListener((p, v, i, id) -> { if (i >= 0 && i < vis.size()) playOnActive(vis.get(i)); });

        right = new LinearLayout(act);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setPadding(dp(8), dp(6), dp(8), dp(6));

        holder = new VideoHolder(act);
        holder.setBackgroundColor(Color.BLACK);
        loading = new TextView(act);
        loading.setTextColor(0xFFCBD5E1);
        loading.setTextSize(15f);
        loading.setGravity(Gravity.CENTER);
        holder.addView(loading, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        holder.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            if (r - l != or - ol || b - t != ob - ot || t != ot || l != ol) scheduleRect();
        });
        holder.setOnClickListener(v -> { if (dual) setActive(0); else setFull(true); });

        holder2 = new VideoHolder(act);
        holder2.setBackgroundColor(Color.BLACK);
        holder2.setVisibility(View.GONE);
        loading2 = new TextView(act);
        loading2.setTextColor(0xFFCBD5E1);
        loading2.setTextSize(13f);
        loading2.setGravity(Gravity.CENTER);
        holder2.addView(loading2, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        holder2.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> {
            if (r - l != or - ol || b - t != ob - ot || t != ot || l != ol) scheduleRect();
        });
        holder2.setOnClickListener(v -> setActive(1));
        videoRow = new LinearLayout(act);
        videoRow.setOrientation(LinearLayout.HORIZONTAL);
        videoRow.setGravity(Gravity.CENTER_HORIZONTAL);
        videoRow.addView(holder, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        videoRow.addView(holder2, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        title = new TextView(act);
        title.setTextColor(Color.WHITE);
        title.setTextSize(18f);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        title.setPadding(dp(4), dp(6), dp(4), 0);

        epg = new TextView(act);
        epg.setTextColor(0xFF9FB3CC);
        epg.setTextSize(14f);
        epg.setMaxLines(2);
        epg.setEllipsize(android.text.TextUtils.TruncateAt.END);
        epg.setPadding(dp(4), 0, dp(4), dp(4));

        row1 = row();
        row2 = row();
        row3 = row();
        btnAspect = button("▭ Ajustar", v -> cycleAspect());
        btnFull = button("⛶ Ecrã total", v -> setFull(!full));
        addBtn(row1, btnAspect);
        addBtn(row1, btnFull);
        btnDual = button("⧉ Dupla", v -> toggleDual());
        addBtn(row1, btnDual);
        addBtn(row1, button("📅 Guia", v -> { close(); host.js("nscreen:guide", ""); }));
        addBtn(row1, button("✕ Sair", v -> close()));
        addBtn(row2, button("◀ Anterior", v -> step(-1)));
        addBtn(row2, button("🔊 Áudio", v -> tracks("audio", "Áudio")));
        addBtn(row2, button("💬 Legendas", v -> tracks("text", "Legendas")));
        addBtn(row2, button("Seguinte ▶", v -> step(1)));

        right.addView(videoRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        right.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        right.addView(epg, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        right.addView(row1, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        addBtn(row3, button("⏪ 10 s", v -> cp().seek(-10000)));
        addBtn(row3, button("⏯ Pausa", v -> cp().toggle()));
        addBtn(row3, button("30 s ⏩", v -> cp().seek(30000)));
        addBtn(row3, button("🌐 Legendas", v -> onlineSubs()));
        right.addView(row2, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        right.addView(row3, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        screen.addView(main, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /** (Re)organiza conforme a orientação: horizontal = lista | vídeo+botões; vertical = vídeo+botões por cima da lista. */
    private void applyOrientation() {
        boolean land = act.getResources().getDisplayMetrics().widthPixels > act.getResources().getDisplayMetrics().heightPixels;
        main.removeAllViews();
        ((ViewGroup) screen).setPadding(0, 0, 0, 0);
        if (land) {
            main.setOrientation(LinearLayout.HORIZONTAL);
            setReserve();
            main.addView(listBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.32f));
            main.addView(right, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.68f));
        } else {
            main.setOrientation(LinearLayout.VERTICAL);
            setReserve();
            main.addView(right, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            main.addView(listBox, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
            ((ViewGroup) screen).setPadding(0, dp(24), 0, 0);   /* margem da barra de estado */
        }
    }

    /** Chamado quando o ecrã roda: reorganiza e reposiciona o vídeo quando a vista assenta (sem o esconder). */
    void onConfigChanged() {
        if (closed || screen == null) return;
        lastKey = "";
        ui.removeCallbacks(rectRun);
        applyOrientation();
        ui.postDelayed(rectRun, 350);
    }

    /* ------------------------------------------------------------ posição do vídeo */
    private String lastKey = "";
    private final Runnable rectRun = new Runnable() {
        @Override public void run() {
            if (closed || holder == null || full) return;
            int[] a = new int[2], b = new int[2];
            holder.getLocationInWindow(a);
            root.getLocationInWindow(b);
            int w = holder.getWidth(), h = holder.getHeight();
            if (w < 20 || h < 20) { ui.postDelayed(this, 150); return; }
            int x = a[0] - b[0], y = a[1] - b[1];
            String k = x + "," + y + "," + w + "," + h;
            int x2 = 0, y2 = 0, w2 = 0, h2 = 0;
            if (dual && np2 != null && holder2.getWidth() > 20) {
                int[] c = new int[2];
                holder2.getLocationInWindow(c);
                x2 = c[0] - b[0]; y2 = c[1] - b[1]; w2 = holder2.getWidth(); h2 = holder2.getHeight();
                k += "|" + x2 + "," + y2 + "," + w2 + "," + h2;
            }
            if (k.equals(lastKey)) return;
            lastKey = k;
            np.rect(x, y, w, h, true);
            if (dual && np2 != null && w2 > 20) np2.rect(x2, y2, w2, h2, true);
        }
    };

    private void scheduleRect() {
        ui.removeCallbacks(rectRun);
        ui.postDelayed(rectRun, 250);   /* só depois de a vista parar de mudar */
    }

    /* ------------------------------------------------------------ reprodução */
    private static String hintFor(String u, boolean live) {
        String l = u.toLowerCase();
        if (l.matches(".*\\.m3u8(\\?.*)?$")) return "hls";
        if (l.matches(".*\\.mpd(\\?.*)?$")) return "dash";
        if (!live) return "";
        if (l.matches(".*\\.ts(\\?.*)?$")) return "";
        return "hls";
    }

    private boolean isVod() { return index >= 0 && index < items.size() ? !"live".equals(items.get(index).kind) : (!items.isEmpty() && !"live".equals(items.get(0).kind)); }

    /** Envia à página a posição atual (filmes/episódios) para guardar a retoma. */
    private void reportPos() {
        if (closed || index < 0 || index >= items.size() || !isVod()) return;
        try {
            String[] a = np.pos().split("\\|");
            long p = Long.parseLong(a[0]), d = Long.parseLong(a[1]);
            if (d > 0 && "0".equals(a[2])) host.js("nscreen:pos", items.get(index).url + "|" + p + "|" + d);
        } catch (Throwable ignored) { }
    }

    private final Runnable posRun = new Runnable() {
        @Override public void run() {
            if (closed) return;
            reportPos();
            ui.postDelayed(this, 5000);
        }
    };

    private void applyMode() {
        boolean vod = isVod();
        row3.setVisibility(vod ? View.VISIBLE : View.GONE);
        applyOrientationKeep();
    }

    private void applyOrientationKeep() { /* a reserva do vídeo depende de haver a linha extra */
        boolean land = act.getResources().getDisplayMetrics().widthPixels > act.getResources().getDisplayMetrics().heightPixels;
        setReserve();
    }

    private void play(int i) {
        if (i < 0 || i >= items.size()) return;
        reportPos();
        index = i;
        retries = 0;
        triedTs = false;
        firstStart = true;
        Item it = items.get(i);
        title.setText(it.name);
        epg.setText(it.epg.length() > 0 ? it.epg : it.group);
        loading.setText("A carregar…");
        loading.setVisibility(View.VISIBLE);
        adapter.notifyDataSetChanged();
        applyMode();
        startUrl(it.url, it);
        host.js("nscreen:play", it.url);
        scheduleRect();
    }

    private void startUrl(String url, Item it) {
        try {
            np.play(url, it.ref, hintFor(url, "live".equals(it.kind)), "", firstStart ? it.start : 0);
            firstStart = false;
            applyVolumes();
            ui.postDelayed(() -> applyVolumes(), 1500);
            ui.postDelayed(() -> applyVolumes(), 4000);
        } catch (Throwable e) {
            loading.setText("Erro: " + e);
        }
    }

    private void step(int d) {
        if (items.isEmpty()) return;
        int cur = (dual && active == 1) ? index2 : index;
        int n = (cur + d + items.size()) % items.size();
        playOnActive(n);
        selectInList(n);
    }

    /** Eventos do leitor. Devolve true se tratou o evento. */
    boolean onPlayerEvent(String k, String m) {
        if (closed) return false;
        if ("ready".equals(k)) { retries = 0; loading.setVisibility(View.GONE); applyVolumes(); return true; }
        if ("buffering".equals(k)) return true;
        if ("ended".equals(k)) { if (isVod() && index + 1 < items.size()) step(1); return true; }
        if ("ui".equals(k)) {
            if ("aspect".equals(m)) cycleAspect();
            else if ("full".equals(m)) setFull(!full);
            return true;
        }
        if ("error".equals(k)) {
            if (index < 0 || index >= items.size()) return true;
            final Item it = items.get(index);
            String u = it.url;
            if ("live".equals(it.kind) && !triedTs && u.matches("(?i).*\\.m3u8(\\?.*)?$") && u.contains("/live/")) {
                triedTs = true;   /* mesmo canal em .ts, como na página */
                startUrl(u.replaceFirst("(?i)\\.m3u8", ".ts"), it);
                return true;
            }
            if (retries < 3) {
                retries++;
                loading.setText("Sem sinal. A tentar de novo (" + retries + "/3)…");
                loading.setVisibility(View.VISIBLE);
                final int mine = index;
                ui.postDelayed(() -> { if (!closed && index == mine) { triedTs = false; firstStart = true; startUrl(it.url, it); } }, 1500L * retries);
            } else {
                loading.setText("Sem sinal neste canal.");
                loading.setVisibility(View.VISIBLE);
            }
            return true;
        }
        if ("noaudio".equals(k)) { Toast.makeText(act, "Este canal tem áudio que o aparelho não descodifica. Tenta outra faixa em Áudio.", Toast.LENGTH_LONG).show(); return true; }
        return true;   /* o resto (aspect:info, hdr…) não interessa à página nesta altura */
    }

    /* ------------------------------------------------------------ pesquisa, categorias, vista dupla, legendas online */
    private NativePlayer cp() { return (dual && active == 1 && np2 != null) ? np2 : np; }

    private void setReserve() {
        boolean land = act.getResources().getDisplayMetrics().widthPixels > act.getResources().getDisplayMetrics().heightPixels;
        int r = land ? dp(isVod() ? 200 : 150) : 0;
        holder.reserve = r;
        holder2.reserve = r;
        videoRow.requestLayout();
    }

    private void buildVis() {
        vis.clear();
        for (int i = 0; i < items.size(); i++) {
            Item it = items.get(i);
            if (groupFilter.length() > 0 && !groupFilter.equals(it.group)) continue;
            if (query.length() > 0 && !(it.name.toLowerCase().contains(query) || it.group.toLowerCase().contains(query))) continue;
            vis.add(i);
        }
        if (btnGroup != null) btnGroup.setText("☰ " + (groupFilter.length() > 0 ? groupFilter : "Todos") + " · " + vis.size());
    }

    private void selectInList(int itemIdx) {
        int p = vis.indexOf(itemIdx);
        if (p >= 0 && list != null) list.setSelection(Math.max(0, p - 2));
    }

    private void pickGroup() {
        final ArrayList<String> gs = new ArrayList<String>();
        final ArrayList<String> labels = new ArrayList<String>();
        gs.add("");
        labels.add("Todos (" + items.size() + ")");
        for (Item it : items) {
            if (it.group.length() == 0 || gs.contains(it.group)) continue;
            int n = 0;
            for (Item x : items) if (x.group.equals(it.group)) n++;
            gs.add(it.group);
            labels.add(it.group + " (" + n + ")");
        }
        new AlertDialog.Builder(act).setTitle("Categoria")
                .setItems(labels.toArray(new String[0]), (d, which) -> { groupFilter = gs.get(which); buildVis(); adapter.notifyDataSetChanged(); })
                .show();
    }

    private void applyVolumes() {
        try { np.volume(!dual || active == 0 ? 1f : 0f); } catch (Throwable ignored) { }
        try { if (np2 != null) np2.volume(dual && active == 1 ? 1f : 0f); } catch (Throwable ignored) { }
    }

    private void setActive(int a) {
        if (!dual) return;
        active = a;
        applyVolumes();
        holder.setBackgroundColor(a == 0 ? 0xFF2F7DD1 : Color.BLACK);
        holder2.setBackgroundColor(a == 1 ? 0xFF2F7DD1 : Color.BLACK);
        int ix = a == 0 ? index : index2;
        if (ix >= 0 && ix < items.size()) { title.setText(items.get(ix).name); epg.setText("Vista dupla · toca num canal da lista para o pôr no vídeo " + (a == 0 ? "da esquerda" : "da direita")); }
    }

    private void toggleDual() {
        if (full) return;
        if (!dual) {
            if (items.size() < 2 || isVod()) { Toast.makeText(act, "A vista dupla é para canais em direto.", Toast.LENGTH_SHORT).show(); return; }
            try {
                if (np2 == null) {
                    np2 = new NativePlayer(act, root, (k, m) -> onEvent2(k, m));
                    np2.prepareViews();
                }
                np2.bringBoxToFront();
                np2.setAspect("fit", "Ajustar");
            } catch (Throwable e) { Toast.makeText(act, "Vista dupla indisponível: " + e, Toast.LENGTH_LONG).show(); np2 = null; return; }
            dual = true;
            holder2.setVisibility(View.VISIBLE);
            btnDual.setText("⧉ Só um");
            lastKey = "";
            setActive(1);
            play2((index + 1) % items.size());
            scheduleRect();
        } else {
            dual = false;
            active = 0;
            holder.setBackgroundColor(Color.BLACK);
            holder2.setVisibility(View.GONE);
            btnDual.setText("⧉ Dupla");
            try { if (np2 != null) { np2.stop(); np2.rect(0, 0, 1, 1, false); } } catch (Throwable ignored) { }
            index2 = -1;
            applyVolumes();
            lastKey = "";
            adapter.notifyDataSetChanged();
            if (index >= 0 && index < items.size()) { title.setText(items.get(index).name); epg.setText(items.get(index).epg.length() > 0 ? items.get(index).epg : items.get(index).group); }
            scheduleRect();
        }
    }

    private void playOnActive(int i) {
        if (dual && active == 1) play2(i); else play(i);
    }

    private void play2(int i) {
        if (np2 == null || i < 0 || i >= items.size()) return;
        index2 = i;
        retries2 = 0;
        Item it = items.get(i);
        title.setText(it.name);
        loading2.setText("A carregar…");
        loading2.setVisibility(View.VISIBLE);
        adapter.notifyDataSetChanged();
        try {
            np2.play(it.url, it.ref, hintFor(it.url, true), "", 0);
            applyVolumes();
        } catch (Throwable e) { loading2.setText("Erro: " + e); }
        scheduleRect();
    }

    private void onEvent2(String k, String m) {
        if (closed || !dual) return;
        if ("ready".equals(k)) { retries2 = 0; loading2.setVisibility(View.GONE); return; }
        if ("error".equals(k) && index2 >= 0 && index2 < items.size()) {
            if (retries2 < 3) {
                retries2++;
                loading2.setText("Sem sinal (" + retries2 + "/3)…");
                loading2.setVisibility(View.VISIBLE);
                final int mine = index2;
                ui.postDelayed(() -> { if (!closed && dual && index2 == mine) play2(mine); }, 1500L * retries2);
            } else loading2.setText("Sem sinal neste canal.");
        }
    }

    private void onlineSubs() {
        if (index < 0 || index >= items.size()) return;
        Toast.makeText(act, "A procurar legendas…", Toast.LENGTH_SHORT).show();
        host.js("nscreen:subsearch", items.get(index).name);
    }

    /** Comandos vindos da página (resultados de legendas, avisos). */
    void command(String cmd, String payload) {
        if (closed) return;
        try {
            if ("msg".equals(cmd)) { Toast.makeText(act, payload, Toast.LENGTH_LONG).show(); return; }
            if ("subres".equals(cmd)) {
                JSONArray a = new JSONArray(payload);
                if (a.length() == 0) { Toast.makeText(act, "Não encontrei legendas em português.", Toast.LENGTH_LONG).show(); return; }
                final String[] labels = new String[a.length()];
                for (int i = 0; i < labels.length; i++) labels[i] = a.getString(i);
                new AlertDialog.Builder(act).setTitle("Legendas online")
                        .setItems(labels, (d, which) -> { Toast.makeText(act, "A descarregar legenda…", Toast.LENGTH_SHORT).show(); host.js("nscreen:subpick", String.valueOf(which)); })
                        .show();
            }
        } catch (Throwable e) { Toast.makeText(act, "Legendas: " + e, Toast.LENGTH_LONG).show(); }
    }

    /* ------------------------------------------------------------ botões */
    private void cycleAspect() {
        aspIdx = (aspIdx + 1) % ASP.length;
        cp().setAspect(ASP[aspIdx], ASP_L[aspIdx]);
        btnAspect.setText("▭ " + ASP_L[aspIdx]);
    }

    private void setFull(boolean on) {
        if (on && dual) { Toast.makeText(act, "Sai da vista dupla para ver em ecrã total.", Toast.LENGTH_SHORT).show(); return; }
        full = on;
        main.setVisibility(on ? View.INVISIBLE : View.VISIBLE);
        np.setFull(on);
        btnFull.setText(on ? "✕ Sair do ecrã total" : "⛶ Ecrã total");
        if (!on) { lastKey = ""; ui.removeCallbacks(rectRun); ui.postDelayed(rectRun, 200); }
    }

    private void tracks(final String type, String label) {
        try {
            JSONObject j = new JSONObject(cp().tracks());
            JSONArray a = j.optJSONArray(type);
            final boolean text = "text".equals(type);
            int n = a == null ? 0 : a.length();
            final ArrayList<String> names = new ArrayList<String>();
            final ArrayList<Integer> ids = new ArrayList<Integer>();
            if (text) { names.add("Sem legendas"); ids.add(-1); }
            for (int i = 0; i < n; i++) {
                JSONObject o = a.getJSONObject(i);
                names.add((o.optBoolean("on") ? "● " : "○ ") + o.optString("name"));
                ids.add(o.optInt("i"));
            }
            if (names.isEmpty()) { Toast.makeText(act, "Este canal só tem a faixa de áudio por defeito.", Toast.LENGTH_SHORT).show(); return; }
            new AlertDialog.Builder(act).setTitle(label)
                    .setItems(names.toArray(new String[0]), (d, which) -> cp().pick(type, ids.get(which)))
                    .show();
        } catch (Throwable e) {
            Toast.makeText(act, "Sem faixas: " + e, Toast.LENGTH_SHORT).show();
        }
    }

    /* ------------------------------------------------------------ linha da lista */
    private final class Row extends LinearLayout {
        final ImageView img;
        final TextView name, sub;
        String shown = "";

        Row(Activity a) {
            super(a);
            setOrientation(HORIZONTAL);
            setGravity(Gravity.CENTER_VERTICAL);
            setPadding(dp(8), dp(6), dp(8), dp(6));
            img = new ImageView(a);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            img.setBackground(round(0xFF1B2B47, 8));
            addView(img, new LayoutParams(dp(54), dp(40)));
            LinearLayout col = new LinearLayout(a);
            col.setOrientation(VERTICAL);
            col.setPadding(dp(10), 0, 0, 0);
            name = new TextView(a);
            name.setTextColor(Color.WHITE);
            name.setTextSize(15f);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            sub = new TextView(a);
            sub.setTextColor(0xFF8DA2BD);
            sub.setTextSize(12f);
            sub.setSingleLine(true);
            sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
            col.addView(name);
            col.addView(sub);
            addView(col, new LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }

        void bind(Item it, boolean current) {
            name.setText(it.name);
            sub.setText(it.epg.length() > 0 ? it.epg : it.group);
            setBackgroundColor(current ? 0x552F7DD1 : Color.TRANSPARENT);
            shown = it.logo;
            img.setImageBitmap(null);
            if (it.logo.length() == 0) return;
            Bitmap b = cache.get(it.logo);
            if (b != null) { img.setImageBitmap(b); return; }
            final String u = it.logo;
            pool.execute(() -> {
                Bitmap bm = download(u);
                if (bm == null) return;
                cache.put(u, bm);
                ui.post(() -> { if (u.equals(shown)) img.setImageBitmap(bm); });
            });
        }
    }

    private Bitmap download(String u) {
        HttpURLConnection c = null;
        InputStream in = null;
        try {
            c = (HttpURLConnection) new URL(u).openConnection();
            c.setConnectTimeout(6000);
            c.setReadTimeout(6000);
            c.setInstanceFollowRedirects(true);
            in = c.getInputStream();
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = 2;
            return BitmapFactory.decodeStream(in, null, o);
        } catch (Throwable e) {
            return null;
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) { }
            try { if (c != null) c.disconnect(); } catch (Throwable ignored) { }
        }
    }
}
