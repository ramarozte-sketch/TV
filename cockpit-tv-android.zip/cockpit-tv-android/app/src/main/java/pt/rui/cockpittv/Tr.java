package pt.rui.cockpittv;

import android.content.Context;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;

/**
 * Traduções da interface. A chave é o texto português original; as traduções
 * estão em assets/i18n/<língua>.json. A língua escolhida fica em
 * SharedPreferences "nativeapp" / "ui_lang". Sem tradução, fica o português.
 */
final class Tr {
    static final String[] LANGS = {"pt", "en", "fr", "es", "de"};
    static final String[] LANG_NAMES = {"Português", "English", "Français", "Español", "Deutsch"};
    static volatile String lang = "pt";
    private static volatile Map<String, String> T = new HashMap<>();

    private Tr() { }

    /** Lê a língua guardada e o dicionário. Chamar no arranque da app. */
    static synchronized void load(Context c) {
        String l = "pt";
        try { l = c.getSharedPreferences("nativeapp", 0).getString("ui_lang", "pt"); } catch (Throwable ignored) { }
        if (!Arrays.asList(LANGS).contains(l)) l = "pt";
        Map<String, String> m = new HashMap<>();
        if (!"pt".equals(l)) {
            try (InputStream in = c.getAssets().open("i18n/" + l + ".json")) {
                ByteArrayOutputStream bo = new ByteArrayOutputStream(); byte[] b = new byte[16384]; int n;
                while ((n = in.read(b)) > 0) bo.write(b, 0, n);
                JSONObject j = new JSONObject(bo.toString("UTF-8"));
                for (Iterator<String> it = j.keys(); it.hasNext(); ) { String k = it.next(); String v = j.optString(k, ""); if (!v.isEmpty()) m.put(k, v); }
            } catch (Throwable ignored) { }
        }
        T = m; lang = l;
    }

    static int index() { return Math.max(0, Arrays.asList(LANGS).indexOf(lang)); }

    /** Texto na língua escolhida; sem tradução, o próprio texto. */
    static String t(String pt) {
        if (pt == null || T.isEmpty()) return pt;
        String v = T.get(pt);
        if (v != null) return v;
        /* espaços à volta (ex.: " min antes") */
        String tr = pt.trim();
        if (tr.length() != pt.length() && !tr.isEmpty()) {
            v = T.get(tr);
            if (v != null) { int a = pt.indexOf(tr); return pt.substring(0, a) + v + pt.substring(a + tr.length()); }
        }
        return pt;
    }

    /** Para setText/setTitle: só traduz texto simples (não mexe em texto formatado). */
    static CharSequence tc(CharSequence s) {
        if (s instanceof String) return t((String) s);
        return s;
    }

    static CharSequence[] arr(CharSequence[] a) {
        if (a == null || T.isEmpty()) return a;
        CharSequence[] o = new CharSequence[a.length];
        for (int i = 0; i < a.length; i++) o[i] = tc(a[i]);
        return o;
    }
}
