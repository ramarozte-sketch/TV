package pt.rui.cockpittv;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/**
 * Cache em disco dos logótipos (picons) e posters: descarrega uma vez, reduz para um tamanho pequeno
 * e serve daí nas aberturas seguintes (instantâneo, mesmo sem rede). Limita os pedidos simultâneos
 * e lembra durante 10 minutos os endereços que falharam, para não atrasar o arranque.
 */
final class PiconCache {
    private static final int MAX_DIM = 400;
    private static final long MAX_BYTES = 120L * 1024 * 1024;
    private static final long MAX_AGE_MS = 30L * 24 * 3600 * 1000;
    private static final Semaphore SEM = new Semaphore(8);
    private static final ConcurrentHashMap<String, Long> BAD = new ConcurrentHashMap<String, Long>();
    private static File dir;

    private PiconCache() { }

    static void init(Context c) {
        try {
            dir = new File(c.getCacheDir(), "picons");
            dir.mkdirs();
            new Thread(PiconCache::trim).start();
        } catch (Throwable ignored) { }
    }

    private static void trim() {
        try {
            File[] fs = dir.listFiles();
            if (fs == null) return;
            long now = System.currentTimeMillis(), total = 0;
            for (File f : fs) {
                if (now - f.lastModified() > MAX_AGE_MS) { f.delete(); continue; }
                total += f.length();
            }
            if (total > MAX_BYTES) {
                java.util.Arrays.sort(fs, (a, b) -> Long.compare(a.lastModified(), b.lastModified()));
                for (File f : fs) { if (total <= MAX_BYTES * 3 / 4) break; if (f.exists()) { total -= f.length(); f.delete(); } }
            }
        } catch (Throwable ignored) { }
    }

    private static String key(String url) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-1").digest(url.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Throwable e) { return Integer.toHexString(url.hashCode()); }
    }

    static String mime(File f) { return f.getName().endsWith(".jpg") ? "image/jpeg" : "image/png"; }

    /** Ficheiro já em cache (sem rede) ou null. */
    static File cached(String url) {
        if (dir == null) return null;
        String k = key(url);
        File p = new File(dir, k + ".png"), j = new File(dir, k + ".jpg");
        if (p.length() > 0) return p;
        if (j.length() > 0) return j;
        return null;
    }

    static boolean knownBad(String url) {
        Long t = BAD.get(url);
        if (t == null) return false;
        if (System.currentTimeMillis() - t > 10 * 60 * 1000) { BAD.remove(url); return false; }
        return true;
    }

    /** Devolve o ficheiro reduzido (da cache ou descarregado agora); null se não deu. */
    static File get(String url) {
        if (dir == null || url == null || !url.startsWith("http")) return null;
        File c = cached(url);
        if (c != null) { c.setLastModified(System.currentTimeMillis()); return c; }
        if (knownBad(url)) return null;
        boolean got = false;
        try {
            got = SEM.tryAcquire(8, TimeUnit.SECONDS);
            if (!got) return null;
            c = cached(url);
            if (c != null) return c;
            HttpURLConnection h = null;
            InputStream in = null;
            try {
                h = (HttpURLConnection) new URL(url).openConnection();
                h.setConnectTimeout(4000);
                h.setReadTimeout(5000);
                h.setInstanceFollowRedirects(true);
                h.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/120 Safari/537.36");
                if (h.getResponseCode() / 100 != 2) { BAD.put(url, System.currentTimeMillis()); return null; }
                in = h.getInputStream();
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) { bo.write(buf, 0, n); if (bo.size() > 4 * 1024 * 1024) { BAD.put(url, System.currentTimeMillis()); return null; } }
                byte[] data = bo.toByteArray();
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(data, 0, data.length, o);
                if (o.outWidth <= 0) { BAD.put(url, System.currentTimeMillis()); return null; }
                int ss = 1;
                while (Math.max(o.outWidth, o.outHeight) / (ss * 2) >= MAX_DIM) ss *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = ss;
                Bitmap bm = BitmapFactory.decodeByteArray(data, 0, data.length, o2);
                if (bm == null) { BAD.put(url, System.currentTimeMillis()); return null; }
                int m = Math.max(bm.getWidth(), bm.getHeight());
                if (m > MAX_DIM) {
                    float f = MAX_DIM / (float) m;
                    Bitmap s2 = Bitmap.createScaledBitmap(bm, Math.max(1, Math.round(bm.getWidth() * f)), Math.max(1, Math.round(bm.getHeight() * f)), true);
                    if (s2 != bm) { bm.recycle(); bm = s2; }
                }
                boolean alpha = bm.hasAlpha();
                File out = new File(dir, key(url) + (alpha ? ".png" : ".jpg"));
                File tmp = new File(dir, key(url) + ".tmp");
                FileOutputStream fo = new FileOutputStream(tmp);
                bm.compress(alpha ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, 85, fo);
                fo.close();
                bm.recycle();
                if (!tmp.renameTo(out)) { tmp.delete(); return null; }
                return out;
            } catch (Throwable e) {
                BAD.put(url, System.currentTimeMillis());
                return null;
            } finally {
                try { if (in != null) in.close(); } catch (Throwable ignored) { }
                try { if (h != null) h.disconnect(); } catch (Throwable ignored) { }
            }
        } catch (InterruptedException e) {
            return null;
        } finally {
            if (got) SEM.release();
        }
    }
}
