package pt.rui.cockpittv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Cockpit TV nativo (v271): a única app. Canais, filmes, séries (fichas, temporadas, continuar a ver, vistos),
 * favoritos, pesquisa, legendas online, transmitir (Chromecast), «Continuar a ver» no ecrã inicial da TV e definições.
 * A reprodução usa o NativePlayer e o ecrã de canal NativeScreen.
 */
public class NativeHomeActivity extends Activity {
    /* as cores e medidas da app antiga (Início da TV): fundo azul-noite, barra em gradiente, botões em pílula, cartões de 18 dp */
    private static int BG = 0xFF0A101C, CARD = 0xFF141C28, ACC = 0xFF7CC4FF, INK = 0xFF06213A, TXT = 0xFFE6EDF6, MUT = 0xFF8C9BB0, OK = 0xFF5CD68A;
    private static final int PANEL = 0x660F1622;
    /* v325: aspeto (cores e ícones) escolhido nas Definições */
    private static int BG2 = 0xFF04070D, SELBG = 0xFF22364A, CHIP = 0xFF2A3B52, NAV1 = 0xFF2D4966, NAV2 = 0xFF18293C, NAVBD = 0xFF49759C;
    private static int iconMode = 0, iconSize = 1;
    /** nome, destaque, texto sobre o destaque */
    private static final Object[][] ACCENTS = {
            {"Azul claro", 0xFF7CC4FF, 0xFF06213A}, {"Verde", 0xFF5CD68A, 0xFF062A14}, {"Laranja", 0xFFFFA24C, 0xFF3A1D04},
            {"Roxo", 0xFFB794F6, 0xFF1F0E40}, {"Rosa", 0xFFFF7EB6, 0xFF3D0A22}, {"Vermelho", 0xFFFF6B6B, 0xFF3D0707},
            {"Dourado", 0xFFF5D060, 0xFF3A2D04}, {"Turquesa", 0xFF4FE3D0, 0xFF03302B}, {"Branco", 0xFFEDEFF3, 0xFF111418}};
    /** nome, fundo, cartões, fundo escuro, barra 1, barra 2, linha da barra, chip */
    private static final Object[][] BGS = {
            {"Azul-noite", 0xFF0A101C, 0xFF141C28, 0xFF04070D, 0xFF2D4966, 0xFF18293C, 0xFF49759C, 0xFF2A3B52},
            {"Preto (OLED)", 0xFF000000, 0xFF101114, 0xFF000000, 0xFF23262B, 0xFF121316, 0xFF3A3E45, 0xFF24272C},
            {"Cinzento", 0xFF15171B, 0xFF21242A, 0xFF0B0C0F, 0xFF3A3F48, 0xFF24272E, 0xFF5A6070, 0xFF343942},
            {"Verde-noite", 0xFF08130F, 0xFF10201A, 0xFF030907, 0xFF245041, 0xFF14291F, 0xFF3F8F72, 0xFF21392E},
            {"Roxo-noite", 0xFF100A1C, 0xFF1C1428, 0xFF06030D, 0xFF45306A, 0xFF271A3C, 0xFF7653B0, 0xFF3A2B52},
            {"Vinho", 0xFF1A0A0F, 0xFF2A1219, 0xFF0A0306, 0xFF65303F, 0xFF3A1A24, 0xFFA04F66, 0xFF4A2531}};
    private static final String[] ICON_MODES = {"Original", "Cor de destaque", "Branco"};
    private static final String[] ICON_SIZES = {"Pequeno", "Normal", "Grande", "Muito grande"};
    private static final float[] ICON_SC = {0.8f, 1f, 1.3f, 1.6f};
    private void applyLook() {
        android.content.SharedPreferences sp = getSharedPreferences("nativeapp", 0);
        int a = Math.max(0, Math.min(ACCENTS.length - 1, sp.getInt("lkAcc", 0)));
        int b = Math.max(0, Math.min(BGS.length - 1, sp.getInt("lkBg", 0)));
        ACC = (Integer) ACCENTS[a][1]; INK = (Integer) ACCENTS[a][2];
        Object[] g = BGS[b];
        BG = (Integer) g[1]; CARD = (Integer) g[2]; BG2 = (Integer) g[3]; NAV1 = (Integer) g[4]; NAV2 = (Integer) g[5]; NAVBD = (Integer) g[6]; CHIP = (Integer) g[7];
        SELBG = (b == 0) ? 0xFF22364A : CHIP;
        iconMode = Math.max(0, Math.min(2, sp.getInt("lkIcM", 0)));
        iconSize = Math.max(0, Math.min(3, sp.getInt("lkIcS", 1)));
    }
    private static String hex(int c) { return String.format("#%06x", c & 0xFFFFFF); }
    private int tintFor(boolean primary) { return iconMode == 1 ? (primary ? INK : ACC) : iconMode == 2 ? (primary ? INK : 0xFFFFFFFF) : (primary ? INK : TXT); }
    private static final String[] TAB_ID = {"live", "movie", "series", "fav", "recent", "search"};
    private static final String[] TAB_L = {"Canais", "Filmes", "Séries", "★ Favoritos", "🕘 Vistos", "Pesquisar"};
    private static final String[] TAB_ICON = {"Canais", "Filmes", "Séries", "", "", "Pesquisar"};

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newFixedThreadPool(3);
    private final ExecutorService img = Executors.newFixedThreadPool(6);
    private final LruCache<String, Bitmap> bmp = new LruCache<String, Bitmap>(28 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };

    private NativeData data;
    private FrameLayout root;
    private LinearLayout body;
    private final TextView[] tabs = new TextView[TAB_ID.length];
    private ListView catList;
    private GridView grid;
    private TextView status, sortBtn;
    private ProgressBar spin;
    private EditText searchBox;
    private View settingsView;
    private FrameLayout details;
    private FrameLayout appLayer;
    private LinearLayout mainCol;
    /* secções da barra de cima (como na app antiga): Início, Explorar, Guia, Definições, Cast */
    private String section = "home";
    private JSONObject navCfg = new JSONObject();
    private final java.util.Map<String, Bitmap> kindIcons = new java.util.HashMap<>();
    private LinearLayout navBar, browseCol, chipsRow, statusRow, homeCol, homeRows, homeKinds;
    private ScrollView homeScroll;
    private TextView clock, heroLabel, heroTitle, heroSub, heroBtn1, heroBtn2, heroArtIni;
    private FrameLayout heroArt;
    private ImageView heroArtImg;
    /* pré-visualização do Início: canal escolhido (ou o último visto), a lista de onde veio, e o que está a dar */
    private NativeData.Item heroItem = null;
    private List<NativeData.Item> heroList = null;
    private int heroIdx = 0;
    private String pvUrl = null;
    private long pvT0 = 0;
    private boolean pvOff = false, pvLastVis = true;
    private String homeKind = "live";
    private int homeSeq = 0;
    private View lastHomeFocus = null;
    private final java.util.Map<String, String> epgCache = new java.util.HashMap<>();
    private final java.util.Map<String, Long> epgAt = new java.util.HashMap<>();
    private boolean epgOld(String url) { Long t = epgAt.get(url); return t != null && System.currentTimeMillis() - t > data.epgTtl(); }

    private String tab = "live";
    private List<NativeData.Cat> curCats = new ArrayList<>();
    private int curCat = 0;
    private String shownKey = "";
    private List<NativeData.Item> curItems = new ArrayList<>();
    /** série aberta (temporadas na coluna, episódios na grelha); null fora das séries */
    private NativeData.Item openSeries = null;
    private List<NativeData.Item> seriesEps = new ArrayList<>();
    private int seriesCatBefore = 0, seriesPosBefore = 0;
    private int loadSeq = 0;

    private NativePlayer np;
    private NativeScreen nscr;
    private CastHelper cast;
    private boolean castWanted = false;
    private List<NativeData.Item> playing = new ArrayList<>();
    private NativeData.Item nowItem = null;
    private List<String[]> osRes = new ArrayList<>();
    private String pendingOpen = null, pendingQuery = null;

    /** Escala do layout (v273): o desenho é o da app antiga a 1280×720; na TV fica ~0,9, no telemóvel deitado ~0,6, ao alto pela largura. */
    private float S = 1f;
    private void computeScale() {
        android.util.DisplayMetrics m = getResources().getDisplayMetrics();
        float w = m.widthPixels / m.density, h = m.heightPixels / m.density;
        float s = w >= h ? Math.min(w / 1280f, h / 720f) : w / 640f;
        S = Math.max(0.5f, Math.min(1.25f, s));
        /* v297: zoom do telemóvel (gesto de pinça no Início) */
        if (!isTv()) S = Math.max(0.35f, Math.min(2.2f, S * phZoom()));
    }
    private float phZoom() { return Math.max(0.6f, Math.min(1.8f, getSharedPreferences("nativeapp", 0).getFloat("phZoom", 1f))); }

    /* ------------------------------------------------------------ v297: zoom in / out com dois dedos no Início (telemóvel) */
    private android.view.ScaleGestureDetector pinch;
    private boolean pinching = false;
    private float pinchF = 1f;
    private boolean pinchAllowed() {
        return !isTv() && "home".equals(section) && details == null && (nscr == null || !nscr.isOpen()) && homeScroll != null && homeScroll.isShown();
    }
    private void ensurePinch() {
        if (pinch != null) return;
        pinch = new android.view.ScaleGestureDetector(this, new android.view.ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScaleBegin(android.view.ScaleGestureDetector d) {
                if (!pinchAllowed()) return false;
                pinching = true; pinchF = 1f;
                try { stopPreview(); } catch (Throwable ignored) { }
                homeScroll.setPivotX(d.getFocusX()); homeScroll.setPivotY(d.getFocusY() + homeScroll.getScrollY());
                return true;
            }
            @Override public boolean onScale(android.view.ScaleGestureDetector d) {
                float z = phZoom();
                pinchF = Math.max(0.6f / z, Math.min(1.8f / z, pinchF * d.getScaleFactor()));
                homeScroll.setScaleX(pinchF); homeScroll.setScaleY(pinchF);
                return true;
            }
            @Override public void onScaleEnd(android.view.ScaleGestureDetector d) { endPinch(); }
        });
        try { pinch.setQuickScaleEnabled(false); } catch (Throwable ignored) { }
    }
    private void endPinch() {
        if (!pinching) return;
        pinching = false;
        homeScroll.setScaleX(1f); homeScroll.setScaleY(1f);
        float z = Math.max(0.6f, Math.min(1.8f, phZoom() * pinchF));
        if (Math.abs(pinchF - 1f) < 0.04f) { startPreviewSoon(); return; }
        z = Math.round(z * 20f) / 20f;   /* passos de 5 % */
        getSharedPreferences("nativeapp", 0).edit().putFloat("phZoom", z).apply();
        NativeData.dbg("zoom do Início: " + Math.round(z * 100) + " %");
        Toast.makeText(this, "Zoom " + Math.round(z * 100) + " %", Toast.LENGTH_SHORT).show();
        saveHomePos();
        rebuild();
    }
    private void startPreviewSoon() { try { ui.postDelayed(() -> { if ("home".equals(section)) startPreview(); }, 50); } catch (Throwable ignored) { } }
    @Override
    public boolean dispatchTouchEvent(android.view.MotionEvent ev) {
        try {
            if (!isTv()) {
                ensurePinch();
                if (pinching || (ev.getPointerCount() >= 2 && pinchAllowed())) {
                    boolean was = pinching;
                    pinch.onTouchEvent(ev);
                    if (!was && pinching) {   /* começou o gesto: cancela o toque que os cartões / a lista tinham recebido */
                        android.view.MotionEvent c = android.view.MotionEvent.obtain(ev); c.setAction(android.view.MotionEvent.ACTION_CANCEL);
                        super.dispatchTouchEvent(c); c.recycle();
                    }
                    if (pinching) {
                        int a = ev.getActionMasked();
                        if (a == android.view.MotionEvent.ACTION_UP || a == android.view.MotionEvent.ACTION_CANCEL) endPinch();
                        return true;
                    }
                    if (was) return true;
                } else {
                    pinch.onTouchEvent(ev);
                }
            }
        } catch (Throwable ignored) { }
        return super.dispatchTouchEvent(ev);
    }
    private boolean portrait() { android.util.DisplayMetrics m = getResources().getDisplayMetrics(); return m.widthPixels < m.heightPixels; }
    private int dp(float v) { return (int) (v * S * getResources().getDisplayMetrics().density + 0.5f); }
    /** tamanho de letra em píxeis, com a mesma escala */
    private float fz(float sp) { return sp * S * getResources().getDisplayMetrics().density; }

    @Override
    protected void attachBaseContext(android.content.Context base) {
        try {
            float sc = MainActivity.uiScaleOf(base);
            if (Math.abs(sc - 1f) > 0.01f) {
                android.content.res.Configuration cfg = new android.content.res.Configuration(base.getResources().getConfiguration());
                cfg.densityDpi = Math.round(cfg.densityDpi * sc);
                super.attachBaseContext(base.createConfigurationContext(cfg));
                return;
            }
        } catch (Throwable ignored) { }
        super.attachBaseContext(base);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        applyLook();
        overridePendingTransition(0, 0);   /* abre direto, sem animação */
        PiconCache.init(this);
        NativeData.initPersist(getApplicationContext());
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        data = new NativeData(this);
        /* v331: ao abrir, verifica se o servidor IPTV responde e avisa se não */
        new Thread(() -> { try { Thread.sleep(2500); } catch (InterruptedException ignored) { } final String why = NativeData.checkServer(this); if (why != null) { final String h = NativeData.serverHost(this);
            runOnUiThread(() -> android.widget.Toast.makeText(this, "⚠️ O servidor IPTV (" + h + ") não está a funcionar: " + why + ". Não é um problema da app nem do aparelho.", android.widget.Toast.LENGTH_LONG).show()); } }).start();
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root);
        immersive();
        computeScale();
        buildUi();
        readIntent(getIntent());
        if (!data.configured()) {
            /* primeira vez: tenta trazer a lista, os favoritos e os vistos da app antiga (estão guardados no aparelho) */
            setStatus("A procurar os dados da app antiga…", true);
            importOld(ok -> { if (ok) showSection("home"); else showSection("settings"); });
            return;
        }
        String rs = getSharedPreferences("nativeapp", 0).getString("reopenSet", "");
        if (!rs.isEmpty()) { getSharedPreferences("nativeapp", 0).edit().remove("reopenSet").apply(); showSection("settings"); openSetPage(rs); }
        else if (pendingQuery != null) showTab("search"); else showSection("home");
        afterStart();
        /* v278: telemóvel: o som Dolby (E-AC-3) volta a ser descodificado pela app (o descodificador Dolby do Samsung adianta o som) */
        if (!isTv() && !getSharedPreferences("nativeapp", 0).getBoolean("dolbyMig278", false)) {
            np0().edit().remove("dolbySw").remove("av_spk_dolby").apply();
            getSharedPreferences("nativeapp", 0).edit().putBoolean("dolbyMig278", true).apply();
        }
        /* v285: na TV, o acerto de −800 ms do som Dolby era o valor do telemóvel Samsung (som 0,8 s atrasado nos filmes E-AC3 na TV): volta a 0 */
        if (isTv() && !getSharedPreferences("nativeapp", 0).getBoolean("avTvMig285", false)) {
            if (np0().getInt("av_spk_dolby", 0) == -800) np0().edit().remove("av_spk_dolby").apply();
            getSharedPreferences("nativeapp", 0).edit().putBoolean("avTvMig285", true).apply();
        }
        if (!getSharedPreferences("nativeapp", 0).getBoolean("extras3Done", false)) importExtras(() -> { opCache = null; if ("home".equals(section)) renderHome(); });
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        readIntent(i);
        if (pendingQuery != null) { showTab("search"); }
        afterStart();
    }

    /** cockpittv://play?id=<endereço> (Continuar a ver do ecrã inicial) e pesquisa por voz. */
    private void readIntent(Intent intent) {
        try {
            if (intent == null) return;
            String a = intent.getAction();
            if (a != null && (a.equals(Intent.ACTION_SEARCH) || a.equals("com.google.android.gms.actions.SEARCH_ACTION"))) {
                String q = intent.getStringExtra("query");
                if (q == null || q.isEmpty()) q = intent.getStringExtra(android.app.SearchManager.QUERY);
                if (q != null && !q.trim().isEmpty()) pendingQuery = q.trim();
                return;
            }
            Uri d = intent.getData();
            if (d != null && "cockpittv".equals(d.getScheme())) pendingOpen = d.getQueryParameter("id");
        } catch (Throwable ignored) { }
    }

    private void afterStart() {
        if (pendingQuery != null && searchBox != null) { searchBox.setText(pendingQuery); pendingQuery = null; }
        final String id = pendingOpen; pendingOpen = null;
        if (id == null || id.isEmpty()) return;
        /* v288: só carrega o tipo desse endereço (antes carregava canais, 247 mil filmes e séries antes de abrir) */
        NativeData.Item rec = null;
        for (NativeData.Item x : data.recents()) if (x.url.equals(id)) { rec = x; break; }
        if (rec != null && !"episode".equals(rec.kind)) { List<NativeData.Item> one = new ArrayList<>(); one.add(rec); play(one, 0, -1); return; }
        final String kind = id.contains("/movie/") ? "movie" : id.contains("/series/") ? "series" : "live";
        bg.execute(() -> {
            try { data.load(kind, false); } catch (Throwable ignored) { }
            final NativeData.Item it = data.findByUrl(id);
            ui.post(() -> {
                if (it == null) { Toast.makeText(this, "Já não encontro esse vídeo na lista.", Toast.LENGTH_LONG).show(); return; }
                if ("episode".equals(it.kind) && it.sid.length() > 0) playEpisode(it.sid, it.url);
                else { List<NativeData.Item> one = new ArrayList<>(); one.add(it); play(one, 0, -1); }
            });
        });
    }

    /* ------------------------------------------------------------ importar da app antiga (sem a abrir) */
    private interface Done { void run(boolean ok); }
    private void importOld(final Done done) {
        if (data.importFromWeb()) { done.run(true); return; }   /* a v270 clássica já tinha partilhado os dados */
        final boolean[] fin = {false};
        final Runnable timeout = () -> { if (!fin[0]) { fin[0] = true; done.run(false); } };
        try {
            final WebView w = new WebView(this);
            w.getSettings().setJavaScriptEnabled(true);
            w.getSettings().setDomStorageEnabled(true);
            w.getSettings().setAllowFileAccess(true);
            w.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView v, String u) {
                    v.evaluateJavascript("(function(){try{return JSON.stringify({c:localStorage.getItem('ck_cfg')||'',f:localStorage.getItem('ck_tvfavs')||'[]',r:localStorage.getItem('ck_tvRecent')||'[]'})}catch(e){return ''}})()", val -> {
                        boolean ok = false;
                        try {
                            if (val != null && val.length() > 4 && !"null".equals(val)) {
                                JSONObject o = new JSONObject(new JSONArray("[" + val + "]").getString(0));
                                ok = data.importJson(o.optString("c"), o.optString("f", "[]"), o.optString("r", "[]"));
                            }
                        } catch (Throwable ignored) { }
                        try { w.destroy(); } catch (Throwable ignored) { }
                        if (!fin[0]) { fin[0] = true; ui.removeCallbacks(timeout); done.run(ok); }
                    });
                }
            });
            /* a página antiga corria em file:///android_asset/: o mesmo endereço base dá acesso ao que ela guardou */
            w.loadDataWithBaseURL("file:///android_asset/index.html", "<html><body></body></html>", "text/html", "utf-8", null);
            ui.postDelayed(timeout, 8000);
        } catch (Throwable e) { timeout.run(); }
    }

    /** v274: as escolhas de operador, imagem, som e legendas que estavam na app antiga (uma vez). */
    private void importExtras(final Runnable after) {
        final android.content.SharedPreferences ns = getSharedPreferences("nativeapp", 0);
        try {
            final WebView w = new WebView(this);
            w.getSettings().setJavaScriptEnabled(true);
            w.getSettings().setDomStorageEnabled(true);
            w.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView v, String u) {
                    v.evaluateJavascript("(function(){try{var g=function(k){return localStorage.getItem('ck_'+k)};return JSON.stringify({op:g('tvOp'),opc:g('tvOpCustom'),afr:g('tvAfr'),dei:g('tvDeint'),tun:g('tvTunnel'),fsl:g('fsList'),prv:g('tvPrev'),snd:g('tvPrevSnd'),an:g('tvAnim'),vf:g('tvVfx'),tok:g('dbgTok'),org:g('tvOrg'),cty:localStorage.getItem('ck_tvCty'),cfg:g('ck_cfg')||g('cfg')})}catch(e){return ''}})()", val -> {
                        try {
                            JSONObject o = new JSONObject(new JSONArray("[" + val + "]").getString(0));
                            android.content.SharedPreferences.Editor e = ns.edit();
                            android.content.SharedPreferences.Editor n = getSharedPreferences("np", 0).edit();
                            if (!ns.getBoolean("extrasDone", false)) {   /* o resto só na 1.ª vez (não desfaz o que mudaste depois) */
                            String op = js(o, "op"); if (op != null) e.putString("tvOp", op);
                            String opc = js(o, "opc"); if (opc != null) e.putString("tvOpCustom", opc);
                            String prv = js(o, "prv"); if (prv != null) e.putBoolean("tvPrev", !"off".equals(prv));
                            String snd = js(o, "snd"); if (snd != null) e.putBoolean("tvPrevSnd", "on".equals(snd));
                            String afr = js(o, "afr"); if (afr != null) n.putBoolean("afr", !"off".equals(afr));
                            String dei = js(o, "dei"); if (dei != null) n.putBoolean("deint", "adapt".equals(dei));
                            String tun = js(o, "tun"); if (tun != null) n.putBoolean("tunnel", "true".equals(tun));
                            String fsl = js(o, "fsl"); if (fsl != null) n.putString("fsList", "off".equals(fsl) ? "off" : "all");
                            }
                            if (!ns.getBoolean("extras3Done", false)) { String og = js(o, "org"); String cy = o.isNull("cty") ? null : o.optString("cty", null); data.importOrg(og, cy); }
                            String an = js(o, "an"); if (an != null) e.putString("tvAnim", an);
                            String vf = js(o, "vf"); if (vf != null) e.putString("tvVfx", vf);
                            String tok = js(o, "tok"); if (tok != null && tok.length() > 3 && ns.getString("dbgTok", "").isEmpty()) e.putString("dbgTok", tok);
                            String cf = o.optString("cfg", ""); 
                            if (cf.length() > 2) { JSONObject cj = new JSONObject(cf); JSONObject ss = cj.optJSONObject("subStyle"); if (ss != null && !ns.getBoolean("extrasDone", false)) n.putString("subStyle", ss.toString()); String rp = cj.optString("dbgRepo", ""); if (rp.length() > 3) e.putString("dbgRepo", rp); }
                            e.putBoolean("extrasDone", true).putBoolean("extras2Done", true).putBoolean("extras3Done", true).apply(); n.apply();
                        } catch (Throwable ignored) { ns.edit().putBoolean("extrasDone", true).apply(); }
                        try { w.destroy(); } catch (Throwable ignored) { }
                        if (after != null) after.run();
                    });
                }
            });
            w.loadDataWithBaseURL("file:///android_asset/index.html", "<html><body></body></html>", "text/html", "utf-8", null);
        } catch (Throwable e) { ns.edit().putBoolean("extrasDone", true).apply(); }
    }
    /** valor guardado pela página (JSON): "\"meo\"" → meo; null se não existir */
    private static String js(JSONObject o, String k) {
        if (o.isNull(k)) return null;
        String v = o.optString(k, null); if (v == null) return null;
        try { Object x = new JSONArray("[" + v + "]").get(0); return String.valueOf(x); } catch (Throwable e) { return v; }
    }

    /* ------------------------------------------------------------ preferências de som e imagem (v274) */
    private android.content.SharedPreferences np0() { return getSharedPreferences("np", 0); }
    private static final String[] SUB_SIZE_L = {"Pequeno", "Normal", "Grande", "Enorme"};
    private static final int[] SUB_SIZE = {70, 100, 140, 190};
    private static final String[] SUB_COL_L = {"Branco", "Amarelo", "Verde", "Ciano"};
    private static final int[] SUB_COL = {0xFFFFFFFF, 0xFFFFEB3B, 0xFF66FF66, 0xFF00E5FF};
    private static final String[] SUB_BG_L = {"Sem fundo", "Transparente", "Preto"};
    private static final int[] SUB_BG = {0, 0x99000000, 0xFF000000};
    private static final String[] SUB_EDGE_L = {"Nenhum", "Sombra", "Contorno"};
    private static final String[] SUB_POS_L = {"Em baixo", "Meio", "Alto"};
    private static final float[] SUB_POS = {0.08f, 0.2f, 0.35f};
    private int subPref(String k, int def) { try { return new JSONObject(np0().getString("subStyle", "{}")).optInt(k, def); } catch (Throwable e) { return def; } }
    private void setSubPref(String k, int v) { try { JSONObject o = new JSONObject(np0().getString("subStyle", "{}")); o.put(k, v); np0().edit().putString("subStyle", o.toString()).apply(); } catch (Throwable ignored) { } applyPlayerPrefs(); }
    /** Aplica ao leitor: taxa de atualização, desentrelaçamento e aspeto das legendas. */
    private void applyPlayerPrefs() {
        try {
            /* v342: uma vez — TsFix + AFR ligados, SurfaceView (perfil fluidez Bravia). */
            if (!np0().getBoolean("optv342", false)) {
                android.content.SharedPreferences.Editor e = np0().edit();
                e.putBoolean("tsFix", true);
                e.putBoolean("afr", true);
                if (!np0().getBoolean("tvTextureUser", false)) e.putBoolean("tvTexture", false);
                e.putBoolean("optv342", true);
                e.apply();
            }
            int sz = SUB_SIZE[cl(subPref("size", 1), 4)], fg = SUB_COL[cl(subPref("color", 0), 4)], bgc = SUB_BG[cl(subPref("bg", 1), 3)], ed = cl(subPref("edge", 1), 3);
            float pos = SUB_POS[cl(subPref("pos", 0), 3)];
            NativePlayer.subSizePct = sz; NativePlayer.subFg = fg; NativePlayer.subBg = bgc; NativePlayer.subEdge = ed; NativePlayer.subBottom = pos;
            if (np != null) {
                np.setSubStyle(sz, fg, bgc, ed, pos);
                np.setAfr(np0().getBoolean("afr", true));
                String dm = deintModePref();
                np.setDeint(dm.equals("adapt") || dm.equals("lines") || dm.equals("blend"));
                np.setDeintMode(dm.equals("lines") ? DeinterlaceEffect.LINES : dm.equals("blend") ? DeinterlaceEffect.BLEND : DeinterlaceEffect.ADAPT,
                        new float[]{0f, 0.35f, 0.7f}[cl(np0().getInt("sdSharp", 0), 3)]);
            }
        } catch (Throwable ignored) { }
    }
    private static int cl(int v, int n) { return Math.max(0, Math.min(n - 1, v)); }
    /** v298: off / tv / adapt / lines / blend (antes só havia ligado/desligado = adapt/off) */
    private String deintModePref() {
        String m = np0().getString("deintMode", "");
        if (m.isEmpty()) m = np0().getBoolean("deint", false) ? "adapt" : "off";
        return m;
    }
    private static final String[] DEINT_KEYS = {"off", "tv", "adapt", "lines", "blend"};

    /* ------------------------------------------------------------ interface */
    private StateListDrawable sel(int base, int radius) {
        StateListDrawable s = new StateListDrawable();
        GradientDrawable f = new GradientDrawable(); f.setColor(SELBG); f.setStroke(dp(2), ACC); f.setCornerRadius(dp(radius));
        GradientDrawable p = new GradientDrawable(); p.setColor(0xFF1E3044); p.setCornerRadius(dp(radius));
        GradientDrawable n = new GradientDrawable(); n.setColor(base); n.setCornerRadius(dp(radius));
        s.addState(new int[]{android.R.attr.state_focused}, f);
        s.addState(new int[]{android.R.attr.state_selected}, f);
        s.addState(new int[]{android.R.attr.state_pressed}, p);
        s.addState(new int[]{}, n);
        return s;
    }
    private StateListDrawable ringSel(int radius) {
        StateListDrawable s = new StateListDrawable();
        GradientDrawable f = new GradientDrawable(); f.setColor((ACC & 0xFFFFFF) | 0x26000000); f.setStroke(dp(3), ACC); f.setCornerRadius(dp(radius));
        GradientDrawable p = new GradientDrawable(); p.setColor(0x337CC4FF); p.setCornerRadius(dp(radius));
        s.addState(new int[]{android.R.attr.state_focused}, f);
        s.addState(new int[]{android.R.attr.state_selected}, f);
        s.addState(new int[]{android.R.attr.state_pressed}, p);
        s.addState(new int[]{}, new android.graphics.drawable.ColorDrawable(0));
        return s;
    }
    private GradientDrawable roundRect(int c, int r) { GradientDrawable g = new GradientDrawable(); g.setColor(c); g.setCornerRadius(dp(r)); return g; }

    /* ------------------------------------------------------------ aspeto (igual ao da app antiga) */
    private static String asset(android.content.Context c, String name) {
        try (InputStream in = c.getAssets().open(name)) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); byte[] b = new byte[16384]; int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            return bo.toString("UTF-8");
        } catch (Throwable e) { return ""; }
    }
    private static Bitmap b64(String s) {
        try { byte[] b = android.util.Base64.decode(s, android.util.Base64.DEFAULT); return BitmapFactory.decodeByteArray(b, 0, b.length); } catch (Throwable e) { return null; }
    }
    private int col(String k, int def) { try { return android.graphics.Color.parseColor(navCfg.optString(k, "")); } catch (Throwable e) { return def; } }

    /** Ícones dos botões do leitor e barra do ecrã do canal: os mesmos da app antiga (guardados na APK). */
    private void loadLook() {
        try { MainActivity.ICONS_JSON = asset(this, "ui/icons.json"); } catch (Throwable ignored) { }
        try { navCfg = new JSONObject(asset(this, "ui/nav.json")); } catch (Throwable ignored) { }
        try { navCfg.put("acc", hex(ACC)); navCfg.put("ink", hex(INK)); navCfg.put("c1", hex(NAV1)); navCfg.put("c2", hex(NAV2)); navCfg.put("bd", hex(NAVBD)); } catch (Throwable ignored) { }
        try { JSONObject k = new JSONObject(asset(this, "ui/kinds.json")); java.util.Iterator<String> it = k.keys(); while (it.hasNext()) { String n = it.next(); Bitmap b = b64(k.optString(n)); if (b != null) kindIcons.put(n, b); } } catch (Throwable ignored) { }
    }
    /** Barra para o ecrã do canal (NativeScreen), com as medidas deste ecrã. */
    private String playerNavJson() {
        try {
            JSONObject o = new JSONObject(navCfg.toString());
            float d = getResources().getDisplayMetrics().density * S;
            boolean phone = getResources().getDisplayMetrics().widthPixels < getResources().getDisplayMetrics().heightPixels;
            o.put("phone", phone); o.put("sc", d); o.put("h", Math.round(72 * d)); o.put("fs", Math.round(16 * d)); o.put("cfs", Math.round(26 * d)); o.put("geo", false);
            return o.toString();
        } catch (Throwable e) { return ""; }
    }

    private GradientDrawable pill(int c, float r) { GradientDrawable g = new GradientDrawable(); g.setColor(c); g.setCornerRadius(dp(r)); return g; }
    private GradientDrawable ring(int c, float r) { GradientDrawable g = pill(c, r); g.setStroke(dp(3), 0xFFFFFFFF); return g; }

    /** Botão como os da app antiga (thBtn): ícone + texto, 14 dp de raio; o principal em azul claro. */
    private TextView thBtn(String text, Bitmap icon, final boolean primary, View.OnClickListener l) {
        final TextView b = new TextView(this);
        b.setText(text); b.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(17)); b.setGravity(Gravity.CENTER_VERTICAL); b.setSingleLine(true);
        b.setPadding(dp(20), dp(6), dp(20), dp(6)); b.setMinHeight(dp(44));
        b.setFocusable(true); b.setClickable(true);
        b.setCompoundDrawablePadding(dp(8));
        setPrimary(b, icon, primary);
        b.setOnFocusChangeListener((v, f) -> {
            boolean pr = Boolean.TRUE.equals(v.getTag());
            v.setBackground(f ? ring(pr ? ACC : 0x33FFFFFF, 14) : pill(pr ? ACC : 0x1FFFFFFF, 14));
            v.animate().scaleX(f ? 1.04f : 1f).scaleY(f ? 1.04f : 1f).setDuration(120).start();
        });
        if (l != null) b.setOnClickListener(l);
        return b;
    }
    private void setPrimary(TextView b, Bitmap icon, boolean primary) {
        b.setTag(primary);
        b.setTextColor(primary ? INK : TXT);
        b.setBackground(b.isFocused() ? ring(primary ? ACC : 0x33FFFFFF, 14) : pill(primary ? ACC : 0x1FFFFFFF, 14));
        if (icon != null) {
            android.graphics.drawable.BitmapDrawable d = new android.graphics.drawable.BitmapDrawable(getResources(), icon);
            int isz = Math.round(dp(20) * ICON_SC[iconSize]);
            d.setBounds(0, 0, isz, isz);
            d.setColorFilter(tintFor(primary), android.graphics.PorterDuff.Mode.SRC_IN);
            b.setCompoundDrawables(d, null, null, null);
        }
    }

    private void buildUi() {
        loadLook();
        GradientDrawable lin = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{BG, BG2});
        GradientDrawable glow = new GradientDrawable(); glow.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        glow.setColors(new int[]{(ACC & 0xFFFFFF) | 0x33000000, 0x00000000}); glow.setGradientRadius(dp(700)); glow.setGradientCenter(0.85f, -0.08f);
        root.setBackground(new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{lin, glow}));

        /* a interface fica numa camada própria por baixo do vídeo (o leitor junta a sua vista ao root, por cima) */
        appLayer = new FrameLayout(this);
        root.addView(appLayer, 0, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        mainCol = main;
        appLayer.addView(main, new FrameLayout.LayoutParams(-1, -1));
        buildNav();
        main.addView(navBar, new LinearLayout.LayoutParams(-1, dp(72)));
        FrameLayout content = new FrameLayout(this);
        main.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        /* ---- Início ---- */
        homeScroll = new ScrollView(this);
        homeScroll.setFillViewport(true);
        homeScroll.setVerticalScrollBarEnabled(false);
        homeScroll.setClipToPadding(false);
        homeCol = new LinearLayout(this); homeCol.setOrientation(LinearLayout.VERTICAL);
        homeCol.setPadding(dp(48), dp(8), dp(48), dp(40)); homeCol.setClipChildren(false); homeCol.setClipToPadding(false);
        homeScroll.addView(homeCol);
        /* destaque (thHero): à esquerda a janela 16:9 com a pré-visualização do canal, à direita o texto e os botões */
        LinearLayout hero = new LinearLayout(this); hero.setOrientation(portrait() ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable hg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF375778, 0xFF0D1526, 0xFF0D1526}); hg.setCornerRadius(dp(26));
        hero.setBackground(hg); hero.setPadding(dp(24), dp(14), dp(24), dp(14)); hero.setElevation(dp(10));
        heroArt = new FrameLayout(this);
        heroArt.setBackground(pill(0xCC0B1220, 8)); heroArt.setClipToOutline(true);
        heroArtImg = new ImageView(this); heroArtImg.setScaleType(ImageView.ScaleType.FIT_CENTER); heroArtImg.setPadding(dp(30), dp(20), dp(30), dp(20));
        heroArt.addView(heroArtImg, new FrameLayout.LayoutParams(-1, -1));
        heroArtIni = new TextView(this); heroArtIni.setTextColor(TXT); heroArtIni.setAlpha(0.6f); heroArtIni.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(44)); heroArtIni.setTypeface(null, Typeface.BOLD);
        heroArt.addView(heroArtIni, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int innerW = dm.widthPixels - dp(48) * 2 - dp(24) * 2;
        int aw = portrait() ? innerW : Math.max(dp(280), Math.min(dp(680), (int) (innerW * 0.42f)));
        if (!portrait()) aw = Math.min(aw, (int) ((dm.heightPixels * 0.34f) * 16 / 9));   /* deitado: a janela não passa de ~1/3 da altura, para as filas ficarem à vista */
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(aw, aw * 9 / 16);
        if (portrait()) al.bottomMargin = dp(12); else al.rightMargin = dp(20);
        hero.addView(heroArt, al);
        heroArt.setVisibility(View.GONE);
        heroArt.addOnLayoutChangeListener((q0, q1, q2, q3, q4, q5, q6, q7, q8) -> placePreview());
        LinearLayout htx = new LinearLayout(this); htx.setOrientation(LinearLayout.VERTICAL);
        heroLabel = new TextView(this); heroLabel.setText("COCKPIT TV"); heroLabel.setTextColor(TXT); heroLabel.setAlpha(0.7f); heroLabel.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(12)); heroLabel.setLetterSpacing(0.14f); heroLabel.setSingleLine(true);
        heroTitle = new TextView(this); heroTitle.setText("Bem-vindo"); heroTitle.setTextColor(TXT); heroTitle.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(28)); heroTitle.setTypeface(null, Typeface.BOLD); heroTitle.setLetterSpacing(0.03f); heroTitle.setSingleLine(true); heroTitle.setEllipsize(TextUtils.TruncateAt.END);
        heroSub = new TextView(this); heroSub.setText("Escolhe um canal em baixo para começar."); heroSub.setTextColor(TXT); heroSub.setAlpha(0.85f); heroSub.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(16)); heroSub.setMaxLines(2); heroSub.setEllipsize(TextUtils.TruncateAt.END);
        htx.addView(heroLabel);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-1, -2); tl.topMargin = dp(4); htx.addView(heroTitle, tl);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-1, -2); sl.topMargin = dp(4); htx.addView(heroSub, sl);
        LinearLayout hb = new LinearLayout(this); hb.setClipChildren(false);
        heroBtn1 = thBtn("Explorar canais", kindIcons.get("Explorar canais"), true, v -> heroPrimary());
        heroBtn2 = thBtn("Definições", kindIcons.get("Definições"), false, v -> heroSecondary());
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, dp(44)); bl.rightMargin = dp(12);
        hb.addView(heroBtn1, bl); hb.addView(heroBtn2, new LinearLayout.LayoutParams(-2, dp(44)));
        LinearLayout.LayoutParams hbl = new LinearLayout.LayoutParams(-1, -2); hbl.topMargin = dp(10); htx.addView(hb, hbl);
        hero.addView(htx, new LinearLayout.LayoutParams(portrait() ? -1 : 0, -2, portrait() ? 0 : 1));
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(-1, -2); hl.topMargin = dp(2); hl.bottomMargin = dp(6);
        homeCol.addView(hero, hl);
        homeScroll.setOnScrollChangeListener((q0, q1, q2, q3, q4) -> { placePreview(); fxSoon(); });
        homeKinds = new LinearLayout(this); homeKinds.setClipChildren(false); homeKinds.setPadding(0, dp(4), 0, dp(4));
        String[][] K = {{"live", "Canais"}, {"movie", "Filmes"}, {"series", "Séries"}};
        homeKind = getSharedPreferences("nativeapp", 0).getString("homeKind", "live");
        for (final String[] k : K) {
            TextView c = thBtn(k[1], kindIcons.get(k[1]), k[0].equals(homeKind), v -> { if (homeKind.equals(k[0])) return; saveHomePos(); homeKind = k[0]; getSharedPreferences("nativeapp", 0).edit().putString("homeKind", homeKind).apply(); markKinds(); renderHome(); });
            c.setContentDescription(k[0]);
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, dp(44)); cl.rightMargin = dp(12);
            homeKinds.addView(c, cl);
        }
        homeKinds.addView(thBtn("Pesquisar", kindIcons.get("Pesquisar"), false, v -> { searchKind = homeKind; showTab("search"); }), new LinearLayout.LayoutParams(-2, dp(44)));
        LinearLayout.LayoutParams kl = new LinearLayout.LayoutParams(-1, -2); kl.topMargin = dp(12); kl.bottomMargin = dp(4);
        homeCol.addView(homeKinds, kl);
        homeRows = new LinearLayout(this); homeRows.setOrientation(LinearLayout.VERTICAL); homeRows.setClipChildren(false);
        homeCol.addView(homeRows, new LinearLayout.LayoutParams(-1, -2));
        content.addView(homeScroll, new FrameLayout.LayoutParams(-1, -1));

        /* ---- Explorar / Guia / Definições ---- */
        browseCol = new LinearLayout(this);
        browseCol.setOrientation(LinearLayout.VERTICAL);
        content.addView(browseCol, new FrameLayout.LayoutParams(-1, -1));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false); hs.setClipToPadding(false);
        chipsRow = new LinearLayout(this);
        chipsRow.setPadding(dp(48), dp(12), dp(48), dp(6)); chipsRow.setClipChildren(false);
        for (int i = 0; i < TAB_ID.length; i++) {
            final String id = TAB_ID[i];
            TextView t = thBtn(TAB_L[i], kindIcons.get(TAB_ICON[i]), false, v -> showTab(id));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(44)); lp.rightMargin = dp(12);
            chipsRow.addView(t, lp);
            tabs[i] = t;
        }
        hs.addView(chipsRow);
        browseCol.addView(hs, new LinearLayout.LayoutParams(-1, -2));

        statusRow = new LinearLayout(this);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);
        statusRow.setPadding(dp(52), dp(2), dp(48), dp(6));
        spin = new ProgressBar(this); spin.setIndeterminate(true); spin.setVisibility(View.GONE);
        statusRow.addView(spin, new LinearLayout.LayoutParams(dp(18), dp(18)));
        status = new TextView(this); status.setTextColor(MUT); status.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(14)); status.setPadding(dp(8), 0, 0, 0);
        status.setSingleLine(true); status.setEllipsize(TextUtils.TruncateAt.END);
        statusRow.addView(status, new LinearLayout.LayoutParams(0, -2, 1));
        sortBtn = thBtn("⇅", null, false, v -> pickSort());
        sortBtn.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(15)); sortBtn.setMinHeight(dp(36));
        sortBtn.setVisibility(View.GONE);
        statusRow.addView(sortBtn, new LinearLayout.LayoutParams(-2, dp(38)));
        browseCol.addView(statusRow, new LinearLayout.LayoutParams(-1, -2));

        searchRow = new LinearLayout(this); searchRow.setOrientation(LinearLayout.HORIZONTAL); searchRow.setVisibility(View.GONE);
        searchBox = new EditText(this);
        searchBox.setHint("Nome do canal, filme ou série…"); searchBox.setHintTextColor(MUT); searchBox.setTextColor(TXT); searchBox.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(17));
        searchBox.setSingleLine(true); searchBox.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchBox.setOnEditorActionListener((v, a, e) -> {   /* v278: a lupa do teclado fecha o teclado e mostra os resultados */
            boolean go = a == EditorInfo.IME_ACTION_SEARCH || a == EditorInfo.IME_ACTION_DONE || (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER && e.getAction() == KeyEvent.ACTION_DOWN);
            if (!go) return false;
            hideKb(v);
            ui.removeCallbacks(doSearch); runSearch();
            ui.postDelayed(() -> { if (!curItems.isEmpty()) { grid.requestFocus(); grid.setSelection(0); } }, 150);
            return true;
        });
        searchBox.setBackground(sel(0x1FFFFFFF, 14)); searchBox.setPadding(dp(18), dp(10), dp(18), dp(10));
        countryBox = new EditText(this);   /* v348: país para filtrar filmes e séries (PT, BR, EN…) */
        countryBox.setHint("País (PT, BR, EN…)"); countryBox.setHintTextColor(MUT); countryBox.setTextColor(TXT); countryBox.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(17));
        countryBox.setSingleLine(true); countryBox.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        countryBox.setFilters(new android.text.InputFilter[]{new android.text.InputFilter.LengthFilter(3), new android.text.InputFilter.AllCaps()});
        countryBox.setBackground(sel(0x1FFFFFFF, 14)); countryBox.setPadding(dp(14), dp(10), dp(14), dp(10));
        countryBox.setVisibility(View.GONE);
        countryBox.setOnEditorActionListener((v, a, e) -> { if (a != EditorInfo.IME_ACTION_SEARCH && a != EditorInfo.IME_ACTION_DONE) return false; hideKb(v); ui.removeCallbacks(doSearch); runSearch(); return true; });
        countryBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) { ui.removeCallbacks(doSearch); ui.postDelayed(doSearch, 350); }
        });
        searchRow.setVisibility(View.GONE);
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) { ui.removeCallbacks(doSearch); ui.postDelayed(doSearch, 350); }
        });
        searchRow.addView(searchBox, new LinearLayout.LayoutParams(0, -2, 1));
        LinearLayout.LayoutParams clp = new LinearLayout.LayoutParams(dp(200), -2); clp.leftMargin = dp(10);
        searchRow.addView(countryBox, clp);
        /* v371: género/categoria para filtrar filmes e séries (ex.: ação, comédia); pode usar-se sem nome */
        genreBox = new Button(this);   /* v372: género escolhido numa lista (dropdown) com todas as categorias */
        genreBox.setAllCaps(false); genreBox.setText("Género: todos ▾"); genreBox.setTextColor(TXT); genreBox.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(16));
        genreBox.setBackground(sel(0x1FFFFFFF, 14)); genreBox.setPadding(dp(14), dp(10), dp(14), dp(10));
        genreBox.setVisibility(View.GONE);
        genreBox.setOnClickListener(v -> showGenrePicker());
        LinearLayout.LayoutParams glp = new LinearLayout.LayoutParams(dp(240), -2); glp.leftMargin = dp(10);
        searchRow.addView(genreBox, glp);
        Button voiceBtn = new Button(this); voiceBtn.setText("🎤"); voiceBtn.setAllCaps(false); voiceBtn.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(16));   /* v365: pesquisa por voz */
        voiceBtn.setOnClickListener(v -> voiceSearch());
        searchRow.addView(voiceBtn, new LinearLayout.LayoutParams(dp(72), -2));
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2); slp.setMargins(dp(48), dp(2), dp(48), dp(8));
        browseCol.addView(searchRow, slp);

        body = new LinearLayout(this);
        body.setPadding(dp(40), 0, dp(40), 0);
        browseCol.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));

        catList = new ListView(this);
        catList.setDivider(null); catList.setSelector(sel(0x00000000, 14)); catList.setDrawSelectorOnTop(false);
        catList.setBackground(pill(0x59141C28, 18)); catList.setPadding(dp(6), dp(6), dp(6), dp(6)); catList.setClipToPadding(false);
        catList.setVerticalScrollBarEnabled(false);
        catList.setAdapter(catAdapter);
        catList.setOnItemClickListener((p, v, pos, id) -> pickCat(pos, true));
        catList.setOnItemLongClickListener((p, v, pos, id) -> { catMenu(pos); return true; });
        catList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                /* comando da TV: percorrer as categorias já mostra os itens (com um pequeno atraso para não pesar) */
                final int ps = pos; ui.removeCallbacks(catSelRun); catSelRun = () -> pickCat(ps, false); ui.postDelayed(catSelRun, 220);
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
        body.addView(catList, new LinearLayout.LayoutParams(dp(270), -1));

        grid = new GridView(this);
        grid.setSelector(ringSel(18)); grid.setDrawSelectorOnTop(true);   /* v281: só o contorno por cima (o fundo cheio tapava o nome do canal) */
        grid.setPadding(dp(14), dp(6), dp(8), dp(16)); grid.setClipToPadding(false);
        grid.setVerticalSpacing(dp(14)); grid.setHorizontalSpacing(dp(14));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setLayoutAnimation(null); grid.setVerticalScrollBarEnabled(false);
        grid.setAdapter(gridAdapter);
        grid.setOnItemClickListener((p, v, pos, id) -> onItem(pos));
        grid.setOnItemLongClickListener((p, v, pos, id) -> { itemMenu(pos); return true; });
        grid.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { if ("guide".equals(section) && pos >= 0 && pos < curItems.size()) wantEpg(curItems.get(pos)); }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
        body.addView(grid, new LinearLayout.LayoutParams(0, -1, 1));
        browseCol.setVisibility(View.GONE);
        ui.post(clockTick);
    }

    /* ------------------------------------------------------------ barra de cima */
    private final java.util.Map<String, View> navTabs = new java.util.HashMap<>();
    private Bitmap navIcon(String id) {
        JSONArray t = navCfg.optJSONArray("tabs"); if (t == null) return null;
        for (int i = 0; i < t.length(); i++) { JSONObject o = t.optJSONObject(i); if (o != null && id.equals(o.optString("id"))) return b64(o.optString("icon")); }
        return null;
    }
    private final Runnable clockTick = new Runnable() { @Override public void run() {
        try { if (clock != null) clock.setText(new java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(new java.util.Date())); } catch (Throwable ignored) { }
        ui.postDelayed(this, 10000);
    } };
    private static String secOf(String navId) { return "tvhome".equals(navId) ? "home" : "tv".equals(navId) ? "explore" : navId; }

    private void buildNav() {
        navBar = new LinearLayout(this);
        navBar.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{col("c1", 0xFF2D4966), col("c2", 0xFF18293C)});
        android.graphics.drawable.LayerDrawable ld = new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{bg, new android.graphics.drawable.ColorDrawable(col("bd", 0xFF49759C))});
        try { ld.setLayerHeight(1, dp(2)); ld.setLayerGravity(1, Gravity.BOTTOM); } catch (Throwable ignored) { }
        navBar.setBackground(ld);
        navBar.setPadding(dp(28), 0, dp(14), 0);
        navBar.setElevation(dp(6));
        clock = new TextView(this);
        clock.setTextColor(0xFFFFFFFF); clock.setTypeface(Typeface.DEFAULT_BOLD); clock.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(26)); clock.setSingleLine(true);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, -2); cl.rightMargin = dp(24);
        navBar.addView(clock, cl);
        HorizontalScrollView hs = new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); hs.setFillViewport(false);
        LinearLayout tabsL = new LinearLayout(this); tabsL.setGravity(Gravity.CENTER_VERTICAL);
        hs.addView(tabsL);
        JSONArray t = navCfg.optJSONArray("tabs");
        if (t == null || t.length() == 0) {
            t = new JSONArray();
            try { for (String[] x : new String[][]{{"tvhome", "Início"}, {"tv", "Explorar"}, {"guide", "Guia"}, {"settings", "Definições"}, {"cast", "Cast"}}) t.put(new JSONObject().put("id", x[0]).put("label", x[1])); } catch (Throwable ignored) { }
        }
        for (int i = 0; i < t.length(); i++) {
            final JSONObject o = t.optJSONObject(i); if (o == null) continue;
            final String id = o.optString("id");
            final LinearLayout tab = new LinearLayout(this);
            tab.setGravity(Gravity.CENTER); tab.setPadding(dp(22), dp(6), dp(22), dp(6));
            final ImageView iv = new ImageView(this);
            tab.addView(iv, new LinearLayout.LayoutParams(Math.round(dp(22) * ICON_SC[iconSize]), Math.round(dp(22) * ICON_SC[iconSize])));
            final TextView lb = new TextView(this);
            lb.setText(o.optString("label")); lb.setSingleLine(true); lb.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(16));
            LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(-2, -2); ll.leftMargin = dp(8);
            tab.addView(lb, ll);
            tab.setTag(new Object[]{iv, lb, b64(o.optString("icon")), b64(o.optString("iconA"))});
            tab.setFocusable(true); tab.setClickable(true);
            tab.setOnFocusChangeListener((v, f) -> styleTab(tab, id));
            tab.setOnClickListener(v -> {
                if ("cast".equals(id)) { startCast(); return; }
                if ("mirror".equals(id)) { startMirror(); return; }
                showSection(secOf(id));
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(50)); lp.rightMargin = dp(8);
            tabsL.addView(tab, lp);
            navTabs.put(id, tab);
            styleTab(tab, id);
        }
        navBar.addView(hs, new LinearLayout.LayoutParams(0, -1, 1));
    }

    private void styleTab(View tab, String id) {
        Object[] p = (Object[]) tab.getTag();
        boolean cur = secOf(id).equals(section);
        boolean f = tab.isFocused();
        GradientDrawable g = pill(cur ? ACC : (f ? 0x22FFFFFF : 0x00000000), 999);
        if (f) g.setStroke(dp(3), 0xFFFFFFFF);
        tab.setBackground(g);
        tab.setAlpha(cur || f ? 1f : 0.82f);
        Bitmap ic = (Bitmap) (cur && p[3] != null ? p[3] : p[2]);
        ((ImageView) p[0]).setImageBitmap(ic);
        if (iconMode == 0) ((ImageView) p[0]).clearColorFilter(); else ((ImageView) p[0]).setColorFilter(iconMode == 1 ? (cur ? INK : ACC) : (cur ? INK : 0xFFFFFFFF), android.graphics.PorterDuff.Mode.SRC_IN);
        ((TextView) p[1]).setTextColor(cur ? col("ink", INK) : 0xFFE6EEF9);
        ((TextView) p[1]).setTypeface(Typeface.DEFAULT_BOLD);
    }

    /** Muda de secção (Início / Explorar / Guia / Definições), sem animação. */
    private void showSection(String sec) {
        closeDetails();
        if ("home".equals(section) && !"home".equals(sec)) saveHomePos();
        if (("explore".equals(section) || "guide".equals(section)) && !sec.equals(section)) saveBrowsePos();
        section = sec;
        for (java.util.Map.Entry<String, View> e : navTabs.entrySet()) styleTab(e.getValue(), e.getKey());
        boolean home = "home".equals(sec);
        if (!home) stopPreview();
        homeScroll.setVisibility(home ? View.VISIBLE : View.GONE);
        browseCol.setVisibility(home ? View.GONE : View.VISIBLE);
        if (home) { renderHome(); return; }
        if ("settings".equals(sec)) { lastBrowseSec = "settings"; chipsRow.setVisibility(View.GONE); setPage = ""; showTab("settings"); return; }
        if ("tvlive".equals(sec)) { lastBrowseSec = "tvlive"; chipsRow.setVisibility(View.GONE); showTvLive(); return; }
        chipsRow.setVisibility("guide".equals(sec) ? View.GONE : View.VISIBLE);
        if ("guide".equals(sec)) {
            lastBrowseSec = "guide";
            showTab("live");
            searchBox.setText(""); searchBox.setHint("Pesquisar canal no guia…"); searchRow.setVisibility(View.VISIBLE); countryBox.setVisibility(View.GONE); genreBox.setVisibility(View.GONE);
            setStatus("Guia: escolhe uma categoria ou pesquisa um canal.", false);
            return;
        }
        /* v286: voltar ao Explorar não recarrega: se a lista ainda está montada, mostra-a como ficou */
        boolean intact = "explore".equals(lastBrowseSec) && !curCats.isEmpty() && settingsView == null && browseTab != null && browseTab.equals(tab) && !"search".equals(tab);
        lastBrowseSec = "explore";
        if (intact) {
            searchRow.setVisibility(View.GONE); catList.setVisibility(View.VISIBLE); grid.setVisibility(View.VISIBLE);
            markTabs(); updateSortBtn();
            ui.post(() -> { if (!grid.hasFocus() && !catList.hasFocus()) grid.requestFocus(); });
            return;
        }
        showTab(browseTab == null || "settings".equals(browseTab) ? "live" : browseTab);
    }
    private String browseTab = "live", lastBrowseSec = "";

    private void markKinds() {
        for (int i = 0; i < homeKinds.getChildCount(); i++) {
            View v = homeKinds.getChildAt(i);
            if (!(v instanceof TextView) || v.getContentDescription() == null) continue;
            String k = v.getContentDescription().toString();
            setPrimary((TextView) v, kindIcons.get(((TextView) v).getText().toString()), k.equals(homeKind));
        }
    }

    private void markTabs() {
        for (int i = 0; i < TAB_ID.length; i++) setPrimary(tabs[i], kindIcons.get(TAB_ICON[i]), TAB_ID[i].equals(tab));
    }

    /* ------------------------------------------------------------ Início: destaque + filas de cartões */
    private static final java.util.regex.Pattern PT = java.util.regex.Pattern.compile("(^|[^A-Za-zÀ-ÿ])(PT|PT-PT|PORTUGAL|PORTUGU[EÊ]S|PORTUGUESA)([^A-Za-zÀ-ÿ]|$)|🇵🇹", java.util.regex.Pattern.CASE_INSENSITIVE);

    private void renderHome() {
        refreshHero();
        if (!data.configured()) { homeRows.removeAllViews(); homeRows.addView(emptyMsg("Sem lista configurada. Abre as Definições.")); return; }
        final String kind = homeKind;
        final int seq = ++homeSeq;
        /* v288: ao abrir, mostra logo as filas guardadas da última vez (o Início aparece de imediato) enquanto a lista carrega */
        if (homeRows.getChildCount() == 0 && !data.cats.containsKey(kind)) {
            bg.execute(() -> {
                final List<Object[]> snap = loadHomeSnap(kind);
                if (snap != null && !snap.isEmpty()) ui.post(() -> { if (seq == homeSeq && "home".equals(section) && homeRows.getChildCount() == 0) { homeSig = "snap"; buildRows(snap, kind); } });
            });
        }
        bg.execute(() -> {
            try { data.load(kind, false); } catch (Throwable ignored) { }
            final List<Object[]> rows = new ArrayList<>();
            /* v301: fila «Continuar a ver» removida do Início (repetia os «Vistos recentemente») */
            List<NativeData.Item> fav = new ArrayList<>();
            for (NativeData.Item x : data.favItems()) if (kind.equals(x.kind)) fav.add(x);
            if (!fav.isEmpty()) rows.add(new Object[]{"⭐ Favoritos", fav.subList(0, Math.min(40, fav.size())), fav.size()});
            List<NativeData.Item> rec = new ArrayList<>(); java.util.Set<String> seen = new java.util.HashSet<>();
            for (NativeData.Item x : data.recents()) {
                NativeData.Item y = x;
                if ("series".equals(kind) && "episode".equals(x.kind)) { y = data.seriesBySid(x.sid); if (y == null) continue; }
                else if (!kind.equals(x.kind)) continue;
                if (seen.add(y.url)) rec.add(y);
                if (rec.size() >= 20) break;
            }
            if (!rec.isEmpty()) rows.add(new Object[]{"🕘 Vistos recentemente", rec, rec.size()});
            if ("live".equals(kind) && !data.opKey().isEmpty()) {
                List<NativeData.Item> ol = opList();
                if (!ol.isEmpty()) rows.add(new Object[]{"📺 " + data.opTitle(data.opKey()), ol.subList(0, Math.min(80, ol.size())), ol.size()});
            }
            if (!"live".equals(kind)) { try { for (NativeData.Cat g : data.genreCats(kind)) rows.add(new Object[]{g.name, g.items.subList(0, Math.min(25, g.items.size())), g.items.size(), g.items}); } catch (Throwable ignored) { } }   /* v330: filas por género no Início */
            List<NativeData.Cat> cats = data.homeCats(kind);
            if (cats != null) {
                List<NativeData.Cat> sel = new ArrayList<>();
                final boolean custom = data.customHome(kind);   /* v311: com ordem/ocultos definidos, o Início mostra todos os grupos visíveis pela ordem escolhida */
                if (custom) sel = cats;
                else {
                    for (NativeData.Cat c : cats) if (PT.matcher(c.name).find()) sel.add(c);
                    if (sel.isEmpty()) sel = cats;
                }
                int n = "live".equals(kind) ? 40 : 25;
                for (int i = 0; i < Math.min(custom ? 80 : 14, sel.size()); i++) { NativeData.Cat c = sel.get(i); rows.add(new Object[]{c.name, c.items.subList(0, Math.min(n, c.items.size())), c.items.size(), "live".equals(kind) ? null : c.items}); }
            }
            /* v286: assinatura do conteúdo: se nada mudou desde a última vez, não refaz as filas (não «recarrega» ao voltar ao Início) */
            StringBuilder sg = new StringBuilder(kind);
            for (Object[] r : rows) { sg.append('|').append(r[0]).append(':').append(r[2]); for (Object o : (List<?>) r[1]) sg.append(',').append(((NativeData.Item) o).url.hashCode()); }
            sg.append("|fav").append(data.favs().hashCode());
            final String sig = sg.toString();
            saveHomeSnap(kind, rows);
            preloadOthers();
            ui.post(() -> {
                if (seq != homeSeq || !"home".equals(section)) return;
                if (sig.equals(homeSig) && homeRows.getChildCount() > 0) { restoreHomeFocus(); return; }
                homeSig = sig;
                buildRows(rows, kind);
            });
            /* v277: pré-carrega para o disco os logótipos do Início, do operador e dos favoritos (baixa prioridade) */
            java.util.LinkedHashSet<String> pre = new java.util.LinkedHashSet<>();
            for (Object[] r : rows) for (Object o : (List<?>) r[1]) pre.add(data.logo((NativeData.Item) o));
            PiconCache.prefetch(pre);
        });
    }

    private TextView emptyMsg(String s) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(TXT); t.setAlpha(0.75f); t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(19)); t.setPadding(dp(6), dp(30), dp(6), dp(30));
        return t;
    }

    @SuppressWarnings("unchecked")
    private String homeSig = "";
    /** v294: depois do Início estar pronto, carrega por trás os filmes e as séries (e prepara a pesquisa), para abrirem logo. */
    private boolean preloadStarted = false;
    private final java.util.Set<String> openRefreshed = java.util.Collections.synchronizedSet(new java.util.HashSet<String>());
    private void preloadOthers() {
        if (preloadStarted) return;
        preloadStarted = true;
        Thread t = new Thread(() -> {
            try { Thread.sleep(2500); } catch (InterruptedException e) { return; }
            for (String k : new String[]{"movie", "series", "live"}) {
                try { long t0 = System.currentTimeMillis(); boolean had = data.cats.containsKey(k); data.load(k, false); if (data.sp().getInt("listOpen", 0) == 1 && !openRefreshed.contains(k)) { openRefreshed.add(k); data.load(k, true); } if (!had) NativeData.dbg("lista " + k + " pré-carregada em " + (System.currentTimeMillis() - t0) + " ms"); data.prepareSearch(k); warmKind(k); } catch (Throwable ignored) { }
            }
        }, "pre-listas");
        t.setPriority(Thread.MIN_PRIORITY);
        t.setDaemon(true);
        t.start();
    }
    private File snapFile(String kind) { return new File(getFilesDir(), "home_" + kind + ".json"); }
    private void saveHomeSnap(String kind, List<Object[]> rows) {
        try {
            JSONArray a = new JSONArray();
            for (Object[] r : rows) {
                JSONArray it = new JSONArray(); for (Object o : (List<?>) r[1]) it.put(((NativeData.Item) o).json());
                a.put(new JSONObject().put("t", r[0]).put("n", r[2]).put("i", it));
            }
            try (java.io.FileOutputStream o = new java.io.FileOutputStream(snapFile(kind))) { o.write(a.toString().getBytes("UTF-8")); }
        } catch (Throwable ignored) { }
    }
    private List<Object[]> loadHomeSnap(String kind) {
        try {
            File f = snapFile(kind); if (!f.exists()) return null;
            byte[] b = new byte[(int) f.length()];
            try (java.io.FileInputStream in = new java.io.FileInputStream(f)) { int o = 0, n; while (o < b.length && (n = in.read(b, o, b.length - o)) > 0) o += n; }
            JSONArray a = new JSONArray(new String(b, "UTF-8"));
            List<Object[]> rows = new ArrayList<>();
            for (int i = 0; i < a.length(); i++) {
                JSONObject r = a.getJSONObject(i); JSONArray it = r.getJSONArray("i"); List<NativeData.Item> l = new ArrayList<>();
                for (int j = 0; j < it.length(); j++) { NativeData.Item x = NativeData.Item.from(it.getJSONObject(j)); x.logoDone = true; l.add(x); }
                rows.add(new Object[]{r.optString("t"), l, r.optInt("n")});
            }
            return rows;
        } catch (Throwable e) { return null; }
    }
    private void restoreHomeFocus() {
        ui.post(() -> {
            View f = getCurrentFocus();
            if (f != null && f.isShown()) return;
            if (lastHomeFocus != null && lastHomeFocus.isAttachedToWindow() && lastHomeFocus.isShown()) lastHomeFocus.requestFocus();
            else { View k = homeKinds.getChildAt(0); if (k != null) k.requestFocus(); }
            fxSoon();
        });
    }
    private void buildRows(List<Object[]> rows, String kind) {
        boolean hadFocus = homeRows.hasFocus();
        homeRows.removeAllViews();
        lastHomeFocus = null;
        if (rows.isEmpty()) {
            String kl = "live".equals(kind) ? "canais" : "movie".equals(kind) ? "filmes" : "séries";
            homeRows.addView(emptyMsg("Sem " + kl + " carregados. Adiciona a tua lista IPTV nas Definições."));
            return;
        }
        final int gen = ++rowsGen;
        for (int ri = 0; ri < rows.size(); ri++) {
            final Object[] r = rows.get(ri);
            if (ri >= 3) { final int d = ri; ui.postDelayed(() -> { if (gen == rowsGen && "home".equals(section)) { addHomeRow(r); fxSoon(); } }, 40L * (d - 2)); continue; }
            addHomeRow(r);
        }
        homeRows.post(this::fxNow);
        ui.postDelayed(this::fxNow, 250);
        final String rk = kind;
        ui.postDelayed(() -> { if (gen == rowsGen && "home".equals(section)) restoreHomePos(rk); }, 40L * Math.max(0, rows.size() - 2) + 120);
        if (hadFocus) restoreHomeFocus();
    }
    private int rowsGen = 0;

    /* ------------------------------------------------------------ v292: posição do Início por separador (Canais / Filmes / Séries) */
    private static String rowTitle(View row) {
        try { return String.valueOf(((TextView) ((ViewGroup) ((ViewGroup) row).getChildAt(0)).getChildAt(0)).getText()); } catch (Throwable e) { return ""; }
    }
    /** Guarda o deslize do Início, o deslize de cada fila e o cartão com foco (fica guardado no aparelho). */
    private void saveHomePos() {
        try {
            if (homeRows == null || homeRows.getChildCount() == 0) return;
            JSONObject o = new JSONObject();
            o.put("y", homeScroll.getScrollY());
            JSONObject sx = new JSONObject();
            String ft = "", fu = ""; int fi = -1;
            View f = getCurrentFocus();
            for (int i = 0; i < homeRows.getChildCount(); i++) {
                View r = homeRows.getChildAt(i);
                if (!(r instanceof ViewGroup) || ((ViewGroup) r).getChildCount() < 2) continue;
                String t = rowTitle(r);
                View sc = ((ViewGroup) r).getChildAt(1);
                sx.put(t, sc.getScrollX());
                List<View> cs = cardsOf(r);
                View lf = f != null && f.isShown() ? f : lastHomeFocus;
                int ix = lf == null ? -1 : cs.indexOf(lf);
                if (ix >= 0) { ft = t; fi = ix; }
            }
            o.put("sx", sx); o.put("ft", ft); o.put("fi", fi);
            getSharedPreferences("nativeapp", 0).edit().putString("homePos_" + homeKind, o.toString()).apply();
        } catch (Throwable ignored) { }
    }
    private void restoreHomePos(String kind) {
        try {
            String raw = getSharedPreferences("nativeapp", 0).getString("homePos_" + kind, "");
            if (raw.isEmpty()) return;
            final JSONObject o = new JSONObject(raw);
            JSONObject sx = o.optJSONObject("sx");
            View target = null;
            for (int i = 0; i < homeRows.getChildCount(); i++) {
                View r = homeRows.getChildAt(i);
                if (!(r instanceof ViewGroup) || ((ViewGroup) r).getChildCount() < 2) continue;
                String t = rowTitle(r);
                final View sc = ((ViewGroup) r).getChildAt(1);
                if (sx != null && sx.has(t)) { final int x = sx.optInt(t); sc.post(() -> sc.scrollTo(x, 0)); }
                if (t.equals(o.optString("ft")) && o.optInt("fi", -1) >= 0) { List<View> cs = cardsOf(r); int fi = o.optInt("fi"); if (fi < cs.size()) target = cs.get(fi); }
            }
            final View tg = target;
            homeScroll.post(() -> {
                homeScroll.scrollTo(0, o.optInt("y"));
                View f = getCurrentFocus();
                boolean inHome = f != null && f.isShown() && (homeRows.hasFocus() || homeKinds.hasFocus() || f == heroBtn1 || f == heroBtn2);
                if (tg != null && (!inHome || homeRows.hasFocus())) { tg.requestFocus(); lastHomeFocus = tg; homeScroll.post(() -> homeScroll.scrollTo(0, o.optInt("y"))); }
                fxSoon();
            });
        } catch (Throwable ignored) { }
    }
    /** Explorar / Guia: guarda a posição da grelha na categoria aberta. */
    private void saveBrowsePos() {
        try {
            if (openSeries != null || curCat >= curCats.size() || !("live".equals(tab) || "movie".equals(tab) || "series".equals(tab))) return;
            getSharedPreferences("nativeapp", 0).edit().putInt("pos_" + tab + "_" + curCats.get(curCat).name, Math.max(0, grid.getSelectedItemPosition() >= 0 ? grid.getSelectedItemPosition() : grid.getFirstVisiblePosition())).apply();
        } catch (Throwable ignored) { }
    }
    @SuppressWarnings("unchecked")
    private void addHomeRow(Object[] r) {
        {
            final List<NativeData.Item> list = new ArrayList<>((List<NativeData.Item>) r[1]);
            /* v358: no máximo 60 cartões por fila (memória: o log mostrou OOM ao montar as filas com a lista de filmes carregada); o «+» abre o resto */
            if (list.size() > 60) list.subList(60, list.size()).clear();
            final List<NativeData.Item> full = r.length > 3 ? (List<NativeData.Item>) r[3] : null;
            final LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setClipChildren(false); row.setClipToPadding(false);
            LinearLayout head = new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
            TextView h = new TextView(this); h.setText((String) r[0]); h.setTextColor(0xFF8C9BB0); h.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(21)); h.setTypeface(null, Typeface.BOLD); h.setLetterSpacing(0.01f); h.setSingleLine(true); h.setEllipsize(TextUtils.TruncateAt.END);
            head.addView(h, new LinearLayout.LayoutParams(0, -2, 1));
            TextView cnt = new TextView(this); cnt.setText(String.valueOf(r[2])); cnt.setTextColor(0xFF8C9BB0); cnt.setAlpha(0.7f); cnt.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(13)); cnt.setTypeface(null, Typeface.BOLD);
            cnt.setBackground(pill(0x1FFFFFFF, 999)); cnt.setPadding(dp(12), dp(2), dp(12), dp(2));
            head.addView(cnt);
            LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(-1, -2); hl.setMargins(dp(4), dp(10), dp(4), dp(2));
            row.addView(head, hl);
            HorizontalScrollView sc = new HorizontalScrollView(this); sc.setHorizontalScrollBarEnabled(false); sc.setClipToPadding(false); sc.setClipChildren(false);
            sc.setOnScrollChangeListener((q0, q1, q2, q3, q4) -> { fxSoon(); stackFade(sc); });
            LinearLayout strip = new LinearLayout(this); strip.setPadding(dp(48), dp(12), dp(10), dp(26));   /* v374: margem à esquerda para o picon focado (escala) não ser cortado */ strip.setClipChildren(false); strip.setClipToPadding(false);
            sc.addView(strip);
            for (int i = 0; i < list.size(); i++) {
                final int idx = i;
                View card = homeCard(list.get(i), v -> onHomeCard(list, idx), row);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(244), -2); lp.rightMargin = dp(18);
                if (stackOn()) {   /* v348: pilha — cada cartão tapa o da frente só até 64 dp; vê-se a direita de cada um, e o focado sobe */
                    lp.rightMargin = -dp(180);
                    float z = dp(list.size() - i); card.setTag(R_Z, z); card.setTranslationZ(z);
                }
                strip.addView(card, lp);
            }
            if (full != null && full.size() > list.size()) strip.addView(moreCard(list, full, strip, row), moreLp());
            row.addView(sc, new LinearLayout.LayoutParams(-1, -2));
            row.setTag(Boolean.FALSE);   /* fila com o cartão focado? */
            row.setAlpha(0.85f); row.setScaleX(0.98f); row.setScaleY(0.98f);
            homeRows.addView(row, new LinearLayout.LayoutParams(-1, -2));
            if (!"nenhuma".equals(animPref())) for (View c : cardsOf(row)) { c.setTag(R_REV, Boolean.FALSE); c.setAlpha(0f); }
        }
    }

    /* ------------------------------------------------------------ v299: «+25» no fim das filas de filmes / séries do Início */
    private LinearLayout.LayoutParams moreLp() { LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(170), -1); lp.rightMargin = dp(18); return lp; }
    private View moreCard(final List<NativeData.Item> list, final List<NativeData.Item> full, final LinearLayout strip, final View row) {
        final LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL); c.setGravity(Gravity.CENTER);
        c.setBackground(pill(0x22FFFFFF, 18)); c.setClipToOutline(true); c.setElevation(dp(4));
        c.setTag(R_REV, Boolean.TRUE);
        final String kl = "movie".equals(homeKind) ? "filmes" : "séries";
        final TextView big = new TextView(this); big.setTextColor(ACC); big.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(40)); big.setTypeface(null, Typeface.BOLD); big.setGravity(Gravity.CENTER);
        final TextView sm = new TextView(this); sm.setTextColor(TXT); sm.setAlpha(0.8f); sm.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(15)); sm.setGravity(Gravity.CENTER); sm.setPadding(dp(8), dp(4), dp(8), 0);
        final Runnable txt = () -> { int left = full.size() - list.size(); big.setText("+" + Math.min(25, left)); sm.setText("mostrar mais " + Math.min(25, left) + " " + kl + "\n(faltam " + left + ")"); };
        txt.run();
        c.addView(big); c.addView(sm);
        GradientDrawable fr = new GradientDrawable(); fr.setCornerRadius(dp(18)); fr.setStroke(dp(3), ACC); fr.setColor(0x00000000);
        c.setFocusable(true); c.setClickable(true);
        c.setOnFocusChangeListener((v, f) -> {
            v.setForeground(f ? fr : null);
            v.animate().scaleX(f ? 1.06f : 1f).scaleY(f ? 1.06f : 1f).setDuration(120).start();
            if (f) { lastHomeFocus = v; for (int i = 0; i < homeRows.getChildCount(); i++) { View r = homeRows.getChildAt(i); r.setTag(r == row ? Boolean.TRUE : Boolean.FALSE); } rowsFx(); }
        });
        c.setOnClickListener(v -> {
            int from = list.size(), to = Math.min(full.size(), from + 25);
            if (to <= from) return;
            int at = strip.indexOfChild(c);
            View first = null;
            for (int i = from; i < to; i++) {
                list.add(full.get(i));
                final int idx = i;
                View card = homeCard(full.get(i), x -> onHomeCard(list, idx), row);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(244), -2); lp.rightMargin = dp(18);
                strip.addView(card, at++, lp);
                if (first == null) first = card;
            }
            NativeData.dbg("Início: fila alargada para " + list.size() + " " + kl);
            if (list.size() >= full.size()) {
                boolean had = c.hasFocus();
                strip.removeView(c);
                if (had && first != null) first.requestFocus();
            } else txt.run();
            final View f0 = first;
            if (f0 != null && !c.isAttachedToWindow()) f0.requestFocus();
            fxSoon(); ui.postDelayed(this::fxNow, 120);
        });
        return c;
    }

    /* ------------------------------------------------------------ transições dos cartões e efeito das filas (v275, como na app antiga) */
    private static final int R_REV = 0x7f0b0001;   /* etiqueta: cartão já revelado */
    private static final int R_Z = 0x7f0b0003;      /* etiqueta: profundidade do cartão na pilha */
    private static final int R_IMG = 0x7f0b0002;   /* etiqueta: carregador do logótipo ainda por correr */
    /** Logótipos dos cartões visíveis e dos próximos (1 ecrã à frente, para os lados e para baixo). */
    private void loadNearImgs() {
        int picLoads = 0;
        int[] hs = new int[2]; homeScroll.getLocationOnScreen(hs);
        int H = Math.max(1, homeScroll.getHeight());
        for (int i = 0; i < homeRows.getChildCount(); i++) {
            View r = homeRows.getChildAt(i);
            int[] l = new int[2]; r.getLocationOnScreen(l);
            int top = l[1] - hs[1];
            if (top + r.getHeight() < -H || top > 2 * H) continue;
            View sc = ((ViewGroup) r).getChildAt(1);
            int sx = sc.getScrollX(), w = Math.max(1, sc.getWidth());
            for (View c : cardsOf(r)) {
                Object o = c.getTag(R_IMG);
                if (!(o instanceof Runnable)) continue;
                if (c.getRight() < sx - w || c.getLeft() > sx + 5 * w) continue;   /* v383: carrega os picons com mais antecedência à direita */
                c.setTag(R_IMG, null);
                ((Runnable) o).run();
                picLoads++;
            }
        }
        if (picLoads > 0) NativeData.dbg("v384 picons pedidos: " + picLoads);
    }
    static final String[][] ANIMS = {{"suave", "Suave"}, {"cascata", "Cascata"}, {"zoom", "Zoom"}, {"livro", "Livro (3D)"}, {"nenhuma", "Sem animação"}};
    static final String[][] VFXS = {{"profundidade", "Profundidade"}, {"onda", "Onda"}, {"parallax", "Parallax"}, {"nenhuma", "Sem efeito"}};
    /* v376: na fila sobreposta os cartões não esmorecem ao deslocar (o que sai e o que entra); a animação só vale para a fila a abrir */
    private String animPref() { if (stackOn()) return "nenhuma"; return getSharedPreferences("nativeapp", 0).getString("tvAnim", "suave"); }
    private android.media.ToneGenerator tickTone;
    /** v381: som curto ao mudar de cartão na fila sobreposta (definição «Som ao deslizar»). */
    private void tickCard() {
        if (!np0().getBoolean("tvSomCartoes", true)) return;
        try { android.media.AudioManager am = (android.media.AudioManager) getSystemService(AUDIO_SERVICE); if (am != null) am.playSoundEffect(android.media.AudioManager.FX_FOCUS_NAVIGATION_RIGHT, 1f); } catch (Throwable ignored) { }   /* v382: efeito de navegação do sistema */
        try { if (tickTone == null) tickTone = new android.media.ToneGenerator(android.media.AudioManager.STREAM_MUSIC, 100); tickTone.startTone(android.media.ToneGenerator.TONE_PROP_BEEP, 60); } catch (Throwable ignored) { }
    }
    /* v377: fila sobreposta — o cartão que sai pela esquerda desvanece; os que estão na área visível (e o focado) ficam opacos e à frente */
    private long lastScrollLog = 0;
    private void stackFade(HorizontalScrollView hs) {
        if (!stackOn() || !(hs.getChildAt(0) instanceof ViewGroup)) return;
        long nowMs = System.currentTimeMillis();
        if (nowMs - lastScrollLog > 1000) { lastScrollLog = nowMs; NativeData.dbg("v384 scroll x=" + hs.getScrollX() + " max=" + Math.max(0, hs.getChildAt(0).getWidth() - hs.getWidth()) + " cartões=" + ((ViewGroup) hs.getChildAt(0)).getChildCount()); }
        int[] hx = new int[2]; hs.getLocationOnScreen(hx); int viewLeft = hx[0] + dp(190);   /* v380: a transição começa onde a fila se vê de facto, não na margem escondida */
        ViewGroup g = (ViewGroup) hs.getChildAt(0);
        for (int i = 0; i < g.getChildCount(); i++) {
            View c = g.getChildAt(i);
            int[] cx = new int[2]; c.getLocationOnScreen(cx);
            float a = Math.max(0f, Math.min(1f, (cx[0] + c.getWidth() - viewLeft) / (float) dp(70)));   /* v379: só o bordo esquerdo esmorece */
            if (c.isFocused() || a >= 1f) { c.setAlpha(1f); c.setVisibility(View.VISIBLE); }
            else if (a <= 0.02f) { c.setVisibility(View.VISIBLE); c.setAlpha(0f); }   /* v381: já saiu: invisível mas continua focável (não bloqueia o scroll) */
            else { c.setVisibility(View.VISIBLE); c.setAlpha(a); }
        }
    }
    private String vfxPref() { return getSharedPreferences("nativeapp", 0).getString("tvVfx", "profundidade"); }
    private boolean fxQueued = false;
    private void fxSoon() { if (fxQueued) return; fxQueued = true; homeScroll.postOnAnimation(() -> { fxQueued = false; fxNow(); }); }
    private List<View> cardsOf(View row) {
        List<View> out = new ArrayList<>();
        try { ViewGroup sc = (ViewGroup) ((ViewGroup) row).getChildAt(1); ViewGroup strip = (ViewGroup) sc.getChildAt(0); for (int i = 0; i < strip.getChildCount(); i++) out.add(strip.getChildAt(i)); } catch (Throwable ignored) { }
        return out;
    }
    private void fxNow() {
        if (homeRows == null || !"home".equals(section)) return;
        try { loadNearImgs(); } catch (Throwable ignored) { }
        revealCards();
        rowsFx();
    }
    /** Cartões que entram no ecrã aparecem com a animação escolhida (repete sempre que voltam a entrar). */
    private final java.util.WeakHashMap<View, android.animation.Animator> bookAnims = new java.util.WeakHashMap<>();
    private void stopBook(View c) { android.animation.Animator a = bookAnims.remove(c); if (a != null) a.cancel(); }
    private void revealCards() {
        String an = animPref();
        android.graphics.Rect vr = new android.graphics.Rect();
        boolean none = "nenhuma".equals(an);
        int batch = 0;
        for (int i = 0; i < homeRows.getChildCount(); i++) {
            for (View c : cardsOf(homeRows.getChildAt(i))) {
                Object rv = c.getTag(R_REV);
                if (none) { if (rv != null) { c.setTag(R_REV, null); stopBook(c); c.setRotationY(0f); c.animate().cancel(); if (!stackOn()) c.setAlpha(1f); c.setTranslationY(0); c.setScaleX(c.isFocused() ? 1.06f : 1f); c.setScaleY(c.isFocused() ? 1.06f : 1f); } continue; }
                boolean anyVis = c.getGlobalVisibleRect(vr);
                boolean vis = anyVis && vr.width() > c.getWidth() / 5 && vr.height() > c.getHeight() / 5;
                boolean done = Boolean.TRUE.equals(rv);
                if ("livro".equals(an)) {   /* a rotação muda a área visível: a meio da animação não se mexe, e um cartão já mostrado só se esconde quando sai de todo */
                    if (bookAnims.containsKey(c)) { if (c.isFocused()) { stopBook(c); } else continue; }
                    if (done && anyVis) continue;
                }
                if (vis && !done) {
                    c.setTag(R_REV, Boolean.TRUE);
                    if (c.isFocused()) { stopBook(c); c.setRotationY(0f); c.setAlpha(1f); continue; }
                    long delay = "suave".equals(an) ? 0 : Math.min(8, batch) * ("cascata".equals(an) ? 70L : 45L);
                    batch++;
                    c.animate().cancel();
                    if ("zoom".equals(an)) {
                        c.setTranslationY(0); c.setScaleX(0.55f); c.setScaleY(0.55f); c.setAlpha(0f);
                        c.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(delay).setDuration(550).setInterpolator(new android.view.animation.OvershootInterpolator(1.6f)).start();
                    } else if ("livro".equals(an)) {
                        /* v347: página de livro a virar em 3D, com os valores do Tesla: roda à volta da margem esquerda, de -105° (de costas) a +14°, recua a -5° e assenta.
                           A perspetiva é a de 1100 px do Tesla (a v346 usava uma câmara tão longe que o cartão só «encolhia», sem profundidade). */
                        final View cv = c;
                        stopBook(cv);
                        float dens = getResources().getDisplayMetrics().density;
                        cv.setCameraDistance(2444f * dens * dens);
                        cv.setPivotX(0f); cv.setPivotY(cv.getHeight() > 0 ? cv.getHeight() / 2f : dens * 90f);
                        cv.setTranslationY(0); cv.setScaleX(1f); cv.setScaleY(1f); cv.setRotationY(-105f); cv.setAlpha(0f);
                        android.animation.PropertyValuesHolder rk = android.animation.PropertyValuesHolder.ofKeyframe(View.ROTATION_Y,
                                android.animation.Keyframe.ofFloat(0f, -105f), android.animation.Keyframe.ofFloat(0.55f, 14f), android.animation.Keyframe.ofFloat(0.78f, -5f), android.animation.Keyframe.ofFloat(1f, 0f));
                        android.animation.PropertyValuesHolder ak = android.animation.PropertyValuesHolder.ofKeyframe(View.ALPHA,
                                android.animation.Keyframe.ofFloat(0f, 0f), android.animation.Keyframe.ofFloat(0.12f, 0f), android.animation.Keyframe.ofFloat(0.5f, 1f), android.animation.Keyframe.ofFloat(1f, 1f));
                        android.animation.ObjectAnimator ro = android.animation.ObjectAnimator.ofPropertyValuesHolder(cv, rk, ak);
                        ro.setDuration(750); ro.setStartDelay(Math.min(8, batch - 1) * 70L);
                        ro.setInterpolator(new android.view.animation.PathInterpolator(.2f, .7f, .2f, 1f));
                        /* sombra da dobra por cima do cartão (numa camada própria, para não mexer no aro de foco) */
                        final android.graphics.drawable.GradientDrawable sh = new android.graphics.drawable.GradientDrawable(android.graphics.drawable.GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xAA000000, 0x44000000, 0x11FFFFFF, 0x00000000});
                        sh.setBounds(0, 0, Math.max(1, cv.getWidth()), Math.max(1, cv.getHeight()));
                        try { cv.getOverlay().add(sh); } catch (Throwable ignored) { }
                        ro.addUpdateListener(va -> { float fr = va.getAnimatedFraction(); sh.setAlpha((int) (255 * Math.max(0f, 1f - fr * 1.25f))); });
                        ro.addListener(new android.animation.AnimatorListenerAdapter() {
                            @Override public void onAnimationEnd(android.animation.Animator x) {
                                bookAnims.remove(cv); try { cv.getOverlay().remove(sh); } catch (Throwable ignored) { }
                                cv.setRotationY(0f); cv.setAlpha(1f); cv.setPivotX(cv.getWidth() / 2f); cv.setPivotY(cv.getHeight() / 2f);
                            }
                        });
                        bookAnims.put(cv, ro);
                        ro.start();
                    } else {
                        c.setTranslationY(dp(46)); c.setScaleX(0.94f); c.setScaleY(0.94f); c.setAlpha(0f);
                        c.animate().alpha(1f).translationY(0).scaleX(1f).scaleY(1f).setStartDelay(delay).setDuration("cascata".equals(an) ? 600 : 500).setInterpolator(new android.view.animation.DecelerateInterpolator(2.2f)).start();
                    }
                } else if (!vis && done && !c.isFocused()) {
                    c.setTag(R_REV, Boolean.FALSE);
                    stopBook(c); c.animate().cancel(); c.setAlpha(0f);
                    try { c.setRotationY(0f); } catch (Throwable ignored) { }
                }
            }
        }
    }
    /** Efeito ao deslizar: as filas mudam com a distância ao centro do ecrã (profundidade, onda ou parallax). */
    private void rowsFx() {
        String vf = vfxPref();
        int[] hs = new int[2]; homeScroll.getLocationOnScreen(hs);
        float H = Math.max(1, homeScroll.getHeight());
        for (int i = 0; i < homeRows.getChildCount(); i++) {
            View r = homeRows.getChildAt(i);
            boolean foc = Boolean.TRUE.equals(r.getTag());
            float vx = 0, vy = 0, vs = 1, vo = 1;
            if (!"nenhuma".equals(vf)) {
                int[] l = new int[2]; r.getLocationOnScreen(l);
                float c = l[1] - hs[1] + r.getHeight() / 2f;
                float p = Math.max(-1f, Math.min(1f, (c - H * 0.5f) / (H * 0.55f))), ap = Math.abs(p);
                if ("profundidade".equals(vf)) { vs = 1 - ap * 0.07f; vo = 1 - ap * 0.55f; }
                else if ("onda".equals(vf)) { vx = p * (i % 2 == 1 ? 1 : -1) * dp(56); vo = 1 - ap * 0.4f; }
                else if ("parallax".equals(vf)) { float d = Math.max(0, p); vy = -p * dp(16); vs = 1 - d * 0.05f; vo = 1 - d * 0.5f; }
                if (foc) { vo = Math.max(vo, 0.9f); vs = Math.max(vs, 0.97f); }
            }
            r.setPivotX(0); r.setPivotY(r.getHeight() / 2f);
            r.setTranslationX(vx); r.setTranslationY(vy);
            float sc = vs * (foc ? 1f : 0.98f);
            r.setScaleX(sc); r.setScaleY(sc);
            r.setAlpha(vo * (foc ? 1f : 0.85f));
        }
        /* parallax: o destaque esmorece ao subir */
        View hero = homeCol.getChildCount() > 0 ? homeCol.getChildAt(0) : null;
        if (hero != null) {
            float a = 1f;
            if ("parallax".equals(vf)) a = 1f - Math.min(1f, homeScroll.getScrollY() / (float) Math.max(1, hero.getHeight())) * 0.7f;
            hero.setAlpha(a);
        }
    }

    /** Cartão do Início (thCard): arte em cima (logótipo ou capa; sem imagem, as iniciais), nome e grupo em baixo. */
    private View homeCard(final NativeData.Item it, View.OnClickListener click, final View row) {
        final boolean poster = isPoster(it);
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(pill(CARD, 18)); c.setClipToOutline(true); c.setElevation(dp(4));
        GradientDrawable fr = new GradientDrawable(); fr.setCornerRadius(dp(18)); fr.setStroke(dp(3), ACC); fr.setColor(0x00000000);
        final GradientDrawable focusRing = fr;
        FrameLayout art = new FrameLayout(this);
        art.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF1D2A47, 0xFF0D1424}));
        /* v346: lombada do livro nos posters (faixa escura à esquerda). */
        if (poster) {
            View spine = new View(this);
            spine.setBackgroundColor(0xCC0A0F1A);
            FrameLayout.LayoutParams slp = new FrameLayout.LayoutParams(dp(7), -1, Gravity.LEFT);
            art.addView(spine, slp);
            View spineHi = new View(this);
            spineHi.setBackgroundColor(0x33FFFFFF);
            FrameLayout.LayoutParams hlp = new FrameLayout.LayoutParams(dp(2), -1, Gravity.LEFT);
            hlp.leftMargin = dp(7);
            art.addView(spineHi, hlp);
        }
        TextView ini = new TextView(this);
        String nm = it.name.replaceAll("^[^\\p{L}\\p{N}]+", "");
        ini.setText(nm.length() >= 2 ? nm.substring(0, 2).toUpperCase() : nm.toUpperCase());
        ini.setTextColor(TXT); ini.setAlpha(0.45f); ini.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(34)); ini.setTypeface(null, Typeface.BOLD); ini.setLetterSpacing(0.04f);
        art.addView(ini, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        ImageView im = new ImageView(this);
        im.setScaleType(poster ? ImageView.ScaleType.CENTER_CROP : ImageView.ScaleType.FIT_CENTER);
        int pad = poster ? 0 : dp(22); im.setPadding(pad, pad, pad, pad);
        art.addView(im, new FrameLayout.LayoutParams(-1, -1));
        c.addView(art, new LinearLayout.LayoutParams(-1, dp(poster ? 360 : 137)));
        LinearLayout meta = new LinearLayout(this); meta.setOrientation(LinearLayout.VERTICAL); meta.setPadding(dp(14), dp(10), dp(14), dp(13));
        TextView n = new TextView(this);
        boolean fav = data.isFav(it.url), seen = !"live".equals(it.kind) && data.watched(it.url);
        n.setText((fav ? "★ " : "") + (seen ? "✓ " : "") + it.name); n.setTextColor(TXT); n.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(18)); n.setTypeface(null, Typeface.BOLD);
        n.setMaxLines(poster ? 2 : 1); n.setEllipsize(TextUtils.TruncateAt.END);
        TextView g = new TextView(this);
        long ps = "live".equals(it.kind) ? 0 : data.pos(it.url);
        String sub = ps > 0 ? "▶ " + (ps / 60000) + " min · " + it.group : it.group;
        if ("series".equals(it.kind) && data.lastEp(it.sid).length() > 0) sub = "▶ em curso · " + it.group;
        g.setText(sub); g.setTextColor(TXT); g.setAlpha(0.7f); g.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(14)); g.setSingleLine(true); g.setEllipsize(TextUtils.TruncateAt.END);
        meta.addView(n); LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(-1, -2); gl.topMargin = dp(3); meta.addView(g, gl);
        c.addView(meta, new LinearLayout.LayoutParams(-1, -2));
        c.setFocusable(true); c.setClickable(true);
        c.setOnClickListener(click);
        c.setOnLongClickListener(v -> { homeMenu(it); return true; });
        c.setOnFocusChangeListener((v, f) -> {
            v.setForeground(f ? focusRing : null);
            boolean book = "livro".equals(animPref());
            try {
                stopBook(v);   /* v347: o foco termina a página a virar (fica direita e visível) */
                float dens = getResources().getDisplayMetrics().density;
                v.setCameraDistance(2444f * dens * dens);
                v.setPivotX(v.getWidth() > 0 ? v.getWidth() / 2f : dens * 60f);
                v.setPivotY(v.getHeight() > 0 ? v.getHeight() / 2f : dens * 90f);
            } catch (Throwable ignored) { }
            NativeData.dbg("v384 foco " + (f ? "entra" : "sai") + " stack=" + stackOn() + " pai=" + (v.getParent() == null ? "-" : v.getParent().getClass().getSimpleName()));
            v.animate().cancel();
            /* v350: camada de hardware só durante a animação do foco (mais fluido na TV) */
            v.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            if (book) {
                v.animate().scaleX(f ? 1.08f : 1f).scaleY(f ? 1.08f : 1f).rotationY(f ? -8f : 0f).setDuration(160).withEndAction(() -> v.setLayerType(View.LAYER_TYPE_NONE, null)).start();
            } else {
                v.animate().scaleX(f ? 1.06f : 1f).scaleY(f ? 1.06f : 1f).rotationY(0f).setDuration(120).withEndAction(() -> v.setLayerType(View.LAYER_TYPE_NONE, null)).start();
            }
            v.setElevation(dp(f ? 14 : 4));
            if (stackOn()) { Object zt = v.getTag(R_Z); v.setTranslationZ(f ? dp(300) : (zt instanceof Float ? (Float) zt : 0f));
                /* v352: o picon focado fica o mais à esquerda da fila */
                if (v.getParent() instanceof View && ((View) v.getParent()).getParent() instanceof HorizontalScrollView) { final HorizontalScrollView hs = (HorizontalScrollView) ((View) v.getParent()).getParent(); v.post(() -> hs.smoothScrollTo(Math.max(0, v.getLeft() - dp(40)), 0)); v.postDelayed(() -> hs.smoothScrollTo(Math.max(0, v.getLeft() - dp(40)), 0), 120); }
                if (f) tickCard();   /* v381: som ao deslizar (definição) */
                /* v375: diagnóstico — desativa o corte em todas as vistas pai do cartão focado e regista as suas posições */
                if (f) { try { int[] xy = new int[2]; v.getLocationOnScreen(xy); StringBuilder pb = new StringBuilder("foco x=" + xy[0] + " w=" + v.getWidth());
                    android.view.ViewParent pp = v.getParent(); int lv = 0;
                    while (pp instanceof View && lv < 8) { View pv = (View) pp; if (pv instanceof android.view.ViewGroup) { ((android.view.ViewGroup) pv).setClipChildren(false); ((android.view.ViewGroup) pv).setClipToPadding(false); } int[] pxy = new int[2]; pv.getLocationOnScreen(pxy);
                        pb.append(" | ").append(pv.getClass().getSimpleName()).append(" x=").append(pxy[0]).append(" w=").append(pv.getWidth()).append(" padE=").append(pv.getPaddingLeft());
                        pp = pv.getParent(); lv++; }
                    if (v.getParent() instanceof View && ((View) v.getParent()).getParent() instanceof HorizontalScrollView) { HorizontalScrollView hsd = (HorizontalScrollView) ((View) v.getParent()).getParent(); pb.append(" | scrollX=").append(hsd.getScrollX()).append(" max=").append(Math.max(0, hsd.getChildAt(0).getWidth() - hsd.getWidth())); }
                    NativeData.dbg(pb.toString()); } catch (Throwable ignored) { } }
                if (f) v.bringToFront();
                /* v353: o focado abre para a largura total e fica à esquerda da fila; os outros voltam à pilha */
                try { LinearLayout.LayoutParams plp = (LinearLayout.LayoutParams) v.getLayoutParams(); int want = f ? dp(18) : -dp(180); if (plp.rightMargin != want) { plp.rightMargin = want; v.setLayoutParams(plp); } } catch (Throwable ignored) { }
            }
            if (f) {
                lastHomeFocus = v;
                if (v.getAlpha() < 1f) { v.animate().cancel(); v.setAlpha(1f); v.setTranslationY(0); try { v.setRotationY(book ? -8f : 0f); } catch (Throwable ignored) { } }
                for (int i = 0; i < homeRows.getChildCount(); i++) { View r = homeRows.getChildAt(i); r.setTag(r == row ? Boolean.TRUE : Boolean.FALSE); }
                rowsFx();
            }
        });
        data.logo(it);
        if (it.logo != null && it.logo.startsWith("http")) {
            Holder h = new Holder(); h.im = im; h.name = n; h.sub = g;
            final TextView fi = ini;
            final Runnable go = () -> loadImgThen(h, it.logo, () -> fi.setVisibility(im.getDrawable() != null ? View.GONE : View.VISIBLE));
            Bitmap mb = PiconCache.mem(it.logo);
            if (mb != null) { im.setImageBitmap(mb); ini.setVisibility(View.GONE); }
            else c.setTag(R_IMG, go);   /* carrega quando o cartão estiver perto do ecrã (ver loadNearImgs) */
        }
        return c;
    }

    /* ------------------------------------------------------------ destaque e pré-visualização (como na app antiga) */
    private boolean pvPref() { return getSharedPreferences("nativeapp", 0).getBoolean("tvPrev", true); }
    private boolean pvSnd() { return getSharedPreferences("nativeapp", 0).getBoolean("tvPrevSnd", false); }

    /** Destaque: o canal escolhido no Início ou o último visto («Continuar a ver»); sem nenhum, «Bem-vindo». */
    private void refreshHero() {
        if (heroTitle == null) return;
        NativeData.Item cur = heroItem;
        if (cur == null) { List<NativeData.Item> r = data.recents(); if (!r.isEmpty()) cur = r.get(0); heroItem = cur; heroList = null; }
        if (cur == null) {
            heroLabel.setText("COCKPIT TV"); heroTitle.setText("Bem-vindo"); heroSub.setText("Escolhe um canal em baixo para começar.");
            heroBtn1.setText("Explorar canais"); setPrimary(heroBtn1, kindIcons.get("Explorar canais"), true);
            heroBtn2.setText("Definições"); setPrimary(heroBtn2, kindIcons.get("Definições"), false);
            heroArt.setVisibility(View.GONE);
            return;
        }
        heroLabel.setText("CONTINUAR A VER");
        String nm = cur.name; if ("episode".equals(cur.kind) && cur.group.length() > 0) nm = cur.group + " · " + cur.name;
        heroTitle.setText(nm);
        String e = epgCache.get(cur.url);
        heroSub.setText(e != null && !e.isEmpty() ? e : cur.group);
        if ("live".equals(cur.kind) && (e == null || epgOld(cur.url))) wantEpg(cur);
        heroBtn1.setText("▶ Ver agora"); heroBtn1.setCompoundDrawables(null, null, null, null); setPrimary(heroBtn1, null, true);
        heroBtn2.setText("Explorar canais"); setPrimary(heroBtn2, kindIcons.get("Explorar canais"), false);
        heroArt.setVisibility(View.VISIBLE);
        String ini = cur.name.replaceAll("^[^\\p{L}\\p{N}]+", ""); heroArtIni.setText(ini.length() >= 2 ? ini.substring(0, 2).toUpperCase() : ini.toUpperCase());
        heroArtIni.setVisibility(View.VISIBLE); heroArtImg.setImageBitmap(null);
        data.logo(cur);
        if (cur.logo != null && cur.logo.startsWith("http")) {
            Holder h = new Holder(); h.im = heroArtImg;
            loadImgThen(h, cur.logo, () -> heroArtIni.setVisibility(heroArtImg.getDrawable() != null ? View.GONE : View.VISIBLE));
        }
        startPreview();
    }

    private void heroPrimary() {
        NativeData.Item cur = heroItem;
        if (cur == null) { tab = "live"; showSection("explore"); return; }
        if (heroList != null && heroIdx < heroList.size() && heroList.get(heroIdx).url.equals(cur.url)) { onHomeOpen(heroList, heroIdx); return; }
        List<NativeData.Item> one = new ArrayList<>(); one.add(cur);
        if ("live".equals(cur.kind)) {   /* a lista do ecrã total: a categoria do canal */
            List<NativeData.Cat> cs = data.cats.get("live");
            if (cs != null) for (NativeData.Cat c : cs) if (c.name.equals(cur.group)) { int ix = indexOf(c.items, cur.url); if (ix >= 0) { onHomeOpen(c.items, ix); return; } }
        }
        onHomeOpen(one, 0);
    }
    private void heroSecondary() {
        if (heroItem == null) showSection("settings"); else { tab = "live"; showSection("explore"); }
    }

    /** O vídeo pequeno do destaque: só canais em direto, no Início, sem som (opção), pára ao fim de 10 min. */
    private void startPreview() {
        NativeData.Item cur = heroItem;
        boolean ok = cur != null && "live".equals(cur.kind) && "home".equals(section) && details == null && pvPref() && !pvOff
                && (nscr == null || !nscr.isOpen()) && heroArt != null && heroArt.getVisibility() == View.VISIBLE && !isFinishing();
        if (!ok) { stopPreview(); return; }
        try {
            if (np == null) np = new NativePlayer(this, root, (k, m) -> playerEvent(k, m));
            applyPlayerPrefs();
            if (!cur.url.equals(pvUrl)) {
                String u = cur.url.toLowerCase();
                String hint = u.contains(".m3u8") ? "hls" : (!u.matches(".*\\.ts(\\?.*)?$") && !u.matches(".*\\.(mp4|mkv|avi|mov)(\\?.*)?$")) ? "hls" : "";
                np.play(cur.url, "", hint, "", 0);
                pvUrl = cur.url; pvT0 = System.currentTimeMillis();
            }
            np.setPreview(true);
            np.volume(pvSnd() ? 1f : 0f);
            pvLastVis = true;   /* v295: volta sempre a posicionar (a janela ficava por cima das filas, no sítio antigo) */
            placePreview();
            ui.removeCallbacks(pvLimit); ui.postDelayed(pvLimit, 10 * 60000L);
        } catch (Throwable e) { pvUrl = null; }
    }
    private final Runnable pvLimit = () -> { if (pvUrl != null && (nscr == null || !nscr.isOpen())) { stopPreview(); pvOff = true; } };
    private void stopPreview() {
        ui.removeCallbacks(pvLimit);
        if (pvUrl == null) return;
        pvUrl = null;
        try { if (np != null && (nscr == null || !nscr.isOpen())) { if (isFinishing() || !hasWindowFocus()) np.stop(); else np.stopSoon(30000); } } catch (Throwable ignored) { }
    }
    /** Põe o vídeo por cima da janela do destaque (e esconde-o se a janela sair do ecrã). */
    private void placePreview() {
        if (pvUrl == null || np == null || heroArt == null || (nscr != null && nscr.isOpen())) return;
        int[] a = new int[2], r = new int[2], n = new int[2];
        heroArt.getLocationInWindow(a); root.getLocationInWindow(r); navBar.getLocationInWindow(n);
        int x = a[0] - r[0], y = a[1] - r[1], w = heroArt.getWidth(), h = heroArt.getHeight();
        boolean vis = w > 20 && h > 20 && "home".equals(section) && details == null && heroArt.isShown() && y >= n[1] - r[1] + navBar.getHeight() - dp(2);
        if (!vis && !pvLastVis) return;   /* fora do ecrã e já escondido: não repete (enchia o diário a cada movimento) */
        pvLastVis = vis;
        if (vis) np.notePageRect(x, y, w, h);
        np.rect(x, y, w, h, vis);
    }

    /** Programa a decorrer (pedido só quando o canal é escolhido, guardado para não repetir). */
    private void wantEpg(final NativeData.Item it) {
        if (!"live".equals(it.kind) || (epgCache.containsKey(it.url) && !epgOld(it.url))) return;
        epgCache.put(it.url, ""); epgAt.put(it.url, System.currentTimeMillis());
        bg.execute(() -> {
            final String t = data.nowNext(it);
            ui.post(() -> {
                epgCache.put(it.url, t);
                if (t.isEmpty()) return;
                if ("home".equals(section) && heroTitle.getText().toString().equals(it.name)) heroSub.setText(t);
                if ("guide".equals(section)) gridAdapter.notifyDataSetChanged();
            });
        });
    }

    private void onHomeCard(List<NativeData.Item> list, int idx) {
        NativeData.Item it = list.get(idx);
        if ("live".equals(it.kind) && pvPref() && (heroItem == null || !heroItem.url.equals(it.url))) {
            /* 1.º OK num canal: passa para a pré-visualização do destaque; 2.º OK (ou «Ver agora»): ecrã total */
            heroItem = it; heroList = list; heroIdx = idx; pvOff = false;
            data.pushRecent(it);
            refreshHero();
            return;
        }
        onHomeOpen(list, idx);
    }

    private void onHomeOpen(List<NativeData.Item> list, int idx) {
        NativeData.Item it = list.get(idx);
        if ("series".equals(it.kind)) { openSeriesDetails(it); return; }
        if ("movie".equals(it.kind) || "vod".equals(it.kind)) { openMovieDetails(list, idx); return; }
        if ("episode".equals(it.kind) && it.sid.length() > 0) { playEpisode(it.sid, it.url); return; }
        play(list, idx, -1);
    }

    private void homeMenu(final NativeData.Item it) {
        final boolean on = data.isFav(it.url);
        List<String> opts = new ArrayList<>();
        opts.add(on ? "Tirar dos favoritos" : "Juntar aos favoritos");
        hideOpts(opts, it);
        final String[] arr = opts.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle(it.name).setItems(arr, (d, w) -> {
            if (doHide(arr[w], it)) return;
            data.toggleFav(it);
            Toast.makeText(this, on ? "Fora dos favoritos" : "★ Nos favoritos", Toast.LENGTH_SHORT).show();
            renderHome();
        }).show();
    }

    private void loadImgThen(final Holder h, final String url, final Runnable after) {
        h.url = url;
        Bitmap c = PiconCache.mem(url);
        if (c != null) { h.im.setImageBitmap(c); after.run(); return; }
        PiconCache.load(url, b -> { if (b != null && url.equals(h.url)) { h.im.setImageBitmap(b); after.run(); } });
    }

    private void hideKb(View v) {
        try { android.view.inputmethod.InputMethodManager m = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE); if (m != null) m.hideSoftInputFromWindow(v.getWindowToken(), 0); } catch (Throwable ignored) { }
        try { v.clearFocus(); } catch (Throwable ignored) { }
    }
    private Runnable catSelRun = () -> { };
    private final Runnable doSearch = () -> runSearch();
    private static final int REQ_VOICE_NATIVE = 4721;
    /* v366: controlo parental — PIN (guardado só como SHA-256) e palavras; desbloqueia até fechar a app */
    private boolean parUnlocked = false;
    private android.content.SharedPreferences parSp() { return getSharedPreferences("nativeapp", 0); }
    private static String parHash(String pin) {
        try { java.security.MessageDigest md = java.security.MessageDigest.getInstance("SHA-256");
            byte[] b = md.digest(("cockpit:" + pin).getBytes("UTF-8")); StringBuilder sb = new StringBuilder();
            for (byte x : b) sb.append(String.format(java.util.Locale.ROOT, "%02x", x)); return sb.toString();
        } catch (Exception e) { return ""; }
    }
    private java.util.List<String> parKeywords() {
        java.util.List<String> l = new ArrayList<>();
        for (String k : parSp().getString("parWords", "").split(",")) { String t = k.trim().toLowerCase(java.util.Locale.ROOT); if (!t.isEmpty()) l.add(t); }
        return l;
    }
    private boolean parOn() { return parSp().contains("parPin") && !parKeywords().isEmpty(); }
    private boolean parLocked(String s) {
        if (s == null || s.isEmpty() || parUnlocked || !parOn()) return false;
        String x = s.toLowerCase(java.util.Locale.ROOT);
        for (String k : parKeywords()) if (x.contains(k)) return true;
        return false;
    }
    private void parAsk(final Runnable ok) {
        final EditText et = new EditText(this);
        et.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD); et.setHint("PIN");
        new android.app.AlertDialog.Builder(this).setTitle("Conteúdo protegido").setMessage("Introduz o PIN para continuar.").setView(et)
            .setPositiveButton("OK", (dl, w) -> {
                if (parHash(et.getText().toString()).equals(parSp().getString("parPin", ""))) { parUnlocked = true; ok.run(); }
                else Toast.makeText(this, "PIN errado", Toast.LENGTH_SHORT).show();
            }).setNegativeButton("Cancelar", null).show();
    }
    private void parSetPin() {
        final EditText et = new EditText(this);
        et.setInputType(android.text.InputType.TYPE_CLASS_NUMBER | android.text.InputType.TYPE_NUMBER_VARIATION_PASSWORD); et.setHint("Novo PIN (mín. 4 dígitos)");
        new android.app.AlertDialog.Builder(this).setTitle("Definir PIN").setView(et)
            .setPositiveButton("Guardar", (dl, w) -> {
                String p = et.getText().toString();
                if (p.length() < 4) { Toast.makeText(this, "O PIN tem de ter pelo menos 4 dígitos", Toast.LENGTH_SHORT).show(); return; }
                parSp().edit().putString("parPin", parHash(p)).apply(); parUnlocked = false;
                Toast.makeText(this, "PIN guardado", Toast.LENGTH_SHORT).show();
            }).setNegativeButton("Cancelar", null).show();
    }
    /* v365: reconhecimento de voz do sistema (Google) para pesquisar canais, filmes e séries */
    private void voiceSearch() {
        try {
            Intent i = new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
            i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "pt-PT");
            i.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Diz o canal, filme ou série");
            i.putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 1);
            startActivityForResult(i, REQ_VOICE_NATIVE);
        } catch (Exception e) { Toast.makeText(this, "Esta TV não tem reconhecimento de voz instalado.", Toast.LENGTH_LONG).show(); }
    }

    private void setStatus(String s, boolean busy) { status.setText(s); spin.setVisibility(busy ? View.VISIBLE : View.GONE); }

    private boolean vodTab() { return "movie".equals(tab) || "series".equals(tab); }
    private void updateSortBtn() {
        boolean on = vodTab() && openSeries == null && catList.getVisibility() == View.VISIBLE;
        sortBtn.setVisibility(on ? View.VISIBLE : View.GONE);
        if (on) sortBtn.setText("⇅ " + NativeData.SORT_L[data.sortMode(tab)]);
    }
    private void pickSort() {
        if (!vodTab()) return;
        final String k = tab;
        new AlertDialog.Builder(this).setTitle("Ordenar").setSingleChoiceItems(NativeData.SORT_L, data.sortMode(k), (d, w) -> {
            d.dismiss();
            data.setSortMode(k, w);
            updateSortBtn();
            shownKey = "";
            pickCat(curCat, false);
            grid.setSelection(0);
        }).show();
    }

    /* ------------------------------------------------------------ separadores */
    /** v286: o tipo onde a pesquisa procura (o último escolhido: Canais, Filmes ou Séries). */
    private String searchKind = "live";
    private LinearLayout searchRow; private EditText countryBox; private Button genreBox; private String genreSel = ""; private String genreKind = "";
    private String genreText() {
        if (genreBox == null || genreBox.getVisibility() != View.VISIBLE) return "";
        return genreSel;
    }
    /** v372: lista de géneros (categorias) do tipo de pesquisa atual; escolher um filtra a pesquisa. */
    private static final String[][] GENEROS = {   /* v373: géneros comuns; cada um procura palavras-chave no nome da categoria */
            {"Todos os géneros", ""}, {"Ação", "acao|action"}, {"Comédia", "comedia|comedy"}, {"Terror", "terror|horror"}, {"Drama", "drama"},
            {"Romance", "romance|romantic"}, {"Thriller / Suspense", "thriller|suspense"}, {"Ficção científica", "ficcao|sci-fi|scifi|sci fi"},
            {"Aventura", "aventura|adventure"}, {"Animação", "animacao|animation|animad"}, {"Documentário", "documentario|documentary"},
            {"Crime", "crime"}, {"Fantasia", "fantasia|fantasy"}, {"Infantil / Família", "infantil|kids|familia|family"}, {"Guerra", "guerra|war"},
            {"Western", "western|faroeste"}, {"Musical", "musical"}};
    private void showGenrePicker() {
        final String[] arr = new String[GENEROS.length];
        for (int i = 0; i < GENEROS.length; i++) arr[i] = GENEROS[i][0];
        new AlertDialog.Builder(this).setTitle("Género").setItems(arr, (d, w) -> {
            genreSel = GENEROS[w][1];
            genreBox.setText("Género: " + (w == 0 ? "todos" : arr[w]) + " ▾");
            ui.removeCallbacks(doSearch); runSearch();
        }).show();
    }
    /** v348: código de país escrito pelo utilizador (PT, BR, EN…); vazio = todos. GB passa a UK, como na lista. */
    private String countryCode() {
        if (countryBox == null || countryBox.getVisibility() != View.VISIBLE) return "";
        String c = countryBox.getText().toString().replaceAll("[^A-Za-z]", "").toUpperCase(java.util.Locale.ROOT);
        return "GB".equals(c) ? "UK" : c;
    }
    private boolean stackOn() { return getSharedPreferences("nativeapp", 0).getBoolean("tvStack", false); }
    private void showTab(String id) {
        closeDetails();
        if ("live".equals(id) || "movie".equals(id) || "series".equals(id)) searchKind = id;
        if (!"settings".equals(id)) browseTab = id;
        if (!"settings".equals(id) && ("home".equals(section) || "settings".equals(section))) {
            section = "explore";
            stopPreview();
            for (java.util.Map.Entry<String, View> e : navTabs.entrySet()) styleTab(e.getValue(), e.getKey());
            homeScroll.setVisibility(View.GONE); browseCol.setVisibility(View.VISIBLE); chipsRow.setVisibility(View.VISIBLE);
        }
        statusRow.setVisibility("settings".equals(id) ? View.GONE : View.VISIBLE);
        tab = id;
        openSeries = null;
        loadSeq++;
        getSharedPreferences("nativeapp", 0).edit().putString("tab", id).apply();
        markTabs();
        if (settingsView != null) { body.removeView(settingsView); settingsView = null; }
        catList.setVisibility(View.VISIBLE); grid.setVisibility(View.VISIBLE);
        searchRow.setVisibility(View.GONE);
        curCats = new ArrayList<>(); curItems = new ArrayList<>(); shownKey = "";
        catAdapter.notifyDataSetChanged(); gridAdapter.notifyDataSetChanged();
        switch (id) {
            case "live": case "movie": case "series": loadKind(id, false); break;
            case "fav": case "recent": showFlat(id); break;
            case "search":
                catList.setVisibility(View.GONE);
                searchRow.setVisibility(View.VISIBLE);
                countryBox.setVisibility("movie".equals(searchKind) || "series".equals(searchKind) ? View.VISIBLE : View.GONE);
                genreBox.setVisibility("movie".equals(searchKind) || "series".equals(searchKind) ? View.VISIBLE : View.GONE);
                if (!searchKind.equals(genreKind)) { genreKind = searchKind; genreSel = ""; genreBox.setText("Género: todos ▾"); }
                searchBox.setHint("movie".equals(searchKind) ? "Nome do filme…" : "series".equals(searchKind) ? "Nome da série…" : "Nome do canal…");
                searchBox.requestFocus();
                final String sk = searchKind;
                setStatus("A preparar…", true);
                bg.execute(() -> { try { data.load(sk, false); data.prepareSearch(sk); } catch (Throwable ignored) { } ui.post(() -> { if ("search".equals(tab)) { setStatus("", false); runSearch(); } }); });
                break;
            case "settings": showSettings(); break;
        }
        updateSortBtn();
    }

    /* lista do operador (calculada uma vez por lista carregada) */
    private List<NativeData.Item> opCache = null;
    private String opCacheKey = "";
    private List<NativeData.Item> opList() {
        String k = data.opKey();
        List<NativeData.Item> live = data.all.get("live");
        String ck = k + "|" + (live == null ? 0 : live.size()) + "|" + data.opCustom().hashCode();
        if (opCache == null || !ck.equals(opCacheKey)) {
            List<NativeData.Item> l = k.isEmpty() ? new ArrayList<>() : data.opChannels(k), v = new ArrayList<>();
            for (NativeData.Item x : l) if (!data.hiddenItem(x)) v.add(x);
            opCache = v; opCacheKey = ck;
        }
        return opCache;
    }

    /** Categorias do tipo, com «Continuar a ver» e «Adicionados recentemente» no topo (filmes e séries). */
    private final java.util.Map<String, Object[]> newCache = new java.util.concurrent.ConcurrentHashMap<>();
    /** v308: prepara por trás o que o separador precisa (recentes + categoria guardada já ordenada). */
    void warmKind(String kind) {
        try {
            if ("live".equals(kind) || data.all.get(kind) == null) return;
            withVirtual(kind);
            String nm = getSharedPreferences("nativeapp", 0).getString("catn_" + kind, "");
            List<NativeData.Cat> bc = data.visibleCats(kind);
            int sm = data.sortMode(kind);
            if (bc != null && sm > 0) for (NativeData.Cat c : bc) if (c.name.equals(nm)) { NativeData.sorted(c.items, sm); break; }
        } catch (Throwable ignored) { }
    }
    private List<NativeData.Cat> withVirtual(String kind) {
        List<NativeData.Cat> out = new ArrayList<>();
        List<NativeData.Cat> base = data.visibleCats(kind);
        if ("live".equals(kind) && !data.opKey().isEmpty()) {   /* operador escolhido: os canais pela ordem da grelha, no topo */
            List<NativeData.Item> ol = opList();
            if (!ol.isEmpty()) { NativeData.Cat c = new NativeData.Cat(); c.id = "__op"; c.name = "📺 " + data.opTitle(data.opKey()); c.items.addAll(ol); out.add(c); }
        }
        if (!"live".equals(kind)) {
            List<NativeData.Item> cont = "movie".equals(kind) ? data.continueMovies() : data.continueSeries();
            if (!cont.isEmpty()) { NativeData.Cat c = new NativeData.Cat(); c.id = "__cont"; c.name = "▶ Continuar a ver"; c.items.addAll(cont); out.add(c); }
            List<NativeData.Item> allk = data.all.get(kind);
            if (allk != null) {
                /* v308: «Adicionados recentemente» calculado uma vez por lista (antes ordenava os ~250 mil filmes sempre que se abria o separador) */
                Object[] ce = newCache.get(kind);
                NativeData.Cat c;
                if (ce != null && ce[0] == allk) c = (NativeData.Cat) ce[1];
                else {
                    boolean has = false;
                    for (NativeData.Item x : allk) if (x.added > 0) { has = true; break; }
                    c = null;
                    if (has) {
                        List<NativeData.Item> s = NativeData.sorted(allk, 2);
                        c = new NativeData.Cat(); c.id = "__new"; c.name = "🆕 Adicionados recentemente"; c.items.addAll(s.subList(0, Math.min(200, s.size())));
                    }
                    newCache.put(kind, new Object[]{allk, c});
                }
                if (c != null) out.add(c);
            }
        }
        if (!"live".equals(kind)) out.addAll(data.genreCats(kind));   /* v330: géneros (Ação, Comédia, Terror, Drama…) antes das categorias do fornecedor */
        if (base != null) out.addAll(base);
        return out;
    }

    private int savedCatIndex(String kind) {
        String name = getSharedPreferences("nativeapp", 0).getString("catn_" + kind, "");
        for (int i = 0; i < curCats.size(); i++) if (curCats.get(i).name.equals(name)) return i;
        return "live".equals(kind) ? 0 : Math.min(curCats.size() - 1, 0);
    }

    private void loadKind(final String kind, final boolean force) {
        if (!data.configured()) { setStatus("Sem lista configurada — abre ⚙️ Definições.", false); return; }
        final int seq = ++loadSeq;
        if (!force) setStatus("A carregar…", true);
        final long t0 = System.currentTimeMillis();
        bg.execute(() -> {
            String err = null;
            List<NativeData.Cat> vc = null;
            try { data.load(kind, force); vc = withVirtual(kind); } catch (Throwable e) { err = e.getMessage() == null ? String.valueOf(e) : e.getMessage(); }
            final String fe = err; final List<NativeData.Cat> fvc = vc;
            final long ms = System.currentTimeMillis() - t0;
            ui.post(() -> {
                if (seq != loadSeq || !kind.equals(tab) || openSeries != null) return;
                if (fe != null) { if (!force) setStatus("Erro: " + fe, false); return; }
                /* v280: categorias calculadas fora do ecrã; na renovação por trás mantém a categoria e o sítio onde estás */
                String keepName = force && curCat < curCats.size() ? curCats.get(curCat).name : null;
                int keepPos = grid.getFirstVisiblePosition();
                boolean gridFocus = grid.hasFocus();
                curCats = fvc;
                catAdapter.notifyDataSetChanged();
                shownKey = "";
                int ci = -1;
                if (keepName != null) for (int i = 0; i < curCats.size(); i++) if (curCats.get(i).name.equals(keepName)) { ci = i; break; }
                if (ci >= 0) { pickCat(ci, false); grid.setSelection(keepPos); if (gridFocus) grid.requestFocus(); }
                else { ci = Math.max(0, savedCatIndex(kind)); pickCat(ci, false); catList.setSelection(curCat); }
                int n = 0; List<NativeData.Item> al = data.all.get(kind); if (al != null) n = al.size();
                setStatus(n + (kind.equals("live") ? " canais" : kind.equals("movie") ? " filmes" : " séries") + "   ·   OK longo / Menu: opções", false);
                try { if (np != null) np.log("lista " + kind + ": " + n + " itens em " + ms + " ms" + (force ? " (renovada)" : "")); } catch (Throwable ignored) { }
                updateSortBtn();
                int lo = data.sp().getInt("listOpen", 0); if (!force && lo != 2 && (lo == 1 || !data.cacheFresh(kind)) && !refreshTried.contains(kind)) { refreshTried.add(kind); loadKind(kind, true); }   /* lista guardada antiga: mostra-a e renova por trás (uma vez) */
            });
        });
    }
    private final java.util.Set<String> refreshTried = new java.util.HashSet<>();

    /* v357: guia — pede o programa a dar dos primeiros canais em lote, com «X de Y canais» */
    private void refreshGuideNow() {
        epgCache.clear(); epgAt.clear();
        final java.util.List<NativeData.Item> chans = new java.util.ArrayList<>();
        try { List<NativeData.Item> l = data.all.get("live"); if (l != null) for (NativeData.Item it : l) { if (chans.size() >= 300) break; if (!it.url.isEmpty()) chans.add(it); } } catch (Throwable ignored) { }
        if (chans.isEmpty()) { updEnd("Sem canais para atualizar o guia."); return; }
        updStart("A atualizar o guia: 0 de " + chans.size() + " canais");
        updRunning = false; ui.removeCallbacks(updTick);   /* o guia atualiza o próprio texto; sem o contador de transferência */
        bg.execute(() -> {
            int n = 0;
            for (NativeData.Item it : chans) {
                String t = ""; try { t = data.nowNext(it); } catch (Throwable ignored) { }
                final String ft = t; final String u = it.url;
                ui.post(() -> { epgCache.put(u, ft); epgAt.put(u, System.currentTimeMillis()); });
                n++; final int fn = n;
                ui.post(() -> { if (updLbl != null) updLbl.setText("A atualizar o guia: " + fn + " de " + chans.size() + " canais"); if (updBar != null) { updBar.setIndeterminate(false); updBar.setMax(chans.size()); updBar.setProgress(fn); } });
            }
            final int total = n;
            ui.post(() -> updEnd("Guia atualizado: " + total + " canais (até 300)."));
        });
    }
    /** v312: renova já a lista do tipo (descarrega de novo) e refaz o Início/Explorar se estiver aberto. */
    /* v357: barra de progresso das atualizações — só nas Definições */
    private android.widget.ProgressBar updBar; private TextView updLbl; private boolean updRunning = false;
    private final Runnable updTick = new Runnable() { @Override public void run() {
        try {
            if (updBar == null || updLbl == null) return;
            if (updRunning) {
                long tot = NativeData.dlTotal, done = NativeData.dlDone;
                if (tot > 0) { updBar.setIndeterminate(false); updBar.setMax(100); updBar.setProgress((int) Math.min(100, done * 100 / tot)); updLbl.setText("A transferir " + NativeData.dlLabel + ": " + (done / 1024) + " / " + (tot / 1024) + " KB"); }
                else { updBar.setIndeterminate(true); updLbl.setText(NativeData.dlLabel.isEmpty() ? "A atualizar…" : "A transferir " + NativeData.dlLabel + ": " + (done / 1024) + " KB"); }
                ui.postDelayed(this, 300);
            }
        } catch (Throwable ignored) { }
    } };
    private void updStart(String msg) {
        updRunning = true; NativeData.dlLabel = ""; NativeData.dlDone = 0; NativeData.dlTotal = -1;
        if (updBar != null) { updBar.setVisibility(View.VISIBLE); updBar.setIndeterminate(true); }
        if (updLbl != null) { updLbl.setVisibility(View.VISIBLE); updLbl.setText(msg); }
        ui.removeCallbacks(updTick); ui.postDelayed(updTick, 200);
    }
    private void updEnd(String msg) {
        updRunning = false; ui.removeCallbacks(updTick);
        if (updBar != null) { updBar.setIndeterminate(false); updBar.setProgress(100); }
        if (updLbl != null) updLbl.setText(msg);
    }
    private void refreshKindNow(final String kind) {
        if (!data.configured()) { Toast.makeText(this, "Sem lista configurada.", Toast.LENGTH_SHORT).show(); return; }
        Toast.makeText(this, "A atualizar " + ("live".equals(kind) ? "canais" : "movie".equals(kind) ? "filmes" : "séries") + "…", Toast.LENGTH_SHORT).show();
        updStart("A atualizar " + ("live".equals(kind) ? "canais" : "movie".equals(kind) ? "filmes" : "séries") + "…");
        bg.execute(() -> {
            String err = null;
            try { data.load(kind, true); } catch (Throwable e) { err = String.valueOf(e.getMessage()); }
            final String fe = err;
            ui.post(() -> {
                updEnd(fe == null ? "Lista atualizada" : "Erro: " + fe);
                Toast.makeText(this, fe == null ? "Lista atualizada" : "Erro: " + fe, Toast.LENGTH_SHORT).show();
                opCache = null; homeSig = ""; if ("home".equals(section)) renderHome();
            });
        });
    }
    /** v312: com a app aberta, de 10 em 10 min vê se alguma lista passou o intervalo e renova-a por trás. */
    private final Runnable listTick = new Runnable() { @Override public void run() {
        try {
            if (data.configured() && data.sp().getBoolean("listBg", true) && data.sp().getInt("listTtlH", 12) > 0 && (nscr == null || !nscr.isOpen())) {
                for (final String k : new String[]{"live", "movie", "series"}) {
                    if (data.cats.containsKey(k) && !data.cacheFresh(k)) { bg.execute(() -> { try { data.load(k, true); ui.post(() -> { opCache = null; if ("home".equals(section) && k.equals(homeKind)) { homeSig = ""; renderHome(); } }); } catch (Throwable ignored) { } }); break; }
                }
            }
        } catch (Throwable ignored) { }
        ui.postDelayed(this, 10 * 60 * 1000L);
    } };

    /** Depois de ver algo: atualiza «Continuar a ver» mantendo a categoria aberta. */
    private void refreshCats() {
        if (!vodTab() || openSeries != null || data.cats.get(tab) == null) return;
        String name = curCat < curCats.size() ? curCats.get(curCat).name : "";
        int keep = grid.getFirstVisiblePosition();
        curCats = withVirtual(tab);
        catAdapter.notifyDataSetChanged();
        int ci = 0; for (int i = 0; i < curCats.size(); i++) if (curCats.get(i).name.equals(name)) { ci = i; break; }
        shownKey = "";
        pickCat(ci, false);
        grid.setSelection(keep);
    }

    private void ensureAllLoaded(final Runnable after) {
        if (!data.configured()) return;
        setStatus("A preparar…", true);
        final int seq = loadSeq;
        bg.execute(() -> {
            for (String k : new String[]{"live", "movie", "series"}) { try { data.load(k, false); } catch (Throwable ignored) { } }
            ui.post(() -> { if (seq == loadSeq) setStatus("", false); after.run(); });
        });
    }

    private void showFlat(final String id) {
        catList.setVisibility(View.GONE);
        if ("recent".equals(id)) {
            curItems = data.recents();
            gridAdapter.notifyDataSetChanged(); setColumns(); grid.setSelection(0);
            setStatus(curItems.isEmpty() ? "Ainda não viste nada." : curItems.size() + " vistos recentemente", false);
            return;
        }
        ensureAllLoaded(() -> {
            if (!"fav".equals(tab)) return;
            curItems = data.favItems();
            gridAdapter.notifyDataSetChanged(); setColumns(); grid.setSelection(0);
            setStatus(curItems.isEmpty() ? "Sem favoritos. Mantém OK (ou Menu) num canal, filme ou série para o marcar." : curItems.size() + " favoritos", false);
        });
    }

    private int searchSeq = 0;
    private void runSearch() {
        if ("guide".equals(section) && "live".equals(tab)) {   /* v281: pesquisa no Guia: só canais, com o programa a dar */
            String q = searchBox.getText().toString().trim();
            if (q.length() < 2) { shownKey = ""; pickCat(curCat, false); setStatus("Guia: escreve o nome do canal para o procurar.", false); return; }
            final int my = ++searchSeq; final String fq = q;
            bg.execute(() -> {
                final List<NativeData.Item> r = data.search(fq, "live");
                ui.post(() -> {
                    if (my != searchSeq || !"guide".equals(section)) return;
                    curItems = r; shownKey = "guide-search";
                    gridAdapter.notifyDataSetChanged(); setColumns(); grid.setSelection(0);
                    setStatus(r.size() + " canais", false);
                });
            });
            return;
        }
        if (!"search".equals(tab)) return;
        final String q = searchBox.getText().toString();
        final String sk = searchKind;
        final String kl = "movie".equals(sk) ? "filmes" : "series".equals(sk) ? "séries" : "canais";
        if (q.trim().length() < 2 && genreText().length() < 2) { curItems = new ArrayList<>(); gridAdapter.notifyDataSetChanged(); setStatus("Pesquisar em " + kl + ": escreve pelo menos 2 letras.", false); return; }
        final int my = ++searchSeq;
        final String ccode = "live".equals(sk) ? "" : countryCode();
        final String gen = "live".equals(sk) ? "" : genreText();
        setStatus("A pesquisar…", true);
        /* v287: a pesquisa corre fora do ecrã (antes, em séries/filmes na TV, prendia o ecrã e o Android fechava a app) */
        bg.execute(() -> {
            List<NativeData.Item> r;
            try { data.load(sk, false); long t0 = System.nanoTime(); r = data.search(q, sk, ccode, gen); long ms = (System.nanoTime() - t0) / 1000000L; Runtime rt = Runtime.getRuntime(); NativeData.dbg("pesquisa «" + q + "» (" + sk + (ccode.isEmpty() ? "" : ", país " + ccode) + (gen.isEmpty() ? "" : ", género " + gen) + "): " + ms + " ms, " + r.size() + " resultados, memória " + ((rt.totalMemory() - rt.freeMemory()) / (1024 * 1024)) + " MB"); } catch (Throwable e) { r = new ArrayList<>(); NativeData.dbg("pesquisa: " + e); }
            final List<NativeData.Item> fr = r;
            ui.post(() -> {
                if (my != searchSeq || !"search".equals(tab)) return;
                curItems = fr; gridAdapter.notifyDataSetChanged(); setColumns(); grid.setSelection(0);
                setStatus(fr.size() + (fr.size() >= 300 ? "+" : "") + " " + kl + " encontrados", false);
            });
        });
    }

    private void pickCat(int pos, boolean focusGrid) {
        if (pos < 0 || pos >= curCats.size()) return;
        if (parLocked(curCats.get(pos).name)) { parAsk(() -> pickCat(pos, focusGrid)); return; }   /* v366 */
        NativeData.Cat c = curCats.get(pos);
        boolean virt = c.id.startsWith("__");
        int sm = openSeries == null && vodTab() && !virt ? data.sortMode(tab) : 0;
        String key = tab + "|" + (openSeries == null ? "" : openSeries.sid) + "|" + c.id + "|" + c.name + "|" + sm;
        if (!key.equals(shownKey)) {
            if (!shownKey.isEmpty() && !"guide-search".equals(shownKey)) saveBrowsePos();
            shownKey = key;
            curCat = pos;
            curItems = NativeData.sorted(c.items, sm);
            gridAdapter.notifyDataSetChanged(); setColumns();
            /* v281: sem pré-carregamento no Explorar: só os picons das listas do Início (e os que aparecem no ecrã) */
            grid.setSelection(openSeries == null ? getSharedPreferences("nativeapp", 0).getInt("pos_" + tab + "_" + c.name, 0) : 0);
            if (openSeries == null) getSharedPreferences("nativeapp", 0).edit().putString("catn_" + tab, c.name).apply();
        }
        curCat = pos;
        catAdapter.notifyDataSetChanged();
        if (focusGrid) grid.requestFocus();
    }

    private void setColumns() {
        boolean poster = !curItems.isEmpty() ? isPoster(curItems.get(0)) : vodTab();
        grid.setColumnWidth(dp(poster ? 150 : 300));
        grid.setNumColumns(GridView.AUTO_FIT);
    }

    /* ------------------------------------------------------------ adaptadores */
    private final BaseAdapter catAdapter = new BaseAdapter() {
        @Override public int getCount() { return curCats.size(); }
        @Override public Object getItem(int i) { return curCats.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public View getView(int i, View v, ViewGroup p) {
            TextView t = (TextView) v;
            if (t == null) {
                t = new TextView(NativeHomeActivity.this);
                t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(16)); t.setPadding(dp(14), dp(12), dp(10), dp(12));
                t.setSingleLine(true); t.setEllipsize(TextUtils.TruncateAt.END);
            }
            NativeData.Cat c = curCats.get(i);
            t.setText(c.name + "  ·  " + c.items.size());
            t.setTextColor(i == curCat ? ACC : TXT);
            t.setTypeface(null, i == curCat ? Typeface.BOLD : Typeface.NORMAL);
            return t;
        }
    };

    private static final class Holder { ImageView im; TextView name, sub; View bar; String url; boolean poster; }

    private final BaseAdapter gridAdapter = new BaseAdapter() {
        @Override public int getCount() { return curItems.size(); }
        @Override public Object getItem(int i) { return curItems.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public int getItemViewType(int i) { return isPoster(curItems.get(i)) ? 1 : 0; }
        @Override public View getView(int i, View v, ViewGroup p) {
            NativeData.Item it = curItems.get(i);
            boolean poster = isPoster(it);
            Holder h = v == null ? null : (Holder) v.getTag();
            if (h == null || h.poster != poster) { v = poster ? makePoster() : makeRow(); h = (Holder) v.getTag(); }
            boolean fav = data.isFav(it.url);
            boolean seen = !"live".equals(it.kind) && data.watched(it.url);
            h.name.setText((fav ? "★ " : "") + (seen ? "✓ " : "") + it.name);
            long ps = "live".equals(it.kind) ? 0 : data.pos(it.url);
            String s;
            if (poster) {
                s = it.year.length() > 0 ? it.year : "";
                if (it.rating.length() > 0 && !"0".equals(it.rating)) s += (s.isEmpty() ? "" : " · ") + "★ " + it.rating;
                if ("series".equals(it.kind)) { String le = data.lastEp(it.sid); if (le.length() > 0) s = "▶ em curso" + (s.isEmpty() ? "" : " · " + s); }
                if (ps > 0) s = "▶ " + (ps / 60000) + " min" + (s.isEmpty() ? "" : " · " + s);
            } else {
                if ("episode".equals(it.kind)) s = ps > 0 ? "▶ continuar aos " + (ps / 60000) + " min" : seen ? "visto" : ((it.rating.length() > 0 ? it.rating + "  ·  " : "") + it.plot);
                else if ("guide".equals(section) && "live".equals(it.kind)) { String e = epgCache.get(it.url); s = e == null || e.isEmpty() ? (e == null ? "…" : "Sem programa") : e; if (e == null) wantEpg(it); }
                else s = "search".equals(tab) || "fav".equals(tab) || "recent".equals(tab) ? kindLabel(it) + it.group : (it.num > 0 ? "#" + it.num : "");
            }
            h.sub.setText(s); h.sub.setVisibility(s.isEmpty() ? View.GONE : View.VISIBLE);
            h.sub.setTextColor(seen ? OK : MUT);
            loadImg(h, data.logo(it));
            return v;
        }
    };

    private boolean isPoster(NativeData.Item it) { return "movie".equals(it.kind) || "series".equals(it.kind) || "vod".equals(it.kind); }
    private String kindLabel(NativeData.Item it) { return "live".equals(it.kind) ? "📺 " : "episode".equals(it.kind) || "series".equals(it.kind) ? "🎞️ " : "🎬 "; }

    private View makeRow() {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(10), dp(8), dp(10), dp(8));
        r.setBackground(roundRect(CARD, 18));
        Holder h = new Holder();
        h.im = new ImageView(this); h.im.setScaleType(ImageView.ScaleType.FIT_CENTER);
        r.addView(h.im, new LinearLayout.LayoutParams(dp(64), dp(40)));
        LinearLayout tx = new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.setPadding(dp(12), 0, 0, 0);
        h.name = new TextView(this); h.name.setTextColor(TXT); h.name.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(15)); h.name.setSingleLine(true); h.name.setEllipsize(TextUtils.TruncateAt.END);
        h.sub = new TextView(this); h.sub.setTextColor(MUT); h.sub.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(12)); h.sub.setSingleLine(true); h.sub.setEllipsize(TextUtils.TruncateAt.END);
        tx.addView(h.name); tx.addView(h.sub);
        r.addView(tx, new LinearLayout.LayoutParams(0, -2, 1));
        r.setTag(h);
        return r;
    }

    private View makePoster() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(4), dp(4), dp(4), dp(6));
        Holder h = new Holder(); h.poster = true;
        h.im = new ImageView(this); h.im.setScaleType(ImageView.ScaleType.CENTER_CROP);
        h.im.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF1D2A47, 0xFF0D1424})); h.im.setClipToOutline(true);
        h.im.setOutlineProvider(new android.view.ViewOutlineProvider() { @Override public void getOutline(View v, android.graphics.Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(18)); } });
        r.addView(h.im, new LinearLayout.LayoutParams(-1, dp(220)));
        h.name = new TextView(this); h.name.setTextColor(TXT); h.name.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(13)); h.name.setMaxLines(2); h.name.setEllipsize(TextUtils.TruncateAt.END);
        h.name.setPadding(dp(2), dp(5), dp(2), 0);
        h.sub = new TextView(this); h.sub.setTextColor(MUT); h.sub.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(11.5f)); h.sub.setSingleLine(true); h.sub.setPadding(dp(2), 0, dp(2), 0);
        r.addView(h.name); r.addView(h.sub);
        r.setTag(h);
        return r;
    }

    private void loadImg(final Holder h, final String url) {
        h.url = url;
        if (url == null || url.isEmpty() || !url.startsWith("http")) { h.im.setImageBitmap(null); return; }
        Bitmap c = bmp.get(url);
        if (c != null) { h.im.setImageBitmap(c); return; }
        h.im.setImageBitmap(null);
        if (PiconCache.knownBad(url)) return;
        Bitmap m = PiconCache.mem(url);
        if (m != null) { h.im.setImageBitmap(m); return; }
        PiconCache.load(url, b -> { if (url.equals(h.url) && b != null) h.im.setImageBitmap(b); });   /* v277: os visíveis primeiro, memória partilhada */
    }

    /** Imagem grande (fundo da ficha): descarregada com a resolução certa para o ecrã. */
    private void loadBig(final ImageView v, final String url, final int maxW) {
        if (url == null || !url.startsWith("http")) return;
        final String key = "big:" + url;
        Bitmap c = bmp.get(key);
        if (c != null) { v.setImageBitmap(c); return; }
        img.execute(() -> {
            Bitmap b = null;
            HttpURLConnection h = null;
            try {
                h = (HttpURLConnection) new URL(url).openConnection();
                h.setConnectTimeout(5000); h.setReadTimeout(8000); h.setInstanceFollowRedirects(true);
                h.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) CockpitTV");
                InputStream in = h.getInputStream();
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); byte[] buf = new byte[16384]; int n;
                while ((n = in.read(buf)) > 0) { bo.write(buf, 0, n); if (bo.size() > 8 * 1024 * 1024) break; }
                in.close();
                byte[] d = bo.toByteArray();
                BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(d, 0, d.length, o);
                int ss = 1; while (o.outWidth / (ss * 2) >= maxW) ss *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options(); o2.inSampleSize = ss;
                b = BitmapFactory.decodeByteArray(d, 0, d.length, o2);
            } catch (Throwable ignored) { } finally { if (h != null) try { h.disconnect(); } catch (Throwable ignored) { } }
            final Bitmap fb = b;
            if (fb != null) bmp.put(key, fb);
            ui.post(() -> { if (fb != null) v.setImageBitmap(fb); });
        });
    }

    /* ------------------------------------------------------------ ações nos itens */
    private void onItem(int pos) {
        if (pos < 0 || pos >= curItems.size()) return;
        NativeData.Item it = curItems.get(pos);
        if (openSeries == null && vodTab() || "live".equals(tab)) {
            if (openSeries == null && curCat < curCats.size()) getSharedPreferences("nativeapp", 0).edit().putInt("pos_" + tab + "_" + curCats.get(curCat).name, pos).apply();
        }
        if ("series".equals(it.kind)) { openSeriesDetails(it); return; }
        if ("movie".equals(it.kind) || "vod".equals(it.kind)) { openMovieDetails(curItems, pos); return; }
        if ("episode".equals(it.kind)) {
            if (openSeries != null) { int i = indexOf(seriesEps, it.url); if (i >= 0) { play(seriesEps, i, -1); return; } }
            if (it.sid.length() > 0) { playEpisode(it.sid, it.url); return; }
        }
        play(curItems, pos, -1);
    }

    private static int indexOf(List<NativeData.Item> l, String url) { for (int i = 0; i < l.size(); i++) if (l.get(i).url.equals(url)) return i; return -1; }

    /** Categoria: subir, descer, para o topo ou ocultar (como «Organizar» na app antiga). */
    private void catMenu(final int pos) {
        if (pos < 0 || pos >= curCats.size() || openSeries != null) return;
        final NativeData.Cat c = curCats.get(pos);
        if (c.id.startsWith("__") || !("live".equals(tab) || "movie".equals(tab) || "series".equals(tab))) return;
        final String k = tab;
        final String[] o = {"🚫 Ocultar esta categoria", "🚫 Ocultar todas as categorias", "👁 Mostrar todas as categorias"};
        new AlertDialog.Builder(this).setTitle(c.name + "  (a ordem define-se em Definições › Início)").setItems(o, (d, w) -> {
            String keep = c.name;
            if (w == 0) { data.hideCat(k, c.name); keep = ""; Toast.makeText(this, "Categoria oculta (repor em Definições › Início e canais)", Toast.LENGTH_LONG).show(); }
            else if (w == 1) { data.hideAllGroups(k); keep = ""; Toast.makeText(this, "Todas as categorias ocultas (mostra-as em Definições › Início e canais)", Toast.LENGTH_LONG).show(); }
            else { data.showAllGroups(k); Toast.makeText(this, "Todas as categorias visíveis", Toast.LENGTH_SHORT).show(); }
            afterCatChange(k, keep, pos);
        }).show();
    }
    /** v314: depois de mudar categorias, volta a mostrar a lista ficando na mesma posição (ou na categoria movida); nunca salta para a primeira. */
    private void afterCatChange(String k, String keepName, int oldPos) {
        curCats = withVirtual(k); shownKey = ""; catAdapter.notifyDataSetChanged();
        int ni = -1;
        if (keepName != null && !keepName.isEmpty()) for (int i = 0; i < curCats.size(); i++) if (curCats.get(i).name.equals(keepName)) { ni = i; break; }
        if (ni < 0) ni = Math.max(0, Math.min(oldPos, curCats.size() - 1));
        if (!curCats.isEmpty()) { pickCat(ni, false); catList.setSelection(ni); catList.requestFocus(); } else { curItems = new ArrayList<>(); gridAdapter.notifyDataSetChanged(); }
        opCache = null;
    }
    /** Ocultar um canal/filme/série ou a sua categoria (Explorar e Início). */
    private void hideOpts(List<String> opts, NativeData.Item it) {
        opts.add("🚫 Ocultar " + ("live".equals(it.kind) ? "este canal" : "series".equals(it.kind) ? "esta série" : "episode".equals(it.kind) ? "este episódio" : "este filme"));
        if (it.group.length() > 0 && !"episode".equals(it.kind)) opts.add("🚫 Ocultar a categoria «" + it.group + "»");
    }
    private boolean doHide(String o, NativeData.Item it) {
        if (!o.startsWith("🚫")) return false;
        if (o.contains("categoria")) data.hideCat("episode".equals(it.kind) ? "series" : it.kind, it.group); else data.hideItem(it.url);
        opCache = null;
        Toast.makeText(this, "Oculto. Para repor: Definições › Início e canais › Ocultos.", Toast.LENGTH_LONG).show();
        if ("home".equals(section)) renderHome(); else if ("search".equals(tab)) runSearch(); else refreshCats();
        return true;
    }

    private void itemMenu(int pos) {
        if (pos < 0 || pos >= curItems.size()) return;
        final NativeData.Item it = curItems.get(pos);
        final boolean vod = !"live".equals(it.kind) && !"series".equals(it.kind);
        List<String> opts = new ArrayList<>();
        opts.add(data.isFav(it.url) ? "Tirar dos favoritos" : "Juntar aos favoritos");
        if (vod) opts.add(data.watched(it.url) ? "Marcar como não visto" : "Marcar como visto");
        if (vod && data.pos(it.url) > 0) opts.add("Ver do início");
        opts.add("series".equals(it.kind) ? "Abrir" : "Ver");
        if (openSeries == null) hideOpts(opts, it);
        final String[] arr = opts.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle(it.name).setItems(arr, (d, w) -> {
            String o = arr[w];
            if (doHide(o, it)) return;
            if (o.contains("favoritos")) {
                boolean on = data.toggleFav(it);
                Toast.makeText(this, on ? "★ Nos favoritos" : "Fora dos favoritos", Toast.LENGTH_SHORT).show();
                if ("fav".equals(tab)) showFlat("fav"); else gridAdapter.notifyDataSetChanged();
            } else if (o.startsWith("Marcar")) {
                data.setWatched(it.url, !data.watched(it.url));
                gridAdapter.notifyDataSetChanged(); refreshCats();
            } else if (o.equals("Ver do início")) {
                if ("episode".equals(it.kind) && openSeries != null) { int i = indexOf(seriesEps, it.url); if (i >= 0) { play(seriesEps, i, 0); return; } }
                play(curItems, pos, 0);
            } else onItem(pos);
        }).show();
    }

    /* ------------------------------------------------------------ fichas de filmes e séries */
    private void closeDetails() {
        if (details == null) return;
        try { appLayer.removeView(details); } catch (Throwable ignored) { }
        details = null;
        try { mainCol.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS); } catch (Throwable ignored) { }
        if ("home".equals(section)) ui.post(this::startPreview);
    }

    private interface Fill { void into(LinearLayout buttons, TextView meta, TextView plot, TextView people, ImageView back, ImageView poster); }

    private View firstBtn;
    /** Ecrã de ficha (fundo, capa, título, dados, sinopse e botões). */
    private void showDetails(String title, String posterUrl, Fill f) {
        closeDetails();
        firstBtn = null;
        details = new FrameLayout(this);
        details.setBackgroundColor(BG);
        details.setClickable(true);
        ImageView back = new ImageView(this); back.setScaleType(ImageView.ScaleType.CENTER_CROP); back.setAlpha(0.35f);
        details.addView(back, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xF20B0F14, 0xC00B0F14, 0x400B0F14}));
        details.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout row = new LinearLayout(this);
        row.setPadding(dp(28), dp(26), dp(28), dp(26));
        boolean narrow = getResources().getDisplayMetrics().widthPixels < dp(600);
        row.setOrientation(narrow ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        ImageView poster = new ImageView(this); poster.setScaleType(ImageView.ScaleType.CENTER_CROP);
        poster.setBackground(roundRect(CARD, 10)); poster.setClipToOutline(true);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(dp(narrow ? 140 : 200), dp(narrow ? 210 : 300));
        plp.rightMargin = dp(26); plp.bottomMargin = dp(14);
        row.addView(poster, plp);
        Bitmap pc = posterUrl == null ? null : bmp.get(posterUrl);
        if (pc != null) poster.setImageBitmap(pc); else loadBig(poster, posterUrl, dp(200));

        LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(this); t.setText(title); t.setTextColor(TXT); t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(26)); t.setTypeface(null, Typeface.BOLD);
        info.addView(t);
        TextView meta = new TextView(this); meta.setTextColor(ACC); meta.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(14)); meta.setPadding(0, dp(6), 0, dp(10));
        info.addView(meta);
        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL);
        HorizontalScrollView bh = new HorizontalScrollView(this); bh.setHorizontalScrollBarEnabled(false); bh.addView(buttons);
        info.addView(bh);
        TextView plot = new TextView(this); plot.setTextColor(TXT); plot.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(15)); plot.setLineSpacing(0, 1.15f); plot.setPadding(0, dp(14), 0, dp(10));
        info.addView(plot);
        TextView people = new TextView(this); people.setTextColor(MUT); people.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(13)); people.setLineSpacing(0, 1.1f);
        info.addView(people);
        row.addView(info, new LinearLayout.LayoutParams(narrow ? -1 : 0, -2, narrow ? 0 : 1));
        sv.addView(row);
        details.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        appLayer.addView(details, new FrameLayout.LayoutParams(-1, -1));
        /* v289: com a ficha aberta, o resto do ecrã não recebe o foco (as setas saltavam para a lista escondida por trás e «perdiam-se») */
        try { mainCol.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS); } catch (Throwable ignored) { }
        stopPreview();
        f.into(buttons, meta, plot, people, back, poster);
        if (firstBtn != null) firstBtn.requestFocus();
    }

    /** Sinopse em português: traduz por trás (com cache) e troca o texto se a ficha ainda estiver aberta. */
    private void translatePlot(final TextView tv, final String src) {
        if (src == null || src.length() < 20) return;
        final FrameLayout d0 = details;
        bg.execute(() -> {
            final String t = data.translatePt(src);
            if (t == null || t.trim().equalsIgnoreCase(src.trim())) return;
            ui.post(() -> { if (details == d0 && d0 != null) tv.setText(t); });
        });
    }

    private Button dBtn(LinearLayout parent, String text, boolean primary, View.OnClickListener l) {
        Button b = btn(text, l);
        if (primary) b.setBackground(sel(0xFF2B6CB0, 12));
        parent.addView(b);
        if (firstBtn == null) firstBtn = b;
        return b;
    }

    private static String mins(String dur) {
        if (dur == null || dur.isEmpty()) return "";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(\\d+):(\\d+)(?::\\d+)?$").matcher(dur.trim());
        if (m.find()) { int h = Integer.parseInt(m.group(1)), mi = Integer.parseInt(m.group(2)); return (h > 0 ? h + " h " : "") + mi + " min"; }
        return dur;
    }

    private void openMovieDetails(final List<NativeData.Item> list, final int idx) {
        final NativeData.Item m = list.get(idx);
        final int seq = ++loadSeq;
        setStatus("A abrir «" + m.name + "»…", true);
        bg.execute(() -> {
            final JSONObject inf = data.vodInfo(m);
            ui.post(() -> {
                if (seq != loadSeq) return;
                setStatus("", false);
                showDetails(m.name, NativeData.firstImg(inf, "movie_image", "cover_big").isEmpty() ? m.logo : NativeData.firstImg(inf, "movie_image", "cover_big"), (buttons, meta, plot, people, back, poster) -> {
                    StringBuilder mt = new StringBuilder();
                    String yr = inf.optString("releasedate", inf.optString("release_date", m.year));
                    if (yr.length() >= 4) mt.append(yr.substring(0, 4));
                    String rt = inf.optString("rating", m.rating); if (rt.length() > 0 && !"0".equals(rt)) mt.append(mt.length() > 0 ? "  ·  " : "").append("★ ").append(rt);
                    String du = mins(inf.optString("duration")); if (du.length() > 0) mt.append(mt.length() > 0 ? "  ·  " : "").append(du);
                    String ge = inf.optString("genre"); if (ge.length() > 0) mt.append(mt.length() > 0 ? "  ·  " : "").append(ge);
                    if (data.watched(m.url)) mt.append("  ·  ✓ visto");
                    meta.setText(mt);
                    String pl = NativeData.text(inf, "plot", "description", "overview", "plot_outline"); if (pl.isEmpty()) pl = m.plot;
                    plot.setText(pl.isEmpty() ? "Sem sinopse disponível para este título." : pl);
                    translatePlot(plot, pl);
                    StringBuilder pe = new StringBuilder();
                    String di = inf.optString("director"); if (di.length() > 0) pe.append("Realização: ").append(di);
                    String ca = NativeData.text(inf, "cast", "actors"); if (ca.length() > 0) pe.append(pe.length() > 0 ? "\n" : "").append("Elenco: ").append(ca);
                    people.setText(pe);
                    loadBig(back, NativeData.firstImg(inf, "backdrop_path", "backdrop", "movie_image"), dp(960));
                    final long ps = data.pos(m.url);
                    if (ps > 0) {
                        dBtn(buttons, "▶ Continuar (" + (ps / 60000) + " min)", true, v -> { closeDetails(); play(list, idx, -1); });
                        dBtn(buttons, "↺ Do início", false, v -> { closeDetails(); play(list, idx, 0); });
                    } else dBtn(buttons, "▶ Ver", true, v -> { closeDetails(); play(list, idx, 0); });
                    final String yt = NativeData.trailerId(inf);
                    dBtn(buttons, "🎬 Trailer", false, v -> trailer(m.name, yr, false, yt));
                    final Button fb = dBtn(buttons, data.isFav(m.url) ? "★ Nos favoritos" : "☆ Favorito", false, null);
                    fb.setOnClickListener(v -> { boolean on = data.toggleFav(m); fb.setText(on ? "★ Nos favoritos" : "☆ Favorito"); });
                    final Button wb = dBtn(buttons, data.watched(m.url) ? "✓ Visto" : "Marcar como visto", false, null);
                    wb.setOnClickListener(v -> { boolean on = !data.watched(m.url); data.setWatched(m.url, on); wb.setText(on ? "✓ Visto" : "Marcar como visto"); gridAdapter.notifyDataSetChanged(); });
                });
            });
        });
    }

    /** Ficha da série: continuar no episódio certo, episódios por temporada, trailer e favorito. */
    private void openSeriesDetails(final NativeData.Item s) {
        final int seq = ++loadSeq;
        setStatus("A abrir «" + s.name + "»…", true);
        bg.execute(() -> {
            List<NativeData.Cat> seasons = null; String err = null;
            try { seasons = data.seriesInfo(s, false); } catch (Throwable e) { err = String.valueOf(e.getMessage()); }
            final List<NativeData.Cat> fs = seasons; final String fe = err;
            ui.post(() -> {
                if (seq != loadSeq) return;
                if (fs == null || fs.isEmpty()) { setStatus(fe != null ? "Erro: " + fe : "Esta série ainda não tem episódios.", false); return; }
                setStatus("", false);
                final List<NativeData.Item> eps = new ArrayList<>(); for (NativeData.Cat c : fs) eps.addAll(c.items);
                JSONObject inf0 = data.seriesMeta.get(s.sid); final JSONObject inf = inf0 == null ? new JSONObject() : inf0;
                showDetails(s.name, s.logo, (buttons, meta, plot, people, back, poster) -> {
                    StringBuilder mt = new StringBuilder();
                    String yr = inf.optString("releaseDate", inf.optString("release_date", s.year)); if (yr.length() >= 4) mt.append(yr.substring(0, 4));
                    String rt = inf.optString("rating", s.rating); if (rt.length() > 0 && !"0".equals(rt)) mt.append(mt.length() > 0 ? "  ·  " : "").append("★ ").append(rt);
                    mt.append(mt.length() > 0 ? "  ·  " : "").append(fs.size()).append(fs.size() == 1 ? " temporada" : " temporadas").append("  ·  ").append(eps.size()).append(" episódios");
                    String ge = inf.optString("genre"); if (ge.length() > 0) mt.append("  ·  ").append(ge);
                    int seen = 0; for (NativeData.Item e : eps) if (data.watched(e.url)) seen++;
                    if (seen > 0) mt.append("  ·  ✓ ").append(seen).append("/").append(eps.size());
                    meta.setText(mt);
                    String pl = NativeData.text(inf, "plot", "description", "overview"); if (pl.isEmpty()) pl = s.plot;
                    plot.setText(pl.isEmpty() ? "Sem sinopse disponível para este título." : pl);
                    translatePlot(plot, pl);
                    StringBuilder pe = new StringBuilder();
                    String di = inf.optString("director"); if (di.length() > 0) pe.append("Realização: ").append(di);
                    String ca = inf.optString("cast"); if (ca.length() > 0) pe.append(pe.length() > 0 ? "\n" : "").append("Elenco: ").append(ca);
                    people.setText(pe);
                    loadBig(back, NativeData.firstImg(inf, "backdrop_path", "cover"), dp(960));
                    /* onde continuar: o último episódio aberto (se ficou a meio) ou o seguinte (se acabou) */
                    String last = data.lastEp(s.sid);
                    int ix = 0; String lbl;
                    int li = last.isEmpty() ? -1 : indexOf(eps, last);
                    if (li >= 0) { ix = data.watched(last) && li + 1 < eps.size() ? li + 1 : li; NativeData.Item e = eps.get(ix); lbl = "▶ Continuar T" + e.season + "·E" + e.ep; }
                    else lbl = "▶ Começar T" + eps.get(0).season + "·E" + eps.get(0).ep;
                    final int fix = ix;
                    dBtn(buttons, lbl, true, v -> { closeDetails(); play(eps, fix, -1); });
                    dBtn(buttons, "☰ Episódios", false, v -> { closeDetails(); showSeasons(s, fs, eps, fix); });
                    final String yt = NativeData.trailerId(inf);
                    dBtn(buttons, "🎬 Trailer", false, v -> trailer(s.name, yr, true, yt));
                    final Button fb = dBtn(buttons, data.isFav(s.url) ? "★ Nos favoritos" : "☆ Favorito", false, null);
                    fb.setOnClickListener(v -> { boolean on = data.toggleFav(s); fb.setText(on ? "★ Nos favoritos" : "☆ Favorito"); });
                });
            });
        });
    }

    /** Temporadas na coluna, episódios na grelha (abre na temporada do episódio a seguir). */
    private void showSeasons(NativeData.Item s, List<NativeData.Cat> seasons, List<NativeData.Item> eps, int focusEp) {
        if (openSeries == null) { seriesCatBefore = curCat; seriesPosBefore = grid.getFirstVisiblePosition(); }
        String prevTab = tab;
        if (!"series".equals(tab) && catList.getVisibility() != View.VISIBLE) { catList.setVisibility(View.VISIBLE); }
        openSeries = s;
        seriesEps = eps;
        curCats = seasons; shownKey = "";
        catAdapter.notifyDataSetChanged();
        int si = 0; String target = focusEp >= 0 && focusEp < eps.size() ? eps.get(focusEp).url : "";
        for (int i = 0; i < seasons.size(); i++) if (indexOf(seasons.get(i).items, target) >= 0) { si = i; break; }
        pickCat(si, true);
        catList.setSelection(si);
        int ei = indexOf(curItems, target); if (ei >= 0) grid.setSelection(ei);
        updateSortBtn();
        setStatus("🎞️ " + s.name + " · " + seasons.size() + " temporadas   ·   Voltar: " + ("series".equals(prevTab) ? "lista de séries" : "anterior"), false);
    }

    private void closeSeries() {
        openSeries = null;
        if (!"series".equals(tab)) { showTab(tab); return; }
        curCats = withVirtual("series"); shownKey = "";
        catAdapter.notifyDataSetChanged();
        pickCat(Math.min(seriesCatBefore, Math.max(0, curCats.size() - 1)), true);
        catList.setSelection(curCat);
        grid.setSelection(seriesPosBefore);
        updateSortBtn();
        setStatus("", false);
    }

    /** Abre um episódio pelo endereço, com a série toda na lista (o seguinte começa sozinho). */
    private void playEpisode(final String sid, final String url) {
        bg.execute(() -> {
            try { data.load("series", false); } catch (Throwable ignored) { }
            NativeData.Item s = data.seriesBySid(sid);
            List<NativeData.Item> eps = new ArrayList<>();
            if (s != null) try { for (NativeData.Cat c : data.seriesInfo(s, false)) eps.addAll(c.items); } catch (Throwable ignored) { }
            final List<NativeData.Item> fe = eps;
            ui.post(() -> {
                int i = indexOf(fe, url);
                if (i >= 0) { play(fe, i, -1); return; }
                NativeData.Item it = data.findByUrl(url);
                if (it != null) { List<NativeData.Item> one = new ArrayList<>(); one.add(it); play(one, 0, -1); }
            });
        });
    }

    /** v310: o trailer mais recente do YouTube, dentro da app. */
    private void trailer(String title, String year, boolean series, String providerId) {
        try { NativeTrailer.open(this, title, year, series, providerId); } catch (Throwable e) { trailer(providerId); }
    }
    private void trailer(String id) {
        if (id == null || id.isEmpty()) return;
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:" + id))); return; } catch (Throwable ignored) { }
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=" + id))); }
        catch (Throwable e) { Toast.makeText(this, "Não há nenhuma app para abrir o trailer (instala o YouTube).", Toast.LENGTH_LONG).show(); }
    }

    /* ------------------------------------------------------------ reprodução */
    /** startOverride: -1 = retoma onde ficou; 0 = do início. */
    private void play(List<NativeData.Item> list, int idx, long startOverride) {
        if (nscr != null && nscr.isOpen()) return;
        if (idx >= 0 && idx < list.size() && (parLocked(list.get(idx).name) || parLocked(list.get(idx).group))) { parAsk(() -> play(list, idx, startOverride)); return; }   /* v366 */
        /* só os itens reproduzíveis, no máximo 1500 à volta do escolhido: é a lista do ecrã total */
        List<NativeData.Item> src = new ArrayList<>(); int start = 0;
        int from = Math.max(0, idx - 750), to = Math.min(list.size(), from + 1500);
        for (int i = from; i < to; i++) { NativeData.Item it = list.get(i); if ("series".equals(it.kind) || it.url.startsWith("series:")) continue; if (i == idx) start = src.size(); src.add(it); }
        if (src.isEmpty()) return;
        JSONArray a = new JSONArray();
        for (int i = 0; i < src.size(); i++) {
            NativeData.Item it = src.get(i);
            try {
                JSONObject o = new JSONObject();
                String nm = it.name;
                if ("episode".equals(it.kind) && it.group.length() > 0) nm = it.group + " · " + it.name;
                o.put("name", nm); o.put("logo", data.logo(it)); o.put("group", it.group); o.put("url", it.url);
                o.put("kind", "live".equals(it.kind) ? "live" : ("episode".equals(it.kind) ? "episode" : "movie"));
                if (it.year != null && it.year.length() > 0) o.put("year", it.year);
                if (it.season > 0) o.put("season", it.season);
                if (it.ep > 0) o.put("ep", it.ep);
                long p = "live".equals(it.kind) ? 0 : (i == start && startOverride >= 0 ? startOverride : data.pos(it.url));
                if (p > 0) o.put("start", p);
                a.put(o);
            } catch (Throwable ignored) { }
        }
        playing = src;
        if ("home".equals(section)) saveHomePos(); else saveBrowsePos();
        ui.removeCallbacks(pvLimit);
        pvUrl = null;   /* o leitor passa da pré-visualização para o ecrã total (a mesma ligação, se for o mesmo canal) */
        try {
            if (np == null) np = new NativePlayer(this, root, (k, m) -> playerEvent(k, m));
            applyPlayerPrefs();
            MainActivity.NAV_JSON = playerNavJson();   /* a mesma barra de cima no ecrã do canal */
            nscr = new NativeScreen(this, root, np, (k, m) -> runOnUiThread(() -> onScreen(k, m)));
            nscr.open(a.toString(), start);
            /* v290: com o ecrã do canal aberto, o Início/Explorar por trás não recebe o foco (as setas fugiam para lá e «perdiam-se» nas ações) */
            if (nscr.isOpen()) try { appLayer.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS); } catch (Throwable ignored) { }
            if (nscr.isOpen()) nscr.command("full", "");
        } catch (Throwable e) {
            Toast.makeText(this, "Não consegui abrir: " + e, Toast.LENGTH_LONG).show();
        }
    }

    private boolean restarting = false;
    /** v282: reinicia o processo (liberta o descodificador preso) e volta ao mesmo canal/filme. */
    private void restartApp(String url) {
        if (restarting) return;
        restarting = true;
        try { Toast.makeText(this, "O descodificador de vídeo da TV bloqueou. A reiniciar…", Toast.LENGTH_LONG).show(); } catch (Throwable ignored) { }
        try {
            NativeData.Item it = url == null || url.isEmpty() || nscr == null || !nscr.isOpen() ? null : playingByUrl(url);   /* v288: só volta ao vídeo se estava a vê-lo (não ao sair para o Início) */
            Intent next = new Intent(this, NativeHomeActivity.class);
            if (it != null) next.setData(Uri.parse("cockpittv://play?id=" + Uri.encode(it.url)));
            Intent ph = new Intent(this, PhoenixActivity.class).putExtra("pid", android.os.Process.myPid()).putExtra("next", next).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ui.postDelayed(() -> { try { startActivity(ph); overridePendingTransition(0, 0); } catch (Throwable e) { restarting = false; } }, 1200);
        } catch (Throwable e) { restarting = false; }
    }

    private void playerEvent(String k, String m) {
        if ("restartapp".equals(k)) {
            /* no máximo um reinício a cada 3 min (um vídeo que este aparelho não descodifica não pode pôr a app em ciclo) */
            android.content.SharedPreferences ns = getSharedPreferences("nativeapp", 0);
            long last = ns.getLong("lastRestart", 0), now = System.currentTimeMillis();
            final String fu = m;
            if (now - last > 180000) { ns.edit().putLong("lastRestart", now).commit(); runOnUiThread(() -> restartApp(fu)); return; }
            NativeScreen s0 = nscr;
            if (s0 != null && s0.isOpen()) s0.onPlayerEvent("error", "o descodificador de vídeo deste aparelho não abriu este vídeo");
            return;
        }
        NativeScreen s = nscr;
        if ("suberr".equals(k)) { runOnUiThread(() -> Toast.makeText(this, "Legendas: " + m, Toast.LENGTH_LONG).show()); return; }
        if (s != null && s.isOpen()) { s.onPlayerEvent(k, m); return; }
        if ("ui".equals(k) && pvUrl != null) runOnUiThread(this::heroPrimary);   /* tocar na pré-visualização: ecrã total */
    }

    private NativeData.Item playingByUrl(String url) { for (NativeData.Item it : playing) if (it.url.equals(url)) return it; return null; }

    private void onScreen(String k, String m) {
        switch (k) {
            case "nscreen:play": {
                NativeData.Item it = playingByUrl(m);
                nowItem = it;
                osRes = new ArrayList<>();
                if (it != null) {
                    data.pushRecent(it);
                    if ("episode".equals(it.kind) && it.sid.length() > 0) data.setLastEp(it.sid, it.url);
                    if ("live".equals(it.kind)) fetchEpg(it);
                    else if (data.osAuto()) autoSubs(it);
                    if (cast != null && cast.active()) castNow();
                }
                break;
            }
            case "nscreen:pos": {
                String[] p = m.split("\\|");
                if (p.length >= 3) try {
                    long ps = Long.parseLong(p[1]), du = Long.parseLong(p[2]);
                    data.savePos(p[0], ps, du);
                    NativeData.Item it = playingByUrl(p[0]);
                    if (it != null) watchNext(it, ps, du);
                } catch (Throwable ignored) { }
                break;
            }
            case "nscreen:closed":
                try { appLayer.setDescendantFocusability(ViewGroup.FOCUS_AFTER_DESCENDANTS); } catch (Throwable ignored) { }
                final NativeData.Item closedItem = nowItem;
                boolean keep = "home".equals(section) && closedItem != null && "live".equals(closedItem.kind) && pvPref();
                pvUrl = null;
                if (!keep) try { if (np != null) np.stop(); } catch (Throwable ignored) { }
                nowItem = null;
                if (pendingRebuild && !"home".equals(section)) { pendingRebuild = false; rebuild(); break; }
                if ("home".equals(section)) {
                    if (pendingRebuild) { pendingRebuild = false; rebuild(); break; }
                    if (closedItem != null && "live".equals(closedItem.kind)) {   /* o mesmo canal continua no destaque, sem voltar a ligar */
                        heroItem = closedItem; heroList = playing; heroIdx = Math.max(0, indexOf(playing, closedItem.url)); pvUrl = null;   /* play() do mesmo canal cancela a paragem pendente e continua */
                        refreshHero();
                    }
                    if (lastHomeFocus != null && lastHomeFocus.isAttachedToWindow()) lastHomeFocus.requestFocus();
                } else {
                    gridAdapter.notifyDataSetChanged();
                    if ("recent".equals(tab)) showFlat("recent"); else refreshCats();
                    grid.requestFocus();
                }
                break;
            case "nscreen:nav":
                if ("search".equals(m) || "movie".equals(m) || "series".equals(m) || "live".equals(m)) showTab(m);
                else showSection(secOf(m));
                break;
            case "nscreen:guide":
                showSection("guide");
                break;
            case "nscreen:subsearch": subSearch(m); break;
            case "nscreen:subpick": try { subApply(Integer.parseInt(m), false); } catch (Throwable ignored) { } break;
            case "nscreen:act":
                if ("cast".equals(m)) startCast();
                else if ("mirror".equals(m)) startMirror();
                break;
        }
    }

    /** Programa a decorrer e o seguinte (Xtream), mostrado no ecrã do canal. */
    private void fetchEpg(final NativeData.Item it) {
        bg.execute(() -> {
            String t = data.nowNext(it);
            if (t.isEmpty()) return;
            ui.post(() -> {
                try { if (nscr != null && nscr.isOpen()) { JSONObject o = new JSONObject(); o.put(it.url, t); nscr.command("epg", o.toString()); } } catch (Throwable ignored) { }
            });
        });
    }

    /* ------------------------------------------------------------ legendas online */
    /** v345: título limpo para OpenSubtitles (sem CAM/EN|/qualidade). */
    private String subQuery(NativeData.Item it) {
        if (it == null) return "";
        if ("episode".equals(it.kind) && it.group != null && it.group.length() > 0)
            return cleanSubTitle(it.group) + " S" + it.season + "E" + it.ep;
        String n = cleanSubTitle(it.name);
        /* ano à parte ajuda a API (ex.: Wildwood 2026). */
        if (it.year != null && it.year.length() >= 4 && !n.matches(".*\\b" + it.year + "\\b.*")) n = n + " " + it.year;
        return n;
    }
    private static String cleanSubTitle(String n) {
        if (n == null) return "";
        String s = n;
        s = s.replaceAll("^\\s*[A-Za-z]{2,3}\\s*[|:]\\s*", "");
        s = s.replaceAll("[\\[(][^\\])]*[\\])]", " ");
        s = s.replaceAll("(?i)\\b(fhd|uhd|4k|hd|sd|1080p|720p|dublado|legendado|vostpt|pt-pt|multi|dual|cam|hdcam|telesync|ts|tc|screener|web-?dl|webrip|bluray|bdrip|hdtv|dvdrip)\\b", " ");
        s = s.replaceAll("\\s*[-–|]\\s*\\d{4}\\s*$", " ");
        s = s.replaceAll("\\s+[-–|]\\s*$", "").replaceAll("\\s+", " ").trim();
        return s;
    }
    /** v347: procura legendas em português. Com chave OpenSubtitles usa-a primeiro; sem chave (ou sem resultados) usa o motor sem credenciais. */
    private List<String[]> findSubs(NativeData.Item it) throws Exception {
        List<String[]> r = new ArrayList<>();
        if (data.osKey().length() > 0) { try { r = data.osSearch(subQuery(it)); } catch (Throwable e) { NativeData.dbg("legendas (conta): " + e); } }
        if (!r.isEmpty()) return r;
        boolean ep = "episode".equals(it.kind);
        String raw = ep && it.group != null && it.group.length() > 0 ? it.group : it.name;
        String yr = it.year != null && it.year.matches("(19|20)\\d\\d.*") ? it.year.substring(0, 4) : "";
        if (yr.isEmpty() && raw != null) { java.util.regex.Matcher ym = java.util.regex.Pattern.compile("\\b(19\\d\\d|20\\d\\d)\\b").matcher(raw); if (ym.find()) yr = ym.group(1); }
        String t = cleanSubTitle(raw).replaceAll("^\\s*[A-Z0-9+]{2,4}\\s+[-–]\\s+", "").replaceAll("\\b(19\\d\\d|20\\d\\d)\\b", " ").replaceAll("\\s+", " ").trim();
        return data.freeSubs(t, ep ? "" : yr, ep || "series".equals(it.kind), it.season, it.ep);
    }
    /** v345: payload = url\nname\nkind\nyear\ngroup\nseason\nep (do ecrã) ou vazio (usa nowItem). */
    private void subSearch(String payload) {
        NativeData.Item it = nowItem;
        String forcedQ = null;
        if (payload != null && payload.length() > 0) {
            String[] p = payload.split("\n", -1);
            if (p.length >= 1 && p[0].length() > 0) {
                NativeData.Item byUrl = playingByUrl(p[0]);
                if (byUrl != null) it = byUrl;
                else if (it == null || !p[0].equals(it.url)) {
                    /* construir item mínimo a partir dos dados do ecrã */
                    NativeData.Item tmp = new NativeData.Item();
                    tmp.url = p[0];
                    if (p.length > 1) tmp.name = p[1];
                    if (p.length > 2) tmp.kind = p[2];
                    if (p.length > 3) tmp.year = p[3];
                    if (p.length > 4) tmp.group = p[4];
                    try { if (p.length > 5 && p[5].length() > 0) tmp.season = Integer.parseInt(p[5]); } catch (Throwable ignored) { }
                    try { if (p.length > 6 && p[6].length() > 0) tmp.ep = Integer.parseInt(p[6]); } catch (Throwable ignored) { }
                    if (tmp.name == null || tmp.name.isEmpty()) tmp.name = p.length > 1 ? p[1] : "";
                    it = tmp;
                }
            }
        }
        if (it == null) {
            Toast.makeText(this, "Sem título para pesquisar legendas.", Toast.LENGTH_LONG).show();
            return;
        }
        final NativeData.Item target = it;
        final String q = subQuery(target);
        Toast.makeText(this, "A procurar legendas: «" + q + "»…", Toast.LENGTH_SHORT).show();
        bg.execute(() -> {
            try {
                final List<String[]> r = findSubs(target);
                ui.post(() -> {
                    if (nscr == null || !nscr.isOpen()) return;
                    osRes = r;
                    if (r.isEmpty()) {
                        Toast.makeText(this, "Não encontrei legendas para «" + q + "».", Toast.LENGTH_LONG).show();
                        return;
                    }
                    JSONArray a = new JSONArray(); for (String[] x : r) a.put(x[1]);
                    nscr.command("subres", a.toString());
                });
            } catch (final Throwable e) { ui.post(() -> Toast.makeText(this, "Legendas: " + e.getMessage(), Toast.LENGTH_LONG).show()); }
        });
    }
    private void subSearch() { subSearch(""); }
    private void subApply(final int i, final boolean silent) {
        if (i < 0 || i >= osRes.size() || np == null) return;
        final String fid = osRes.get(i)[0];
        final NativeData.Item it = nowItem;
        bg.execute(() -> {
            try {
                final String txt = fid.startsWith("http") ? data.freeSubDownload(fid) : data.osDownload(fid);
                ui.post(() -> {
                    if (nowItem != it || np == null) return;
                    np.subtitle(txt, fid.startsWith("http") ? "Português · online" : "Português · OpenSubtitles", "pt");
                    Toast.makeText(this, "Legendas em português ativadas ✓", Toast.LENGTH_SHORT).show();
                });
            } catch (final Throwable e) { if (!silent) ui.post(() -> Toast.makeText(this, "Legendas: " + e.getMessage(), Toast.LENGTH_LONG).show()); }
        });
    }
    /** Legendas automáticas: procura e aplica a melhor em português pouco depois de começar. */
    private void autoSubs(final NativeData.Item it) {
        ui.postDelayed(() -> {
            if (nowItem != it || nscr == null || !nscr.isOpen()) return;
            bg.execute(() -> {
                try {
                    final List<String[]> r = findSubs(it);
                    ui.post(() -> { if (nowItem == it && !r.isEmpty()) { osRes = r; subApply(0, true); } });
                } catch (Throwable ignored) { }
            });
        }, 6000);
    }

    /* ------------------------------------------------------------ transmitir (Chromecast) */
    /** Espelhar o ecrã: abre o seletor do Android (Transmitir / Smart View / Miracast), como na app antiga. */
    private void startMirror() {
        String[] acts = {"android.settings.CAST_SETTINGS", "com.samsung.android.smartmirroring.SETTINGS", android.provider.Settings.ACTION_WIFI_SETTINGS};
        for (String a : acts) {
            try { startActivity(new android.content.Intent(a).addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)); return; } catch (Throwable ignored) { }
        }
        Toast.makeText(this, isTv() ? "Para espelhar o telemóvel nesta TV: no telemóvel abre Transmitir / Smart View e escolhe esta TV."
                : "Abre o painel rápido do Android e toca em Transmitir / Smart View / Espelhar ecrã.", Toast.LENGTH_LONG).show();
    }
    private void startCast() {
        try {
            if (cast == null) cast = new CastHelper(this, (k, m) -> runOnUiThread(() -> onCast(k, m)));
            if (cast.active()) { castNow(); return; }
            castWanted = true;
            cast.pick();
        } catch (Throwable e) { Toast.makeText(this, "Transmitir não está disponível neste aparelho.", Toast.LENGTH_LONG).show(); }
    }
    private void onCast(String k, String m) {
        if ("connected".equals(k)) { Toast.makeText(this, "Ligado a " + m, Toast.LENGTH_SHORT).show(); if (castWanted) castNow(); castWanted = false; }
        else if ("failed".equals(k) || "error".equals(k) || "unavailable".equals(k)) { castWanted = false; Toast.makeText(this, "Transmitir: " + m, Toast.LENGTH_LONG).show(); }
    }
    private void castNow() {
        NativeData.Item it = nowItem;
        if (it == null || cast == null) return;
        String u = it.url.toLowerCase();
        String mime = u.contains(".m3u8") ? "application/x-mpegURL" : u.endsWith(".ts") ? "video/mp2t" : u.endsWith(".mkv") ? "video/x-matroska" : "video/mp4";
        long st = 0;
        try { st = Long.parseLong(np.pos().split("\\|")[0]); } catch (Throwable ignored) { }
        boolean live = "live".equals(it.kind);
        cast.load(it.url, it.name, mime, live, live ? 0 : st);
        try { np.pause(); } catch (Throwable ignored) { }
        Toast.makeText(this, "A transmitir «" + it.name + "»", Toast.LENGTH_SHORT).show();
    }

    /* ------------------------------------------------------------ «Continuar a ver» no ecrã inicial da TV */
    private void watchNext(NativeData.Item it, long pos, long dur) {
        final String id = it.url, name = "episode".equals(it.kind) && it.group.length() > 0 ? it.group + " · " + it.name : it.name, logo = it.logo;
        final boolean remove = dur > 0 && pos > Math.max(dur * 0.93, dur - 120000) || pos < 30000;
        bg.execute(() -> {
            try {
                android.content.ContentResolver cr = getContentResolver();
                long existing = -1;
                android.database.Cursor c = cr.query(androidx.tvprovider.media.tv.TvContractCompat.WatchNextPrograms.CONTENT_URI,
                        androidx.tvprovider.media.tv.WatchNextProgram.PROJECTION, null, null, null);
                if (c != null) {
                    try {
                        while (c.moveToNext()) {
                            androidx.tvprovider.media.tv.WatchNextProgram p = androidx.tvprovider.media.tv.WatchNextProgram.fromCursor(c);
                            if (id.equals(p.getInternalProviderId())) { existing = p.getId(); break; }
                        }
                    } finally { c.close(); }
                }
                if (remove) { if (existing >= 0) cr.delete(androidx.tvprovider.media.tv.TvContractCompat.buildWatchNextProgramUri(existing), null, null); return; }
                androidx.tvprovider.media.tv.WatchNextProgram.Builder b = new androidx.tvprovider.media.tv.WatchNextProgram.Builder();
                b.setType(androidx.tvprovider.media.tv.TvContractCompat.WatchNextPrograms.TYPE_MOVIE);
                b.setWatchNextType(androidx.tvprovider.media.tv.TvContractCompat.WatchNextPrograms.WATCH_NEXT_TYPE_CONTINUE);
                b.setLastEngagementTimeUtcMillis(System.currentTimeMillis());
                b.setTitle(name);
                b.setInternalProviderId(id);
                b.setLastPlaybackPositionMillis((int) pos);
                b.setDurationMillis((int) dur);
                b.setIntentUri(Uri.parse("cockpittv://play?id=" + Uri.encode(id)));
                if (logo != null && logo.startsWith("http")) {
                    b.setPosterArtUri(Uri.parse(logo));
                    b.setPosterArtAspectRatio(androidx.tvprovider.media.tv.TvContractCompat.PreviewPrograms.ASPECT_RATIO_2_3);
                }
                android.content.ContentValues cv = b.build().toContentValues();
                if (existing >= 0) cr.update(androidx.tvprovider.media.tv.TvContractCompat.buildWatchNextProgramUri(existing), cv, null, null);
                else cr.insert(androidx.tvprovider.media.tv.TvContractCompat.WatchNextPrograms.CONTENT_URI, cv);
            } catch (Throwable ignored) { }
        });
    }

    /* ------------------------------------------------------------ definições */
    /* v278: Definições como na app antiga: grelha de secções, cada uma abre a sua página */
    private String setPage = "";
    private static final String[][] SET_PAGES = {
            {"iptv", "Lista IPTV e ligação", "Fornecedor, atualizar listas e importar da app antiga", "iptv"},
            {"home", "Início e canais", "Aparência, operador, países, ordem, ocultos e pré-visualização", "home"},
            {"video", "Vídeo e imagem", "Ecrã total, desentrelaçamento, formato, superfície, túnel e tamanho", "video"},
            {"sound", "Som e legendas", "Dolby, acerto do som, aspeto das legendas e legendas online", "sound"},
            {"vod", "Filmes e séries", "Continuar a ver e marcas de visto", "vod"},
            {"look", "Aspeto: cores e ícones", "Cor de destaque, fundo, cor e tamanho dos ícones", "home"},
            {"backup", "Cópia de segurança", "Exportar e importar todas as definições", "info"},
            {"parental", "Controlo parental", "PIN e palavras que pedem PIN para abrir ou ver", "info"},
            {"diag", "Diagnóstico e ajuda", "Registo do leitor, envio para o GitHub e versão", "info"}};
    private Bitmap setIcon(String k) {
        try {
            if ("sound".equals(k)) { JSONObject o = new JSONObject(MainActivity.ICONS_JSON); return b64(o.optString("sound")); }
            if ("vod".equals(k)) return kindIcons.get("Filmes");
            JSONObject o = new JSONObject(asset(this, "ui/seticons.json"));
            return b64(o.optString("home".equals(k) ? "home" : "iptv".equals(k) ? "iptv" : "video".equals(k) ? "video" : "info"));
        } catch (Throwable e) { return null; }
    }
    private static String flag(String c) {
        if (c == null || !c.matches("[A-Z]{2}")) return "🌐";
        String x = "UK".equals(c) ? "GB" : c;
        return new String(Character.toChars(127397 + x.charAt(0))) + new String(Character.toChars(127397 + x.charAt(1)));
    }
    private static String ctyName(String c) {
        try { String x = "UK".equals(c) ? "GB" : c; String n = new java.util.Locale("", x).getDisplayCountry(new java.util.Locale("pt", "PT")); return n == null || n.isEmpty() || n.equals(x) ? c : n; } catch (Throwable e) { return c; }
    }

    private void showSettings() {
        catList.setVisibility(View.GONE); grid.setVisibility(View.GONE);
        setStatus("", false);
        ScrollView sv = new ScrollView(this);
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(20), dp(8), dp(20), dp(30));
        sv.addView(f);
        final String pg = setPage;
        TextView title = new TextView(this); title.setTextColor(TXT); title.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(28)); title.setTypeface(null, Typeface.BOLD);
        if (pg.isEmpty()) {
            title.setText("Definições");
            f.addView(title);
            boolean two = !portrait();
            LinearLayout rowL = null;
            for (int i = 0; i < SET_PAGES.length; i++) {
                final String[] sp = SET_PAGES[i];
                if (rowL == null || !two || rowL.getChildCount() == 2) { rowL = new LinearLayout(this); LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2); rl.topMargin = dp(16); f.addView(rowL, rl); }
                LinearLayout card = new LinearLayout(this); card.setGravity(Gravity.CENTER_VERTICAL);
                card.setPadding(dp(22), dp(18), dp(22), dp(18));
                card.setBackground(sel(CARD, 18)); card.setFocusable(true); card.setClickable(true);
                ImageView ic = new ImageView(this); ic.setImageBitmap(setIcon(sp[0])); ic.setPadding(dp(11), dp(11), dp(11), dp(11)); ic.setBackground(pill(CHIP, 12));
                card.addView(ic, new LinearLayout.LayoutParams(dp(52), dp(52)));
                LinearLayout tx = new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.setPadding(dp(16), 0, dp(10), 0);
                TextView t = new TextView(this); t.setText(sp[1]); t.setTextColor(TXT); t.setTypeface(null, Typeface.BOLD); t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(21));
                TextView d = new TextView(this); d.setText(sp[2]); d.setTextColor(MUT); d.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(15));
                tx.addView(t); tx.addView(d);
                card.addView(tx, new LinearLayout.LayoutParams(0, -2, 1));
                TextView ch = new TextView(this); ch.setText("›"); ch.setTextColor(MUT); ch.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(28));
                card.addView(ch);
                card.setOnClickListener(v -> openSetPage(sp[0]));
                LinearLayout.LayoutParams cl0 = new LinearLayout.LayoutParams(0, -1, 1);
                if (two && rowL.getChildCount() == 1) cl0.leftMargin = dp(16);
                rowL.addView(card, cl0);
            }
            if (two && rowL != null && rowL.getChildCount() == 1) rowL.addView(new View(this), new LinearLayout.LayoutParams(0, -1, 1));
            settingsView = sv;
            body.addView(sv, new LinearLayout.LayoutParams(-1, -1));
            ui.post(() -> { View c0 = findFocusable(f, setLast); if (c0 != null) c0.requestFocus(); });
            return;
        }
        String pt = ""; for (String[] x : SET_PAGES) if (x[0].equals(pg)) pt = x[1];
        LinearLayout hdr = new LinearLayout(this); hdr.setGravity(Gravity.CENTER_VERTICAL);
        hdr.addView(btn("‹ Definições", v -> openSetPage("")));
        title.setText(pt); title.setPadding(dp(14), 0, 0, 0);
        hdr.addView(title);
        f.addView(hdr);
        if ("iptv".equals(pg)) {
        f.addView(head("Lista IPTV"));
        final EditText xs = field(f, "Servidor Xtream (ex.: http://servidor:8080)", data.server, false);
        final EditText xu = field(f, "Utilizador", data.user, false);
        final EditText xp = field(f, "Palavra-passe", data.pass, true);
        final EditText mm = field(f, "…ou endereço de lista M3U", data.m3u, false);
        LinearLayout row = new LinearLayout(this); row.setPadding(0, dp(12), 0, 0);
        final Button save = btn("Guardar", v -> {
            data.saveCfg(xs.getText().toString(), xu.getText().toString(), xp.getText().toString(), mm.getText().toString());
            Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show();
            if (data.configured()) showSection("home");
        });
        row.addView(save);
        row.addView(btn("Atualizar listas agora", v -> { data.clearCache(); Toast.makeText(this, "As listas vão ser descarregadas de novo", Toast.LENGTH_SHORT).show(); showSection("home"); }));
        row.addView(btn("Importar da app antiga", v -> {
            importOld(res -> { if (res) { data.loadCfg(); data.clearCache(); Toast.makeText(this, "Importado", Toast.LENGTH_SHORT).show(); showSection("home"); } else Toast.makeText(this, "Não encontrei dados da app antiga.", Toast.LENGTH_LONG).show(); });
        }));
        f.addView(row);

        /* ---- v312: atualização das listas e do guia (EPG), como nas apps IPTV ---- */
        f.addView(head("Atualização de canais e guia (EPG)"));
        f.addView(label("Renovar as listas de canais, filmes e séries a cada"));
        final int[] ttlH = {6, 12, 24, 48, 168, 0};
        int ti = 1; { int cur = data.sp().getInt("listTtlH", 12); for (int q = 0; q < ttlH.length; q++) if (ttlH[q] == cur) ti = q; }
        f.addView(choice(new String[]{"6 horas", "12 horas", "24 horas", "2 dias", "7 dias", "Só manual"}, ti, w -> { data.sp().edit().putInt("listTtlH", ttlH[w]).apply(); refreshTried.clear(); }));
        f.addView(label("Atualizar as listas ao abrir a app"));
        f.addView(choice(new String[]{"Se estiverem antigas", "Sempre", "Nunca"}, data.sp().getInt("listOpen", 0), w -> data.sp().edit().putInt("listOpen", w).apply()));
        f.addView(label("Atualizar em segundo plano com a app aberta (a cada intervalo acima)"));
        f.addView(choice(new String[]{"Ligado", "Desligado"}, data.sp().getBoolean("listBg", true) ? 0 : 1, w -> data.sp().edit().putBoolean("listBg", w == 0).apply()));
        f.addView(label("Atualizar o guia (programa a dar e a seguir) a cada"));
        final int[] epgM = {5, 15, 30, 60, 180};
        int ei = 2; { int cur = data.sp().getInt("epgTtlMin", 30); for (int q = 0; q < epgM.length; q++) if (epgM[q] == cur) ei = q; }
        f.addView(choice(new String[]{"5 min", "15 min", "30 min", "1 hora", "3 horas"}, ei, w -> data.sp().edit().putInt("epgTtlMin", epgM[w]).apply()));
        LinearLayout rr = new LinearLayout(this); rr.setPadding(0, dp(8), 0, 0);
        rr.addView(btn("Atualizar canais", v -> refreshKindNow("live")));
        rr.addView(btn("Atualizar filmes e séries", v -> { refreshKindNow("movie"); refreshKindNow("series"); }));
        rr.addView(btn("Atualizar guia (EPG)", v -> refreshGuideNow()));
        f.addView(rr);
        updLbl = new TextView(this); updLbl.setTextColor(MUT); updLbl.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(14)); updLbl.setVisibility(View.GONE); updLbl.setPadding(0, dp(8), 0, 0);
        updBar = new android.widget.ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal); updBar.setMax(100); updBar.setVisibility(View.GONE);
        f.addView(updLbl); f.addView(updBar, new LinearLayout.LayoutParams(-1, dp(10)));
        LinearLayout rr2 = new LinearLayout(this); rr2.setPadding(0, dp(6), 0, 0);
        rr2.addView(btn("Limpar logótipos", v -> Toast.makeText(this, PiconCache.clearAll() + " logótipos apagados", Toast.LENGTH_SHORT).show()));
        f.addView(rr2);

        }
        if ("home".equals(pg)) {
        f.addView(head("Início"));
        final CheckBox pv = new CheckBox(this);
        pv.setText("Pré-visualização do canal no destaque (1.º OK mostra, 2.º OK abre)"); pv.setTextColor(TXT); pv.setChecked(pvPref()); pv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(15));
        pv.setOnCheckedChangeListener((b, on) -> getSharedPreferences("nativeapp", 0).edit().putBoolean("tvPrev", on).apply());
        f.addView(pv);
        f.addView(label("Animação dos cartões (canais, filmes e séries) ao aparecerem"));
        final String[] anK = new String[ANIMS.length], anL = new String[ANIMS.length];
        for (int i = 0; i < ANIMS.length; i++) { anK[i] = ANIMS[i][0]; anL[i] = ANIMS[i][1]; }
        f.addView(choice(anL, indexOfS(anK, animPref()), w -> getSharedPreferences("nativeapp", 0).edit().putString("tvAnim", anK[w]).apply()));
        f.addView(note("Livro (3D): os cartões abrem como páginas e, ao focar, inclinam-se ligeiramente."));
        f.addView(label("Efeito das filas ao deslizar"));
        final String[] vfK = new String[VFXS.length], vfL = new String[VFXS.length];
        for (int i = 0; i < VFXS.length; i++) { vfK[i] = VFXS[i][0]; vfL[i] = VFXS[i][1]; }
        f.addView(choice(vfL, indexOfS(vfK, vfxPref()), w -> getSharedPreferences("nativeapp", 0).edit().putString("tvVfx", vfK[w]).apply()));
        f.addView(note("Profundidade: as filas junto às bordas encolhem e ficam transparentes. Onda: ondulam para os lados. Parallax: o destaque esmorece e as filas aproximam-se ao subir."));
        f.addView(label("Cartões sobrepostos (pilha)"));
        f.addView(choice(new String[]{"Normal", "Sobrepostos"}, stackOn() ? 1 : 0, w -> getSharedPreferences("nativeapp", 0).edit().putBoolean("tvStack", w == 1).apply()));
        f.addView(note("Sobrepostos: os cartões ficam empilhados e só se vê a direita de cada um. Ao focar, o cartão sobe para a frente. Volta ao Início para aplicar."));

        /* ---- Operador ---- */
        f.addView(head("Operador"));
        f.addView(note("Mostra no Início e no topo dos Canais os canais pela ordem da grelha do teu operador (a melhor versão portuguesa que a tua lista tiver)."));
        final String[] opK = {"", "meo", "nos", "vodafone", "custom"};
        final String[] opL = {"Desligado", "MEO", "NOS", "Vodafone", "Personalizada"};
        final EditText opc = new EditText(this);
        opc.setText(data.opCustom()); opc.setHint("Um canal por linha (ex.: RTP 1, SIC, TVI…). Usa | para nomes alternativos."); opc.setHintTextColor(MUT); opc.setTextColor(TXT);
        opc.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(15)); opc.setMinLines(4); opc.setGravity(Gravity.TOP); opc.setBackground(sel(CARD, 10)); opc.setPadding(dp(14), dp(10), dp(14), dp(10));
        opc.setVisibility("custom".equals(data.opKey()) ? View.VISIBLE : View.GONE);
        final TextView opSrc = note("");
        final Runnable opInfo = () -> { JSONObject o = data.ops().optJSONObject(data.opKey()); opSrc.setText(o == null ? "" : "Fonte: " + o.optString("src") + " · " + o.optJSONArray("list").length() + " canais"); opSrc.setVisibility(o == null ? View.GONE : View.VISIBLE); };
        f.addView(choice(opL, indexOfS(opK, data.opKey()), w -> { data.setOp(opK[w], null); opCache = null; opc.setVisibility(w == 4 ? View.VISIBLE : View.GONE); opInfo.run(); int n = opList().size(); Toast.makeText(this, w == 0 ? "Lista do operador desligada" : n + " canais encontrados na tua lista", Toast.LENGTH_SHORT).show(); }));
        f.addView(opSrc); opInfo.run();
        LinearLayout.LayoutParams ocl = new LinearLayout.LayoutParams(-1, -2); ocl.topMargin = dp(8);
        f.addView(opc, ocl);
        opc.setOnFocusChangeListener((v, fo) -> { if (!fo) { data.setOp(data.opKey(), opc.getText().toString()); opCache = null; } });


        /* ---- Países: ordenar e ocultar (como na app antiga); v316: recolher/expandir, ocultar/mostrar todos e posição mantida ---- */
        final Runnable[] paintG = new Runnable[1];
        final LinearLayout cbox = new LinearLayout(this); cbox.setOrientation(LinearLayout.VERTICAL);
        addCollapsible(f, "Países", "colC", cbox);
        cbox.addView(note("Os países vêm dos prefixos das categorias (|PT|, |ES|, …). A ordem dos países e os ocultos valem no Início, Explorar, Guia e Pesquisa. Os grupos do Início só aparecem se o país estiver visível; ao mostrares um país, os grupos dele voltam a aparecer."));
        final LinearLayout cl = new LinearLayout(this); cl.setOrientation(LinearLayout.VERTICAL);
        final int[] cfocus = {-1, 0};
        final Runnable[] paintC = new Runnable[1];
        paintC[0] = () -> {
            final Runnable hold = holdScroll(cl);
            cl.removeAllViews();
            List<String[]> cs = data.countries();
            if (cs.isEmpty()) { cl.addView(note("Abre os Canais uma vez para eu ver os países da tua lista.")); hold.run(); return; }
            int ci = 0;
            for (final String[] c : cs.subList(0, Math.min(40, cs.size()))) {
                final int ri = ci++;
                LinearLayout r = new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(0, dp(1), 0, dp(1));
                final boolean hid = data.ctyIsHidden(c[0]);
                TextView t = new TextView(this); t.setText(flag(c[0]) + "  " + ctyName(c[0]) + "  ·  " + c[1] + (hid ? "  · oculto" : "")); t.setTextColor(hid ? MUT : TXT); t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(14)); t.setSingleLine(true);
                r.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
                r.addView(sbtn("↑", v -> { cfocus[0] = Math.max(0, ri - 1); cfocus[1] = 1; data.moveCty(c[0], -1); opCache = null; paintC[0].run(); }));
                r.addView(sbtn("↓", v -> { cfocus[0] = ri + 1; cfocus[1] = 2; data.moveCty(c[0], 1); opCache = null; paintC[0].run(); }));
                r.addView(sbtn(hid ? "👁 Mostrar" : "🚫 Ocultar", v -> { cfocus[0] = ri; cfocus[1] = 3; data.toggleCty(c[0]); opCache = null; paintC[0].run(); if (paintG[0] != null) paintG[0].run(); }));
                cl.addView(r);
                if (ri == cfocus[0]) { final View fv = r.getChildAt(Math.min(cfocus[1], r.getChildCount() - 1)); cfocus[0] = -1; if (fv != null) fv.post(fv::requestFocus); }
            }
            hold.run();
        };
        paintC[0].run();
        LinearLayout ca = new LinearLayout(this); ca.setPadding(0, dp(6), 0, 0);
        ca.addView(btn("👁 Mostrar todos", v -> { data.showAllCountries(); opCache = null; cfocus[0] = -1; paintC[0].run(); if (paintG[0] != null) paintG[0].run(); Toast.makeText(this, "Todos os países visíveis", Toast.LENGTH_SHORT).show(); }));
        ca.addView(btn("🚫 Ocultar todos", v -> { data.hideAllCountries(); opCache = null; cfocus[0] = -1; paintC[0].run(); if (paintG[0] != null) paintG[0].run(); Toast.makeText(this, "Todos os países ocultos: escolhe os que queres mostrar", Toast.LENGTH_LONG).show(); }));
        cbox.addView(ca);
        cbox.addView(cl);
        LinearLayout cr = new LinearLayout(this); cr.setPadding(0, dp(6), 0, 0);
        cr.addView(btn("Repor países", v -> { data.resetCty(); opCache = null; paintC[0].run(); if (paintG[0] != null) paintG[0].run(); }));
        cr.addView(btn("Repor ordem das categorias", v -> { data.resetOrder(); opCache = null; if (paintG[0] != null) paintG[0].run(); Toast.makeText(this, "Ordem original das categorias", Toast.LENGTH_SHORT).show(); }));
        cbox.addView(cr);

        /* ---- v311: grupos de canais / filmes / séries: ordenar, ocultar e mostrar (todos de uma vez) ---- */
        final LinearLayout gbox = new LinearLayout(this); gbox.setOrientation(LinearLayout.VERTICAL);
        addCollapsible(f, "Grupos no Início", "colG", gbox);
        gbox.addView(note("A ordem definida aqui vale só para o Início (de cima para baixo). O Explorar, o Guia e a Pesquisa mantêm a ordem normal. Os grupos ocultos não aparecem em nenhum deles."));
        final String[] gkK = {"live", "movie", "series"};
        final int[] gk = {0};
        final LinearLayout gl = new LinearLayout(this); gl.setOrientation(LinearLayout.VERTICAL);
        final int[] gfocus = {-1, 0};
        final int[] gen = {0};
        paintG[0] = () -> {
            final int my = ++gen[0];
            gl.removeAllViews();
            final String kind = gkK[gk[0]];
            if (data.cats.get(kind) == null) {
                gl.addView(note("A carregar a lista…"));
                bg.execute(() -> { try { data.load(kind, false); } catch (Throwable ignored) { } ui.post(() -> { if (my == gen[0]) paintG[0].run(); }); });
                return;
            }
            final List<String[]> rows = data.groupRows(kind);
            int nv = 0; for (String[] r : rows) if ("0".equals(r[1])) nv++;
            gl.addView(note(nv + " visíveis · " + (rows.size() - nv) + " ocultos"));
            /* v314: mantém a posição do ecrã e do foco depois de cada clique (a lista é refeita, mas o ecrã não volta ao início) */
            View gpv = gl; ScrollView svx = null; while (gpv != null && gpv.getParent() instanceof View) { gpv = (View) gpv.getParent(); if (gpv instanceof ScrollView) { svx = (ScrollView) gpv; break; } }
            final ScrollView sv2 = svx; final int sy = sv2 != null ? sv2.getScrollY() : 0;
            if (sv2 != null && gl.getHeight() > 0) gl.setMinimumHeight(gl.getHeight());
            final int[] ix = {0};
            final Runnable[] chunk = new Runnable[1];
            chunk[0] = () -> {
                if (my != gen[0]) return;
                int end = Math.min(rows.size(), ix[0] + 60);
                for (; ix[0] < end; ix[0]++) {
                    final int ri = ix[0]; final String[] c = rows.get(ri); final boolean hid = "1".equals(c[1]);
                    LinearLayout r = new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(0, dp(1), 0, dp(1));
                    TextView t = new TextView(this); t.setText((hid ? "🚫  " : (ri + 1) + ".  ") + c[0] + "  ·  " + c[2]); t.setTextColor(hid ? MUT : TXT); t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(14)); t.setSingleLine(true); t.setEllipsize(android.text.TextUtils.TruncateAt.END);
                    r.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
                    if (!hid) {
                        r.addView(sbtn("⤒", v -> { gfocus[0] = Math.min(ri, rows.size() - 1); gfocus[1] = 1; data.moveCat(kind, c[0], Integer.MIN_VALUE); opCache = null; paintG[0].run(); }));
                        r.addView(sbtn("↑", v -> { gfocus[0] = Math.max(0, ri - 1); gfocus[1] = 2; data.moveCat(kind, c[0], -1); opCache = null; paintG[0].run(); }));
                        r.addView(sbtn("↓", v -> { gfocus[0] = ri + 1; gfocus[1] = 3; data.moveCat(kind, c[0], 1); opCache = null; paintG[0].run(); }));
                        r.addView(sbtn("#", v -> {
                            final EditText nb = new EditText(this); nb.setInputType(android.text.InputType.TYPE_CLASS_NUMBER); nb.setText(String.valueOf(ri + 1)); nb.selectAll();
                            new AlertDialog.Builder(this).setTitle("Posição de «" + c[0] + "» (1 a " + Math.max(1, rows.size()) + ")").setView(nb).setNegativeButton("Cancelar", null).setPositiveButton("OK", (d2, w2) -> {
                                int n; try { n = Integer.parseInt(nb.getText().toString().trim()); } catch (Throwable e) { return; }
                                n = Math.max(1, n); gfocus[0] = Math.min(rows.size() - 1, n - 1); gfocus[1] = 4; data.moveCatTo(kind, c[0], n); opCache = null; paintG[0].run();
                            }).show();
                        }));
                    }
                    r.addView(sbtn(hid ? "👁 Mostrar" : "🚫 Ocultar", v -> { gfocus[0] = ri; gfocus[1] = hid ? 1 : 5; if (hid) data.showCat(kind, c[0]); else data.hideCat(kind, c[0]); opCache = null; paintG[0].run(); }));
                    gl.addView(r);
                    if (ri == gfocus[0] && gfocus[0] >= 0) { int bi = Math.min(gfocus[1], r.getChildCount() - 1); View fv = r.getChildAt(Math.max(1, bi)); if (fv != null) { final View ff = fv; gfocus[0] = -1; ff.post(ff::requestFocus); } }
                }
                if (sv2 != null) sv2.post(() -> sv2.scrollTo(0, sy));
                if (ix[0] < rows.size()) ui.post(chunk[0]); else gl.setMinimumHeight(0);
            };
            chunk[0].run();
        };
        gbox.addView(choice(new String[]{"📺 Canais", "🎬 Filmes", "🎞️ Séries"}, 0, w -> { gk[0] = w; gfocus[0] = -1; paintG[0].run(); }));
        LinearLayout gr = new LinearLayout(this); gr.setPadding(0, dp(6), 0, dp(6));
        gr.addView(btn("👁 Mostrar todos", v -> { data.showAllGroups(gkK[gk[0]]); opCache = null; gfocus[0] = -1; paintG[0].run(); Toast.makeText(this, "Todos os grupos visíveis", Toast.LENGTH_SHORT).show(); }));
        gr.addView(btn("🚫 Ocultar todos", v -> { data.hideAllGroups(gkK[gk[0]]); opCache = null; gfocus[0] = -1; paintG[0].run(); Toast.makeText(this, "Todos ocultos: escolhe os que queres mostrar", Toast.LENGTH_LONG).show(); }));
        gr.addView(btn("Repor ordem", v -> { data.resetOrder(); opCache = null; gfocus[0] = -1; paintG[0].run(); }));
        gbox.addView(gr);
        gbox.addView(gl);
        paintG[0].run();

        /* ---- Ocultos ---- */
        f.addView(head("Ocultos"));
        f.addView(note("Para ocultar ou ordenar: mantém OK (ou Menu) num canal, filme ou série, ou numa categoria no Explorar."));
        final LinearLayout hl = new LinearLayout(this); hl.setOrientation(LinearLayout.VERTICAL);
        f.addView(hl);
        final Runnable[] paintH = new Runnable[1];
        paintH[0] = () -> {
            hl.removeAllViews();
            int n = data.hiddenItemsCount();
            LinearLayout r0 = new LinearLayout(this); r0.setGravity(Gravity.CENTER_VERTICAL);
            TextView t0 = new TextView(this); t0.setText(n + (n == 1 ? " canal/filme oculto" : " canais/filmes ocultos")); t0.setTextColor(TXT); t0.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(16));
            r0.addView(t0, new LinearLayout.LayoutParams(0, -2, 1));
            if (n > 0) r0.addView(btn("👁 Mostrar todos", v -> { data.showAllItems(); opCache = null; paintH[0].run(); }));
            hl.addView(r0);
            for (final String[] c : data.hiddenCats()) {
                LinearLayout r = new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(0, dp(3), 0, dp(3));
                TextView t = new TextView(this); t.setText(("live".equals(c[0]) ? "📺 " : "movie".equals(c[0]) ? "🎬 " : "🎞️ ") + c[1]); t.setTextColor(TXT); t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(16));
                r.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
                r.addView(btn("👁 Mostrar", v -> { data.showCat(c[0], c[1]); opCache = null; paintH[0].run(); }));
                hl.addView(r);
            }
        };
        paintH[0].run();
        }
        if ("video".equals(pg)) {
        /* ---- Imagem ---- */
        f.addView(head("Imagem"));
        f.addView(label("Ajustar a taxa de atualização da TV ao vídeo (25/50/60 Hz)"));
        f.addView(choice(new String[]{"Ligado", "Desligado"}, np0().getBoolean("afr", true) ? 0 : 1, w -> { np0().edit().putBoolean("afr", w == 0).apply(); applyPlayerPrefs(); }));
        f.addView(note("Recomendado: Ligado. Alinha o ecrã a 25/50 Hz com o vídeo e reduz o efeito de ‘saltos’ em desporto."));
        f.addView(label("Desentrelaçamento (canais 1080i / 576i, ex.: Sport TV)"));
        f.addView(choice(new String[]{"Desligado", "Pela TV (túnel)", "Adaptativo", "Por linhas", "Mistura"}, indexOfS(DEINT_KEYS, deintModePref()), w -> {
            String m = DEINT_KEYS[w];
            np0().edit().putString("deintMode", m).putBoolean("deint", m.equals("adapt") || m.equals("lines") || m.equals("blend")).apply();
            applyPlayerPrefs();
            if (m.equals("tv")) Toast.makeText(this, "Pela TV: o vídeo vai direto para o processador de imagem da TV (aplica ao abrir o próximo canal).", Toast.LENGTH_LONG).show();
        }));
        f.addView(note("Pela TV: usa o desentrelaçamento da própria TV (melhor qualidade, se a TV suportar o modo túnel). Adaptativo: só corrige onde há riscas. Por linhas: tira sempre as riscas, com um pouco menos de detalhe. Mistura: junta as duas metades da imagem, mais suave."));
        f.addView(label("Nitidez em canais SD (720x576)"));
        f.addView(choice(new String[]{"Desligada", "Média", "Forte"}, cl(np0().getInt("sdSharp", 0), 3), w -> { np0().edit().putInt("sdSharp", w).apply(); applyPlayerPrefs(); }));
        f.addView(label("Formato da imagem ao entrar em ecrã total (filmes e séries — os canais abrem sempre esticados)"));
        f.addView(choice(new String[]{"Ajustar", "Zoom", "Esticar", "16:9", "4:3", "21:9"}, np0().getInt("aspectFull", 2), w -> np0().edit().putInt("aspectFull", w).apply()));
        f.addView(label("Vista do vídeo (se houver ecrã preto com som ou imagem a piscar)"));
        f.addView(choice(new String[]{"Automático", "Sempre compatível"}, np0().getBoolean("tvTexture", false) ? 1 : 0, w -> { np0().edit().putBoolean("tvTexture", w == 1).putBoolean("tvTextureUser", true).apply(); Toast.makeText(this, "Fecha e reabre a app para aplicar.", Toast.LENGTH_LONG).show(); }));
        f.addView(note("Automático = SurfaceView (recomendado na Bravia). «Sempre compatível» = TextureView, só se houver ecrã preto."));
        f.addView(label("Modo túnel (som e imagem pela TV; só se a TV o suportar bem)"));
        f.addView(choice(new String[]{"Desligado", "Ligado"}, np0().getBoolean("tunnel", false) ? 1 : 0, w -> np0().edit().putBoolean("tunnel", w == 1).apply()));
        f.addView(label("TsFix (correções MPEG-TS / PTS / SPS 1080i)"));
        f.addView(choice(new String[]{"Ligado", "Desligado"}, np0().getBoolean("tsFix", true) ? 0 : 1, w -> {
            np0().edit().putBoolean("tsFix", w == 0).apply();
            Toast.makeText(this, "TsFix " + (w == 0 ? "ligado" : "desligado") + " — reabre o canal para aplicar.", Toast.LENGTH_LONG).show();
        }));
        f.addView(note("Obrigatório em canais 1080i (Sport TV / Eleven em AVC): sem TsFix a imagem fica a ~1 fps. Desliga só para diagnóstico."));
        f.addView(label("Lista de canais em ecrã total (OK abre a lista)"));
        f.addView(choice(new String[]{"Lista de onde veio o canal", "Desligada"}, "off".equals(np0().getString("fsList", "all")) ? 1 : 0, w -> np0().edit().putString("fsList", w == 1 ? "off" : "all").apply()));
        f.addView(label("Tamanho da interface"));
        LinearLayout zr = new LinearLayout(this); zr.setGravity(Gravity.CENTER_VERTICAL);
        final TextView zv = new TextView(this); zv.setTextColor(TXT); zv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(17)); zv.setPadding(dp(14), 0, dp(14), 0);
        zv.setText(Math.round(MainActivity.uiScaleOf(this) * 100) + " %");
        zr.addView(btn("−", v -> setUi(-0.1f)));
        zr.addView(zv);
        zr.addView(btn("+", v -> setUi(0.1f)));
        zr.addView(btn("Automático", v -> { np0().edit().remove("uiScale").apply(); getSharedPreferences("nativeapp", 0).edit().remove("phZoom").apply(); recreate(); }));
        f.addView(zr);

        }
        if ("look".equals(pg)) {
            final android.content.SharedPreferences lsp = getSharedPreferences("nativeapp", 0);
            f.addView(head("Aspeto"));
            f.addView(note("Cada alteração é aplicada logo; o ecrã é redesenhado e volta a esta página."));
            f.addView(label("Cor de destaque (botões, seleção, relógio)"));
            final String[] al = new String[ACCENTS.length]; for (int i = 0; i < al.length; i++) al[i] = (String) ACCENTS[i][0];
            f.addView(choice(al, lsp.getInt("lkAcc", 0), w -> { lsp.edit().putInt("lkAcc", w).apply(); lookApplied(); }));
            f.addView(label("Fundo e cartões"));
            final String[] bl = new String[BGS.length]; for (int i = 0; i < bl.length; i++) bl[i] = (String) BGS[i][0];
            f.addView(choice(bl, lsp.getInt("lkBg", 0), w -> { lsp.edit().putInt("lkBg", w).apply(); lookApplied(); }));
            f.addView(label("Cor dos ícones (barra de cima e botões)"));
            f.addView(choice(ICON_MODES, lsp.getInt("lkIcM", 0), w -> { lsp.edit().putInt("lkIcM", w).apply(); lookApplied(); }));
            f.addView(label("Tamanho dos ícones"));
            f.addView(choice(ICON_SIZES, lsp.getInt("lkIcS", 1), w -> { lsp.edit().putInt("lkIcS", w).apply(); lookApplied(); }));
            LinearLayout lr = new LinearLayout(this); lr.setPadding(0, dp(14), 0, 0);
            lr.addView(btn("↺ Repor aspeto original", v -> { lsp.edit().remove("lkAcc").remove("lkBg").remove("lkIcM").remove("lkIcS").apply(); lookApplied(); }));
            f.addView(lr);
        }
        if ("backup".equals(pg)) {
            f.addView(head("Cópia de segurança"));
            f.addView(note("Guarda tudo num só ficheiro: lista IPTV (com utilizador e palavra-passe), favoritos, vistos, posições, ordem, países e ocultos, operador, vídeo, som e acertos. Guarda o ficheiro num sítio seguro: contém os teus dados de acesso."));
            LinearLayout b1 = new LinearLayout(this); b1.setPadding(0, dp(10), 0, 0);
            b1.addView(btn("💾 Exportar (Transferências)", v -> backupExport(false)));
            b1.addView(btn("📤 Exportar para…", v -> backupExport(true)));
            f.addView(b1);
            LinearLayout b2 = new LinearLayout(this); b2.setPadding(0, dp(10), 0, 0);
            b2.addView(btn("📥 Importar de um ficheiro…", v -> backupPick()));
            b2.addView(btn("📂 Importar da pasta da app", v -> backupFromAppDir()));
            f.addView(b2);
            f.addView(note("Exportar (Transferências) guarda em Transferências/cockpit-tv-backup-….json e uma cópia na pasta da app. Importar substitui as definições atuais e reinicia o ecrã."));
        }
        if ("sound".equals(pg)) {
        /* ---- Som ---- */
        f.addView(head("Som"));
        f.addView(label("Som Dolby (AC-3 / E-AC-3)"));
        boolean dsw = np0().contains("dolbySw") ? np0().getBoolean("dolbySw", false) : !isTv();
        f.addView(choice(new String[]{"Descodificado pela app (FFmpeg)", "Pelo aparelho / passthrough"}, dsw ? 0 : 1, w -> np0().edit().putBoolean("dolbySw", w == 0).apply()));
        f.addView(label("Som ao deslizar nos cartões (fila sobreposta)"));
        f.addView(choice(new String[]{"Sim", "Não"}, np0().getBoolean("tvSomCartoes", true) ? 0 : 1, w -> np0().edit().putBoolean("tvSomCartoes", w == 0).apply()));
        f.addView(label("Acerto do som em relação à imagem (para a saída de som atual)"));
        LinearLayout ar = new LinearLayout(this); ar.setGravity(Gravity.CENTER_VERTICAL);
        final TextView av = new TextView(this); av.setTextColor(TXT); av.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(17)); av.setPadding(dp(14), 0, dp(14), 0);
        final Runnable avShow = () -> av.setText((NativePlayer.avOffsetMs > 0 ? "+" : "") + NativePlayer.avOffsetMs + " ms" + (NativePlayer.avOffsetMs < 0 ? " (som mais tarde)" : NativePlayer.avOffsetMs > 0 ? " (som mais cedo)" : ""));
        ar.addView(btn("−100", v -> { avStep(-100); avShow.run(); }));
        ar.addView(btn("−20", v -> { avStep(-20); avShow.run(); }));
        ar.addView(av);
        ar.addView(btn("+20", v -> { avStep(20); avShow.run(); }));
        ar.addView(btn("+100", v -> { avStep(100); avShow.run(); }));
        ar.addView(btn("0", v -> { avStep(-NativePlayer.avOffsetMs); avShow.run(); }));
        HorizontalScrollView arh = new HorizontalScrollView(this); arh.addView(ar); f.addView(arh);
        try { if (np != null) np.loadAv(); } catch (Throwable ignored) { }
        avShow.run();
        f.addView(note("O valor fica guardado para cada tipo de som (Dolby / estéreo) e saída (altifalante / Bluetooth). No ecrã do vídeo também o podes mudar em Áudio."));
        f.addView(label("Som na pré-visualização do Início"));
        f.addView(choice(new String[]{"Sem som", "Com som"}, pvSnd() ? 1 : 0, w -> { getSharedPreferences("nativeapp", 0).edit().putBoolean("tvPrevSnd", w == 1).apply(); if (np != null && pvUrl != null) np.volume(w == 1 ? 1f : 0f); }));

        /* ---- Legendas ---- */
        f.addView(head("Legendas"));
        f.addView(label("Tamanho")); f.addView(choice(SUB_SIZE_L, subPref("size", 1), w -> setSubPref("size", w)));
        f.addView(label("Cor")); f.addView(choice(SUB_COL_L, subPref("color", 0), w -> setSubPref("color", w)));
        f.addView(label("Fundo")); f.addView(choice(SUB_BG_L, subPref("bg", 1), w -> setSubPref("bg", w)));
        f.addView(label("Contorno")); f.addView(choice(SUB_EDGE_L, subPref("edge", 1), w -> setSubPref("edge", w)));
        f.addView(label("Posição")); f.addView(choice(SUB_POS_L, subPref("pos", 0), w -> setSubPref("pos", w)));

        /* v347: a opção era uma caixa de visto que o comando da TV não conseguia marcar e só ficava guardada com o botão; agora é uma escolha normal, guardada logo */
        f.addView(head("Legendas online em português"));
        f.addView(label("Pôr legendas em português automaticamente nos filmes e séries"));
        f.addView(choice(new String[]{"Desligado", "Ligado"}, data.osAuto() ? 1 : 0, w -> data.setOsAuto(w == 1)));
        f.addView(note("Não precisa de conta nem de chave: a app procura sozinha as legendas pelo título (português de Portugal primeiro; do Brasil se não houver). No ecrã do vídeo, Legendas → 🌐 online mostra a lista para escolheres outra."));
        f.addView(head("Conta OpenSubtitles (opcional)"));
        f.addView(note("Só se quiseres mais resultados, com o nome da versão do ficheiro. Pode ficar vazio."));
        final EditText ok = field(f, "Chave da API (opensubtitles.com → Consumers)", data.osKey(), false);
        final EditText ou = field(f, "Utilizador", data.osUser(), false);
        final EditText op = field(f, "Palavra-passe", data.osPass(), true);
        LinearLayout row2 = new LinearLayout(this); row2.setPadding(0, dp(8), 0, 0);
        row2.addView(btn("Guardar conta", v -> { data.saveOs(ok.getText().toString(), ou.getText().toString(), op.getText().toString(), data.osAuto()); Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show(); }));
        f.addView(row2);

        }
        if ("vod".equals(pg)) {
        f.addView(head("Filmes e séries"));
        LinearLayout row3 = new LinearLayout(this); row3.setPadding(0, dp(4), 0, 0);
        row3.addView(btn("Limpar «Continuar a ver»", v -> {
            getSharedPreferences("nativeapp", 0).edit().putString("pos", "{}").putString("slast", "{}").apply();
            Toast.makeText(this, "Limpo", Toast.LENGTH_SHORT).show();
        }));
        row3.addView(btn("Limpar marcas de visto", v -> { getSharedPreferences("nativeapp", 0).edit().putString("watched", "{}").apply(); Toast.makeText(this, "Limpo", Toast.LENGTH_SHORT).show(); }));
        f.addView(row3);

        }
        if ("parental".equals(pg)) {   /* v366: controlo parental por PIN e palavras */
            f.addView(head("Controlo parental"));
            f.addView(note("Canais, filmes e séries cujo nome ou categoria contenha uma destas palavras pedem o PIN para abrir ou ver. Depois de introduzido, fica desbloqueado até fechares a app."));
            final EditText words = field(f, "Palavras a bloquear, separadas por vírgula (ex.: adultos, +18, xxx)", parSp().getString("parWords", ""), false);
            f.addView(btn("Guardar palavras", v -> { parSp().edit().putString("parWords", words.getText().toString()).apply(); parUnlocked = false; Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show(); }));
            f.addView(btn(parSp().contains("parPin") ? "Alterar PIN" : "Definir PIN", v -> parSetPin()));
            if (parSp().contains("parPin")) f.addView(btn("Remover PIN", v -> { parSp().edit().remove("parPin").apply(); parUnlocked = false; Toast.makeText(this, "PIN removido", Toast.LENGTH_SHORT).show(); }));
        }
        if ("diag".equals(pg)) {
        /* ---- Diagnóstico do vídeo (como na app antiga: ver, copiar e enviar o registo para o GitHub) ---- */
        f.addView(head("Diagnóstico do vídeo"));
        f.addView(note("Vê um canal, deixa acontecer o problema, volta aqui e toca em Atualizar ou em Enviar para o GitHub."));
        final TextView dgOut = new TextView(this);
        dgOut.setTextColor(0xFFCFE0F2); dgOut.setTypeface(Typeface.MONOSPACE); dgOut.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(12)); dgOut.setTextIsSelectable(true);
        dgOut.setText("(toca em Atualizar)");
        final TextView dgMsg = note("");
        LinearLayout dr = new LinearLayout(this); dr.setPadding(0, dp(4), 0, dp(4));
        dr.addView(btn("Atualizar", v -> dgOut.setText(diagText())));
        dr.addView(btn("Copiar", v -> { try { ((android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("registo", diagText())); Toast.makeText(this, "Copiado.", Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) { } }));
        Button gh = btn("Enviar para o GitHub", v -> sendLog(dgMsg));
        gh.setBackground(sel(0xFF2B6CB0, 12));
        dr.addView(gh);
        HorizontalScrollView drh = new HorizontalScrollView(this); drh.addView(dr); f.addView(drh);
        f.addView(dgMsg);
        final EditText rp = field(f, "Repositório dos registos", getSharedPreferences("nativeapp", 0).getString("dbgRepo", "ramarozte-sketch/cockpit-logs"), false);
        final EditText tk = field(f, "Token do GitHub (só fica neste aparelho; «Contents: Read and write» só nesse repositório)", getSharedPreferences("nativeapp", 0).getString("dbgTok", ""), true);
        rp.setOnFocusChangeListener((v, fo) -> { if (!fo) getSharedPreferences("nativeapp", 0).edit().putString("dbgRepo", rp.getText().toString().trim()).apply(); });
        tk.setOnFocusChangeListener((v, fo) -> { if (!fo) getSharedPreferences("nativeapp", 0).edit().putString("dbgTok", tk.getText().toString().trim()).apply(); });
        tk.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence q, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence q, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) { getSharedPreferences("nativeapp", 0).edit().putString("dbgTok", e.toString().trim()).apply(); }
        });
        rp.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence q, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence q, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) { getSharedPreferences("nativeapp", 0).edit().putString("dbgRepo", e.toString().trim()).apply(); }
        });
        ScrollView dgs = new ScrollView(this); dgs.setNestedScrollingEnabled(true); dgs.setBackground(pill(0xCC0B1220, 10)); dgs.setPadding(dp(12), dp(10), dp(12), dp(10));
        dgs.setFocusable(true);
        dgs.addView(dgOut);
        LinearLayout.LayoutParams dgl = new LinearLayout.LayoutParams(-1, dp(320)); dgl.topMargin = dp(10);
        f.addView(dgs, dgl);

        TextView ver = new TextView(this);
        String vn = ""; try { vn = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Throwable ignored) { }
        ver.setText("Cockpit TV · " + vn + "\nNo ecrã do vídeo: Áudio (faixas, Dolby e atraso do som), Legendas (embutidas e 🌐 online), ⧉ vários ecrãs e 📡 Transmitir.");
        ver.setTextColor(MUT); ver.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(12)); ver.setPadding(0, dp(18), 0, 0);
        f.addView(ver);

        }

        settingsView = sv;
        body.addView(sv, new LinearLayout.LayoutParams(-1, -1));
        ui.post(() -> { View c0 = findFocusable(f, 1); if (c0 != null) c0.requestFocus(); });
    }
    /* ------------------------------------------------------------ v320: TV Direto (canais do sintonizador da TV e da lista Sony Bravia) */
    private LinearLayout tvlList; private TextView tvlMsg; private int tvlGen = 0;
    private void showTvLive() {
        closeDetails(); stopPreview();
        if (settingsView != null) { body.removeView(settingsView); settingsView = null; }
        catList.setVisibility(View.GONE); grid.setVisibility(View.GONE); searchRow.setVisibility(View.GONE); statusRow.setVisibility(View.GONE);
        ScrollView sv = new ScrollView(this);
        final LinearLayout f = new LinearLayout(this); f.setOrientation(LinearLayout.VERTICAL); f.setPadding(dp(20), dp(8), dp(20), dp(30));
        sv.addView(f);
        TextView title = new TextView(this); title.setText("📡 TV Direto"); title.setTextColor(TXT); title.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(28)); title.setTypeface(null, Typeface.BOLD);
        f.addView(title);
        tvlMsg = note("");
        f.addView(tvlMsg);
        LinearLayout bar = new LinearLayout(this); bar.setPadding(0, dp(8), 0, dp(6));
        bar.addView(btn("▶ Abrir TV em direto", v -> { if (!TvLive.openLive(this)) Toast.makeText(this, "Não encontrei a app de TV desta TV.", Toast.LENGTH_LONG).show(); }));
        bar.addView(btn("↻ Recarregar canais", v -> tvlLoad()));
        f.addView(bar);
        f.addView(head("Canais da TV (Sony Bravia)"));
        f.addView(note("Opcional: com o IP da TV e a Pre-Shared Key (Definições › Rede › Controlo IP) a app lê a lista de canais da Sony e sintoniza-os."));
        final SharedPreferences np = getSharedPreferences("nativeapp", 0);
        String ip0 = np.getString("brIp", ""); if (ip0.isEmpty()) ip0 = TvLive.lanIp();
        final EditText eip = field(f, "IP da TV (ex.: 192.168.1.50)", ip0, false);
        final EditText epsk = field(f, "Pre-Shared Key", np.getString("brPsk", ""), true);
        LinearLayout b2 = new LinearLayout(this); b2.setPadding(0, dp(8), 0, dp(10));
        b2.addView(btn("Guardar e carregar", v -> { np.edit().putString("brIp", eip.getText().toString().trim()).putString("brPsk", epsk.getText().toString().trim()).apply(); tvlLoad(); }));
        b2.addView(btn("Limpar", v -> { np.edit().remove("brIp").remove("brPsk").apply(); eip.setText(""); epsk.setText(""); tvlLoad(); }));
        f.addView(b2);
        f.addView(head("Numeração e painel"));
        final EditText efrom = field(f, "Mostrar os canais a partir do número (vazio = todos)", np.getInt("tvlFrom", 0) > 0 ? String.valueOf(np.getInt("tvlFrom", 0)) : "", false);
        efrom.setInputType(android.text.InputType.TYPE_CLASS_NUMBER);
        LinearLayout b3 = new LinearLayout(this); b3.setPadding(0, dp(8), 0, dp(6));
        b3.addView(btn("Aplicar número", v -> { int n = 0; try { n = Integer.parseInt(efrom.getText().toString().trim()); } catch (Throwable ignored) { } np.edit().putInt("tvlFrom", Math.max(0, n)).apply(); tvlLoad(); }));
        final Button ovb = btn("", null);
        final Runnable ovShow = () -> ovb.setText("Painel por cima da TV: " + (np.getBoolean("brOverlay", true) ? "Ligado" : "Desligado"));
        ovb.setOnClickListener(v -> {
            boolean on = !np.getBoolean("brOverlay", true); np.edit().putBoolean("brOverlay", on).apply(); ovShow.run();
            if (on && !overlayOk()) { try { startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()))); } catch (Throwable ignored) { } }
            tvlMsg.setText(!on ? "Painel desligado: OK num canal muda a TV para esse canal (sem painel)." : overlayOk() ? "OK num canal: a TV sintoniza-o e o painel do Cockpit aparece à esquerda (OK muda, CH+/CH− zapping, Voltar fecha)."
                    : "Falta a permissão «Sobrepor a outras apps». Se a TV não abrir esse ecrã, ativa-a uma vez a partir de um PC:  adb connect " + eip.getText() + "  e  adb shell appops set pt.rui.cockpittv SYSTEM_ALERT_WINDOW allow");
        });
        ovShow.run();
        b3.addView(ovb);
        b3.addView(btn("Fechar painel", v -> { try { TvOverlayService.stop(this); } catch (Throwable ignored) { } Toast.makeText(this, "Painel fechado", Toast.LENGTH_SHORT).show(); }));
        f.addView(b3);
        f.addView(note("Com a lista da Sony ligada, ao escolher um canal a TV sintoniza-o e a lista de canais aparece à esquerda por cima da imagem: OK muda de canal, CH+/CH− faz zapping, Voltar fecha. Passados 5 s a lista esconde-se e volta com qualquer seta."));
        tvlList = new LinearLayout(this); tvlList.setOrientation(LinearLayout.VERTICAL);
        f.addView(tvlList);
        settingsView = sv;
        body.addView(sv, new LinearLayout.LayoutParams(-1, -1));
        tvlLoad();
        ui.post(() -> { View c0 = findFocusable(f, 1); if (c0 != null) c0.requestFocus(); });
    }
    private boolean overlayOk() { return android.os.Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(this); }
    private void tvlLoad() {
        final int my = ++tvlGen;
        final SharedPreferences np = getSharedPreferences("nativeapp", 0);
        final String ip = np.getString("brIp", "").trim(), psk = np.getString("brPsk", "").trim();
        tvlList.removeAllViews();
        tvlMsg.setText(ip.isEmpty() || psk.isEmpty() ? "A ler os canais do sintonizador da TV…" : "A ligar à TV em " + ip + "…");
        bg.execute(() -> {
            final boolean br = !ip.isEmpty() && !psk.isEmpty();
            List<String[]> items = new ArrayList<>(); String msg = "";
            if (br) {
                String[] err = {null}; items = TvLive.braviaItems(ip, psk, err);
                msg = items.isEmpty() ? "Falhou: " + (err[0] == null ? "a TV respondeu mas sem canais nesta lista." : err[0]) : items.size() + " itens da lista da TV (canais e entradas). OK para ver.";
            } else {
                try { for (String[] c : TvLive.tunerChannels(this)) items.add(new String[]{c[0], c[1].isEmpty() ? "Canal " + c[2] : c[1], c[2]}); }
                catch (Throwable e) { msg = "A TV não deixou a app ler os canais (" + e.getMessage() + "). Usa «Abrir TV em direto» ou configura o IP e a chave da Sony abaixo."; }
                if (msg.isEmpty()) msg = items.isEmpty() ? "Não encontrei canais acessíveis. Se a TV tem sintonizador, a app de TV do sistema pode não os partilhar. Usa «Abrir TV em direto» ou a lista Sony." : items.size() + " canais da TV. OK para ver.";
            }
            final int from = np.getInt("tvlFrom", 0);
            if (from > 0) { List<String[]> fl = new ArrayList<>(); for (String[] c : items) { double n; try { n = Double.parseDouble(c[0].trim()); } catch (Throwable e) { fl.add(c); continue; } if (n >= from) fl.add(c); } msg = (msg.isEmpty() ? "" : msg + " ") + "(a partir do canal " + from + ": " + fl.size() + ")"; items = fl; }
            final List<String[]> fi = items; final String fm = msg;
            ui.post(() -> { if (my != tvlGen || tvlList == null) return; tvlMsg.setText(fm); tvlPaint(fi, br, ip, psk, my); });
        });
    }
    private void tvlPaint(final List<String[]> items, final boolean br, final String ip, final String psk, final int my) {
        final int[] ix = {0};
        final Runnable[] ch = new Runnable[1];
        ch[0] = () -> {
            if (my != tvlGen || tvlList == null) return;
            int end = Math.min(items.size(), ix[0] + 60);
            while (ix[0] < end) {
                LinearLayout row = new LinearLayout(this);
                for (int k = 0; k < 3; k++) {
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(46), 1); lp.rightMargin = dp(8); lp.bottomMargin = dp(8);
                    if (ix[0] >= items.size()) { row.addView(new View(this), lp); continue; }
                    final String[] c = items.get(ix[0]++);
                    Button b = new Button(this); b.setAllCaps(false); b.setText(c[0] + "   " + c[1]); b.setTextColor(TXT); b.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(15));
                    b.setGravity(Gravity.CENTER_VERTICAL | Gravity.LEFT); b.setSingleLine(true); b.setEllipsize(android.text.TextUtils.TruncateAt.END); b.setStateListAnimator(null);
                    b.setBackground(sel(0xFF1F2B38, 12)); b.setPadding(dp(14), 0, dp(14), 0);
                    b.setOnClickListener(v -> {
                        if (br && getSharedPreferences("nativeapp", 0).getBoolean("brOverlay", true) && overlayOk() && !"↪".equals(c[0])) {
                            try {
                                JSONArray ls = new JSONArray();
                                for (String[] x : items) if (!"↪".equals(x[0])) ls.put(new JSONObject().put("num", x[0]).put("name", x[1]).put("uri", x[2]));
                                TvOverlayService.start(this, ip, psk, ls.toString(), c[2]);
                                Toast.makeText(this, "A sintonizar " + c[1] + " com o painel por cima…", Toast.LENGTH_LONG).show();
                            } catch (Throwable e) { Toast.makeText(this, "Não consegui abrir o painel: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
                        }
                        else if (br) bg.execute(() -> { final String r = TvLive.braviaPlay(ip, psk, c[2]); ui.post(() -> Toast.makeText(this, "ok".equals(r) ? "A abrir " + c[1] + "…" : r, Toast.LENGTH_LONG).show()); });
                        else { String r = TvLive.tune(this, Long.parseLong(c[2])); Toast.makeText(this, "ok".equals(r) ? "A abrir " + c[1] + "…" : "app".equals(r) ? "Abri a app de TV: escolhe lá o canal." : "Não consegui abrir o canal.", Toast.LENGTH_LONG).show(); }
                    });
                    row.addView(b, lp);
                }
                tvlList.addView(row);
            }
            if (ix[0] < items.size()) ui.post(ch[0]);
        };
        ch[0].run();
    }
    private int setLast = 0;
    /** v325: guarda a página e redesenha com o novo aspeto */
    private void lookApplied() {
        getSharedPreferences("nativeapp", 0).edit().putString("reopenSet", "look").apply();
        recreate();
    }
    private void openSetPage(String pg) {
        if (!pg.isEmpty()) { for (int i = 0; i < SET_PAGES.length; i++) if (SET_PAGES[i][0].equals(pg)) setLast = i; }
        setPage = pg;
        if (settingsView != null) { body.removeView(settingsView); settingsView = null; }
        showSettings();
    }
    /** n-ésima vista focável (0 = primeira) dentro de v. */
    private View findFocusable(View root0, int n) {
        java.util.ArrayList<View> l = new java.util.ArrayList<>();
        root0.addFocusables(l, View.FOCUS_DOWN);
        if (l.isEmpty()) return null;
        return l.get(Math.max(0, Math.min(n, l.size() - 1)));
    }

    private TextView head(String s) {
        TextView h = new TextView(this);
        h.setText(s); h.setTextColor(TXT); h.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(19)); h.setTypeface(null, Typeface.BOLD); h.setPadding(0, dp(16), 0, dp(2));
        return h;
    }

    /** Informação da app, das listas e do registo do leitor. */
    private String diagText() {
        StringBuilder b = new StringBuilder();
        String vn = ""; try { vn = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Throwable ignored) { }
        android.util.DisplayMetrics m = getResources().getDisplayMetrics();
        Runtime rt = Runtime.getRuntime();
        b.append("Cockpit TV nativo ").append(vn).append(" · ").append(android.os.Build.MANUFACTURER).append(" ").append(android.os.Build.MODEL).append(" · Android ").append(android.os.Build.VERSION.RELEASE).append("\n");
        b.append("ecrã ").append(m.widthPixels).append("x").append(m.heightPixels).append(" · escala ").append(Math.round(S * 100)).append(" % · memória ").append((rt.totalMemory() - rt.freeMemory()) >> 20).append("/").append(rt.maxMemory() >> 20).append(" MB\n");
        for (String k : new String[]{"live", "movie", "series"}) { List<NativeData.Item> l = data.all.get(k); b.append(k).append(": ").append(l == null ? "não carregado" : l.size() + " itens").append(data.cacheFresh(k) ? " (cache recente)" : "").append(" · "); }
        b.append("operador: ").append(data.opKey().isEmpty() ? "desligado" : data.opKey()).append("\n");
        b.append("imagem: taxa auto ").append(np0().getBoolean("afr", true) ? "sim" : "não").append(" · desentrelaçar ").append(deintModePref()).append(" · nitidez SD ").append(np0().getInt("sdSharp", 0)).append(" · túnel ").append(np0().getBoolean("tunnel", false) ? "sim" : "não").append(" · TsFix ").append(np0().getBoolean("tsFix", true) ? "sim" : "não").append(" · Dolby pela app ").append(np0().contains("dolbySw") ? np0().getBoolean("dolbySw", false) : !isTv()).append("\n\n");
        b.append(NativeData.previousSession(70));
        synchronized (NativeData.DBG) { for (String l : NativeData.DBG) b.append(l).append("\n"); }
        b.append(np == null ? "(leitor ainda não iniciado: vê um canal primeiro)" : np.dbgDump());
        return scrub(b.toString());
    }
    /** Tira utilizador, palavra-passe e tokens do registo. */
    private String scrub(String t) {
        t = t.replaceAll("(?i)(/(?:live|movie|series|timeshift)/)([^/?#\\s]+)/([^/?#\\s]+)/", "$1•••/•••/");
        t = t.replaceAll("(?i)([?&](?:username|password|user|pass|pwd|passwd|token|key|k|auth|apikey|api_key|access_token|signature|sig)=)[^&#\"\\s]*", "$1•••");
        t = t.replaceAll("(?i)(Bearer\\s+)[\\w.\\-]+", "$1•••");
        for (String x : new String[]{data.user, data.pass, data.osKey(), data.osPass(), getSharedPreferences("nativeapp", 0).getString("dbgTok", "")}) {
            if (x != null && x.length() >= 4) { t = t.replace(x, "•••"); try { String e = java.net.URLEncoder.encode(x, "UTF-8"); if (!e.equals(x)) t = t.replace(e, "•••"); } catch (Throwable ignored) { } }
        }
        return t;
    }
    /** Envia o registo para o repositório de registos (logs/AAAA-MM-DD_HHMMSS_tv.json), como a app antiga. */
    private void sendLog(final TextView msg) {
        final String tok = getSharedPreferences("nativeapp", 0).getString("dbgTok", "").trim();
        final String repo = getSharedPreferences("nativeapp", 0).getString("dbgRepo", "ramarozte-sketch/cockpit-logs").trim();
        if (tok.isEmpty()) { msg.setText("Falta o token do GitHub (campo aqui por baixo)."); return; }
        msg.setText("A enviar…");
        final String text = diagText();
        final NativeData.Item ch = nowItem != null ? nowItem : (data.recents().isEmpty() ? null : data.recents().get(0));
        bg.execute(() -> {
            String res;
            try {
                JSONObject rep = new JSONObject();
                String vn = ""; try { vn = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Throwable ignored) { }
                rep.put("ambiente", new JSONObject().put("versao", vn).put("app", "Cockpit TV (nativa)").put("quando", new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", java.util.Locale.US).format(new java.util.Date()))
                        .put("aparelho", android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL + " · Android " + android.os.Build.VERSION.RELEASE)
                        .put("ecra", getResources().getDisplayMetrics().widthPixels + "x" + getResources().getDisplayMetrics().heightPixels));
                if (ch != null) rep.put("canal", new JSONObject().put("nome", ch.name).put("tipo", ch.kind).put("grupo", ch.group).put("url", ch.url));
                JSONArray nat = new JSONArray(); String[] lines = text.split("\n"); for (int i = Math.max(0, lines.length - 420); i < lines.length; i++) nat.put(lines[i]);
                rep.put("nativo", nat); rep.put("motivo", "manual (app TV nativa)");
                String body = scrub(rep.toString(1));
                String name = new java.text.SimpleDateFormat("yyyy-MM-dd_HHmmss", java.util.Locale.US).format(new java.util.Date()) + "_tv.json";
                HttpURLConnection c = (HttpURLConnection) new URL("https://api.github.com/repos/" + repo + "/contents/logs/" + name).openConnection();
                c.setRequestMethod("PUT"); c.setDoOutput(true); c.setConnectTimeout(10000); c.setReadTimeout(20000);
                c.setRequestProperty("Authorization", "Bearer " + tok); c.setRequestProperty("Accept", "application/vnd.github+json"); c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28"); c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("User-Agent", "CockpitTV");
                String payload = new JSONObject().put("message", "Registo da app TV " + name).put("content", android.util.Base64.encodeToString(body.getBytes("UTF-8"), android.util.Base64.NO_WRAP)).toString();
                c.getOutputStream().write(payload.getBytes("UTF-8"));
                int code = c.getResponseCode();
                if (code >= 200 && code < 300) res = "Enviado ✓ logs/" + name;
                else res = "GitHub " + code + (code == 404 ? " (o repositório não existe ou o token não tem acesso)" : code == 401 ? " (token inválido ou expirado)" : "");
                c.disconnect();
            } catch (Throwable e) { res = "Não consegui enviar: " + e.getMessage(); }
            final String fr = res;
            ui.post(() -> { msg.setText(fr); if (fr.startsWith("Enviado")) Toast.makeText(this, "Registo enviado para o GitHub ✓", Toast.LENGTH_SHORT).show(); });
        });
    }

    private interface Pick { void on(int w); }
    /** Fila de botões de escolha (o escolhido em azul, como na app antiga). */
    private View choice(final String[] labels, int cur, final Pick p) {
        HorizontalScrollView hs = new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); hs.setClipToPadding(false);
        final LinearLayout r = new LinearLayout(this); r.setPadding(0, dp(4), 0, dp(6)); r.setClipChildren(false);
        final int[] sel = {Math.max(0, Math.min(labels.length - 1, cur))};
        for (int i = 0; i < labels.length; i++) {
            final int w = i;
            final TextView b = thBtn(labels[i], null, i == sel[0], null);
            b.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(15)); b.setMinHeight(dp(40));
            b.setOnClickListener(v -> { sel[0] = w; for (int j = 0; j < r.getChildCount(); j++) setPrimary((TextView) r.getChildAt(j), null, j == w); p.on(w); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(42)); lp.rightMargin = dp(10);
            r.addView(b, lp);
        }
        hs.addView(r);
        return hs;
    }
    private TextView label(String s) { TextView t = new TextView(this); t.setText(s); t.setTextColor(TXT); t.setAlpha(0.9f); t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(15)); t.setPadding(0, dp(10), 0, dp(2)); return t; }
    private TextView note(String s) { TextView t = new TextView(this); t.setText(s); t.setTextColor(MUT); t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(13)); t.setPadding(0, dp(2), 0, dp(4)); return t; }
    private static int indexOfS(String[] a, String v) { for (int i = 0; i < a.length; i++) if (a[i].equals(v)) return i; return 0; }
    private boolean isTv() { try { android.app.UiModeManager um = (android.app.UiModeManager) getSystemService(UI_MODE_SERVICE); return um != null && um.getCurrentModeType() == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION; } catch (Throwable e) { return false; } }
    private void setUi(float d) {
        float v = Math.max(0.5f, Math.min(1.6f, MainActivity.uiScaleOf(this) + d));
        np0().edit().putFloat("uiScale", v).apply();
        recreate();
    }
    /** Acerto do som: precisa do leitor para saber a saída atual (altifalante / Bluetooth, Dolby / estéreo). */
    private void avStep(int d) {
        try {
            if (np == null) { np = new NativePlayer(this, root, (k, m) -> playerEvent(k, m)); applyPlayerPrefs(); }
            np.loadAv();
            np.setAv(np.getAv() + d);
        } catch (Throwable ignored) { }
    }

    private EditText field(LinearLayout f, String hint, String val, boolean pw) {
        TextView l = new TextView(this); l.setText(hint); l.setTextColor(MUT); l.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(12.5f)); l.setPadding(0, dp(8), 0, dp(3));
        f.addView(l);
        EditText e = new EditText(this);
        e.setText(val); e.setTextColor(TXT); e.setSingleLine(true);
        e.setInputType(pw ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD) : (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI));
        e.setBackground(sel(CARD, 10)); e.setPadding(dp(14), dp(10), dp(14), dp(10));
        f.addView(e, new LinearLayout.LayoutParams(-1, -2));
        return e;
    }

    /* ------------------------------------------------------------ v317: cópia de segurança das definições */
    private static final int RC_BK_SAVE = 7101, RC_BK_OPEN = 7102;
    private String pendingBackup = "";
    private static final String[] BK_SKIP = {"WebView", "com.google", "androidx", "com.android", "Crashlytics", "firebase"};
    private JSONObject backupJson() throws Exception {
        JSONObject root = new JSONObject(); root.put("cockpitTvBackup", 1);
        try { root.put("versao", getPackageManager().getPackageInfo(getPackageName(), 0).versionName); } catch (Throwable ignored) { }
        root.put("quando", new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(new java.util.Date()));
        JSONObject prefs = new JSONObject();
        File dir = new File(getApplicationInfo().dataDir, "shared_prefs");
        File[] fs = dir.listFiles();
        if (fs != null) for (File f : fs) {
            String n = f.getName(); if (!n.endsWith(".xml")) continue; n = n.substring(0, n.length() - 4);
            boolean skip = false; for (String k : BK_SKIP) if (n.startsWith(k)) skip = true; if (skip) continue;
            JSONObject o = new JSONObject();
            for (java.util.Map.Entry<String, ?> en : getSharedPreferences(n, 0).getAll().entrySet()) {
                Object v = en.getValue(); JSONObject e = new JSONObject();
                if (v instanceof Boolean) { e.put("t", "b"); e.put("v", v); }
                else if (v instanceof Integer) { e.put("t", "i"); e.put("v", v); }
                else if (v instanceof Long) { e.put("t", "l"); e.put("v", v); }
                else if (v instanceof Float) { e.put("t", "f"); e.put("v", (double) (Float) v); }
                else if (v instanceof String) { e.put("t", "s"); e.put("v", v); }
                else if (v instanceof java.util.Set) { e.put("t", "S"); e.put("v", new JSONArray((java.util.Set<?>) v)); }
                else continue;
                o.put(en.getKey(), e);
            }
            if (o.length() > 0) prefs.put(n, o);
        }
        root.put("prefs", prefs);
        return root;
    }
    private String backupName() { return "cockpit-tv-backup-" + new java.text.SimpleDateFormat("yyyyMMdd-HHmm", java.util.Locale.US).format(new java.util.Date()) + ".json"; }
    private void backupExport(boolean pick) {
        try {
            final String txt = backupJson().toString(1);
            final String name = backupName();
            if (pick) {
                pendingBackup = txt;
                try {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("application/json").putExtra(Intent.EXTRA_TITLE, name);
                    startActivityForResult(i, RC_BK_SAVE);
                } catch (Throwable e) { Toast.makeText(this, "Esta TV não tem seletor de ficheiros: usa «Exportar (Transferências)».", Toast.LENGTH_LONG).show(); }
                return;
            }
            String where = "";
            try {
                File d = new File(getExternalFilesDir(null), "backup"); d.mkdirs();
                try (java.io.FileOutputStream o = new java.io.FileOutputStream(new File(d, name))) { o.write(txt.getBytes("UTF-8")); }
                where = d.getPath();
            } catch (Throwable ignored) { }
            boolean dl = false;
            try {
                if (android.os.Build.VERSION.SDK_INT >= 29) {
                    android.content.ContentValues cv = new android.content.ContentValues();
                    cv.put(android.provider.MediaStore.MediaColumns.DISPLAY_NAME, name); cv.put(android.provider.MediaStore.MediaColumns.MIME_TYPE, "application/json");
                    cv.put(android.provider.MediaStore.MediaColumns.RELATIVE_PATH, android.os.Environment.DIRECTORY_DOWNLOADS);
                    Uri u = getContentResolver().insert(android.provider.MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                    if (u != null) { try (java.io.OutputStream o = getContentResolver().openOutputStream(u)) { o.write(txt.getBytes("UTF-8")); } dl = true; }
                }
            } catch (Throwable ignored) { }
            Toast.makeText(this, dl ? "Guardado em Transferências: " + name : where.isEmpty() ? "Não consegui guardar." : "Guardado em " + where + "/" + name, Toast.LENGTH_LONG).show();
        } catch (Throwable e) { Toast.makeText(this, "Erro ao exportar: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }
    private void backupPick() {
        try { startActivityForResult(new Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"), RC_BK_OPEN); }
        catch (Throwable e) { Toast.makeText(this, "Esta TV não tem seletor de ficheiros: usa «Importar da pasta da app».", Toast.LENGTH_LONG).show(); }
    }
    private void backupFromAppDir() {
        File d = new File(getExternalFilesDir(null), "backup");
        final File[] fs = d.listFiles((dd, n) -> n.endsWith(".json"));
        if (fs == null || fs.length == 0) { Toast.makeText(this, "Sem cópias na pasta da app. Põe lá o ficheiro (Android/data/" + getPackageName() + "/files/backup) ou usa «Importar de um ficheiro».", Toast.LENGTH_LONG).show(); return; }
        java.util.Arrays.sort(fs, (a, b) -> Long.compare(b.lastModified(), a.lastModified()));
        String[] names = new String[fs.length]; for (int i = 0; i < fs.length; i++) names[i] = fs[i].getName();
        new AlertDialog.Builder(this).setTitle("Importar cópia").setItems(names, (dg, w) -> {
            try (java.io.FileInputStream in = new java.io.FileInputStream(fs[w])) { backupConfirm(readAll(in)); } catch (Throwable e) { Toast.makeText(this, "Erro: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
        }).show();
    }
    private static String readAll(java.io.InputStream in) throws java.io.IOException {
        java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream(); byte[] b = new byte[16384]; int n;
        while ((n = in.read(b)) > 0) o.write(b, 0, n);
        return o.toString("UTF-8");
    }
    private void backupConfirm(final String txt) {
        try {
            final JSONObject root = new JSONObject(txt);
            if (root.optInt("cockpitTvBackup", 0) != 1 || root.optJSONObject("prefs") == null) { Toast.makeText(this, "Este ficheiro não é uma cópia do Cockpit TV.", Toast.LENGTH_LONG).show(); return; }
            new AlertDialog.Builder(this).setTitle("Importar cópia de " + root.optString("quando"))
                    .setMessage("Isto substitui TODAS as definições atuais (lista IPTV, favoritos, ordem, ocultos, vídeo, som…) pelas da cópia.")
                    .setNegativeButton("Cancelar", null)
                    .setPositiveButton("Importar", (d, w) -> backupApply(root)).show();
        } catch (Throwable e) { Toast.makeText(this, "Ficheiro inválido: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }
    private void backupApply(JSONObject root) {
        try {
            JSONObject prefs = root.getJSONObject("prefs"); int n = 0;
            java.util.Iterator<String> it = prefs.keys();
            while (it.hasNext()) {
                String name = it.next(); JSONObject o = prefs.getJSONObject(name);
                android.content.SharedPreferences.Editor ed = getSharedPreferences(name, 0).edit(); ed.clear();
                java.util.Iterator<String> ks = o.keys();
                while (ks.hasNext()) {
                    String k = ks.next(); JSONObject e = o.getJSONObject(k); String t = e.optString("t");
                    switch (t) {
                        case "b": ed.putBoolean(k, e.getBoolean("v")); break;
                        case "i": ed.putInt(k, e.getInt("v")); break;
                        case "l": ed.putLong(k, e.getLong("v")); break;
                        case "f": ed.putFloat(k, (float) e.getDouble("v")); break;
                        case "s": ed.putString(k, e.getString("v")); break;
                        case "S": { JSONArray a = e.getJSONArray("v"); java.util.Set<String> ss = new java.util.HashSet<>(); for (int q = 0; q < a.length(); q++) ss.add(a.getString(q)); ed.putStringSet(k, ss); break; }
                        default: break;
                    }
                    n++;
                }
                ed.commit();
            }
            try { data.clearCache(); } catch (Throwable ignored) { }
            Toast.makeText(this, "Cópia importada (" + n + " definições). A reiniciar o ecrã…", Toast.LENGTH_LONG).show();
            ui.postDelayed(this::recreate, 600);
        } catch (Throwable e) { Toast.makeText(this, "Erro ao importar: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
    }
    @Override
    protected void onActivityResult(int rc, int res, Intent d) {
        super.onActivityResult(rc, res, d);
        if (rc == REQ_VOICE_NATIVE) {   /* v365: texto ditado vai para a caixa de pesquisa */
            try { java.util.ArrayList<String> r = (res == RESULT_OK && d != null) ? d.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS) : null;
                if (r != null && !r.isEmpty() && searchBox != null) { searchBox.setText(r.get(0)); searchBox.setSelection(r.get(0).length()); runSearch(); } } catch (Throwable ignored) { }
            return;
        }
        if (res != RESULT_OK || d == null || d.getData() == null) return;
        if (rc == RC_BK_SAVE) {
            try (java.io.OutputStream o = getContentResolver().openOutputStream(d.getData())) { o.write(pendingBackup.getBytes("UTF-8")); Toast.makeText(this, "Cópia guardada", Toast.LENGTH_SHORT).show(); }
            catch (Throwable e) { Toast.makeText(this, "Erro ao guardar: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
            pendingBackup = "";
        } else if (rc == RC_BK_OPEN) {
            try (java.io.InputStream in = getContentResolver().openInputStream(d.getData())) { backupConfirm(readAll(in)); }
            catch (Throwable e) { Toast.makeText(this, "Erro a ler: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
        }
    }

    /** v316: título de secção com botão para recolher/expandir (estado guardado). O conteúdo vai para a caixa dada. */
    private void addCollapsible(LinearLayout parent, final String title, final String key, final LinearLayout box) {
        /* v318: o título é o próprio botão (alinhado à esquerda, como o resto), para as setas do comando chegarem lá */
        final Button tg = btn("", null);
        tg.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(18)); tg.setTypeface(null, Typeface.BOLD);
        tg.setPadding(dp(18), dp(10), dp(18), dp(10));
        final boolean[] col = {getSharedPreferences("nativeapp", 0).getBoolean(key, false)};
        final Runnable upd = () -> { box.setVisibility(col[0] ? View.GONE : View.VISIBLE); tg.setText((col[0] ? "▸  " : "▾  ") + title + (col[0] ? "   ·   OK para expandir" : "   ·   OK para recolher")); };
        tg.setOnClickListener(v -> { col[0] = !col[0]; getSharedPreferences("nativeapp", 0).edit().putBoolean(key, col[0]).apply(); upd.run(); });
        upd.run();
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.topMargin = dp(16); lp.bottomMargin = dp(4);
        tg.setLayoutParams(lp);
        parent.addView(tg);
        parent.addView(box);
    }
    /** v316: segura a posição do ecrã enquanto uma lista é refeita; chama o Runnable devolvido quando acabar. */
    private Runnable holdScroll(final LinearLayout anchor) {
        View p = anchor; ScrollView x = null;
        while (p != null && p.getParent() instanceof View) { p = (View) p.getParent(); if (p instanceof ScrollView) { x = (ScrollView) p; break; } }
        final ScrollView sv = x; final int sy = sv != null ? sv.getScrollY() : 0;
        if (sv != null && anchor.getHeight() > 0) anchor.setMinimumHeight(anchor.getHeight());
        return () -> { if (sv != null) sv.post(() -> { sv.scrollTo(0, sy); anchor.setMinimumHeight(0); }); else anchor.setMinimumHeight(0); };
    }
    /** v314: botão pequeno para as linhas de grupos. */
    private Button sbtn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t); b.setAllCaps(false); b.setTextColor(TXT); b.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(12));
        b.setBackground(sel(0xFF1F2B38, 8)); b.setPadding(dp(8), 0, dp(8), 0); b.setMinWidth(0); b.setMinimumWidth(0); b.setMinHeight(0); b.setMinimumHeight(0);
        b.setStateListAnimator(null);
        if (l != null) b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(30)); lp.rightMargin = dp(5);
        b.setLayoutParams(lp);
        return b;
    }
    private Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t); b.setAllCaps(false); b.setTextColor(TXT); b.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(14));
        b.setBackground(sel(0xFF1F2B38, 12)); b.setPadding(dp(16), dp(8), dp(16), dp(8));
        b.setStateListAnimator(null);
        if (l != null) b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    /* ------------------------------------------------------------ teclas, voltar e ciclo de vida */
    @Override
    public void onBackPressed() {
        if (nscr != null && nscr.isOpen()) { nscr.onBack(); return; }
        if (details != null) { closeDetails(); grid.requestFocus(); return; }
        if (openSeries != null) { closeSeries(); return; }
        if (!"home".equals(section) && grid.hasFocus() && catList.getVisibility() == View.VISIBLE) { catList.requestFocus(); return; }
        if ("settings".equals(section) && !setPage.isEmpty()) { openSetPage(""); return; }
        if (!"home".equals(section)) { showSection("home"); return; }
        if (homeScroll.getScrollY() > 0 && !homeKinds.hasFocus()) { homeScroll.scrollTo(0, 0); View k = homeKinds.getChildAt(0); if (k != null) k.requestFocus(); return; }
        super.onBackPressed();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent ev) {
        try {
            int k = ev.getKeyCode();
            /* v324: em ecrã total o OK abre sempre o menu (modo de imagem / sair), mesmo que algum botão tenha ficado com o foco e o engolisse */
            if ((k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER) && ev.getAction() == KeyEvent.ACTION_DOWN && ev.getRepeatCount() == 0
                    && nscr != null && nscr.isOpen() && nscr.fullOkMenuReady()) {
                if (nscr.onKey(ev)) return true;
            }
            boolean nav = k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN || k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT || k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER;
            if (nav && ev.getAction() == KeyEvent.ACTION_DOWN && (nscr == null || !nscr.isOpen())) {
                View f = getCurrentFocus();
                if (f == null || !f.isShown() || !f.isAttachedToWindow()) {
                    /* v286: o foco tinha ficado num sítio que desapareceu (lista refeita, ficha fechada…): as setas deixavam de mexer */
                    NativeData.dbg("foco perdido (" + (f == null ? "nenhum" : f.getClass().getSimpleName()) + ") em " + section + ": reposto");
                    if (refocus()) return true;
                }
            }
        } catch (Throwable ignored) { }
        return super.dispatchKeyEvent(ev);
    }
    /** Põe o foco num sítio útil da secção atual. */
    private boolean refocus() {
        View t = null;
        if (details != null) t = findFocusable(details, 0);
        else if ("home".equals(section)) {
            if (lastHomeFocus != null && lastHomeFocus.isAttachedToWindow() && lastHomeFocus.isShown()) t = lastHomeFocus;
            else t = homeKinds.getChildAt(0);
        } else if ("settings".equals(section) && settingsView != null) t = findFocusable(settingsView, 0);
        else if (grid.isShown() && grid.getCount() > 0) t = grid;
        else if (catList.isShown()) t = catList;
        else if (searchBox.isShown()) t = searchBox;
        if (t == null) { View tab0 = navTabs.get("tvhome"); t = tab0; }
        return t != null && t.requestFocus();
    }

    @Override
    public boolean onKeyDown(int code, KeyEvent ev) {
        if (code == KeyEvent.KEYCODE_ESCAPE) { onBackPressed(); return true; }
        if (code == KeyEvent.KEYCODE_SEARCH && searchRow != null && searchRow.getVisibility() == View.VISIBLE) { voiceSearch(); return true; }
        if (nscr != null && nscr.isOpen()) { if (nscr.onKey(ev)) return true; return super.onKeyDown(code, ev); }
        if (code == KeyEvent.KEYCODE_MENU || code == KeyEvent.KEYCODE_BOOKMARK) {
            if (details == null && grid.hasFocus()) { itemMenu(grid.getSelectedItemPosition()); return true; }
        }
        return super.onKeyDown(code, ev);
    }

    /** Ecrã inteiro sem barras do sistema (como a app antiga): o vídeo em ecrã total ocupa o telemóvel todo. */
    private void immersive() {
        try {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        } catch (Throwable ignored) { }
    }

    @Override
    public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) immersive();
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        if (nscr != null && nscr.isOpen()) { nscr.onConfigChanged(); pendingRebuild = true; return; }
        rebuild();
    }
    private boolean pendingRebuild = false;
    /** Rodar o telemóvel: refaz a interface com a escala nova (os dados ficam). */
    private void rebuild() {
        try {
            float old = S; computeScale();
            ui.removeCallbacks(clockTick);
            stopPreview();
            details = null; settingsView = null;
            navTabs.clear();
            /* v283: ao rodar guarda o que estava escrito na pesquisa e a página das Definições */
            final String q = searchBox == null ? "" : searchBox.getText().toString();
            final String pg = setPage;
            if (appLayer != null) root.removeView(appLayer);
            buildUi();
            String sec = section; section = "";
            if ("home".equals(sec) || sec.isEmpty()) showSection("home");
            else if ("settings".equals(sec)) { showSection("settings"); if (!pg.isEmpty()) openSetPage(pg); }
            else if ("guide".equals(sec)) { showSection("guide"); if (q.length() > 0) { searchBox.setText(q); searchBox.setSelection(q.length()); } }
            else { section = sec; homeScroll.setVisibility(View.GONE); browseCol.setVisibility(View.VISIBLE); chipsRow.setVisibility(View.VISIBLE); for (java.util.Map.Entry<String, View> e : navTabs.entrySet()) styleTab(e.getValue(), e.getKey()); showTab(tab); if ("search".equals(tab) && q.length() > 0) { searchBox.setText(q); searchBox.setSelection(q.length()); } }
        } catch (Throwable ignored) { }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        try {
            if (android.os.Build.VERSION.SDK_INT < 26 || np == null || !np.isActive() || nscr == null || !nscr.isOpen()) return;
            android.app.UiModeManager um = (android.app.UiModeManager) getSystemService(UI_MODE_SERVICE);
            if (um != null && um.getCurrentModeType() == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION) return;
            if (!getPackageManager().hasSystemFeature(android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE)) return;
            enterPictureInPictureMode(new android.app.PictureInPictureParams.Builder().setAspectRatio(new android.util.Rational(16, 9)).build());
        } catch (Throwable ignored) { }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean in, android.content.res.Configuration cfg) {
        super.onPictureInPictureModeChanged(in, cfg);
        try { if (nscr != null && nscr.isOpen()) nscr.setSystemPip(in); } catch (Throwable ignored) { }
    }

    @Override
    protected void onStart() {
        super.onStart();
        ui.removeCallbacks(listTick); ui.postDelayed(listTick, 10 * 60 * 1000L);
        if (np != null && nscr != null && nscr.isOpen()) np.resumeAfterBackground();
        else if ("home".equals(section)) ui.postDelayed(this::startPreview, 300);
    }

    @Override
    protected void onStop() {
        super.onStop();
        ui.removeCallbacks(listTick);
        if ("home".equals(section)) saveHomePos(); else if ("explore".equals(section) || "guide".equals(section)) saveBrowsePos();
        if (nscr != null && nscr.isOpen()) { if (np != null) np.pause(); }
        else stopPreview();
    }

    @Override
    protected void onDestroy() {
        try { if (nscr != null && nscr.isOpen()) nscr.close(); } catch (Throwable ignored) { }
        if (np != null) { np.release(); np = null; }
        if (cast != null) { try { cast.release(); } catch (Throwable ignored) { } cast = null; }
        bg.shutdownNow(); img.shutdownNow();
        super.onDestroy();
    }
}
