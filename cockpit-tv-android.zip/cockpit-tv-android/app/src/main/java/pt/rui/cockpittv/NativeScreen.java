package pt.rui.cockpittv;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Ecrã de canais 100% nativo (Fase 1, opcional): lista à esquerda, vídeo ao centro e botões por baixo.
 * Só usa o leitor nativo (NativePlayer). A página (WebView) fica por baixo, parada, até saíres.
 */
final class NativeScreen {
    interface Host { void js(String kind, String msg); }

    private static final class Item { String name = "", logo = "", group = "", url = "", ref = "", epg = "", kind = "live"; long start = 0; }

    /** Grelha dos frames de vídeo (1 a 4, ou PIP). Cada frame é 16:9; a grelha nunca ocupa mais do que a altura livre menos a reserva. */
    private final class VideoGrid extends FrameLayout {
        int reserve = 0, cw = 0, chh = 0, gap = 0, gridW = 0;
        VideoGrid(Activity a) { super(a); }
        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            int w = MeasureSpec.getSize(wSpec);
            int availH = MeasureSpec.getSize(hSpec);
            gap = dp(3);
            int cols = (nslots == 1 || pip) ? 1 : 2, rows = (nslots <= 2 || pip) ? 1 : 2;
            cw = (w - gap * (cols - 1)) / cols;
            chh = cw * 9 / 16;
            int maxH = availH > 0 ? Math.max(availH - reserve, 120) : Integer.MAX_VALUE;
            if (chh * rows + gap * (rows - 1) > maxH) { chh = (maxH - gap * (rows - 1)) / rows; cw = chh * 16 / 9; }
            gridW = cw * cols + gap * (cols - 1);
            setMeasuredDimension(w, chh * rows + gap * (rows - 1));
            for (int s = 0; s < MAXS; s++) {
                View v = hs[s];
                if (v == null || v.getVisibility() == View.GONE) continue;
                int vw = cw, vh = chh;
                if (pip && s > 0) { vw = Math.max(cw * 34 / 100, dp(90)); vh = vw * 9 / 16; }
                v.measure(MeasureSpec.makeMeasureSpec(vw, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(vh, MeasureSpec.EXACTLY));
            }
        }
        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int ox = ((r - l) - gridW) / 2;
            for (int s = 0; s < MAXS; s++) {
                View v = hs[s];
                if (v == null || v.getVisibility() == View.GONE) continue;
                int x, y;
                if (pip && s > 0) { x = ox + cw - v.getMeasuredWidth() - dp(8); y = chh - v.getMeasuredHeight() - dp(8); }
                else if (nslots == 1 || pip) { x = ox; y = 0; }
                else { x = ox + (s % 2) * (cw + gap); y = (s / 2) * (chh + gap); }
                v.layout(x, y, x + v.getMeasuredWidth(), y + v.getMeasuredHeight());
            }
        }
    }

    private final Activity act;
    private final FrameLayout root;
    private final NativePlayer np;
    private final Host host;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newFixedThreadPool(6);
    private final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(300);

    private final ArrayList<Item> items = new ArrayList<Item>();
    private static final int MAXS = 4;
    private int index = -1;                       /* canal do frame 0 */
    private boolean full = false, closed = false;
    private final NativePlayer[] sp = new NativePlayer[MAXS];
    private final FrameLayout[] hs = new FrameLayout[MAXS];
    private final TextView[] ls = new TextView[MAXS];
    private final int[] sidx = {-1, -1, -1, -1}, sret = new int[MAXS], sasp = new int[MAXS];
    private final int[] sslow = new int[MAXS];
    private final boolean[] sts = new boolean[MAXS], sfirst = {true, true, true, true};
    private int nslots = 1, fullSlot = 0;
    private boolean pip = false;
    private VideoGrid grid;

    private FrameLayout screen;
    private LinearLayout main, right, row1, row2, row3;
    private ListView list;
    private LinearLayout listBox;
    private TextView title, epg, btnAspect, btnFull, btnGroup, btnDual;
    private EditText search;
    private final ArrayList<Integer> vis = new ArrayList<Integer>();
    private String query = "", groupFilter = "";
    private int active = 0, soundSlot = 0;
    private TextView btnSound, btnSubs, statsView;
    private boolean showStats = false;
    private LinearLayout ctrlBar;
    /* lista de canais por cima do ecrã total (um toque / OK no comando) */
    private FrameLayout fsOv;
    private ListView fsList;
    private boolean fsShown = false;
    private final Runnable fsHide = () -> hideFsList();
    private TextView btnExitRef;
    private View hsvChips;
    private final TextView[] tb5 = new TextView[5];
    private BaseAdapter adapter;

    private static final String[] ASP = {"fit", "zoom", "stretch", "16:9", "4:3", "21:9"};
    private static final String[] ASP_L = {"Ajustar", "Zoom", "Esticar", "16:9", "4:3", "21:9"};

    NativeScreen(Activity act, FrameLayout root, NativePlayer np, Host host) {
        this.act = act;
        this.root = root;
        this.np = np;
        this.sp[0] = np;
        this.host = host;
    }

    private int dp(int v) { return (int) (v * act.getResources().getDisplayMetrics().density + 0.5f); }

    /* ------------------------------------------------------------ abrir / fechar */
    void open(String json, int start) {
        try {
            JSONArray a = new JSONArray(json);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item();
                it.name = o.optString("name");
                it.logo = o.optString("logo");
                it.group = o.optString("group");
                it.url = o.optString("url");
                it.ref = o.optString("ref");
                it.epg = o.optString("epg");
                it.kind = o.optString("kind", "live");
                it.start = o.optLong("start", 0);
                if (it.url.length() > 0) items.add(it);
            }
        } catch (Throwable e) {
            Toast.makeText(act, "Lista inválida: " + e, Toast.LENGTH_LONG).show();
            host.js("nscreen:closed", "");
            return;
        }
        if (items.isEmpty()) { host.js("nscreen:closed", ""); return; }
        buildVis();
        build();
        np.prepareViews();
        root.addView(screen, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        np.bringBoxToFront();
        applyOrientation();
        /* v303: canais (vindos do Explorar, do Guia ou do Início) abrem esticados também fora do ecrã total; filmes e séries ajustados */
        final boolean liveOpen = "live".equals(items.get(Math.max(0, Math.min(start, items.size() - 1))).kind);
        java.util.Arrays.fill(sasp, liveOpen ? 2 : 0);
        np.setAspect(ASP[sasp[0]], ASP_L[sasp[0]]);
        try { setBtn(btnAspect, "▭ " + ASP_L[sasp[0]]); } catch (Throwable ignored) { }
        play(Math.max(0, Math.min(start, items.size() - 1)));
        ui.postDelayed(posRun, 5000);
        selectInList(index);
        /* o foco do comando tem de ir para o ecrã nativo (senão as setas continuam a mexer na página escondida) */
        screen.setFocusable(true);
        screen.setFocusableInTouchMode(false);
        screen.post(() -> { try { list.requestFocus(); } catch (Throwable ignored) { } });
    }

    private boolean fromHome = false;   // aberto a partir do Início (a página pede o ecrã total)
    boolean isOpen() { return !closed && screen != null; }

    void close() {
        if (closed) return;
        MainActivity.NAV_LISTENER = null;
        reportPos();
        closed = true;
        ui.removeCallbacksAndMessages(null);
        try { np.setFull(false); } catch (Throwable ignored) { }
        try { np.setMaxRes(0, 0); } catch (Throwable ignored) { }
        /* volta ao Início: o mesmo canal continua na pré-visualização sem recarregar (se a superfície não mudar) */
        try { boolean rebuilt = np.switchSurface(false); if (rebuilt) np.stop(); else np.stopSoon(5000, fromHome); } catch (Throwable ignored) { try { np.stop(); } catch (Throwable x) { } }
        for (int q = 1; q < MAXS; q++) {
            try { if (sp[q] != null) { sp[q].setFull(false); sp[q].stop(); sp[q].release(); sp[q] = null; } } catch (Throwable ignored) { }
        }
        try { if (fsOv != null) root.removeView(fsOv); } catch (Throwable ignored) { }
        try { root.removeView(screen); } catch (Throwable ignored) { }
        pool.shutdownNow();
        host.js("nscreen:closed", index >= 0 && index < items.size() ? items.get(index).url : "");
    }

    /** Botão Voltar: primeiro sai do ecrã total, depois fecha. */
    private boolean toListOnExit = false;

    boolean onBack() {
        if (full && fsShown) { hideFsList(); return true; }   /* Voltar fecha primeiro a lista de canais */
        if (full) { toListOnExit = true; setFull(false); return true; }   /* Voltar: sai do ecrã total e fica no canal da lista */
        close();
        return true;
    }

    /** Teclas do comando (TV): cima/baixo muda de canal fora do ecrã total. */
    boolean onKey(KeyEvent ev) {
        if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
        int k = ev.getKeyCode();
        if (full) {
            if (fsShown) {   /* com a lista aberta, as setas e o OK pertencem a ela (o sistema entrega-os à lista com foco) */
                if (k == KeyEvent.KEYCODE_CHANNEL_UP) { step(-1); fsPoke(); return true; }
                if (k == KeyEvent.KEYCODE_CHANNEL_DOWN) { step(1); fsPoke(); return true; }
                fsPoke();
                return false;
            }
            if (isVod() && cp().canSeek()) {   /* v289: filmes e séries: o comando anda na barra de progresso */
                int rep = ev.getRepeatCount();
                long st = rep > 6 ? 60000 : rep > 2 ? 30000 : 10000;
                if (k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_MEDIA_REWIND) { cp().seek(-st); pbUpdate(); return true; }
                if (k == KeyEvent.KEYCODE_DPAD_RIGHT || k == KeyEvent.KEYCODE_MEDIA_FAST_FORWARD) { cp().seek(st); pbUpdate(); return true; }
                if (k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN) { cp().showSeekBar(); return true; }
                if (k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER || k == KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE) { cp().toggle(); cp().showSeekBar(); return true; }
            }
            if (k == KeyEvent.KEYCODE_CHANNEL_UP || k == KeyEvent.KEYCODE_DPAD_UP) { step(-1); return true; }
            if (k == KeyEvent.KEYCODE_CHANNEL_DOWN || k == KeyEvent.KEYCODE_DPAD_DOWN) { step(1); return true; }
            if (k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER) { if (fsOff()) setFull(false); else showFsList(); return true; }   /* OK: lista de canais (Voltar sai do ecrã total) */
        }
        if (k == KeyEvent.KEYCODE_CHANNEL_UP) { step(-1); return true; }
        if (k == KeyEvent.KEYCODE_CHANNEL_DOWN) { step(1); return true; }
        return false;
    }

    /* ------------------------------------------------------------ interface */
    private GradientDrawable round(int color, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    private TextView button(String text, View.OnClickListener l) {
        TextView b = new NIcons.TV(act);
        NIcons.set(b, text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15f);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setMaxLines(1);
        b.setPadding(dp(4), dp(10), dp(4), dp(10));
        /* o texto encolhe para caber no botão (telemóvel na vertical tem 5 botões por linha) */
        final TextView tb = b;
        b.addOnLayoutChangeListener((vw, x1, y1, x2, y2, ox1, oy1, ox2, oy2) -> { if (x2 - x1 != ox2 - ox1) fitText(tb); });
        b.setFocusable(true);
        b.setClickable(true);
        StateListDrawable sl = new StateListDrawable();
        GradientDrawable focus = round(0xFF2F7DD1, 12);
        focus.setStroke(dp(2), Color.WHITE);
        sl.addState(new int[]{android.R.attr.state_focused}, focus);
        sl.addState(new int[]{android.R.attr.state_pressed}, round(0xFF2F7DD1, 12));
        sl.addState(new int[]{}, round(0xFF1B2B47, 12));
        b.setBackground(sl);
        b.setTag(15f);
        b.setOnClickListener(l);
        return b;
    }

    private StateListDrawable stateBg(int normal, int r) {
        StateListDrawable sl = new StateListDrawable();
        GradientDrawable focus = round(0xFF2F7DD1, r);
        focus.setStroke(dp(2), Color.WHITE);
        sl.addState(new int[]{android.R.attr.state_focused}, focus);
        sl.addState(new int[]{android.R.attr.state_pressed}, round(0xFF2F7DD1, r));
        sl.addState(new int[]{}, round(normal, r));
        return sl;
    }

    private TextView chip(String text, View.OnClickListener l) {
        TextView b = button(text, l);
        b.setTextSize(13f);
        b.setTag(13f);
        b.setPadding(dp(3), dp(7), dp(3), dp(7));
        b.setBackground(stateBg(0xFF1B2B47, 16));
        return b;
    }

    private void addChip(LinearLayout r, TextView b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(2), dp(2), dp(2), dp(2));
        r.addView(b, lp);
    }

    private TextView tbtn(String text, View.OnClickListener l, boolean accent) {
        TextView b = button(text, l);
        b.setTextSize(accent ? 26f : 22f);
        b.setTag(accent ? 26f : 22f);
        b.setPadding(dp(4), dp(accent ? 6 : 5), dp(4), dp(accent ? 6 : 5));
        b.setBackground(stateBg(accent ? 0xFF2F7DD1 : 0xFF1B2B47, 28));
        return b;
    }

    private TextView iconBtn(String text, View.OnClickListener l, boolean danger) {
        TextView b = button(text, l);
        b.setTextSize(20f);
        b.setTag(20f);
        b.setPadding(0, 0, 0, 0);
        b.setBackground(stateBg(danger ? 0xFF6B2230 : 0xFF1B2B47, 23));
        return b;
    }

    private void addT(LinearLayout r, TextView b, float w) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, w);
        lp.setMargins(dp(4), dp(4), dp(4), dp(2));
        r.addView(b, lp);
    }

    private float baseSize(TextView tv) { Object g = tv.getTag(); return g instanceof Float ? (Float) g : 15f; }

    private void setBtn(final TextView tv, String text) {
        NIcons.set(tv, text);
        tv.setTextSize(baseSize(tv));
        tv.post(() -> fitText(tv));
    }

    /** Encolhe o texto até caber na largura do botão. */
    private void fitText(TextView tv) {
        int avail = tv.getWidth() - tv.getPaddingLeft() - tv.getPaddingRight();
        if (avail <= 0 || tv.getText() == null) return;
        float sp = baseSize(tv);
        String t = tv.getText().toString();
        boolean ic = t.indexOf('\uFFFC') >= 0;
        t = t.replace("\uFFFC", "");
        float dens = act.getResources().getDisplayMetrics().scaledDensity;
        android.graphics.Paint p = new android.graphics.Paint(tv.getPaint());
        while (sp > 8f) {
            p.setTextSize(sp * dens);
            if (p.measureText(t) + (ic ? sp * dens * 1.3f + dp(4) : 0) <= avail) break;
            sp -= 0.5f;
        }
        tv.setTextSize(sp);
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(act);
        r.setOrientation(LinearLayout.HORIZONTAL);
        return r;
    }

    private void addBtn(LinearLayout r, TextView b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        r.addView(b, lp);
    }

    private void build() {
        screen = new FrameLayout(act);
        screen.setBackgroundColor(0xFF0B1220);
        screen.setKeepScreenOn(true);
        screen.setClickable(true);   /* não deixa toques passarem para a página */

        main = new LinearLayout(act);

        list = new ListView(act);
        list.setDivider(null);
        list.setBackgroundColor(0xFF111B2E);
        list.setSelector(new android.graphics.drawable.ColorDrawable(0x332F7DD1));
        adapter = new BaseAdapter() {
            @Override public int getCount() { return vis.size(); }
            @Override public Object getItem(int i) { return items.get(vis.get(i)); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View v, ViewGroup parent) {
                Row r;
                if (v == null) { r = new Row(act); v = r; } else r = (Row) v;
                int ix = vis.get(i);
                r.bind(items.get(ix), isShown(ix));
                return v;
            }
        };
        list.setAdapter(adapter);
        listBox = new LinearLayout(act);
        listBox.setOrientation(LinearLayout.VERTICAL);
        listBox.setBackgroundColor(0xFF111B2E);
        LinearLayout sr = row();
        search = new EditText(act);
        search.setHint("🔍 Pesquisar");
        search.setHintTextColor(0xFF8DA2BD);
        search.setTextColor(Color.WHITE);
        search.setTextSize(14f);
        search.setSingleLine(true);
        search.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void onTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void afterTextChanged(Editable e) { query = e.toString().trim().toLowerCase(); buildVis(); adapter.notifyDataSetChanged(); }
        });
        btnGroup = button("☰ Todos", v -> pickGroup());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        sr.addView(search, sp);
        sr.addView(btnGroup, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        sr.setPadding(dp(4), dp(4), dp(4), dp(4));
        listBox.addView(sr, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        listBox.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        if (items.size() < 2) sr.setVisibility(View.GONE);
        buildVis();
        list.setOnItemClickListener((p, v, i, id) -> {
            if (i >= 0 && i < vis.size()) {
                lastPick = vis.get(i);
                /* OK no canal que já está a dar: ecrã total */
                if (nslots == 1 && !full && ix(0) == vis.get(i)) { setFull(true); return; }
                playOnActive(vis.get(i));
                if (nslots > 1 && !full) ui.postDelayed(() -> { if (!closed && hs[active] != null) hs[active].requestFocus(); }, 80);   /* vários frames: depois do canal volta ao frame */
            }
        });

        right = new LinearLayout(act);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setPadding(dp(8), dp(6), dp(8), dp(6));

        grid = new VideoGrid(act);
        for (int q = 0; q < MAXS; q++) {
            final int sq = q;
            FrameLayout h = new FrameLayout(act);
            h.setBackgroundColor(Color.BLACK);
            h.setFocusable(true);
            h.setClickable(true);
            TextView t = new TextView(act);
            t.setTextColor(0xFFCBD5E1);
            t.setTextSize(q == 0 ? 15f : 13f);
            t.setGravity(Gravity.CENTER);
            h.addView(t, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            h.addOnLayoutChangeListener((v, l, tt, r, b, ol, ot, or, ob) -> {
                if (r - l != or - ol || b - tt != ob - ot || tt != ot || l != ol) scheduleRect();
            });
            h.setOnFocusChangeListener((v, f) -> updateFrames());
            h.setOnClickListener(v -> onFrameClick(sq));
            h.setOnLongClickListener(v -> { if (sq < nslots) setSound(sq); return true; });
            hs[q] = h;
            ls[q] = t;
            if (q > 0) h.setVisibility(View.GONE);
            grid.addView(h);
        }

        title = new TextView(act);
        title.setTextColor(Color.WHITE);
        title.setTextSize(18f);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        title.setPadding(dp(4), dp(6), dp(4), 0);

        epg = new TextView(act);
        epg.setTextColor(0xFF9FB3CC);
        epg.setTextSize(14f);
        epg.setMaxLines(2);
        epg.setEllipsize(android.text.TextUtils.TruncateAt.END);
        epg.setPadding(dp(4), 0, dp(4), dp(4));

        epg.setMaxLines(1);
        row1 = row();
        row2 = row();
        row3 = row();   /* barra de transporte */

        /* cabeçalho: nome + programa à esquerda; ecrã total e sair à direita */
        btnFull = iconBtn("⛶", v -> setFull(!full), false);
        TextView btnExit = iconBtn("✕", v -> close(), true);
        btnExitRef = btnExit;
        LinearLayout col = new LinearLayout(act);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        col.addView(epg, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        row1.setGravity(Gravity.CENTER_VERTICAL);
        row1.addView(col, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(46), dp(46));
        ip.setMargins(dp(4), 0, dp(2), 0);
        row1.addView(btnFull, ip);
        row1.addView(btnExit, ip);

        /* transporte: anterior · -10 s · pausa · +30 s · seguinte */
        tb5[0] = tbtn("⏮", v -> step(-1), false);
        tb5[1] = tbtn("⏪", v -> cp().seek(-10000), false);
        tb5[2] = tbtn("⏯", v -> cp().toggle(), true);
        tb5[3] = tbtn("⏩", v -> cp().seek(30000), false);
        tb5[4] = tbtn("⏭", v -> step(1), false);
        for (TextView t5 : tb5) row3.addView(t5, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));

        /* opções em «chips» que deslizam para o lado */
        btnAspect = chip("▭ Ajustar", v -> cycleAspect());
        btnDual = chip("⧉ 1 frame", v -> pickLayout());
        btnSound = chip("🔊 Som F1", v -> cycleSound());
        btnSubs = chip("🌐 Online", v -> { if (isVod()) onlineSubs(); else cp().goLive(); });
        /* todas as opções visíveis: grelha 4×2 de botões compactos */
        LinearLayout chips = new LinearLayout(act);
        chips.setOrientation(LinearLayout.VERTICAL);
        LinearLayout cr1 = row(), cr2 = row();
        TextView[] cs = {btnAspect, btnDual, chip("🎧 Áudio", v -> tracks("audio", "Áudio")), chip("💬 Legendas", v -> tracks("text", "Legendas")),
                btnSound, btnSubs, chip("📅 Guia", v -> { close(); host.js("nscreen:guide", ""); }), chip("📊 Info", v -> toggleStats())};
        for (int i = 0; i < cs.length; i++) addChip(i < 4 ? cr1 : cr2, cs[i]);
        chips.addView(cr1, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        chips.addView(cr2, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        View hsv = chips;
        statsView = new TextView(act);
        statsView.setTextColor(0xFF9FD0FF);
        statsView.setTextSize(12f);
        statsView.setTypeface(android.graphics.Typeface.MONOSPACE);
        statsView.setPadding(dp(6), dp(2), dp(6), dp(2));
        statsView.setVisibility(View.GONE);

        right.addView(grid, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        right.addView(row1, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        buildProgress();
        right.addView(pbRow, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        hsvChips = hsv;
        ctrlBar = new LinearLayout(act);
        ctrlBar.addView(row3, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        ctrlBar.addView(hsv, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        right.addView(ctrlBar, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        right.addView(statsView, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        screen.addView(main, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        buildNav();
    }

    /* ------------------------------------------------------------ v289: barra de progresso (filmes e episódios) fora do ecrã total */
    private LinearLayout pbRow;
    private android.widget.SeekBar pbar;
    private TextView pbPos, pbDur;
    private boolean pbTouch = false;
    private static String pbFmt(long ms) {
        long s = Math.max(0, ms / 1000), h = s / 3600, m = (s % 3600) / 60, x = s % 60;
        return h > 0 ? String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, x) : String.format(java.util.Locale.US, "%d:%02d", m, x);
    }
    private void buildProgress() {
        pbRow = new LinearLayout(act);
        pbRow.setGravity(Gravity.CENTER_VERTICAL);
        pbRow.setPadding(dp(4), dp(2), dp(4), dp(4));
        pbPos = new TextView(act); pbPos.setTextColor(0xFFCBD5E1); pbPos.setTextSize(15f); pbPos.setText("0:00");
        pbDur = new TextView(act); pbDur.setTextColor(0xFFCBD5E1); pbDur.setTextSize(15f); pbDur.setText("0:00");
        pbar = new android.widget.SeekBar(act);
        pbar.setMax(1000);
        pbar.setFocusable(true);
        /* v291: com foco só um contorno à volta (o fundo azul cheio tapava a barra) */
        StateListDrawable pbs = new StateListDrawable();
        GradientDrawable pf = new GradientDrawable(); pf.setColor(0x1A7CC4FF); pf.setStroke(dp(2), 0xFF7CC4FF); pf.setCornerRadius(dp(14));
        pbs.addState(new int[]{android.R.attr.state_focused}, pf);
        pbs.addState(new int[]{}, new android.graphics.drawable.ColorDrawable(0));
        pbar.setBackground(pbs);
        pbar.setPadding(dp(14), dp(10), dp(14), dp(10));
        pbar.setKeyProgressIncrement(0);
        pbar.setOnKeyListener((v, kc, e) -> {
            if (e.getAction() != KeyEvent.ACTION_DOWN) return false;
            int rep = e.getRepeatCount();
            long st = rep > 6 ? 60000 : rep > 2 ? 30000 : 10000;
            if (kc == KeyEvent.KEYCODE_DPAD_LEFT) { cp().seek(-st); pbUpdate(); return true; }
            if (kc == KeyEvent.KEYCODE_DPAD_RIGHT) { cp().seek(st); pbUpdate(); return true; }
            if (kc == KeyEvent.KEYCODE_DPAD_CENTER || kc == KeyEvent.KEYCODE_ENTER) { cp().toggle(); return true; }
            return false;
        });
        pbar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar sb, int p, boolean fromUser) {
                if (fromUser && pbTouch) { long[] pd = pbNow(); if (pd != null) pbPos.setText(pbFmt(pd[1] * p / 1000L)); }
            }
            @Override public void onStartTrackingTouch(android.widget.SeekBar sb) { pbTouch = true; }
            @Override public void onStopTrackingTouch(android.widget.SeekBar sb) {
                pbTouch = false;
                long[] pd = pbNow(); if (pd != null) { long to = pd[1] * sb.getProgress() / 1000L; cp().seek(to - pd[0]); }
                pbUpdate();
            }
        });
        LinearLayout.LayoutParams bp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        pbRow.addView(pbPos);
        pbRow.addView(pbar, bp);
        pbRow.addView(pbDur);
        pbRow.setVisibility(View.GONE);
        ui.postDelayed(pbTick, 1000);
    }
    /** {posição, duração} do vídeo ativo, ou null em direto. */
    private long[] pbNow() {
        try { String[] a = cp().pos().split("\\|"); long p = Long.parseLong(a[0]), d = Long.parseLong(a[1]); if (d <= 0 || "1".equals(a[2])) return null; return new long[]{p, d}; } catch (Throwable e) { return null; }
    }
    private void pbUpdate() {
        if (pbRow == null) return;
        long[] pd = isVod() ? pbNow() : null;
        pbRow.setVisibility(pd == null || full ? View.GONE : View.VISIBLE);
        if (pd == null || pbTouch) return;
        pbar.setProgress((int) (Math.min(pd[0], pd[1]) * 1000L / pd[1]));
        pbPos.setText(pbFmt(pd[0])); pbDur.setText(NativePlayer.remain(pd[0], pd[1]));   /* decorrido · em falta · total */
    }
    private final Runnable pbTick = new Runnable() { @Override public void run() { if (closed) return; try { pbUpdate(); } catch (Throwable ignored) { } ui.postDelayed(this, 1000); } };

    /** Barra global de navegação: copia o aspeto da barra da página (relógio, abas com ícones, cores). */
    private LinearLayout nav;
    private boolean navBottom = false;
    private int navH = 0;
    private TextView navClock, navStamp;
    private String navJsonUsed = "";

    /** Depois de rodar o telemóvel a página manda a barra nova (em cima ou em baixo): reconstrói a barra nativa. */
    private void checkNav() {
        try {
            if (closed || screen == null || nav == null) return;
            String j = MainActivity.NAV_JSON;
            if (j == null || j.length() < 3 || j.equals(navJsonUsed)) return;
            try { screen.removeView(nav); } catch (Throwable ignored) { }
            try { if (navStamp != null) screen.removeView(navStamp); } catch (Throwable ignored) { }
            nav = null; navClock = null; navStamp = null; navGeo = false;
            buildNav();
            boolean land = act.getResources().getDisplayMetrics().widthPixels > act.getResources().getDisplayMetrics().heightPixels;
            placeNav(land);
            if (full) { nav.setVisibility(View.GONE); if (navStamp != null) navStamp.setVisibility(View.GONE); }
            lastKey = "";
            ui.removeCallbacks(rectRun);
            ui.postDelayed(rectRun, 200);
        } catch (Throwable ignored) { }
    }
    private boolean navGeo = false; private int navBx, navBy, navBw, navBh;
    private int navCol(JSONObject c, String k, int def) { try { return Color.parseColor(c.optString(k, "")); } catch (Throwable e) { return def; } }
    private void buildNav() {
        MainActivity.NAV_LISTENER = this::checkNav;
        JSONObject cfg = null;
        try { String j = MainActivity.NAV_JSON; navJsonUsed = j == null ? "" : j; if (j != null && j.length() > 2) cfg = new JSONObject(j); } catch (Throwable ignored) { }
        if (cfg == null || cfg.optJSONArray("tabs") == null || cfg.optJSONArray("tabs").length() == 0) { buildNavSimple(); return; }
        try {
            final boolean phone = cfg.optBoolean("phone");
            navBottom = phone;
            double sc = cfg.optDouble("sc", 1.0);
            navH = Math.max(dp(40), cfg.optInt("h", dp(56)));
            navGeo = cfg.optBoolean("geo");
            if (navGeo) { navBx = cfg.optInt("bx"); navBy = cfg.optInt("by"); navBw = Math.max(dp(200), cfg.optInt("bw")); navBh = Math.max(dp(40), cfg.optInt("bh")); navH = phone ? navBh : navBy + navBh; }
            int fs = Math.max(10, cfg.optInt("fs", 18)), cfs = Math.max(12, cfg.optInt("cfs", 26));
            final int acc = navCol(cfg, "acc", 0xFF7CC4FF), ink = navCol(cfg, "ink", 0xFF08121F);
            nav = new LinearLayout(act);
            nav.setOrientation(LinearLayout.HORIZONTAL);
            nav.setGravity(Gravity.CENTER_VERTICAL);
            GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{navCol(cfg, "c1", 0xFF12253F), navCol(cfg, "c2", 0xFF0A1424)});
            android.graphics.drawable.LayerDrawable ld = new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{bg, new android.graphics.drawable.ColorDrawable(navCol(cfg, "bd", 0xFF2F5F95))});
            try { ld.setLayerHeight(1, Math.max(2, (int) (2 * sc))); ld.setLayerGravity(1, phone ? Gravity.TOP : Gravity.BOTTOM); } catch (Throwable ignored) { }
            nav.setBackground(ld);
            int pad = (int) (14 * sc);
            nav.setPadding(navGeo ? 0 : pad, 0, navGeo ? 0 : pad, 0);
            final int[] curX = {0};
            if (navGeo) {
                final float br = cfg.optInt("br", 0);
                try { bg.setCornerRadius(br); } catch (Throwable ignored) { }
            }
            if (!phone) {
                navClock = new TextView(act);
                navClock.setTextColor(Color.WHITE);
                navClock.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                navClock.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, cfs);
                navClock.setSingleLine(true);
                LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                cl.rightMargin = (int) (22 * sc);
                JSONObject ckj = cfg.optJSONObject("clk");
                if (navGeo && ckj != null) {
                    cl = new LinearLayout.LayoutParams(Math.max(1, ckj.optInt("w")), ViewGroup.LayoutParams.WRAP_CONTENT);
                    cl.leftMargin = Math.max(0, ckj.optInt("x")); cl.rightMargin = 0;
                    curX[0] = cl.leftMargin + cl.width;
                }
                nav.addView(navClock, cl);
                tickNavClock();
            }
            JSONArray tabs = cfg.getJSONArray("tabs");
            for (int i = 0; i < tabs.length(); i++) {
                final JSONObject t = tabs.getJSONObject(i);
                final String id = t.optString("id");
                final boolean cur = "tv".equals(id);
                final LinearLayout tab = new LinearLayout(act);
                tab.setOrientation(phone ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
                final int trad = (phone && cfg.optInt("tr") > 0) ? cfg.optInt("tr") : dp(999);
                tab.setGravity(Gravity.CENTER);
                int px = (int) ((phone ? 4 : 22) * sc), py = (int) (6 * sc);
                final boolean tg = navGeo && t.has("w");
                if (tg) { px = 0; py = 0; }
                tab.setPadding(px, py, px, py);
                final ImageView iv = new ImageView(act);
                int isz = phone ? (int) (22 * sc) : (int) (fs * 1.35f);
                String ic = t.optString(cur ? "iconA" : "icon");
                if (ic.length() > 0) { byte[] bytes = android.util.Base64.decode(ic, android.util.Base64.DEFAULT); iv.setImageBitmap(BitmapFactory.decodeByteArray(bytes, 0, bytes.length)); }
                tab.addView(iv, new LinearLayout.LayoutParams(isz, isz));
                final TextView lb = new TextView(act);
                String ltxt = t.optString("label");
                if (tg && t.optInt("lines", 1) >= 2) { lb.setText(ltxt.replaceFirst(" ", "\n")); lb.setSingleLine(false); lb.setMaxLines(2); lb.setGravity(Gravity.CENTER); }
                else { lb.setText(ltxt); lb.setSingleLine(true); }
                lb.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                lb.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, phone ? Math.max(10, fs) : fs);
                lb.setTextColor(cur ? ink : 0xFFE6EEF9);
                LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
                if (phone) ll.topMargin = (int) (2 * sc); else ll.leftMargin = (int) (8 * sc);
                tab.addView(lb, ll);
                tab.setAlpha(cur ? 1f : 0.82f);
                final GradientDrawable on = new GradientDrawable(); on.setColor(cur ? acc : 0x00000000); on.setCornerRadius(trad);
                final GradientDrawable foc = new GradientDrawable(); foc.setColor(cur ? acc : 0x22FFFFFF); foc.setCornerRadius(trad); foc.setStroke(Math.max(2, (int) (3 * sc)), Color.WHITE);
                tab.setBackground(on);
                tab.setFocusable(true);
                tab.setClickable(true);
                tab.setOnFocusChangeListener((v, f) -> { tab.setBackground(f ? foc : on); tab.setAlpha(f || cur ? 1f : 0.82f); });
                tab.setOnClickListener(v -> { if ("cast".equals(id) || "mirror".equals(id)) { host.js("nscreen:act", id); return; } close(); host.js("nscreen:nav", id); });
                LinearLayout.LayoutParams tl = phone ? new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 1f) : new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, (int) Math.max(dp(36), 50 * sc));
                if (!phone) tl.rightMargin = (int) (8 * sc);
                if (tg) {
                    tl = new LinearLayout.LayoutParams(Math.max(1, t.optInt("w")), Math.max(dp(30), t.optInt("h")));
                    tl.leftMargin = Math.max(0, t.optInt("x") - curX[0]); tl.rightMargin = 0;
                    curX[0] = Math.max(0, t.optInt("x")) + tl.width;
                }
                nav.addView(tab, tl);
            }
            if (navGeo) {
                FrameLayout.LayoutParams gp = new FrameLayout.LayoutParams(navBw, navBh, (phone ? Gravity.BOTTOM : Gravity.TOP) | Gravity.LEFT);
                gp.leftMargin = navBx; if (!phone) gp.topMargin = navBy;
                screen.addView(nav, gp);
                JSONObject st = cfg.optJSONObject("stamp");
                if (st != null && st.optString("text").length() > 0) {
                    navStamp = new TextView(act);
                    navStamp.setText(st.optString("text"));
                    navStamp.setTextColor(Color.WHITE); navStamp.setAlpha(0.85f);
                    navStamp.setTypeface(android.graphics.Typeface.DEFAULT_BOLD);
                    navStamp.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, Math.max(8, st.optInt("fs", 13)));
                    navStamp.setShadowLayer(2f, 0f, 1f, 0xFF000000);
                    navStamp.setSingleLine(true);
                    int sw = act.getResources().getDisplayMetrics().widthPixels;
                    FrameLayout.LayoutParams sp2 = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.TOP | Gravity.RIGHT);
                    sp2.topMargin = Math.max(0, st.optInt("y")); sp2.rightMargin = Math.max(0, sw - (st.optInt("x") + st.optInt("w")));
                    screen.addView(navStamp, sp2);
                }
            } else {
                screen.addView(nav, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, navH, phone ? Gravity.BOTTOM : Gravity.TOP));
            }
        } catch (Throwable e) {
            try { if (nav != null) screen.removeView(nav); } catch (Throwable ignored) { }
            nav = null; navClock = null; navGeo = false; try { if (navStamp != null) screen.removeView(navStamp); } catch (Throwable ig) { } navStamp = null;
            buildNavSimple();
        }
    }

    private void tickNavClock() {
        if (navClock == null || closed) return;
        try { navClock.setText(new java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(new java.util.Date())); } catch (Throwable ignored) { }
        ui.postDelayed(this::tickNavClock, 10000);
    }

    /** Barra simples (se a página ainda não enviou o aspeto da barra). */
    private void buildNavSimple() {
        navBottom = act.getResources().getDisplayMetrics().widthPixels <= act.getResources().getDisplayMetrics().heightPixels;
        navH = dp(52);
        nav = new LinearLayout(act);
        nav.setOrientation(LinearLayout.HORIZONTAL);
        nav.setBackgroundColor(0xFF0E1A2E);
        nav.setPadding(dp(4), dp(4), dp(4), dp(4));
        /* v271: abas da app nativa (a app antiga com página web foi retirada) */
        final String[][] tabs = {{"📺 Canais", "live"}, {"🎬 Filmes", "movie"}, {"🎞️ Séries", "series"}, {"🔍 Pesquisar", "search"}, {"📡 Transmitir", "cast"}};
        String curKind = items.isEmpty() ? "live" : items.get(Math.max(0, Math.min(index, items.size() - 1))).kind;
        for (final String[] t : tabs) {
            final boolean cur = t[1].equals("live".equals(curKind) ? "live" : "movie");
            final TextView b = new TextView(act);
            b.setText(t[0]);
            b.setTextColor(cur ? 0xFF0B1220 : 0xFFE6EEF9);
            b.setTextSize(14f);
            b.setSingleLine(true);
            b.setGravity(Gravity.CENTER);
            b.setPadding(dp(6), dp(8), dp(6), dp(8));
            final int bgc = cur ? 0xFF7CC4FF : 0x00000000;
            b.setBackground(rr(bgc, 20));
            b.setFocusable(true);
            b.setClickable(true);
            b.setOnFocusChangeListener((v, f) -> b.setBackground(rr(f ? 0xFF2F7DD1 : bgc, 20)));
            b.setOnClickListener(v -> { if ("cast".equals(t[1])) { host.js("nscreen:act", "cast"); return; } close(); host.js("nscreen:nav", t[1]); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            nav.addView(b, lp);
        }
        screen.addView(nav, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, navH, navBottom ? Gravity.BOTTOM : Gravity.TOP));
    }

    private android.graphics.drawable.GradientDrawable rr(int color, int rdp) {
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(color); g.setCornerRadius(dp(rdp));
        return g;
    }

    /** Posição da barra: a mesma da página (telemóvel vertical: em baixo; restantes: em cima). */
    private void placeNav(boolean land) {
        if (nav == null || main == null) return;
        int nh = navH > 0 ? navH : dp(52);
        FrameLayout.LayoutParams ml = (FrameLayout.LayoutParams) main.getLayoutParams();
        ml.topMargin = navBottom ? 0 : nh; ml.bottomMargin = navBottom ? nh : 0;
        main.setLayoutParams(ml);
        FrameLayout.LayoutParams nl = (FrameLayout.LayoutParams) nav.getLayoutParams();
        if (!navGeo) { nl.gravity = navBottom ? Gravity.BOTTOM : Gravity.TOP; nl.height = nh; }
        nav.setLayoutParams(nl);
        nav.setVisibility(full ? View.GONE : View.VISIBLE);
        if (navStamp != null) navStamp.setVisibility(full ? View.GONE : View.VISIBLE);
    }

    /** (Re)organiza conforme a orientação: horizontal = lista | vídeo+botões; vertical = vídeo+botões por cima da lista. */
    private void applyOrientation() {
        boolean land = act.getResources().getDisplayMetrics().widthPixels > act.getResources().getDisplayMetrics().heightPixels;
        main.removeAllViews();
        ((ViewGroup) screen).setPadding(0, 0, 0, 0);
        placeNav(land);
        if (land) {
            main.setOrientation(LinearLayout.HORIZONTAL);
            setReserve();
            main.addView(listBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.32f));
            main.addView(right, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.68f));
        } else {
            main.setOrientation(LinearLayout.VERTICAL);
            setReserve();
            main.addView(right, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            main.addView(listBox, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
            ((ViewGroup) screen).setPadding(0, dp(4), 0, 0);
            screen.post(this::fixTopInset);   /* só deixa margem se a barra de estado realmente tapar o ecrã */
        }
    }

    private void fixTopInset() {
        try {
            if (closed || screen == null) return;
            boolean land = act.getResources().getDisplayMetrics().widthPixels > act.getResources().getDisplayMetrics().heightPixels;
            if (land) return;
            int[] loc = new int[2];
            screen.getLocationOnScreen(loc);
            int sb = 0, id = act.getResources().getIdentifier("status_bar_height", "dimen", "android");
            if (id > 0) sb = act.getResources().getDimensionPixelSize(id);
            int overlap = Math.max(0, sb - loc[1]);
            ((ViewGroup) screen).setPadding(0, overlap + dp(4), 0, 0);
        } catch (Throwable ignored) { }
    }

    /** Chamado quando o ecrã roda: reorganiza e reposiciona o vídeo quando a vista assenta (sem o esconder). */
    void onConfigChanged() {
        if (closed || screen == null || pipEntered) return;
        if (full) {   /* em ecrã total, rodar só reajusta a imagem (não volta ao menu) */
            applyOrientation();
            main.setVisibility(View.INVISIBLE);
            ui.postDelayed(() -> { if (!closed && full) applyFullLayout(); }, 350);
            ui.postDelayed(() -> { if (!closed && full) applyFullLayout(); }, 900);
            return;
        }
        lastKey = "";
        ui.removeCallbacks(rectRun);
        applyOrientation();
        try { host.js("nscreen:rot", ""); } catch (Throwable ignored) { }
        ui.postDelayed(rectRun, 350);
        ui.postDelayed(this::checkNav, 250);
        ui.postDelayed(this::checkNav, 500);
        ui.postDelayed(this::checkNav, 1200);
        ui.postDelayed(this::checkNav, 2500);
    }

    /* ------------------------------------------------------------ posição do vídeo */
    private String lastKey = "";
    private final Runnable rectRun = new Runnable() {
        @Override public void run() {
            if (closed || grid == null || full) return;
            int[] b = new int[2];
            root.getLocationInWindow(b);
            int ins = nslots > 1 ? dp(3) : 0;
            int[][] r = new int[MAXS][];
            StringBuilder k = new StringBuilder();
            for (int q = 0; q < nslots; q++) {
                if (sp[q] == null || ix(q) < 0) continue;
                int w = hs[q].getWidth(), h = hs[q].getHeight();
                if (w < 20 || h < 20) { ui.postDelayed(this, 150); return; }
                int[] a = new int[2];
                hs[q].getLocationInWindow(a);
                r[q] = new int[]{a[0] - b[0] + ins, a[1] - b[1] + ins, w - 2 * ins, h - 2 * ins};
                k.append(q).append(':').append(r[q][0]).append(',').append(r[q][1]).append(',').append(r[q][2]).append(',').append(r[q][3]).append('|');
            }
            String ks = k.toString();
            if (ks.equals(lastKey)) return;
            lastKey = ks;
            for (int q = 0; q < MAXS; q++) {
                if (sp[q] == null) continue;
                if (r[q] != null) sp[q].rect(r[q][0], r[q][1], r[q][2], r[q][3], true);
                else if (q > 0) sp[q].rect(0, 0, 1, 1, false);
            }
        }
    };

    private void scheduleRect() {
        ui.removeCallbacks(rectRun);
        ui.postDelayed(rectRun, 250);   /* só depois de a vista parar de mudar */
    }

    /* ------------------------------------------------------------ reprodução */
    private static String hintFor(String u, boolean live) {
        String l = u.toLowerCase();
        if (l.matches(".*\\.m3u8(\\?.*)?$")) return "hls";
        if (l.matches(".*\\.mpd(\\?.*)?$")) return "dash";
        if (!live) return "";
        if (l.matches(".*\\.ts(\\?.*)?$")) return "";
        return "hls";
    }

    private boolean isVod() { return index >= 0 && index < items.size() ? !"live".equals(items.get(index).kind) : (!items.isEmpty() && !"live".equals(items.get(0).kind)); }

    /** Envia à página a posição atual (filmes/episódios) para guardar a retoma. */
    private void reportPos() {
        if (closed || index < 0 || index >= items.size() || !isVod()) return;
        try {
            String[] a = np.pos().split("\\|");
            long p = Long.parseLong(a[0]), d = Long.parseLong(a[1]);
            if (d > 0 && "0".equals(a[2])) host.js("nscreen:pos", items.get(index).url + "|" + p + "|" + d);
        } catch (Throwable ignored) { }
    }

    private final Runnable posRun = new Runnable() {
        @Override public void run() {
            if (closed) return;
            reportPos();
            ui.postDelayed(this, 5000);
        }
    };

    private void applyMode() {
        boolean vod = isVod();
        if (btnSubs != null) setBtn(btnSubs, vod ? "🌐 Online" : "⏭ Direto");
        applyOrientationKeep();
    }

    private void applyOrientationKeep() { /* a reserva do vídeo depende de haver a linha extra */
        boolean land = act.getResources().getDisplayMetrics().widthPixels > act.getResources().getDisplayMetrics().heightPixels;
        setReserve();
    }

    private int ix(int q) { return q == 0 ? index : sidx[q]; }

    private boolean isShown(int itemIdx) {
        for (int q = 0; q < nslots; q++) if (ix(q) == itemIdx) return true;
        return false;
    }

    /** Frame 0 (o principal, que também serve filmes e episódios). */
    private void play(int i) {
        if (i < 0 || i >= items.size()) return;
        reportPos();
        index = i;
        lastPick = i;
        sret[0] = 0; sslow[0] = 0;
        sts[0] = false;
        sfirst[0] = true;
        Item it = items.get(i);
        ls[0].setText("A carregar…");
        ls[0].setVisibility(View.VISIBLE);
        adapter.notifyDataSetChanged();
        refreshInfo();
        applyMode();
        startSlotUrl(0, it.url, it);
        host.js("nscreen:play", it.url);
        scheduleRect();
    }

    /** Frames 1..3 (só canais em direto). */
    private void playSlot(int q, int i) {
        if (q == 0) { play(i); return; }
        if (q >= nslots || sp[q] == null || i < 0 || i >= items.size()) return;
        sidx[q] = i;
        lastPick = i;
        sret[q] = 0; sslow[q] = 0;
        sts[q] = false;
        sfirst[q] = true;
        Item it = items.get(i);
        ls[q].setText("A carregar…");
        ls[q].setVisibility(View.VISIBLE);
        adapter.notifyDataSetChanged();
        refreshInfo();
        startSlotUrl(q, it.url, it);
        host.js("nscreen:want", it.url);
        scheduleRect();
    }

    private void startSlotUrl(int q, String url, Item it) {
        try {
            sp[q].play(url, it.ref, hintFor(url, "live".equals(it.kind)), "", sfirst[q] ? it.start : 0);
            sfirst[q] = false;
            if ("live".equals(it.kind)) {
                final int ci = items.indexOf(it);
                ui.postDelayed(() -> {
                    try {
                        if (closed || ci < 0 || items.size() < 2) return;
                        Item nx = items.get((ci + 1) % items.size()), pv = items.get((ci - 1 + items.size()) % items.size());
                        /* v262: desligado. «Aquecer» o canal seguinte e o anterior pedia o endereço deles ao servidor IPTV, e cada pedido
                           conta como uma ligação: numa conta de 1 ligação o servidor cortava o canal que estava a dar com HTTP 509 ao fim
                           de ~40 s (visto no diário: Sport TV 1 a preto só com som, sem nenhum outro equipamento ligado). */
                        if (false) { NativePlayer.warm(nx.url, nx.ref); NativePlayer.warm(pv.url, pv.ref); }
                    } catch (Throwable ignored) { }
                }, 2500);
            }
            lastKey = "";   /* o leitor esconde a caixa ao começar: obriga a reenviar a posição */
            scheduleRect();
            applyVolumes();
            ui.postDelayed(() -> applyVolumes(), 1500);
            ui.postDelayed(() -> applyVolumes(), 4000);
        } catch (Throwable e) {
            ls[q].setText("Erro: " + e);
        }
    }

    private void playOnActive(int i) { playSlot(active, i); }

    private void step(int d) {
        if (items.isEmpty()) return;
        int cur = ix(active);
        int n = (cur + d + items.size()) % items.size();
        playOnActive(n);
        selectInList(n);
    }

    /** Eventos do leitor principal (vindos da atividade). Devolve true se tratou o evento. */
    boolean onPlayerEvent(String k, String m) {
        if (closed) return false;
        return onSlotEvent(0, k, m);
    }

    private boolean onSlotEvent(int q, String k, String m) {
        if (closed || q >= nslots) return true;
        if ("ready".equals(k)) { sret[q] = 0; sslow[q] = 0; ls[q].setVisibility(View.GONE); applyVolumes(); return true; }
        if ("buffering".equals(k)) return true;
        if ("note".equals(k)) { ls[q].setText(m); ls[q].setVisibility(View.VISIBLE); return true; }
        if ("ended".equals(k)) { if (q == 0 && isVod() && index + 1 < items.size()) step(1); return true; }
        if ("ui".equals(k)) {
            if (q != active) setActive(q);
            if ("tap".equals(m)) { if (nslots > 1 && soundSlot != q && ix(q) >= 0) setSound(q); if (full) { if (fsShown) hideFsList(); else showFsList(); } return true; }
            if ("aspect".equals(m)) cycleAspect();
            else if ("full".equals(m)) setFull(!full);
            return true;
        }
        if ("error".equals(k)) {
            final int i = ix(q);
            if (i < 0 || i >= items.size()) return true;
            final Item it = items.get(i);
            String u = it.url;
            final int fq = q;
            if ("live".equals(it.kind) && !sts[q] && u.matches("(?i).*\\.m3u8(\\?.*)?$") && u.contains("/live/")) {
                sts[q] = true;   /* mesmo canal em .ts, como na página */
                startSlotUrl(q, u.replaceFirst("(?i)\\.m3u8", ".ts"), it);
                return true;
            }
            if (sret[q] < 3) {
                sret[q]++;
                ls[q].setText("Sem sinal. A tentar de novo (" + sret[q] + "/3)…");
                ls[q].setVisibility(View.VISIBLE);
                ui.postDelayed(() -> { if (!closed && fq < nslots && ix(fq) == i) { sts[fq] = false; sfirst[fq] = true; startSlotUrl(fq, it.url, it); } }, 1500L * sret[q]);
            } else {
                /* não desiste: volta a tentar com intervalos crescentes (10 s, 20 s, 40 s, depois de minuto a minuto).
                   Os servidores IPTV cortam ligações ao fim de um tempo ou limitam as ligações em simultâneo. */
                sslow[q]++;
                final long wait = Math.min(60000L, 10000L << Math.min(3, sslow[q] - 1));
                ls[q].setText("Sem sinal. A reconectar em " + (wait / 1000) + " s…");
                ls[q].setVisibility(View.VISIBLE);
                ui.postDelayed(() -> { if (!closed && fq < nslots && ix(fq) == i && sp[fq] != null) { sts[fq] = false; sfirst[fq] = true; ls[fq].setText("A reconectar…"); startSlotUrl(fq, it.url, it); } }, wait);
            }
            return true;
        }
        if ("noaudio".equals(k)) { Toast.makeText(act, "Este canal tem áudio que o aparelho não descodifica. Tenta outra faixa em Áudio.", Toast.LENGTH_LONG).show(); return true; }
        return true;   /* o resto (aspect:info, hdr…) não interessa à página nesta altura */
    }

    /** Título e linha de informação conforme o frame ativo. */
    private void refreshInfo() {
        int i = ix(active);
        boolean multi = nslots > 1;
        if (i >= 0 && i < items.size()) {
            Item it = items.get(i);
            title.setText((multi ? "Frame " + (active + 1) + " · " : "") + it.name);
            epg.setText(it.epg.length() > 0 ? it.epg : it.group);   /* programa a decorrer com o intervalo (ex.: 21:00–22:00 · Telejornal) */
        } else {
            title.setText("Frame " + (active + 1) + " vazio");
            epg.setText("Escolhe agora o canal na lista para este frame.");
        }
    }

    /* ------------------------------------------------------------ pesquisa, categorias, vista dupla, legendas online */
    private NativePlayer cp() { return (active < nslots && sp[active] != null) ? sp[active] : np; }

    /** Horizontal: transporte compacto + opções na mesma linha (mais altura para o vídeo). Vertical: duas linhas. */
    private void applyCompact(boolean land) {
        if (ctrlBar == null) return;
        ctrlBar.setOrientation(land ? LinearLayout.HORIZONTAL : LinearLayout.VERTICAL);
        ctrlBar.setGravity(Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rp = (LinearLayout.LayoutParams) row3.getLayoutParams();
        rp.width = land ? ViewGroup.LayoutParams.WRAP_CONTENT : ViewGroup.LayoutParams.MATCH_PARENT;
        row3.setLayoutParams(rp);
        LinearLayout.LayoutParams hp = (LinearLayout.LayoutParams) hsvChips.getLayoutParams();
        hp.width = land ? 0 : ViewGroup.LayoutParams.MATCH_PARENT;
        hp.weight = land ? 1f : 0f;
        hp.topMargin = land ? 0 : dp(2);
        hp.leftMargin = land ? dp(6) : 0;
        hsvChips.setLayoutParams(hp);
        for (int i = 0; i < 5; i++) {
            TextView t = tb5[i];
            if (t == null) continue;
            boolean acc = i == 2;
            float sz = land ? (acc ? 20f : 17f) : (acc ? 26f : 22f);
            t.setTag(sz);
            t.setTextSize(sz);
            t.setPadding(dp(land ? 2 : 4), dp(land ? 5 : (acc ? 6 : 5)), dp(land ? 2 : 4), dp(land ? 5 : (acc ? 6 : 5)));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(land ? dp(acc ? 56 : 42) : 0, ViewGroup.LayoutParams.WRAP_CONTENT, land ? 0f : (acc ? 1.5f : 1f));
            lp.setMargins(dp(land ? 2 : 4), dp(land ? 0 : 4), dp(land ? 2 : 4), dp(land ? 0 : 2));
            t.setLayoutParams(lp);
            NIcons.refresh(t);
        }
        LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(land ? 40 : 46), dp(land ? 40 : 46));
        ip.setMargins(dp(4), 0, dp(2), 0);
        if (btnFull != null) btnFull.setLayoutParams(ip);
        if (btnExitRef != null) btnExitRef.setLayoutParams(ip);
        ctrlBar.requestLayout();
    }

    private void setReserve() {
        boolean land = act.getResources().getDisplayMetrics().widthPixels > act.getResources().getDisplayMetrics().heightPixels;
        applyCompact(land);
        grid.reserve = land ? dp(130) + (showStats ? dp(30) : 0) : 0;
        grid.requestLayout();
        /* v304: com a barra de progresso e as duas filas de botões, a parte de baixo saía do ecrã (Som, Online, Guia e Info ficavam escondidos):
           depois de medir, o vídeo encolhe o que faltar para os botões todos caberem */
        if (land && ctrlBar != null) {
            if (!reserveHook) { reserveHook = true;
                ctrlBar.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> ui.post(this::fitControls)); }
            ctrlBar.post(this::fitControls);
        }
    }
    private boolean reserveHook = false;
    private void fitControls() {
        try {
            if (ctrlBar == null || grid == null || ctrlBar.getHeight() <= 0 || !ctrlBar.isShown()) return;
            int[] loc = new int[2]; ctrlBar.getLocationOnScreen(loc);
            int bottom = loc[1] + ctrlBar.getHeight() + (statsView != null && statsView.getVisibility() == View.VISIBLE ? statsView.getHeight() : 0);
            int over = bottom - act.getResources().getDisplayMetrics().heightPixels + dp(8);
            if (over > 0 && grid.reserve < dp(420)) { grid.reserve += over; grid.requestLayout(); }
        } catch (Throwable ignored) { }
    }

    private void buildVis() {
        vis.clear();
        for (int i = 0; i < items.size(); i++) {
            Item it = items.get(i);
            if (groupFilter.length() > 0 && !groupFilter.equals(it.group)) continue;
            if (query.length() > 0 && !(it.name.toLowerCase().contains(query) || it.group.toLowerCase().contains(query))) continue;
            vis.add(i);
        }
        if (btnGroup != null) NIcons.set(btnGroup, "☰ " + (groupFilter.length() > 0 ? groupFilter : "Todos") + " · " + vis.size());
    }

    private void selectInList(int itemIdx) {
        int p = vis.indexOf(itemIdx);
        if (p >= 0 && list != null) list.setSelection(Math.max(0, p - 2));
    }

    private void pickGroup() {
        final ArrayList<String> gs = new ArrayList<String>();
        final ArrayList<String> labels = new ArrayList<String>();
        gs.add("");
        labels.add("Todos (" + items.size() + ")");
        for (Item it : items) {
            if (it.group.length() == 0 || gs.contains(it.group)) continue;
            int n = 0;
            for (Item x : items) if (x.group.equals(it.group)) n++;
            gs.add(it.group);
            labels.add(it.group + " (" + n + ")");
        }
        new AlertDialog.Builder(act).setTitle("Categoria")
                .setItems(labels.toArray(new String[0]), (d, which) -> { groupFilter = gs.get(which); buildVis(); adapter.notifyDataSetChanged(); })
                .show();
    }

    private void applyVolumes() {
        for (int q = 0; q < MAXS; q++) {
            try { if (sp[q] != null) sp[q].volume(q == soundSlot && q < nslots ? 1f : 0f); } catch (Throwable ignored) { }
        }
    }

    /** Realça o frame escolhido (moldura azul) e o que tem o foco do comando (moldura branca). */
    private void updateFrames() {
        for (int q = 0; q < MAXS; q++) {
            if (hs[q] == null) continue;
            int c = Color.BLACK;
            if (nslots > 1) c = q == active ? 0xFF2F7DD1 : (hs[q].isFocused() ? 0xFFFFFFFF : 0xFF1B2B47);
            hs[q].setBackgroundColor(c);
        }
    }

    private void setActive(int a) {
        if (a < 0 || a >= nslots) a = 0;
        active = a;
        applyVolumes();
        if (btnSound != null) setBtn(btnSound, "🔊 Som F" + (soundSlot + 1));
        updateFrames();
        refreshInfo();
        setBtn(btnAspect, "▭ " + ASP_L[sasp[active]]);
    }

    private final Runnable statsRun = new Runnable() {
        @Override public void run() {
            if (closed || !showStats) return;
            try { statsView.setText(cp().stats()); } catch (Throwable ignored) { }
            ui.postDelayed(this, 1000);
        }
    };

    private void toggleStats() {
        showStats = !showStats;
        statsView.setVisibility(showStats ? View.VISIBLE : View.GONE);
        setReserve();
        ui.removeCallbacks(statsRun);
        if (showStats) ui.post(statsRun);
    }

    /** Limita a resolução de cada frame conforme o tamanho que ocupa (menos peso para o aparelho). */
    private void applyCaps() {
        for (int q = 0; q < MAXS; q++) {
            if (sp[q] == null) continue;
            int w = 0, h = 0;
            if (nslots == 2 && !pip) { w = 1280; h = 720; }
            else if (nslots == 2 && pip) { if (q == 0) { w = 1920; h = 1080; } else { w = 640; h = 360; } }
            else if (nslots == 3) { w = 960; h = 540; }
            else if (nslots >= 4) { w = 854; h = 480; }
            try { sp[q].setMaxRes(w, h); } catch (Throwable ignored) { }
            try { sp[q].setLite(nslots >= 3 && q >= 1); } catch (Throwable ignored) { }
        }
    }

    private void setSound(int q) {
        soundSlot = q;
        applyVolumes();
        if (btnSound != null) setBtn(btnSound, "🔊 Som F" + (soundSlot + 1));
        Toast.makeText(act, "Som do frame " + (q + 1), Toast.LENGTH_SHORT).show();
    }

    private void cycleSound() { setSound((soundSlot + 1) % nslots); }

    private int lastPick = -1;
    private final Runnable frameGuard = new Runnable() {
        @Override public void run() {
            if (closed || nslots <= 1) return;
            if (full) { ui.postDelayed(this, 5000); return; }   /* ecrã inteiro: não mexe nos frames (causava preto passados segundos) */
            for (int q = 0; q < nslots; q++) { try { if (sp[q] != null) sp[q].checkFrames(); } catch (Throwable ignored) { } }
            ui.postDelayed(this, 5000);
        }
    };

    /** Foco na lista de canais, no canal do frame ativo. */
    private void focusList() {
        ui.postDelayed(() -> {
            try {
                if (closed || list == null) return;
                int p = ix(active) >= 0 ? vis.indexOf(ix(active)) : -1;
                if (p < 0 && lastPick >= 0) p = vis.indexOf(lastPick);   /* frame vazio: fica no último canal escolhido, não no topo */
                list.requestFocus();
                if (p < 0 && ix(0) >= 0) p = vis.indexOf(ix(0));
                list.setSelectionFromTop(Math.max(0, p), dp(110));   /* fica no canal escolhido, com uns canais acima visíveis */
            } catch (Throwable ignored) { }
        }, 60);
    }

    private void onFrameClick(int q) {
        if (nslots == 1) { setFull(true); return; }
        /* vários frames: OK no frame escolhe-o (e dá-lhe o som) e passa o foco para a lista de canais */
        if (q != active) setActive(q);
        if (soundSlot != q && ix(q) >= 0) setSound(q);
        focusList();
    }

    private void pickLayout() {
        if (full) return;
        final String[] labels = {"1 frame (normal)", "2 frames lado a lado", "2 frames · PIP (janela pequena)", "3 frames", "4 frames (grelha 2×2)", "💾 Guardar esta combinação", "📂 Combinações guardadas (" + presets().length() + ")"};
        new AlertDialog.Builder(act).setTitle("Frames · escolhe o frame e depois o canal")
                .setItems(labels, (d, which) -> {
                    if (which == 0) setLayout(1, false);
                    else if (which == 1) setLayout(2, false);
                    else if (which == 2) setLayout(2, true);
                    else if (which == 3) setLayout(3, false);
                    else if (which == 4) setLayout(4, false);
                    else if (which == 5) savePreset();
                    else listPresets();
                }).show();
    }

    /* ---------------------------------------------------- combinações de frames guardadas */
    private JSONArray presets() {
        try { return new JSONArray(act.getSharedPreferences("nsc", 0).getString("presets", "[]")); } catch (Throwable e) { return new JSONArray(); }
    }

    private void putPresets(JSONArray a) { act.getSharedPreferences("nsc", 0).edit().putString("presets", a.toString()).apply(); }

    private void savePreset() {
        try {
            if (nslots < 2) { Toast.makeText(act, "Põe 2 ou mais canais em frames antes de guardar.", Toast.LENGTH_LONG).show(); return; }
            JSONObject o = new JSONObject();
            JSONArray urls = new JSONArray();
            StringBuilder nm = new StringBuilder();
            for (int q = 0; q < nslots; q++) {
                int i = ix(q);
                urls.put(i >= 0 && i < items.size() ? items.get(i).url : "");
                if (i >= 0 && i < items.size()) { if (nm.length() > 0) nm.append(" + "); nm.append(items.get(i).name); }
            }
            o.put("name", (pip ? "PIP · " : nslots + "× · ") + nm);
            o.put("n", nslots);
            o.put("pip", pip);
            o.put("sound", soundSlot);
            o.put("urls", urls);
            JSONArray all = presets();
            all.put(o);
            putPresets(all);
            Toast.makeText(act, "Combinação guardada ✓", Toast.LENGTH_SHORT).show();
        } catch (Throwable e) { Toast.makeText(act, "Não guardei: " + e, Toast.LENGTH_LONG).show(); }
    }

    private void listPresets() {
        final JSONArray all = presets();
        if (all.length() == 0) { Toast.makeText(act, "Ainda não guardaste combinações.", Toast.LENGTH_LONG).show(); return; }
        final String[] names = new String[all.length()];
        for (int i = 0; i < names.length; i++) names[i] = all.optJSONObject(i) == null ? "?" : all.optJSONObject(i).optString("name");
        new AlertDialog.Builder(act).setTitle("Combinações guardadas")
                .setItems(names, (d, which) -> {
                    final JSONObject o = all.optJSONObject(which);
                    if (o == null) return;
                    new AlertDialog.Builder(act).setTitle(o.optString("name"))
                            .setPositiveButton("Abrir", (d2, w2) -> openPreset(o))
                            .setNegativeButton("Apagar", (d2, w2) -> {
                                try {
                                    JSONArray n2 = new JSONArray();
                                    for (int i = 0; i < all.length(); i++) if (i != which) n2.put(all.get(i));
                                    putPresets(n2);
                                } catch (Throwable ignored) { }
                            }).show();
                }).show();
    }

    private void openPreset(JSONObject o) {
        try {
            setLayout(o.optInt("n", 2), o.optBoolean("pip", false));
            JSONArray urls = o.optJSONArray("urls");
            int missing = 0;
            for (int q = 0; urls != null && q < urls.length() && q < nslots; q++) {
                String u = urls.optString(q);
                int found = -1;
                for (int i = 0; i < items.size(); i++) if (items.get(i).url.equals(u)) { found = i; break; }
                if (found >= 0) playSlot(q, found); else if (u.length() > 0) missing++;
            }
            soundSlot = Math.min(o.optInt("sound", 0), nslots - 1);
            setActive(0);
            if (missing > 0) Toast.makeText(act, missing + " canal(is) da combinação já não estão na lista.", Toast.LENGTH_LONG).show();
        } catch (Throwable e) { Toast.makeText(act, "Combinação: " + e, Toast.LENGTH_LONG).show(); }
    }

    /** Janela flutuante do sistema (Android PiP): o vídeo ocupa a janela toda, sem lista nem botões. */
    private boolean pipEntered = false;
    void setSystemPip(boolean in) {
        if (closed || screen == null) return;
        if (in) { if (!full) { pipEntered = true; setFull(true); } }
        else if (pipEntered) { pipEntered = false; if (full) setFull(false); }
    }

    private void setLayout(int n, boolean p) {
        if (full) return;
        if (n > 1 && (isVod() || items.size() < 2)) { Toast.makeText(act, "Vários frames são para canais em direto.", Toast.LENGTH_SHORT).show(); return; }
        int old = nslots;
        nslots = n;
        pip = p;
        boolean rebuilt0 = false;
        try { if (sp[0] != null) rebuilt0 = sp[0].switchSurface(n > 1); } catch (Throwable ignored) { }
        for (int q = 1; q < MAXS; q++) {
            if (q < n) {
                if (sp[q] == null) {
                    try {
                        final int fq = q;
                        sp[q] = new NativePlayer(act, root, (k, m) -> onSlotEvent(fq, k, m));
                        sp[q].shareAudio = true;
                        sp[q].useTexture(true);
                        sp[q].prepareViews();
                        sp[q].setAspect("fit", "Ajustar");
                    } catch (Throwable e) {
                        Toast.makeText(act, "Frame " + (q + 1) + " indisponível: " + e, Toast.LENGTH_LONG).show();
                        sp[q] = null;
                        nslots = q;
                        break;
                    }
                }
                hs[q].setVisibility(View.VISIBLE);
                if (q >= old && sidx[q] < 0) { ls[q].setText("Frame " + (q + 1) + "\nescolhe um canal na lista"); ls[q].setVisibility(View.VISIBLE); }
            } else {
                hs[q].setVisibility(View.GONE);
                sidx[q] = -1;
                try { if (sp[q] != null) { sp[q].stop(); sp[q].rect(0, 0, 1, 1, false); } } catch (Throwable ignored) { }
            }
        }
        for (int q = 1; q < nslots; q++) { try { sp[q].bringBoxToFront(); } catch (Throwable ignored) { } }   /* frames seguintes por cima (PIP) */
        setBtn(btnDual, "⧉ " + (pip ? "PIP" : nslots + (nslots == 1 ? " frame" : " frames")));
        applyOrientationKeep();
        grid.requestLayout();
        adapter.notifyDataSetChanged();
        if (soundSlot >= nslots) soundSlot = 0;
        if (rebuilt0 && index >= 0 && index < items.size()) {   /* vistas do frame 1 recriadas: volta a abrir o canal */
            try { sp[0].setAspect(ASP[sasp[0]], ASP_L[sasp[0]]); } catch (Throwable ignored) { }
            play(index);
        }
        ui.removeCallbacks(frameGuard);   /* desligado (v179): o contador de frames dava falsos positivos e recarregava os 4 frames ao fim de ~13 s (ecrã a azul) */
        applyCaps();
        try { if (sp[0] != null) { sp[0].setTunnelAllowed(nslots <= 1); } } catch (Throwable ignored) { }
        /* ensureVideoAlive desligado (v179): falsos positivos */
        for (long dl : new long[]{700, 2200}) ui.postDelayed(() -> { if (!closed) for (int q = 0; q < nslots; q++) { try { if (sp[q] != null) sp[q].reattachSurface(); } catch (Throwable ignored) { } } }, dl);
        setActive(nslots > old ? old : Math.min(active, nslots - 1));
        lastKey = "";
        scheduleRect();
        if (nslots > old) focusList();   /* novo frame: o foco vai para a lista, para escolher o canal */
    }

    private void onlineSubs() {
        if (index < 0 || index >= items.size()) return;
        Toast.makeText(act, "A procurar legendas…", Toast.LENGTH_SHORT).show();
        host.js("nscreen:subsearch", items.get(index).name);
    }

    /** Comandos vindos da página (resultados de legendas, avisos). */
    void command(String cmd, String payload) {
        if (closed) return;
        try {
            if ("full".equals(cmd)) { fromHome = true; autoFull(0); return; }
            if ("msg".equals(cmd)) { Toast.makeText(act, payload, Toast.LENGTH_LONG).show(); return; }
            if ("epg".equals(cmd)) {   /* programa a decorrer por canal: {url: "21:00–22:00 · Título"} */
                JSONObject m = new JSONObject(payload);
                for (Item it : items) { String t = m.optString(it.url, null); if (t != null && it.kind.equals("live")) it.epg = t; }
                adapter.notifyDataSetChanged();
                refreshInfo();
                return;
            }
            if ("subres".equals(cmd)) {
                JSONArray a = new JSONArray(payload);
                if (a.length() == 0) { Toast.makeText(act, "Não encontrei legendas em português.", Toast.LENGTH_LONG).show(); return; }
                final String[] labels = new String[a.length()];
                for (int i = 0; i < labels.length; i++) labels[i] = a.getString(i);
                new AlertDialog.Builder(act).setTitle("Legendas online")
                        .setItems(labels, (d, which) -> { Toast.makeText(act, "A descarregar legenda…", Toast.LENGTH_SHORT).show(); host.js("nscreen:subpick", String.valueOf(which)); })
                        .show();
            }
        } catch (Throwable e) { Toast.makeText(act, "Legendas: " + e, Toast.LENGTH_LONG).show(); }
    }

    /** Canal escolhido no Início: entra em ecrã total com a imagem esticada, assim que houver um frame a dar. */
    private void autoFull(final int tries) {
        ui.postDelayed(() -> {
            try {
                if (closed || full) return;
                /* só depois de haver imagem (entrar antes deixava só o som) */
                if (ix(active) >= 0 && sp[active] != null && sp[active].hasFrame()) {
                    int ai = 2; try { if (isVod()) ai = Math.max(0, Math.min(ASP.length - 1, act.getSharedPreferences("np", 0).getInt("aspectFull", 2))); } catch (Throwable ignored) { }   /* v274: formato escolhido em Definições › Imagem */
                    sasp[active] = ai;
                    try { sp[active].setAspect(ASP[ai], ASP_L[ai]); } catch (Throwable ignored) { }
                    setFull(true);
                    if (full) {
                        for (int d : new int[]{350, 1100, 2500}) ui.postDelayed(() -> { try { if (!closed && full && sp[active] != null) sp[active].reattachIfStalled(); } catch (Throwable ignored) { } }, d);
                        return;
                    }
                }
                if (tries < 60) autoFull(tries + 1);
            } catch (Throwable ignored) { }
        }, tries == 0 ? 250 : 400);
    }

    /* ------------------------------------------------------------ botões */
    private void cycleAspect() {
        sasp[active] = (sasp[active] + 1) % ASP.length;
        cp().setAspect(ASP[sasp[active]], ASP_L[sasp[active]]);
        setBtn(btnAspect, "▭ " + ASP_L[sasp[active]]);
    }

    /** Posiciona os vídeos em ecrã total (também chamado depois de rodar o ecrã, sem sair do ecrã total). */
    private void applyFullLayout() {
            if (nslots > 1 && !pip) {   /* grelha em ecrã total: todos os frames a ocupar o ecrã */
                int W = root.getWidth(), H = root.getHeight(), g = dp(2);
                int rows = nslots <= 2 ? 1 : 2;
                int cw = (W - g) / 2, chh = (H - g * (rows - 1)) / rows;
                for (int q = 0; q < MAXS; q++) {
                    if (sp[q] == null) continue;
                    try {
                        if (q < nslots && ix(q) >= 0) { sp[q].bringBoxToFront(); sp[q].rect((q % 2) * (cw + g), (q / 2) * (chh + g), cw, chh, true); }
                        else sp[q].rect(0, 0, 1, 1, false);
                    } catch (Throwable ignored) { }
                }
                fullSlot = active;
                for (int q = 0; q < nslots; q++) { try { if (sp[q] != null) sp[q].setAspect("stretch", "Esticar"); } catch (Throwable ignored) { } }
                setBtn(btnFull, "⤡");
                return;
            }
            fullSlot = pip && nslots > 1 ? 0 : active;   /* PIP: o principal ocupa o ecrã e a janela pequena continua por cima */
            for (int q = 0; q < MAXS; q++) { if (q != fullSlot && sp[q] != null) { try { sp[q].rect(0, 0, 1, 1, false); } catch (Throwable ignored) { } } }
            try { sp[fullSlot].bringBoxToFront(); } catch (Throwable ignored) { }
            sp[fullSlot].setFull(true);
            /* v300: canais em ecrã total abrem sempre esticados (o botão de formato continua a poder mudar depois) */
            if (!isVod()) { try { sp[fullSlot].setAspect("stretch", "Esticar"); } catch (Throwable ignored) { } }
            if (pip && nslots > 1) { for (int q = 0; q < nslots; q++) { try { if (sp[q] != null) sp[q].setAspect("stretch", "Esticar"); } catch (Throwable ignored) { } } }
            if (pip && nslots > 1 && sp[1] != null && sidx[1] >= 0) {
                int W = root.getWidth(), H = root.getHeight();
                int sw = Math.max(W * 28 / 100, dp(140)), sh = sw * 9 / 16;
                try { sp[1].bringBoxToFront(); sp[1].rect(W - sw - dp(16), H - sh - dp(16), sw, sh, true); } catch (Throwable ignored) { }
            }
            fsFront();
    }

    private void setFull(boolean on) {
        if (on == full) return;
        if (on && ix(active) < 0) return;
        full = on;
        hideFsList();
        main.setVisibility(on ? View.INVISIBLE : View.VISIBLE);
        if (nav != null) nav.setVisibility(on ? View.GONE : View.VISIBLE);
        if (navStamp != null) navStamp.setVisibility(on ? View.GONE : View.VISIBLE);
        if (on) {
            applyFullLayout();
        } else {
            for (int q = 0; q < MAXS; q++) { if (sp[q] != null) { try { sp[q].setFull(false); sp[q].setAspect(ASP[sasp[q]], ASP_L[sasp[q]]); } catch (Throwable ignored) { } } }
            for (int q = 0; q < nslots; q++) { if (sp[q] != null) { try { sp[q].bringBoxToFront(); } catch (Throwable ignored) { } } }
        }
        setBtn(btnFull, on ? "⤡" : "⛶");
        if (!on) {
            lastKey = ""; ui.removeCallbacks(rectRun); ui.postDelayed(rectRun, 200);
            /* ao sair do ecrã inteiro a vista com foco estava invisível e o foco perdia-se: sem setas. Devolve o foco ao frame ativo. */
            ui.postDelayed(() -> {
                try {
                    if (closed || full) return;
                    if (toListOnExit) { toListOnExit = false; focusList(); return; }
                    View t = btnFull != null && btnFull.isShown() ? btnFull : (hs[active] != null && hs[active].isShown() ? hs[active] : list);   /* volta ao ícone de ecrã inteiro */
                    if (t != null) t.requestFocus();
                } catch (Throwable ignored) { }
            }, 120);
            ui.postDelayed(() -> { try { if (!closed && !full && btnFull != null && btnFull.isShown() && !btnFull.hasFocus() && !(list != null && list.hasFocus())) btnFull.requestFocus(); } catch (Throwable ignored) { } }, 500);
        }
    }

    /* ---------------------------------------------------- lista de canais sobre o ecrã total */
    private void buildFsList() {
        if (fsOv != null) return;
        fsOv = new FrameLayout(act);
        fsOv.setBackgroundColor(0xE60B1220);
        fsOv.setClickable(true);   /* os toques na lista não chegam ao vídeo */
        fsList = new ListView(act);
        fsList.setDivider(null);
        fsList.setSelector(new android.graphics.drawable.ColorDrawable(0x552F7DD1));
        fsList.setAdapter(adapter);
        fsList.setOnItemClickListener((p, v, i, id) -> {
            if (i >= 0 && i < vis.size()) {
                int k = vis.get(i);
                lastPick = k;
                if (ix(active) != k) { playOnActive(k); selectInList(k); }
                adapter.notifyDataSetChanged();
                try { Toast.makeText(act, items.get(k).name, Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) { }
                /* escolhido o canal: fecha a lista para o canal aparecer em ecrã total e repõe o vídeo */
                ui.postDelayed(() -> { if (closed) return; hideFsList(); if (full) applyFullLayout(); }, 300);
            }
        });
        fsList.setOnTouchListener((v, e) -> { fsPoke(); return false; });
        fsList.setOnScrollListener(new android.widget.AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(android.widget.AbsListView v, int st) { fsPoke(); }
            @Override public void onScroll(android.widget.AbsListView v, int a, int b, int c) { }
        });
        TextView hint = new TextView(act);
        hint.setText("Canais   ·   Desligar: Definições › TV e vídeo");
        hint.setTextColor(0xFF8DA2BD);
        hint.setTextSize(12f);
        hint.setPadding(dp(14), dp(10), dp(8), dp(4));
        LinearLayout col = new LinearLayout(act);
        col.setOrientation(LinearLayout.VERTICAL);
        col.addView(hint, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        col.addView(fsList, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        fsOv.addView(col, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void fsFront() { try { if (fsShown && fsOv != null && fsOv.getParent() == root) root.bringChildToFront(fsOv); } catch (Throwable ignored) { } }

    /** Reinicia o temporizador que fecha a lista (7 s sem mexer). */
    private void fsPoke() { ui.removeCallbacks(fsHide); if (fsShown) ui.postDelayed(fsHide, 7000); }

    private boolean fsOff() { try { return "off".equals(act.getSharedPreferences("np", 0).getString("fsList", "all")); } catch (Throwable e) { return false; } }

    private void showFsList() {
        if (!full || closed || items.isEmpty() || fsOff()) return;
        buildFsList();
        if (fsShown) { fsPoke(); return; }
        int W = root.getWidth();
        int w = Math.min(dp(340), Math.max(dp(220), W * 45 / 100));
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(w, ViewGroup.LayoutParams.MATCH_PARENT);
        lp.gravity = Gravity.LEFT;
        try { if (fsOv.getParent() != null) ((ViewGroup) fsOv.getParent()).removeView(fsOv); } catch (Throwable ignored) { }
        root.addView(fsOv, lp);
        fsShown = true;
        adapter.notifyDataSetChanged();
        int cur = vis.indexOf(ix(active));
        if (cur >= 0) fsList.setSelectionFromTop(cur, dp(80));
        fsOv.setAlpha(0f);
        fsOv.setTranslationX(-dp(40));
        fsOv.animate().alpha(1f).translationX(0f).setDuration(180).start();
        fsList.requestFocus();
        fsPoke();
    }

    private void hideFsList() {
        ui.removeCallbacks(fsHide);
        if (!fsShown) return;
        fsShown = false;
        try { if (fsOv != null && fsOv.getParent() != null) ((ViewGroup) fsOv.getParent()).removeView(fsOv); } catch (Throwable ignored) { }
    }

    private void tracks(final String type, String label) {
        try {
            JSONObject j = new JSONObject(cp().tracks());
            JSONArray a = j.optJSONArray(type);
            final boolean text = "text".equals(type);
            int n = a == null ? 0 : a.length();
            final ArrayList<String> names = new ArrayList<String>();
            final ArrayList<Integer> ids = new ArrayList<Integer>();
            if (text) { names.add("Sem legendas"); ids.add(-1); }
            for (int i = 0; i < n; i++) {
                JSONObject o = a.getJSONObject(i);
                names.add((o.optBoolean("on") ? "● " : "○ ") + o.optString("name"));
                ids.add(o.optInt("i"));
            }
            /* v265: acertar o som com a imagem (fica guardado para o altifalante e para o Bluetooth, à parte) */
            if (!text) {
                int av = cp().getAv();
                names.add("⏱ Som atrasado → atrasar a imagem 100 ms (agora " + av + " ms)"); ids.add(-1001);
                names.add("⏱ Som adiantado → adiantar a imagem 100 ms"); ids.add(-1002);
                if (av != 0) { names.add("⏱ Repor acerto do som (0 ms)"); ids.add(-1003); }
                names.add(cp().dolbySw() ? "🔈 Som Dolby: descodificado pela app ✓ (toca para usar o do aparelho)" : "🔈 Som Dolby: descodificador do aparelho ✓ (toca para usar o da app)"); ids.add(-1004);
            }
            if (names.isEmpty()) { Toast.makeText(act, "Este canal só tem a faixa de áudio por defeito.", Toast.LENGTH_SHORT).show(); return; }
            new AlertDialog.Builder(act).setTitle(label)
                    .setItems(names.toArray(new String[0]), (d, which) -> {
                        int id = ids.get(which);
                        if (id == -1004) { boolean on = !cp().dolbySw(); cp().setDolbySw(on); Toast.makeText(act, "Som Dolby " + (on ? "pela app" : "pelo aparelho") + ": vale ao abrir o próximo canal ou filme.", Toast.LENGTH_LONG).show(); return; }
                        if (id <= -1001) {
                            int av = cp().getAv(); av = id == -1001 ? av + 100 : id == -1002 ? av - 100 : 0;
                            cp().setAv(av);
                            Toast.makeText(act, "Acerto do som: " + (av > 0 ? "imagem atrasada " + av : av < 0 ? "imagem adiantada " + (-av) : "0") + " ms", Toast.LENGTH_SHORT).show();
                            tracks(type, label);   /* reabre para poder carregar várias vezes */
                            return;
                        }
                        cp().pick(type, id);
                    })
                    .show();
        } catch (Throwable e) {
            Toast.makeText(act, "Sem faixas: " + e, Toast.LENGTH_SHORT).show();
        }
    }

    /* ------------------------------------------------------------ linha da lista */
    private final class Row extends LinearLayout {
        final ImageView img;
        final TextView name, sub;
        String shown = "";

        Row(Activity a) {
            super(a);
            setOrientation(HORIZONTAL);
            setGravity(Gravity.CENTER_VERTICAL);
            setPadding(dp(8), dp(4), dp(8), dp(4));
            img = new ImageView(a);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            img.setBackground(round(0xFF1B2B47, 8));
            addView(img, new LayoutParams(dp(54), dp(40)));
            LinearLayout col = new LinearLayout(a);
            col.setOrientation(VERTICAL);
            col.setPadding(dp(10), 0, 0, 0);
            name = new TextView(a);
            name.setTextColor(Color.WHITE);
            name.setTextSize(15f);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            sub = new TextView(a);
            sub.setTextColor(0xFF8DA2BD);
            sub.setTextSize(12f);
            sub.setSingleLine(true);
            sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
            col.addView(name);
            col.addView(sub);
            addView(col, new LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }

        void bind(Item it, boolean current) {
            name.setText(it.name);
            sub.setText(it.epg.length() > 0 ? it.epg : it.group);
            setBackgroundColor(current ? 0x552F7DD1 : Color.TRANSPARENT);
            shown = it.logo;
            img.setImageBitmap(null);
            if (it.logo.length() == 0) return;
            Bitmap b = PiconCache.mem(it.logo);
            if (b != null) { img.setImageBitmap(b); return; }
            final String u = it.logo;
            PiconCache.load(u, bm -> { if (bm != null && u.equals(shown)) img.setImageBitmap(bm); });   /* v277: memória partilhada com o Início, os visíveis primeiro */
        }
    }

    private Bitmap download(String u) {
        HttpURLConnection c = null;
        InputStream in = null;
        try {
            c = (HttpURLConnection) new URL(u).openConnection();
            c.setConnectTimeout(6000);
            c.setReadTimeout(6000);
            c.setInstanceFollowRedirects(true);
            in = c.getInputStream();
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = 2;
            return BitmapFactory.decodeStream(in, null, o);
        } catch (Throwable e) {
            return null;
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) { }
            try { if (c != null) c.disconnect(); } catch (Throwable ignored) { }
        }
    }
}
