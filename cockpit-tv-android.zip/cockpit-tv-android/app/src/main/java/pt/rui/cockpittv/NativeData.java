package pt.rui.cockpittv;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/**
 * App nativa (v270): dados da lista IPTV sem a página web.
 * Lê a configuração que a app clássica guardou (servidor Xtream / M3U, favoritos, vistos), descarrega as listas
 * pela API Xtream (ou M3U), guarda-as em disco (abre instantaneamente da vez seguinte) e organiza por categorias.
 * Tudo corre fora da thread da interface.
 */
final class NativeData {
    static final class Item {
        String name = "", logo = "", group = "", url = "", kind = "live", id = "", sid = "", epgId = "", plot = "", rating = "", year = "";
        int num = 0;
        long added = 0;
        int season = 0, ep = 0;
        JSONObject json() {
            JSONObject o = new JSONObject();
            try { o.put("name", name); o.put("logo", logo); o.put("group", group); o.put("url", url); o.put("kind", kind); o.put("id", id); o.put("sid", sid); o.put("epgId", epgId); o.put("season", season); o.put("ep", ep); } catch (Throwable ignored) { }
            return o;
        }
        static Item from(JSONObject o) {
            Item it = new Item();
            it.name = o.optString("name"); it.logo = o.optString("logo"); it.group = o.optString("group"); it.url = o.optString("url");
            it.kind = o.optString("kind", "live"); it.id = o.optString("id"); it.sid = o.optString("sid"); it.epgId = o.optString("epgId");
            it.season = o.optInt("season"); it.ep = o.optInt("ep");
            if ("vod".equals(it.kind)) it.kind = "movie";
            return it;
        }
    }
    static final class Cat { String id = "", name = ""; final List<Item> items = new ArrayList<>(); }

    private static final long TTL = 12L * 3600 * 1000;
    private static final String UA = "Mozilla/5.0 (Linux; Android) CockpitTV";
    private final Context ctx;
    private final SharedPreferences sp;
    String server = "", user = "", pass = "", m3u = "";
    /** por tipo (live / movie / series): categorias por ordem, com os itens de cada uma */
    final Map<String, List<Cat>> cats = new HashMap<>();
    final Map<String, List<Item>> all = new HashMap<>();

    NativeData(Context c) {
        ctx = c.getApplicationContext();
        sp = ctx.getSharedPreferences("nativeapp", 0);
        loadCfg();
    }

    /* ------------------------------------------------------------ configuração */
    void loadCfg() {
        server = sp.getString("xs", ""); user = sp.getString("xu", ""); pass = sp.getString("xp", ""); m3u = sp.getString("m3u", "");
        /* primeira vez: vem da app clássica (a MainActivity copia o localStorage da página para «webexport») */
        if (server.isEmpty() && m3u.isEmpty()) importFromWeb();
    }
    boolean importFromWeb() {
        SharedPreferences w = ctx.getSharedPreferences("webexport", 0);
        return importJson(w.getString("cfg", ""), w.getString("favs", "[]"), w.getString("recents", "[]"));
    }
    /** Dados da app antiga (localStorage da página): servidor, conta OpenSubtitles, favoritos e vistos. */
    boolean importJson(String c, String favs, String recents) {
        try {
            if (c == null || c.length() < 3) return false;
            JSONObject o = new JSONObject(c);
            if (o.optString("xs").isEmpty() && o.optString("m3u").isEmpty()) return false;
            SharedPreferences.Editor e = sp.edit();
            e.putString("xs", o.optString("xs")).putString("xu", o.optString("xu")).putString("xp", o.optString("xp")).putString("m3u", o.optString("m3u")).putString("epg", o.optString("epg"));
            if (sp.getString("osKey", "").isEmpty()) e.putString("osKey", o.optString("osKey")).putString("osUser", o.optString("osUser")).putString("osPass", o.optString("osPass")).putBoolean("osAuto", o.optBoolean("osAuto"));
            if (!sp.contains("favs") && favs != null) e.putString("favs", favs);
            if (!sp.contains("recents") && recents != null) e.putString("recents", recents);
            e.apply();
            server = o.optString("xs"); user = o.optString("xu"); pass = o.optString("xp"); m3u = o.optString("m3u");
            return server.length() > 0 || m3u.length() > 0;
        } catch (Throwable e) { return false; }
    }
    void saveCfg(String xs, String xu, String xp, String m) {
        sp.edit().putString("xs", xs.trim()).putString("xu", xu.trim()).putString("xp", xp).putString("m3u", m.trim()).apply();
        server = xs.trim(); user = xu.trim(); pass = xp; m3u = m.trim();
        clearCache();
    }
    boolean configured() { return (server.length() > 0 && user.length() > 0) || m3u.length() > 0; }
    private String base() {
        String s = server.trim(); if (s.isEmpty()) return "";
        if (!s.startsWith("http")) s = "http://" + s;
        s = s.replaceAll("/(player_api|get)\\.php.*$", "");
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }
    private String enc(String s) { try { return URLEncoder.encode(s, "UTF-8"); } catch (Throwable e) { return s; } }
    private String api(String action, String extra) { return base() + "/player_api.php?username=" + enc(user) + "&password=" + enc(pass) + "&action=" + action + (extra == null ? "" : extra); }

    /* ------------------------------------------------------------ rede e cache em disco */
    private File cacheFile(String k) { File d = new File(ctx.getFilesDir(), "nlist"); d.mkdirs(); return new File(d, k.replaceAll("[^a-zA-Z0-9_]", "_") + ".json"); }
    void clearCache() { try { File d = new File(ctx.getFilesDir(), "nlist"); File[] fs = d.listFiles(); if (fs != null) for (File f : fs) f.delete(); } catch (Throwable ignored) { } cats.clear(); all.clear(); }
    boolean cacheFresh(String kind) { File f = cacheFile("x_" + kind + "_streams"); return f.exists() && System.currentTimeMillis() - f.lastModified() < TTL; }

    static String http(String u, int timeoutMs) throws Exception {
        HttpURLConnection c = null;
        try {
            String cur = u;
            for (int i = 0; i < 6; i++) {
                c = (HttpURLConnection) new URL(cur).openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(timeoutMs); c.setReadTimeout(timeoutMs * 3);
                c.setRequestProperty("User-Agent", UA);
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) { String loc = c.getHeaderField("Location"); c.disconnect(); if (loc == null) break; cur = new URL(new URL(cur), loc).toString(); continue; }
                if (code >= 400) throw new Exception("HTTP " + code);
                InputStream in = c.getInputStream();
                BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"), 65536);
                StringBuilder sb = new StringBuilder(65536); char[] buf = new char[16384]; int n;
                while ((n = r.read(buf)) > 0) sb.append(buf, 0, n);
                r.close();
                return sb.toString();
            }
            throw new Exception("demasiados redirecionamentos");
        } finally { if (c != null) try { c.disconnect(); } catch (Throwable ignored) { } }
    }
    private String cached(String key, String url, boolean force) throws Exception {
        File f = cacheFile(key);
        if (!force && f.exists() && System.currentTimeMillis() - f.lastModified() < TTL) return readFile(f);
        try {
            String s = http(url, 15000);
            try (FileOutputStream o = new FileOutputStream(f)) { o.write(s.getBytes("UTF-8")); }
            return s;
        } catch (Exception e) {
            if (f.exists()) return readFile(f);   /* sem rede: usa a última lista guardada, mesmo antiga */
            throw e;
        }
    }
    private static String readFile(File f) throws Exception {
        try (FileInputStream in = new FileInputStream(f)) { byte[] b = new byte[(int) f.length()]; int o = 0, n; while (o < b.length && (n = in.read(b, o, b.length - o)) > 0) o += n; return new String(b, 0, o, "UTF-8"); }
    }

    /* ------------------------------------------------------------ carregar listas */
    /** kind: live | movie | series. Força a renovação com force=true. */
    synchronized void load(String kind, boolean force) throws Exception {
        if (!force && cats.containsKey(kind)) return;
        if (server.length() > 0 && user.length() > 0) loadXtream(kind, force);
        else if (m3u.length() > 0) loadM3u(force);
        else throw new Exception("Sem lista configurada. Abre as Definições.");
    }
    private void loadXtream(String kind, boolean force) throws Exception {
        String ca = kind.equals("live") ? "get_live_categories" : kind.equals("movie") ? "get_vod_categories" : "get_series_categories";
        String st = kind.equals("live") ? "get_live_streams" : kind.equals("movie") ? "get_vod_streams" : "get_series";
        JSONArray jc = new JSONArray(cached("x_" + kind + "_cats", api(ca, null), force));
        JSONArray js = new JSONArray(cached("x_" + kind + "_streams", api(st, null), force));
        LinkedHashMap<String, Cat> m = new LinkedHashMap<>();
        for (int i = 0; i < jc.length(); i++) { JSONObject o = jc.optJSONObject(i); if (o == null) continue; Cat c = new Cat(); c.id = o.optString("category_id"); c.name = o.optString("category_name"); m.put(c.id, c); }
        List<Item> list = new ArrayList<>(js.length());
        String b = base(), u = enc(user), p = enc(pass);
        for (int i = 0; i < js.length(); i++) {
            JSONObject o = js.optJSONObject(i); if (o == null) continue;
            Item it = new Item(); it.kind = kind; it.name = o.optString("name").trim();
            String cid = o.optString("category_id");
            Cat c = m.get(cid); if (c == null) { c = new Cat(); c.id = cid; c.name = "Sem categoria"; m.put(cid, c); }
            it.group = c.name;
            if (kind.equals("live")) {
                it.id = o.optString("stream_id"); it.logo = o.optString("stream_icon"); it.epgId = o.optString("epg_channel_id"); it.num = o.optInt("num");
                it.url = b + "/live/" + u + "/" + p + "/" + it.id + ".m3u8";
            } else if (kind.equals("movie")) {
                it.id = o.optString("stream_id"); it.logo = o.optString("stream_icon"); it.rating = o.optString("rating"); it.year = o.optString("year");
                try { it.added = Long.parseLong(o.optString("added", "0")); } catch (Throwable ignored) { }
                if (it.year.isEmpty()) { java.util.regex.Matcher ym = java.util.regex.Pattern.compile("\\b(19\\d\\d|20\\d\\d)\\b").matcher(it.name); if (ym.find()) it.year = ym.group(1); }
                String ext = o.optString("container_extension", "mp4"); if (ext.isEmpty()) ext = "mp4";
                it.url = b + "/movie/" + u + "/" + p + "/" + it.id + "." + ext;
            } else {
                it.sid = o.optString("series_id"); it.id = it.sid; it.logo = o.optString("cover"); it.plot = o.optString("plot"); it.rating = o.optString("rating");
                try { it.added = Long.parseLong(o.optString("last_modified", "0")); } catch (Throwable ignored) { }
                String rd = o.optString("releaseDate", o.optString("release_date")); if (rd.length() >= 4) it.year = rd.substring(0, 4);
                it.url = "series:" + it.sid;
            }
            c.items.add(it); list.add(it);
        }
        List<Cat> out = new ArrayList<>();
        for (Cat c : m.values()) if (!c.items.isEmpty()) out.add(c);
        cats.put(kind, out); all.put(kind, list);
    }
    private void loadM3u(boolean force) throws Exception {
        String s = cached("m3u", m3u, force);
        LinkedHashMap<String, Map<String, Cat>> byKind = new LinkedHashMap<>();
        Map<String, List<Item>> lists = new HashMap<>();
        for (String k : new String[]{"live", "movie", "series"}) { byKind.put(k, new LinkedHashMap<>()); lists.put(k, new ArrayList<>()); }
        Item pend = null;
        for (String line : s.split("\n")) {
            line = line.trim();
            if (line.startsWith("#EXTINF")) {
                pend = new Item();
                pend.logo = attr(line, "tvg-logo"); pend.group = attr(line, "group-title"); pend.epgId = attr(line, "tvg-id");
                int k = line.lastIndexOf(','); pend.name = k >= 0 ? line.substring(k + 1).trim() : "";
            } else if (pend != null && line.length() > 0 && !line.startsWith("#")) {
                pend.url = line; String l = line.toLowerCase();
                pend.kind = l.contains("/movie/") ? "movie" : l.contains("/series/") ? "series" : "live";
                if (pend.kind.equals("series")) pend.kind = "movie";   /* M3U: episódios soltos tratados como filmes */
                if (pend.group.isEmpty()) pend.group = "Sem categoria";
                Map<String, Cat> mc = byKind.get(pend.kind);
                Cat c = mc.get(pend.group); if (c == null) { c = new Cat(); c.id = pend.group; c.name = pend.group; mc.put(pend.group, c); }
                c.items.add(pend); lists.get(pend.kind).add(pend);
                pend = null;
            }
        }
        for (String k : byKind.keySet()) { cats.put(k, new ArrayList<>(byKind.get(k).values())); all.put(k, lists.get(k)); }
    }
    private static String attr(String line, String a) {
        int i = line.indexOf(a + "=\""); if (i < 0) return "";
        int s0 = i + a.length() + 2, e = line.indexOf('"', s0); return e > s0 ? line.substring(s0, e) : "";
    }

    /** Temporadas e episódios de uma série (Xtream get_series_info). */
    final Map<String, JSONObject> seriesMeta = new HashMap<>();
    List<Cat> seriesInfo(Item s, boolean force) throws Exception {
        JSONObject o = new JSONObject(cached("x_series_" + s.sid, api("get_series_info", "&series_id=" + enc(s.sid)), force));
        JSONObject inf0 = o.optJSONObject("info"); if (inf0 != null) seriesMeta.put(s.sid, inf0);
        JSONObject eps = o.optJSONObject("episodes");
        List<Cat> out = new ArrayList<>();
        if (eps == null) return out;
        List<String> keys = new ArrayList<>(); java.util.Iterator<String> itk = eps.keys(); while (itk.hasNext()) keys.add(itk.next());
        java.util.Collections.sort(keys, (a, b) -> { try { return Integer.parseInt(a) - Integer.parseInt(b); } catch (Throwable e) { return a.compareTo(b); } });
        String b = base(), u = enc(user), p = enc(pass);
        for (String k : keys) {
            JSONArray a = eps.optJSONArray(k); if (a == null) continue;
            Cat c = new Cat(); c.id = k; c.name = "Temporada " + k;
            for (int i = 0; i < a.length(); i++) {
                JSONObject e = a.optJSONObject(i); if (e == null) continue;
                Item it = new Item(); it.kind = "episode"; it.id = e.optString("id"); it.sid = s.sid;
                try { it.season = Integer.parseInt(k); } catch (Throwable ignored) { } it.ep = e.optInt("episode_num", i + 1);
                it.name = "T" + k + "·E" + e.optString("episode_num") + " — " + e.optString("title");
                String ext = e.optString("container_extension", "mp4"); if (ext.isEmpty()) ext = "mp4";
                it.url = b + "/series/" + u + "/" + p + "/" + it.id + "." + ext;
                JSONObject inf = e.optJSONObject("info"); it.logo = inf != null ? inf.optString("movie_image", s.logo) : s.logo; if (it.logo.isEmpty()) it.logo = s.logo;
                if (inf != null) { it.plot = inf.optString("plot"); it.rating = inf.optString("duration"); }
                it.group = s.name;
                c.items.add(it);
            }
            out.add(c);
        }
        return out;
    }

    /** O que está a dar agora e a seguir (Xtream get_short_epg). */
    String nowNext(Item ch) {
        try {
            if (server.isEmpty() || ch.id.isEmpty()) return "";
            JSONObject o = new JSONObject(http(api("get_short_epg", "&stream_id=" + enc(ch.id) + "&limit=2"), 6000));
            JSONArray a = o.optJSONArray("epg_listings"); if (a == null || a.length() == 0) return "";
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < Math.min(2, a.length()); i++) {
                JSONObject e = a.getJSONObject(i);
                String t = b64(e.optString("title")), st = e.optString("start");
                String hm = st.length() >= 16 ? st.substring(11, 16) : "";
                if (sb.length() > 0) sb.append("   ·   a seguir ");
                sb.append(hm).append(" ").append(t);
            }
            return sb.toString();
        } catch (Throwable e) { return ""; }
    }
    private static String b64(String s) { try { return new String(android.util.Base64.decode(s, android.util.Base64.DEFAULT), "UTF-8"); } catch (Throwable e) { return s; } }

    /* ------------------------------------------------------------ favoritos, vistos e posição dos filmes */
    LinkedHashSet<String> favs() {
        LinkedHashSet<String> s = new LinkedHashSet<>();
        try { JSONArray a = new JSONArray(sp.getString("favs", "[]")); for (int i = 0; i < a.length(); i++) s.add(a.getString(i)); } catch (Throwable ignored) { }
        return s;
    }
    boolean isFav(String url) { return favs().contains(url); }
    boolean toggleFav(Item it) {
        LinkedHashSet<String> s = favs(); boolean on;
        if (s.contains(it.url)) { s.remove(it.url); on = false; } else { s.add(it.url); on = true; }
        sp.edit().putString("favs", new JSONArray(s).toString()).apply();
        return on;
    }
    /** Favoritos (todos os tipos), pela ordem em que foram marcados. */
    List<Item> favItems() {
        LinkedHashSet<String> s = favs(); Map<String, Item> by = new HashMap<>();
        for (List<Item> l : all.values()) for (Item it : l) if (s.contains(it.url)) by.put(it.url, it);
        List<Item> out = new ArrayList<>(); for (String u : s) { Item it = by.get(u); if (it != null) out.add(it); }
        return out;
    }
    void pushRecent(Item it) {
        try {
            JSONArray a = new JSONArray(sp.getString("recents", "[]")), b = new JSONArray();
            b.put(it.json());
            for (int i = 0; i < a.length() && b.length() < 40; i++) { JSONObject o = a.optJSONObject(i); if (o != null && !it.url.equals(o.optString("url"))) b.put(o); }
            sp.edit().putString("recents", b.toString()).apply();
        } catch (Throwable ignored) { }
    }
    List<Item> recents() {
        List<Item> out = new ArrayList<>();
        try { JSONArray a = new JSONArray(sp.getString("recents", "[]")); for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o != null && o.optString("url").length() > 0) out.add(Item.from(o)); } } catch (Throwable ignored) { }
        return out;
    }
    void savePos(String url, long pos, long dur) {
        try {
            JSONObject o = new JSONObject(sp.getString("pos", "{}"));
            boolean done = dur > 0 && pos > Math.max(dur * 0.93, dur - 120000);
            if (done || pos < 30000) o.remove(url); else o.put(url, pos);
            sp.edit().putString("pos", o.toString()).apply();
            if (done) setWatched(url, true);
        } catch (Throwable ignored) { }
    }
    /* ------------------------------------------------------------ filmes e séries (v271) */
    /** Ficha de um filme (Xtream get_vod_info): sinopse, elenco, género, duração, trailer, imagem de fundo. */
    JSONObject vodInfo(Item m) {
        try {
            if (server.isEmpty() || m.id.isEmpty()) return new JSONObject();
            JSONObject o = new JSONObject(cached("x_vod_" + m.id, api("get_vod_info", "&vod_id=" + enc(m.id)), false));
            JSONObject i = o.optJSONObject("info");
            return i == null ? new JSONObject() : i;
        } catch (Throwable e) { return new JSONObject(); }
    }
    static String firstImg(JSONObject i, String... keys) {
        for (String k : keys) {
            Object v = i.opt(k);
            if (v instanceof JSONArray) { JSONArray a = (JSONArray) v; for (int j = 0; j < a.length(); j++) { String s = a.optString(j); if (s.startsWith("http")) return s; } }
            else if (v != null && String.valueOf(v).startsWith("http")) return String.valueOf(v);
        }
        return "";
    }
    static String trailerId(JSONObject i) {
        String t = i.optString("youtube_trailer", i.optString("trailer"));
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?:v=|youtu\\.be/|embed/)([\\w-]{11})").matcher(t);
        if (m.find()) return m.group(1);
        return t.matches("[\\w-]{11}") ? t : "";
    }

    Item findByUrl(String url) {
        for (List<Item> l : all.values()) for (Item it : l) if (it.url.equals(url)) return it;
        for (Item it : recents()) if (it.url.equals(url)) return it;
        return null;
    }
    Item seriesBySid(String sid) {
        List<Item> l = all.get("series"); if (l == null) return null;
        for (Item it : l) if (it.sid.equals(sid)) return it;
        return null;
    }

    /** Vistos até ao fim (filmes e episódios). */
    boolean watched(String url) { try { return new JSONObject(sp.getString("watched", "{}")).has(url); } catch (Throwable e) { return false; } }
    void setWatched(String url, boolean on) {
        try { JSONObject o = new JSONObject(sp.getString("watched", "{}")); if (on) o.put(url, System.currentTimeMillis()); else o.remove(url); sp.edit().putString("watched", o.toString()).apply(); } catch (Throwable ignored) { }
        if (on) { try { JSONObject o = new JSONObject(sp.getString("pos", "{}")); o.remove(url); sp.edit().putString("pos", o.toString()).apply(); } catch (Throwable ignored) { } }
    }
    /** Último episódio aberto de cada série. */
    void setLastEp(String sid, String url) { try { JSONObject o = new JSONObject(sp.getString("slast", "{}")); o.put(sid, url); sp.edit().putString("slast", o.toString()).apply(); } catch (Throwable ignored) { } }
    String lastEp(String sid) { try { return new JSONObject(sp.getString("slast", "{}")).optString(sid, ""); } catch (Throwable e) { return ""; } }

    /** Filmes a meio, do mais recente para o mais antigo. */
    List<Item> continueMovies() {
        List<Item> out = new ArrayList<>(); LinkedHashSet<String> seen = new LinkedHashSet<>();
        for (Item r : recents()) {
            if (!"movie".equals(r.kind) || pos(r.url) <= 0 || !seen.add(r.url)) continue;
            Item full = null; List<Item> l = all.get("movie"); if (l != null) for (Item x : l) if (x.url.equals(r.url)) { full = x; break; }
            out.add(full != null ? full : r);
        }
        return out;
    }
    /** Séries em curso (pela ordem em que foram vistas). */
    List<Item> continueSeries() {
        List<Item> out = new ArrayList<>(); LinkedHashSet<String> seen = new LinkedHashSet<>();
        for (Item r : recents()) {
            if (!"episode".equals(r.kind) || r.sid.isEmpty() || !seen.add(r.sid)) continue;
            Item s = seriesBySid(r.sid);
            if (s != null) out.add(s);
        }
        return out;
    }
    static final String[] SORT_L = {"Ordem do servidor", "A–Z", "Mais recentes", "Melhor avaliação", "Ano"};
    int sortMode(String kind) { return sp.getInt("sort_" + kind, 0); }
    void setSortMode(String kind, int m) { sp.edit().putInt("sort_" + kind, m).apply(); }
    static List<Item> sorted(List<Item> in, int mode) {
        if (mode <= 0) return in;
        List<Item> l = new ArrayList<>(in);
        java.util.Comparator<Item> c;
        if (mode == 1) c = (a, b) -> norm(a.name).compareTo(norm(b.name));
        else if (mode == 2) c = (a, b) -> Long.compare(b.added, a.added);
        else if (mode == 3) c = (a, b) -> Double.compare(num(b.rating), num(a.rating));
        else c = (a, b) -> b.year.compareTo(a.year);
        java.util.Collections.sort(l, c);
        return l;
    }
    private static double num(String s) { try { return Double.parseDouble(s); } catch (Throwable e) { return 0; } }

    /* ------------------------------------------------------------ legendas online (OpenSubtitles, a mesma conta da app antiga) */
    String osKey() { return sp.getString("osKey", ""); }
    boolean osAuto() { return sp.getBoolean("osAuto", false); }
    void saveOs(String key, String u, String p, boolean auto) { sp.edit().putString("osKey", key.trim()).putString("osUser", u.trim()).putString("osPass", p).putBoolean("osAuto", auto).apply(); osToken = ""; }
    String osUser() { return sp.getString("osUser", ""); }
    String osPass() { return sp.getString("osPass", ""); }
    private String osToken = "", osBase = "https://api.opensubtitles.com/api/v1";
    private String osCall(String path, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(osBase + path).openConnection();
        try {
            c.setConnectTimeout(10000); c.setReadTimeout(20000);
            c.setRequestProperty("Api-Key", osKey()); c.setRequestProperty("Accept", "application/json"); c.setRequestProperty("User-Agent", "CockpitTV v1.0");
            if (osToken.length() > 0 && body != null) c.setRequestProperty("Authorization", "Bearer " + osToken);
            if (body != null) { c.setRequestMethod("POST"); c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json"); c.getOutputStream().write(body.getBytes("UTF-8")); }
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String s = in == null ? "" : readAll(in);
            if (code >= 400) { String m = ""; try { JSONObject j = new JSONObject(s); m = j.optString("message", j.optString("error")); } catch (Throwable ignored) { } throw new Exception(m.isEmpty() ? "HTTP " + code : m); }
            return s;
        } finally { c.disconnect(); }
    }
    private static String readAll(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); byte[] b = new byte[16384]; int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n); in.close();
        return bo.toString("UTF-8");
    }
    /** Resultados em português: [{id, label}] (PT primeiro, depois os de confiança e os mais descarregados). */
    List<String[]> osSearch(String raw) throws Exception {
        if (osKey().isEmpty()) throw new Exception("falta a chave da API OpenSubtitles (Definições)");
        String t = java.text.Normalizer.normalize(raw == null ? "" : raw, java.text.Normalizer.Form.NFKD)
                .replaceAll("(?i)\\.(mkv|mp4|avi|mov|m4v|ts|m3u8)$", " ").replaceAll("\\[[^\\]]*\\]|\\([^)]*\\)|\\|[a-zA-Z]{2,3}\\|", " ").replaceAll("[._]+", " ");
        int s = 0, e = 0;
        java.util.regex.Matcher se = java.util.regex.Pattern.compile("(?i)\\bS(\\d{1,2})\\s?E(\\d{1,3})\\b").matcher(t);
        java.util.regex.Matcher se2 = java.util.regex.Pattern.compile("\\bT(\\d{1,2})·E(\\d{1,3})\\b").matcher(raw == null ? "" : raw);
        if (se.find()) { s = Integer.parseInt(se.group(1)); e = Integer.parseInt(se.group(2)); }
        else if (se2.find()) { s = Integer.parseInt(se2.group(1)); e = Integer.parseInt(se2.group(2)); }
        java.util.regex.Matcher ym = java.util.regex.Pattern.compile("\\b(19\\d\\d|20\\d\\d)\\b").matcher(t);
        String year = ym.find() ? ym.group(1) : "";
        t = t.replaceAll("(?i)\\bS\\d{1,2}\\s?E\\d{1,3}\\b", " ").replaceAll("\\bT\\d{1,2}·E\\d{1,3}\\b.*$", " ").replaceAll("\\b(19\\d\\d|20\\d\\d)\\b.*$", " ")
                .replaceAll("(?i)\\b(uhd|fhd|4k|hevc|h ?26[45]|x26[45]|hd|sd|1080p?|720p?|2160p?|bluray|brrip|webrip|web-?dl|hdrip|dvdrip|dublado|legendado|pt-?pt|pt-?br)\\b.*$", " ")
                .replaceAll("[^\\p{L}\\p{N}' ]+", " ").replaceAll("\\s+", " ").trim().toLowerCase();
        if (t.isEmpty()) throw new Exception("título vazio");
        java.util.TreeMap<String, String> p = new java.util.TreeMap<>();   /* a API exige os parâmetros por ordem alfabética */
        p.put("languages", "pt-br,pt-pt"); p.put("query", t);
        if (s > 0) { p.put("season_number", "" + s); p.put("episode_number", "" + e); p.put("type", "episode"); } else if (!year.isEmpty()) p.put("year", year);
        StringBuilder q = new StringBuilder(); for (Map.Entry<String, String> en : p.entrySet()) q.append(q.length() == 0 ? "?" : "&").append(en.getKey()).append("=").append(enc(en.getValue()).replace("+", "%20"));
        JSONArray d = new JSONObject(osCall("/subtitles" + q, null)).optJSONArray("data");
        List<Object[]> rows = new ArrayList<>();
        if (d != null) for (int i = 0; i < d.length(); i++) {
            JSONObject a = d.optJSONObject(i) == null ? null : d.optJSONObject(i).optJSONObject("attributes"); if (a == null) continue;
            JSONArray fs = a.optJSONArray("files"); if (fs == null || fs.length() == 0) continue;
            JSONObject f = fs.optJSONObject(0); String fid = f.optString("file_id"); if (fid.isEmpty()) continue;
            String lang = a.optString("language"); boolean pt = lang.toLowerCase().matches("pt-?pt");
            String rel = a.optString("release", f.optString("file_name"));
            String label = (pt ? "PT" : "BR") + " · " + (rel.length() > 60 ? rel.substring(0, 60) : rel) + "  ↓" + a.optInt("download_count") + (a.optBoolean("from_trusted") ? " ✓" : "");
            int score = (pt ? 1000000000 : 0) + (a.optBoolean("from_trusted") ? 100000000 : 0) - (a.optBoolean("hearing_impaired") ? 50000000 : 0) + Math.min(49999999, a.optInt("download_count"));
            rows.add(new Object[]{score, new String[]{fid, label}});
        }
        java.util.Collections.sort(rows, (x, y) -> Integer.compare((Integer) y[0], (Integer) x[0]));
        List<String[]> out = new ArrayList<>(); for (Object[] r : rows) { out.add((String[]) r[1]); if (out.size() >= 10) break; }
        return out;
    }
    /** Descarrega a legenda escolhida em SRT (texto). */
    String osDownload(String fileId) throws Exception {
        if (osToken.isEmpty() && osUser().length() > 0 && osPass().length() > 0) {
            try {
                JSONObject j = new JSONObject(osCall("/login", new JSONObject().put("username", osUser()).put("password", osPass()).toString()));
                osToken = j.optString("token");
                String bu = j.optString("base_url"); if (bu.length() > 0) osBase = "https://" + bu.replaceAll("^https?://", "").replaceAll("/.*$", "") + "/api/v1";
            } catch (Throwable ignored) { }
        }
        JSONObject j = new JSONObject(osCall("/download", new JSONObject().put("file_id", Long.parseLong(fileId)).put("sub_format", "srt").toString()));
        String link = j.optString("link"); if (link.isEmpty()) throw new Exception("sem ligação de download");
        HttpURLConnection c = (HttpURLConnection) new URL(link).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(20000); c.setInstanceFollowRedirects(true);
        byte[] b; try { InputStream in = c.getInputStream(); java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); byte[] buf = new byte[16384]; int n; while ((n = in.read(buf)) > 0) bo.write(buf, 0, n); in.close(); b = bo.toByteArray(); } finally { c.disconnect(); }
        String txt = new String(b, "UTF-8");
        if (txt.contains("\uFFFD")) txt = new String(b, "windows-1252");   /* legendas antigas em Latin-1 */
        return txt;
    }

    long pos(String url) { try { return new JSONObject(sp.getString("pos", "{}")).optLong(url, 0); } catch (Throwable e) { return 0; } }

    /** Pesquisa em todos os tipos já carregados (sem acentos, sem maiúsculas). */
    List<Item> search(String q) {
        String n = norm(q); List<Item> out = new ArrayList<>();
        if (n.length() < 2) return out;
        for (String k : new String[]{"live", "movie", "series"}) { List<Item> l = all.get(k); if (l == null) continue; for (Item it : l) { if (norm(it.name).contains(n)) { out.add(it); if (out.size() >= 300) return out; } } }
        return out;
    }
    static String norm(String s) { return java.text.Normalizer.normalize(s == null ? "" : s, java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase(); }
}
