package pt.rui.cockpittv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.text.InputType;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

/** v479: «Programas e gravações» — procura programas futuros no guia e agenda a gravação do canal à hora do programa. */
final class GuideRecUi {
    private static final int BG = 0xFF111A24, TXT = 0xFFEAF2FA, DIM = 0xFF9FB2C4;
    private static final Handler UI = new Handler(Looper.getMainLooper());
    private static final SimpleDateFormat DAY = new SimpleDateFormat("EEE d MMM HH:mm", new Locale("pt", "PT")), HM = new SimpleDateFormat("HH:mm", Locale.US);
    private static int seq = 0;

    private static final class Row { NativeData.Item ch; NativeData.Prog p; }
    private static int dp(Activity a, int v) { return Math.round(v * a.getResources().getDisplayMetrics().density); }
    private static TextView tv(Activity a, String t, int sp, int color) { TextView x = new TextView(a); x.setText(t); x.setTextColor(color); x.setTextSize(sp); return x; }
    private static Button b(Activity a, String t, View.OnClickListener l) { Button x = new Button(a); x.setText(t); x.setAllCaps(false); x.setOnClickListener(l); return x; }
    private static String fmt(long ms) { return DAY.format(ms); }

    static void programs(final Activity act, final NativeData data, final NativeData.Item focus, final List<NativeData.Item> category, String q0) {
        final List<NativeData.Item> cat = new ArrayList<>();
        for (NativeData.Item it : category) { if ("live".equals(it.kind) && !it.id.isEmpty()) cat.add(it); if (cat.size() >= 150) break; }
        final LinearLayout root = new LinearLayout(act); root.setOrientation(LinearLayout.VERTICAL); root.setBackgroundColor(BG); root.setPadding(dp(act, 16), dp(act, 12), dp(act, 16), dp(act, 8));
        root.addView(tv(act, "Programas futuros e gravações", 20, TXT));
        final EditText et = new EditText(act); et.setHint("Programa (ex.: Telejornal, Benfica) — vazio mostra tudo"); et.setSingleLine(true); et.setInputType(InputType.TYPE_CLASS_TEXT); et.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        et.setTextColor(TXT); et.setHintTextColor(DIM); et.setText(q0 == null ? "" : q0.trim()); root.addView(et);
        final int[] scope = {focus != null ? 0 : 1};
        LinearLayout row = new LinearLayout(act); row.setOrientation(LinearLayout.HORIZONTAL);
        final Button scopeBtn = b(act, "", null), go = b(act, "Procurar", null), recs = b(act, "", null);
        row.addView(scopeBtn); row.addView(go); row.addView(recs); root.addView(row);
        final Button man = b(act, "➕ Gravação manual", v -> manual(act, focus, cat, () -> { }));
        root.addView(man);
        final TextView st = tv(act, "Escolhe o canal ou a categoria e carrega em Procurar.", 14, DIM); root.addView(st);
        final ListView lv = new ListView(act); root.addView(lv, new LinearLayout.LayoutParams(-1, dp(act, 330)));
        final List<Row> rows = new ArrayList<>(); final List<String> labels = new ArrayList<>();
        final ArrayAdapter<String> ad = new ArrayAdapter<String>(act, android.R.layout.simple_list_item_1, labels) {
            @Override public View getView(int pos, View cv, android.view.ViewGroup par) { TextView t = (TextView) super.getView(pos, cv, par); t.setTextColor(TXT); t.setTextSize(15); t.setPadding(dp(act, 8), dp(act, 10), dp(act, 8), dp(act, 10)); return t; }
        };
        lv.setAdapter(ad);
        final AlertDialog dlg = new AlertDialog.Builder(act).setView(root).setNegativeButton("Fechar", null).create();
        final Runnable paintScope = () -> scopeBtn.setText(scope[0] == 0 ? "Canal: " + (focus == null ? "—" : focus.name) : "Categoria (" + cat.size() + " canais)");
        final Runnable paintRecs = () -> { int n = 0; for (Recorder.Rec r : Recorder.list(act)) if ("sched".equals(r.st) || "rec".equals(r.st)) n++; recs.setText("⏺ Gravações (" + n + ")"); };
        paintScope.run(); paintRecs.run();
        scopeBtn.setOnClickListener(v -> { if (focus == null) { scope[0] = 1; } else scope[0] = 1 - scope[0]; paintScope.run(); });
        recs.setOnClickListener(v -> { recordings(act, paintRecs); });
        final Runnable[] repaint = new Runnable[1];
        repaint[0] = () -> { labels.clear(); for (Row r : rows) labels.add((Recorder.has(act, r.ch.url, r.p.start) ? "⏺ " : "") + fmt(r.p.start) + "–" + HM.format(r.p.end) + "  ·  " + r.ch.name + "  ·  " + r.p.title); ad.notifyDataSetChanged(); };
        lv.setOnItemClickListener((p, v, pos, id) -> {
            if (pos < 0 || pos >= rows.size()) return;
            final Row r = rows.get(pos);
            if (Recorder.has(act, r.ch.url, r.p.start)) {
                new AlertDialog.Builder(act).setTitle(r.p.title).setMessage(r.ch.name + "\n" + fmt(r.p.start) + "–" + HM.format(r.p.end) + "\n\nJá está marcado para gravar.")
                        .setPositiveButton("Cancelar gravação", (d, w) -> { Recorder.remove(act, Recorder.idOf(r.ch.url, r.p.start), false); repaint[0].run(); paintRecs.run(); })
                        .setNegativeButton("Fechar", null).show();
                return;
            }
            String extra = r.p.desc.isEmpty() ? "" : "\n\n" + (r.p.desc.length() > 240 ? r.p.desc.substring(0, 240) + "…" : r.p.desc);
            /* início e fim da gravação à escolha: minutos antes do início e depois do fim do programa */
            final LinearLayout box = new LinearLayout(act); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(act, 20), dp(act, 8), dp(act, 20), 0);
            TextView info = tv(act, r.p.title + "\n" + r.ch.name + "\n" + fmt(r.p.start) + "–" + HM.format(r.p.end) + extra, 15, 0xFF222222); box.addView(info);
            final EditText pre = new EditText(act), post = new EditText(act);
            for (EditText e : new EditText[]{pre, post}) { e.setInputType(InputType.TYPE_CLASS_NUMBER); e.setSingleLine(true); e.setMinEms(4); }
            pre.setText(String.valueOf(Recorder.preMin(act))); post.setText(String.valueOf(Recorder.postMin(act)));
            LinearLayout l1 = new LinearLayout(act); l1.setGravity(android.view.Gravity.CENTER_VERTICAL); l1.addView(tv(act, "Começar  ", 15, 0xFF222222)); l1.addView(pre); l1.addView(tv(act, "  min antes", 15, 0xFF222222)); box.addView(l1);
            LinearLayout l2 = new LinearLayout(act); l2.setGravity(android.view.Gravity.CENTER_VERTICAL); l2.addView(tv(act, "Acabar  ", 15, 0xFF222222)); l2.addView(post); l2.addView(tv(act, "  min depois", 15, 0xFF222222)); box.addView(l2);
            box.addView(tv(act, "Guarda no aparelho; a app não precisa de estar aberta. Usa 0 para gravar só o horário do guia.", 13, 0xFF666666));
            new AlertDialog.Builder(act).setTitle("Gravar este programa?").setView(box)
                    .setPositiveButton("Gravar", (d, w) -> {
                        int pm = 1, qm = 2;
                        try { pm = Math.max(0, Math.min(120, Integer.parseInt(pre.getText().toString().trim()))); } catch (Throwable ignored) { }
                        try { qm = Math.max(0, Math.min(360, Integer.parseInt(post.getText().toString().trim()))); } catch (Throwable ignored) { }
                        Recorder.setMargins(act, pm, qm);
                        Recorder.add(act, r.ch.name, r.ch.url, r.p.title, r.p.start, r.p.end, pm * 60_000L, qm * 60_000L); repaint[0].run(); paintRecs.run();
                        Toast.makeText(act, "Gravação marcada: " + r.p.title + " (" + pm + " min antes, " + qm + " min depois)", Toast.LENGTH_LONG).show();
                        if (!Recorder.canExact(act)) Toast.makeText(act, "O Android pode atrasar o início alguns minutos. Em Gravações podes permitir alarmes exatos.", Toast.LENGTH_LONG).show();
                    }).setNegativeButton("Cancelar", null).show();
        });
        final ExecutorService pool = Executors.newFixedThreadPool(6);
        final Runnable run = () -> {
            final int my = ++seq; final String q = NativeData.norm(et.getText().toString()).trim();
            final String[] words = q.isEmpty() ? new String[0] : q.split("\\s+");
            final List<NativeData.Item> chans = new ArrayList<>();
            if (scope[0] == 0 && focus != null) chans.add(focus); else chans.addAll(cat);
            rows.clear(); labels.clear(); ad.notifyDataSetChanged();
            if (chans.isEmpty()) { st.setText("Sem canais para procurar."); return; }
            st.setText("A ler o guia: 0 de " + chans.size() + " canais…");
            final AtomicInteger done = new AtomicInteger(0); final List<Row> found = new ArrayList<>();
            for (final NativeData.Item ch : chans) pool.execute(() -> {
                List<NativeData.Prog> ps = my == seq ? data.epgFull(ch) : new ArrayList<NativeData.Prog>();
                List<Row> mine = new ArrayList<>();
                for (NativeData.Prog p : ps) {
                    String t = NativeData.norm(p.title); boolean ok = true;
                    for (String w : words) if (!t.contains(w)) { ok = false; break; }
                    if (ok) { Row r = new Row(); r.ch = ch; r.p = p; mine.add(r); }
                }
                synchronized (found) { found.addAll(mine); }
                final int n = done.incrementAndGet();
                UI.post(() -> {
                    if (my != seq || !dlg.isShowing()) return;
                    if (n < chans.size()) { st.setText("A ler o guia: " + n + " de " + chans.size() + " canais…"); return; }
                    List<Row> all; synchronized (found) { all = new ArrayList<>(found); }
                    java.util.Collections.sort(all, (x, y) -> Long.compare(x.p.start, y.p.start));
                    rows.clear(); rows.addAll(all.size() > 400 ? all.subList(0, 400) : all); repaint[0].run();
                    st.setText(all.isEmpty() ? "Nenhum programa encontrado nos próximos dias." : all.size() + " programas — toca num para gravar.");
                });
            });
        };
        go.setOnClickListener(v -> run.run());
        et.setOnEditorActionListener((v, a, e) -> { run.run(); return true; });
        dlg.setOnDismissListener(d -> { seq++; pool.shutdownNow(); });
        dlg.show();
        if (dlg.getWindow() != null) dlg.getWindow().setLayout(Math.min(dp(act, 900), (int) (act.getResources().getDisplayMetrics().widthPixels * 0.94)), -2);
        if (focus != null && q0 != null && q0.trim().isEmpty()) run.run();   /* abre já com a programação do canal escolhido */
        else if (q0 != null && !q0.trim().isEmpty()) { scope[0] = 1; paintScope.run(); run.run(); }
    }

    static void recordings(final Activity act, final Runnable onChange) {
        Recorder.purge(act);
        final List<Recorder.Rec> l = Recorder.list(act);
        java.util.Collections.sort(l, (x, y) -> Long.compare(y.start, x.start));
        if (l.isEmpty()) {
            AlertDialog.Builder b = new AlertDialog.Builder(act).setTitle("Gravações").setMessage("Ainda não marcaste nenhuma gravação. Procura um programa e toca nele.\n\nOs vídeos ficam em: " + Recorder.where(act)).setPositiveButton("OK", null);
            if (!Recorder.canExact(act)) b.setNeutralButton("Alarmes exatos", (d, w) -> exactSettings(act));
            b.show(); return;
        }
        String[] items = new String[l.size()];
        for (int i = 0; i < l.size(); i++) {
            Recorder.Rec r = l.get(i); String s;
            switch (r.st) {
                case "rec": s = "● A gravar  " + (r.bytes / 1048576) + " MB"; break;
                case "done": s = "✔ Gravado  " + (r.bytes / 1048576) + " MB"; break;
                case "fail": s = "✖ Falhou: " + r.err; break;
                default: s = "⏰ Marcado";
            }
            items[i] = r.title + "\n" + r.ch + " · " + fmt(r.start) + "–" + HM.format(r.end) + "\n" + s;
        }
        AlertDialog.Builder b = new AlertDialog.Builder(act).setTitle("Gravações").setItems(items, (d, which) -> options(act, l.get(which), onChange)).setNegativeButton("Fechar", null);
        if (!Recorder.canExact(act)) b.setNeutralButton("Alarmes exatos", (d, w) -> exactSettings(act));
        b.show();
    }

    private static void exactSettings(Activity act) {
        try { act.startActivity(new Intent(android.provider.Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:" + act.getPackageName()))); }
        catch (Throwable e) { Toast.makeText(act, "Permite «Alarmes e lembretes» para esta app nas definições do Android.", Toast.LENGTH_LONG).show(); }
    }

    private static void options(final Activity act, final Recorder.Rec r, final Runnable onChange) {
        final List<String> o = new ArrayList<>(); final List<Runnable> a = new ArrayList<>();
        if ("done".equals(r.st) || ("rec".equals(r.st) && r.bytes > 2_000_000)) {
            o.add("Reproduzir"); a.add(() -> {
                try {
                    Uri u = r.file.startsWith("content:") ? Uri.parse(r.file) : androidx.core.content.FileProvider.getUriForFile(act, "pt.rui.cockpittv.files", new File(r.file));
                    act.startActivity(Intent.createChooser(new Intent(Intent.ACTION_VIEW).setDataAndType(u, "video/mp2t").addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION), "Reproduzir com…"));
                } catch (Throwable e) { Toast.makeText(act, "Não consegui abrir: " + e.getMessage(), Toast.LENGTH_LONG).show(); }
            });
        }
        if ("rec".equals(r.st)) { o.add("Parar a gravação (guarda o que já há)"); a.add(() -> Recorder.stop(r.id)); }
        if ("sched".equals(r.st)) { o.add("Cancelar gravação"); a.add(() -> { Recorder.remove(act, r.id, false); if (onChange != null) onChange.run(); }); }
        if ("done".equals(r.st) || "fail".equals(r.st)) { o.add("Apagar" + ("done".equals(r.st) ? " (e o ficheiro)" : "")); a.add(() -> { Recorder.remove(act, r.id, true); if (onChange != null) onChange.run(); }); }
        o.add("Fechar"); a.add(() -> { });
        new AlertDialog.Builder(act).setTitle(r.title).setItems(o.toArray(new String[0]), (d, w) -> a.get(w).run()).show();
    }

    /** Gravação fora do guia: canal, título e hora de início e de fim à escolha (sem margens extra). */
    static void manual(final Activity act, final NativeData.Item focus, final List<NativeData.Item> cat, final Runnable onDone) {
        final List<NativeData.Item> chans = new ArrayList<>();
        if (focus != null && "live".equals(focus.kind) && !focus.url.isEmpty()) chans.add(focus);
        for (NativeData.Item it : cat) if ("live".equals(it.kind) && !it.url.isEmpty() && !chans.contains(it)) chans.add(it);
        if (chans.isEmpty()) { Toast.makeText(act, "Abre uma categoria de canais no Guia primeiro.", Toast.LENGTH_LONG).show(); return; }
        final LinearLayout box = new LinearLayout(act); box.setOrientation(LinearLayout.VERTICAL); box.setPadding(dp(act, 20), dp(act, 8), dp(act, 20), 0);
        final android.widget.Spinner sp = new android.widget.Spinner(act);
        List<String> names = new ArrayList<>(); for (NativeData.Item it : chans) names.add(it.name);
        sp.setAdapter(new ArrayAdapter<>(act, android.R.layout.simple_spinner_dropdown_item, names));
        box.addView(tv(act, "Canal", 13, 0xFF666666)); box.addView(sp);
        final EditText title = new EditText(act); title.setSingleLine(true); title.setHint("Título (opcional)"); box.addView(title);
        final java.util.Calendar[] t = {java.util.Calendar.getInstance(), java.util.Calendar.getInstance()};
        t[0].setTimeInMillis(System.currentTimeMillis() + 10 * 60_000L); t[0].set(java.util.Calendar.SECOND, 0); t[0].set(java.util.Calendar.MILLISECOND, 0);
        t[0].setTimeInMillis((t[0].getTimeInMillis() / 300_000L + 1) * 300_000L);   /* próximo múltiplo de 5 min */
        t[1].setTimeInMillis(t[0].getTimeInMillis() + 60 * 60_000L);
        final Button bs = b(act, "", null), be = b(act, "", null);
        final Runnable paint = () -> { bs.setText("Início: " + fmt(t[0].getTimeInMillis())); be.setText("Fim: " + fmt(t[1].getTimeInMillis())); };
        paint.run();
        final View.OnClickListener pick = v -> {
            final java.util.Calendar c = v == bs ? t[0] : t[1];
            new android.app.DatePickerDialog(act, (dp, y, m, d) -> new android.app.TimePickerDialog(act, (tp, h, mi) -> {
                c.set(y, m, d, h, mi, 0); c.set(java.util.Calendar.MILLISECOND, 0);
                if (c == t[0] && t[1].getTimeInMillis() <= c.getTimeInMillis()) t[1].setTimeInMillis(c.getTimeInMillis() + 60 * 60_000L);
                paint.run();
            }, c.get(java.util.Calendar.HOUR_OF_DAY), c.get(java.util.Calendar.MINUTE), true).show(), c.get(java.util.Calendar.YEAR), c.get(java.util.Calendar.MONTH), c.get(java.util.Calendar.DAY_OF_MONTH)).show();
        };
        bs.setOnClickListener(pick); be.setOnClickListener(pick); box.addView(bs); box.addView(be);
        box.addView(tv(act, "Grava exatamente entre estas horas, sem margens. Guarda no aparelho; a app não precisa de estar aberta.", 13, 0xFF666666));
        new AlertDialog.Builder(act).setTitle("Gravação manual").setView(box).setNegativeButton("Cancelar", null)
                .setPositiveButton("Gravar", (d, w) -> {
                    long st = t[0].getTimeInMillis(), en = t[1].getTimeInMillis();
                    if (en <= st || en <= System.currentTimeMillis()) { Toast.makeText(act, "O fim tem de ser depois do início e no futuro.", Toast.LENGTH_LONG).show(); return; }
                    NativeData.Item ch = chans.get(Math.max(0, sp.getSelectedItemPosition()));
                    String ti = title.getText().toString().trim(); if (ti.isEmpty()) ti = "Gravação " + HM.format(st);
                    Recorder.add(act, ch.name, ch.url, ti, st, en, 0, 0);
                    Toast.makeText(act, "Gravação marcada: " + ch.name + " " + fmt(st) + "–" + HM.format(en), Toast.LENGTH_LONG).show();
                    if (!Recorder.canExact(act)) Toast.makeText(act, "O Android pode atrasar o início alguns minutos. Em Gravações podes permitir alarmes exatos.", Toast.LENGTH_LONG).show();
                    if (onDone != null) onDone.run();
                }).show();
    }
}
