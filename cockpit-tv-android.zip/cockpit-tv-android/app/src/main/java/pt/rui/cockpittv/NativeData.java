package pt.rui.cockpittv;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/**
 * App nativa (v270): dados da lista IPTV sem a página web.
 * Lê a configuração que a app clássica guardou (servidor Xtream / M3U, favoritos, vistos), descarrega as listas
 * pela API Xtream (ou M3U), guarda-as em disco (abre instantaneamente da vez seguinte) e organiza por categorias.
 * Tudo corre fora da thread da interface.
 */
final class NativeData {
    static final class Item {
        String name = "", logo = "", group = "", url = "", kind = "live", id = "", sid = "", epgId = "", plot = "", rating = "", year = "";
        int num = 0;
        long added = 0;
        boolean logoDone = false;
        int season = 0, ep = 0;
        JSONObject json() {
            JSONObject o = new JSONObject();
            try { o.put("name", name); o.put("logo", logo); o.put("group", group); o.put("url", url); o.put("kind", kind); o.put("id", id); o.put("sid", sid); o.put("epgId", epgId); o.put("season", season); o.put("ep", ep); } catch (Throwable ignored) { }
            return o;
        }
        static Item from(JSONObject o) {
            Item it = new Item();
            it.name = o.optString("name"); it.logo = o.optString("logo"); it.group = o.optString("group"); it.url = o.optString("url");
            it.kind = o.optString("kind", "live"); it.id = o.optString("id"); it.sid = o.optString("sid"); it.epgId = o.optString("epgId");
            it.season = o.optInt("season"); it.ep = o.optInt("ep");
            if ("vod".equals(it.kind)) it.kind = "movie";
            return it;
        }
    }
    static final class Cat { String id = "", name = ""; final List<Item> items = new ArrayList<>();
        /* v510: categoria oculta nas Definições: não é carregada para a memória; fica só o nome e o total */
        boolean skipped = false; int total = 0;
        int size() { return skipped ? total : items.size(); } }

    private static final long TTL_DEF = 12L * 3600 * 1000;
    /** v312: intervalo de renovação das listas (definições): horas; 0 = só manual. */
    SharedPreferences sp() { return sp; }
    long ttl() { int h = sp.getInt("listTtlH", 12); return h <= 0 ? Long.MAX_VALUE / 4 : h * 3600L * 1000L; }
    long epgTtl() { return sp.getInt("epgTtlMin", 30) * 60L * 1000L; }
    private static final String UA = "Mozilla/5.0 (Linux; Android) CockpitTV";
    private final Context ctx;
    private final SharedPreferences sp;
    String server = "", user = "", pass = "", m3u = "";
    /** por tipo (live / movie / series): categorias por ordem, com os itens de cada uma */
    final Map<String, List<Cat>> cats = new java.util.concurrent.ConcurrentHashMap<>();
    final Map<String, List<Item>> all = new java.util.concurrent.ConcurrentHashMap<>();

    NativeData(Context c) {
        ctx = c.getApplicationContext();
        sp = ctx.getSharedPreferences("nativeapp", 0);
        loadCfg();
    }

    /* ------------------------------------------------------------ configuração */
    void loadCfg() {
        server = sp.getString("xs", ""); user = sp.getString("xu", ""); pass = sp.getString("xp", ""); m3u = sp.getString("m3u", "");
        /* primeira vez: vem da app clássica (a MainActivity copia o localStorage da página para «webexport») */
        if (server.isEmpty() && m3u.isEmpty()) importFromWeb();
    }
    boolean importFromWeb() {
        SharedPreferences w = ctx.getSharedPreferences("webexport", 0);
        return importJson(w.getString("cfg", ""), w.getString("favs", "[]"), w.getString("recents", "[]"));
    }
    /** Dados da app antiga (localStorage da página): servidor, conta OpenSubtitles, favoritos e vistos. */
    boolean importJson(String c, String favs, String recents) {
        try {
            if (c == null || c.length() < 3) return false;
            JSONObject o = new JSONObject(c);
            if (o.optString("xs").isEmpty() && o.optString("m3u").isEmpty()) return false;
            SharedPreferences.Editor e = sp.edit();
            e.putString("xs", o.optString("xs")).putString("xu", o.optString("xu")).putString("xp", o.optString("xp")).putString("m3u", o.optString("m3u")).putString("epg", o.optString("epg"));
            if (sp.getString("osKey", "").isEmpty()) e.putString("osKey", o.optString("osKey")).putString("osUser", o.optString("osUser")).putString("osPass", o.optString("osPass")).putBoolean("osAuto", o.optBoolean("osAuto"));
            if (!sp.contains("favs") && favs != null) e.putString("favs", favs);
            if (!sp.contains("recents") && recents != null) e.putString("recents", recents);
            e.apply();
            server = o.optString("xs"); user = o.optString("xu"); pass = o.optString("xp"); m3u = o.optString("m3u");
            return server.length() > 0 || m3u.length() > 0;
        } catch (Throwable e) { return false; }
    }
    void saveCfg(String xs, String xu, String xp, String m) {
        sp.edit().putString("xs", xs.trim()).putString("xu", xu.trim()).putString("xp", xp).putString("m3u", m.trim()).apply();
        server = xs.trim(); user = xu.trim(); pass = xp; m3u = m.trim();
        String pa = perfilAtual(); if (!pa.isEmpty()) gravarPerfil(pa);   /* v497: o perfil em uso fica com estes dados */
        clearCache();
    }

    /* ---- v497: perfis de IPTV (cada um com a sua lista, servidor ou M3U e EPG) ---- */
    JSONArray perfis() { try { return new JSONArray(sp.getString("perfis", "[]")); } catch (Throwable e) { return new JSONArray(); } }
    String perfilAtual() { return sp.getString("perfilAtual", ""); }
    List<String> perfilNomes() { List<String> l = new ArrayList<>(); JSONArray a = perfis(); for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o != null) l.add(o.optString("nome")); } return l; }
    private JSONObject perfilDoAtual(String nome) {
        JSONObject o = new JSONObject();
        try { o.put("nome", nome).put("xs", sp.getString("xs", "")).put("xu", sp.getString("xu", "")).put("xp", sp.getString("xp", "")).put("m3u", sp.getString("m3u", "")).put("epg", sp.getString("epg", "")); } catch (Throwable ignored) { }
        return o;
    }
    /** Cria ou atualiza o perfil com a configuração atual e passa a ser o perfil em uso. */
    void gravarPerfil(String nome) {
        JSONArray a = perfis(), n = new JSONArray(); boolean ok = false;
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i); if (o == null) continue;
            if (nome.equals(o.optString("nome"))) { o = perfilDoAtual(nome); ok = true; }
            n.put(o);
        }
        if (!ok) n.put(perfilDoAtual(nome));
        sp.edit().putString("perfis", n.toString()).putString("perfilAtual", nome).apply();
    }
    boolean usarPerfil(String nome) {
        JSONArray a = perfis();
        for (int i = 0; i < a.length(); i++) {
            JSONObject o = a.optJSONObject(i);
            if (o == null || !nome.equals(o.optString("nome"))) continue;
            sp.edit().putString("xs", o.optString("xs")).putString("xu", o.optString("xu")).putString("xp", o.optString("xp")).putString("m3u", o.optString("m3u")).putString("epg", o.optString("epg")).putString("perfilAtual", nome).apply();
            server = o.optString("xs"); user = o.optString("xu"); pass = o.optString("xp"); m3u = o.optString("m3u");
            clearCache();
            return true;
        }
        return false;
    }
    void apagarPerfil(String nome) {
        JSONArray a = perfis(), n = new JSONArray();
        for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o != null && !nome.equals(o.optString("nome"))) n.put(o); }
        SharedPreferences.Editor e = sp.edit().putString("perfis", n.toString());
        if (nome.equals(perfilAtual())) e.putString("perfilAtual", "");
        e.apply();
    }
    boolean configured() { return (server.length() > 0 && user.length() > 0) || m3u.length() > 0; }
    private String base() {
        String s = server.trim(); if (s.isEmpty()) return "";
        if (!s.startsWith("http")) s = "http://" + s;
        s = s.replaceAll("/(player_api|get)\\.php.*$", "");
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }
    /** v331: verifica se o servidor IPTV responde; devolve null se está bem, senão o motivo (em português). */
    static String checkServer(Context c) {
        try {
            NativeData d = new NativeData(c);
            if (d.server.isEmpty() || d.user.isEmpty()) return null;
            String s = http(d.base() + "/player_api.php?username=" + d.enc(d.user) + "&password=" + d.enc(d.pass), 10000);
            JSONObject o = new JSONObject(s); JSONObject ui = o.optJSONObject("user_info");
            if (ui == null) return "respondeu sem os dados da conta";
            String st = ui.optString("status", "");
            if (ui.optInt("auth", 0) != 1 && !"1".equals(ui.optString("auth"))) return "recusou a conta" + (st.isEmpty() ? "" : " (" + st + ")");
            if (st.toLowerCase().matches(".*(expired|disabled|banned).*")) return "a conta está " + st;
            return null;
        } catch (Exception e) {
            String m = String.valueOf(e.getMessage());
            if (m.startsWith("HTTP")) return "respondeu com erro (" + m + ")";
            if (e instanceof java.net.SocketTimeoutException) return "não respondeu em 10 s";
            if (e instanceof org.json.JSONException) return "respondeu com uma página de erro";
            return "não responde (" + e.getClass().getSimpleName() + ")";
        }
    }
    static String serverHost(Context c) { try { return new URL(new NativeData(c).base()).getHost(); } catch (Throwable e) { return "servidor IPTV"; } }
    private String enc(String s) { try { return URLEncoder.encode(s, "UTF-8"); } catch (Throwable e) { return s; } }
    private String api(String action, String extra) { return base() + "/player_api.php?username=" + enc(user) + "&password=" + enc(pass) + "&action=" + action + (extra == null ? "" : extra); }

    /* ------------------------------------------------------------ rede e cache em disco */
    private File cacheFile(String k) { File d = new File(ctx.getFilesDir(), "nlist"); d.mkdirs(); return new File(d, k.replaceAll("[^a-zA-Z0-9_]", "_") + ".json"); }
    void clearCache() { try { File d = new File(ctx.getFilesDir(), "nlist"); File[] fs = d.listFiles(); if (fs != null) for (File f : fs) f.delete(); } catch (Throwable ignored) { } cats.clear(); all.clear(); dropCaches(); }
    boolean cacheFresh(String kind) { File f = cacheFile("x_" + kind + "_streams"); return f.exists() && System.currentTimeMillis() - f.lastModified() < ttl(); }

    static String http(String u, int timeoutMs) throws Exception {
        HttpURLConnection c = null;
        try {
            String cur = u;
            for (int i = 0; i < 6; i++) {
                c = (HttpURLConnection) new URL(cur).openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(timeoutMs); c.setReadTimeout(timeoutMs * 3);
                c.setRequestProperty("User-Agent", UA);
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) { String loc = c.getHeaderField("Location"); c.disconnect(); if (loc == null) break; cur = new URL(new URL(cur), loc).toString(); continue; }
                if (code >= 400) throw new Exception(Tr.t("HTTP ") + code);
                InputStream in = c.getInputStream();
                BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"), 65536);
                StringBuilder sb = new StringBuilder(65536); char[] buf = new char[16384]; int n;
                while ((n = r.read(buf)) > 0) sb.append(buf, 0, n);
                r.close();
                return sb.toString();
            }
            throw new Exception(Tr.t("demasiados redirecionamentos"));
        } finally { if (c != null) try { c.disconnect(); } catch (Throwable ignored) { } }
    }
    private String cached(String key, String url, boolean force) throws Exception {
        File f = cacheFile(key);
        if (!force && f.exists() && System.currentTimeMillis() - f.lastModified() < ttl()) return readFile(f);
        try {
            String s = http(url, 15000);
            try (FileOutputStream o = new FileOutputStream(f)) { o.write(s.getBytes("UTF-8")); }
            return s;
        } catch (Exception e) {
            if (f.exists()) return readFile(f);   /* sem rede: usa a última lista guardada, mesmo antiga */
            throw e;
        }
    }
    private static String readFile(File f) throws Exception {
        try (FileInputStream in = new FileInputStream(f)) { byte[] b = new byte[(int) f.length()]; int o = 0, n; while (o < b.length && (n = in.read(b, o, b.length - o)) > 0) o += n; return new String(b, 0, o, "UTF-8"); }
    }

    /* ------------------------------------------------------------ carregar listas */
    /** kind: live | movie | series. Força a renovação com force=true. */
    /* v280: cada tipo tem o seu cadeado (carregar os 246 mil filmes já não bloqueia os canais) */
    private final Map<String, Object> locks = new java.util.concurrent.ConcurrentHashMap<>();
    private static final Object BIG_LOAD = new Object();
    /** v409: esvazia as caches que guardam listas antigas (pesquisa normalizada e ordenações), para libertar memória. */
    void dropCaches() { synchronized (SORT_CACHE) { SORT_CACHE.clear(); } normIdx.clear(); gnIdx.clear(); ctyIdx.clear(); genItemsCache.clear(); genKeysCache.clear(); }
    /** v475: ao recarregar uma lista, os índices da lista antiga são largados já (guardavam 250 mil filmes antigos vivos durante o carregamento: pico de memória a dobrar → OutOfMemoryError). */
    private void dropIdx(String kind) { normIdx.remove(kind); gnIdx.remove(kind); ctyIdx.remove(kind); try { for (String k : new ArrayList<>(genItemsCache.keySet())) if (k.startsWith(kind + "|")) genItemsCache.remove(k); } catch (Throwable ignored) { } }
    /** v475: textos repetidos (classificação, ano, país) partilham o mesmo objeto: poupa dezenas de MB nas listas grandes. */
    private final java.util.HashMap<String, String> POOL = new java.util.HashMap<>();
    private synchronized String pool(String v) { if (v == null || v.isEmpty()) return ""; String o = POOL.get(v); if (o != null) return o; if (POOL.size() < 30000) POOL.put(v, v); return v; }
    private Object lockOf(String k) { Object o = locks.get(k); if (o == null) { o = new Object(); Object p = ((java.util.concurrent.ConcurrentHashMap<String, Object>) locks).putIfAbsent(k, o); if (p != null) o = p; } return o; }
    /** v510: tipos com categorias que voltaram a ficar visíveis: têm de ser relidos do disco. */
    private final java.util.Set<String> stale = java.util.Collections.synchronizedSet(new java.util.HashSet<String>());
    /** v510: categorias a não carregar (ocultas nas Definições: grupo oculto ou país oculto). */
    private java.util.Set<String> hiddenNow(String kind) {
        java.util.Set<String> h = new java.util.HashSet<>(list(arr2("grpHide", kind)));
        return h;
    }
    private boolean skipCat(String kind, String name, java.util.Set<String> gh) { return gh.contains(name) || ctyHidden(ctyOfGroup(name)); }
    /** v510: depois de mostrar um grupo ou país, relê por trás os tipos onde estava por carregar. */
    private void checkUnhidden() {
        for (String k : new ArrayList<>(cats.keySet())) {
            List<Cat> l = cats.get(k); if (l == null) continue;
            java.util.Set<String> gh = hiddenNow(k); boolean need = false;
            for (Cat c : l) if (c.skipped && !skipCat(k, c.name, gh)) { need = true; break; }
            if (need && stale.add(k)) { final String kk = k; Thread t = new Thread(() -> { try { load(kk, false); } catch (Throwable ignored) { } }, "relê-" + k); t.setDaemon(true); t.start(); }
        }
    }
    void load(String kind, boolean force) throws Exception {
        if (!force && cats.containsKey(kind) && !stale.contains(kind)) return;
        boolean x = server.length() > 0 && user.length() > 0;
        /* v409: uma lista de cada vez (duas em paralelo somam o pico de memória e davam OutOfMemoryError);
           as caches que guardam listas antigas são esvaziadas, para a lista anterior poder ser libertada */
        try {
            synchronized (BIG_LOAD) {
                synchronized (lockOf(x ? kind : "m3u")) {
                    if (!force && cats.containsKey(kind) && !stale.contains(kind)) return;
                    if (cats.containsKey(kind)) dropIdx(kind);
                    stale.remove(kind); visCache.clear();
                    long t0 = System.currentTimeMillis();
                    if (x) loadXtream(kind, force);
                    else if (m3u.length() > 0) loadM3u(force);
                    else throw new Exception(Tr.t("Sem lista configurada. Abre as Definições."));
                    try { List<Cat> cl = cats.get(kind); int sk = 0, skI = 0; if (cl != null) for (Cat c : cl) if (c.skipped) { sk++; skI += c.total; }
                        dbg("lista " + kind + ": " + lastSrc + " em " + (System.currentTimeMillis() - t0) + " ms · " + (all.get(kind) == null ? 0 : all.get(kind).size()) + " itens carregados · " + sk + " categorias ocultas por carregar (" + skI + " itens)"); } catch (Throwable ignored) { }
                }
            }
        } catch (OutOfMemoryError oom) {
            dropCaches(); System.gc();
            throw new Exception(Tr.t("memória insuficiente ao carregar ") + kind + Tr.t(" (a app libertou o que pôde; tenta de novo)"));
        }
        dropCaches();
        /* v368 (fase 0): quanto ocupa cada lista na memória, para medir antes de otimizar */
        try { Runtime rt = Runtime.getRuntime(); long used = (rt.totalMemory() - rt.freeMemory()) / (1024 * 1024);
            List<Item> l = all.get(kind); dbg("memória depois de carregar " + kind + ": " + used + " MB (" + (l == null ? 0 : l.size()) + " itens)"); } catch (Throwable ignored) { }
    }
    /** v357: progresso visível nas Definições (lido pela UI). */
    static volatile long dlDone = 0, dlTotal = -1; static volatile String dlLabel = "";
    /** Ficheiro da lista no aparelho (descarrega para o disco às partes; sem rede usa o último guardado). */
    private File fetchFile(String key, String url, boolean force) throws Exception {
        File f = cacheFile(key);
        if (!force && f.exists() && f.length() > 0 && System.currentTimeMillis() - f.lastModified() < ttl()) return f;
        File tmp = new File(f.getPath() + ".part");
        HttpURLConnection c = null;
        try {
            String cur = url;
            for (int i = 0; i < 6; i++) {
                c = (HttpURLConnection) new URL(cur).openConnection();
                c.setInstanceFollowRedirects(false); c.setConnectTimeout(15000); c.setReadTimeout(45000);
                c.setRequestProperty("User-Agent", UA);
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) { String loc = c.getHeaderField("Location"); c.disconnect(); if (loc == null) break; cur = new URL(new URL(cur), loc).toString(); continue; }
                if (code >= 400) throw new Exception(Tr.t("HTTP ") + code);
                dlLabel = key; dlDone = 0; dlTotal = c.getContentLengthLong();
                try (InputStream in = c.getInputStream(); FileOutputStream o = new FileOutputStream(tmp)) { byte[] b = new byte[65536]; int n; while ((n = in.read(b)) > 0) { o.write(b, 0, n); dlDone += n; } }
                if (tmp.length() < 2) throw new Exception(Tr.t("lista vazia"));
                if (!tmp.renameTo(f)) { f.delete(); if (!tmp.renameTo(f)) throw new Exception(Tr.t("não consegui guardar a lista")); }
                return f;
            }
            throw new Exception(Tr.t("demasiados redirecionamentos"));
        } catch (Exception e) {
            tmp.delete();
            if (f.exists() && f.length() > 0) return f;   /* sem rede: a última lista guardada, mesmo antiga */
            throw e;
        } finally { if (c != null) try { c.disconnect(); } catch (Throwable ignored) { } }
    }
    private static String jstr(android.util.JsonReader r) throws java.io.IOException {
        android.util.JsonToken t = r.peek();
        if (t == android.util.JsonToken.NULL) { r.nextNull(); return ""; }
        if (t == android.util.JsonToken.STRING || t == android.util.JsonToken.NUMBER) return r.nextString();
        if (t == android.util.JsonToken.BOOLEAN) return String.valueOf(r.nextBoolean());
        r.skipValue(); return "";
    }
    private static final java.util.regex.Pattern YEAR = java.util.regex.Pattern.compile("\\b(19\\d\\d|20\\d\\d)\\b");
    /** Lê a lista em fluxo (sem a carregar inteira para a memória como texto): muito mais rápido e leve nas TVs. */
    private void loadXtream(String kind, boolean force) throws Exception {
        String ca = kind.equals("live") ? "get_live_categories" : kind.equals("movie") ? "get_vod_categories" : "get_series_categories";
        String st = kind.equals("live") ? "get_live_streams" : kind.equals("movie") ? "get_vod_streams" : "get_series";
        File fc = fetchFile("x_" + kind + "_cats", api(ca, null), force);
        File fs = fetchFile("x_" + kind + "_streams", api(st, null), force);
        /* v294: cópia compacta (binária) da lista já organizada: abre várias vezes mais depressa que ler o JSON outra vez */
        File fb = cacheFile("x_" + kind + "_bin");
        if (fb.exists() && fb.lastModified() >= fs.lastModified() && fb.lastModified() >= fc.lastModified()) {
            try { if (readBin(fb, kind)) return; } catch (Throwable e) { fb.delete(); }
        }
        LinkedHashMap<String, Cat> m = new LinkedHashMap<>();
        try (android.util.JsonReader r = new android.util.JsonReader(new InputStreamReader(new java.io.BufferedInputStream(new FileInputStream(fc), 65536), "UTF-8"))) {
            if (r.peek() == android.util.JsonToken.BEGIN_ARRAY) {
                r.beginArray();
                while (r.hasNext()) {
                    if (r.peek() != android.util.JsonToken.BEGIN_OBJECT) { r.skipValue(); continue; }
                    r.beginObject(); Cat c = new Cat();
                    while (r.hasNext()) { String n = r.nextName(); if ("category_id".equals(n)) c.id = jstr(r); else if ("category_name".equals(n)) c.name = jstr(r); else r.skipValue(); }
                    r.endObject(); m.put(c.id, c);
                }
                r.endArray();
            }
        }
        List<Item> list = new ArrayList<>(kind.equals("movie") ? 200000 : 40000);
        String b = base(), u = enc(user), p = enc(pass);
        String pre = kind.equals("live") ? b + "/live/" + u + "/" + p + "/" : b + "/movie/" + u + "/" + p + "/";
        try (android.util.JsonReader r = new android.util.JsonReader(new InputStreamReader(new java.io.BufferedInputStream(new FileInputStream(fs), 131072), "UTF-8"))) {
            if (r.peek() != android.util.JsonToken.BEGIN_ARRAY) throw new Exception(Tr.t("resposta inesperada do servidor (") + kind + ")");
            r.beginArray();
            while (r.hasNext()) {
                if (r.peek() != android.util.JsonToken.BEGIN_OBJECT) { r.skipValue(); continue; }
                r.beginObject();
                Item it = new Item(); it.kind = kind;
                String cid = "", ext = "", added = "", lm = "", rd = "", sid = "", sidS = "", icon = "", cover = "";
                while (r.hasNext()) {
                    String n = r.nextName();
                    switch (n) {
                        case "name": it.name = jstr(r).trim(); break;
                        case "category_id": cid = jstr(r); break;
                        case "stream_id": sidS = jstr(r); break;
                        case "series_id": sid = jstr(r); break;
                        case "stream_icon": icon = jstr(r); break;
                        case "cover": cover = jstr(r); break;
                        case "epg_channel_id": it.epgId = jstr(r); break;
                        case "num": try { it.num = Integer.parseInt(jstr(r)); } catch (Throwable e) { } break;
                        case "rating": it.rating = pool(jstr(r)); break;
                        case "year": it.year = pool(jstr(r)); break;
                        case "added": added = jstr(r); break;
                        case "last_modified": lm = jstr(r); break;
                        case "container_extension": ext = jstr(r); break;
                        case "plot": if (kind.equals("series")) it.plot = jstr(r); else r.skipValue(); break;
                        case "releaseDate": case "release_date": rd = jstr(r); break;
                        default: r.skipValue();
                    }
                }
                r.endObject();
                Cat c = m.get(cid); if (c == null) { c = new Cat(); c.id = cid; c.name = "Sem categoria"; m.put(cid, c); }
                it.group = c.name;
                if (kind.equals("live")) {
                    it.id = sidS; it.logo = icon; it.url = pre + it.id + ".m3u8";
                } else if (kind.equals("movie")) {
                    it.id = sidS; it.logo = icon;
                    try { it.added = Long.parseLong(added); } catch (Throwable ignored) { }
                    if (it.year.isEmpty()) { java.util.regex.Matcher ym = YEAR.matcher(it.name); if (ym.find()) it.year = ym.group(1); }
                    if (ext.isEmpty()) ext = "mp4";
                    it.url = pre + it.id + "." + ext;
                } else {
                    it.sid = sid; it.id = sid; it.logo = cover;
                    try { it.added = Long.parseLong(lm); } catch (Throwable ignored) { }
                    if (rd.length() >= 4) it.year = rd.substring(0, 4);
                    it.url = "series:" + sid;
                }
                c.items.add(it); list.add(it);
            }
            r.endArray();
        }
        List<Cat> out = new ArrayList<>();
        for (Cat c : m.values()) if (!c.items.isEmpty()) out.add(c);
        if (kind.equals("live")) betterLogos(list);
        try { writeBin(fb, out); } catch (Throwable e) { fb.delete(); }
        /* v510: as categorias ocultas nas Definições não ficam na memória */
        java.util.Set<String> gh = hiddenNow(kind); boolean any = false;
        for (Cat c : out) if (skipCat(kind, c.name, gh)) { c.total = c.items.size(); c.skipped = true; c.items.clear(); any = true; }
        if (any) { List<Item> vis = new ArrayList<>(); for (Cat c : out) vis.addAll(c.items); list = vis; }
        lastSrc = "lida do servidor (JSON)";
        cats.put(kind, out); all.put(kind, list);
    }
    private static final int BIN_VER = 2;   /* v510: cada categoria leva o tamanho em bytes, para saltar as ocultas sem as ler */
    private volatile String lastSrc = "";
    private static void ws(java.io.DataOutputStream o, String s) throws java.io.IOException {
        if (s == null || s.isEmpty()) { o.writeInt(0); return; }
        byte[] b = s.getBytes("UTF-8"); o.writeInt(b.length); o.write(b);
    }
    private static String rs(java.io.DataInputStream in, byte[][] buf) throws java.io.IOException {
        int n = in.readInt(); if (n <= 0) return "";
        if (buf[0].length < n) buf[0] = new byte[Math.max(n, buf[0].length * 2)];
        in.readFully(buf[0], 0, n);
        byte[] b = buf[0]; boolean ascii = true; for (int i = 0; i < n; i++) if (b[i] < 0) { ascii = false; break; }
        /* v510: texto só ASCII (endereços, ids): conversão direta, sem descodificador UTF-8 */
        if (ascii) { @SuppressWarnings("deprecation") String s = new String(b, 0, 0, n); return s; }
        return new String(b, 0, n, java.nio.charset.StandardCharsets.UTF_8);
    }
    private void writeBin(File f, List<Cat> out) throws Exception {
        File tmp = new File(f.getPath() + ".part");
        try (java.io.DataOutputStream o = new java.io.DataOutputStream(new java.io.BufferedOutputStream(new FileOutputStream(tmp), 262144))) {
            o.writeInt(BIN_VER); o.writeInt(out.size());
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(1 << 16);
            for (Cat c : out) {
                ws(o, c.id); ws(o, c.name); o.writeInt(c.items.size());
                bo.reset(); java.io.DataOutputStream d = new java.io.DataOutputStream(bo);
                for (Item it : c.items) {
                    ws(d, it.name); ws(d, it.logo); ws(d, it.id); ws(d, it.url); ws(d, it.epgId); ws(d, it.sid);
                    ws(d, it.rating); ws(d, it.year); ws(d, it.plot); d.writeInt(it.num); d.writeLong(it.added);
                }
                d.flush(); o.writeInt(bo.size()); bo.writeTo(o);
            }
        }
        if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f); }
    }
    private boolean readBin(File f, String kind) throws Exception {
        try (java.io.DataInputStream in = new java.io.DataInputStream(new java.io.BufferedInputStream(new FileInputStream(f), 262144))) {
            if (in.readInt() != BIN_VER) return false;
            int nc = in.readInt();
            byte[][] buf = {new byte[4096]};
            java.util.Set<String> gh = hiddenNow(kind);
            List<Cat> out = new ArrayList<>(nc);
            List<Item> list = new ArrayList<>(kind.equals("movie") ? 250000 : 50000);
            for (int i = 0; i < nc; i++) {
                Cat c = new Cat(); c.id = rs(in, buf); c.name = rs(in, buf);
                int n = in.readInt(), len = in.readInt();
                if (skipCat(kind, c.name, gh)) {   /* v510: oculta nas Definições: salta sem ler */
                    int left = len; while (left > 0) { int k = in.skipBytes(left); if (k <= 0) { in.readByte(); k = 1; } left -= k; }
                    c.skipped = true; c.total = n; out.add(c); continue;
                }
                for (int j = 0; j < n; j++) {
                    Item it = new Item(); it.kind = kind; it.group = c.name;
                    it.name = rs(in, buf); it.logo = rs(in, buf); it.id = rs(in, buf); it.url = rs(in, buf); it.epgId = rs(in, buf); it.sid = rs(in, buf);
                    if (it.sid.equals(it.id)) it.sid = it.id;
                    it.rating = pool(rs(in, buf)); it.year = pool(rs(in, buf)); it.plot = rs(in, buf); it.num = in.readInt(); it.added = in.readLong();
                    c.items.add(it); list.add(it);
                }
                out.add(c);
            }
            if (kind.equals("live")) betterLogos(list);
            lastSrc = "lida da cópia no aparelho";
            cats.put(kind, out); all.put(kind, list);
            return true;
        }
    }
    /** v516: pesquisa «tudo»: as categorias ocultas não estão na memória (v510), por isso lêem-se do disco só para a pesquisa
        (cada título é lido e largado; ficam só os que contêm o texto). cc/rp: filtros de país e resolução (podem ser null). */
    private static void skipStr(java.io.DataInputStream in) throws java.io.IOException { int n = in.readInt(); while (n > 0) { int k = in.skipBytes(n); if (k <= 0) { in.readByte(); k = 1; } n -= k; } }
    /** v518: lê do disco os itens das categorias ocultas cujo nome passa no filtro (para o género, que usa todas as categorias). */
    List<Item> readHiddenCats(String kind, java.util.regex.Pattern catP) {
        List<Item> out = new ArrayList<>();
        List<Cat> cl = cats.get(kind); if (cl == null) return out;
        java.util.Set<String> want = new java.util.HashSet<>();
        for (Cat c : cl) if (c.skipped && catP.matcher(fastNorm(c.name)).find()) want.add(c.name);
        if (want.isEmpty()) return out;
        File f = cacheFile("x_" + kind + "_bin"); if (!f.exists()) return out;
        try (java.io.DataInputStream in = new java.io.DataInputStream(new java.io.BufferedInputStream(new FileInputStream(f), 262144))) {
            if (in.readInt() != BIN_VER) return out;
            int nc = in.readInt(); byte[][] buf = {new byte[4096]};
            for (int i = 0; i < nc; i++) {
                rs(in, buf); String name = rs(in, buf); int cnt = in.readInt(), len = in.readInt();
                if (!want.contains(name)) { int left = len; while (left > 0) { int k = in.skipBytes(left); if (k <= 0) { in.readByte(); k = 1; } left -= k; } continue; }
                for (int j = 0; j < cnt; j++) {
                    Item it = new Item(); it.kind = kind; it.group = name;
                    it.name = rs(in, buf); it.logo = rs(in, buf); it.id = rs(in, buf); it.url = rs(in, buf); it.epgId = rs(in, buf); it.sid = rs(in, buf);
                    it.rating = pool(rs(in, buf)); it.year = pool(rs(in, buf)); it.plot = rs(in, buf); it.num = in.readInt(); it.added = in.readLong();
                    out.add(it);
                }
            }
        } catch (Throwable e) { dbg("género: leitura das ocultas (" + kind + "): " + e); }
        return out;
    }
    /** País de um item (mesma regra do índice: prefixo do nome, «PT» no nome, depois a categoria). */
    static String ctyOfItem(Item it) {
        String x = maybePfx(it.name) || hasPortug(it.name) ? ctyOfGroup(it.name) : "";
        if (x.isEmpty() && ptTag(it.name)) x = "PT";
        if (x.isEmpty()) { x = ctyOfGroup(it.group); if (x.isEmpty() && ptTag(it.group)) x = "PT"; }
        return x;
    }
    List<Item> searchHidden(String kind, String n, int cap, String cc, java.util.regex.Pattern rp) {
        List<Item> out = new ArrayList<>();
        List<Cat> cl = cats.get(kind); if (cl == null || (n.length() < 2 && (cc == null || cc.isEmpty()) && rp == null)) return out;
        boolean any = false; for (Cat c : cl) if (c.skipped) { any = true; break; }
        if (!any) return out;
        File f = cacheFile("x_" + kind + "_bin"); if (!f.exists()) return out;
        long t0 = System.currentTimeMillis();
        try (java.io.DataInputStream in = new java.io.DataInputStream(new java.io.BufferedInputStream(new FileInputStream(f), 262144))) {
            if (in.readInt() != BIN_VER) return out;
            int nc = in.readInt(); byte[][] buf = {new byte[4096]};
            java.util.Set<String> skipped = new java.util.HashSet<>(); for (Cat c : cl) if (c.skipped) skipped.add(c.name);
            for (int i = 0; i < nc && out.size() < cap; i++) {
                String id = rs(in, buf), name = rs(in, buf); int cnt = in.readInt(), len = in.readInt();
                if (!skipped.contains(name)) { int left = len; while (left > 0) { int k = in.skipBytes(left); if (k <= 0) { in.readByte(); k = 1; } left -= k; } continue; }
                String gc = cc == null || cc.isEmpty() ? "" : ctyOfGroup(name);
                for (int j = 0; j < cnt; j++) {
                    String nm = rs(in, buf);
                    if (out.size() >= cap || !fastNorm(nm).contains(n) || (rp != null && !rp.matcher(nm).find())) { for (int s = 0; s < 8; s++) skipStr(in); in.readInt(); in.readLong(); continue; }
                    Item it = new Item(); it.kind = kind; it.group = name; it.name = nm;
                    it.logo = rs(in, buf); it.id = rs(in, buf); it.url = rs(in, buf); it.epgId = rs(in, buf); it.sid = rs(in, buf);
                    it.rating = rs(in, buf); it.year = rs(in, buf); it.plot = rs(in, buf); it.num = in.readInt(); it.added = in.readLong();
                    if (cc != null && !cc.isEmpty()) { String c = maybePfx(nm) || hasPortug(nm) ? ctyOfGroup(nm) : ""; if (c.isEmpty() && ptTag(nm)) c = "PT"; if (c.isEmpty()) c = gc.isEmpty() && ptTag(name) ? "PT" : gc; if (!cc.equals(c)) continue; }
                    out.add(it);
                }
            }
        } catch (Throwable e) { dbg("pesquisa nas ocultas (" + kind + "): " + e); }
        dbg("pesquisa nas categorias ocultas de " + kind + ": " + out.size() + " em " + (System.currentTimeMillis() - t0) + " ms");
        return out;
    }
    private void loadM3u(boolean force) throws Exception {
        String s = cached("m3u", m3u, force);
        LinkedHashMap<String, Map<String, Cat>> byKind = new LinkedHashMap<>();
        Map<String, List<Item>> lists = new HashMap<>();
        for (String k : new String[]{"live", "movie", "series"}) { byKind.put(k, new LinkedHashMap<>()); lists.put(k, new ArrayList<>()); }
        Item pend = null;
        for (String line : s.split("\n")) {
            line = line.trim();
            if (line.startsWith("#EXTINF")) {
                pend = new Item();
                pend.logo = attr(line, "tvg-logo"); pend.group = attr(line, "group-title"); pend.epgId = attr(line, "tvg-id");
                int k = line.lastIndexOf(','); pend.name = k >= 0 ? line.substring(k + 1).trim() : "";
            } else if (pend != null && line.length() > 0 && !line.startsWith("#")) {
                pend.url = line; String l = line.toLowerCase();
                pend.kind = l.contains("/movie/") ? "movie" : l.contains("/series/") ? "series" : "live";
                if (pend.kind.equals("series")) pend.kind = "movie";   /* M3U: episódios soltos tratados como filmes */
                if (pend.group.isEmpty()) pend.group = "Sem categoria";
                Map<String, Cat> mc = byKind.get(pend.kind);
                Cat c = mc.get(pend.group); if (c == null) { c = new Cat(); c.id = pend.group; c.name = pend.group; mc.put(pend.group, c); }
                c.items.add(pend); lists.get(pend.kind).add(pend);
                pend = null;
            }
        }
        betterLogos(lists.get("live"));
        for (String k : byKind.keySet()) { cats.put(k, new ArrayList<>(byKind.get(k).values())); all.put(k, lists.get(k)); }
    }
    private static String attr(String line, String a) {
        int i = line.indexOf(a + "=\""); if (i < 0) return "";
        int s0 = i + a.length() + 2, e = line.indexOf('"', s0); return e > s0 ? line.substring(s0, e) : "";
    }

    /** Temporadas e episódios de uma série (Xtream get_series_info). */
    final Map<String, JSONObject> seriesMeta = new HashMap<>();
    List<Cat> seriesInfo(Item s, boolean force) throws Exception {
        JSONObject o = new JSONObject(cached("x_series_" + s.sid, api("get_series_info", "&series_id=" + enc(s.sid)), force));
        JSONObject inf0 = o.optJSONObject("info"); if (inf0 != null) seriesMeta.put(s.sid, inf0);
        JSONObject eps = o.optJSONObject("episodes");
        List<Cat> out = new ArrayList<>();
        if (eps == null) return out;
        List<String> keys = new ArrayList<>(); java.util.Iterator<String> itk = eps.keys(); while (itk.hasNext()) keys.add(itk.next());
        java.util.Collections.sort(keys, (a, b) -> { try { return Integer.parseInt(a) - Integer.parseInt(b); } catch (Throwable e) { return a.compareTo(b); } });
        String b = base(), u = enc(user), p = enc(pass);
        for (String k : keys) {
            JSONArray a = eps.optJSONArray(k); if (a == null) continue;
            Cat c = new Cat(); c.id = k; c.name = "Temporada " + k;
            for (int i = 0; i < a.length(); i++) {
                JSONObject e = a.optJSONObject(i); if (e == null) continue;
                Item it = new Item(); it.kind = "episode"; it.id = e.optString("id"); it.sid = s.sid;
                try { it.season = Integer.parseInt(k); } catch (Throwable ignored) { } it.ep = e.optInt("episode_num", i + 1);
                it.name = "T" + k + "·E" + e.optString("episode_num") + " — " + e.optString("title");
                String ext = e.optString("container_extension", "mp4"); if (ext.isEmpty()) ext = "mp4";
                it.url = b + "/series/" + u + "/" + p + "/" + it.id + "." + ext;
                JSONObject inf = e.optJSONObject("info"); it.logo = inf != null ? inf.optString("movie_image", s.logo) : s.logo; if (it.logo.isEmpty()) it.logo = s.logo;
                if (inf != null) { it.plot = text(inf, "plot", "description", "overview"); it.rating = inf.optString("duration"); }
                it.group = s.name;
                c.items.add(it);
            }
            out.add(c);
        }
        return out;
    }

    /** v479: um programa do guia (início e fim em milissegundos). */
    static final class Prog { String title = "", desc = ""; long start, end; }
    private final Map<String, Object[]> epgFullCache = new java.util.concurrent.ConcurrentHashMap<>();
    /** v479: toda a programação futura de um canal (Xtream get_simple_data_table); guardada 30 min em memória. */
    List<Prog> epgFull(Item ch) {
        List<Prog> out = new ArrayList<>();
        try {
            if (server.isEmpty() || ch.id.isEmpty()) return out;
            Object[] c = epgFullCache.get(ch.id);
            if (c != null && System.currentTimeMillis() - (Long) c[0] < 30 * 60 * 1000) return (List<Prog>) c[1];
            JSONObject o = new JSONObject(http(api("get_simple_data_table", "&stream_id=" + enc(ch.id)), 12000));
            JSONArray a = o.optJSONArray("epg_listings"); long now = System.currentTimeMillis();
            if (a != null) for (int i = 0; i < a.length(); i++) {
                JSONObject e = a.getJSONObject(i);
                long st = e.optLong("start_timestamp") * 1000L, en = e.optLong("stop_timestamp") * 1000L;
                if (st <= 0 || en <= now) continue;
                Prog p = new Prog(); p.title = b64(e.optString("title")).trim(); p.desc = b64(e.optString("description")).trim(); p.start = st; p.end = en;
                if (!p.title.isEmpty()) out.add(p);
            }
            java.util.Collections.sort(out, (x, y) -> Long.compare(x.start, y.start));
            epgFullCache.put(ch.id, new Object[]{System.currentTimeMillis(), out});
        } catch (Throwable e) { dbg("guia completo: " + ch.name + ": " + e); }
        return out;
    }

    /** O que está a dar agora e a seguir (Xtream get_short_epg). */
    String nowNext(Item ch) {
        try {
            if (server.isEmpty() || ch.id.isEmpty()) return "";
            JSONObject o = new JSONObject(http(api("get_short_epg", "&stream_id=" + enc(ch.id) + "&limit=2"), 6000));
            JSONArray a = o.optJSONArray("epg_listings"); if (a == null || a.length() == 0) return "";
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < Math.min(2, a.length()); i++) {
                JSONObject e = a.getJSONObject(i);
                String t = b64(e.optString("title")), st = e.optString("start");
                String hm = st.length() >= 16 ? st.substring(11, 16) : "";
                if (sb.length() > 0) sb.append("   ·   a seguir ");
                sb.append(hm).append(" ").append(t);
            }
            return sb.toString();
        } catch (Throwable e) { return ""; }
    }
    private static String b64(String s) { try { return new String(android.util.Base64.decode(s, android.util.Base64.DEFAULT), "UTF-8"); } catch (Throwable e) { return s; } }

    /* ------------------------------------------------------------ favoritos, vistos e posição dos filmes */
    /* v287: leituras guardadas em memória enquanto o valor não muda (eram refeitas para cada cartão da grelha) */
    private final Map<String, Object[]> joCache = new java.util.concurrent.ConcurrentHashMap<>();
    private JSONObject jo(String key) {
        String raw = sp.getString(key, "{}");
        Object[] c = joCache.get(key);
        if (c != null && c[0] == raw) return (JSONObject) c[1];
        JSONObject o; try { o = new JSONObject(raw); } catch (Throwable e) { o = new JSONObject(); }
        joCache.put(key, new Object[]{raw, o});
        return o;
    }
    private volatile Object[] favCache = null;
    /* ------------------------------------------------------------ perfis de quem vê (tab Cinema): lista, vistos, progresso e «continuar a ver» de cada um */
    /** Perfil atual ("" = o principal, que usa as chaves de sempre). */
    String viewer() { return sp.getString("viewer", ""); }
    String uk(String k) { String v = viewer(); return v.isEmpty() ? k : k + "@" + v; }
    JSONArray viewers() { try { return new JSONArray(sp.getString("viewers", "[]")); } catch (Throwable e) { return new JSONArray(); } }
    boolean kidsNow() { String v = viewer(); if (v.isEmpty()) return false; JSONArray a = viewers(); for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o != null && v.equals(o.optString("n"))) return o.optBoolean("k"); } return false; }
    void setViewer(String v) { sp.edit().putString("viewer", v == null ? "" : v).apply(); favCache = null; }
    void addViewer(String n, boolean kids) {
        JSONArray a = viewers();
        try { for (int i = 0; i < a.length(); i++) if (n.equals(a.getJSONObject(i).optString("n"))) return; a.put(new JSONObject().put("n", n).put("k", kids)); } catch (Throwable ignored) { }
        sp.edit().putString("viewers", a.toString()).apply();
    }
    void delViewer(String n) {
        JSONArray a = viewers(), b = new JSONArray();
        for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o != null && !n.equals(o.optString("n"))) b.put(o); }
        SharedPreferences.Editor e = sp.edit().putString("viewers", b.toString());
        for (String k : new String[]{"favs", "recents", "pos", "durs", "watched", "slast"}) e.remove(k + "@" + n);
        if (n.equals(viewer())) e.putString("viewer", "");
        e.apply(); favCache = null;
    }
    void removeRecent(String url, String sid) {
        try {
            JSONArray a = new JSONArray(sp.getString(uk("recents"), "[]")), b = new JSONArray();
            for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o == null || url.equals(o.optString("url")) || (sid != null && !sid.isEmpty() && sid.equals(o.optString("sid")))) continue; b.put(o); }
            sp.edit().putString(uk("recents"), b.toString()).apply();
        } catch (Throwable ignored) { }
    }
    LinkedHashSet<String> favs() {
        String raw = sp.getString(uk("favs"), "[]");
        Object[] c = favCache;
        if (c != null && c[0] == raw) return new LinkedHashSet<>((LinkedHashSet<String>) c[1]);
        LinkedHashSet<String> s0 = new LinkedHashSet<>();
        try { JSONArray a = new JSONArray(raw); for (int i = 0; i < a.length(); i++) s0.add(a.getString(i)); } catch (Throwable ignored) { }
        favCache = new Object[]{raw, s0};
        return new LinkedHashSet<>(s0);
    }
    LinkedHashSet<String> favsOld() {
        LinkedHashSet<String> s = new LinkedHashSet<>();
        try { JSONArray a = new JSONArray(sp.getString(uk("favs"), "[]")); for (int i = 0; i < a.length(); i++) s.add(a.getString(i)); } catch (Throwable ignored) { }
        return s;
    }
    boolean isFav(String url) { favs(); Object[] c = favCache; return c != null && ((LinkedHashSet<String>) c[1]).contains(url); }
    boolean toggleFav(Item it) {
        LinkedHashSet<String> s = favs(); boolean on;
        if (s.contains(it.url)) { s.remove(it.url); on = false; } else { s.add(it.url); on = true; }
        sp.edit().putString(uk("favs"), new JSONArray(s).toString()).apply();
        return on;
    }
    /** Favoritos (todos os tipos), pela ordem em que foram marcados. */
    List<Item> favItems() {
        LinkedHashSet<String> s = favs(); Map<String, Item> by = new HashMap<>();
        for (List<Item> l : all.values()) for (Item it : l) if (s.contains(it.url)) by.put(it.url, it);
        List<Item> out = new ArrayList<>(); for (String u : s) { Item it = by.get(u); if (it != null) out.add(it); }
        return out;
    }
    void pushRecent(Item it) {
        try {
            JSONArray a = new JSONArray(sp.getString(uk("recents"), "[]")), b = new JSONArray();
            b.put(it.json());
            for (int i = 0; i < a.length() && b.length() < 40; i++) { JSONObject o = a.optJSONObject(i); if (o != null && !it.url.equals(o.optString("url"))) b.put(o); }
            sp.edit().putString(uk("recents"), b.toString()).apply();
        } catch (Throwable ignored) { }
    }
    List<Item> recents() {
        List<Item> out = new ArrayList<>();
        try { JSONArray a = new JSONArray(sp.getString(uk("recents"), "[]")); for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o != null && o.optString("url").length() > 0) out.add(Item.from(o)); } } catch (Throwable ignored) { }
        return out;
    }
    void savePos(String url, long pos, long dur) {
        try {
            JSONObject o = new JSONObject(sp.getString(uk("pos"), "{}"));
            boolean done = dur > 0 && pos > Math.max(dur * 0.93, dur - 120000);
            if (done || pos < 30000) o.remove(url); else o.put(url, pos);
            sp.edit().putString(uk("pos"), o.toString()).apply();
            /* v420: duração guardada à parte, para a barra de progresso dos cartões (estilo Moderno) */
            if (dur > 0 && !done) { JSONObject d = new JSONObject(sp.getString(uk("durs"), "{}")); d.put(url, dur); sp.edit().putString(uk("durs"), d.toString()).apply(); }
            if (done) setWatched(url, true);
        } catch (Throwable ignored) { }
    }
    /* ------------------------------------------------------------ filmes e séries (v271) */
    /** Ficha de um filme (Xtream get_vod_info): sinopse, elenco, género, duração, trailer, imagem de fundo. */
    /** Estilo «Estreias»: todos os títulos visíveis do tipo, sem repetidos, dos adicionados mais recentemente para os mais antigos. */
    synchronized List<Item> recentVod(String kind, int max) {
        List<Item> out = new ArrayList<>(); java.util.Set<String> seen = new java.util.HashSet<>();
        try { for (Cat c : visCats(kind, false)) for (Item it : c.items) if (seen.add(it.url)) out.add(it); } catch (Throwable ignored) { }
        java.util.Collections.sort(out, (a, b) -> Long.compare(b.added, a.added));
        if (out.size() > max) out = new ArrayList<>(out.subList(0, max));
        return out;
    }
    JSONObject vodInfo(Item m) {
        try {
            if (server.isEmpty() || m.id.isEmpty()) return new JSONObject();
            JSONObject o = new JSONObject(cached("x_vod_" + m.id, api("get_vod_info", "&vod_id=" + enc(m.id)), false));
            JSONObject i = o.optJSONObject("info");
            if (i == null) i = new JSONObject();
            JSONObject md = o.optJSONObject("movie_data");   /* alguns servidores põem parte dos dados aqui */
            if (md != null) { java.util.Iterator<String> it = md.keys(); while (it.hasNext()) { String k = it.next(); if (text(i, k).isEmpty()) i.put(k, md.opt(k)); } }
            if (text(i, "plot", "description", "overview").isEmpty()) dbg("filme " + m.id + " sem sinopse no servidor (campos: " + i.names() + ")");
            return i;
        } catch (Throwable e) { dbg("filme " + m.id + ": erro na ficha: " + e.getMessage()); return new JSONObject(); }
    }
    /* ------------------------------------------------------------ v284: sinopses (primeiro campo com texto) e tradução para português */
    static final java.util.ArrayDeque<String> DBG = new java.util.ArrayDeque<>();
    /* v424: um só formatador de horas (criar um por linha de registo custava tempo em cada entrada) */
    private static final java.text.SimpleDateFormat HHMMSS = new java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US);
    static void dbg(String m) {
        String l;
        synchronized (DBG) { l = HHMMSS.format(new java.util.Date()) + " " + m; DBG.addLast(l); while (DBG.size() > 40) DBG.removeFirst(); }
        persist(l);
    }

    /* ------------------------------------------------------------ v302: registo que sobrevive a a app fechar-se / ir abaixo */
    private static java.io.File pDir;
    private static final java.util.ArrayDeque<String> PLOG = new java.util.ArrayDeque<>();
    private static volatile boolean pQueued = false;
    private static final android.os.Handler pH; static { android.os.HandlerThread t = new android.os.HandlerThread("registo"); t.start(); pH = new android.os.Handler(t.getLooper()); }
    /** Chamado uma vez no arranque: guarda o registo da sessão anterior e instala o apanhador de falhas. */
    static void initPersist(Context c) {
        if (pDir != null) return;
        pDir = c.getFilesDir();
        try { java.io.File now = new java.io.File(pDir, "dbg_now.txt"), prev = new java.io.File(pDir, "dbg_prev.txt"); if (now.exists()) { prev.delete(); now.renameTo(prev); } } catch (Throwable ignored) { }
        /* v472: quedas nativas (decodificador/superfície) não passam pelo apanhador de falhas; o Android guarda o motivo da saída do processo anterior */
        try {
            if (android.os.Build.VERSION.SDK_INT >= 30) {
                android.app.ActivityManager am = (android.app.ActivityManager) c.getSystemService(Context.ACTIVITY_SERVICE);
                java.util.List<android.app.ApplicationExitInfo> xs = am.getHistoricalProcessExitReasons(c.getPackageName(), 0, 4);
                java.io.File seen = new java.io.File(pDir, "exit_seen.txt");
                long last = 0; try { last = Long.parseLong(readTxt(seen).trim()); } catch (Throwable ignored) { }
                long newest = last;
                StringBuilder eb = new StringBuilder();
                for (android.app.ApplicationExitInfo x : xs) {
                    if (x.getTimestamp() <= last) continue;
                    newest = Math.max(newest, x.getTimestamp());
                    String why;
                    switch (x.getReason()) {
                        case android.app.ApplicationExitInfo.REASON_CRASH: why = "falha Java"; break;
                        case android.app.ApplicationExitInfo.REASON_CRASH_NATIVE: why = "FALHA NATIVA (decodificador/superfície)"; break;
                        case android.app.ApplicationExitInfo.REASON_ANR: why = "app sem resposta (ANR)"; break;
                        case android.app.ApplicationExitInfo.REASON_LOW_MEMORY: why = "morta por falta de memória"; break;
                        case android.app.ApplicationExitInfo.REASON_SIGNALED: why = "morta por sinal"; break;
                        case android.app.ApplicationExitInfo.REASON_INITIALIZATION_FAILURE: why = "falha ao iniciar"; break;
                        case android.app.ApplicationExitInfo.REASON_USER_REQUESTED: why = "fechada pelo utilizador"; break;
                        case android.app.ApplicationExitInfo.REASON_USER_STOPPED: why = "parada pelo utilizador"; break;
                        case android.app.ApplicationExitInfo.REASON_EXIT_SELF: why = "terminou sozinha"; break;
                        case android.app.ApplicationExitInfo.REASON_DEPENDENCY_DIED: why = "dependência morreu"; break;
                        case android.app.ApplicationExitInfo.REASON_EXCESSIVE_RESOURCE_USAGE: why = "uso excessivo de recursos"; break;
                        default: why = "outro (" + x.getReason() + ")";
                    }
                    String ln = "SAÍDA ANTERIOR: " + new java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(new java.util.Date(x.getTimestamp()))
                            + " · " + why + " · estado " + x.getStatus() + (x.getDescription() != null ? " · " + x.getDescription() : "") + " · importância " + x.getImportance();
                    eb.append(ln).append('\n');
                    if (x.getReason() == android.app.ApplicationExitInfo.REASON_CRASH_NATIVE || x.getReason() == android.app.ApplicationExitInfo.REASON_ANR) {
                        try (java.io.InputStream in = x.getTraceInputStream()) {
                            if (in != null) {
                                java.io.BufferedReader br = new java.io.BufferedReader(new java.io.InputStreamReader(in, "UTF-8"));
                                String l; int n = 0; boolean mainT = false; int lines = 0;
                                while ((l = br.readLine()) != null && lines < 20000 && n < 70) {
                                    lines++;
                                    if (l.startsWith("\"main\"")) { mainT = true; eb.append("  ").append(l.length() > 200 ? l.substring(0, 200) : l).append('\n'); continue; }
                                    if (mainT) {
                                        if (l.trim().isEmpty() || l.startsWith("\"")) { mainT = false; continue; }
                                        if (l.contains("  at ") || l.contains("native: #") || l.contains("held by") || l.contains("waiting") || l.contains("locked")) { eb.append("  ").append(l.length() > 220 ? l.substring(0, 220) : l).append('\n'); n++; }
                                    } else if (l.startsWith("signal") || l.startsWith("Abort message")) { eb.append("  ").append(l).append('\n'); n++; }
                                }
                            }
                        } catch (Throwable ignored) { }
                    }
                }
                if (eb.length() > 0) { try (FileOutputStream o = new FileOutputStream(new java.io.File(pDir, "exit_last.txt"))) { o.write(eb.toString().getBytes("UTF-8")); } catch (Throwable ignored) { } }
                if (newest > last) { try (FileOutputStream o = new FileOutputStream(seen)) { o.write(String.valueOf(newest).getBytes("UTF-8")); } catch (Throwable ignored) { } }
            }
        } catch (Throwable ignored) { }
        final Thread.UncaughtExceptionHandler old = Thread.getDefaultUncaughtExceptionHandler();
        Thread.setDefaultUncaughtExceptionHandler((th, ex) -> {
            try {
                java.io.StringWriter sw = new java.io.StringWriter(); ex.printStackTrace(new java.io.PrintWriter(sw));
                String st = sw.toString(); if (st.length() > 6000) st = st.substring(0, 6000);
                String head = new java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.US).format(new java.util.Date()) + " · fio " + th.getName() + "\n";
                try (FileOutputStream o = new FileOutputStream(new java.io.File(pDir, "crash.txt"))) { o.write((head + st).getBytes("UTF-8")); }
                persist("A APP FOI ABAIXO: " + ex);
                flushNow();
            } catch (Throwable ignored) { }
            if (old != null) old.uncaughtException(th, ex);
        });
    }
    static void persist(String line) {
        if (pDir == null) return;
        synchronized (PLOG) { PLOG.addLast(line); while (PLOG.size() > 300) PLOG.removeFirst(); }
        if (!pQueued) { pQueued = true; pH.postDelayed(NativeData::flushNow, 1500); }
    }
    static void flushNow() {
        pQueued = false;
        try {
            StringBuilder b = new StringBuilder(); synchronized (PLOG) { for (String l : PLOG) b.append(l).append('\n'); }
            try (FileOutputStream o = new FileOutputStream(new java.io.File(pDir, "dbg_now.txt"))) { o.write(b.toString().getBytes("UTF-8")); }
        } catch (Throwable ignored) { }
    }
    private static String readTxt(java.io.File f) throws java.io.IOException {
        try (java.io.FileInputStream in = new java.io.FileInputStream(f)) { java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); byte[] b = new byte[8192]; int n; while ((n = in.read(b)) > 0) bo.write(b, 0, n); return bo.toString("UTF-8"); }
    }
    /** Para o diagnóstico: falha guardada e fim do registo da sessão anterior. */
    static String previousSession(int maxLines) {
        StringBuilder b = new StringBuilder();
        try {
            java.io.File cr = new java.io.File(pDir, "crash.txt");
            if (cr.exists() && System.currentTimeMillis() - cr.lastModified() < 3L * 86400000L) b.append("=== ÚLTIMA FALHA DA APP ===\n").append(readTxt(cr)).append("\n");
            java.io.File ex = new java.io.File(pDir, "exit_last.txt");
            if (ex.exists() && System.currentTimeMillis() - ex.lastModified() < 3L * 86400000L) b.append("=== MOTIVO DA ÚLTIMA SAÍDA (Android) ===\n").append(readTxt(ex)).append("\n");
            java.io.File pv = new java.io.File(pDir, "dbg_prev.txt");
            if (pv.exists()) {
                String[] ls = readTxt(pv).split("\n");
                b.append("=== SESSÃO ANTERIOR (fim) ===\n");
                for (int i = Math.max(0, ls.length - maxLines); i < ls.length; i++) b.append(ls[i]).append('\n');
                b.append("=== SESSÃO ATUAL ===\n");
            }
        } catch (Throwable ignored) { }
        return b.toString();
    }
    static String text(JSONObject i, String... keys) {
        if (i == null) return "";
        for (String k : keys) { String v = i.optString(k, "").trim(); if (v.length() > 1 && !v.equalsIgnoreCase("n/a") && !v.equalsIgnoreCase("null")) return v; }
        return "";
    }
    /** Tradução já guardada no aparelho (para o idioma da interface), ou null. */
    String trCached(String t) {
        if (t == null || t.trim().length() < 20) return null;
        t = t.trim();
        return ctx.getSharedPreferences("trcache", 0).getString(Tr.lang + "|" + Integer.toHexString(t.hashCode()) + "|" + t.length(), null);
    }
    private final java.util.Set<String> trQueued = java.util.Collections.synchronizedSet(new java.util.HashSet<>());
    private final java.util.concurrent.ExecutorService trExec = java.util.concurrent.Executors.newSingleThreadExecutor();
    /** Traduz por trás (sinopses dos episódios); a próxima vez que o cartão aparecer já vem traduzido. */
    void trLater(final String t) {
        if (t == null || t.trim().length() < 20 || !trQueued.add(Tr.lang + t)) return;
        trExec.execute(() -> { try { translatePt(t); } catch (Throwable ignored) { } });
    }
    /** Traduz para português (Google, com o MyMemory de reserva), como a app antiga; guarda no aparelho. Devolve null se não conseguir. */
    String translatePt(String t) {
        if (t == null || t.trim().length() < 3) return null;
        t = t.trim();
        SharedPreferences tc = ctx.getSharedPreferences("trcache", 0);
        final String tl = Tr.lang;   /* idioma da interface escolhido nas Definições */
        String key = tl + "|" + Integer.toHexString(t.hashCode()) + "|" + t.length();
        String hit = tc.getString(key, null); if (hit != null) return hit;
        StringBuilder out = new StringBuilder();
        for (String part : chunks(t, 1200)) {
            String r = null;
            try {
                JSONArray j = new JSONArray(http("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=" + tl + "&dt=t&q=" + enc(part), 8000));
                JSONArray a = j.optJSONArray(0); StringBuilder sb = new StringBuilder();
                if (a != null) for (int i = 0; i < a.length(); i++) { JSONArray x = a.optJSONArray(i); if (x != null) sb.append(x.optString(0)); }
                if (sb.length() > 0) r = sb.toString();
            } catch (Throwable ignored) { }
            if (r == null) {
                try {
                    JSONObject j = new JSONObject(http("https://api.mymemory.translated.net/get?q=" + enc(part.length() > 480 ? part.substring(0, 480) : part) + "&langpair=Autodetect|" + ("pt".equals(tl) ? "pt-PT" : "en".equals(tl) ? "en-GB" : "fr".equals(tl) ? "fr-FR" : "es".equals(tl) ? "es-ES" : "de-DE"), 8000));
                    String o = j.optJSONObject("responseData") == null ? "" : j.optJSONObject("responseData").optString("translatedText");
                    if (o.length() > 0 && !o.matches("(?is).*(MYMEMORY WARNING|INVALID).*")) r = o;
                } catch (Throwable ignored) { }
            }
            if (r == null) return null;
            if (out.length() > 0) out.append(' ');
            out.append(r);
        }
        String res = out.toString();
        tc.edit().putString(key, res).apply();
        return res;
    }
    private static List<String> chunks(String t, int max) {
        List<String> out = new ArrayList<>(); StringBuilder cur = new StringBuilder();
        for (String sn : t.split("(?<=[.!?…])\\s+")) {
            while (sn.length() > max) { if (cur.length() > 0) { out.add(cur.toString()); cur.setLength(0); } out.add(sn.substring(0, max)); sn = sn.substring(max); }
            if (cur.length() + sn.length() + 1 > max) { out.add(cur.toString()); cur.setLength(0); }
            if (cur.length() > 0) cur.append(' ');
            cur.append(sn);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    static String firstImg(JSONObject i, String... keys) {
        for (String k : keys) {
            Object v = i.opt(k);
            if (v instanceof JSONArray) { JSONArray a = (JSONArray) v; for (int j = 0; j < a.length(); j++) { String s = a.optString(j); if (s.startsWith("http")) return s; } }
            else if (v != null && String.valueOf(v).startsWith("http")) return String.valueOf(v);
        }
        return "";
    }
    static String trailerId(JSONObject i) {
        String t = i.optString("youtube_trailer", i.optString("trailer"));
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?:v=|youtu\\.be/|embed/)([\\w-]{11})").matcher(t);
        if (m.find()) return m.group(1);
        return t.matches("[\\w-]{11}") ? t : "";
    }

    Item findByUrl(String url) {
        for (List<Item> l : all.values()) for (Item it : l) if (it.url.equals(url)) return it;
        for (Item it : recents()) if (it.url.equals(url)) return it;
        return null;
    }
    Item seriesBySid(String sid) {
        List<Item> l = all.get("series"); if (l == null) return null;
        for (Item it : l) if (it.sid.equals(sid)) return it;
        return null;
    }

    /** Vistos até ao fim (filmes e episódios). */
    boolean watched(String url) { return jo(uk("watched")).has(url); }
    void setWatched(String url, boolean on) {
        try { JSONObject o = new JSONObject(sp.getString(uk("watched"), "{}")); if (on) o.put(url, System.currentTimeMillis()); else o.remove(url); sp.edit().putString(uk("watched"), o.toString()).apply(); } catch (Throwable ignored) { }
        if (on) { try { JSONObject o = new JSONObject(sp.getString(uk("pos"), "{}")); o.remove(url); sp.edit().putString(uk("pos"), o.toString()).apply(); } catch (Throwable ignored) { } }
    }
    /** Último episódio aberto de cada série. */
    void setLastEp(String sid, String url) { try { JSONObject o = new JSONObject(sp.getString(uk("slast"), "{}")); o.put(sid, url); sp.edit().putString(uk("slast"), o.toString()).apply(); } catch (Throwable ignored) { } }
    String lastEp(String sid) { return jo(uk("slast")).optString(sid, ""); }

    /** Filmes a meio, do mais recente para o mais antigo. */
    List<Item> continueMovies() {
        List<Item> out = new ArrayList<>(); LinkedHashSet<String> seen = new LinkedHashSet<>();
        for (Item r : recents()) {
            if (!"movie".equals(r.kind) || pos(r.url) <= 0 || !seen.add(r.url)) continue;
            Item full = null; List<Item> l = all.get("movie"); if (l != null) for (Item x : l) if (x.url.equals(r.url)) { full = x; break; }
            out.add(full != null ? full : r);
        }
        return out;
    }
    /** Séries em curso (pela ordem em que foram vistas). */
    List<Item> continueSeries() {
        List<Item> out = new ArrayList<>(); LinkedHashSet<String> seen = new LinkedHashSet<>();
        for (Item r : recents()) {
            if (!"episode".equals(r.kind) || r.sid.isEmpty() || !seen.add(r.sid)) continue;
            Item s = seriesBySid(r.sid);
            if (s != null) out.add(s);
        }
        return out;
    }
    static final String[] SORT_L = {"Ordem do servidor", "A–Z", "Mais recentes", "Melhor avaliação", "Ano"};
    int sortMode(String kind) { return sp.getInt("sort_" + kind, 0); }
    void setSortMode(String kind, int m) { sp.edit().putInt("sort_" + kind, m).apply(); }
    /* v308: ordenações guardadas (o mesmo ficheiro de lista = a mesma ordem) e chaves calculadas uma só vez (antes normalizava o nome em cada comparação: segundos nas TV) */
    private static final java.util.LinkedHashMap<String, Object[]> SORT_CACHE = new java.util.LinkedHashMap<String, Object[]>(16, 0.75f, true) {
        @Override protected boolean removeEldestEntry(Map.Entry<String, Object[]> e) { return size() > 24; }
    };
    static List<Item> sorted(List<Item> in, int mode) {
        if (mode <= 0) return in;
        final String ck = System.identityHashCode(in) + ":" + mode + ":" + in.size();
        if (in.size() > 300) synchronized (SORT_CACHE) { Object[] e = SORT_CACHE.get(ck); if (e != null && e[0] == in) { @SuppressWarnings("unchecked") List<Item> r = (List<Item>) e[1]; return r; } }
        final int n = in.size();
        final Item[] arr = in.toArray(new Item[0]);
        Integer[] idx = new Integer[n]; for (int k = 0; k < n; k++) idx[k] = k;
        if (mode == 1) {
            final String[] key = new String[n]; for (int k = 0; k < n; k++) key[k] = norm(arr[k].name);
            java.util.Arrays.sort(idx, (a, b) -> key[a].compareTo(key[b]));
        } else if (mode == 2) {
            java.util.Arrays.sort(idx, (a, b) -> Long.compare(arr[b].added, arr[a].added));
        } else if (mode == 3) {
            final double[] key = new double[n]; for (int k = 0; k < n; k++) key[k] = num(arr[k].rating);
            java.util.Arrays.sort(idx, (a, b) -> Double.compare(key[b], key[a]));
        } else {
            java.util.Arrays.sort(idx, (a, b) -> arr[b].year.compareTo(arr[a].year));
        }
        List<Item> l = new ArrayList<>(n); for (int k = 0; k < n; k++) l.add(arr[idx[k]]);
        if (n > 300) synchronized (SORT_CACHE) { SORT_CACHE.put(ck, new Object[]{in, l}); }
        return l;
    }
    private static double num(String s) { try { return Double.parseDouble(s); } catch (Throwable e) { return 0; } }

    /* ------------------------------------------------------------ legendas online (OpenSubtitles, a mesma conta da app antiga) */
    String osKey() { return sp.getString("osKey", ""); }
    /* v402: chave da API do TMDB (trailers oficiais do YouTube). Grátis para uso pessoal com atribuição; vazia = usa as outras fontes. */
    String tmdbKey() { return sp.getString("tmdbKey", ""); }
    void setTmdbKey(String k) { sp.edit().putString("tmdbKey", k.trim()).apply(); }
    /* v401: por defeito ligado: filmes e séries arrancam com legendas em português (a escolha guardada prevalece). */
    boolean osAuto() { return sp.getBoolean("osAuto", true); }
    void saveOs(String key, String u, String p, boolean auto) { sp.edit().putString("osKey", key.trim()).putString("osUser", u.trim()).putString("osPass", p).putBoolean("osAuto", auto).apply(); osToken = ""; }
    String osUser() { return sp.getString("osUser", ""); }
    String osPass() { return sp.getString("osPass", ""); }
    private String osToken = "", osBase = "https://api.opensubtitles.com/api/v1";
    private String osCall(String path, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(osBase + path).openConnection();
        try {
            c.setConnectTimeout(10000); c.setReadTimeout(20000);
            c.setRequestProperty("Api-Key", osKey()); c.setRequestProperty("Accept", "application/json"); c.setRequestProperty("User-Agent", "CockpitTV v1.0");
            if (osToken.length() > 0 && body != null) c.setRequestProperty("Authorization", "Bearer " + osToken);
            if (body != null) { c.setRequestMethod("POST"); c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json"); c.getOutputStream().write(body.getBytes("UTF-8")); }
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String s = in == null ? "" : readAll(in);
            if (code >= 400) { String m = ""; try { JSONObject j = new JSONObject(s); m = j.optString("message", j.optString("error")); } catch (Throwable ignored) { } throw new Exception(m.isEmpty() ? Tr.t("HTTP ") + code : m); }
            return s;
        } finally { c.disconnect(); }
    }
    private static String readAll(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); byte[] b = new byte[16384]; int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n); in.close();
        return bo.toString("UTF-8");
    }
    /** Resultados em português: [{id, label}] (PT primeiro, depois os de confiança e os mais descarregados). */
    List<String[]> osSearch(String raw) throws Exception {
        if (osKey().isEmpty()) throw new Exception(Tr.t("falta a chave da API OpenSubtitles (Definições)"));
        String t = java.text.Normalizer.normalize(raw == null ? "" : raw, java.text.Normalizer.Form.NFKD)
                .replaceAll("(?i)\\.(mkv|mp4|avi|mov|m4v|ts|m3u8)$", " ")
                .replaceAll("^\\s*[A-Za-z]{2,3}\\s*[|:]\\s*", " ")
                .replaceAll("\\[[^\\]]*\\]|\\([^)]*\\)|\\|[a-zA-Z]{2,3}\\|", " ").replaceAll("[._]+", " ");
        int s = 0, e = 0;
        java.util.regex.Matcher se = java.util.regex.Pattern.compile("(?i)\\bS(\\d{1,2})\\s?E(\\d{1,3})\\b").matcher(t);
        java.util.regex.Matcher se2 = java.util.regex.Pattern.compile("\\bT(\\d{1,2})·E(\\d{1,3})\\b").matcher(raw == null ? "" : raw);
        if (se.find()) { s = Integer.parseInt(se.group(1)); e = Integer.parseInt(se.group(2)); }
        else if (se2.find()) { s = Integer.parseInt(se2.group(1)); e = Integer.parseInt(se2.group(2)); }
        java.util.regex.Matcher ym = java.util.regex.Pattern.compile("\\b(19\\d\\d|20\\d\\d)\\b").matcher(t);
        String year = ym.find() ? ym.group(1) : "";
        /* v345: não cortar o título depois do ano; remover só tags de qualidade/CAM. */
        t = t.replaceAll("(?i)\\bS\\d{1,2}\\s?E\\d{1,3}\\b", " ").replaceAll("\\bT\\d{1,2}·E\\d{1,3}\\b", " ")
                .replaceAll("(?i)\\b(uhd|fhd|4k|hevc|h ?26[45]|x26[45]|hd|sd|1080p?|720p?|2160p?|bluray|brrip|webrip|web-?dl|hdrip|dvdrip|bdrip|hdtv|cam|hdcam|telesync|screener|dublado|legendado|pt-?pt|pt-?br|multi|dual)\\b", " ")
                .replaceAll("\\b(19\\d\\d|20\\d\\d)\\b", " ")
                .replaceAll("[^\\p{L}\\p{N}' ]+", " ").replaceAll("\\s+", " ").trim().toLowerCase();
        if (t.isEmpty()) throw new Exception(Tr.t("título vazio"));
        java.util.TreeMap<String, String> p = new java.util.TreeMap<>();   /* a API exige os parâmetros por ordem alfabética */
        p.put("languages", "pt-br,pt-pt"); p.put("query", t);
        if (s > 0) { p.put("season_number", "" + s); p.put("episode_number", "" + e); p.put("type", "episode"); }
        else {
            p.put("type", "movie");
            if (!year.isEmpty()) p.put("year", year);
        }
        /* v345: tenta com type/year; se vazio, relaxa (só query + língua) — títulos CAM/IPTV falham muitas vezes com type=movie. */
        List<Object[]> rows = osSearchRows(p);
        if (rows.isEmpty() && (p.containsKey("year") || "movie".equals(p.get("type")))) {
            p.remove("year");
            rows = osSearchRows(p);
        }
        if (rows.isEmpty() && p.containsKey("type") && !"episode".equals(p.get("type"))) {
            p.remove("type");
            rows = osSearchRows(p);
        }
        java.util.Collections.sort(rows, (x, y) -> Integer.compare((Integer) y[0], (Integer) x[0]));
        List<String[]> out = new ArrayList<>(); for (Object[] r : rows) { out.add((String[]) r[1]); if (out.size() >= 10) break; }
        return out;
    }
    private List<Object[]> osSearchRows(java.util.Map<String, String> p) throws Exception {
        StringBuilder q = new StringBuilder();
        for (Map.Entry<String, String> en : p.entrySet()) q.append(q.length() == 0 ? "?" : "&").append(en.getKey()).append("=").append(enc(en.getValue()).replace("+", "%20"));
        JSONArray d = new JSONObject(osCall("/subtitles" + q, null)).optJSONArray("data");
        List<Object[]> rows = new ArrayList<>();
        if (d != null) for (int i = 0; i < d.length(); i++) {
            JSONObject a = d.optJSONObject(i) == null ? null : d.optJSONObject(i).optJSONObject("attributes"); if (a == null) continue;
            JSONArray fs = a.optJSONArray("files"); if (fs == null || fs.length() == 0) continue;
            JSONObject f = fs.optJSONObject(0); String fid = f.optString("file_id"); if (fid.isEmpty()) continue;
            String lang = a.optString("language"); boolean pt = lang.toLowerCase().matches("pt-?pt");
            String rel = a.optString("release", f.optString("file_name"));
            String label = (pt ? "PT" : "BR") + " · " + (rel.length() > 60 ? rel.substring(0, 60) : rel) + "  ↓" + a.optInt("download_count") + (a.optBoolean("from_trusted") ? " ✓" : "");
            int score = (pt ? 1000000000 : 0) + (a.optBoolean("from_trusted") ? 100000000 : 0) - (a.optBoolean("hearing_impaired") ? 50000000 : 0) + Math.min(49999999, a.optInt("download_count"));
            rows.add(new Object[]{score, new String[]{fid, label}});
        }
        return rows;
    }

    void setOsAuto(boolean on) { sp.edit().putBoolean("osAuto", on).apply(); }
    /* ------------------------------------------------------------ v347: legendas em português SEM credenciais
       1) Cinemeta (catálogo aberto do Stremio) dá o código IMDb a partir do título; 2) o addon aberto do OpenSubtitles (v3) dá as legendas desse código.
       Nenhum dos dois pede chave nem conta. «por» = português de Portugal (primeiro), «pob» = do Brasil (recurso). Devolve [{url, etiqueta}]. */
    List<String[]> freeSubs(String title, String year, boolean series, int season, int ep) throws Exception {
        String t = java.text.Normalizer.normalize(title == null ? "" : title, java.text.Normalizer.Form.NFKC).replaceAll("[._]+", " ").replaceAll("\\s+", " ").trim();
        if (t.isEmpty()) throw new Exception(Tr.t("título vazio"));
        String kind = series ? "series" : "movie";
        String imdb = "";
        String nt = norm(t).replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
        JSONArray metas = null;
        try { metas = new JSONObject(http("https://v3-cinemeta.strem.io/catalog/" + kind + "/top/search=" + enc(t).replace("+", "%20") + ".json", 12000)).optJSONArray("metas"); }
        catch (Exception e) { dbg("legendas sem conta: catálogo falhou: " + e); throw new Exception(Tr.t("não consegui consultar o catálogo de filmes (") + e.getMessage() + ")"); }
        int best = -1;
        if (metas != null) for (int i = 0; i < metas.length() && i < 15; i++) {
            JSONObject m = metas.optJSONObject(i); if (m == null) continue;
            String id = m.optString("imdb_id", m.optString("id")); if (!id.startsWith("tt")) continue;
            String nm = norm(m.optString("name")).replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
            String ri = m.optString("releaseInfo", m.optString("year"));
            int sc = 100 - i;
            if (nm.equals(nt)) sc += 1000; else if (nm.startsWith(nt) || nt.startsWith(nm)) sc += 300;
            if (year != null && year.length() >= 4 && ri.startsWith(year.substring(0, 4))) sc += 500;
            if (sc > best) { best = sc; imdb = id; }
        }
        dbg("legendas sem conta: «" + t + "»" + (year == null || year.isEmpty() ? "" : " " + year) + " → " + (imdb.isEmpty() ? "sem código IMDb" : imdb));
        if (imdb.isEmpty()) return new ArrayList<>();
        String vid = series && season > 0 ? imdb + ":" + season + ":" + Math.max(1, ep) : imdb;
        JSONArray subs = new JSONObject(http("https://opensubtitles-v3.strem.io/subtitles/" + kind + "/" + enc(vid).replace("%3A", ":") + ".json", 15000)).optJSONArray("subtitles");
        List<String[]> pt = new ArrayList<>(), br = new ArrayList<>();
        if (subs != null) for (int i = 0; i < subs.length(); i++) {
            JSONObject s = subs.optJSONObject(i); if (s == null) continue;
            String lang = s.optString("lang").toLowerCase(java.util.Locale.ROOT), u = s.optString("url");
            if (!u.startsWith("http")) continue;
            if (lang.equals("por") || lang.equals("pt") || lang.equals("pt-pt")) { if (pt.size() < 6) pt.add(new String[]{u, Tr.t("PT · Português (Portugal) ") + (pt.size() + 1)}); }
            else if (lang.equals("pob") || lang.equals("pt-br")) { if (br.size() < 4) br.add(new String[]{u, Tr.t("BR · Português (Brasil) ") + (br.size() + 1)}); }
        }
        dbg("legendas sem conta: " + pt.size() + " PT, " + br.size() + " BR" + (subs == null ? " (resposta sem lista)" : " em " + subs.length()));
        pt.addAll(br);
        return pt;
    }
    String freeSubDownload(String url) throws Exception {
        String s = http(url, 15000);
        if (s == null || !s.contains("-->")) throw new Exception(Tr.t("o ficheiro recebido não é uma legenda"));
        return s;
    }

    /** Descarrega a legenda escolhida em SRT (texto). */
    String osDownload(String fileId) throws Exception {
        if (osToken.isEmpty() && osUser().length() > 0 && osPass().length() > 0) {
            try {
                JSONObject j = new JSONObject(osCall("/login", new JSONObject().put("username", osUser()).put("password", osPass()).toString()));
                osToken = j.optString("token");
                String bu = j.optString("base_url"); if (bu.length() > 0) osBase = "https://" + bu.replaceAll("^https?://", "").replaceAll("/.*$", "") + "/api/v1";
            } catch (Throwable ignored) { }
        }
        JSONObject j = new JSONObject(osCall("/download", new JSONObject().put("file_id", Long.parseLong(fileId)).put("sub_format", "srt").toString()));
        String link = j.optString("link"); if (link.isEmpty()) throw new Exception(Tr.t("sem ligação de download"));
        HttpURLConnection c = (HttpURLConnection) new URL(link).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(20000); c.setInstanceFollowRedirects(true);
        byte[] b; try { InputStream in = c.getInputStream(); java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); byte[] buf = new byte[16384]; int n; while ((n = in.read(buf)) > 0) bo.write(buf, 0, n); in.close(); b = bo.toByteArray(); } finally { c.disconnect(); }
        String txt = new String(b, "UTF-8");
        if (txt.contains("\uFFFD")) txt = new String(b, "windows-1252");   /* legendas antigas em Latin-1 */
        return txt;
    }

    /* ------------------------------------------------------------ operador (v274): canais pela ordem da grelha MEO / NOS / Vodafone */
    String opKey() { return sp.getString("tvOp", ""); }
    String opCustom() { return sp.getString("tvOpCustom", ""); }
    void setOp(String k, String custom) { sp.edit().putString("tvOp", k == null ? "" : k).putString("tvOpCustom", custom == null ? opCustom() : custom).apply(); }
    private JSONObject ops;
    JSONObject ops() {
        if (ops == null) { try (InputStream in = ctx.getAssets().open("ui/ops.json")) { ops = new JSONObject(readAll(in)); } catch (Throwable e) { ops = new JSONObject(); } }
        return ops;
    }
    String opTitle(String k) { return "custom".equals(k) ? "Ordem personalizada" : "Canais " + (ops().optJSONObject(k) == null ? k : ops().optJSONObject(k).optString("label")); }
    private static final java.util.Set<String> OP_DROP = new java.util.HashSet<>(java.util.Arrays.asList("fhd", "uhd", "hd", "sd", "4k", "8k", "hevc", "h265", "raw", "plus", "1080p", "1080", "720p", "720", "2160p"));
    /** v288: a mesma normalização de antes, sem expressões regulares (muito mais rápida nas TVs). */
    private static String opNrm(String n) {
        String s = fastNorm(n);
        StringBuilder out = new StringBuilder(s.length());
        StringBuilder tok = new StringBuilder();
        int depth = 0; boolean first = true;
        for (int i = 0; i <= s.length(); i++) {
            char c = i < s.length() ? s.charAt(i) : ' ';
            if (c == '[' || c == '(') { depth++; c = ' '; } else if ((c == ']' || c == ')') && depth > 0) { depth--; c = ' '; continue; }
            if (depth > 0) continue;
            boolean an = (c >= 'a' && c <= 'z') || (c >= '0' && c <= '9');
            if (an) { tok.append(c); continue; }
            if (tok.length() > 0) {
                String t = tok.toString(); tok.setLength(0);
                if (first && (t.equals("pt") || t.equals("portugal"))) { first = false; continue; }
                first = false;
                if (!OP_DROP.contains(t)) out.append(t);
            }
        }
        return out.toString();
    }
    private static final java.util.regex.Pattern CTY = java.util.regex.Pattern.compile("^[\\s|\\[]*([A-Za-z]{2,3})\\s*[|:\\]]");
    /** 0 = português (PT, BR, AO, MZ, CV), 1 = sem país, 2 = outro país (fica de fora). */
    private static int opLang(Item c) {
        for (String t : new String[]{c.group, c.name}) {
            java.util.regex.Matcher m = CTY.matcher(t == null ? "" : t);
            if (m.find()) { String k = m.group(1).toUpperCase(); return k.matches("PT|BR|AO|MZ|CV|POR") ? 0 : 2; }
            if (t != null && t.toUpperCase().matches(".*\\b(PORTUGAL|PORTUGU[EÊ]S|PORTUGUESA)\\b.*")) return 0;
        }
        return 1;
    }
    private static final java.util.regex.Pattern Q_FHD = java.util.regex.Pattern.compile("(?i)\\b(1080[pi]?|fhd)\\b");
    private static final java.util.regex.Pattern Q_UHD = java.util.regex.Pattern.compile("(?i)\\b(4k|uhd|2160p?)\\b");
    private static final java.util.regex.Pattern Q_HD = java.util.regex.Pattern.compile("(?i)\\b(hd|720p?)\\b");
    /** v457: altura real (píxeis) lida do vídeo de cada entrada na validação das Definições; 0/ausente = nunca validada. */
    static final Map<String, Integer> PROBED = new java.util.concurrent.ConcurrentHashMap<>();
    private boolean probedLoaded = false;
    private static boolean learnLoaded = false; private static long learnSaveAt = 0;
    /** v472: aprende a altura real de cada canal em direto quando o vês em ecrã total (guarda o máximo visto); a lista MEO passa a preferir sozinha as entradas que sabemos serem 1080p. */
    static void learnHeight(Context c, String url, int h) {
        try {
            if (c == null || url == null || h <= 0 || !url.contains("/live/")) return;
            android.content.SharedPreferences p = c.getSharedPreferences("nativeapp", 0);
            if (!learnLoaded) { learnLoaded = true; JSONObject o = new JSONObject(p.getString("opRes", "{}")); for (java.util.Iterator<String> it = o.keys(); it.hasNext(); ) { String k = it.next(); PROBED.putIfAbsent(k, o.optInt(k)); } }
            Integer old = PROBED.get(url);
            if (old != null && old >= h) return;
            PROBED.put(url, h);
            long now = System.currentTimeMillis();
            if (now - learnSaveAt < 5000) return;
            learnSaveAt = now;
            JSONObject o = new JSONObject(); for (Map.Entry<String, Integer> e : PROBED.entrySet()) o.put(e.getKey(), e.getValue());
            p.edit().putString("opRes", o.toString()).apply();
        } catch (Throwable ignored) { }
    }
    void loadProbed() {
        try {
            JSONObject o = new JSONObject(sp.getString("opRes", "{}"));
            PROBED.clear();
            for (java.util.Iterator<String> it = o.keys(); it.hasNext(); ) { String k = it.next(); PROBED.put(k, o.optInt(k)); }
            probedLoaded = true;
        } catch (Throwable ignored) { }
    }
    void saveProbed() {
        try { JSONObject o = new JSONObject(); for (Map.Entry<String, Integer> e : PROBED.entrySet()) o.put(e.getKey(), e.getValue()); sp.edit().putString("opRes", o.toString()).apply(); } catch (Throwable ignored) { }
    }
    private static int opQ(Item c) {
        /* v456: os nomes do fornecedor trazem a qualidade em letras pequenas elevadas («ᵁᴴᴰ», «ᴴᴰ»); a comparação não as via e
           todas as versões ficavam empatadas (ganhava a primeira da lista, muitas vezes a SD). NFKC transforma-as em UHD / HD. */
        String n = java.text.Normalizer.normalize(c.name == null ? "" : c.name, java.text.Normalizer.Form.NFKC);
        /* v457: se a entrada foi validada pelo conteúdo, manda a altura real (1080 primeiro; 4K só se não houver 1080; depois 720; o resto) e
           ganha às que só têm o nome como indício. Sem validação: 1080p/FHD, UHD (neste fornecedor os canais portugueses UHD saem em 1080), HD, resto. */
        Integer ph = c.url == null ? null : PROBED.get(c.url);
        boolean sure = ph != null && ph > 0;
        int q = sure ? (ph >= 1500 ? 1 : ph >= 1000 ? 0 : ph >= 650 ? 2 : 3)
                : Q_FHD.matcher(n).find() ? 0 : Q_UHD.matcher(n).find() ? 1 : Q_HD.matcher(n).find() ? 2 : 3;
        return q * 2 + (sure ? 0 : 1) + opLang(c) * 20 + (c.group != null && c.group.toUpperCase().matches(".*\\bPT\\b.*|.*PORTUGAL.*") ? 0 : 10);
    }
    /** v457: para cada canal da grelha, as entradas candidatas da lista (melhores primeiro, no máximo 4), para validar a resolução real. */
    Map<String, List<Item>> opCandidates(String key) {
        Map<String, List<Item>> out = new java.util.LinkedHashMap<>();
        List<Item> live = all.get("live"); if (live == null || live.isEmpty() || key == null || key.isEmpty()) return out;
        List<String> order = new ArrayList<>();
        if ("custom".equals(key)) { for (String l : opCustom().split("\\r?\\n")) if (l.trim().length() > 0) order.add(l.trim()); }
        else { JSONObject o = ops().optJSONObject(key); JSONArray a = o == null ? null : o.optJSONArray("list"); if (a != null) for (int i = 0; i < a.length(); i++) order.add(a.optString(i)); }
        Map<String, List<Item>> idx = new HashMap<>();
        for (Item c : live) { String k = opNrm(c.name); if (k.isEmpty()) continue; List<Item> l = idx.get(k); if (l == null) { l = new ArrayList<>(); idx.put(k, l); } l.add(c); }
        for (String ent : order) {
            List<Item> cand = new ArrayList<>();
            for (String alias : ent.split("\\|")) {
                List<Item> l = idx.get(opNrm(alias)); if (l == null) continue;
                for (Item c : l) if (opLang(c) < 2 && c.url != null && !c.url.isEmpty() && !cand.contains(c)) cand.add(c);
            }
            if (cand.isEmpty()) continue;
            java.util.Collections.sort(cand, (x, y) -> Integer.compare(opQ(x), opQ(y)));
            out.put(ent, cand.size() > 4 ? new ArrayList<>(cand.subList(0, 4)) : cand);
        }
        return out;
    }

    /** v458: canais da grelha do operador que não têm nenhuma entrada na lista do fornecedor (com a razão), para explicar «131 na grelha, N na tua lista». */
    List<String> opMissing(String key, Map<String, List<Item>> found) {
        List<String> out = new ArrayList<>();
        List<Item> live = all.get("live"); if (live == null || key == null || key.isEmpty()) return out;
        List<String> order = new ArrayList<>();
        if ("custom".equals(key)) { for (String l : opCustom().split("\\r?\\n")) if (l.trim().length() > 0) order.add(l.trim()); }
        else { JSONObject o = ops().optJSONObject(key); JSONArray a = o == null ? null : o.optJSONArray("list"); if (a != null) for (int i = 0; i < a.length(); i++) order.add(a.optString(i)); }
        Map<String, List<Item>> idx = new HashMap<>();
        for (Item c : live) { String k = opNrm(c.name); if (k.isEmpty()) continue; List<Item> l = idx.get(k); if (l == null) { l = new ArrayList<>(); idx.put(k, l); } l.add(c); }
        for (String ent : order) {
            if (found.containsKey(ent)) continue;
            boolean other = false;
            for (String alias : ent.split("\\|")) { List<Item> l = idx.get(opNrm(alias)); if (l != null && !l.isEmpty()) other = true; }
            out.add(ent + (other ? Tr.t(" (só existe com prefixo de outro país)") : Tr.t(" (sem nome igual na lista)")));
        }
        return out;
    }

    /** v457: altura real do vídeo de uma entrada: pede a lista, depois o início de um segmento, e lê o SPS (ver TsProbe).
     *  0 = não foi possível ler; lança «HTTP nnn» se o servidor recusar (509 = limite de ligações). */
    int probeHeight(String url) throws Exception {
        String cur = url;
        for (int depth = 0; depth < 3; depth++) {
            Object[] r = fetchHead(cur, 700000, 9000);
            byte[] b = (byte[]) r[0]; String fu = (String) r[1];
            String txt = new String(b, 0, Math.min(b.length, 200000), "ISO-8859-1");
            if (!txt.contains("#EXTM3U")) return TsProbe.height(b);   /* o fornecedor devolveu o fluxo TS logo */
            String[] lines = txt.split("\\r?\\n");
            if (txt.contains("#EXT-X-STREAM-INF")) {
                int best = 0; String first = null;
                for (int i = 0; i < lines.length; i++) {
                    String ln = lines[i].trim();
                    if (!ln.startsWith("#EXT-X-STREAM-INF")) continue;
                    java.util.regex.Matcher m = java.util.regex.Pattern.compile("RESOLUTION=\\d+x(\\d+)").matcher(ln);
                    if (m.find()) best = Math.max(best, Integer.parseInt(m.group(1)));
                    if (first == null) for (int j = i + 1; j < lines.length; j++) { String u = lines[j].trim(); if (!u.isEmpty() && !u.startsWith("#")) { first = u; break; } }
                }
                if (best > 0) return best;
                if (first == null) return 0;
                cur = new URL(new URL(fu), first).toString();
                continue;
            }
            List<String> segs = new ArrayList<>();
            for (String ln : lines) { String t = ln.trim(); if (!t.isEmpty() && !t.startsWith("#")) segs.add(t); }
            if (segs.isEmpty()) return 0;
            Object[] sg = fetchHead(new URL(new URL(fu), segs.get(Math.max(0, segs.size() - 2))).toString(), 700000, 12000);
            return TsProbe.height((byte[]) sg[0]);
        }
        return 0;
    }
    private static Object[] fetchHead(String u, int max, int timeoutMs) throws Exception {
        String cur = u;
        for (int i = 0; i < 6; i++) {
            HttpURLConnection c = (HttpURLConnection) new URL(cur).openConnection();
            c.setInstanceFollowRedirects(false); c.setConnectTimeout(timeoutMs); c.setReadTimeout(timeoutMs);
            c.setRequestProperty("User-Agent", UA);
            try {
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) { String loc = c.getHeaderField("Location"); if (loc == null) break; cur = new URL(new URL(cur), loc).toString(); continue; }
                if (code >= 400) throw new Exception(Tr.t("HTTP ") + code);
                InputStream in = c.getInputStream();
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); byte[] buf = new byte[16384]; int n;
                while (bo.size() < max && (n = in.read(buf)) > 0) bo.write(buf, 0, n);
                return new Object[]{bo.toByteArray(), cur};
            } finally { try { c.disconnect(); } catch (Throwable ignored) { } }
        }
        throw new Exception(Tr.t("demasiados redirecionamentos"));
    }
    /** Canais da lista do operador escolhido, pela ordem da grelha, na melhor versão portuguesa que houver. */
    List<Item> opChannels(String key) {
        List<Item> out = new ArrayList<>();
        if (!probedLoaded) loadProbed();
        List<Item> live = all.get("live"); if (live == null || live.isEmpty() || key == null || key.isEmpty()) return out;
        List<String> order = new ArrayList<>();
        if ("custom".equals(key)) { for (String l : opCustom().split("\\r?\\n")) if (l.trim().length() > 0) order.add(l.trim()); }
        else { JSONObject o = ops().optJSONObject(key); JSONArray a = o == null ? null : o.optJSONArray("list"); if (a != null) for (int i = 0; i < a.length(); i++) order.add(a.optString(i)); }
        Map<String, List<Item>> idx = new HashMap<>();
        for (Item c : live) { String k = opNrm(c.name); if (k.isEmpty()) continue; List<Item> l = idx.get(k); if (l == null) { l = new ArrayList<>(); idx.put(k, l); } l.add(c); }
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        int n = 0;
        for (String ent : order) {
            Item best = null;
            for (String alias : ent.split("\\|")) {
                List<Item> l = idx.get(opNrm(alias)); if (l == null) continue;
                for (Item c : l) if (!seen.contains(c.url) && opLang(c) < 2 && (best == null || opQ(c) < opQ(best))) best = c;
            }
            if (best != null) { seen.add(best.url); out.add(best); }
        }
        return out;
    }

    long pos(String url) { return jo(uk("pos")).optLong(url, 0); }
    long dur(String url) { return jo(uk("durs")).optLong(url, 0); }

    /** Pesquisa em todos os tipos já carregados (sem acentos, sem maiúsculas). */
    List<Item> search(String q) { return search(q, null); }
    /* v287: nomes já normalizados por tipo (feitos uma vez, fora do ecrã): a pesquisa em 250 mil filmes / 51 mil séries é instantânea */
    private final Map<String, Object[]> normIdx = new java.util.concurrent.ConcurrentHashMap<>();
    private String[] normsOf(String k) {
        List<Item> l = all.get(k); if (l == null) return null;
        Object[] c = normIdx.get(k);
        if (c != null && c[0] == l) return (String[]) c[1];
        String[] n = new String[l.size()];
        for (int i = 0; i < n.length; i++) n[i] = fastNorm(l.get(i).name);
        normIdx.put(k, new Object[]{l, n});
        return n;
    }
    static String fastNorm(String s) {
        if (s == null) return "";
        boolean ascii = true;
        for (int i = 0; i < s.length(); i++) if (s.charAt(i) > 127) { ascii = false; break; }
        return ascii ? s.toLowerCase(java.util.Locale.ROOT) : norm(s);
    }
    /** Prepara o índice de pesquisa de um tipo (chamar fora da thread do ecrã). */
    void prepareSearch(String k) { normsOf(k); gnOf(k); ctysOf(k); }   /* v424: os índices de género e país também ficam prontos (a 1.ª pesquisa por género demorava quase 9 s) */

    /** v424: padrão de um género: o id da tabela GEN (ex.: "comedia"); outro texto procura-se tal como está. Null = sem género. */
    static java.util.regex.Pattern genrePattern(String id) {
        if (id == null || id.trim().isEmpty()) return null;
        String t = id.trim();
        for (int i = 0; i < GEN.length; i++) if (GEN[i][0].equals(t)) return GENP[i];
        return java.util.regex.Pattern.compile(java.util.regex.Pattern.quote(fastNorm(t)));
    }
    /** v486: pesquisa na base completa (ignora as categorias, canais e países ocultos); escolhido no botão da pesquisa. */
    volatile boolean searchAll = false;
    /** v286: pesquisa só no tipo escolhido (canais, filmes ou séries); null = todos. */
    List<Item> search(String q, String only) {
        String n = norm(q); List<Item> out = new ArrayList<>();
        if (n.length() < 2) return out;
        final boolean full = searchAll;
        /* v486: «Todos»: filmes e séries primeiro e até 150 de cada tipo (antes os canais enchiam os 300 lugares) */
        final int cap = only == null ? 150 : 300;
        for (String k : only != null ? new String[]{only} : new String[]{"movie", "series", "live"}) {
            int got = 0;
            List<Item> l0 = all.get(k); String[] nn = normsOf(k);
            if (l0 != null && nn != null && nn.length == l0.size()) {
                for (int i = 0; i < nn.length && got < cap; i++) if (nn[i].contains(n)) { Item it = l0.get(i); if (full || !hiddenItem(it)) { out.add(it); got++; } }
                if (full && got < cap) for (Item it : searchHidden(k, n, cap - got, null, null)) { out.add(it); got++; }   /* v516 */
                continue;
            } List<Item> l = all.get(k); if (l == null) continue; for (Item it : l) { if (got >= cap) break; if (norm(it.name).contains(n) && (full || !hiddenItem(it))) { out.add(it); got++; } } }
        return out;
    }
    /** v348: pesquisa por nome, só dos títulos de um país (cc = PT, BR, EN…; vazio = todos). */
    List<Item> search(String q, String only, String cc) { return search(q, only, cc, null); }
    /** v371: pesquisa por nome, com filtro de país (cc) e de género/categoria (gen, texto contido no nome da categoria). */
    List<Item> search(String q, String only, String cc, String gen) { return search(q, only, cc, gen, null); }
    /** v391: resolução (720p, 1080p, 4k; vazio = qualquer) procurada como token no nome do item. */
    static java.util.regex.Pattern resPattern(String res) {
        if (res == null || res.trim().isEmpty()) return null;
        String alt;
        switch (res.trim().toLowerCase(java.util.Locale.ROOT)) {
            case "720p": alt = "720p?"; break;
            case "1080p": alt = "1080p?"; break;
            case "4k": alt = "4k|2160p?|uhd"; break;
            default: return null;
        }
        return java.util.regex.Pattern.compile("(?i)(?<![\\p{L}\\p{N}])(" + alt + ")(?![\\p{L}\\p{N}])");
    }
    /** v391: como a anterior, mais o filtro de resolução (res = 720p, 1080p ou 4k). */
    List<Item> search(String q, String only, String cc, String gen, String res) {
        if (only == null) return search(q, null);
        String n = norm(q);
        /* v424: o género usa a mesma tabela (GEN) que as categorias de género, aplicada ao nome do grupo */
        java.util.regex.Pattern gp = genrePattern(gen);
        java.util.regex.Pattern rp = resPattern(res);
        List<Item> out = new ArrayList<>();
        boolean useCc = cc != null && !cc.isEmpty();
        if (n.length() < 2 && gp == null && rp == null && !useCc) return out;   /* v477: só o país também é uma pesquisa válida */
        List<Item> l = all.get(only); if (l == null) return out;
        /* v369: nomes, grupos e países já calculados uma vez por lista. v370: se a lista mudou entre as leituras, cálculo directo */
        String[] nn = normsOf(only), cs = useCc ? ctysOf(only) : null;
        /* v425: o género usa os mesmos itens que as categorias de género (Explorar) */
        java.util.Set<Item> gset = gp == null ? null : genreItems(only, gen);
        if (gp != null && gset == null) return out;
        /* v477: com país e género, um título do país conta se o mesmo título está no género noutra categoria (ex.: «Moana» em |PT| FILMES e em |EN| ANIMATION) */
        final java.util.Set<String> gkeys = (gset != null && useCc) ? genreKeys(only, gen, gset) : null;
        boolean fast = nn != null && nn.length == l.size() && (cs == null || cs.length == l.size());
        /* v428: as ocultas lêem-se uma vez por pesquisa (antes, cada resultado voltava a ler as definições) */
        final java.util.Set<String> chS = new java.util.HashSet<>(list(org().optJSONArray("chHide")));
        final java.util.Set<String> ghS = new java.util.HashSet<>(list(arr2("grpHide", only)));
        final java.util.Map<String, Boolean> ctyH = new java.util.HashMap<>();
        for (int i = 0; i < l.size(); i++) {
            Item it = l.get(i);
            if (!(fast ? nn[i] : fastNorm(it.name)).contains(n)) continue;
            boolean viaTitulo = false;
            if (gset != null && !gset.contains(it)) { if (gkeys == null) continue; viaTitulo = true; }
            if (useCc) {
                String c = fast ? cs[i] : ctyOfGroup(it.name);
                if (!fast && c.isEmpty()) c = ctyOfGroup(it.group);
                if (!cc.equals(c)) continue;
            }
            if (viaTitulo && !gkeys.contains(titleKey(it.name))) continue;
            if (rp != null && !rp.matcher(it.name == null ? "" : it.name).find()) continue;
            if (!searchAll && chS.contains(it.url)) continue;
            if (gset == null && !searchAll) {   /* v429: com género escolhido, as categorias e países ocultos não tiram títulos da pesquisa */
                if (ghS.contains(it.group)) continue;
                Boolean hc = ctyH.get(it.group); if (hc == null) { hc = ctyHidden(ctyOfGroup(it.group)); ctyH.put(it.group, hc); }
                if (hc) continue;
            }
            out.add(it); if (out.size() >= 300) break;
        }
        /* v518: títulos do género que estão em categorias ocultas (lidos do disco) */
        if (gset != null && out.size() < 300) for (Item it : genreExtra(only, gen)) {
            if (n.length() >= 2 && !fastNorm(it.name).contains(n)) continue;
            if (useCc && !cc.equals(ctyOfItem(it))) continue;
            if (rp != null && !rp.matcher(it.name == null ? "" : it.name).find()) continue;
            out.add(it); if (out.size() >= 300) break;
        }
        /* v516/v518: «tudo»: junta os títulos das categorias ocultas (lidos do disco), também só com país ou resolução;
           com género, um título de outra categoria conta se o mesmo título está no género (como nas visíveis) */
        if (searchAll && out.size() < 300 && (n.length() >= 2 || useCc || rp != null)) {
            for (Item it : searchHidden(only, n, gp == null ? 300 - out.size() : 5000, useCc ? cc : null, rp)) {
                if (gp != null) { if (gp.matcher(fastNorm(it.group)).find() || gkeys == null || !gkeys.contains(titleKey(it.name))) continue; }
                out.add(it); if (out.size() >= 300) break;
            }
        }
        if (out.isEmpty() && useCc && fast) { int nc = 0; for (String c : cs) if (cc.equals(c)) nc++; StringBuilder pc = new StringBuilder(); int np = 0; List<Cat> cl = cats.get(only); if (cl != null) for (Cat c : cl) if (cc.equals(ctyOfGroup(c.name)) && np++ < 14) pc.append(c.name).append(" (").append(c.items.size()).append(") | "); dbg("sem resultados: " + nc + " itens de «" + cc + "» em " + only + (gset != null ? " (o género tem " + gset.size() + " itens)" : "") + " · categorias do país: " + pc); }
        return out;
    }
    /** v371: nome normalizado do grupo/categoria de cada item, calculado uma vez por lista. */
    private final Map<String, Object[]> gnIdx = new java.util.concurrent.ConcurrentHashMap<>();
    private String[] gnOf(String k) {
        List<Item> l = all.get(k); if (l == null) return null;
        Object[] c = gnIdx.get(k);
        if (c != null && c[0] == l) return (String[]) c[1];
        String[] r = new String[l.size()];
        java.util.IdentityHashMap<String, String> memo = new java.util.IdentityHashMap<>();   /* v475: normaliza cada grupo uma vez (5 mil) e não um por filme (250 mil) */
        for (int i = 0; i < r.length; i++) { String g = l.get(i).group; String v = memo.get(g); if (v == null) { v = fastNorm(g); memo.put(g, v); } r[i] = v; }
        gnIdx.put(k, new Object[]{l, r});
        return r;
    }
    /** v369: país de cada item da lista, calculado uma vez (mesma regra de antes: nome, depois grupo). */
    private final Map<String, Object[]> ctyIdx = new java.util.concurrent.ConcurrentHashMap<>();
    private String[] ctysOf(String k) {
        List<Item> l = all.get(k); if (l == null) return null;
        Object[] c = ctyIdx.get(k);
        if (c != null && c[0] == l) return (String[]) c[1];
        String[] r = new String[l.size()];
        java.util.IdentityHashMap<String, String> memo = new java.util.IdentityHashMap<>();   /* v475: o país do grupo calcula-se uma vez por grupo; o do nome só se tiver pinta de prefixo (sem regex em 250 mil títulos) */
        for (int i = 0; i < r.length; i++) {
            Item it = l.get(i);
            String x = maybePfx(it.name) || hasPortug(it.name) ? ctyOfGroup(it.name) : "";
            if (x.isEmpty() && ptTag(it.name)) x = "PT";   /* v476: títulos com «PT» no nome — (PT), [PT], PT-PT, «… PT» — contam como portugueses */
            if (x.isEmpty()) { String g = it.group, v = memo.get(g); if (v == null) { v = ctyOfGroup(g); if (v.isEmpty() && ptTag(g)) v = "PT"; memo.put(g, v); } x = v; }
            r[i] = x;
        }
        ctyIdx.put(k, new Object[]{l, r});
        return r;
    }
    static String norm(String s) { return java.text.Normalizer.normalize(s == null ? "" : s, java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase(); }

    /* ------------------------------------------------------------ v278: picons de qualidade (tv-logo/tv-logos), como a app antiga fazia para os canais PT */
    private static JSONObject LOGOS;
    private static final String LOGO_BASE = "https://cdn.jsdelivr.net/gh/tv-logo/tv-logos@main/countries/";
    private static final String[][] CTY_DIR = {{"PT", "portugal"}, {"BR", "brazil"}, {"ES", "spain"}, {"FR", "france"}, {"DE", "germany"}, {"IT", "italy"}, {"UK", "united-kingdom"}, {"GB", "united-kingdom"},
            {"US", "united-states"}, {"USA", "united-states"}, {"NL", "netherlands"}, {"BE", "belgium"}, {"PL", "poland"}, {"RO", "romania"}, {"TR", "turkey"}, {"GR", "greece"}, {"AR", "argentina"},
            {"MX", "mexico"}, {"CA", "canada"}, {"IN", "india"}, {"AL", "albania"}, {"AT", "austria"}, {"AU", "australia"}, {"BG", "bulgaria"}, {"CL", "chile"}, {"HR", "croatia"}, {"CZ", "czech-republic"},
            {"HU", "hungary"}, {"IE", "ireland"}, {"IL", "israel"}, {"LT", "lithuania"}, {"LU", "luxembourg"}, {"MT", "malta"}, {"NZ", "new-zealand"}, {"PH", "philippines"}, {"RS", "serbia"}, {"SK", "slovakia"},
            {"SI", "slovenia"}, {"ZA", "south-africa"}, {"CH", "switzerland"}, {"UA", "ukraine"}, {"AE", "united-arab-emirates"}, {"RU", "russia"}, {"AZ", "azerbaijan"}, {"LB", "lebanon"}, {"MY", "malaysia"},
            {"SG", "singapore"}, {"ID", "indonesia"}, {"HK", "hong-kong"}, {"CR", "costa-rica"}, {"SE", "nordic"}, {"NO", "nordic"}, {"DK", "nordic"}, {"FI", "nordic"}};
    private static final String[][] LOGO_ALIAS = {{"rtp3", "rtpnoticias"}, {"hollywood", "canalhollywood"}, {"panda", "canalpanda"}, {"11", "canal11"}, {"globo", "globointernacional"},
            {"q", "canalq"}, {"cnn", "cnnportugal"}, {"foxmovies", "starmovies"}, {"fox", "starchannel"}, {"sportv", "sporttv"}, {"elevensports", "elevensports1"}, {"tvi24", "tvi24"},
            {"benficatv", "btv"}, {"benfica", "btv"}, {"discovery", "discoverychannel"}, {"natgeo", "nationalgeographic"}, {"natgeowild", "nationalgeographicwild"}, {"tvciné", "tvcine"},
            {"sporttvmais", "sporttvmais"}, {"sptv1", "sporttv1"}, {"sptv2", "sporttv2"}, {"sptv3", "sporttv3"}, {"sptv4", "sporttv4"}, {"sptv5", "sporttv5"}, {"sporttv", "sporttv1"}};
    private void loadLogos() {
        if (LOGOS != null) return;
        try (InputStream in = ctx.getAssets().open("ui/logos.json")) { LOGOS = new JSONObject(readAll(in)); } catch (Throwable e) { LOGOS = new JSONObject(); }
    }
    private static final java.util.regex.Pattern PFX = java.util.regex.Pattern.compile("^[^A-Za-z]*([A-Za-z]{2,3})\\s*[|:]");
    static String ctyCode(Item c) {
        for (String t : new String[]{c.group, c.name}) {
            if (t == null) continue;
            java.util.regex.Matcher m = PFX.matcher(t);
            if (m.find()) return m.group(1).toUpperCase();
            if (t.toUpperCase().matches(".*\\b(PORTUGAL|PORTUGU[EÊ]S|PORTUGUESA)\\b.*")) return "PT";
        }
        return "";
    }
    static String logoKey(String n) {
        String s = java.text.Normalizer.normalize(n == null ? "" : n, java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase();
        s = s.replaceFirst("^[^a-z0-9]*[a-z]{2,3}\\s*[|:]+\\s*", "");
        s = s.replaceAll("\\[[^\\]]*\\]|\\([^)]*\\)", " ").replaceAll("[ᴴᴰᵁ⁴ᴷ]", " ");
        s = s.replaceAll("\\b(fhd|uhd|hd|sd|4k|8k|hevc|h265|h264|raw|1080p|720p|1080|720|50fps|60fps|backup|alt|multi|vip)\\b", " ");
        return s.replaceAll("[^a-z0-9+]", "");
    }
    private String logoIn(String dir, String key) {
        JSONObject m = LOGOS.optJSONObject(dir); if (m == null) return null;
        String f = m.optString(key, null);
        if (f == null || f.isEmpty()) return null;
        return LOGO_BASE + dir + "/" + android.net.Uri.encode(f);
    }
    /** Logótipo da tv-logos para um canal (ou null). */
    String logoFor(Item c, String cty) {
        loadLogos();
        String k = logoKey(c.name);
        if (k.length() < 2) return null;
        java.util.LinkedHashSet<String> keys = new java.util.LinkedHashSet<>();
        keys.add(k); keys.add(k.replace("+", "mais")); keys.add(k.replace("+", "plus")); keys.add(k.replace("+", ""));
        String k2 = k.replace("+", "");
        for (String[] a : LOGO_ALIAS) if (a[0].equals(k2)) keys.add(a[1]);
        if (k2.startsWith("canal") && k2.length() > 6) keys.add(k2.substring(5)); else keys.add(Tr.t("canal") + k2);
        if (k2.endsWith("tv") && k2.length() > 4) keys.add(k2.substring(0, k2.length() - 2)); else keys.add(k2 + "tv");
        java.util.LinkedHashSet<String> dirs = new java.util.LinkedHashSet<>();
        for (String[] d : CTY_DIR) if (d[0].equals(cty)) dirs.add(d[1]);
        if (cty.isEmpty() || "PT".equals(cty)) dirs.add("portugal");
        dirs.add("international"); dirs.add("world-europe");
        if ("PT".equals(cty) || cty.isEmpty()) { dirs.add("spain"); dirs.add("united-kingdom"); dirs.add("united-states"); }
        for (String d : dirs) for (String key : keys) { String u = logoIn(d, key); if (u != null) return u; }
        return null;
    }
    /** v279: só conta os logótipos ao carregar (rápido); a troca pelo logótipo do canal é feita quando o cartão aparece (logo()). */
    private final Map<String, Integer> logoCnt = new java.util.concurrent.ConcurrentHashMap<>();
    private void betterLogos(List<Item> live) {
        if (live == null) return;
        loadLogos();   /* índice dos picons já pronto quando os cartões aparecerem */
        logoCnt.clear();
        for (Item c : live) if (c.logo != null && c.logo.length() > 0) { Integer n = logoCnt.get(c.logo); logoCnt.put(c.logo, n == null ? 1 : n + 1); }
    }
    /** Logótipo a mostrar: o do canal (tv-logos) quando o do servidor é genérico, falta ou o canal é PT. */
    String logo(Item c) {
        if (c == null) return "";
        if (c.logoDone || !"live".equals(c.kind) || !sp.getBoolean("betterLogos", true)) return c.logo;
        c.logoDone = true;
        try {
            String cty = ctyCode(c);
            Integer n = c.logo == null || c.logo.isEmpty() ? Integer.valueOf(0) : logoCnt.get(c.logo);
            boolean generic = c.logo == null || c.logo.isEmpty() || (n != null && n >= 3);
            if (generic || "PT".equals(cty)) { String u = logoFor(c, cty); if (u != null) c.logo = u; }
        } catch (Throwable ignored) { }
        return c.logo;
    }

    /* ------------------------------------------------------------ v278: ordenar e ocultar (categorias, canais e países), formato igual ao da app antiga */
    private JSONObject org;
    JSONObject org() { if (org == null) { try { org = new JSONObject(sp.getString("org", "{}")); } catch (Throwable e) { org = new JSONObject(); } } return org; }
    void saveOrg() { sp.edit().putString("org", org().toString()).apply(); visCache.clear(); checkUnhidden(); }
    private static JSONArray arr(JSONObject o, String k) { JSONArray a = o.optJSONArray(k); if (a == null) { a = new JSONArray(); try { o.put(k, a); } catch (Throwable ignored) { } } return a; }
    private JSONArray arr2(String k, String kind) { JSONObject o = org().optJSONObject(k); if (o == null) { o = new JSONObject(); try { org().put(k, o); } catch (Throwable ignored) { } } return arr(o, kind); }
    private static List<String> list(JSONArray a) { List<String> l = new ArrayList<>(); if (a != null) for (int i = 0; i < a.length(); i++) l.add(a.optString(i)); return l; }
    private void put2(String k, String kind, List<String> l) { try { JSONObject o = org().optJSONObject(k); if (o == null) { o = new JSONObject(); org().put(k, o); } o.put(kind, new JSONArray(l)); } catch (Throwable ignored) { } }
    private JSONObject cty;
    JSONObject cty() { if (cty == null) { try { cty = new JSONObject(sp.getString("cty", "{}")); } catch (Throwable e) { cty = new JSONObject(); } arr(cty, "order"); arr(cty, "hide"); } return cty; }
    void saveCty() { sp.edit().putString("cty", cty().toString()).apply(); visCache.clear(); checkUnhidden(); }
    void importOrg(String orgJson, String ctyJson) {
        try { if (orgJson != null && orgJson.length() > 2) { org = new JSONObject(orgJson); saveOrg(); } } catch (Throwable ignored) { }
        try { if (ctyJson != null && ctyJson.length() > 2) { cty = new JSONObject(ctyJson); arr(cty, "order"); arr(cty, "hide"); saveCty(); } } catch (Throwable ignored) { }
    }
    private static final java.util.regex.Pattern PT_WORD = java.util.regex.Pattern.compile(".*\\b(PORTUGAL|PORTUGU[EÊ]S|PORTUGUESA)\\b.*");
    private static final java.util.regex.Pattern GPFX =java.util.regex.Pattern.compile("^[^A-Za-zÀ-ÿ]*([A-Za-z]{2,3})\\s*(?:\\||:|-|–|—|\\]|\\))");
    /** v431: nome para mostrar no ecrã, sem o país do início (|PT|, |FR|…). Os dados e a pesquisa continuam a usar o nome completo. */
    static String shownName(String n) {
        if (n == null) return "";
        return n.replaceFirst("^\\s*(\\|[A-Za-z]{2,3}\\|\\s*)+", "");
    }
    /** País de uma categoria pelo prefixo (|PT|, FR:, UK | …); "" sem país. */
    /** v475: pré-filtro exato do padrão GPFX (2 ou 3 letras iniciais seguidas de | : - – — ] )): evita o regex quase sempre. */
    static boolean maybePfx(String s) {
        if (s == null) return false;
        int n = s.length(), i = 0;
        while (i < n) { char c = s.charAt(i); if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') || (c >= 0xC0 && c <= 0xFF)) break; i++; }
        if (i >= n) return false;
        int a = i; while (i < n) { char c = s.charAt(i); if ((c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z')) i++; else break; }
        int len = i - a; if (len < 2 || len > 3) return false;
        while (i < n && Character.isWhitespace(s.charAt(i))) i++;
        if (i >= n) return false;
        char d = s.charAt(i); return d == '|' || d == ':' || d == '-' || d == '\u2013' || d == '\u2014' || d == ']' || d == ')';
    }
    /** v477: chave do título sem prefixo de país, ano, qualidade nem marcas (PT), [4K]…: o mesmo filme em categorias diferentes dá a mesma chave. */
    static String titleKey(String name) {
        if (name == null) return "";
        String t = fastNorm(name);
        t = t.replaceAll("\\[[^\\]]*\\]|\\([^)]*\\)", " ");
        t = t.replaceFirst("^[^a-z0-9]*[a-z]{2,3}\\s*[|:]+\\s*", "");
        t = t.replaceAll("\\b(19|20)\\d\\d\\b", " ");
        t = t.replaceAll("\\b(pt|pt-pt|br|dublado|legendado|multi|4k|uhd|fhd|hd|sd|hevc|h265|1080p|720p|2160p|dual|audio)\\b", " ");
        return t.replaceAll("[^a-z0-9]", "");
    }
    /** v477: títulos (chaves) dos itens de um género; cache por tipo e género. */
    private final Map<String, Object[]> genKeysCache = new java.util.concurrent.ConcurrentHashMap<>();
    @SuppressWarnings("unchecked")
    private java.util.Set<String> genreKeys(String kind, String gen, java.util.Set<Item> gset) {
        String key = kind + "|" + gen.trim();
        Object[] ce = genKeysCache.get(key);
        if (ce != null && ce[0] == gset) return (java.util.Set<String>) ce[1];
        java.util.HashSet<String> ks = new java.util.HashSet<>(gset.size() * 2);
        for (Item it : gset) { String k = titleKey(it.name); if (k.length() >= 3) ks.add(k); }
        genKeysCache.put(key, new Object[]{gset, ks});
        return ks;
    }
    /** v476: o texto tem «PT» como palavra solta (não PT-BR / PT BR, que é português do Brasil). */
    static boolean ptTag(String s) {
        if (s == null) return false;
        for (int i = 0, n = s.length() - 1; i < n; i++) {
            if (s.charAt(i) != 'P' || s.charAt(i + 1) != 'T') continue;
            if (i > 0 && Character.isLetterOrDigit(s.charAt(i - 1))) continue;
            int e = i + 2; if (e < s.length() && Character.isLetterOrDigit(s.charAt(e))) continue;
            int j = e; while (j < s.length() && (s.charAt(j) == '-' || s.charAt(j) == '_' || s.charAt(j) == ' ')) j++;
            if (j + 1 < s.length() && s.charAt(j) == 'B' && s.charAt(j + 1) == 'R' && (j + 2 >= s.length() || !Character.isLetterOrDigit(s.charAt(j + 2)))) continue;
            return true;
        }
        return false;
    }
    /** v475: contém «PORTUG» (sem distinguir maiúsculas)? Pré-filtro do padrão PT_WORD. */
    static boolean hasPortug(String s) { if (s == null) return false; for (int i = 0, n = s.length() - 5; i < n; i++) { char c = s.charAt(i); if ((c == 'p' || c == 'P') && s.regionMatches(true, i, "portug", 0, 6)) return true; } return false; }
    static String ctyOfGroup(String g) {
        if (g == null) return "";
        java.util.regex.Matcher m = GPFX.matcher(g);
        if (m.find()) { String c = m.group(1).toUpperCase(); return "GB".equals(c) ? "UK" : c.intern(); }
        if (PT_WORD.matcher(g.toUpperCase()).matches()) return "PT";
        return "";
    }
    private static boolean isPtGroup(String n) { return n != null && n.matches("(?is)^[\\s\\W_]*(PT|PORTUGAL|PORTUGUES)(?![A-Za-zÀ-ÿ]).*"); }
    int ctyRank(String code) { int i = list(cty().optJSONArray("order")).indexOf(code); return i >= 0 ? i : ("PT".equals(code) ? -1 : 1000); }
    boolean ctyHidden(String code) { return !code.isEmpty() && list(cty().optJSONArray("hide")).contains(code); }
    private java.util.Set<String> chHideSet = null;
    boolean hiddenItem(Item it) {
        if (it == null) return false;
        if (chHideSet == null) chHideSet = new java.util.HashSet<>(list(org().optJSONArray("chHide")));
        if (chHideSet.contains(it.url)) return true;
        String k = "episode".equals(it.kind) ? "series" : it.kind;
        if (list(arr2("grpHide", k)).contains(it.group)) return true;
        return ctyHidden(ctyOfGroup(it.group));
    }
    private final Map<String, List<Cat>> visCache = new HashMap<>();
    /** Categorias pela ordem escolhida (países, depois a tua ordem, depois as PT), sem as ocultas e sem os canais ocultos. */
    /** v315: Explorar, Guia e Pesquisa usam a ordem normal (países e ordem do servidor); a ordem escolhida por ti só vale no Início. */
    synchronized List<Cat> visibleCats(String kind) { return visCats(kind, false); }
    /** Grupos visíveis pela ordem definida nas Definições (só para o Início). */
    synchronized List<Cat> homeCats(String kind) { return visCats(kind, true); }
    private synchronized List<Cat> visCats(String kind, boolean custom) {
        List<Cat> base = cats.get(kind);
        if (base == null) return null;
        String ck = kind + "|" + System.identityHashCode(base) + "|" + custom;
        List<Cat> cached = visCache.get(ck);
        if (cached != null) return cached;
        final List<String> ord = custom ? list(arr2("grp", kind)) : new ArrayList<String>();
        java.util.Set<String> gh = new java.util.HashSet<>(list(arr2("grpHide", kind)));
        java.util.Set<String> ch = new java.util.HashSet<>(list(org().optJSONArray("chHide")));
        List<Cat> l = new ArrayList<>();
        for (Cat c : base) {
            if (gh.contains(c.name) || ctyHidden(ctyOfGroup(c.name))) continue;
            Cat x = c;
            if (!ch.isEmpty()) {
                boolean any = false; for (Item it : c.items) if (ch.contains(it.url)) { any = true; break; }
                if (any) { x = new Cat(); x.id = c.id; x.name = c.name; for (Item it : c.items) if (!ch.contains(it.url)) x.items.add(it); }
            }
            l.add(x);
        }
        final Map<String, Long> key = new HashMap<>();
        for (Cat c : l) { int i = ord.indexOf(c.name); long gi = i >= 0 ? i : (isPtGroup(c.name) ? -1 : 1000000); key.put(c.name, ctyRank(ctyOfGroup(c.name)) * 10000000L + gi); }
        java.util.Collections.sort(l, (a, b) -> Long.compare(key.get(a.name), key.get(b.name)));   /* estável: a ordem do servidor fica entre iguais */
        visCache.put(ck, l);
        return l;
    }
    /* v330: géneros de filmes e séries (Ação, Comédia, Terror, Drama…). O fornecedor só dá categorias (não género por título): agrupa as categorias cujo nome indica o género. */
    private static final String[][] GEN = {
        {"acao", "💥 Ação", "acao|\\baction|accion|azione|actie|akcj|aksiyon"}, {"comedia", "😂 Comédia", "comedia|comedy|comedie|commedia|komedi|komodi|humor|humour|\\bcomique"}, {"terror", "👻 Terror", "terror|horror|horreur|orrore|korku|\\bmedo\\b"}, {"drama", "🎭 Drama", "drama"},
        {"romance", "💕 Romance", "romanc|romant|amour|liebe|\\bamor\\b|amore"}, {"ficcao", "🚀 Ficção científica", "ficcao|ficcion|sci-?fi|science.?fiction|fantascienza|cienc.?ficcion|science.?fiktion"}, {"thriller", "🔪 Thriller", "thriller|suspense|suspens|misterio|mystery|mistero"}, {"crime", "🕵️ Crime", "\\bcrime|policia|polic|policier|gangster|krimi|poliz"},
        {"animacao", "🧸 Animação", "animac|animad|cartoon|desenhos|animation|\\banime\\b|dessin|zeichentrick|cartoni"}, {"aventura", "🧭 Aventura", "aventura|adventure|aventure|abenteuer|avventura"}, {"fantasia", "🧙 Fantasia", "fantasi|fantasy|fantastique"}, {"doc", "🎥 Documentários", "document|dokument|documental|documentaire"},
        {"familia", "👨\u200d👩\u200d👧 Família", "familia|family|famille|famiglia|familie|infantil|\\bkids\\b|crianca|enfant|bambin|kinder|children"}, {"guerra", "🪖 Guerra", "\\bguerra|\\bwar\\b|guerre|krieg"}, {"western", "🤠 Western", "western|faroeste|\\bwestern"}
    };
    private static final java.util.regex.Pattern[] GENP = new java.util.regex.Pattern[GEN.length];
    static { for (int i = 0; i < GEN.length; i++) GENP[i] = java.util.regex.Pattern.compile(GEN[i][2]); }
    private final Map<String, Object[]> genCache = new HashMap<>();
    /** Uma categoria virtual por género (só com 6 ou mais títulos), com as categorias portuguesas primeiro; vazio nos canais. */
    synchronized List<Cat> genreCats(String kind) {
        List<Cat> out = new ArrayList<>();
        if (kind == null || "live".equals(kind)) return out;
        List<Cat> vis = visCats(kind, false);
        if (vis == null) return out;
        Object[] ce = genCache.get(kind);
        if (ce != null && ce[0] == vis) { @SuppressWarnings("unchecked") List<Cat> c0 = (List<Cat>) ce[1]; return c0; }
        List<Cat> ord = new ArrayList<>();
        for (Cat c : vis) if (isPtGroup(c.name)) ord.add(c);
        for (Cat c : vis) if (!isPtGroup(c.name)) ord.add(c);
        Cat[] g = new Cat[GEN.length];
        @SuppressWarnings("unchecked") java.util.Set<Item>[] seen = new java.util.Set[GEN.length];
        for (Cat c : ord) {
            String n = java.text.Normalizer.normalize(c.name == null ? "" : c.name, java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase(java.util.Locale.ROOT);
            for (int i = 0; i < GEN.length; i++) {
                if (!GENP[i].matcher(n).find()) continue;
                if (g[i] == null) { g[i] = new Cat(); g[i].id = "__g_" + GEN[i][0]; g[i].name = GEN[i][1]; seen[i] = java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<Item, Boolean>()); }
                for (Item it : c.items) if (seen[i].add(it)) g[i].items.add(it);
            }
        }
        for (int i = 0; i < GEN.length; i++) if (g[i] != null && g[i].items.size() >= 6) out.add(g[i]);
        genCache.put(kind, new Object[]{vis, out});
        return out;
    }
    /** v425: itens de um género pelo mesmo critério das categorias de género: a categoria (visível) cujo nome corresponde,
     *  ou o grupo do próprio item. Cache por tipo, género e lista. */
    private final Map<String, Object[]> genItemsCache = new java.util.concurrent.ConcurrentHashMap<>();
    @SuppressWarnings("unchecked")
    List<Item> genreExtra(String kind, String gen) { Object[] ce = genItemsCache.get(kind + "|" + gen.trim()); return ce != null && ce.length > 3 ? (List<Item>) ce[3] : new ArrayList<Item>(); }
    @SuppressWarnings("unchecked")
    java.util.Set<Item> genreItems(String kind, String gen) {
        java.util.regex.Pattern p = genrePattern(gen);
        List<Item> all0 = all.get(kind);
        /* v429: o género usa todas as categorias (também as ocultas): ocultar uma categoria não tira os seus títulos da pesquisa por género */
        List<Cat> todas = cats.get(kind);
        if (p == null || all0 == null || todas == null) return null;
        String key = kind + "|" + gen.trim();
        Object[] ce = genItemsCache.get(key);
        if (ce != null && ce[1] == all0) return (java.util.Set<Item>) ce[2];
        java.util.Set<Item> s = java.util.Collections.newSetFromMap(new java.util.IdentityHashMap<Item, Boolean>());
        int hits = 0; StringBuilder ex = new StringBuilder();
        for (Cat c : todas) if (p.matcher(fastNorm(c.name)).find()) { s.addAll(c.items); hits++; if (hits <= 8) ex.append(c.name).append(" (").append(c.size()).append(") | "); }
        /* v518: desde a v510 as categorias ocultas não estão na memória: as do género lêem-se do disco (só essas) */
        List<Item> extra = readHiddenCats(kind, p); s.addAll(extra);
        dbg("género «" + gen + "» em " + kind + ": " + hits + " categorias, " + s.size() + " itens (" + extra.size() + " lidos do disco, de categorias ocultas)" + (hits > 0 ? " · " + ex : " · sem categoria com esse nome"));
        genItemsCache.put(key, new Object[]{todas, all0, s, extra});
        return s;
    }
    private void changed() { saveOrg(); chHideSet = null; genItemsCache.clear(); }
    void hideCat(String kind, String name) { List<String> h = list(arr2("grpHide", kind)); if (!h.contains(name)) h.add(name); put2("grpHide", kind, h); changed(); }
    void showCat(String kind, String name) { List<String> h = list(arr2("grpHide", kind)); h.remove(name); put2("grpHide", kind, h); changed(); }
    void hideItem(String url) { List<String> h = list(org().optJSONArray("chHide")); if (!h.contains(url)) h.add(url); try { org().put("chHide", new JSONArray(h)); } catch (Throwable ignored) { } changed(); }
    void showAllItems() { try { org().put("chHide", new JSONArray()); } catch (Throwable ignored) { } changed(); }
    void showAllCats() { try { org().put("grpHide", new JSONObject()); } catch (Throwable ignored) { } changed(); }
    int hiddenItemsCount() { return list(org().optJSONArray("chHide")).size(); }
    List<String[]> hiddenCats() { List<String[]> out = new ArrayList<>(); for (String k : new String[]{"live", "movie", "series"}) for (String n : list(arr2("grpHide", k))) out.add(new String[]{k, n}); return out; }
    /** Muda a posição de uma categoria (delta −1/+1, ou Integer.MIN_VALUE = para o topo); grava a ordem atual toda. */
    void moveCat(String kind, String name, int delta) {
        List<Cat> v = homeCats(kind); if (v == null) return;
        List<String> names = new ArrayList<>(); for (Cat c : v) names.add(c.name);
        int i = names.indexOf(name); if (i < 0) return;
        names.remove(i);
        int j = delta == Integer.MIN_VALUE ? 0 : Math.max(0, Math.min(names.size(), i + delta));
        names.add(j, name);
        for (String o : list(arr2("grp", kind))) if (!names.contains(o)) names.add(o);   /* mantém as posições das ocultas */
        put2("grp", kind, names); changed();
    }
    /** v311: todos os grupos do tipo para o ecrã de gestão: primeiro os visíveis (pela ordem do Início), depois os ocultos. {nome, "1" se oculto, nº de itens} */
    List<String[]> groupRows(String kind) {
        List<String[]> out = new ArrayList<>();
        List<Cat> base = cats.get(kind); if (base == null) return out;
        List<Cat> vis = homeCats(kind);
        java.util.Set<String> seen = new java.util.HashSet<>();
        if (vis != null) for (Cat c : vis) { out.add(new String[]{c.name, "0", String.valueOf(c.size())}); seen.add(c.name); }
        java.util.Set<String> gh = new java.util.HashSet<>(list(arr2("grpHide", kind)));
        for (Cat c : base) if (!seen.contains(c.name) && gh.contains(c.name) && !ctyHidden(ctyOfGroup(c.name))) { out.add(new String[]{c.name, "1", String.valueOf(c.size())}); seen.add(c.name); }
        return out;
    }
    void hideAllGroups(String kind) { List<Cat> base = cats.get(kind); if (base == null) return; List<String> h = new ArrayList<>(); for (Cat c : base) if (!h.contains(c.name)) h.add(c.name); put2("grpHide", kind, h); changed(); }
    void showAllGroups(String kind) { put2("grpHide", kind, new ArrayList<String>()); changed(); }
    /** Há ordem ou ocultos definidos para o tipo: o Início mostra exatamente os grupos visíveis, pela ordem definida. */
    boolean customHome(String kind) { return !list(arr2("grpHide", kind)).isEmpty() || !list(arr2("grp", kind)).isEmpty(); }
    /** v314: põe o grupo numa posição precisa (1 = primeiro) da lista visível. */
    void moveCatTo(String kind, String name, int pos1) {
        List<Cat> v = homeCats(kind); if (v == null) return;
        List<String> names = new ArrayList<>(); for (Cat c : v) names.add(c.name);
        int i = names.indexOf(name); if (i < 0) return;
        names.remove(i);
        names.add(Math.max(0, Math.min(names.size(), pos1 - 1)), name);
        for (String o : list(arr2("grp", kind))) if (!names.contains(o)) names.add(o);
        put2("grp", kind, names); changed();
    }
    void resetOrder() { try { org().put("grp", new JSONObject()); } catch (Throwable ignored) { } changed(); }
    /** Países presentes nas categorias (código, nº de categorias), pela ordem atual. */
    List<String[]> countries() {
        final Map<String, Integer> n = new HashMap<>();
        for (String k : new String[]{"live", "movie", "series"}) { List<Cat> l = cats.get(k); if (l == null) continue; for (Cat c : l) { String x = ctyOfGroup(c.name); if (x.isEmpty()) continue; Integer v = n.get(x); n.put(x, v == null ? 1 : v + 1); } }
        List<String> codes = new ArrayList<>(n.keySet());
        java.util.Collections.sort(codes, (a, b) -> ctyRank(a) != ctyRank(b) ? Integer.compare(ctyRank(a), ctyRank(b)) : Integer.compare(n.get(b), n.get(a)));
        List<String[]> out = new ArrayList<>(); for (String c : codes) out.add(new String[]{c, String.valueOf(n.get(c))});
        return out;
    }
    void moveCty(String code, int delta) {
        List<String> codes = new ArrayList<>(); for (String[] x : countries()) codes.add(x[0]);
        int i = codes.indexOf(code); if (i < 0) return;
        codes.remove(i); codes.add(Math.max(0, Math.min(codes.size(), i + delta)), code);
        try { cty().put("order", new JSONArray(codes)); } catch (Throwable ignored) { } saveCty();
    }
    /** v319: mostrar um país volta a mostrar os grupos dele (os que tinham sido ocultos um a um ou com «Ocultar todos»). */
    private void unhideGroupsOf(String code) {
        for (String k : new String[]{"live", "movie", "series"}) {
            List<String> h = list(arr2("grpHide", k)); boolean ch = false;
            for (java.util.Iterator<String> it = h.iterator(); it.hasNext();) if (code.equals(ctyOfGroup(it.next()))) { it.remove(); ch = true; }
            if (ch) put2("grpHide", k, h);
        }
        saveOrg();
    }
    void toggleCty(String code) {
        List<String> h = list(cty().optJSONArray("hide")); if (h.contains(code)) { h.remove(code); unhideGroupsOf(code); } else h.add(code);
        try { cty().put("hide", new JSONArray(h)); } catch (Throwable ignored) { } saveCty();
    }
    void hideAllCountries() { List<String> codes = new ArrayList<>(); for (String[] x : countries()) codes.add(x[0]); try { cty().put("hide", new JSONArray(codes)); } catch (Throwable ignored) { } saveCty(); }
    void showAllCountries() { for (String c : list(cty().optJSONArray("hide"))) unhideGroupsOf(c); try { cty().put("hide", new JSONArray()); } catch (Throwable ignored) { } saveCty(); }
    boolean ctyIsHidden(String code) { return ctyHidden(code); }
    void resetCty() { cty = new JSONObject(); arr(cty, "order"); arr(cty, "hide"); saveCty(); }
}
