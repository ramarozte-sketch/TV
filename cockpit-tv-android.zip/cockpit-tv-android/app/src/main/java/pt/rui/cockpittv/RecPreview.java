package pt.rui.cockpittv;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Outline;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.TextureView;
import android.view.View;
import android.view.ViewOutlineProvider;
import android.widget.FrameLayout;
import android.widget.ImageView;

import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.exoplayer.ExoPlayer;

import java.io.File;
import java.io.FileOutputStream;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Miniaturas das gravações e pré-visualização sem som no ecrã das Gravações. */
final class RecPreview {
    private RecPreview() { }

    private static final LruCache<String, Bitmap> MEM = new LruCache<String, Bitmap>(12 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };
    private static final ExecutorService EXEC = Executors.newSingleThreadExecutor();
    private static final Handler UI = new Handler(Looper.getMainLooper());

    interface Got { void on(Bitmap b); }

    static Uri uriOf(Recorder.Rec r) {
        if (r.file == null || r.file.isEmpty()) return null;
        if (r.file.startsWith("content:") || r.file.startsWith("file:")) return Uri.parse(r.file);
        return Uri.fromFile(new File(r.file));
    }

    /** Miniatura (a meio do programa). Fica em cache no aparelho; nas gravações a decorrer é renovada a cada 3 min. */
    static void thumb(final Context c, final Recorder.Rec r, final Got cb) {
        if (r == null || r.file == null || r.file.isEmpty() || !("done".equals(r.st) || "rec".equals(r.st))) { cb.on(null); return; }
        final boolean live = "rec".equals(r.st);
        final String key = r.id + (live ? "_" + (System.currentTimeMillis() / 180_000L) : "");
        Bitmap m = MEM.get(key);
        if (m != null) { cb.on(m); return; }
        final Context app = c.getApplicationContext();
        EXEC.execute(() -> {
            Bitmap b = null;
            File dir = new File(app.getCacheDir(), "recthumb"); dir.mkdirs();
            File f = new File(dir, r.id + ".jpg");
            try {
                if (f.exists() && (!live || System.currentTimeMillis() - f.lastModified() < 180_000L)) b = BitmapFactory.decodeFile(f.getAbsolutePath());
            } catch (Throwable ignored) { }
            if (b == null) {
                MediaMetadataRetriever mr = new MediaMetadataRetriever();
                try {
                    Uri u = uriOf(r);
                    if ("file".equals(u.getScheme())) mr.setDataSource(u.getPath()); else mr.setDataSource(app, u);
                    long durMs = 0;
                    try { durMs = Long.parseLong(mr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)); } catch (Throwable ignored) { }
                    if (durMs <= 0) durMs = live ? Math.max(0, System.currentTimeMillis() - (r.start - r.pre)) : (r.end + r.post) - (r.start - r.pre);
                    long at = Math.max(5_000L, live ? durMs - 20_000L : Math.min(durMs * 2 / 5, r.pre + 10 * 60_000L));
                    if (durMs > 0 && at > durMs) at = durMs / 2;
                    Bitmap fr = mr.getFrameAtTime(at * 1000L, MediaMetadataRetriever.OPTION_CLOSEST_SYNC);
                    if (fr == null) fr = mr.getFrameAtTime();
                    if (fr != null) {
                        int w = 384, h = Math.max(1, Math.round(w * fr.getHeight() / (float) fr.getWidth()));
                        b = Bitmap.createScaledBitmap(fr, w, h, true);
                        if (b != fr) fr.recycle();
                        try (FileOutputStream o = new FileOutputStream(f)) { b.compress(Bitmap.CompressFormat.JPEG, 82, o); }
                    }
                } catch (Throwable e) { NativeData.dbg("gravações: miniatura de «" + r.title + "» falhou: " + e); }
                finally { try { mr.release(); } catch (Throwable ignored) { } }
            }
            final Bitmap fb = b;
            if (fb != null) MEM.put(key, fb);
            UI.post(() -> cb.on(fb));
        });
    }
    static void forget(Context c, String id) { try { new File(new File(c.getCacheDir(), "recthumb"), id + ".jpg").delete(); } catch (Throwable ignored) { } }

    /** Janela de pré-visualização: imagem fixa (miniatura) e, ao fim de um momento, o vídeo sem som. */
    static final class Mini {
        final FrameLayout box; final ImageView img; final TextureView tv;
        private ExoPlayer pl; private String curId = "";
        private final Context ctx;

        Mini(Context c, float radiusPx) {
            ctx = c;
            box = new FrameLayout(c); box.setBackgroundColor(0xFF000000);
            box.setOutlineProvider(new ViewOutlineProvider() { @Override public void getOutline(View v, Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), radiusPx); } });
            box.setClipToOutline(true);
            tv = new TextureView(c); tv.setAlpha(0f);
            box.addView(tv, new FrameLayout.LayoutParams(-1, -1));
            img = new ImageView(c); img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            box.addView(img, new FrameLayout.LayoutParams(-1, -1));
        }
        /** Mostra a miniatura e prepara a gravação. */
        void show(Recorder.Rec r) {
            if (r == null) { stop(); img.setImageBitmap(null); return; }
            if (r.id.equals(curId)) return;
            stop(); curId = r.id;
            img.setImageBitmap(null); img.setAlpha(1f);
            final String id = r.id;
            thumb(ctx, r, b -> { if (id.equals(curId) && b != null) img.setImageBitmap(b); });
        }
        /** Começa o vídeo sem som (a uns 2 minutos do início real do programa). */
        void play(Recorder.Rec r) {
            if (r == null || !r.id.equals(curId) || pl != null) return;
            Uri u = uriOf(r); if (u == null) return;
            try {
                pl = new ExoPlayer.Builder(ctx).build();
                pl.setVolume(0f);
                pl.setVideoTextureView(tv);
                pl.setRepeatMode(Player.REPEAT_MODE_ONE);
                final long skip = Math.max(0, r.pre) + 120_000L;
                final boolean[] sought = {false};
                pl.addListener(new Player.Listener() {
                    @Override public void onPlaybackStateChanged(int s) {
                        if (s == Player.STATE_READY && !sought[0] && pl != null) {
                            sought[0] = true;
                            long d = pl.getDuration();
                            if (pl.isCurrentMediaItemSeekable() && d > 0 && d > skip + 30_000L && !"rec".equals(r.st)) pl.seekTo(skip);
                        }
                    }
                    @Override public void onRenderedFirstFrame() { tv.animate().alpha(1f).setDuration(250).start(); img.animate().alpha(0f).setDuration(250).start(); }
                    @Override public void onPlayerError(androidx.media3.common.PlaybackException e) { NativeData.dbg("gravações: pré-visualização falhou: " + e.getErrorCodeName()); stop(); }
                });
                pl.setMediaItem(MediaItem.fromUri(u));
                pl.prepare(); pl.play();
            } catch (Throwable e) { NativeData.dbg("gravações: pré-visualização: " + e); stop(); }
        }
        void stop() {
            if (pl != null) { try { pl.release(); } catch (Throwable ignored) { } pl = null; }
            tv.animate().cancel(); tv.setAlpha(0f); img.animate().cancel(); img.setAlpha(1f);
        }
        void release() { stop(); curId = ""; }
    }
}
