package pt.rui.cockpittv;

import android.animation.ValueAnimator;
import android.content.Context;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Shader;
import android.graphics.Typeface;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;

/** Barra vertical moderna para volume/brilho: vidro escuro, preenchimento em gradiente que desliza, ícone e percentagem. */
class GestHud extends View {
    private final Paint bg = new Paint(Paint.ANTI_ALIAS_FLAG), stroke = new Paint(Paint.ANTI_ALIAS_FLAG),
            fill = new Paint(Paint.ANTI_ALIAS_FLAG), txt = new Paint(Paint.ANTI_ALIAS_FLAG), ico = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF r = new RectF();
    private final Path clip = new Path();
    private float level = 0f, shown = 0f;
    private String icon = "🔊";
    private ValueAnimator va;
    private float shH = -1f;
    private final float d;
    private final Runnable hide = () -> animate().alpha(0f).scaleX(0.9f).scaleY(0.9f).setDuration(220).withEndAction(() -> setVisibility(GONE)).start();

    GestHud(Context c) {
        super(c);
        d = c.getResources().getDisplayMetrics().density;
        bg.setColor(0xC0101A2B);
        stroke.setStyle(Paint.Style.STROKE); stroke.setStrokeWidth(1.2f * d); stroke.setColor(0x40FFFFFF);
        txt.setColor(0xFFFFFFFF); txt.setTextAlign(Paint.Align.CENTER); txt.setTextSize(15f * d); txt.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
        ico.setTextAlign(Paint.Align.CENTER); ico.setTextSize(24f * d);
        setVisibility(GONE);
    }

    /** level 0..1; icon emoji; mostra com animação e some sozinho. */
    void show(float lv, String ic) {
        icon = ic; level = Math.max(0f, Math.min(1f, lv));
        removeCallbacks(hide);
        if (getVisibility() != VISIBLE) {
            shown = level;
            setAlpha(0f); setScaleX(0.88f); setScaleY(0.88f); setVisibility(VISIBLE);
            animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(260).setInterpolator(new OvershootInterpolator(1.4f)).start();
        } else {
            animate().cancel(); setAlpha(1f); setScaleX(1f); setScaleY(1f);
        }
        /* v268: durante o gesto a barra acompanha o dedo logo (sem animação de 140 ms a cada movimento, que a deixava atrás) */
        if (va != null) va.cancel();
        shown = level; invalidate();
        postDelayed(hide, 1100);
    }

    @Override protected void onDraw(Canvas c) {
        float w = getWidth(), h = getHeight(), rad = w / 2f;
        r.set(1f, 1f, w - 1f, h - 1f);
        c.drawRoundRect(r, rad, rad, bg);
        clip.reset(); clip.addRoundRect(r, rad, rad, Path.Direction.CW);
        c.save(); c.clipPath(clip);
        float top = h - (h * shown);
        if (shH != h) { shH = h; fill.setShader(new LinearGradient(0, h, 0, 0, 0xFF2F7DD1, 0xFFA6D8FF, Shader.TileMode.CLAMP)); }
        c.drawRect(0, top, w, h, fill);
        c.restore();
        c.drawRoundRect(r, rad, rad, stroke);
        /* percentagem no topo, ícone em baixo; sombra suave para ler sobre o preenchimento */
        txt.setShadowLayer(3f * d, 0, 1f * d, 0x99000000);
        c.drawText(Math.round(shown * 100) + "%", w / 2f, 30f * d, txt);
        c.drawText(icon, w / 2f, h - 18f * d, ico);
    }
}
