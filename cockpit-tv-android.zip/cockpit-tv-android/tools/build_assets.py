#!/usr/bin/env python3
"""Gera app/src/main/assets/index.html (só IPTV) a partir do index.html do Cockpit.
Uso: python3 tools/build_assets.py [caminho/para/cockpit/index.html]"""
import sys, os
src = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), "..", "..", "cockpit", "index.html")
out = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "index.html")
h = open(src, encoding="utf-8").read()

def rep(old, new, count=1):
    global h
    if h.count(old) != count:
        sys.exit("Não encontrei (ou há repetições) de: " + old[:70])
    h = h.replace(old, new)

rep('$("tvList").querySelectorAll("[data-ep]").forEach(bt=>bt.onclick=()=>playChannel(eps[+bt.dataset.ep]));', 'window.EPL = {list:eps, series:c}; $("tvList").querySelectorAll("[data-ep]").forEach(bt=>bt.onclick=()=>playChannel(eps[+bt.dataset.ep]));')
rep('function applyLang(){ document.documentElement.lang = {pt:"pt-PT", en:"en", fr:"fr"}[uiLang()]; trTree(document.body); }', 'function applyLang(){ document.documentElement.lang = {pt:"pt-PT", en:"en", fr:"fr"}[uiLang()]; if(uiLang() !== "pt") window.__trUsed = true; else if(!window.__trUsed) return; trTree(document.body); }')
rep("const TOTAL = 4000,", "const TOTAL = 2200,")   # TV: arranque mais curto (a TV é lenta e a animação atrasava o uso)
rep('const isPtGroup = n => /^[\\s\\W_]*(PT|PORTUGAL|PORTUGUES)(?![A-Za-zÀ-ÿ])/i.test(String(n || ""));', 'const PTRE = /^[\\s\\W_]*(PT|PORTUGAL|PORTUGUES)(?![A-Za-zÀ-ÿ])/i, PTC = new Map(); const isPtGroup = n => { n = String(n || ""); let r = PTC.get(n); if(r === undefined){ r = PTRE.test(n); if(PTC.size < 4000) PTC.set(n, r); } return r; };')
rep("<head>", '<head>\n<script>window.ANDROID = (typeof Android !== "undefined"); window.__pxMode = function(){ try{ return localStorage.getItem("tvPxMode") || "off"; }catch(e){ return "off"; } }; try{ window.__lt = []; new PerformanceObserver(function(l){ l.getEntries().forEach(function(e){ window.__lt.push([e.startTime, e.duration]); }); }).observe({entryTypes:["longtask"]}); setTimeout(function(){ try{ var t = 0, last = 0; window.__lt.forEach(function(x){ t += x[1]; last = x[0] + x[1]; }); var big = window.__lt.slice().sort(function(a,b){ return b[1]-a[1]; }).slice(0, 4).map(function(x){ return Math.round(x[0]) + "+" + Math.round(x[1]); }).join(" "); Android.nlogjs("arranque: " + window.__lt.length + " tarefas longas, " + Math.round(t) + " ms no total, a última acaba aos " + Math.round(last) + " ms; maiores (início+duração): " + big); }catch(e){} }, 20000); }catch(e){}</script>')
CTY = r"""<script>(function(){
  const MAP = {PORTUGAL:"PT",PORTUGUES:"PT",PORTUGUESA:"PT",SPAIN:"ES",ESPANA:"ES",ESPANHA:"ES",BRASIL:"BR",BRAZIL:"BR",FRANCE:"FR",FRANCA:"FR",ITALY:"IT",ITALIA:"IT",GERMANY:"DE",DEUTSCHLAND:"DE",ALEMANHA:"DE",ENGLAND:"GB",ANGOLA:"AO",MOCAMBIQUE:"MZ",CANADA:"CA",NETHERLANDS:"NL",HOLLAND:"NL",TURKEY:"TR",TURKIYE:"TR",ARABIC:"AR",ARAB:"AR"};
  const FIX = {UK:"GB", EL:"GR"};
  const KNOWN = {PT:1,ES:1,BR:1,FR:1,GB:1,UK:1,US:1,NL:1,AO:1,MZ:1,TR:1,MX:1,CV:1};   /* só códigos que não se confundem com palavras («DE», «IN», «IT», «NO»…) */
  let st = null;
  const load = () => { try{ st = JSON.parse(localStorage.getItem("ck_tvCty") || "{}") || {}; }catch(e){ st = {}; } st.order = st.order || []; st.hide = st.hide || []; return st; };
  const state = () => st || load();
  const CCACHE = new Map();
  const ctyOf = g => { g = String(g || ""); let r = CCACHE.get(g); if(r === undefined){ r = ctyOf0(g); if(CCACHE.size < 4000) CCACHE.set(g, r); } return r; };   /* memoriza: a mesma categoria repete-se milhares de vezes */
  const ctyOf0 = g => {
    let m = /^[^A-Za-zÀ-ÿ]*([A-Za-z]{2,3})\s*(?:\||:|-|–|—|\]|\))/.exec(g);
    if(m){ const c = m[1].toUpperCase(); return FIX[c] || c; }
    m = /^[^A-Za-zÀ-ÿ]*([A-Za-zÀ-ÿ]{4,})/.exec(g);
    if(m){ const w = m[1].toUpperCase().normalize("NFD").replace(/[̀-ͯ]/g, ""); if(MAP[w]) return MAP[w]; }
    /* filmes e séries: o país nem sempre vem no início («FILMES | PT», «Séries - Portugal», «Netflix PT») */
    const toks = g.split(/[^A-Za-zÀ-ÿ]+/).filter(Boolean);
    for(const t of toks){ if(KNOWN[t]) return FIX[t] || t; }
    for(const t of toks){ const w = t.toUpperCase().normalize("NFD").replace(/[̀-ͯ]/g, ""); if(w.length > 3 && MAP[w]) return MAP[w]; }
    /* sem país (Ação, Comédia, Terror…): cada categoria fica individual, para a poderes ordenar ou esconder */
    return g.trim() ? "G:" + g.trim() : "??";
  };
  /* país de um item: a categoria; se não disser, o prefixo do nome («|PT| Título») */
  const ctyOfItem = c => { let k = ctyOf(c && c.group); if((k === "??" || k.slice(0, 2) === "G:") && c && c.name){ const n = ctyOf(c.name); if(n !== "??" && n.slice(0, 2) !== "G:") k = n; } return k; };
  window.__par = {unlocked:false, re:/(^|[^a-z0-9])(xxx|adult[oa]?s?|adulto|porn\w*|er[oó]tic\w*|sexy|18\+|\+18|hentai|playboy|hustler|brazzers|for adults|xxxx)([^a-z0-9]|$)/i,
    on(){ try{ return !!localStorage.getItem("ck_parPin"); }catch(e){ return false; } },
    blocksText(t){ return this.on() && !this.unlocked && this.re.test(String(t || "")); },
    blocks(c){ return !!c && this.blocksText((c.group || "") + " " + (c.name || "")); }};
  window.__cty = {
    ctyOf, ctyOfItem, state, reload: load,
    hiddenItem: c => state().hide.indexOf(ctyOfItem(c)) >= 0 || window.__par.blocks(c),
    rankItem: c => { const k = ctyOfItem(c), i = state().order.indexOf(k); return i >= 0 ? i : (k === "PT" ? -1 : 1000); },
    save: () => { try{ localStorage.setItem("ck_tvCty", JSON.stringify(state())); }catch(e){} },
    rank: g => { const c = ctyOf(g), i = state().order.indexOf(c); return i >= 0 ? i : (c === "PT" ? -1 : 1000); },
    hidden: g => state().hide.indexOf(ctyOf(g)) >= 0 || window.__par.blocksText(g),
    active: () => { const x = state(); return x.order.length > 0 || x.hide.length > 0; },
    name: c => { if(c === "??") return "Outros"; if(c.slice(0, 2) === "G:") return c.slice(2); try{ const n = new Intl.DisplayNames(["pt"], {type:"region"}).of(c); return n && n !== c ? n : c; }catch(e){ return c; } },
    flag: c => c.slice(0, 2) === "G:" ? "\u{1F3F7}" : /^[A-Z]{2}$/.test(c) ? String.fromCodePoint(...[...c].map(ch => 127397 + ch.charCodeAt(0))) : "\u{1F310}"
  };
})();</script>
"""
rep("</head>", CTY + "</head>")
rep("  const l = [...names].sort((a, b) => idx(a) - idx(b) || a.localeCompare(b));\n  return withHidden ? l : l.filter(n => !hid.has(n));",
    "  const cr = window.__cty ? window.__cty.rank : (() => 0);\n  const l = [...names].sort((a, b) => cr(a) - cr(b) || idx(a) - idx(b) || a.localeCompare(b));\n  return withHidden ? l : l.filter(n => !hid.has(n) && !(window.__cty && window.__cty.hidden(n)));")
rep("let l = list.filter(c => !hid.has(c.url) && (kind === \"free\" || kind === \"fav\" || !gh.has(c.group)));",
    "let l = list.filter(c => !hid.has(c.url) && (kind === \"free\" || kind === \"fav\" || kind === \"intl\" || (!gh.has(c.group) && !(window.__cty && window.__cty.hiddenItem(c)))));")
rep("|| l.some(c => isPtGroup(c.group));", "|| l.some(c => isPtGroup(c.group)) || (window.__cty && window.__cty.active());")
rep("const gi = c => { const i = gord.indexOf(c.group); return i < 0 ? (isPtGroup(c.group) ? -1 : 1e6) : i; }, seen",
    "const gi = c => (window.__cty && kind !== \"free\" && kind !== \"intl\" ? window.__cty.rankItem(c) * 1e7 : 0) + (() => { const i = gord.indexOf(c.group); return i < 0 ? (isPtGroup(c.group) ? -1 : 1e6) : i; })(), seen")
rep("<title>Cockpit", "<title>Cockpit TV")
rep('id="bootLogo">COCKPIT<', 'id="bootLogo">COCKPIT TV<')
rep("function px(url, ref, ua){\n  if(!url) return url;", "function px(url, ref, ua){\n  if(!url || (window.ANDROID && window.__pxMode() === \"off\")) return url;")
rep("function px2(url, ref, ua){\n  if(!url || !cfg.proxy2 || !cfg.proxy) return url;", "function px2(url, ref, ua){\n  if(!url || (window.ANDROID && window.__pxMode() === \"off\") || !cfg.proxy2 || !cfg.proxy) return url;")
rep("const HASPX = () => !!(PHONE || cfg.proxy2 || cfg.proxy);", "const HASPX = () => (!window.ANDROID || window.__pxMode() !== \"off\") && !!(PHONE || cfg.proxy2 || cfg.proxy);")
rep('const PAGE_HTTP = location.protocol === "http:" && !PHONE;', 'const PAGE_HTTP = (location.protocol === "http:" && !PHONE) || !!window.ANDROID;')
rep('let mirrorOn = LS.get("mirror", false);', 'let mirrorOn = LS.get("mirror", false) && !window.ANDROID;')
rep('if(window.top !== window || location.protocol==="file:") return',
    'if(window.ANDROID) return "Não consegui ligar ao servidor (" + e.message + "). Confirma o endereço, o utilizador e a palavra-passe e a ligação à internet.";\n  if(window.top !== window || location.protocol==="file:") return')
rep("function show(view){\n", 'function show(view){\n  if(window.ANDROID && !["settings","tv","tvhome","tvlive"].includes(view)) view = "tvhome";\n')
rep("applyPassenger(); applyLayout();", 'if(window.ANDROID){ cfg.layout = "classic"; cfg.passenger = false; }\napplyPassenger(); applyLayout();')
rep('\nif(passengerImport()) show("tv");', '\nif(window.ANDROID) show("tvhome");\nelse if(passengerImport()) show("tv");')

# --- leitor nativo (Media3): ganchos no código do Cockpit ---
rep("  if(isTs && live){ tryTs(); }\n  else if(isFlv || isFileTs){", "  if(window.NATIVE && NATIVE.go(c, slot, playId, fail)){ /* leitor nativo */ }\n  else if(isTs && live){ tryTs(); }\n  else if(isFlv || isFileTs){")
rep("  audioWatch(slot, c, playId, () => fileViaHls && fileViaHls());", "  if(!(window.NATIVE && NATIVE.active)) audioWatch(slot, c, playId, () => fileViaHls && fileViaHls());")
rep("function stopSlot(slot){\n", "function stopSlot(slot){\n  if(window.NATIVE && slot === 0) NATIVE.stop();\n")
rep("function trkAddExt(slot, text, label){\n", "function trkAddExt(slot, text, label){\n  if(window.NATIVE && NATIVE.active && slot === 0){ NATIVE.subText(text, label); return; }\n")
rep("function trkShift(slot, d){\n", "function trkShift(slot, d){\n  if(window.NATIVE && NATIVE.active && slot === 0){ NATIVE.shift(d); return; }\n")
rep("function osHasPt(slot){", "function osHasPt(slot){ if(window.NATIVE && NATIVE.active && slot === 0) return NATIVE.tracks('text').some(t => trkIsPt(t.name)) || !!NATIVE.subBase;\n  return osHasPt0(slot); }\nfunction osHasPt0(slot){")
rep("function trkAudioList(slot){\n", "function trkAudioList(slot){\n  if(window.NATIVE && NATIVE.active && slot === 0){ const t = NATIVE.tracks('audio'); if(t.length) return {kind:'nat', items:t}; }\n")
rep("function trkSetAudio(slot, kind, i){\n", "function trkSetAudio(slot, kind, i){\n  if(kind === 'nat'){ NATIVE.pick('audio', i); return; }\n")
rep("function trkSubList(slot){\n  const h = hlsInst[slot], v = $(\"vid\"+slot), items = [];\n", "function trkSubList(slot){\n  const h = hlsInst[slot], v = $(\"vid\"+slot), items = [];\n  if(window.NATIVE && NATIVE.active && slot === 0){ NATIVE.tracks('text').forEach(t => items.push({kind:'nat', i:t.i, name:t.name, on:t.on})); return items; }\n")
rep("function trkSubsOff(slot){\n", "function trkSubsOff(slot){\n  if(window.NATIVE && NATIVE.active && slot === 0){ NATIVE.pick('text', -1); return; }\n")
rep("function trkSetSub(slot, it){\n  trkSubsOff(slot); if(!it) return;\n", "function trkSetSub(slot, it){\n  trkSubsOff(slot); if(!it) return;\n  if(it.kind === 'nat'){ NATIVE.pick('text', it.i); return; }\n")

CSS = """
/* ===== Cockpit TV (Android) ===== */
body.android .rail,body.android .tsonly,body.android #tsPanel,body.android #chipCar,body.android #chipNet,body.android #lockNow,body.android #teslaFs,body.android #heard,body.android #micBtn{display:none!important}
body.android .app{grid-template-columns:1fr!important;grid-template-rows:54px 1fr!important}
body.android .top{grid-column:1!important;grid-row:1!important;padding:0 14px;gap:10px}
body.android main{grid-column:1!important;grid-row:2!important}
body.android .app.cinema{grid-template-rows:54px 1fr!important}
body.android #gdDlg{inset:54px 0 0 0!important}
body.phone #gdDlg{inset:0 0 calc(62px + env(safe-area-inset-bottom,0px)) 0!important;height:auto!important;width:auto!important;max-width:none!important}
body.android .clock{font-size:22px}
body.android :focus-visible{outline:4px solid var(--accent)!important;outline-offset:3px;box-shadow:0 0 0 8px color-mix(in srgb,var(--accent) 30%,transparent)}
body.android .item:focus-visible{background:var(--panel-2)}
body.android.tv .app{padding:14px 22px 0;box-sizing:border-box}
body.android.tv .btn,body.android.tv .tab{min-height:46px;padding-block:6px}
body.android.tv .item{min-height:52px}
body.android.tv{font-size:16px}
body.android #btnFull,body.android #btnMirror{display:none!important}
/* ===== Android TV: visual moderno ===== */
body.android{background:radial-gradient(1100px 520px at 85% -8%,color-mix(in srgb,var(--accent) 20%,transparent),transparent),linear-gradient(180deg,#0a101c,#04070d)!important}
body.android .top{background:linear-gradient(180deg,color-mix(in srgb,var(--accent) 30%,#0b1424),color-mix(in srgb,var(--accent) 14%,#08101c))!important;border:0!important;border-bottom:2px solid color-mix(in srgb,var(--accent) 55%,transparent)!important;box-shadow:0 6px 24px rgba(0,0,0,.45)!important;height:72px;padding:0 28px;gap:18px;position:relative;z-index:5}
body.android .top .btn[data-v],body.android #atvHome,body.android #chipDrive,body.android #chipCar,body.android #chipNet{display:none!important}
body.android .clock{font-size:26px;font-weight:700;letter-spacing:.02em}
.thNav{display:flex;gap:8px;margin-left:18px}
.thTab{display:inline-flex;align-items:center;gap:8px;min-height:50px;padding:6px 22px;border:0;border-radius:999px;background:transparent;color:inherit;font:600 18px/1 inherit;opacity:.78}
.thTab span{font-size:20px}
.thTab[aria-current="page"]{background:var(--accent);color:var(--accent-ink);opacity:1}
body.android .thTab:focus-visible{outline:3px solid #fff!important;outline-offset:2px;box-shadow:none;opacity:1}
#v-tvhome{padding:4px 28px 40px;box-sizing:border-box}
#exitDlg{position:fixed;inset:0;z-index:300;background:#000b;display:flex;align-items:center;justify-content:center}
#exitDlg[hidden]{display:none}
#exitDlg .exBox{background:#121b2e;border-radius:22px;padding:28px 36px;min-width:min(520px,80vw);text-align:center;box-shadow:0 20px 60px #000a}
#exitDlg h2{margin:0 0 6px;font-size:28px}#exitDlg p{margin:0 0 20px;font-size:18px;opacity:.8}
#exitDlg .exBt{display:flex;gap:14px;justify-content:center}#exitDlg .btn{min-width:150px;min-height:54px;font-size:19px}
body.exitOpen .app{pointer-events:none}
.thBar{position:absolute;left:0;right:0;bottom:0;height:6px;background:#0008;z-index:2}.thBar i{display:block;height:100%;background:var(--accent,#7cc4ff)}
.tplGrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px}
.tplBtn{flex-direction:column;align-items:flex-start!important;justify-content:flex-start!important;text-align:left!important;height:auto;padding:12px 16px!important;gap:3px}
.tplBtn small{font-size:13px;opacity:.7;font-weight:400;white-space:normal}
.tplBtn[aria-pressed=true]{background:var(--accent)!important;color:var(--accent-ink)!important}
body.tl-cinema .thCard{flex-basis:340px}body.tl-cinema .thHero{min-height:300px}body.tl-cinema .thHeroTx h1{font-size:50px}body.tl-cinema .thMeta b{font-size:22px}body.tl-cinema .thHeroArt{flex-basis:340px}
body.tl-compacto .thHero{display:none}body.tl-compacto .thCard{flex-basis:190px}body.tl-compacto .thMeta b{font-size:15px}body.tl-compacto .thMeta small{display:none}body.tl-compacto .thRow h2{font-size:20px;margin-top:8px}body.tl-compacto .thScroll{gap:12px;padding-bottom:14px}
body.tl-grelha .thScroll{flex-wrap:wrap;overflow:visible}
body.tl-grande{font-size:22px!important}body.tl-grande .thCard{flex-basis:300px}body.tl-grande .thMeta b{font-size:24px}body.tl-grande .thMeta small{font-size:18px}body.tl-grande .thRow h2{font-size:30px}body.tl-grande .thTab{font-size:22px}body.tl-grande .thBtn{font-size:23px}body.tl-grande .btn,body.tl-grande .tab{font-size:20px!important}
body.tl-grande #v-tv .cinebar{display:grid!important;grid-template-columns:repeat(auto-fit,minmax(200px,1fr))!important;flex-wrap:wrap!important;overflow:visible!important;gap:10px!important}
body.tl-grande.phone:not(.pland) #v-tv .cinebar{grid-template-columns:repeat(2,minmax(0,1fr))!important}
body.tl-grande.phone:not(.pland) #v-tv .cinebar .btn{font-size:17px!important;padding:6px 8px!important;min-height:52px!important}
body.tl-grande #v-tv .cinebar .cinename{grid-column:1/-1!important;font-size:24px!important;white-space:normal!important}
body.tl-grande #v-tv .cinebar .btn{width:100%!important;min-height:58px!important;font-size:19px!important;padding:6px 14px!important;white-space:nowrap!important;overflow:visible!important;text-overflow:clip!important;gap:8px}
body.tl-grande #v-tv .cinebar .btn svg{flex:none}
body.tl-grande #tvList .item .t b,body.tl-grande #tvList .item .t span{white-space:normal}
body.tl-grande #tvList>.item,body.tl-grande #tvList>div{flex:none!important;height:auto!important;min-height:64px;overflow:visible}body.tl-grande #tvList .item .t{min-width:0;flex:1 1 auto;line-height:1.2;overflow-wrap:anywhere}body.tl-grande #tvList .item .t b,body.tl-grande #tvList .item .t span{display:block;line-height:1.2}
#tvList>.item{flex:none}
body.ov-1.android .app{padding:32px 48px 0!important}body.ov-2.android .app{padding:56px 80px 0!important}
#castBanner{position:fixed;left:50%;bottom:18px;transform:translateX(-50%);z-index:260;display:flex;align-items:center;gap:10px;padding:10px 16px;border-radius:16px;background:#121b2ef2;box-shadow:0 10px 36px #000a;max-width:94vw}
#castBanner[hidden]{display:none}#castBanner span{font-weight:700;max-width:46vw;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.epgdlg .detbox{display:flex!important;flex-direction:row!important;align-items:flex-start;gap:26px;width:min(1100px,94vw);max-height:90vh;padding:24px;box-sizing:border-box;overflow:hidden}
.detposter{flex:0 0 240px;aspect-ratio:2/3;border-radius:16px;background:linear-gradient(135deg,#1d2a47,#0d1424);display:flex;align-items:center;justify-content:center;overflow:hidden;align-self:flex-start}
.detposter img{width:100%;height:100%;object-fit:cover}.detposter b{font-size:56px;opacity:.4}
.dettx{flex:1;min-width:0;display:flex;flex-direction:column;gap:10px;overflow:hidden}
.dettx h2{margin:0;font-size:30px;line-height:1.15}
.detmeta{font-size:17px;opacity:.9}.detrate{color:#ffd166;margin-right:6px}
.detplot{flex:0 1 auto;min-height:96px;font-size:17px;line-height:1.45;overflow-y:auto;max-height:36vh;padding:4px 8px 4px 2px;border-radius:10px}
.detplot:focus-visible{outline:3px solid var(--accent)!important}
.detcrew{font-size:15px;opacity:.8;display:flex;flex-direction:column;gap:4px;max-height:16vh;overflow:hidden}
.detbt{display:flex;gap:12px;flex-wrap:wrap;margin-top:auto;padding-top:6px}
/* detalhes de filme/série: nada cortado. A coluna de texto rola inteira (sinopse completa, elenco completo) e os botões ficam sempre à vista */
.epgdlg .detbox{max-height:92vh!important}
.ctyList .orgrow{flex-wrap:wrap;gap:6px;padding:8px 10px;align-items:center}.ctyList .orgrow .nm{flex:1 1 100%;white-space:normal;font-size:1.05em}.ctyList .orgrow .btn{flex:1 1 0;min-width:0;padding:0 6px}
/* Guia: as linhas da lista não encolhem (antes ficavam sobrepostas) e o texto alinha à esquerda */
#gdList>.gch,#gdSched>*,#gdRes>*{flex:none!important}
body.android #gdList .gch{justify-content:flex-start!important;text-align:left!important;min-height:64px!important;height:auto!important;padding:10px 12px!important}
body.android #gdList .gch .t{align-items:flex-start;flex:1;min-width:0}
body.android #gdList .gch .t b{font-size:1.02em}
body.android #gdList .gch .ph,body.android #gdList .gch img{width:46px;height:46px}
body.android #gdDlg .gdbox{background:#0f1726!important}
body.pland #gdDlg .gdbox{width:calc(100% - 20px)!important;max-width:none!important;height:calc(96vh / var(--ps,1))!important;max-height:none!important}
body.pland #gdDlg .gdgrid{grid-template-columns:minmax(260px,330px) minmax(0,1fr)!important;grid-template-rows:minmax(0,1fr)!important}
body.tv #gdDlg .gdbox{width:min(1700px,94vw)!important;height:min(940px,90vh)!important;max-height:none!important}
body.tv #gdDlg .gdgrid{grid-template-columns:minmax(380px,460px) minmax(0,1fr)!important;grid-template-rows:minmax(0,1fr)!important}
.epgdlg .dettx{overflow-y:auto!important;max-height:calc(92vh - 48px);padding-right:4px}
.epgdlg .detplot{max-height:none!important;overflow:visible!important;flex:0 0 auto}
.epgdlg .detcrew{max-height:none!important;overflow:visible!important}
.epgdlg .detbt{position:sticky;bottom:0;margin-top:auto;padding:10px 0 2px;background:linear-gradient(to bottom,transparent,var(--panel,#111a2c) 35%);z-index:2}
body.pland .epgdlg .detbox{max-height:calc(94vh / var(--ps,1))!important;width:min(1100px,94%)}
body.pland .epgdlg .dettx{max-height:calc(94vh / var(--ps,1) - 48px)}
@media (max-width:700px){
  body:not(.pland) .epgdlg .detbox{overflow-y:auto!important;max-height:90vh!important}
  body:not(.pland) .epgdlg .dettx{overflow:visible!important;max-height:none!important}
  body:not(.pland) .epgdlg .detbt{position:static;background:none}
}
@media (max-width:700px){.epgdlg .detbox{flex-direction:column!important;overflow-y:auto}.detposter{flex-basis:auto;width:42%}}
.ic{width:1.2em;height:1.2em;flex:none;vertical-align:-.22em;fill:none;stroke:currentColor;stroke-width:var(--icw,2);stroke-linecap:var(--icc,round);stroke-linejoin:var(--icj,round);margin-inline:.1em}
body.ics-2{--icw:3}body.ics-3{--icw:1.4}
.icw{display:inline}body.ics-5 .icw>svg.ic{display:none}body.ics-5 .icw::before{content:attr(data-e);font-size:1.05em;line-height:1;margin-inline:.1em}
body.ics-4 .ic :is(circle,rect,path[d$="z"]):not([fill]),.ic.icduo :is(circle,rect,path[d$="z"]):not([fill]){fill:currentColor;fill-opacity:.3}
body.ics-3 .ic :is(circle,rect,path[d$="z"]):not([fill]),.ic.icsolid :is(circle,rect,path[d$="z"]):not([fill]){fill:currentColor}
.icsGrid{display:flex;flex-direction:column;gap:10px}.icsB{display:flex!important;align-items:center;justify-content:space-between!important;gap:14px;text-align:left}.icsPv{display:flex;gap:10px}.icsPv .ic{width:26px;height:26px;margin:0}
.thTab .ic{width:1.35em;height:1.35em}
#tvSetGrid{grid-column:1/-1;width:100%;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;align-items:start;padding-bottom:48px}
#tvSetGrid .setcard{padding:0!important;overflow:hidden;scroll-margin-top:96px}
#tvSetGrid .setcard.open{grid-column:1/-1}
#tvSetGrid .setcard>h2{display:none}
#tvSetGrid .setcard:focus-within{box-shadow:0 0 0 3px var(--accent),0 10px 30px #0008}
.setHead:focus,.setHead:focus-visible{outline:4px solid #fff!important;outline-offset:-4px;background:color-mix(in srgb,var(--accent) 24%,transparent)!important}
.setHead:focus b{text-decoration:underline}
#tvSetGrid input:focus,#tvSetGrid select:focus,#tvSetGrid textarea:focus,#tvSetGrid .btn:focus,#tvSetGrid .btn:focus-visible{outline:3px solid #fff!important;outline-offset:2px}
.setHead{display:flex;align-items:center;gap:16px;width:100%;padding:16px 22px;border:0;background:transparent;color:inherit;text-align:left;font:inherit;border-radius:20px;min-height:84px;cursor:pointer}
.setHead .setIc{width:52px;height:52px;border-radius:14px;background:color-mix(in srgb,var(--accent) 22%,transparent);display:flex;align-items:center;justify-content:center;flex:none}
.setHead .setIc .ic{width:28px;height:28px;margin:0}
.setHead .setT{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}.setHead b{font-size:21px}.setHead small{font-size:15px;opacity:.7}
.setHead .chev .ic{width:22px;height:22px;opacity:.7;transition:transform .15s}.setcard.open .chev .ic{transform:rotate(90deg)}
.setBody{padding:4px 22px 22px;display:flex;flex-direction:column;gap:12px}.setBody[hidden]{display:none}
textarea{width:100%;box-sizing:border-box;background:var(--panel2,#1a2438);color:inherit;border:1px solid #fff2;border-radius:12px;padding:10px;font:inherit}.opB.on{background:var(--accent);color:var(--accent-ink)}
.keyList{display:flex;flex-direction:column;gap:8px}.keyList div{display:flex;gap:16px;align-items:baseline}.keyList b{flex:0 0 190px;font-size:17px}.keyList span{opacity:.85;font-size:16px}
@media (max-width:800px){#tvSetGrid{grid-template-columns:1fr}.keyList b{flex-basis:120px}}


/* ===== Telemóvel na horizontal: layout de TV reduzido ===== */
html.phoneh{overflow:hidden!important}
body.pland{transform:scale(var(--ps,.6));transform-origin:0 0;width:calc(100vw / var(--ps,.6))!important;height:calc(100vh / var(--ps,.6))!important;overflow:hidden!important;position:absolute;top:0;left:0}
body.pland .app{height:100%!important;min-height:0!important}
body.pland .thCard{flex-basis:178px}body.pland .thCard.sm{flex-basis:150px}
body.pland .thHero{min-height:0;padding:12px 24px;gap:20px;margin-bottom:8px}body.pland .thHeroArt{flex-basis:150px}body.pland .thHeroTx h1{font-size:28px}body.pland .thHeroTx p{font-size:16px}body.pland .thHeroBt{margin-top:2px}body.pland .thBtn{min-height:44px;font-size:17px}body.pland .thKind{min-width:120px}body.pland .thRow h2{margin-top:6px}
body.pland #bStamp{display:none}
/* Ecrã de canal (telemóvel na horizontal e TV): lista à esquerda, vídeo ao centro, botões à direita */
body.pland:not(.vfull) #v-tv.cinema{max-width:none!important;height:100%!important}
body.pland:not(.vfull) #v-tv.cinema .tvwrap{display:grid!important;grid-template-columns:300px minmax(0,1fr) 190px!important;grid-template-rows:auto auto auto minmax(0,1fr)!important;gap:10px 14px!important;height:100%!important;align-content:start!important}
body.pland:not(.vfull) #v-tv.cinema .tvwrap>.panel:first-child{display:flex!important;flex-direction:column!important;gap:8px!important;grid-column:1!important;grid-row:1/-1!important;min-height:0!important;overflow:hidden!important;padding:10px!important}
body.pland:not(.vfull) #v-tv.cinema .tvwrap>.panel:first-child>.tabs,body.pland:not(.vfull) #v-tv.cinema #freeTools,body.pland:not(.vfull) #v-tv.cinema #btnOrg,body.pland:not(.vfull) #v-tv.cinema #tvCount,body.pland:not(.vfull) #v-tv.cinema #tvLock{display:none!important}
body.pland:not(.vfull) #v-tv.cinema #tvList{flex:1 1 0!important;min-height:0!important;height:auto!important;max-height:none!important;overflow-y:auto!important}
body.pland:not(.vfull) #v-tv.cinema .tvwrap>.panel:last-child{display:contents!important}
body.pland:not(.vfull) #v-tv.cinema .stage{grid-column:2!important;grid-row:1!important;width:min(100%,calc((100vh / var(--ps,.6) - 190px) * 16 / 9))!important;margin:0!important}
body.pland:not(.vfull) #v-tv.cinema .tvwrap>.panel:last-child>.epg{grid-column:2!important;grid-row:2!important;display:block!important;max-height:150px!important;overflow:hidden!important;font-size:15px!important}
body.pland:not(.vfull) #v-tv.cinema .tvwrap>.panel:last-child>.row{grid-column:2!important;grid-row:3!important;margin:0!important}
body.pland:not(.vfull) #v-tv.cinema .cinebar{grid-column:3!important;grid-row:1/-1!important;display:flex!important;flex-direction:column!important;flex-wrap:nowrap!important;gap:6px!important;min-height:0!important;overflow:hidden!important;align-self:stretch!important}
body.pland:not(.vfull) #v-tv.cinema .cinebar .cinename{font-size:18px!important;white-space:nowrap!important;overflow:hidden!important;text-overflow:ellipsis!important;flex:none!important;margin:0 0 2px!important;text-align:left!important}
body.pland:not(.vfull) #v-tv.cinema .cinebar .btn{min-height:0!important;flex:1 1 0!important;font-size:15px!important;padding:0 8px!important;width:100%!important}
body.pland:not(.vfull) #v-tv.cinema #epgBox{display:block!important;grid-column:2!important;grid-row:2!important}
body.pland:not(.vfull) #v-tv.cinema #epgBox>b:first-child{display:none}
/* TV: vídeo maior, lista mais estreita e botões por baixo do vídeo */
/* TV: as duas barras de botões (canal e salto) não se podem sobrepor; o vídeo deixa espaço para ambas */

html body.pland.vfull.android #v-tv.cinema .stage{width:100%!important;height:100%!important;inset:0!important;max-width:none!important}html body.pland.vfull.android #stage .slot{width:100%!important;height:100%!important}
/* ===== Telemóvel: layout automático ===== */
html.phoneh,body.phone{overflow-x:hidden!important;max-width:100vw}
body.phone{font-size:15px;min-width:0!important}
body.phone .top{position:fixed!important;top:auto!important;bottom:0;left:0;right:0;height:62px!important;padding:0 4px calc(env(safe-area-inset-bottom,0px)) !important;gap:0!important;border-bottom:0!important;border-top:2px solid color-mix(in srgb,var(--accent) 55%,transparent)!important;box-shadow:0 -6px 24px rgba(0,0,0,.5)!important;z-index:50}
body.phone .top .clock,body.phone .top .spacer,body.phone .top>*:not(.thNav){display:none!important}
body.phone .thNav{margin:0;flex:1;gap:0;justify-content:space-around}
body.phone .thTab{flex-direction:column;gap:2px;min-height:54px;padding:4px 6px;font-size:11px;border-radius:14px;flex:1;min-width:0;justify-content:center}
body.phone .thTab span{font-size:20px;line-height:1}body.phone .thTab .ic{width:22px;height:22px;margin:0}
body.phone .app{display:flex!important;flex-direction:column;height:100dvh}body.phone #main{flex:1;min-height:0;overflow-y:auto;padding:12px 10px 76px!important}body.phone #v-tvhome{padding-left:2px!important;padding-right:2px!important}body.phone #thCast .lb,body.phone #thMirror .lb{display:none}
body.phone .thHero{flex-direction:column;align-items:stretch;padding:16px;gap:14px;min-height:0;border-radius:20px}
body.phone .thHeroArt{flex:none;width:100%}
body.phone .thHeroTx h1{font-size:24px}body.phone .thHeroTx p{font-size:15px}
/* Início no telemóvel (vertical): o último canal visto ocupa pouco espaço, com a capa do tamanho de um picon */
body.phone:not(.pland) .thHero{flex-direction:row;align-items:center;padding:12px 14px;gap:14px;border-radius:18px;margin:20px 0 8px}
body.phone:not(.pland) .thHeroArt{flex:0 0 36%;width:auto;border-radius:14px}
body.phone:not(.pland) .thHeroArt img{max-width:78%;max-height:78%}
body.phone:not(.pland) .thHeroArt b{font-size:28px}
body.phone:not(.pland) .thHeroTx{gap:4px}
body.phone:not(.pland) .thHeroTx small{font-size:10.5px}
body.phone:not(.pland) .thHeroTx h1{font-size:19px;white-space:normal;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
body.phone:not(.pland) .thHeroTx p{font-size:13px}
body.phone:not(.pland) .thHeroBt{gap:8px;margin-top:4px}
body.phone:not(.pland) .thHeroBt .thBtn{min-height:40px;padding:6px 14px;font-size:14px}
body.phone .thRow h2{font-size:19px;margin-top:12px}
body.phone .thCard{flex-basis:44vw}body.phone .thCard.sm{flex-basis:36vw}
body.phone .thMeta b{font-size:14px}body.phone .thMeta small{font-size:12px}
body.phone .thKinds{overflow-x:auto;scrollbar-width:none}
body.phone .thBtn{font-size:15px;min-height:44px;padding:8px 16px}
body.phone #tvSetGrid{grid-template-columns:1fr}
body.phone .setHead{min-height:68px;padding:12px 16px}body.phone .setHead b{font-size:17px}
body.phone .epgdlg{width:100vw!important;max-width:100vw!important;height:100%!important;border-radius:0!important}
.thKinds{display:flex;gap:12px;margin:6px 0 4px}
.thKind{min-width:150px}
.thKind[aria-pressed=true]{background:#7cc4ff;color:#06101f;border-color:#7cc4ff}
.thHero{display:flex;align-items:center;gap:30px;padding:26px 32px;margin:2px 0 14px;border-radius:26px;min-height:210px;background:linear-gradient(120deg,color-mix(in srgb,var(--accent) 38%,#0d1526),#0d1526 72%);box-shadow:0 18px 50px #0007}
.thHeroArt{flex:0 0 250px;aspect-ratio:16/9;border-radius:18px;background:#0b1220cc;display:flex;align-items:center;justify-content:center;overflow:hidden}
.thHeroArt img{max-width:70%;max-height:70%;object-fit:contain}
.thHeroArt b{font-size:44px;opacity:.6}
.thHeroTx{flex:1;min-width:0;display:flex;flex-direction:column;gap:8px}
.thHeroTx small{font-size:15px;letter-spacing:.14em;text-transform:uppercase;opacity:.7}
.thHeroTx h1{margin:0;font-size:38px;line-height:1.1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.thHeroTx p{margin:0;font-size:19px;opacity:.85;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.thHeroBt{display:flex;gap:12px;margin-top:8px;flex-wrap:wrap}
.thBtn{min-height:54px;padding:8px 26px;border:0;border-radius:14px;background:#ffffff1f;color:inherit;font:600 19px/1 inherit}
.thBtn.pri{background:var(--accent);color:var(--accent-ink)}
body.android .thBtn:focus-visible{outline:3px solid #fff!important;outline-offset:3px;box-shadow:none;transform:scale(1.04)}
.thRow h2{display:flex;align-items:baseline;justify-content:space-between;gap:12px}.thRow h2 span{min-width:0;overflow:hidden;text-overflow:ellipsis}.thRow h2 .thCnt{flex:none;font-style:normal;font-size:.62em;font-weight:600;opacity:.7;background:#ffffff1f;border-radius:999px;padding:2px 12px}
.thRow h2{margin:18px 4px 2px;font-size:24px;font-weight:700;letter-spacing:.01em;text-transform:none}
@media (max-height:800px){.thHero{min-height:0;padding:14px 24px;gap:20px;margin-bottom:6px}.thHeroArt{flex-basis:170px}.thHeroTx h1{font-size:28px}.thHeroTx p{font-size:16px}.thHeroTx small{font-size:12px}.thHeroBt{margin-top:2px}.thBtn{min-height:44px;padding:6px 20px;font-size:17px}.thKind{min-width:120px}.thRow h2{margin-top:10px;font-size:21px}}
.thScroll{display:flex;gap:18px;overflow-x:auto;padding:12px 10px 26px;scrollbar-width:none;scroll-padding:0 40px}
#thRows .thCard,#thRows .thRow{scroll-margin-top:170px;scroll-margin-bottom:36px}
.thScroll::-webkit-scrollbar{display:none}
.thCard{flex:0 0 244px;border:0;border-radius:18px;background:var(--panel,#121b2e);color:inherit;padding:0;text-align:left;overflow:hidden;transition:transform .09s,box-shadow .09s;box-shadow:0 6px 18px #0006}
.thCard.sm{flex-basis:200px}#thSrch{position:fixed;inset:0;z-index:99998;background:rgba(5,9,16,.88);backdrop-filter:blur(8px);display:flex;justify-content:center;padding:4vh 3vw}
#thSrch .thSrBox{width:min(900px,100%);display:flex;flex-direction:column;gap:12px;max-height:92vh}
#thSrch .thSrTop{display:flex;gap:10px}#thSrch input{flex:1;font-size:20px;padding:12px 16px;border-radius:14px;border:1px solid rgba(255,255,255,.25);background:#141e32;color:#fff}
#thSrch .thSrRes{overflow:auto;display:flex;flex-direction:column;gap:6px;padding-bottom:12px}
#thSrch .thSrI{text-align:left;justify-content:flex-start;gap:8px;display:flex;align-items:center}#thSrch .thSrI small{opacity:.65}
/* ===== Estilo Netflix (só com a opção ligada) ===== */
body.tl-netflix{--panel:#181818}
body.tl-netflix .thHero{border-radius:10px;background:linear-gradient(90deg,#000 0%,color-mix(in srgb,var(--accent) 20%,#0c0c0e) 100%);box-shadow:none}
body.tl-netflix:not(.phone) .thHero{min-height:clamp(200px,38vh,420px);padding:22px 34px}
body.tl-netflix:not(.phone) .thHeroArt{flex:0 0 clamp(280px,42%,680px);border-radius:8px}
body.tl-netflix .thHeroArt img{max-width:78%;max-height:78%}
body.tl-netflix .thHeroTx h1{font-size:clamp(26px,5.2vh,54px);font-weight:800;white-space:normal;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical}
body.tl-netflix .thHeroTx small{color:var(--accent);font-weight:700}
body.tl-netflix .thBtn{border-radius:6px;background:#6d6d6eb3}
body.tl-netflix .thBtn.pri{background:#fff;color:#000}
body.tl-netflix .thKind{border-radius:999px;background:transparent;border:1px solid #ffffff55}
body.tl-netflix .thKind[aria-pressed=true]{background:#fff;color:#000;border-color:#fff}
body.tl-netflix .thRow h2{font-size:clamp(16px,2.6vh,24px);font-weight:700}
body.tl-netflix .thRow h2 .thCnt{display:none}
body.tl-netflix .thScroll{padding:22px 14px 30px}
body.tl-netflix .thCard{border-radius:6px;box-shadow:none;background:#181818;position:relative;transition:transform .18s cubic-bezier(.2,.8,.2,1),box-shadow .18s}
body.tl-netflix .thMeta{position:absolute;left:0;right:0;bottom:0;padding:34px 10px 8px!important;background:linear-gradient(transparent,#000d)}
body.tl-netflix .thMeta small{display:none!important}
body.tl-netflix .thMeta b{white-space:normal;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden;line-height:1.2}
body.android.tl-netflix .thCard:focus-visible{transform:scale(1.14);box-shadow:0 0 0 3px #fff,0 20px 40px #000c}
@media (hover:hover){body.tl-netflix .thCard:hover{transform:scale(1.07);z-index:3}}
/* ===== Animações do Início (escolhidas nas Definições) ===== */
@keyframes thUp{from{opacity:0;transform:translateY(46px) scale(.94)}to{opacity:1;transform:none}}
@keyframes thZoom{from{opacity:0;transform:scale(.55)}60%{opacity:1;transform:scale(1.07)}to{opacity:1;transform:none}}
@keyframes thSlideR{from{opacity:0;transform:translateX(110px)}to{opacity:1;transform:none}}
@keyframes thSlideL{from{opacity:0;transform:translateX(-110px)}to{opacity:1;transform:none}}
body.an-suave #thRows.thArm .thCard:not(.in),body.an-cascata #thRows.thArm .thCard:not(.in),body.an-zoom #thRows.thArm .thCard:not(.in),body.an-flow #thRows.thArm .thCard:not(.in){opacity:0}
body.an-slide #thRows.thArm .thRow:not(.in){opacity:0}
#thRows .thCard:focus-visible{opacity:1!important}
body.an-suave .thCard.thRev,body.an-flow .thCard.thRev{animation:thUp .5s cubic-bezier(.2,.8,.2,1) backwards}
body.an-cascata .thCard.thRev{animation:thUp .6s cubic-bezier(.2,.8,.2,1) backwards;animation-delay:var(--d,0ms)}
body.an-zoom .thCard.thRev{animation:thZoom .55s cubic-bezier(.2,.9,.3,1.1) backwards;animation-delay:var(--d,0ms)}
body.an-slide .thRow.thRev{animation:thSlideR .65s cubic-bezier(.2,.8,.2,1) backwards}
body.an-slide .thRow:nth-child(even).thRev{animation-name:thSlideL}
body.an-flow .thCard:not(:focus-visible):not(.thRev){transform:scale(var(--s,1));opacity:var(--o,1);transition:transform .1s linear,opacity .1s linear}
body.vf-on #thRows .thRow{transform:translate3d(var(--vx,0px),var(--vy,0px),0) scale(var(--vs,1));opacity:var(--vo,1);transform-origin:left center;will-change:transform,opacity}
#thRmDlg{position:fixed;inset:0;z-index:99999;background:rgba(5,9,16,.62);backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;animation:thRmIn .18s ease-out}
#thRmDlg .thRmBox{background:#141e32;border:1px solid rgba(255,255,255,.18);border-radius:22px;padding:22px 26px;max-width:min(440px,88vw);box-shadow:0 18px 50px rgba(0,0,0,.55);text-align:center;color:#fff}
#thRmDlg h3{margin:0 0 8px;font-size:20px}#thRmDlg p{margin:0 0 16px;opacity:.85;overflow-wrap:anywhere}
#thRmDlg .thRmBt{display:flex;gap:12px;justify-content:center}
@keyframes thRmIn{from{opacity:0;transform:scale(.96)}to{opacity:1;transform:none}}
body.android .thCard:focus-visible{outline:none!important;transform:scale(1.08);box-shadow:0 0 0 4px var(--accent),0 20px 44px #000b;position:relative;z-index:3}
.thCard.poster .thArt{aspect-ratio:2/3}
.thCard.poster .thArt img{max-width:none;max-height:none;width:100%;height:100%;object-fit:cover!important}
.thCard.poster .thMeta b{white-space:normal;display:-webkit-box;-webkit-line-clamp:4;-webkit-box-orient:vertical;overflow:hidden;line-height:1.22}
body.pland .thCard.poster .thMeta b{font-size:14px}body.pland .thCard.poster .thMeta{padding:8px 10px 10px}
body.pland .thCard.poster{flex-basis:170px}body.pland .thCard.poster.sm{flex-basis:145px}
.thCard.poster{align-self:flex-start}
/* TV: capas por altura do ecrã, para caberem inteiras com o nome por baixo (2 linhas) */
body.tv .thCard.poster{flex-basis:clamp(110px,18.5vh,200px)!important}body.tv .thCard.poster.sm{flex-basis:clamp(96px,15.5vh,170px)!important}
body.tv .thCard:not(.poster){flex-basis:clamp(160px,28vh,290px)!important}body.tv .thCard:not(.poster).sm{flex-basis:clamp(140px,23vh,240px)!important}
body.tv .thCard .thMeta{padding:6px 8px 8px}body.tv .thCard .thMeta b{font-size:clamp(12px,1.9vh,17px)!important;line-height:1.2}body.tv .thCard.poster .thMeta b{-webkit-line-clamp:2}
body.tv .thCard .thMeta small{font-size:clamp(10px,1.5vh,13px)!important}body.tv .thRow h2{font-size:clamp(15px,2.4vh,22px)!important;margin:6px 0 4px!important}body.tv .thScroll{gap:clamp(8px,1.4vh,14px)!important}
body.phone:not(.pland) .thCard.poster{flex-basis:38vw}
.thArt{display:flex;align-items:center;justify-content:center;aspect-ratio:16/9;background:linear-gradient(135deg,#1d2a47,#0d1424);position:relative}
.thArt img{max-width:60%;max-height:62%;object-fit:contain}
.thArt img+.thInit{display:none}
.thInit{font-size:34px;font-weight:800;opacity:.45;letter-spacing:.04em}
.thMeta{display:block;padding:10px 14px 13px}
.thMeta b{display:block;font-size:18px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.thMeta small{display:block;margin-top:3px;font-size:14px;opacity:.7;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.thMore{display:flex;align-items:center;justify-content:center;min-height:170px;font:700 20px/1 inherit;background:#ffffff14}
.thEmpty{padding:30px 6px;font-size:20px;opacity:.75}
/* Explorar e leitor: sem confusão de ecrã duplo */
body.android #v-tv>.row .tabs,body.android #btnCinema,body.android #btnSwapAudio,body.android .slot .rot,body.android .slot .lbl,body.android #v-tv .tvwrap>.panel:last-child>.row,body.android #mirDelMinus,body.android #mirDelVal,body.android #mirDelPlus,body.android #v-tv>.row>h1{display:none!important}
body.android #v-tv.cinema .cinebar{display:grid!important;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;width:min(100%,calc((100vh - 180px) * 16 / 9))!important;margin:12px auto 0!important;flex-wrap:wrap}
body.android #v-tv.cinema .cinebar .cinename{grid-column:1/-1;order:0;text-align:center;font-size:24px;font-weight:700;margin-bottom:2px}
body.android #v-tv.cinema .cinebar .btn{width:100%;white-space:nowrap;justify-content:center}
body.android #v-tv.cinema #chPrev{order:1}body.android #v-tv.cinema #chGuide{order:2}body.android #v-tv.cinema #chTracks{order:3}body.android #v-tv.cinema #chSubs{order:4}body.android #v-tv.cinema #chNext{order:5}
body.android #v-tv.cinema .stage{width:min(100%,calc((100vh - 180px) * 16 / 9))!important}

/* ===== Explorar: mesmo desenho do ecrã nativo (título + ⛶, transporte redondo, botões 4x2) ===== */
body.android #v-tv .cinebar .btn,body.android #v-tv #chFull,body.android #v-tv #mvBtn{background:#1B2B47!important;border:0!important;border-radius:12px!important;color:#fff!important;box-shadow:none!important}
body.android #v-tv .cinebar .btn:focus,body.android #v-tv .cinebar .btn:focus-visible,body.android #v-tv #chFull:focus,body.android #v-tv #mvBtn:focus{background:#2F7DD1!important;outline:2px solid #fff!important;outline-offset:0!important}
body.android #v-tv .cinebar .btn[disabled]{opacity:.45}
body.android #v-tv #btnGuide,body.android #v-tv #btnFull{display:none!important}
body.android.phone:not(.pland) #v-tv .tvwrap>.panel:last-child,body.android.tv #v-tv:not(.cinema) .tvwrap>.panel:last-child,body.android.pland #v-tv:not(.cinema) .tvwrap>.panel:last-child{display:grid!important;grid-template-columns:repeat(20,minmax(0,1fr));gap:8px;align-content:start}
body.android.phone:not(.pland) #v-tv .cinebar,body.android.tv #v-tv:not(.cinema) .cinebar,body.android.pland #v-tv:not(.cinema) .cinebar{display:contents!important}
body.android.phone:not(.pland) #v-tv .tvwrap>.panel:last-child>*,body.android.tv #v-tv:not(.cinema) .tvwrap>.panel:last-child>*,body.android.pland #v-tv:not(.cinema) .tvwrap>.panel:last-child>*{grid-column:1/-1;min-width:0}
body.android.phone:not(.pland) #v-tv .stage,body.android.tv #v-tv:not(.cinema) .stage,body.android.pland #v-tv:not(.cinema) .stage{grid-row:1;border-radius:16px;overflow:hidden;width:100%!important;max-width:none!important}
body.android.phone:not(.pland) #v-tv .cinename,body.android.tv #v-tv:not(.cinema) .cinename,body.android.pland #v-tv:not(.cinema) .cinename{grid-row:2;grid-column:1/17;text-align:left!important;font-size:20px;font-weight:700;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;align-self:center;margin:0}
body.android.phone:not(.pland) #v-tv .cineepg,body.android.tv #v-tv:not(.cinema) .cineepg,body.android.pland #v-tv:not(.cinema) .cineepg{grid-row:3;grid-column:1/-1;text-align:left;font-size:14px;opacity:.75;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin:-4px 0 2px}
body.android.phone:not(.pland) #v-tv #chFull,body.android.tv #v-tv:not(.cinema) #chFull,body.android.pland #v-tv:not(.cinema) #chFull{grid-row:2;grid-column:17/21;font-size:0!important;min-height:48px!important;border-radius:999px!important;padding:0!important}
body.android #v-tv:not(.cinema) #chFull::before{content:"⛶";font-size:24px}
/* transporte redondo */
body.android.phone:not(.pland) #v-tv #chPrev,body.android.phone:not(.pland) #v-tv #tsBack,body.android.phone:not(.pland) #v-tv #tsPlay,body.android.phone:not(.pland) #v-tv #tsFwd,body.android.phone:not(.pland) #v-tv #chNext,
body.android.tv #v-tv:not(.cinema) #chPrev,body.android.pland #v-tv:not(.cinema) #chPrev,body.android.tv #v-tv:not(.cinema) #tsBack,body.android.pland #v-tv:not(.cinema) #tsBack,body.android.tv #v-tv:not(.cinema) #tsPlay,body.android.pland #v-tv:not(.cinema) #tsPlay,body.android.tv #v-tv:not(.cinema) #tsFwd,body.android.pland #v-tv:not(.cinema) #tsFwd,body.android.tv #v-tv:not(.cinema) #chNext,body.android.pland #v-tv:not(.cinema) #chNext{grid-row:4;font-size:0!important;min-height:54px!important;border-radius:999px!important;padding:0!important}
body.android #v-tv:not(.cinema) #chPrev{grid-column:1/4}body.android #v-tv:not(.cinema) #tsBack{grid-column:4/8}body.android #v-tv:not(.cinema) #tsPlay{grid-column:8/14;background:#2F7DD1!important}body.android #v-tv:not(.cinema) #tsFwd{grid-column:14/18}body.android #v-tv:not(.cinema) #chNext{grid-column:18/21}
body.android.phone:not(.pland) #v-tv #chPrev::before,body.android.tv #v-tv:not(.cinema) #chPrev::before,body.android.pland #v-tv:not(.cinema) #chPrev::before{content:"⏮";font-size:22px}
body.android.phone:not(.pland) #v-tv #tsBack::before,body.android.tv #v-tv:not(.cinema) #tsBack::before,body.android.pland #v-tv:not(.cinema) #tsBack::before{content:"⏪";font-size:22px}
body.android.phone:not(.pland) #v-tv #tsPlay::before,body.android.tv #v-tv:not(.cinema) #tsPlay::before,body.android.pland #v-tv:not(.cinema) #tsPlay::before{content:"⏯";font-size:26px}
body.android.phone:not(.pland) #v-tv #tsFwd::before,body.android.tv #v-tv:not(.cinema) #tsFwd::before,body.android.pland #v-tv:not(.cinema) #tsFwd::before{content:"⏩";font-size:22px}
body.android.phone:not(.pland) #v-tv #chNext::before,body.android.tv #v-tv:not(.cinema) #chNext::before,body.android.pland #v-tv:not(.cinema) #chNext::before{content:"⏭";font-size:22px}
/* botões 4x2 */
body.android #v-tv:not(.cinema) #chAspect{grid-row:5;grid-column:1/6}body.android #v-tv:not(.cinema) #mvBtn{grid-row:5;grid-column:6/11}body.android #v-tv:not(.cinema) #chTracks{grid-row:5;grid-column:11/16}body.android #v-tv:not(.cinema) #chSubs{grid-row:5;grid-column:16/21}
body.android #v-tv:not(.cinema) #tsLive{grid-row:6;grid-column:1/6}body.android #v-tv:not(.cinema) #chGuide{grid-row:6;grid-column:6/11}body.android #v-tv:not(.cinema) #chInfo{grid-row:6;grid-column:11/16}
body.android.phone:not(.pland) #v-tv .cinebar .btn,body.android.tv #v-tv:not(.cinema) .cinebar .btn,body.android.pland #v-tv:not(.cinema) .cinebar .btn{min-height:44px!important;font-size:14px;padding:6px 4px;white-space:nowrap}
body.android #v-tv:not(.cinema) .tvwrap>.panel:last-child>.epg,body.android #v-tv:not(.cinema) #vStats{grid-row:8}
body.android.phone:not(.pland) #v-tv:not(.cinema) .stage,body.android.tv #v-tv:not(.cinema) .stage,body.android.pland #v-tv:not(.cinema) .stage{aspect-ratio:16/9!important;height:auto!important;min-height:0!important}
body.android.tv #v-tv:not(.cinema) .stage{height:calc(100vh - 440px)!important;width:auto!important;max-width:100%;justify-self:center;margin:0 auto}
/* telemóvel na horizontal (Explorar): vídeo grande à esquerda, comandos à direita, lista até ao fundo */
body.android.pland #v-tv:not(.cinema){max-width:none!important}
body.android.pland #v-tv:not(.cinema) .tvwrap{display:grid!important;grid-template-columns:360px minmax(0,1fr)!important;gap:14px!important;height:calc(100vh / var(--ps,.6) - 120px)!important;align-content:stretch!important}
body.android.pland #v-tv:not(.cinema) .tvwrap>.panel:first-child{display:flex!important;flex-direction:column!important;gap:8px!important;min-height:0!important;overflow:hidden!important;padding:10px!important}
body.android.pland #v-tv:not(.cinema) #tvList{flex:1 1 0!important;min-height:0!important;height:auto!important;max-height:none!important;overflow-y:auto!important}
body.android.pland #v-tv:not(.cinema) .tvwrap>.panel:last-child{grid-template-columns:repeat(40,minmax(0,1fr))!important;grid-auto-rows:min-content;align-content:start!important;padding:14px!important;overflow:hidden}
body.android.pland #v-tv:not(.cinema) .tvwrap>.panel:last-child>*{grid-column:1/-1}
body.android.pland #v-tv:not(.cinema) .stage{grid-column:1/-1!important;grid-row:1!important;height:calc(100vh / var(--ps,.6) - 335px)!important;width:auto!important;max-width:100%;aspect-ratio:16/9!important;justify-self:center;align-self:start;margin:0!important}
body.android.pland #v-tv:not(.cinema) .cinename{grid-column:1/34!important;grid-row:2!important;font-size:19px}
body.android.pland #v-tv:not(.cinema) #chFull{grid-column:36/41!important;grid-row:2!important;min-height:40px!important}
body.android.pland #v-tv:not(.cinema) .cineepg{grid-column:1/-1!important;grid-row:3!important;margin:0!important}
body.android.pland #v-tv:not(.cinema) #chPrev{grid-column:1/8!important;grid-row:4!important;min-height:46px!important}
body.android.pland #v-tv:not(.cinema) #tsBack{grid-column:8/15!important;grid-row:4!important;min-height:46px!important}
body.android.pland #v-tv:not(.cinema) #tsPlay{grid-column:15/27!important;grid-row:4!important;min-height:46px!important}
body.android.pland #v-tv:not(.cinema) #tsFwd{grid-column:27/34!important;grid-row:4!important;min-height:46px!important}
body.android.pland #v-tv:not(.cinema) #chNext{grid-column:34/41!important;grid-row:4!important;min-height:46px!important}
body.android.pland #v-tv:not(.cinema) #chAspect{grid-column:1/6!important;grid-row:5!important}
body.android.pland #v-tv:not(.cinema) #mvBtn{grid-column:6/12!important;grid-row:5!important}
body.android.pland #v-tv:not(.cinema) #chTracks{grid-column:12/17!important;grid-row:5!important}
body.android.pland #v-tv:not(.cinema) #chSubs{grid-column:17/23!important;grid-row:5!important}
body.android.pland #v-tv:not(.cinema) #tsLive{grid-column:23/28!important;grid-row:5!important}
body.android.pland #v-tv:not(.cinema) #chGuide{grid-column:28/34!important;grid-row:5!important}
body.android.pland #v-tv:not(.cinema) #chInfo{grid-column:34/41!important;grid-row:5!important}
body.android.pland #v-tv:not(.cinema) .cinebar .btn{min-height:40px!important;font-size:13px!important;padding:4px 2px!important}
body.android #v-tv:not(.cinema) .cinebar .btn,body.android #v-tv:not(.cinema) #chFull{min-width:0!important;width:auto!important;max-width:100%;overflow:hidden;text-overflow:ellipsis;box-sizing:border-box}
body.android.phone:not(.pland) #v-tv:not(.cinema) .cinebar .btn{font-size:13px;padding:6px 2px;gap:4px}
body.android.phone:not(.pland) #v-tv:not(.cinema) .tvwrap>.panel:last-child{padding-left:12px;padding-right:12px}
body.android .view{max-width:none!important}
body.android.tv{font-size:18px}
body.android.tv .btn,body.android.tv .tab{min-height:52px!important;font-size:17px}
body.android .panel{border-radius:20px;border:0;background:color-mix(in srgb,var(--panel,#121b2e) 92%,transparent)}

/* ===== Botões uniformes, alinhados e sem sobreposição ===== */
body.android .btn,body.android .tab{min-height:44px!important;padding:8px 14px;font-size:15px;line-height:1.15;box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;text-align:center;gap:6px}
body.android .row{align-items:center;gap:10px}
body.android #v-tv>.row{display:flex!important;flex-wrap:wrap!important;gap:10px;align-items:center}
body.android #v-tv>.row .tabs{display:flex;gap:6px;flex-wrap:nowrap}
body.android .tvwrap>.panel:first-child .tabs{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;overflow:visible!important}
body.android .tvwrap>.panel:first-child .tab{min-width:0;font-size:12px!important;padding:6px 2px!important;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
body.android #freeTools{display:grid!important;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:center}
body.android #freeTools .btn{width:100%}
body.android #freeTools #healthMsg{grid-column:1/-1;margin:0}
body.android .tvwrap>.panel:first-child input[type=search],body.android .tvwrap>.panel:first-child select,body.android #btnOrg{width:100%;box-sizing:border-box;min-height:44px!important}
body.android #v-tv:not(.cinema) .cinebar{display:grid!important;grid-template-columns:repeat(auto-fit,minmax(84px,1fr));gap:6px;align-items:stretch}
body.android #v-tv:not(.cinema) #chPrev{order:1}body.android #v-tv:not(.cinema) #chGuide{order:2}body.android #v-tv:not(.cinema) #chTracks{order:3}body.android #v-tv:not(.cinema) #chSubs{order:4}body.android #v-tv:not(.cinema) #chNext{order:5}body.android #v-tv:not(.cinema) #mirDelMinus{order:6}body.android #v-tv:not(.cinema) #mirDelVal{order:7;grid-column:span 2;text-align:center;align-self:center}body.android #v-tv:not(.cinema) #mirDelPlus{order:8}
#chSubs[hidden]{display:none!important}
body.android #v-tv:not(.cinema) .cinebar .cinename{grid-column:1/-1;order:0;text-align:center}
body.android #v-tv:not(.cinema) .cinebar .btn{width:100%;white-space:nowrap;padding-inline:8px;font-size:14px}
body.android #v-tv:not(.cinema) .cinebar #avDelay,body.android #v-tv:not(.cinema) .cinebar .avd{align-self:center;text-align:center}
body.android .tvwrap>.panel:last-child>.row{display:flex;flex-wrap:wrap;gap:10px;align-items:center}
body.android .setcard .row,body.android #v-settings .row{flex-wrap:wrap}
body.android .epgdlg .row{flex-wrap:wrap}

@media (max-width:1100px){body.android #v-tv>.row{gap:8px;flex-wrap:nowrap}body.android #v-tv>.row .btn,body.android #v-tv>.row .tab{font-size:14px;padding:6px 11px;white-space:nowrap;min-height:42px}body.android #v-tv>.row>h1{display:none}}
@media (max-height:640px){body.android #v-tv>h1,body.android #v-tv .row>h1{display:none}body.android .app{grid-template-rows:48px 1fr!important}}
@media (min-width:600px){
  body.android main{min-height:0;overflow-y:auto}
  body.android #v-tv{height:100%;min-height:0;display:flex;flex-direction:column}
  body.android #v-tv:not([hidden]){display:flex}
  body.android .tvwrap{flex:1;min-height:0;grid-template-columns:minmax(250px,34%) minmax(0,1fr)!important;grid-template-rows:minmax(0,1fr);gap:14px}
  body.android .tvwrap>.panel{min-height:0}
  body.android .tvwrap>.panel:last-child{order:0!important;overflow-y:auto}
  body.android .tvwrap>.panel:first-child{display:flex;flex-direction:column;overflow:hidden;gap:8px;padding:12px}
  body.android .tvwrap>.panel:first-child{overflow-y:auto!important}
  body.android .tvwrap>.panel:first-child>*{flex:none}
  body.android .tvwrap>.panel:first-child>.tabs{order:0}
  body.android .tvwrap>.panel:first-child>#tvGroup{order:1}
  body.android .tvwrap>.panel:first-child>#tvSearch{order:2}
  body.android #tvList{order:3;overflow-y:auto;flex:1 1 auto!important;min-height:min(46vh,340px)}
  body.android #btnOrg{order:4}
  body.android #freeTools{order:5}
  body.android #freeTools[hidden]{display:none!important}
  body.android #tvCount{order:6}
  body.android.tv #tvEmpty{display:none!important}
  body.android.tv .tvwrap>.panel:first-child .tabs{flex-wrap:nowrap;overflow-x:auto;gap:6px}
  body.android.tv .tvwrap>.panel:first-child .tab{font-size:13px;padding:5px 10px;min-height:38px;white-space:nowrap}
  body.android.tv .tvwrap>.panel:first-child input,body.android.tv .tvwrap>.panel:first-child select{min-height:40px;padding-block:6px}
  body.android.tv #btnOrg{white-space:nowrap;font-size:14px;min-height:40px}
  body.android.tv #tvCount{display:none}
}
/* modo cinema (ecrã inteiro do leitor) */
body.android .app.cinema{grid-template-rows:1fr!important}
body.android .app.cinema .top{display:none!important}
body.android .app.cinema main{grid-row:1!important;padding:8px 14px!important}
/* telemóvel: o leitor (cinema) mantém a barra global de navegação, só some em ecrã total */
body.android.phone:not(.pland):not(.vfull) .app.cinema .top{display:flex!important}
body.android.phone:not(.pland):not(.vfull) .app.cinema main{padding-bottom:calc(72px + env(safe-area-inset-bottom,0px))!important}
body.android.pland:not(.vfull) .app.cinema{grid-template-rows:72px 1fr!important}
body.android.pland:not(.vfull) .app.cinema .top{display:flex!important}
body.android.pland:not(.vfull) .app.cinema main{grid-row:2!important}
body.android #v-tv.cinema>.row,body.android #v-tv.cinema>.banner{display:none!important}
body.android #v-tv.cinema .tvwrap{display:block!important;grid-template-columns:1fr!important}
body.android #v-tv.cinema .tvwrap>.panel:first-child{display:none!important}
body.android #v-tv.cinema .tvwrap>.panel:last-child{display:flex!important;flex-direction:column;align-items:center;gap:8px;overflow:visible;padding:0!important;border:0!important;background:none!important;height:100%}
body.android #v-tv.cinema .stage{width:min(100%,calc((100vh - 120px) * 16 / 9))!important;margin:0 auto}
body.android #v-tv.cinema .cinebar{width:100%;flex-wrap:nowrap;gap:10px}
body.android #v-tv.cinema .cinebar .btn{min-height:50px;font-size:16px;padding-inline:16px;white-space:nowrap}
body.android #v-tv.cinema .cinename{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:center}
body.android #v-tv.cinema .tvwrap>.panel:last-child>.row,body.android #v-tv.cinema #epgBox{display:none!important}
/* ecrã inteiro do vídeo (OK no vídeo) */
body.android.vfull #v-tv.cinema .cinebar,body.android.vfull #v-tv.cinema .tvwrap>.panel:last-child>.row{display:none!important}
body.android.vfull .app.cinema main{padding:0!important}
body.android.vfull #v-tv.cinema .tvwrap>.panel:last-child{justify-content:center}
body.android.vfull .app{padding:0!important}
body.android.vfull #v-tv.cinema .stage{position:fixed!important;inset:0;z-index:60;width:100vw!important;height:100vh!important;max-height:none;aspect-ratio:auto!important;border-radius:0!important;margin:0!important;background:#000}
body.android.vfull #stage .slot{width:100%!important;height:100%!important;aspect-ratio:auto!important;border-radius:0!important}
body.android.vfull #stage video{object-fit:contain}
body.android.vfull #stage:focus-visible{outline:none!important;box-shadow:none!important}
#fsName{position:fixed;left:24px;bottom:24px;z-index:80;background:rgba(0,0,0,.72);color:#fff;font:600 24px var(--f-display,sans-serif);padding:10px 20px;border-radius:12px;opacity:0;transition:opacity .25s;pointer-events:none;max-width:80vw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#fsName.on{opacity:1}
body.android .top .btn[aria-pressed="true"]{background:var(--accent);color:var(--accent-ink);border-color:var(--accent)}
"""

# --- Explorar na TV: o leitor «cinema» do Explorar tem o mesmo desenho que o ecrã nativo (barra global, lista à esquerda, vídeo + comandos à direita)
import re as _re
_a = CSS.index("/* ===== Explorar: mesmo desenho"); _b = CSS.index("/* telemóvel na horizontal (Explorar)")
_extra = []
for _m in _re.finditer(r"([^{}]+)\{([^{}]*)\}", CSS[_a:_b]):
    _sels = []
    for _s in _m.group(1).split(","):
        _s = _s.strip().split("*/")[-1].strip()
        if "#v-tv:not(.cinema)" in _s and "pland" not in _s and "phone" not in _s:
            _t = _s.replace("#v-tv:not(.cinema)", "#v-tv.cinema")
            _t = _re.sub(r"^body\.android(\.tv)?(?=[ ])", "body.android.tv:not(.vfull)", _t)
            _sels.append(_t)
    if _sels: _extra.append(",".join(_sels) + "{" + _m.group(2) + "}")
CSS += "\n/* ===== Explorar (TV): modo leitor com o mesmo desenho do ecrã nativo ===== */\n" + "\n".join(_extra) + """
body.android.tv:not(.vfull) .app.cinema{grid-template-rows:54px 1fr!important}
body.android.tv:not(.vfull) .app.cinema .top{display:flex!important}
body.android.tv:not(.vfull) .app.cinema main{grid-row:2!important;padding:0!important}
body.android.tv:not(.vfull) #v-tv.cinema .tvwrap{display:grid!important;grid-template-columns:minmax(260px,360px) minmax(0,1fr)!important;grid-template-rows:minmax(0,1fr);gap:18px;height:100%}
body.android.tv:not(.vfull) #v-tv.cinema .tvwrap>.panel:last-child{padding:18px!important;border:1px solid var(--line)!important;background:var(--panel)!important}
body.android.tv #v-tv>.row{display:none!important}
body.android.nscdiv #v-tv{visibility:hidden!important}
/* Guia na TV: ecrã mais denso (mais canais e programas visíveis) */
body.android.tv #gdDlg .gdbox{zoom:.72;width:calc(97vw / .72)!important;height:calc((100vh - 82px) / .72)!important;max-width:none!important}
body.android.tv #gdDlg .gdgrid{grid-template-columns:minmax(330px,400px) minmax(0,1fr)!important}
body.android.tv:not(.vfull) #v-tv{padding-top:20px!important;box-sizing:border-box}
body.android.tv:not(.vfull) #v-tv .tvwrap>.panel:first-child{display:grid!important;grid-template-columns:minmax(0,1fr) 58px;grid-template-rows:auto auto auto auto minmax(0,1fr) auto auto;gap:8px;align-content:stretch;min-height:0;overflow:hidden;padding:12px!important;height:100%}
body.android.tv:not(.vfull) #v-tv .tvwrap>.panel:first-child>*{grid-column:1/-1;min-width:0}
body.android.tv:not(.vfull) #v-tv .tvwrap>.panel:first-child>.tabs{grid-row:1;grid-template-columns:repeat(3,minmax(0,1fr))!important}
body.android.tv:not(.vfull) #v-tv .tvwrap>.panel:first-child .tabs .tab{min-height:38px!important;font-size:14px!important}
body.android.tv:not(.vfull) #v-tv #tvSearch{grid-row:2;grid-column:1!important;min-height:46px}
body.android.tv:not(.vfull) #v-tv #tvGroup{grid-row:3;min-height:46px;font-size:16px;font-weight:700;border-radius:12px}
body.android.tv:not(.vfull) #v-tv #voiceBtn{grid-row:2;grid-column:2!important;min-height:46px;padding:0;font-size:0!important;display:flex;align-items:center;justify-content:center}body.android.tv:not(.vfull) #v-tv #voiceBtn svg{width:26px;height:26px}
body.android.tv:not(.vfull) #v-tv #freeTools{grid-row:4}
body.android.tv:not(.vfull) #v-tv #tvList{grid-row:5;height:auto!important;max-height:none!important;min-height:0;overflow-y:auto}
body.android.tv:not(.vfull) #v-tv #btnOrg{grid-row:6;min-height:40px}
body.android.tv:not(.vfull) #v-tv #tvCount{grid-row:7}
body.android.tv:not(.vfull) #v-tv #chFull{grid-column:16/20!important}
body.android.tv:not(.vfull) #v-tv #chClose{grid-row:2;grid-column:20/21;min-height:48px!important;border-radius:999px!important;padding:0!important;font-size:22px!important;background:#C0334B!important}
body.android #v-tv:not(.cinema) #chMute,body.android.tv:not(.vfull) #v-tv.cinema #chMute{grid-row:6;grid-column:16/21}
"""

rep("</style>", CSS + "</style>", count=h.count("</style>")) if h.count("</style>") == 1 else None
if h.count("</style>") != 1:
    i = h.rfind("</style>", 0, h.find("<body")); h = h[:i] + CSS + h[i:]

JS = r"""
<script>
/* ===== Cockpit TV (Android): só IPTV ===== */
(function(){
  if(!window.ANDROID) return;
  document.body.classList.add("android");
  const top = document.querySelector(".top"), sp = top.querySelector(".spacer");
  const mk = (txt, v) => { const b = document.createElement("button"); b.className = "btn"; b.textContent = txt; b.onclick = () => show(v); b.dataset.v = v; top.insertBefore(b, sp); return b; };
  const bTv = mk("📺 TV", "tv"), bSet = mk("⚙ Definições", "settings");
  const sync = () => { bTv.setAttribute("aria-pressed", currentView === "tv" ? "true" : "false"); bSet.setAttribute("aria-pressed", currentView === "settings" ? "true" : "false"); };
  const _show = window.show;
  window.show = function(v){ const r = _show.apply(this, arguments); sync(); return r; };
  sync();

  /* Definições: só o que interessa à TV (cartões "TV e IPTV" e "Cópia de segurança") */
  const keep = ["TV e IPTV", "Cópia de segurança"];
  $("v-settings").querySelectorAll(".setgrp, .setcard").forEach(e => {
    if(e.classList.contains("setgrp")){ e.hidden = true; return; }
    const t = (e.querySelector("h2") || {}).textContent || "";
    if(!keep.includes(t.trim())) e.hidden = true;
  });
  const tvCard = [...$("v-settings").querySelectorAll(".setcard")].find(e => (e.querySelector("h2") || {}).textContent.trim() === "TV e IPTV");
  if(tvCard){ const info = document.createElement("p"); info.className = "small muted"; info.style.margin = "0"; info.textContent = "Esta aplicação liga-se diretamente ao servidor IPTV (não precisa de proxy)."; tvCard.insertBefore(info, tvCard.children[1] || null); }

  /* Ficheiro de exportação: o Android abre o seletor para escolheres a pasta e o nome */
  window.androidSaved = (ok, where) => { orgXferMsg(ok ? "Ficheiro guardado: " + where : "Não guardei o ficheiro (cancelaste ou não há seletor de ficheiros). Copia o código da caixa em baixo.", !ok); };
  const eb = $("orgExpFile");
  if(eb){ eb.textContent = "Guardar ficheiro…"; eb.onclick = () => {
    const txt = JSON.stringify(orgExport($("orgInclAcc").checked), null, 1); $("orgXfer").value = txt;
    let ok = false; try{ ok = Android.saveText("cockpit-iptv-definicoes.json", txt); }catch(e){}
    if(!ok) orgXferMsg("Não consegui abrir o seletor. Copia o código da caixa.", true);
  }; }

  /* Informar a parte nativa do Referer a usar nos canais abertos (RTP, SIC, …) */
  const _pc = window.playChannel;
  window.playChannel = function(c){ try{ Android.ctx(refFor(c) || ""); }catch(e){} return _pc.apply(this, arguments); };


  /* ===== Navegação com o comando da TV (D-pad) ===== */
  let dpad = false;
  try{ if(Android.isTv && Android.isTv()){ document.body.classList.add("tv"); dpad = true; } }catch(e){}
  /* Toque ou rato: deixa de ser navegação com o comando. Tocar num campo de texto abre logo o teclado (antes era escondido e ficava a piscar). */
  document.addEventListener("pointerdown", e => {
    dpad = false;
    const t = e.target && e.target.closest ? e.target.closest(TXT) : null;
    if(t){ if(editing && editing !== t) editing = null; t.readOnly = false; }
  }, true);
  const FOC = 'button:not([disabled]),a[href],input:not([type=hidden]):not([disabled]),select:not([disabled]),textarea:not([disabled]),summary,label.btn,[tabindex="0"]';
  const TXT = 'input:not([type]),input[type=text],input[type=search],input[type=url],input[type=password],input[type=email],input[type=number],input[type=tel],textarea';
  const isTxt = el => !!(el && el.matches && el.matches(TXT));
  const prep = () => { document.querySelectorAll(".gdp:not([tabindex])").forEach(e => { e.tabIndex = 0; }); document.querySelectorAll("label.btn").forEach(l => { if(!l.hasAttribute("tabindex")) l.tabIndex = 0; }); const st = $("stage"); if(st && !st.hasAttribute("tabindex")) st.tabIndex = 0; };
  prep();
  const vis = el => el.getClientRects().length > 0 && getComputedStyle(el).visibility !== "hidden" && !el.closest("[inert]");
  const openDlg = () => document.querySelector(".epgdlg:not([hidden]),.trkdlg:not([hidden]),#thSrch,#thRmDlg");
  const focusables = () => [...(openDlg() || document).querySelectorAll(FOC)].filter(vis);
  const cinema = () => document.querySelector(".app").classList.contains("cinema");
  const scrollParent = el => { for(let n = el; n && n !== document.body; n = n.parentElement){ const s = getComputedStyle(n); if(/(auto|scroll)/.test(s.overflowY) && n.scrollHeight > n.clientHeight + 4) return n; } return document.scrollingElement; };
  const kb = (on) => { try{ on ? Android.showKeyboard() : Android.hideKeyboard(); }catch(e){} };

  /* Campos de texto: o foco com as setas não abre o teclado; só o OK começa a escrever */
  let editing = null;
  const startEdit = el => {
    if(dpad && window.ANDROID){
      try{
        const ttl = el.getAttribute("aria-label") || el.placeholder || el.title || "Escrever";
        window.__askCb = v => {
          window.__askCb = null;
          if(v !== null){
            el.readOnly = false; el.value = v;
            el.dispatchEvent(new Event("input", {bubbles:true})); el.dispatchEvent(new Event("change", {bubbles:true}));
            window.__synth = 1;
            try{ ["keydown","keyup"].forEach(t => el.dispatchEvent(new KeyboardEvent(t, {key:"Enter", code:"Enter", keyCode:13, which:13, bubbles:true, cancelable:true}))); }catch(x){}
            window.__synth = 0;
            el.readOnly = true;
          }
          try{ el.focus({preventScroll:true}); }catch(x){}
        };
        Android.askText(String(ttl).slice(0, 80), el.value || "", el.type === "password");
        return;
      }catch(x){ window.__askCb = null; }
    }
    editing = el; el.readOnly = false;
    /* o campo já tinha o foco só de leitura: volta a focar para o Android ligar o teclado ao campo */
    el.blur(); editing = el;
    setTimeout(() => { editing = el; el.readOnly = false; el.focus(); try{ const n = el.value.length; el.setSelectionRange(n, n); }catch(x){} kb(true); setTimeout(() => kb(true), 250); }, 40);
  };
  const endEdit = () => { if(editing){ const el = editing; editing = null; el.readOnly = true; kb(false); } };
  document.addEventListener("focusin", e => { const el = e.target; if(dpad && isTxt(el) && el !== editing){ el.readOnly = true; kb(false); } }, true);
  let refocusing = 0;
  document.addEventListener("focusout", e => { if(e.target === editing && !refocusing){ setTimeout(() => { if(editing === e.target && document.activeElement !== e.target) endEdit(); }, 120); } }, true);

  /* Atalhos sem medir centenas de elementos: listas e filas do Início */
  function fastMove(cur, dx, dy){
    if(!cur || cur === document.body) return false;
    const go = el => { if(!el) return false; el.focus({preventScroll:true}); el.scrollIntoView({block:"nearest", inline:"nearest"});
      /* Início: ao subir para o hero/filtros, volta ao topo para a pré-visualização não ficar cortada */
      if(currentView === "tvhome" && el.closest && (el.closest("#thHero") || el.classList.contains("thKind") || el.classList.contains("thTab"))){ let n = el.parentElement; while(n && n !== document.documentElement){ if(n.scrollTop > 0) n.scrollTop = 0; n = n.parentElement; } const se = document.scrollingElement; if(se && se.scrollTop > 0) se.scrollTop = 0; }
      return true; };
    const sib = (el, f) => { let n = el; do{ n = f > 0 ? n.nextElementSibling : n.previousElementSibling; }while(n && !(n.matches && n.matches(FOC) && vis(n))); return n; };
    if(dy && cur.classList && (cur.classList.contains("gch") || cur.classList.contains("gdp"))) return go(sib(cur, dy));
    const row = cur.closest && cur.closest("#tvList > .item");
    if(row && dy){
      const idx = [...row.querySelectorAll(FOC)].indexOf(cur); let n = row;
      do{ n = dy > 0 ? n.nextElementSibling : n.previousElementSibling; }while(n && !n.querySelector(FOC));
      if(n){ const f = [...n.querySelectorAll(FOC)]; return go(f[Math.min(Math.max(idx, 0), f.length - 1)]); }
      return false;
    }
    if(currentView === "tvhome" && dy){
      const kp = () => document.querySelector(".thKind[aria-pressed=true]") || document.querySelector(".thKind");
      const hero = () => document.querySelector("#thHero .thBtn.pri") || document.querySelector("#thHero .thBtn");
      const firstCard = () => { const c = document.querySelector(".thRow .thCard"); return c; };
      if(cur.classList.contains("thTab")){ window.__lastTab = cur; if(dy > 0) return go(hero() || kp() || firstCard()); }
      else if(cur.closest("#thHero")){ if(dy > 0) return go(kp() || firstCard()); const lt = window.__lastTab && document.contains(window.__lastTab) ? window.__lastTab : null; const t = lt || document.querySelector(".thTab[aria-current=page]"); if(t) return go(t); }
      else if(cur.classList.contains("thKind")){
        if(dy < 0) return go(hero() || (window.__lastTab && document.contains(window.__lastTab) ? window.__lastTab : null) || document.querySelector(".thTab[aria-current=page]"));
        const row = document.querySelector(".thRow"); if(row){ const cx = cur.getBoundingClientRect().left + cur.offsetWidth / 2; let best = null, bd = Infinity; for(const c of row.querySelectorAll(".thCard")){ const r = c.getBoundingClientRect(), d = Math.abs(r.left + r.width / 2 - cx); if(d < bd){ bd = d; best = c; } } return go(best); }
      }
      else if(dy < 0 && cur.classList.contains("thCard") && cur.closest(".thRow") && !cur.closest(".thRow").previousElementSibling.classList.contains("thRow")) return go(kp());
    }
    const sc = cur.closest && cur.closest(".thScroll");
    if(sc && dx && cur.classList.contains("thCard")) return go(sib(cur, dx));
    if(sc && dy){
      const tr = cur.closest(".thRow"); let n = tr;
      do{ n = dy > 0 ? n.nextElementSibling : n.previousElementSibling; }while(n && !n.querySelector(".thCard"));
      if(!n || !n.classList.contains("thRow")) return false;
      const cx = cur.getBoundingClientRect().left + cur.offsetWidth / 2; let best = null, bd = Infinity;
      for(const c of n.querySelectorAll(".thCard")){ const r = c.getBoundingClientRect(), d = Math.abs(r.left + r.width / 2 - cx); if(d < bd){ bd = d; best = c; } }
      return go(best);
    }
    return false;
  }
  function simpleMove(dx, dy){
    const cur = document.activeElement, els = focusables(); if(!els.length) return false;
    if(!cur || cur === document.body || !els.includes(cur)){ const f = els.find(e => !(e.closest && e.closest(".top"))) || els[0]; f.focus({preventScroll:true}); return true; }
    const cr = cur.getBoundingClientRect(), cx = cr.left + cr.width / 2, cy = cr.top + cr.height / 2;
    let best = null, bd = 1e12;
    for(const el of els){
      if(el === cur) continue; const r = el.getBoundingClientRect(); const mx = r.left + r.width / 2 - cx, my = r.top + r.height / 2 - cy;
      if(dx && mx * dx <= 1) continue; if(dy && my * dy <= 1) continue;
      const d = dx ? Math.abs(mx) + Math.abs(my) * 3 : Math.abs(my) + Math.abs(mx) * 3;
      if(d < bd){ bd = d; best = el; }
    }
    if(!best) return false;
    best.focus({preventScroll:true}); best.scrollIntoView({block:"nearest", inline:"nearest"}); return true;
  }
  function move(dx, dy){
    if(fastMove(document.activeElement, dx, dy)) return;
    const els = focusables(), cur = document.activeElement;
    if(!cur || cur === document.body || !els.includes(cur)){
      const lost = (currentView === "tvhome" ? document.querySelector("#v-tvhome .thBtn.pri,#v-tvhome .thCard,#v-tvhome .thBtn") : null) || els.find(e => !(e.closest && e.closest(".top"))) || els[0];
      if(lost) lost.focus({preventScroll:true}); return;
    }
    const cr = cur.getBoundingClientRect(), ccx = cr.left + cr.width/2, ccy = cr.top + cr.height/2;
    const inTop = e => !!(e.closest && e.closest(".top"));
    if(inTop(cur) && cur.classList && cur.classList.contains("thTab")) window.__lastTab = cur;
    /* Da barra do topo para baixo: entra no conteúdo pelo sítio certo de cada ecrã */
    const entry = () => {
      const q = sel => { const e = document.querySelector(sel); return e && vis(e) ? e : null; };
      if(currentView === "tv") return q('#v-tv .tab[data-kind][aria-selected="true"]') || q("#tvSearch") || q("#tvList .item button");
      if(currentView === "settings") return q("#tvSetGrid .setHead") || null;
      if(currentView === "tvlive") return q("#tvLiveList button") || q("#tvLiveOpen");
      return null;
    };
    if(dy > 0 && inTop(cur) && !openDlg()){
      const en = entry(); if(en){ en.focus({preventScroll:true}); en.scrollIntoView({block:"nearest"}); return; }
      const body = els.filter(e => !inTop(e));
      if(body.length){
        const mt = Math.min(...body.map(e => e.getBoundingClientRect().top));
        let best = null, bd = Infinity;
        for(const e of body){ const r = e.getBoundingClientRect(); if(r.top > mt + 60) continue; const d = Math.abs(r.left + r.width / 2 - ccx); if(d < bd){ bd = d; best = e; } }
        if(best){ best.focus({preventScroll:true}); best.scrollIntoView({block:"nearest", inline:"nearest"}); return; }
      }
    }
    let best = null, bs = Infinity;
    for(const el of els){
      if(el === cur) continue;
      const r = el.getBoundingClientRect(), cx = r.left + r.width/2, cy = r.top + r.height/2;
      let main, cross;
      if(dx){ if((cx - ccx) * dx <= 1) continue; main = Math.max(0, dx > 0 ? r.left - cr.right : cr.left - r.right); cross = Math.max(0, r.top - cr.bottom, cr.top - r.bottom); }
      else  { if((cy - ccy) * dy <= 1) continue; main = Math.max(0, dy > 0 ? r.top - cr.bottom : cr.top - r.bottom); cross = Math.max(0, r.left - cr.right, cr.left - r.right); }
      const off = dx ? Math.abs(cy - ccy) : Math.abs(cx - ccx);
      const sc = main + cross * 3 + off * 0.15;
      if(sc < bs){ bs = sc; best = el; }
    }
    /* Para cima, quando já não há nada acima no conteúdo: volta ao separador atual (caminho inverso) */
    /* linha de cima do conteúdo: Cima volta ao separador atual */
    const topRow = (() => { const body = els.filter(e => !inTop(e)); if(!body.length) return false; const mt = Math.min(...body.map(e => e.getBoundingClientRect().top)); return cr.top <= mt + 16; })();
    if(dy < 0 && !inTop(cur) && !openDlg() && (!best || inTop(best) || topRow || (currentView === "tv" && cur.matches && cur.matches("#v-tv .tab[data-kind]")))){
      const lt = window.__lastTab && document.contains(window.__lastTab) && vis(window.__lastTab) ? window.__lastTab : null; const t = lt || document.querySelector(".thTab[aria-current=page]") || (best && inTop(best) ? best : null) || document.querySelector(".thTab");
      if(t){ t.focus({preventScroll:true}); return; }
    }
    if(best){ best.focus({preventScroll:true}); best.scrollIntoView({block:"nearest", inline:"nearest"}); }
    else if(dy){ const sp = scrollParent(cur); if(sp) sp.scrollBy(0, dy * 180); }
  }
  const clickId = id => { const b = $(id); if(b) b.click(); };
  const onStage = () => document.activeElement === $("stage");
  let lastItem = null;
  const fsEl = document.createElement("div"); fsEl.id = "fsName"; document.body.appendChild(fsEl);
  let fsT = 0;
  const flashName = () => { if(!document.body.classList.contains("vfull")) return; fsEl.textContent = $("chName").textContent; fsEl.classList.add("on"); clearTimeout(fsT); fsT = setTimeout(() => fsEl.classList.remove("on"), 2600); };
  const setVfull = on => { document.body.classList.toggle("vfull", !!on); if(on) flashName(); else fsEl.classList.remove("on"); };
  new MutationObserver(flashName).observe($("chName"), {childList:true, characterData:true, subtree:true});

  /* Ao escolher um canal (OK) passa para o ecrã do leitor; Voltar regressa à lista */
  $("tvList").addEventListener("click", e => {
    const b = e.target.closest("[data-play]"); if(!b || !dpad) return;
    lastItem = b;
    setTimeout(() => {
      if($("stage").classList.contains("single") && currentView === "tv" && !(window.DET && DET.open)){ setVfull(false); if(!cinema()) setCinema(true); $("stage").focus({preventScroll:true}); }
    }, 60);
  });

  /* Nome da tecla: alguns comandos/TVs enviam key vazio ou "Unidentified" para o OK e para as teclas de multimédia */
  const KC = {13:"Enter", 23:"Enter", 66:"Enter", 160:"Enter", 19:"ArrowUp", 20:"ArrowDown", 21:"ArrowLeft", 22:"ArrowRight", 33:"PageUp", 34:"PageDown", 166:"ChannelUp", 167:"ChannelDown", 85:"MediaPlayPause", 179:"MediaPlayPause", 126:"MediaPlay", 127:"MediaPause", 86:"MediaStop", 90:"MediaFastForward", 89:"MediaRewind", 87:"MediaTrackNext", 88:"MediaTrackPrevious", 175:"Guide", 172:"Guide", 165:"Info", 82:"ContextMenu", 4:"GoBack", 111:"Escape", 84:"Voice", 219:"Voice", 231:"Voice"};
  const keyName = e => { const k = e.key; if(k && k !== "Unidentified" && k !== "Dead") return k === "Return" ? "Enter" : k; if(e.code === "NumpadEnter" || e.code === "Enter") return "Enter"; return KC[e.keyCode || e.which] || k || ""; };
  /* diagnóstico: mostra no ecrã o último erro de JavaScript (para saber porque falha algo) */
  (function(){
    let bar = null, t = 0;
    const show = m => { window.__kerr = m; try{ if(!bar){ bar = document.createElement("div"); bar.id = "kerrBar"; bar.style.cssText = "position:fixed;left:8px;bottom:8px;max-width:70vw;z-index:2147483000;background:#7a1020ee;color:#fff;font:12px/1.3 monospace;padding:6px 10px;border-radius:8px;pointer-events:none"; document.body.appendChild(bar); } bar.textContent = "⚠ " + m; bar.style.display = "block"; clearTimeout(t); t = setTimeout(() => { bar.style.display = "none"; }, 20000); }catch(e){} };
    window.addEventListener("error", ev => { if(ev && ev.target && ev.target !== window) return; show(String(ev.message || "erro") + (ev.lineno ? " (linha " + ev.lineno + ")" : "")); });
    window.addEventListener("unhandledrejection", ev => { show("promessa: " + String(ev.reason && ev.reason.message || ev.reason)); });
  })();
  const keyHandler = e => {
    const a = document.activeElement, k = keyName(e);
    if(e.altKey || e.ctrlKey || e.metaKey) return;
    if(!exitDlg.hidden){   /* janela "Sair?": só Esq./Dir. e OK */
      if(k === "ArrowLeft" || k === "ArrowRight"){ e.preventDefault(); e.stopImmediatePropagation(); ($("exNo") === a ? $("exYes") : $("exNo")).focus(); }
      else if(k === "Enter"){ if(a && a.id !== "exNo" && a.id !== "exYes"){ e.preventDefault(); e.stopImmediatePropagation(); $("exNo").focus(); } }
      else if(k === "GoBack" || k === "Escape" || k === "MediaStop"){ e.preventDefault(); e.stopImmediatePropagation(); exClose(); }
      else { e.preventDefault(); e.stopImmediatePropagation(); }
      return;
    }
    const arrow = {ArrowUp:[0,-1], ArrowDown:[0,1], ArrowLeft:[-1,0], ArrowRight:[1,0]}[k];
    if(arrow || k === "PageUp" || k === "PageDown") dpad = true;
    /* a app original muda de canal com Cima/Baixo: aqui isso fica só para o ecrã do leitor */
    const eat = () => { e.preventDefault(); e.stopImmediatePropagation(); };
    if(window.__nxKey && (k === "Enter" || k === "GoBack") && window.__nxKey(k)){ eat(); return; }

    /* escrever num campo */
    if(editing && a === editing){
      if(k === "Enter"){ const el = editing; setTimeout(() => { if(editing === el) endEdit(); }, 30); return; }   /* deixa a pesquisa do campo correr e fecha o teclado */
      if(k === "ArrowUp" || k === "ArrowDown"){ eat(); endEdit(); move(0, arrow[1]); return; }
      return; /* resto das teclas escreve normalmente */
    }
    if(k === "Enter" && isTxt(a) && (a.readOnly || dpad) && !window.__synth){ eat(); startEdit(a); return; }

    if(window.NATIVE && NATIVE.active){
      if(k === "MediaPlayPause" || k === "MediaPlay" || k === "MediaPause"){ eat(); try{ Android.ntoggle(); }catch(x){} return; }
      if((k === "MediaFastForward" || k === "MediaRewind") && !NATIVE.live){ eat(); try{ Android.nseek(k === "MediaFastForward" ? 30000 : -30000); }catch(x){} return; }
    }
    if(k === "Voice" && window.__voice){ eat(); window.__voice(); return; }
    if(k === "Guide" || k === "Info"){ const g = $("chGuide"); if(g && g.offsetParent){ eat(); g.click(); } return; }
    if(k === "ContextMenu" || k === "Settings"){ eat(); if(currentView === "tv" && cinema() && typeof trkOpen === "function") trkOpen(); else show("settings"); return; }
    if(k === "MediaStop" || k === "GoBack" || k === "Escape"){ eat(); window.androidBack(); return; }
    if(k === "MediaTrackNext"){ eat(); clickId("chNext"); return; }
    if(k === "MediaTrackPrevious"){ eat(); clickId("chPrev"); return; }
    if(k === "MediaFastForward" || k === "MediaRewind"){ const v = $("vid" + (typeof tvTarget === "number" ? tvTarget : 0)); if(v && isFinite(v.duration) && v.duration > 0){ eat(); v.currentTime = Math.max(0, Math.min(v.duration, v.currentTime + (k === "MediaFastForward" ? 30 : -30))); } return; }
    if(k === "ChannelUp"){ eat(); clickId("chNext"); return; }
    if(k === "ChannelDown"){ eat(); clickId("chPrev"); return; }
    if(k === "PageDown" || k === "PageUp"){ eat(); clickId(k === "PageDown" ? "chNext" : "chPrev"); return; }
    if(k === "MediaPlayPause" || k === "MediaPlay" || k === "MediaPause"){
      const v = $("vid" + (typeof tvTarget === "number" ? tvTarget : 0)); if(v){ eat(); (k === "MediaPause" || (k === "MediaPlayPause" && !v.paused)) ? v.pause() : v.play().catch(()=>{}); } return; }

    if(arrow){
      if(arrow[0] && a && a.type === "range") return;
      eat();
      if(onStage() && cinema() && !openDlg()){
        /* filmes e episódios: Esq./Dir. duas vezes seguidas recuam/avançam 10 s (e continua a saltar enquanto carregares depressa) */
        if(arrow[0]){
          const lp = (typeof lastPlayed !== "undefined" && lastPlayed[0]) || null;
          if(lp && lp.kind !== "live"){
            const now = Date.now(), dir = arrow[0];
            if(window.__lr && window.__lr.d === dir && now - window.__lr.t < 480){
              window.__lr.t = now;
              try{
                if(window.NATIVE && NATIVE.active) Android.nseek(dir * 10000);
                else { const v = $("vid0"); if(v && isFinite(v.duration)) v.currentTime = Math.max(0, Math.min(v.duration, v.currentTime + dir * 10)); }
              }catch(x){}
              const msg = (dir < 0 ? "⏪ −10 s" : "+10 s ⏩");
              try{ if(typeof Android.nhud === "function") Android.nhud(msg); }catch(x){}
              try{ toast(msg); }catch(x){}
              clearTimeout(window.__lrT); window.__lrT = setTimeout(() => { try{ if(typeof Android.nhud === "function") Android.nhud(""); }catch(x){} }, 1100);
            } else window.__lr = {d:dir, t:now};
            return;
          }
        }
        /* ecrã inteiro: todas as setas mudam de canal; com a barra visível: Baixo vai para os botões, Esq./Dir. mudam de canal */
        if(document.body.classList.contains("vfull")){ clickId(arrow[1] < 0 || arrow[0] > 0 ? "chNext" : "chPrev"); return; }
        if(arrow[1] > 0){ const f = [...document.querySelectorAll("#v-tv .cinebar .btn")].find(b => !b.disabled && vis(b)); if(f) f.focus({preventScroll:true}); return; }
        if(arrow[0]) clickId(arrow[0] < 0 ? "chPrev" : "chNext");
        return;
      }
      /* barra de topo -> Baixo: volta ao último canal/filme em que estava (em vez do primeiro botão) */
      if(arrow[1] > 0 && !arrow[0] && currentView === "tvhome" && a && a.closest && a.closest(".top") && typeof window.__homeLastCard === "function"){
        const lc = window.__homeLastCard();
        if(lc && lc.isConnected){ lc.focus({preventScroll:true}); try{ lc.scrollIntoView({block:"center", inline:"center"}); }catch(x){} return; }
      }
      const before = document.activeElement;
      try{ move(arrow[0], arrow[1]); }catch(err){ window.__kerr = String(err && err.message || err); try{ if(simpleMove(arrow[0], arrow[1])) return; }catch(x){} }
      /* rede de segurança: se o foco não mexeu, tenta o movimento simples (por posição) */
      setTimeout(() => { const n = document.activeElement; if(n === before || n === document.body){ try{ simpleMove(arrow[0], arrow[1]); }catch(x){} } }, 70);
      return;
    }
    if(k === "Enter" && a){
      if(a.classList && (a.classList.contains("setHead") || (a.closest && a.closest("#tvLiveList")))){ e.preventDefault(); e.stopImmediatePropagation(); a.click(); return; }
      if(a === $("stage") && cinema()){ eat(); setVfull(!document.body.classList.contains("vfull")); return; }   /* OK no vídeo: ecrã inteiro / sair do ecrã inteiro */
      if(a.type === "checkbox" || a.type === "radio" || a.tagName === "LABEL" || (a.classList && a.classList.contains("gdp"))){ e.preventDefault(); a.click(); }
    }
  };
  document.addEventListener("keydown", e => {
    try{ keyHandler(e); }
    catch(err){
      window.__kerr = String(err && err.message || err);
      const m = {ArrowUp:[0,-1], ArrowDown:[0,1], ArrowLeft:[-1,0], ArrowRight:[1,0]}[keyName(e)];
      if(m){ try{ e.preventDefault(); e.stopImmediatePropagation(); simpleMove(m[0], m[1]); }catch(x){} }
    }
  }, true);

  /* Foco inicial e foco ao abrir/fechar janelas */
  setTimeout(() => { if(!document.activeElement || document.activeElement === document.body) bTv.focus(); }, 600);
  let prevFocus = null;
  new MutationObserver(() => {
    prep();
    const d = openDlg();
    if(d && !d.contains(document.activeElement)){ if(!prevFocus) prevFocus = document.activeElement; const f = [...d.querySelectorAll(FOC)].filter(vis)[0]; if(f) f.focus(); }
    else if(!d && prevFocus){ const p = prevFocus; prevFocus = null; if(p !== document.body && document.contains(p) && vis(p)) p.focus(); }
  }).observe(document.body, {subtree:true, attributes:true, attributeFilter:["hidden"]});

  /* Botão Voltar */
  /* Confirmação ao sair da app */
  const exitDlg = document.createElement("div"); exitDlg.id = "exitDlg"; exitDlg.hidden = true;
  exitDlg.innerHTML = '<div class="exBox" role="dialog" aria-modal="true"><h2>Sair do Cockpit TV?</h2><p>Queres mesmo fechar a app?</p><div class="exBt"><button class="btn" id="exNo">Ficar</button><button class="btn" id="exYes">Sair</button></div></div>';
  document.body.appendChild(exitDlg);
  const exClose = () => { exitDlg.hidden = true; document.body.classList.remove("exitOpen"); if(exPrev && document.contains(exPrev)) try{ exPrev.focus({preventScroll:true}); }catch(x){} exPrev = null; };
  let exPrev = null;
  const exOpen = () => { try{ if(typeof Android.showExit === "function"){ Android.showExit(); return; } }catch(x){} exPrev = document.activeElement; exitDlg.hidden = false; document.body.classList.add("exitOpen"); setTimeout(() => $("exNo").focus(), 30); };
  $("exNo").onclick = exClose;
  $("exYes").onclick = () => { try{ Android.exitApp(); }catch(x){} };
  window.androidBack = function(){
    if(!exitDlg.hidden){ exClose(); return true; }
    if(editing){ endEdit(); return true; }
    { const rm = document.getElementById("thRmDlg"); if(rm){ const x = rm.querySelector('[data-x="0"]'); if(x) x.click(); else rm.remove(); return true; } }
    { const sr = document.getElementById("thSrch"); if(sr){ const x = sr.querySelector("#thSrX"); if(x) x.click(); else sr.remove(); return true; } }   /* pesquisa do Início: Voltar fecha */
    const d = document.querySelector(".epgdlg:not([hidden]),.trkdlg:not([hidden])");
    if(d){ const b = [...d.querySelectorAll("button")].find(x => /^(fechar|✕|×|close)/i.test(x.textContent.trim())); if(b) b.click(); else d.hidden = true; return true; }
    if(document.querySelector(".app").classList.contains("cinema")){
      if(document.body.classList.contains("vfull")){ setVfull(false); $("stage").focus({preventScroll:true}); return true; }
      if(!onStage() && $("stage").offsetParent){ $("stage").focus({preventScroll:true}); return true; }   /* dos botões volta ao vídeo */
      setCinema(false); setVfull(false); if(window.__stopPlayback) window.__stopPlayback();
      if(window.__homeOrigin){ window.__homeOrigin = false; show("tvhome"); return true; }
      setTimeout(() => { const it = lastItem && document.contains(lastItem) && vis(lastItem) ? lastItem : null; (it || bTv).focus(); if(it) it.scrollIntoView({block:"nearest"}); }, 60);
      return true;
    }
    if(currentView === "settings"){ show("tvhome"); return true; }
    if(currentView === "tv"){ show("tvhome"); return true; }
    exOpen(); return true;
  };
})();
</script>
"""

JS2 = r'''
<script>
/* ===== Cockpit TV: ecrã Início (estilo Android TV) ===== */
(function(){
  if(!window.ANDROID) return;
  const $ = id => document.getElementById(id);
  const esc = t => String(t == null ? "" : t).replace(/[&<>"]/g, m => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[m]));
  /* ===== Retomar filmes e episódios onde ficaste ===== */
  const RES = window.RES = {
    all(){ try{ return LS.get("resume", {}) || {}; }catch(e){ return {}; } },
    at(url){ const e = RES.all()[url]; return e && e.p > 30 && e.d > 0 && e.p < e.d * 0.95 ? Math.max(0, e.p - 5) : 0; },
    save(c, p, d){
      if(!c || !c.url || !(c.kind === "movie" || c.kind === "episode") || !(d > 300) || !(p >= 0)) return;
      const a = RES.all();
      if(p > d * 0.95) delete a[c.url];
      else if(p > 20) a[c.url] = {name:c.name, logo:c.logo || "", url:c.url, kind:c.kind, group:c.group || "", id:c.id || "", p:Math.round(p), d:Math.round(d), t:Date.now()};
      else return;
      const keys = Object.keys(a).sort((x, y) => a[y].t - a[x].t);
      keys.slice(40).forEach(k => delete a[k]);
      try{ LS.set("resume", a); }catch(e){}
    },
    list(kind){ return Object.values(RES.all()).filter(e => e.p > 30 && e.p < e.d * 0.95 && (kind === "movie" ? e.kind === "movie" : e.kind === "episode")).sort((x, y) => y.t - x.t); }
  };
  /* "Continuar a ver" no ecrã inicial do Android TV (Watch Next) */
  const hid = u => { let h = 2166136261; const t = String(u); for(let i = 0; i < t.length; i++){ h ^= t.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); };
  window.__hid = hid;
  (function(){
    const _rs = RES.save; let lastWn = 0;
    RES.save = function(c, p, d){
      _rs.apply(this, arguments);
      try{
        if(typeof Android.watchNext !== "function" || !c || !c.url || !(c.kind === "movie" || c.kind === "episode") || !(d > 300)) return;
        if(p > d * 0.95){ Android.watchNext(hid(c.url), "", "", 0, 0, true); return; }
        if(p > 20 && Date.now() - lastWn > 30000){ lastWn = Date.now(); Android.watchNext(hid(c.url), c.name || "", c.logo || "", Math.round(p * 1000), Math.round(d * 1000), false); }
      }catch(e){}
    };
    window.__openId = id => {
      try{ const e = Object.values(RES.all()).find(x => hid(x.url) === id); if(!e) return; window.__homeOrigin = false; show("tv"); setTimeout(() => playChannel(e), 300); }catch(x){}
    };
    try{ const id = typeof Android.pendingOpen === "function" ? Android.pendingOpen() : ""; if(id) setTimeout(() => window.__openId(id), 1800); }catch(e){}
  })();
  /* leitor da página (fora do nativo): retoma e guarda a posição */
  const _pcR = window.playChannel;
  window.playChannel = function(c){
    const r = _pcR.apply(this, arguments);
    try{
      if(c && (c.kind === "movie" || c.kind === "episode") && !(window.NATIVE && NATIVE.active)){
        const v = $("vid0"), at = RES.at(c.url);
        if(at > 0){ const go = () => { try{ if(isFinite(v.duration) && at < v.duration - 30) v.currentTime = at; }catch(e){} }; v.addEventListener("loadedmetadata", go, {once:true}); }
        if(v._resT) clearInterval(v._resT);
        v._resT = setInterval(() => { if(!lastPlayed[0] || lastPlayed[0].url !== c.url){ clearInterval(v._resT); return; } if(!v.paused && isFinite(v.duration)) RES.save(c, v.currentTime, v.duration); }, 5000);
      }
    }catch(e){}
    return r;
  };
  setInterval(() => { try{ if(NATIVE.active && !NATIVE.live && NATIVE.cur){ const [p, d, lv] = String(Android.npos()).split("|").map(Number); if(!lv) RES.save(NATIVE.cur.c, p / 1000, d / 1000); } }catch(e){} }, 5000);

  /* ===== Google Cast: envia o endereço do vídeo para a Google TV / Chromecast (só no telemóvel) ===== */
  const CAST = window.CAST = {active:false, name:"", cur:null, banner:null,
    mime(c){
      const u = c.url, fx = (typeof fileExt === "function" ? fileExt(u) : "");
      if(/\.m3u8(\?|$)/i.test(u) || (c.kind === "live" && !/\.ts(\?|$)/i.test(u) && !fx)) return "application/x-mpegURL";
      if(fx === "mpd") return "application/dash+xml";
      if(fx === "mkv") return "video/x-matroska";
      if(fx === "webm") return "video/webm";
      if(/^(ts|m2ts|mts)$/.test(fx) || /\.ts(\?|$)/i.test(u)) return "video/mp2t";
      return "video/mp4";
    },
    send(c){
      CAST.cur = c;
      let ref = ""; try{ ref = (typeof refFor === "function" && refFor(c)) || ""; }catch(e){}
      if(ref){ try{ toast("Este canal precisa de cabeçalhos especiais; a TV pode não o conseguir abrir.", true); }catch(e){} }
      try{ Android.cload(c.url, c.name || "", CAST.mime(c), c.kind === "live", Math.round(RES.at(c.url) * 1000)); }catch(e){}
      CAST.ui();
    },
    ui(){
      if(!CAST.banner){
        const d = document.createElement("div"); d.id = "castBanner"; d.hidden = true;
        d.innerHTML = '<span id="castTx"></span><button class="btn" id="castPp">⏯</button><button class="btn" id="castSt">⏹ Parar</button><button class="btn" id="castOff">Desligar</button>';
        document.body.appendChild(d); CAST.banner = d;
        $("castPp").onclick = () => { try{ Android.ctoggle(); }catch(e){} };
        $("castSt").onclick = () => { try{ Android.cmstop(); }catch(e){} };
        $("castOff").onclick = () => { try{ Android.cstop(); }catch(e){} };
      }
      CAST.banner.hidden = !CAST.active;
      $("castTx").textContent = "📡 " + (CAST.cur ? CAST.cur.name + " · " : "") + (CAST.name || "Google TV");
    },
    ev(kind, msg){
      if(kind === "connected"){
        CAST.active = true; CAST.name = msg || "Google TV";
        try{ toast("Ligado a " + CAST.name + ". Escolhe um canal, filme ou série."); }catch(e){}
        const cur = NATIVE.active && NATIVE.cur ? NATIVE.cur.c : null;
        if(cur){ NATIVE.stop(); CAST.send(cur); } else CAST.ui();
      }
      else if(kind === "ended"){ CAST.active = false; CAST.cur = null; CAST.ui(); try{ toast("Transmissão terminada."); }catch(e){} }
      else if(kind === "failed"){ try{ toast("Não consegui ligar à TV (código " + msg + ").", true); }catch(e){} }
      else if(kind === "unavailable"){ try{ toast("Google Cast indisponível neste telemóvel (precisa dos Serviços Google Play).", true); }catch(e){} }
      else if(kind === "error"){ try{ toast("Cast: " + msg, true); }catch(e){} }
    }
  };

  /* ===== Leitor externo (VLC, MX Player, Just Player, Kodi…) ===== */
  const EXTP = window.EXTP = {
    pkg(){ return LS.get("extPlayer", ""); },   // "" = desligado, "*" = perguntar sempre, senão nome do pacote
    list(){ try{ return JSON.parse(Android.extPlayers()); }catch(e){ return []; } },
    go(c){
      const k = EXTP.pkg(); if(!k || typeof Android.openExternal !== "function" || !c || !c.url || /^series:/.test(c.url)) return false;
      let r = ""; try{ r = (typeof refFor === "function" && refFor(c)) || ""; }catch(e){}
      let u = c.url; try{ if(window.__pxMode && window.__pxMode() === "all" && typeof px === "function") u = px(u, r, false); }catch(e){}
      const st = Math.round(((window.RES && RES.at(c.url)) || 0) * 1000);
      const res = Android.openExternal(u, k === "*" ? "" : k, c.name || "", r, st);
      if(res === "ok"){ EXTP.away = Date.now(); try{ toast("A abrir no leitor externo…"); }catch(e){} return true; }
      try{ toast(res === "notfound" ? "O leitor escolhido não está instalado. A usar o leitor da app." : "Não consegui abrir o leitor externo: " + res, true); }catch(e){}
      return false;
    }
  };

  /* ao regressar do leitor externo, vai para o menu inicial */
  EXTP.back = () => { try{
    if(!EXTP.away || Date.now() - EXTP.away < 1500) return; EXTP.away = 0;
    try{ if(window.__stopPlayback) window.__stopPlayback(); }catch(e){}
    try{ setCinema(false); setVfull(false); }catch(e){}
    window.__homeOrigin = false; show("tvhome");
  }catch(e){} };
  document.addEventListener("visibilitychange", () => { if(!document.hidden) EXTP.back(); });
  window.addEventListener("focus", () => EXTP.back()); window.addEventListener("pageshow", () => EXTP.back());

  /* ===== Leitor nativo (Media3/ExoPlayer) por cima da área do vídeo ===== */
  const HAS_N = typeof Android.nplay === "function";
  const NAT = window.NATIVE = {active:false, live:false, ready:false, off:new Map(), cur:null, id:0, key:"", timer:0, poll:0,
    go(c, slot, playId, fail){
      try{ if(slot === 0 && window.EXTP && EXTP.go(c)){ NAT.stop(); return true; } }catch(e){}
      try{ if(window.__NSC && __NSC.divert(c, slot)){ NAT.stop(); return true; } }catch(e){}
      if(CAST.active && slot === 0 && c && c.url && c.url.indexOf("series:") !== 0){ NAT.stop(); CAST.send(c); return true; }
      if(!HAS_N || slot !== 0 || !c || !c.url || (NAT.off.has(c.url) && Date.now() - NAT.off.get(c.url) < 8000) || !$("stage").classList.contains("single")){ NAT.stop(); return false; }
      const u = c.url, fx = (typeof fileExt === "function" ? fileExt(u) : "");
      const hint = /\.m3u8(\?|$)/i.test(u) ? "hls" : fx === "mpd" ? "dash" : (c.kind === "live" && !/\.ts(\?|$)/i.test(u) && !(typeof FILE_EXT === "function" && FILE_EXT(u))) ? "hls" : "";
      NAT.cur = {c, slot, playId, fail, url:u, triedTs:false}; NAT.live = c.kind === "live"; NAT.id = playId;
      NAT.start(u, hint, c.name);
      return true;
    },
    start(u, hint, title){
      let ref = ""; try{ ref = (typeof refFor === "function" && refFor(NAT.cur.c)) || ""; }catch(e){}
      NAT.active = true; NAT.key = ""; NAT.ready = false; if(!NAT.cur.triedTs || NAT.cur.url === u){ NAT.subBase = ""; NAT.subOff = 0; }
      try{ if(typeof Android.ndeint === "function") Android.ndeint(LS.get("tvDeint", "off") === "adapt"); if(typeof Android.nafr === "function") Android.nafr(LS.get("tvAfr", "on") !== "off"); }catch(e){}
      try{ if(window.__aspect) window.__aspect.apply(false); }catch(e){}
      try{ const pu = (window.__pxMode() === "all" && typeof px === "function") ? px(u, ref, false) : u; if(window.__pv) window.__pv.on = false; try{ if(typeof Android.nlogjs === "function") Android.nlogjs("NAT.start " + String(u).slice(-22) + " < " + String(new Error().stack || "").split("\n").slice(2, 6).map(x => x.trim().replace(/\(.*[\/]/, "(").slice(0, 60)).join(" < ")); }catch(e){} Android.nplay(pu, ref, hint, title || "", Math.round(RES.at(NAT.cur.c.url) * 1000)); try{ if(typeof Android.nvol === "function") Android.nvol(1); }catch(e){} }catch(e){ NAT.fallback("sem leitor nativo"); return; }
      clearTimeout(NAT.timer); NAT.timer = setTimeout(() => { if(NAT.active && NAT.cur && !NAT.ready) NAT.fallback("tempo esgotado"); }, 22000);
      NAT.sync(true);
      if(!NAT.poll) NAT.poll = setInterval(() => NAT.sync(false), 160);
    },
    stop(){ clearTimeout(NAT.timer); if(NAT.active){ NAT.saveNow(); NAT.active = false; NAT.cur = null; try{ Android.nstop(); }catch(e){} } },
    fallback(why){
      const cur = NAT.cur; if(!cur) return;
      if(cur.playId !== playSeq[cur.slot]) return;
      if(cur.c.kind === "live"){   /* canais em direto: tenta de novo até 3 vezes antes de mudar de leitor */
        const n = (NAT.rt && NAT.rt.url === cur.url) ? NAT.rt.n : 0;
        if(n < 3){
          NAT.rt = {url:cur.url, n:n + 1}; NAT.stop();
          try{ toast("Sem sinal. A tentar de novo (" + (n + 1) + "/3)…", true); }catch(e){}
          setTimeout(() => { if(cur.playId === playSeq[cur.slot]) window.playChannel(cur.c, cur.slot, true); }, 1500 * (n + 1));
          return;
        }
        NAT.rt = null;
      }
      NAT.off.set(cur.url, Date.now()); NAT.stop();
      if(cur.c.kind === "movie" || cur.c.kind === "episode"){ try{ toast("Leitor nativo: " + why, true); }catch(e){} return; }   /* filmes e séries: só o leitor nativo (o da página não descodifica estes ficheiros) */
      try{ toast("Leitor nativo: " + why + ". A usar o leitor da página…", true); }catch(e){}
      window.playChannel(cur.c, cur.slot, true);
    },
    sync(force){
      if(!NAT.active) return;
      const st = $("stage"); if(!st) return;
      const r = st.getBoundingClientRect(); let d = window.devicePixelRatio || 1;
      try{ if(!NAT.si || Date.now() - NAT.siT > 4000){ NAT.si = JSON.parse(Android.screenInfo()); NAT.siT = Date.now(); } if(NAT.si && NAT.si.w && window.innerWidth) d = NAT.si.w / window.innerWidth; }catch(e){}
      const blocked = !!document.querySelector(".epgdlg:not([hidden]),.trkdlg:not([hidden]),#exitDlg:not([hidden])");
      const vis = currentView === "tv" && r.width > 20 && r.height > 20 && !blocked && !document.hidden;
      const x = Math.round(r.left * d), y = Math.round(r.top * d), w = Math.round(r.width * d), h = Math.round(r.height * d);
      if(force && NAT.needStable) return;   /* a rodar: espera que a página assente */
      if(!force && NAT.holdUntil && Date.now() < NAT.holdUntil){   /* a rodar o ecrã: esconde o vídeo e não o redimensiona a meio da animação */
        if(!NAT.held){ NAT.held = true; try{ if(NAT.last) Android.nrect(NAT.last[0], NAT.last[1], NAT.last[2], NAT.last[3], false); }catch(e){} NAT.key = ""; }
        return;
      }
      const key = x + "," + y + "," + w + "," + h + "," + vis;
      if(!force && NAT.needStable){   /* depois da rotação só envia quando a posição ficou igual 0,7 s */
        if(key === NAT.lastKey) NAT.same = (NAT.same || 0) + 1; else { NAT.same = 0; NAT.lastKey = key; }
        if(NAT.same < 4) return;
        NAT.needStable = false; NAT.held = false; NAT.key = ""; NAT.pendKey = "";
        try{ Android.nrect(x, y, w, h, vis); NAT.last = [x, y, w, h]; NAT.key = key; }catch(e){}
        return;
      }
      NAT.held = false;
      /* só envia quando a posição ficou igual entre duas leituras: as animações da página (ecrã total, rotação) passam a dar uma única mudança de tamanho, não várias */
      if(!force && key !== NAT.key && key !== NAT.pendKey){ NAT.pendKey = key; return; }
      if(force || key !== NAT.key){ NAT.key = key; NAT.pendKey = ""; NAT.last = [x, y, w, h]; try{ Android.nrect(x, y, w, h, vis); }catch(e){} }
    },
    saveNow(){ try{ if(!NAT.cur || NAT.live) return; const [p, d, lv] = String(Android.npos()).split("|").map(Number); if(!lv) RES.save(NAT.cur.c, p / 1000, d / 1000); }catch(e){} },
    subBase:"", subOff:0, subLabel:"", subTimer:0,
    subText(text, label){ NAT.subBase = text; NAT.subOff = 0; NAT.subLabel = label || "Português"; try{ $("trkOff").textContent = "0 s"; }catch(e){} try{ Android.nsub(text, NAT.subLabel, "pt"); }catch(e){} },
    shift(d){
      if(!NAT.subBase) return toast("Carrega primeiro um ficheiro de legendas.", true);
      NAT.subOff = Math.round((NAT.subOff + d) * 10) / 10;
      try{ $("trkOff").textContent = (NAT.subOff > 0 ? "+" : "") + NAT.subOff.toLocaleString("pt-PT") + " s"; }catch(e){}
      clearTimeout(NAT.subTimer);
      NAT.subTimer = setTimeout(() => {   /* espera um pouco para juntar vários toques */
        const off = NAT.subOff * 1000;
        const t = NAT.subBase.replace(/(\d{2}):(\d{2}):(\d{2})([,.])(\d{3})/g, (m, h, mi, s, sep, ms) => {
          let v = Math.max(0, ((+h * 60 + +mi) * 60 + +s) * 1000 + +ms + off);
          const H = Math.floor(v / 3600000), M = Math.floor(v / 60000) % 60, S = Math.floor(v / 1000) % 60, MS = Math.floor(v) % 1000;
          const z = (n, l = 2) => String(n).padStart(l, "0");
          return z(H) + ":" + z(M) + ":" + z(S) + sep + z(MS, 3);
        });
        try{ Android.nsub(t, NAT.subLabel, "pt"); }catch(e){}
      }, 700);
    },
    tracks(type){ try{ const j = JSON.parse(Android.ntracks()); return j[type] || []; }catch(e){ return []; } },
    pick(type, i){ try{ Android.ntrack(type, i); }catch(e){} }
  };
  window.__nev = (kind, msg) => {
    if(kind === "open") return window.__openId && window.__openId(msg);
    if(kind === "voice") return window.__voiceDone && window.__voiceDone(msg);
    if(kind === "voice:error"){ try{ toast(msg, true); }catch(e){} return; }
    if(String(kind).indexOf("cast:") === 0) return CAST.ev(kind.slice(5), msg);
    const cur = NAT.cur; if(!NAT.active || !cur) return;
    if(kind === "ready"){ NAT.ready = true; NAT.rt = null; clearTimeout(NAT.timer); try{ window.__altReset && window.__altReset(); }catch(e){} }
    else if(kind === "error"){
      if(cur.playId !== playSeq[cur.slot]) return;
      if(cur.c.kind === "live" && /\.m3u8(\?|$)/i.test(cur.url) && /\/live\//.test(cur.url) && !cur.triedTs){
        cur.triedTs = true; NAT.ready = false;
        NAT.start(cur.url.replace(/\.m3u8(\?|$)/i, ".ts$1"), "", cur.c.name); return;
      }
      try{ const alt = window.__altFor && window.__altFor(cur.c); if(alt){ toast("A tentar fonte alternativa: " + alt.name); NAT.ready = false; playChannel(alt); return; } }catch(e){}
      NAT.fallback(msg || "erro");
    }
    else if(kind === "noaudio"){ try{ toast("Este vídeo tem áudio que a TV não descodifica. Escolhe outra faixa em Áudio.", true); }catch(e){} }
  };


  /* guia: linhas de programas navegáveis pelo comando */
  const _gp = window.gdRenderProg; if(typeof _gp === "function") window.gdRenderProg = function(){ const r = _gp.apply(this, arguments); document.querySelectorAll(".gdp").forEach(e => { e.tabIndex = 0; }); return r; };

  /* (removido a pedido: já não aparece o aviso «Continuar: último canal»; o Início mostra o último canal) */

  /* parar a reprodução ao sair do canal/filme */
  const stopPlayback = () => { try{ if(window.CAST && CAST.active) Android.cmstop(); }catch(e){} try{ stopSlot(0); lastPlayed[0] = null; epgSlot[0] = null; updateCinemaBar(); }catch(e){} };
  window.__stopPlayback = stopPlayback;
  /* ✕ no leitor do Explorar (como no ecrã nativo): fecha o leitor e pára a reprodução */
  setTimeout(() => { try{ const full = $("chFull"); if(!full || $("chClose")) return; const b = document.createElement("button"); b.className = "btn"; b.id = "chClose"; b.type = "button"; b.setAttribute("aria-label", "Fechar e parar"); b.textContent = "✕";
    b.onclick = () => { try{ stopPlayback(); }catch(e){} try{ document.body.classList.remove("vfull"); }catch(e){} try{ if(document.querySelector(".app").classList.contains("cinema")) setCinema(false); }catch(e){} };
    full.after(b); }catch(e){} }, 0);

  /* ===== Botão Legendas na barra do leitor ===== */
  (function(){
    const tr = $("chTracks"); if(!tr || $("chSubs")) return;
    const b = document.createElement("button"); b.className = "btn"; b.id = "chSubs"; b.textContent = "💬 Legendas";
    b.onclick = () => { trkOpen(); setTimeout(() => { const f = $("trkSubs").querySelector("button") || $("osGo"); if(f) f.focus({preventScroll:true}); }, 120); };
    tr.after(b);
    const upd = () => { const c = lastPlayed && lastPlayed[0]; b.hidden = !!(c && c.kind === "live"); };
    const _u = window.updateCinemaBar; window.updateCinemaBar = function(){ const r = _u.apply(this, arguments); try{ upd(); }catch(e){} return r; };
    upd();
  })();

  /* ===== Definições: modelos de layout, cor e margens ===== */
  const TPL = [
    ["equilibrado", "Equilibrado", "O padrão: destaque + filas de canais."],
    ["cinema", "Cinema", "Cartões grandes e destaque maior; menos itens por ecrã."],
    ["compacto", "Compacto", "Sem destaque, cartões pequenos: vês muitas categorias de uma vez."],
    ["grelha", "Grelha", "Os canais ficam em grelha, sem deslizar para os lados."],
    ["grande", "Texto grande", "Letra e botões maiores, para ler de longe."],
    ["netflix", "Estilo Netflix", "Fundo escuro, destaque grande e cartões com o título por cima."]
  ];
  const OVS = [["0", "Sem margem"], ["1", "Margem média"], ["2", "Margem grande"]];
  const TL = window.TVLAYOUT = Object.assign({t:"equilibrado", ov:"0"}, (function(){ try{ return LS.get("tvLayout", {}) || {}; }catch(e){ return {}; } })());
  const applyLayout2 = () => {
    TPL.forEach(([id]) => document.body.classList.toggle("tl-" + id, TL.t === id));
    document.body.classList.remove("ov-0", "ov-1", "ov-2"); document.body.classList.add("ov-" + TL.ov);
    try{ LS.set("tvLayout", {t:TL.t, ov:TL.ov}); }catch(e){}
    document.querySelectorAll("[data-tpl]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.tpl === TL.t)));
    document.querySelectorAll("[data-ov]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.ov === TL.ov)));
    try{ if(currentView === "tvhome") renderHome(); }catch(e){}
  };
  (function(){
    const st = $("v-settings"); if(!st) return;
    const card = document.createElement("section"); card.className = "setcard panel"; card.id = "tvLayoutCard";
    let h = '<h2>Aparência e layout</h2><p class="small muted" style="margin:0 0 8px">Escolhe um modelo para o ecrã Início. A mudança é imediata.</p><div class="tplGrid">';
    TPL.forEach(([id, nm, ds]) => { h += '<button class="btn tplBtn" data-tpl="' + id + '"><b>' + nm + '</b><small>' + ds + '</small></button>'; });
    h += '</div><h3 style="margin:14px 0 6px">Cor de destaque</h3><div class="tplGrid" id="tvSchemes"></div>';
    h += '<h3 style="margin:14px 0 6px">Margens do ecrã (para TVs que cortam as bordas)</h3><div class="tplGrid">';
    OVS.forEach(([v, nm]) => { h += '<button class="btn tplBtn" data-ov="' + v + '"><b>' + nm + '</b></button>'; });
    h += '</div>';
    card.innerHTML = h;
    const first = [...st.children].find(e => !e.hidden && e.classList && e.classList.contains("setcard"));
    st.insertBefore(card, first || null);
    try{
      const box = $("tvSchemes");
      (typeof SCHEMES !== "undefined" ? SCHEMES : []).forEach(([id, nm, c]) => {
        const b = document.createElement("button"); b.className = "btn tplBtn"; b.dataset.sch = id; b.innerHTML = '<b>' + nm + '</b>';
        b.style.cssText = "border-left:10px solid " + (c && c[1] || "var(--accent)");
        b.onclick = () => { cfg.scheme = id; cfg.light = (id === "claro" || id === "areia"); saveCfg(); applyTheme(); card.querySelectorAll("[data-sch]").forEach(x => x.setAttribute("aria-pressed", String(x.dataset.sch === cfg.scheme))); };
        b.setAttribute("aria-pressed", String(cfg.scheme === id)); box.appendChild(b);
      });
    }catch(e){}
    card.querySelectorAll("[data-tpl]").forEach(b => b.onclick = () => { TL.t = b.dataset.tpl; applyLayout2(); });
    card.querySelectorAll("[data-ov]").forEach(b => b.onclick = () => { TL.ov = b.dataset.ov; applyLayout2(); });
  })();
  applyLayout2();
  const sec = document.createElement("section"); sec.className = "view"; sec.id = "v-tvhome"; sec.hidden = true;
  sec.innerHTML = '<div class="thHero" id="thHero"></div><div id="thRows"></div>';
  $("main").appendChild(sec);

  /* barra de navegação */
  const top = document.querySelector(".top"), sp = top.querySelector(".spacer");
  const nav = document.createElement("nav"); nav.className = "thNav"; nav.setAttribute("aria-label", "Menu");
  [["tvhome","🏠","Início"],["tv","🔎","Explorar"],["guide","📅","Guia"],["settings","⚙","Definições"]].forEach(([v, ic, t]) => {
    const b = document.createElement("button"); b.className = "thTab"; b.dataset.th = v; b.innerHTML = "<span>" + ic + "</span>" + t;
    b.onclick = () => { window.__homeOrigin = false; if(v === "guide") openGuide(); else show(v); };
    nav.appendChild(b);
  });
  top.insertBefore(nav, sp);
  /* Telemóvel: transmitir o ecrã para uma TV (Miracast / Wi-Fi Direct / Cast) */
  let isTvDev = false; try{ isTvDev = !!(Android.isTv && Android.isTv()); }catch(e){}
  if(!isTvDev && typeof Android.cpick === "function"){
    const cb = document.createElement("button"); cb.className = "thTab"; cb.id = "thCast"; cb.innerHTML = "<span>📡</span>Cast";
    cb.onclick = () => { try{ Android.cpick(); }catch(e){ try{ toast("Google Cast indisponível neste telemóvel.", true); }catch(x){} } };
    nav.appendChild(cb);
    if(typeof Android.castScreen === "function"){
      const mb = document.createElement("button"); mb.className = "thTab"; mb.id = "thMirror"; mb.innerHTML = "<span>🖥</span>Espelhar";
      mb.onclick = () => { try{ toast("Escolhe a TV na lista. O ecrã do telemóvel passa a aparecer nela."); }catch(e){} try{ Android.castScreen(); }catch(e){} };
      nav.appendChild(mb);
    }
  }
  { const bs = document.createElement("div"); bs.id = "bStamp"; bs.textContent = "Cockpit TV · v252 · __BUILD__"; bs.style.cssText = "position:fixed;top:5px;right:12px;z-index:99999;font-size:13px;font-weight:600;color:#fff;opacity:.85;text-shadow:0 1px 3px rgba(0,0,0,.6);pointer-events:none;white-space:nowrap"; document.body.appendChild(bs); }
  const syncNav = () => nav.querySelectorAll(".thTab").forEach(b => b.setAttribute("aria-current", b.dataset.th === currentView ? "page" : "false"));

  /* ===== TV Direto: canais sintonizados pela própria TV (Android TV / Google TV) ===== */
  if(isTvDev){
    const lv = document.createElement("section"); lv.className = "view"; lv.id = "v-tvlive"; lv.hidden = true;
    lv.innerHTML = '<div class="tlWrap"><h2>📡 TV Direto</h2><p id="tvLiveMsg" class="tlMsg"></p>' +
      '<div class="tlBar"><button class="thBtn pri" id="tvLiveOpen">Abrir TV em direto</button><button class="thBtn" id="tvLiveReload">Recarregar canais</button></div>' +
      '<div id="tvLiveBr" class="tlMsg" style="margin:0 0 14px"><b>Canais da TV (Sony Bravia)</b><div class="tlBar" style="margin:8px 0 0"><button class="thBtn" id="brIp"></button><button class="thBtn" id="brPsk"></button><button class="thBtn pri" id="brSave">Guardar e carregar</button></div><div class="tlBar" style="margin:8px 0 0"><button class="thBtn" id="tvvGo">Painel da app por cima da TV</button><button class="thBtn" id="tvvStop">Fechar painel</button></div><div id="tvvMsg" class="tlMsg" style="margin:8px 0 0"></div><div id="brMsg" class="tlMsg" style="margin:8px 0 0"></div></div>' +
      '<div id="tvLiveList" class="tlList"></div><pre id="tvLiveDiag" class="tlMsg" style="font-size:12px;white-space:pre-wrap;opacity:.6;margin-top:18px"></pre></div>';
    $("main").appendChild(lv);
    const st = document.createElement("style");
    st.textContent = '#v-tvlive .tlWrap{padding:24px 32px 60px;max-width:1200px}#v-tvlive h2{margin:0 0 6px;font-size:26px}' +
      '.tlMsg{opacity:.8;margin:0 0 14px;line-height:1.4}.tlBar{display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap}' +
      '.tlList{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:10px}' +
      '.tlList button{display:flex;gap:12px;align-items:center;text-align:left;padding:14px 16px;border-radius:12px;border:2px solid transparent;background:rgba(255,255,255,.07);color:inherit;font-size:17px;cursor:pointer}' +
      '.tlList button:focus,.tlList button:hover{outline:none;border-color:var(--accent,#3b82f6);background:rgba(255,255,255,.14)}' +
      '.tlList .tn{min-width:42px;font-weight:700;opacity:.7}.tlList .pic{width:56px;height:36px;object-fit:contain;flex:none}';
    document.head.appendChild(st);
    const tab = document.createElement("button"); tab.className = "thTab"; tab.dataset.th = "tvlive"; tab.innerHTML = "<span>📡</span>TV Direto";
    tab.onclick = () => { window.__homeOrigin = false; show("tvlive"); };
    const gt = nav.querySelector('[data-th="guide"]'); nav.insertBefore(tab, gt || null);
    const msg = $("tvLiveMsg"), list = $("tvLiveList");
    let loaded = false;
    const load = () => {
      if(BR && BR.ip() && BR.psk() && typeof Android.bravia === "function" && brLoad()) return;
      list.innerHTML = ""; let arr = null, raw = "";
      try{ if(typeof Android.tvChannels !== "function"){ msg.textContent = "Esta versão da app não tem acesso aos canais da TV. Usa 'Abrir TV em direto'."; return; } raw = Android.tvChannels(); arr = JSON.parse(raw); }catch(e){ arr = null; }
      if(arr && !Array.isArray(arr)){ msg.textContent = "A TV não deixou a app ler os canais (" + (arr.error || "sem permissão") + "). Usa 'Abrir TV em direto' para ver os canais na app de TV do sistema."; return; }
      if(!arr || !arr.length){ msg.textContent = "Não encontrei canais acessíveis. Se a TV tem sintonizador, a app de TV do sistema pode não partilhar os canais com apps de terceiros. Usa 'Abrir TV em direto'."; return; }
      arr.sort((a, b) => (parseFloat(a.num) || 1e9) - (parseFloat(b.num) || 1e9) || String(a.name).localeCompare(String(b.name)));
      msg.textContent = arr.length + " canais da TV. OK para ver.";
      const f = document.createDocumentFragment();
      arr.forEach(c => { const b = document.createElement("button"); b.innerHTML = '<span class="tn"></span><span class="tt"></span>'; b.firstChild.textContent = c.num; b.lastChild.textContent = c.name || ("Canal " + c.id); b.onclick = () => { let r = ""; try{ r = Android.tvTune(c.id); }catch(e){ r = "erro"; } try{ toast(String(r).indexOf("ok:") === 0 ? "A abrir " + c.name + "…" : r === "app" ? "A TV não deixou abrir o canal diretamente; abri a app de TV." : "Não consegui abrir o canal.", String(r) === "falhou"); }catch(e){} }; f.appendChild(b); });
      list.appendChild(f); loaded = true;
    };
    /* API Bravia (IP Control): lista os canais da lista própria da Sony e sintoniza-os */
    const BR = {ip:() => LS.get("brIp", "") || "", psk:() => LS.get("brPsk", "") || ""};
    const brCall = (svc, method, params, ver) => { let r; try{ r = JSON.parse(Android.bravia(BR.ip(), BR.psk(), svc, JSON.stringify({method:method, id:1, params:params, version:ver || "1.0"}))); }catch(e){ return {err:"sem resposta (" + e + ")"}; }
      if(r.httpError !== undefined) return {err: r.httpError === 403 ? "403: a Pre-Shared Key está errada ou a autenticação não está em «Pre-Shared Key»" : r.httpError === 0 ? "não consegui ligar à TV em " + BR.ip() + " (" + r.body + ")" : "HTTP " + r.httpError};
      if(r.error) return {err: "erro " + r.error[0] + ": " + r.error[1]};
      return {res: r.result}; };
    /* Canal da lista da TV: sintoniza SEMPRE no sintonizador da TV (nunca troca pelo stream IPTV) */
    const brPlay = (uri, name) => {
      if(brOverlayOn() && typeof Android.overlayStart === "function" && Android.overlayAllowed()){ const ls = (window.__brItems || []).map(c => ({num:String(c.num), name:c.name, uri:c.uri})); if(Android.overlayStart(BR.ip(), BR.psk(), JSON.stringify(ls), uri)){ try{ toast("A sintonizar " + name + " com o painel do Cockpit por cima…"); }catch(e){} return; } } const r = brCall("avContent", "setPlayContent", [{uri:uri}], "1.0"); try{ toast(r.err ? "Não consegui abrir: " + r.err : "A sintonizar " + name + " na TV…", !!r.err); }catch(e){} };
    const brLoad = () => {
      const bm = $("brMsg"); list.innerHTML = ""; bm.textContent = "A ligar à TV…";
      const src = brCall("avContent", "getSourceList", [{scheme:"tv"}], "1.0");
      if(src.err){ bm.textContent = "Falhou: " + src.err; return false; }
      const sources = (src.res[0] || []).map(x => x.source), items = [];
      const errs = [], tried = [];
      const fetchSrc = sc => { let got = 0; for(const ver of ["1.5", "1.2", "1.0"]){ let ok = false; for(let st = 0; st < 2000; st += 50){ const r = brCall("avContent", "getContentList", ver === "1.0" ? [{source:sc, stIdx:st}] : [{source:sc, stIdx:st, cnt:50}], ver); if(r.err){ errs.push(sc + " v" + ver + ": " + r.err); break; } const a = (r.res && r.res[0]) || []; tried.push(sc + " v" + ver + " → " + a.length); ok = true; if(!a.length) break; a.forEach(c => { if((parseFloat(c.dispNum || c.index) || 0) < 800) return; items.push({num:c.dispNum || c.index, name:c.title, uri:c.uri, src:sc}); got++; }); if(a.length < 50) break; } if(got) break; } return got; };
      const srcs = [...new Set(sources.concat(["tv:dvbt", "tv:dvbc", "tv:dvbs"]))];
      srcs.forEach(sc => { if(sc !== "tv:analog" || sources.indexOf(sc) >= 0) fetchSrc(sc); });
      const seen = new Set(); for(let i = items.length - 1; i >= 0; i--){ if(seen.has(items[i].uri)) items.splice(i, 1); else seen.add(items[i].uri); }
      window.__brDebug = {sources:sources, tried:tried, errs:errs};
      window.__brItems = items.slice();
      const ext = brCall("avContent", "getCurrentExternalInputsStatus", [], "1.1");
      const hd = ext.res ? (ext.res[0] || []).filter(x => /hdmi|component|composite|scart/i.test(x.uri)) : [];
      bm.textContent = items.length + " canais (" + sources.join(", ") + ") + " + hd.length + " entradas." + (items.length ? "" : " Detalhe: " + (errs.concat(tried).join(" | ") || "sem resposta") );
      const f = document.createDocumentFragment();
      const mk = (n, t, uri, noPic) => { const b = document.createElement("button"); b.innerHTML = '<span class="tn"></span><span class="tt"></span>'; b.firstChild.textContent = n; b.lastChild.textContent = t; if(!noPic && typeof window.__piconFor === "function"){ const u = window.__piconFor(t); if(u){ const im = document.createElement("img"); im.className = "pic"; im.alt = ""; im.src = u; b.insertBefore(im, b.lastChild); } } b.onclick = () => brPlay(uri, t); f.appendChild(b); };
      items.sort((a, b) => (parseFloat(a.num) || 1e9) - (parseFloat(b.num) || 1e9)).forEach(c => mk(c.num, c.name, c.uri));
      hd.forEach(x => mk("↪", x.title || x.label || x.uri, x.uri, true));
      list.appendChild(f); loaded = true; msg.textContent = items.length ? items.length + " canais da lista da TV. OK para ver." : "A TV respondeu mas sem canais nesta lista."; return true;
    };
    const brShow = () => { $("brIp").textContent = "IP da TV: " + (BR.ip() || "(tocar para escrever)"); $("brPsk").textContent = "Chave: " + (BR.psk() ? "••••••" : "(tocar para escrever)"); };
    try{ if(!BR.ip() && typeof Android.lanIp === "function"){ const ip = Android.lanIp(); if(ip) LS.set("brIp", ip); } }catch(e){}
    const brAsk = (key, title, secret) => { window.__askCb = v => { window.__askCb = null; if(v !== null){ LS.set(key, String(v).trim()); brShow(); } }; try{ Android.askText(title, LS.get(key, "") || "", !!secret); }catch(e){ try{ const v = prompt(title, LS.get(key, "") || ""); if(v !== null){ LS.set(key, v.trim()); brShow(); } }catch(x){} } };
    $("brIp").onclick = () => brAsk("brIp", "IP da TV (ex.: 192.168.1.50)", false);
    $("brPsk").onclick = () => brAsk("brPsk", "Pre-Shared Key da TV", true);
    brShow();
    $("brSave").onclick = () => { brLoad(); };

    /* Experiência TvView: tenta sintonizar ids de canal consecutivos no sintonizador, dentro da app */
    const TV = {run:0, id:0};
    const tvvInput = () => { try{ const d = JSON.parse(Android.tvDiag()); const x = (d.inputs || []).map(t => String(t).split(" | ")[0]).find(t => /DvbTerrCable/.test(t)); if(x) return x; }catch(e){} return "com.sony.dtv.tvinput.tuner/.DvbTerrCableInputService/HW0"; };
    const tvvMsg = t => { const m = $("tvvMsg"); if(m) m.textContent = t; };
    const prevNev = window.__nev;
    window.__nev = (k, m) => { if(String(k).indexOf("tvv:") === 0){ if(TV.run && TV.wait) TV.wait(k, m); return; } return prevNev && prevNev(k, m); };
    /* Painel do Cockpit por cima da TV da Sony (o sintonizador Sony não aceita TvView de apps de terceiros) */
    const brOverlayOn = () => LS.get("brOverlay", true) !== false;
    const ovShow = () => { const b = $("tvvGo"); if(b) b.textContent = "Painel da app por cima da TV: " + (brOverlayOn() ? "Ligado" : "Desligado"); };
    const ovCheck = () => {
      if(typeof Android.overlayAllowed !== "function"){ tvvMsg("Esta versão da app não tem o painel por cima da TV."); return; }
      if(!brOverlayOn()){ tvvMsg("Painel desligado: OK num canal muda a TV para esse canal (sem painel)."); return; }
      if(Android.overlayAllowed()){ tvvMsg("OK num canal: a TV sintoniza-o e o painel do Cockpit aparece por cima (OK muda, CH+/CH− zapping, Voltar fecha)."); return; }
      tvvMsg("Falta a permissão «Sobrepor a outras apps». Se a TV não abrir esse ecrã, ativa-a uma vez a partir de um PC:\n  adb connect " + (BR.ip() || "IP_DA_TV") + "\n  adb shell appops set pt.rui.cockpittv SYSTEM_ALERT_WINDOW allow");
    };
    window.__brOverlayOn = brOverlayOn;
    $("tvvStop").onclick = () => { try{ Android.overlayStop(); }catch(e){} tvvMsg("Painel fechado."); };
    $("tvvGo").onclick = () => {
      LS.set("brOverlay", !brOverlayOn()); ovShow();
      if(brOverlayOn() && typeof Android.overlayAllowed === "function" && !Android.overlayAllowed()){ try{ Android.overlayRequest(); }catch(e){} }
      ovCheck();
    };
    ovShow(); ovCheck();
    const diag = () => { try{ if(typeof Android.tvDiag !== "function") return; const d = JSON.parse(Android.tvDiag()); $("tvLiveDiag").textContent = "Diagnóstico\nEntradas de TV: " + ((d.inputs || []).join("; ") || "nenhuma") + "\nApps que abrem canais: " + ((d.handlers || []).join("; ") || "nenhuma") + (d.error ? "\nErro: " + d.error : ""); }catch(e){} };
    $("tvLiveOpen").onclick = () => { let ok = false; try{ ok = Android.tvOpenLive(); }catch(e){} if(!ok) try{ toast("Não encontrei a app de TV desta TV.", true); }catch(e){} };
    $("tvLiveReload").onclick = load;
    const _sh2 = window.show;
    window.show = function(v){ const r = _sh2.apply(this, arguments); if(currentView === "tvlive"){ syncNav(); if(!loaded) load(); diag(); } return r; };
  }

  /* recentes */
  const REC = "tvRecent";
  const recents = () => LS.get(REC, []) || [];
  window.__recents = recents;
  const pushRecent = c => { try{ const a = recents().filter(x => x.url !== c.url); a.unshift({name:c.name, logo:c.logo || "", url:c.url, kind:c.kind, group:c.group, id:c.id, free:c.free, intl:c.intl, sid:c.sid}); LS.set(REC, a.slice(0, 24)); }catch(e){} };
  const _pc = window.playChannel;
  window.playChannel = function(c){ try{ if(c && c.url){ pushRecent(c); window.__pvPick = null; } }catch(e){} return _pc.apply(this, arguments); };

  /* Ecrã de canais 100% nativo (Fase 1, experimental, desligado por defeito) */
  const NSC = {open:false, map:{}};
  NSC.on = () => LS.get("tvNativeScr", "on") === "on" && typeof Android !== "undefined" && typeof Android.nscreen === "function" && typeof Android.nplay === "function";
  window.__NSC = NSC;
  /* Explorar (TV e telemóvel): o separador e o botão «Explorar canais» abrem direto o ecrã de canais nativo (um só desenho), no último canal visto */
  NSC.explore = function(force){
    try{
      if(!NSC.on() || NSC.open) return false;
      const was = currentView; let n = 0;
      if(was === "tv" && !force) return false;
      if(was !== "tv" && force){ try{ show("tv"); }catch(e){} }
      document.body.classList.add("nscdiv"); setTimeout(() => { if(!NSC.open) document.body.classList.remove("nscdiv"); }, 2500);
      const go = () => {
        if(currentView !== "tv" || NSC.open) return;
        const sh = (window.__tvShown || []).filter(x => x && x.kind === "live" && x.url);
        if(!sh.length){ if(++n < 12) setTimeout(go, 150); return; }
        const rc = (window.__recents ? window.__recents() : []).find(r => r && r.kind === "live" && sh.some(x => x.url === r.url));
        const c = (rc && sh.find(x => x.url === rc.url)) || sh[0];
        window.__homeOrigin = false; window.playChannel(c);
      };
      setTimeout(go, 200); return true;
    }catch(x){ return false; }
  };
  document.addEventListener("click", e => {
    try{ const t = e.target && e.target.closest && e.target.closest('.thTab[data-th="tv"]'); if(t) NSC.explore(); }catch(x){}
  }, true);
  /* programa a decorrer, com intervalo, para o ecrã nativo */
  NSC.epgTxt = c => { try{ const nn = nowNext(c); if(nn && nn.now){ const t = String(nn.now.title || "").trim(); return hm(nn.now.start) + "–" + hm(nn.now.stop) + (t ? " · " + t : ""); } }catch(e){} return ""; };
  NSC.epgPush = () => { try{
    if(!NSC.open || !NSC.px) return; const o = {};
    Object.keys(NSC.px).forEach(pu => { const c = NSC.map && NSC.map[NSC.px[pu]]; if(c && c.kind === "live"){ const t = NSC.epgTxt(c); if(t) o[pu] = t; } });
    if(Object.keys(o).length) Android.nscmd("epg", JSON.stringify(o));
  }catch(e){} };
  NSC.epgWant = async pu => { try{ const c = NSC.map && NSC.map[(NSC.px && NSC.px[pu]) || pu]; if(!c || c.kind !== "live") return; if(!NSC.epgTxt(c) && typeof xEpg === "function") await xEpg(c); NSC.epgPush(); }catch(e){} };
  setInterval(() => { if(NSC.open) NSC.epgPush(); }, 60000);
  NSC.divert = function(c, slot){
    if(slot !== 0 || NSC.open || (NSC.skip && c && NSC.skip === c.url) || !NSC.on() || !c || !c.url || c.kind === "live" || /^series:/.test(c.url) || (window.CAST && CAST.active)) return false;
    if(c.kind !== "movie" && c.kind !== "episode") return false;
    let L = [c], idx = 0;
    const E = window.EPL && EPL.list;
    if(c.kind === "episode" && E){ const i = E.findIndex(e => e.url === c.url); if(i >= 0){ L = E; idx = i; } }
    const px2 = (u, r) => { try{ return (window.__pxMode && window.__pxMode() === "all" && typeof px === "function") ? px(u, r, false) : u; }catch(e){ return u; } };
    NSC.map = {}; NSC.px = {};
    const arr = L.map(x => { let r = ""; try{ r = (typeof refFor === "function" && refFor(x)) || ""; }catch(e){} const pu = px2(x.url, r); NSC.map[x.url] = x; NSC.px[pu] = x.url;
      return {name:x.name || "", logo:(typeof imgSrc === "function" ? imgSrc(x.logo || "") : (x.logo || "")), group:x.group || "", url:pu, ref:r, epg:x.group || "", kind:x.kind || "movie", start:Math.round(((window.RES && RES.at(x.url)) || 0) * 1000)}; });
    try{ if(window.__pv) window.__pv.on = false; }catch(e){}
    NSC.fromHome = !!window.__homeOrigin || currentView === "tvhome";
    NSC.open = true;
    Android.nscreen(JSON.stringify(arr), idx);
    NSC.guard(c);
    return true;
  };
  /* se o ecrã nativo não abrir (nenhum sinal em 5 s), volta ao leitor antigo para o filme/canal abrir na mesma */
  /* Fechar o Guia aberto a partir do Explorar nativo: volta ao Explorar novo (nunca ao antigo) */
  try{
    const gd = document.getElementById("gdDlg");
    if(gd) new MutationObserver(() => {
      if(!gd.hidden || !NSC.retNative) return; NSC.retNative = false;
      setTimeout(() => { if(NSC.open) return; if(!NSC.explore(true)) document.body.classList.remove("nscdiv"); }, 120);
    }).observe(gd, {attributes:true, attributeFilter:["hidden"]});
  }catch(e){}
  NSC.guard = function(c){
    NSC.played = false; clearTimeout(NSC.gt);
    NSC.gt = setTimeout(() => {
      if(!NSC.open || NSC.played) return;
      NSC.open = false; NSC.skip = c && c.url; document.body.classList.remove("nscdiv");
      try{ toast("O ecrã nativo não abriu. A usar o leitor normal.", true); }catch(e){}
      window.__noDet = true; try{ window.playChannel(c); }catch(e){} finally{ window.__noDet = false; NSC.skip = null; }
    }, 5000);
  };
  const nscHook = function(){
  const _pc2 = window.playChannel;
  window.playChannel = function(c){
    try{
      if(NSC.on() && !NSC.open && !(NSC.skip && c && NSC.skip === c.url) && c && c.url && c.kind === "live" && !(window.CAST && CAST.active)){
        const sh = (window.__tvShown || []).filter(x => x && x.kind === "live" && x.url);
        let idx = sh.findIndex(x => x.url === c.url);
        if(idx >= 0){
          NSC.map = {}; sh.forEach(x => { NSC.map[x.url] = x; });
          const px2 = (u, r) => { try{ return (window.__pxMode && window.__pxMode() === "all" && typeof px === "function") ? px(u, r, false) : u; }catch(e){ return u; } };
          const arr = sh.map(x => { let r = ""; try{ r = (typeof refFor === "function" && refFor(x)) || ""; }catch(e){} return {name:x.name || "", logo:(typeof imgSrc === "function" ? imgSrc(x.logo || "") : (x.logo || "")), group:x.group || "", url:px2(x.url, r), ref:r, epg:NSC.epgTxt(x), raw:x.url}; });
          try{ if(window.__pv) window.__pv.on = false; }catch(e){}
          try{ if(typeof stopPlayback === "function") stopPlayback(); }catch(e){}
          NSC.fromHome = !!window.__homeOrigin || currentView === "tvhome"; NSC.open = true; NSC.px = {}; arr.forEach(a => { NSC.px[a.url] = a.raw; });
          Android.nscreen(JSON.stringify(arr), idx);
          if(NSC.fromHome){ try{ Android.nscmd("full", ""); }catch(e){} }   /* canal escolhido no Início: ecrã total, esticado */
          NSC.guard(c);
          return;
        }
      }
    }catch(e){ NSC.open = false; window.__nsce = String(e); }
    return _pc2.apply(this, arguments);
  };
  };
  setTimeout(nscHook, 2500);   /* depois de todos os outros embrulhos de playChannel */
  (function(){
    const prev = window.__nev;
    window.__nev = function(k, m){
      if(k === "nscreen:want"){ NSC.epgWant(m); return; }
      if(k === "nscreen:play"){ NSC.played = true; NSC.epgWant(m); const raw = NSC.px && NSC.px[m] || m, c = NSC.map[raw]; if(c){ try{ window.__pvPick = null; lastPlayed[0] = c; LS.set("last0", c); pushRecent(c); updateCinemaBar(); }catch(e){} } return; }
      if(k === "nscreen:pos"){ const q = String(m).split("|"), raw = NSC.px && NSC.px[q[0]] || q[0], c = NSC.map[raw]; if(c && window.RES){ try{ RES.save(c, (+q[1]) / 1000, (+q[2]) / 1000); }catch(e){} } return; }
      if(k === "nscreen:subsearch"){
        (async () => { try{
          if(typeof osSearch !== "function") throw new Error("pesquisa indisponível");
          if(!(typeof cfg !== "undefined" && cfg.osKey)) throw new Error("falta a chave OpenSubtitles (Definições → Conta OpenSubtitles)");
          NSC.subs = await osSearch(m);
          Android.nscmd("subres", JSON.stringify(NSC.subs.slice(0, 10).map(r => (/pt-?pt/i.test(r.lang) ? "PT" : "BR") + " · " + String(r.rel || "").slice(0, 60) + (r.hi ? " · HI" : ""))));
        }catch(x){ try{ Android.nscmd("msg", "Legendas: " + (x && x.message || x)); }catch(e){} } })();
        return;
      }
      if(k === "nscreen:subpick"){
        (async () => { try{
          const r = NSC.subs && NSC.subs[+m]; if(!r) return;
          await osLogin();
          const j = await osFetch("/download", {method:"POST", auth:true, body:{file_id:r.file_id, sub_format:"srt"}});
          if(!j.link) throw new Error("sem ligação de download");
          const f = await fetchAny(j.link); if(!f.ok) throw new Error("HTTP " + f.status);
          Android.nsub(decodeSub(await f.arrayBuffer()), "Português · OpenSubtitles", "pt");
          Android.nscmd("msg", "Legendas ativadas ✓" + (j.remaining != null ? " Restam " + j.remaining + " downloads hoje." : ""));
        }catch(x){ try{ Android.nscmd("msg", "Não consegui obter a legenda: " + (x && x.message || x)); }catch(e){} } })();
        return;
      }
      if(k === "nscreen:closed"){
        NSC.open = false; clearTimeout(NSC.gt);
        /* Sair / Voltar de um canal ou filme leva SEMPRE ao menu inicial (Início), com o foco no menu */
        try{ setTimeout(() => {
          if(NSC.open){ document.body.classList.remove("nscdiv"); return; }
          if(NSC.toGuide){ NSC.toGuide = false; return; }   /* o Explorar antigo fica escondido enquanto o Guia está aberto */
          try{ setVfull(false); }catch(e){} try{ if(document.querySelector(".app").classList.contains("cinema")) setCinema(false); }catch(e){} try{ if(window.__stopPlayback) window.__stopPlayback(); }catch(e){}
          window.__homeOrigin = false; NSC.fromHome = false;
          try{ const P = window.__pv; const has = typeof Android.nsoft === "function" && Android.nsoft(), soft = has && LS.get("tvPrev", "on") !== "off"; if(has && !soft){ try{ Android.nstopnow(); }catch(e){} } if(P){ P.on = false; P.key = ""; P.off = false; P.settle = soft ? 0 : Date.now() + 500; } if(!soft) Android.nrect(0, 0, 1, 1, false); }catch(e){}   /* a miniatura do Início recomeça do zero */
          try{ show("tvhome"); }catch(e){}
          try{ if(window.__pvTick) window.__pvTick(); }catch(e){}
          setTimeout(() => { document.body.classList.remove("nscdiv"); }, 120);
          setTimeout(() => { try{ const f = document.querySelector("#v-tvhome .thBtn.pri, #v-tvhome .thCard"); if(f) f.focus({preventScroll:true}); }catch(e){} }, 250);
          /* a pré-visualização tem de voltar: se passado um instante ainda não pediu o canal, regista porquê e desbloqueia */
          setTimeout(() => { try{
            const P = window.__pv; if(!P || P.on || currentView !== "tvhome") return;
            const bt = document.getElementById("boot");
            const why = {view:currentView, off:!!P.off, hid:document.hidden, nat:!!(window.NATIVE && NATIVE.active), nsc:!!(window.__NSC && __NSC.open), cast:!!(window.CAST && CAST.active), art:!!document.querySelector("#thHero .thHeroArt"), boot:!!(bt && !bt.hidden)};
            try{ Android.nlogjs("pré-visualização não retomou: " + JSON.stringify(why)); }catch(e){}
            P.off = false; P.settle = 0; P.key = "";
            try{ if(window.__NSC) __NSC.open = false; if(window.NATIVE) NATIVE.active = false; }catch(e){}
          }catch(e){} }, 900);
        }, 0); }catch(e){}
        return; }
      if(k === "pv:lost"){   /* o leitor parou a miniatura por a página não a ter pedido: pede-a de novo */
        try{
          const P = window.__pv, bt = document.getElementById("boot");
          const why = {view:currentView, on:!!(P && P.on), off:!!(P && P.off), hid:document.hidden, nat:!!(window.NATIVE && NATIVE.active), nsc:!!(window.__NSC && __NSC.open), cast:!!(window.CAST && CAST.active), art:!!document.querySelector("#thHero .thHeroArt"), boot:!!(bt && !bt.hidden)};
          try{ Android.nlogjs("miniatura perdida; a repor: " + JSON.stringify(why)); }catch(e){}
          if(P && currentView === "tvhome"){ P.on = false; P.off = false; P.key = ""; P.settle = 0; }
          try{ if(window.__NSC) __NSC.open = false; if(window.NATIVE && NATIVE.active && currentView === "tvhome") NATIVE.active = false; }catch(e){}
        }catch(e){}
        return; }
      if(k === "nscreen:rot"){ [0, 200, 500, 1000, 2000].forEach(ms => setTimeout(() => { try{ if(window.__navSync) window.__navSync(); }catch(e){} }, ms)); return; }   /* rodou o telemóvel: a barra nativa pede a nova */
      if(k === "nscreen:act"){ try{ const b = document.getElementById(m === "cast" ? "thCast" : "thMirror"); if(b) b.click(); }catch(e){} return; }
      if(k === "nscreen:nav"){   /* barra global do ecrã nativo */
        NSC.open = false; clearTimeout(NSC.gt);
        if(m === "tvhome") return;   /* o «closed» já leva ao Início */
        NSC.toGuide = true; if(m === "guide") NSC.retNative = true;
        try{ setVfull(false); }catch(e){} try{ if(document.querySelector(".app").classList.contains("cinema")) setCinema(false); }catch(e){} try{ if(window.__stopPlayback) window.__stopPlayback(); }catch(e){}
        window.__homeOrigin = false; NSC.fromHome = false;
        try{ if(window.__pv){ __pv.on = false; __pv.key = ""; } }catch(e){}
        try{ if(typeof Android.nstopnow === "function") Android.nstopnow(); Android.nrect(0, 0, 1, 1, false); }catch(e){}
        try{
          if(m === "guide"){ show("tv"); openGuide(); }
          else if(m === "tvhome" || m === "tv" || m === "settings") show(m);
          else { const tb = document.querySelector('.thNav .thTab[data-th="' + m + '"]'); if(tb) tb.click(); else show("tvhome"); }
        }catch(e){}
        if(m !== "guide") setTimeout(() => { document.body.classList.remove("nscdiv"); }, 120);
        return; }
      if(k === "nscreen:guide"){ NSC.open = false; NSC.toGuide = true; NSC.retNative = true; try{ show("tv"); }catch(e){} try{ openGuide(); }catch(e){} return; }
      if(k === "nscreen:error"){ NSC.open = false; document.body.classList.remove("nscdiv"); try{ toast("Ecrã nativo: " + m, true); }catch(e){} return; }
      return prev && prev.apply(this, arguments);
    };
  })();

  const HOME = {flat:[], lastK:null, kind:(LS.get("thKind", "live") || "live")};
  const KINDS = [["live","📺","Canais"],["movie","🎬","Filmes"],["series","🍿","Séries"]];
  const ptGroups = kind => { const m = groupsOf(kind), names = orgGroupList(kind, [...m.keys()], false).filter(isPtGroup); return names.map(n => [n, m.get(n)]); };
  const allCh = () => [...(typeof channels !== "undefined" ? channels : []), ...freeChans, ...intlChans];
  const uniq = l => { const s = new Set(); return l.filter(c => c && c.url && !s.has(c.url) && s.add(c.url)); };
  const groupsOf = kind => { const m = new Map(); channels.filter(c => c.kind === kind).forEach(c => { const g = c.group || "Outros"; if(!m.has(g)) m.set(g, []); m.get(g).push(c); }); return m; };

  function card(c, k, small){
    let sub = c.group || "";
    try{ const nn = nowNext(c); if(nn) sub = hm(nn.now.start) + " " + nn.now.title; }catch(e){}
    if(c._sub) sub = c._sub;
    const isPoster = c.kind === "movie" || c.kind === "series";
    return '<button class="thCard' + (small ? " sm" : "") + (isPoster ? " poster" : "") + '" data-k="' + k + '"><span class="thArt">' + (c._pct ? '<span class="thBar"><i style="width:' + c._pct + '%"></i></span>' : "") + (c.logo ? '<img src="' + esc(c.logo) + '" alt="" loading="lazy" decoding="async" onerror="this.remove()">' : "") + '<b class="thInit">' + esc((c.name || "?").replace(/[^\p{L}\p{N}]/gu, "").slice(0, 2).toUpperCase()) + '</b></span><span class="thMeta"><b>' + esc(isPoster ? String(c.name || "").replace(/^\s*\|?[A-Za-z]{2,3}\|?\s*[-–:]\s+/, "") : c.name) + '</b><small>' + esc(sub) + '</small></span></button>';
  }
  function row(title, list, more, total, lm){
    list = uniq(list); if(!list.length) return ""; const cnt = total || list.length;
    const k0 = HOME.flat.length; list.forEach(c => HOME.flat.push(c));
    return '<div class="thRow"><h2><span>' + title + '</span><em class="thCnt">' + cnt + '</em></h2><div class="thScroll">' + list.map((c, i) => card(c, k0 + i)).join("") + (more ? '<button class="thCard thMore" data-more="' + more + '"><span>Ver tudo →</span></button>' : "") + (lm && total > list.length ? '<button class="thCard thMore" data-lm="' + esc(lm) + '"><span>Carregar mais 25<br><small>' + list.length + ' de ' + total + '</small></span></button>' : "") + '</div></div>';
  }

  /* ===== Lista por operador (MEO / NOS / Vodafone) ===== */
  const OPS = {
    meo:{label:"MEO", src:"MEO: lista oficial de canais (set/26) e grelha de caixa", list:["RTP 1", "RTP 2", "SIC", "TVI", "SIC Notícias", "RTP Notícias|RTP 3", "CNN Portugal|CNN PT", "CMTV", "News Now", "Globo", "11|Canal 11", "V+ TVI|TVI Ficção", "SIC Mulher", "SIC Novelas", "Veja", "Sport TV+", "Sport TV 1", "Sport TV 2", "Sport TV 3", "Sport TV 4", "Sport TV 5", "Sport TV 6", "Benfica TV|BTV", "NBA TV", "Eleven Sports 1|ELEVEN 1", "Eleven Sports 2|ELEVEN 2", "Eleven Sports 3|ELEVEN 3", "A Bola TV", "Porto Canal", "Sporting TV", "W-Sport", "Eurosport 1", "Eurosport 2", "Kombat Sport", "Disney Channel", "Cartoon Network", "Panda Kids", "SIC K", "Nickelodeon", "Disney Junior", "Panda", "Cartoonito", "Nick Jr.", "Baby TV", "Biggs", "Lolly Kids", "TVCine Top", "TVCine Edition", "TVCine Emotion", "TVCine Action", "Cinemundo", "Hollywood", "STAR Movies|FOX Movies", "AMC", "AXN Movies", "STAR Channel|FOX", "STAR Life|FOX Life", "STAR Crime|FOX Crime", "FOX Comedy|STAR Comedy", "AXN", "AXN White", "Syfy", "Dizi Channel|Dizi", "VinTV", "Discovery Channel", "História", "Odisseia", "National Geographic", "National Geographic Wild", "TVI Reality", "RTP Memória", "Canal Q|Q", "SIC Radical", "AMC Break", "Gametoon", "AMC Crime", "TLC", "SIC Caras", "Casa e Cozinha", "24 Kitchen", "Travelxp|Travel Channel", "Fashion TV", "MTV Portugal|MTV", "VH1", "Trace Urban", "MCM Pop", "MCM Top", "Afro Music", "Alma Lusa", "Mezzo", "RTP Açores", "RTP Madeira", "ARTV", "Localvisão TV", "Canção Nova", "UM Europa", "Record Europa|Record TV", "Record News", "Euronews", "RTP África", "TPA Notícias|TPA Internacional", "CNN", "Bloomberg", "Sky News", "BBC World News|BBC World", "France 24", "i24News", "NHK World", "CGTN", "Al Jazeera|AlJazeera", "TRT World", "TVE Internacional|TVEi", "TVE 24h", "TV Galicia", "TV5 Monde", "BFM TV", "BVN", "CCTV 4"]},
    nos:{label:"NOS", src:"NOS: plano de canais digitais (sem caixa)", list:["RTP 1", "RTP 2", "SIC", "TVI", "SIC Notícias", "RTP 3", "CNN Portugal|CNN PT", "CMTV", "Sport TV+", "Globo", "Canal 11|11", "TVI Reality", "SIC Mulher", "SIC Caras", "SIC Radical", "RTP Memória", "Porto Canal", "Sporting TV", "Disney Channel", "Nickelodeon", "Canal Panda|Panda", "Disney Junior", "Cartoon Network", "Nick Jr.", "Biggs", "Hollywood", "AXN Movies", "AXN", "AMC", "FOX", "FOX Life", "AXN White", "Canal Q|Q", "TLC", "MTV Portugal|MTV", "Record TV", "Discovery Channel", "National Geographic", "Odisseia", "Canal História|História", "AMC Break", "24 Kitchen", "Eurosport 1", "Eurosport 2", "Fuel TV", "MTV 00s", "MCM Top", "Mezzo", "MCM Pop", "Record News", "Canal 180", "Kuriakos TV", "Canção Nova", "RTP Madeira", "RTP Açores", "RTP África", "TPA Notícias", "STV Notícias", "Localvisão TV", "Rai Italia", "Euronews", "CNN", "Sky News", "Al Jazeera", "France 24", "CNBC", "Bloomberg", "TVE 24h", "Phoenix InfoNews", "NHK World", "CGTN", "ARTV", "TV Galicia", "TVE Internacional|TVEi", "TV5 Monde", "ARTE", "BVN", "RTL", "DW|Deutsche Welle", "KBS World", "CCTV 4"]},
    vodafone:{label:"Vodafone", src:"Vodafone: grelha sem caixa (ago/2023)", list:["RTP 1", "RTP 2", "SIC", "TVI", "SIC Notícias|SIC N", "RTP 3", "CNN Portugal|CNN", "CMTV", "Sport TV+|SPORTV+", "Globo", "Canal 11|11", "TVI Ficção", "Porto Canal", "SIC Caras", "SIC Radical|SIC R", "SIC Mulher|SIC M", "RTP Memória", "24 Kitchen", "Canal Q", "Eurosport 1|Eurosport", "Eurosport 2", "A Bola TV", "SCP|Sporting TV", "Fuel TV", "Disney Channel", "Disney Junior", "Cartoon Network", "Panda", "Biggs|Panda Biggs", "SIC K", "Cartoonito", "Nickelodeon", "Dizi", "Hollywood", "Cinemundo", "FOX Movies", "FOX", "AXN", "FOX Life", "FOX Crime", "FOX Comedy", "AXN White", "AXN Movies", "Syfy", "AMC", "MTV Portugal|MTV", "MTV 00s|MTV00s", "MCM Top", "C Music", "Trace Urban|Trace", "Trace Toca", "Discovery Channel|Discovery", "National Geographic|Nat Geo", "National Geographic Wild|Nat Geo Wild", "História|Historia", "Odisseia", "AMC Crime", "S+", "Casa e Cozinha", "TVI Reality", "Record TV", "AMC Break", "TLC", "E!", "Fashion TV", "Travel Channel|Travel", "BBC Entertainment", "Food Network", "Ginx", "Insight TV", "Gametoon", "ARTV", "Record News", "Euronews", "Bloomberg", "Sky News", "BBC World News|BBC World", "CNBC", "Al Jazeera|Aljazeera English", "TVE 24h", "DW", "France 24", "RTP Madeira", "RTP Açores", "Localvisão TV", "RTP África", "TPA", "Canal 180|180", "TV Galicia", "TVEi", "TV5 Monde", "RAI Uno|RAI 1", "RT DOC", "Russia Today", "PRO TV International", "NHK World", "Cubavision", "Freedom", "Canção Nova", "Kuriakos TV"]}
  };
  const opKey = () => { try{ return LS.get("tvOp", ""); }catch(e){ return ""; } };
  const opCustom = () => { try{ return String(LS.get("tvOpCustom", "") || ""); }catch(e){ return ""; } };
  const nrm = n => String(n || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/^[\s\W_]*(pt|portugal)\b[\s|:\-\/]*/i, "").replace(/\[[^\]]*\]|\([^)]*\)/g, " ").replace(/\b(fhd|uhd|hd|sd|4k|8k|hevc|h265|raw|plus)\b/g, " ").replace(/[^a-z0-9]+/g, "");
  const opOrder = key => key === "custom" ? opCustom().split(/\r?\n/).map(x => x.trim()).filter(Boolean) : ((OPS[key] || {}).list || []);
  const opTitle = key => key === "custom" ? "Ordem personalizada" : "Canais " + ((OPS[key] || {}).label || "");
  function opChannels(key){
    const live = channels.filter(c => c.kind === "live"); if(!live.length) return [];
    const idx = new Map();
    for(const c of live){ const k = nrm(c.name); if(!k) continue; const a = idx.get(k) || []; a.push(c); idx.set(k, a); }
    /* áudio em português: só variantes de categorias PT (ou BR, AO, MZ, CV); categorias sem país vêm depois; ES, FR, GB… ficam de fora */
    const lang = c => { let k = ""; try{ k = window.__cty && window.__cty.ctyOfItem ? window.__cty.ctyOfItem(c) : (isPtGroup(c.group) ? "PT" : "??"); }catch(e){} return /^(PT|BR|AO|MZ|CV)$/.test(k) ? 0 : (k === "??" || k === "" || k.slice(0, 2) === "G:") ? 1 : 2; };
    const q = c => (/\b(fhd|uhd|4k)\b/i.test(c.name) ? 0 : /\bhd\b/i.test(c.name) ? 1 : 2) + lang(c) * 10 + (isPtGroup(c.group) ? 0 : 5);
    const out = [], seen = new Set();
    for(const ent of opOrder(key)){
      let best = null;
      for(const alias of String(ent).split("|")){ const a = idx.get(nrm(alias)); if(a){ for(const c of a) if(!seen.has(c.url) && lang(c) < 2 && (!best || q(c) < q(best))) best = c; } }
      if(best){ seen.add(best.url); out.push(best); }
    }
    return out;
  }
  window.__op = {OPS, opKey, opCustom, opChannels, opTitle};
  /* posições das filas (e do ecrã) memorizadas, para voltares ao mesmo sítio */
  HOME.sc = {}; HOME.y = 0; HOME.my = 0;
  const rowKey = r => { const h = r.querySelector("h2"); return HOME.kind + "|" + (h ? h.textContent : ""); };
  document.addEventListener("scroll", e => {
    if(currentView !== "tvhome") return; const t = e.target;
    if(t && t.classList && t.classList.contains("thScroll")){ const r = t.closest(".thRow"); if(r) HOME.sc[rowKey(r)] = t.scrollLeft; }
    else {
      /* TV: ao subir com o comando para a barra de cima a página rola ao topo sozinha; isso não é a posição onde ficaste */
      const af = document.activeElement; if(document.body.classList.contains("tv") && af && af.closest && af.closest(".top")) return;
      if(t && t.id === "main") HOME.my = t.scrollTop;
      else if(t === document) HOME.y = (document.scrollingElement || document.documentElement).scrollTop;
    }
  }, true);
  const restoreScroll = () => {
    document.querySelectorAll("#thRows .thRow").forEach(r => { const sc = r.querySelector(".thScroll"), v = HOME.sc[rowKey(r)]; if(sc && v) sc.scrollLeft = v; });
    const m = $("main"); if(m && HOME.my) m.scrollTop = HOME.my;
    const d = document.scrollingElement; if(d && HOME.y) d.scrollTop = HOME.y;
  };
  /* o cartão lembrado é identificado pelo canal (url) e pela fila, não pelo índice, que muda quando "Recentes" se atualiza */
  const cardId = el => { try{ const c = HOME.flat[+el.dataset.k]; const r = el.closest(".thRow"); return c ? {u: c.url, r: r ? rowKey(r) : ""} : null; }catch(e){ return null; } };
  const findCard = id => { if(!id) return null; let any = null; for(const el of sec.querySelectorAll("[data-k]")){ const c = HOME.flat[+el.dataset.k]; if(c && c.url === id.u){ const r = el.closest(".thRow"); if(r && rowKey(r) === id.r) return el; any = any || el; } } return any; };
  window.__homeLastCard = () => { try{ if(HOME.lastK == null && !HOME.lastId) return null; return findCard(HOME.lastId) || (HOME.lastK != null ? sec.querySelector('[data-k="' + HOME.lastK + '"]') : null); }catch(e){ return null; } };
  document.addEventListener("focusin", e => { const t = e.target; if(t && t.dataset && t.dataset.k != null && sec.contains(t)){ HOME.lastK = t.dataset.k; HOME.lastId = cardId(t); } }, true);
  window.__heroHtml = (cur, k) => {
    let sub = cur.group || ""; try{ const nn = nowNext(cur); if(nn) sub = hm(nn.now.start) + " " + nn.now.title; }catch(e){}
    return '<div class="thHeroArt">' + (cur.logo ? '<img src="' + esc(cur.logo) + '" alt="" onerror="this.remove()">' : '<b>' + esc((cur.name || "?").slice(0, 2).toUpperCase()) + '</b>') + '</div><div class="thHeroTx"><small>Continuar a ver</small><h1>' + esc(cur.name) + '</h1><p>' + esc(sub) + '</p><div class="thHeroBt"><button class="thBtn pri" data-k="' + k + '">▶ Ver agora</button><button class="thBtn" data-go="tv">🔎 Explorar canais</button></div></div>';
  };
  function renderHome(force){
    if(currentView !== "tvhome") return;
    const t0 = Date.now();
    if(!force && HOME._last && t0 - HOME._last < 600){ if(!HOME._pt) HOME._pt = setTimeout(() => { HOME._pt = 0; renderHome(true); }, 650); return; }
    HOME._last = t0;
    let keepSel = null, keepId = null; const ae = document.activeElement;
    if(ae && ae.dataset && ae.dataset.k != null) keepId = cardId(ae);
    if(ae && ae !== document.body && sec.contains(ae) && ae.dataset){ for(const a of ["k", "kind2", "go", "more"]) if(ae.dataset[a] != null){ keepSel = "[data-" + (a === "kind2" ? "kind2" : a) + '="' + ae.dataset[a] + '"]'; break; } }
    const keep = null;
    HOME.flat = [];
    const cur = window.__pvPick || (lastPlayed && (lastPlayed[0] || lastPlayed[1])) || recents()[0] || null;
    const hasList = channels.length > 0;
    let hero = "";
    if(cur){
      HOME.flat.push(cur); const k = HOME.flat.length - 1;
      hero = window.__heroHtml(cur, k);
    } else {
      hero = '<div class="thHeroTx"><small>Cockpit TV</small><h1>Bem-vindo</h1><p>' + (hasList ? "Escolhe um canal em baixo para começar." : "Os canais abertos portugueses já estão disponíveis. Para ver mais, adiciona a tua lista IPTV nas Definições.") + '</p><div class="thHeroBt"><button class="thBtn pri" data-go="tv">🔎 Explorar canais</button><button class="thBtn" data-go="settings">⚙ Definições</button></div></div>';
    }
    HOME._heroK = cur ? HOME.flat.length - 1 : -1;
    const heroChanged = HOME._hh !== hero; if(heroChanged){ $("thHero").innerHTML = hero; HOME._hh = hero; }
    let rows = '<div class="thKinds">' + KINDS.map(([k, ic, t]) => '<button class="thBtn thKind" data-kind2="' + k + '" aria-pressed="' + (HOME.kind === k) + '">' + ic + " " + t + '</button>').join("") + '<button class="thBtn" data-srch="1">🔎 Pesquisar</button></div>';
    if(HOME.kind !== "live"){
      const rl = RES.list(HOME.kind).slice(0, 20).map(e => Object.assign({}, e, {_pct:Math.round(e.p / e.d * 100), _sub:(e.group ? e.group + " · " : "") + Math.max(1, Math.round((e.d - e.p) / 60)) + " min restantes"}));
      rows += row("▶ Continuar a ver", rl, "");
    }
    { const fl = window.__favList ? window.__favList(HOME.kind) : []; if(fl.length) rows += row("⭐ Favoritos", fl.slice(0, 40), ""); }
    if(HOME.kind === "live"){ const rv = recents().filter(x => x && x.url && !/^(movie|series|episode|vod)$/.test(x.kind || "") && !(cur && cur.url === x.url)).slice(0, 20); if(rv.length) rows += row("🕘 Vistos recentemente", rv, ""); }
    if(HOME.kind === "live"){ const ok = opKey(); if(ok){ const ol = opChannels(ok); if(ol.length) rows += row("📺 " + esc(opTitle(ok)), ol.slice(0, 60), ""); } }
    /* com países ordenados/escondidos nas Definições, o Início mostra as categorias dos países visíveis, pela ordem escolhida */
    let pg = (window.__cty && window.__cty.active()) ? (() => { const gm = groupsOf(HOME.kind); return orgGroupList(HOME.kind, [...gm.keys()], false).map(n => [n, gm.get(n)]); })() : ptGroups(HOME.kind), anyCat = false;
    if(!pg.length && HOME.kind !== "live"){
      /* Filmes e séries: as categorias nem sempre começam por «PT». Procura PT/Portugal em qualquer parte do nome; se não houver, mostra as categorias que existirem. */
      const m = groupsOf(HOME.kind), names = orgGroupList(HOME.kind, [...m.keys()], false);
      const re = /(^|[^A-Za-zÀ-ÿ])(PT|PT-PT|PORTUGAL|PORTUGU[EÊ]S|PORTUGUESA|LUSO)([^A-Za-zÀ-ÿ]|$)|🇵🇹/i;
      let sel = names.filter(n => re.test(n));
      if(!sel.length){ sel = names; anyCat = true; }
      pg = sel.map(n => [n, m.get(n)]);
    }
    HOME.lim = HOME.lim || {}; for(const [g, l] of pg.slice(0, 14)){ const lk = HOME.kind + "|" + g, n = HOME.kind === "live" ? 40 : (HOME.lim[lk] || 25); rows += row(esc(g), l.slice(0, n), "", l.length, HOME.kind === "live" ? "" : lk); }
    if(!pg.length && HOME.kind === "live" && !channels.some(c => c.kind === "live")) rows += row("📡 Canais abertos PT", freeChans.filter(c => typeof hState !== "function" || hState(c) !== "dead").slice(0, 40), "free");
    if(!pg.length){
      const kl = ((KINDS.find(x => x[0] === HOME.kind) || [])[2] || "conteúdos").toLowerCase();
      const tot = channels.filter(c => c.kind === HOME.kind).length;
      if(HOME.kind !== "live" || tot){
        if(tot && window.__cty && window.__cty.active()) rows += '<p class="thEmpty">Tens ' + tot + ' ' + kl + ' carregados, mas as definições de <b>Países</b> escondem todas as categorias.</p><div class="thKinds"><button class="thBtn pri" data-ctyreset="1">Mostrar todos os países</button></div>';
        else if(tot) rows += '<p class="thEmpty">Tens ' + tot + ' ' + kl + ' carregados, mas nenhuma categoria visível. Abre Explorar para os ver.</p>';
        else rows += '<p class="thEmpty">Sem ' + kl + ' carregados. Se a tua lista tem filmes e séries, abre Explorar uma vez para os carregar.</p>';
      }
    }
    if(!rows.includes("thRow") && !rows.includes("thEmpty")) rows += '<p class="thEmpty">' + (typeof freeLoading !== "undefined" && freeLoading ? "A carregar canais…" : "Sem canais para mostrar. Verifica a ligação à internet.") + '</p>';
    const rowsChanged = HOME._rr !== rows; if(rowsChanged){ $("thRows").innerHTML = rows; HOME._rr = rows; }
    if(heroChanged || rowsChanged) restoreScroll();
    if(keepSel && (heroChanged || rowsChanged)){ const el = (keepId && findCard(keepId)) || sec.querySelector(keepSel) || sec.querySelector(".thKind[aria-pressed=true]") || sec.querySelector(".thBtn.pri,.thCard"); if(el) el.focus({preventScroll:true}); }
  }

  function watch(c){
    if(!c) return;
    window.__pvPick = null;
    /* canal em direto do Início: o ecrã nativo abre com os canais que o Início mostra */
    if(c.kind === "live" && HOME.flat && HOME.flat.some(x => x && x.url === c.url)){
      try{ const seen = new Set(), L = []; HOME.flat.forEach(x => { if(x && x.kind === "live" && x.url && !seen.has(x.url)){ seen.add(x.url); L.push(x); } }); window.__tvShown = L; }catch(e){}
    }
    window.__homeOrigin = true;
    if(c.kind === "series" && c.sid){ openSeries(c); return; }
    playChannel(c);
    setTimeout(() => { if(currentView === "tv"){ if(!document.querySelector(".app").classList.contains("cinema")) setCinema(true); const st = $("stage"); if(st) st.focus({preventScroll:true}); } }, 140);
    /* canal em direto escolhido no Início: ecrã total, imagem esticada */
    if(!/^(movie|series|episode|vod)$/.test(c.kind || "")){
      try{ LS.set("tvAspect_live", "stretch"); }catch(e){}
      const t0 = Date.now(); window.__fsGrace = t0 + 9000;
      const tick = () => {
        if(Date.now() - t0 > 8000) return;
        try{
          if(currentView === "tv" && window.__setFull){
            window.__aspect && window.__aspect.apply(false);
            if(!document.body.classList.contains("vfull")) window.__setFull(true);
            if(Date.now() - t0 > 2500) return;   /* ficou em ecrã total e estável */
          }
        }catch(e){}
        setTimeout(tick, 350);
      };
      try{ if(currentView === "tv" && window.__setFull && !document.body.classList.contains("vfull")){ window.__aspect && window.__aspect.apply(false); window.__setFull(true); } }catch(e){}   /* já, sem esperar */
      setTimeout(tick, 120);
    }
  }
  window.__watch = watch;
  sec.addEventListener("click", e => {
    const b = e.target.closest("[data-k],[data-more],[data-go],[data-kind2],[data-ctyreset],[data-lm]"); if(!b) return;
    if(b.dataset.lm){ HOME.lim[b.dataset.lm] = (HOME.lim[b.dataset.lm] || 25) + 25; HOME._rr = null; renderHome(true); return; }
    if(b.dataset.ctyreset){ try{ const C = window.__cty, s2 = C.state(); s2.order = []; s2.hide = []; C.save(); if(typeof fillGroups === "function") fillGroups(); if(typeof renderTvList === "function") renderTvList(); }catch(x){} HOME._rr = null; renderHome(true); return; }
    if(b.dataset.kind2){ HOME.kind = b.dataset.kind2; HOME.lastK = null; try{ LS.set("thKind", HOME.kind); }catch(x){} HOME._hh = HOME._rr = null; renderHome(true); const nb = sec.querySelector('[data-kind2="' + HOME.kind + '"]'); if(nb) nb.focus({preventScroll:true}); return; }
    if(b.dataset.k != null){
      HOME.lastK = b.dataset.k; const c = HOME.flat[+b.dataset.k];
      /* um toque num canal do Início só o põe na pré-visualização; o duplo toque na imagem (ou «Ver agora») abre o ecrã total */
      try{
        const pvOk = c && c.kind === "live" && !b.closest("#thHero") && window.__NSC && __NSC.on() && typeof Android.nplay === "function" && LS.get("tvPrev", "on") !== "off";
        if(pvOk){
          const now = window.__pvPick || recents()[0];
          if(!now || now.url !== c.url){
            pushRecent(c); window.__pvPick = c;
            if(HOME._heroK >= 0 && HOME.flat[HOME._heroK]){   /* só muda a imagem/texto do topo; o resto do Início não é redesenhado */
              HOME.flat[HOME._heroK] = c; const hh = window.__heroHtml(c, HOME._heroK); $("thHero").innerHTML = hh; HOME._hh = hh;
            } else { HOME._hh = null; renderHome(true); }
            try{ if(window.__pvTick) window.__pvTick(); }catch(x){} return;
          }
        }
      }catch(x){}
      watch(c);
    }
    else if(b.dataset.more){ window.__homeOrigin = false; show("tv"); const t = document.querySelector('[data-kind="' + b.dataset.more + '"]'); if(t) t.click(); }
    else if(b.dataset.go){ window.__homeOrigin = false; try{ if(b.dataset.go === "tv" && window.__NSC) __NSC.explore(); }catch(x){} show(b.dataset.go); }
  });

  /* ===== Arranque rápido: listas em cache aparecem logo e atualizam em segundo plano; guia (EPG) guardado ===== */
  (function(){
    const H12 = 12 * 3600e3;
    let quiet = false;
    try{ const _t = window.toast; if(typeof _t === "function") window.toast = function(m, e){ if(quiet && e) return; return _t.apply(this, arguments); }; }catch(e){}
    const stamp = () => { try{ LS.set("chT", Date.now()); }catch(e){} };
    try{ const _li = window.loadIptv; if(typeof _li === "function") window.loadIptv = async function(force){ const r = await _li.apply(this, arguments); if(force) stamp(); return r; }; }catch(e){}
    /* lista pública: usa logo a cache (mesmo antiga) e renova depois */
    try{ const _lf = window.loadFreeTv; if(typeof _lf === "function") window.loadFreeTv = async function(force){
      if(!force){ const c = LS.get("freeTv", null);
        if(c && c.list && c.list.length){ freeChans = c.list;
          if(Date.now() - (c.t || 0) >= 6 * 3600e3 && !window.__lfBg){ window.__lfBg = 1; setTimeout(() => { _lf.call(window, true).then(() => { try{ HOME._hh = HOME._rr = null; if(currentView === "tvhome") renderHome(); }catch(e){} }).catch(() => {}).finally(() => { window.__lfBg = 0; }); }, 4000); }
          return freeChans; } }
      return _lf.apply(this, arguments); }; }catch(e){}
    /* guia: guardado em disco 3 h, evita descarregar o XMLTV em cada arranque */
    try{ const _le = window.loadEpg; if(typeof _le === "function") window.loadEpg = async function(){
      try{ if(!cfg.epg) return; const c = await IDB.get("epgC"); if(c && c.m && c.u === cfg.epg && Date.now() - c.t < 3 * 3600e3){ epg = c.m; return; } }catch(e){}
      await _le.apply(this, arguments);
      try{ if(cfg.epg && epg && Object.keys(epg).length) IDB.set("epgC", {t:Date.now(), u:cfg.epg, m:epg}); }catch(e){} }; }catch(e){}
    /* se a lista de canais tem mais de 12 h, renova-a discretamente passado o arranque */
    setTimeout(() => {
      try{
        const t = LS.get("chT", 0); if(!t){ stamp(); return; }
        if(Date.now() - t < H12) return;
        if(!((cfg.xs && cfg.xu && cfg.xp) || cfg.m3u)) return;
        quiet = true; stamp();
        Promise.resolve(window.loadIptv(true)).catch(() => {}).finally(() => { quiet = false; try{ HOME._hh = HOME._rr = null; if(currentView === "tvhome") renderHome(); }catch(e){} });
      }catch(e){}
    }, 8000);
  })();

  /* ===== Favoritos ordenáveis (Início) ===== */
  window.__favList = kind => {
    try{
      const ord = LS.get("favOrd", []) || [];
      const pool = [...channels, ...(typeof freeChans !== "undefined" ? freeChans : [])];
      const seen = new Set();
      const list = pool.filter(c => c && favs.has(c.url) && !seen.has(c.url) && seen.add(c.url) && !(window.__par && window.__par.blocks(c)) &&
        (kind === "live" ? !/^(movie|series|episode|vod)$/.test(c.kind || "") : kind === "movie" ? c.kind === "movie" : c.kind === "series"));
      const rk = c => { const i = ord.indexOf(c.url); return i < 0 ? 1e6 : i; };
      return list.sort((a, b) => rk(a) - rk(b));
    }catch(e){ return []; }
  };

  /* ===== Pesquisa global (canais, filmes e séries) ===== */
  (function(){
    const nz = t => String(t || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase();
    const open = () => {
      if(document.getElementById("thSrch")) return;
      const d = document.createElement("div"); d.id = "thSrch";
      d.innerHTML = '<div class="thSrBox"><div class="thSrTop"><input id="thSrIn" type="text" placeholder="Pesquisar canais, filmes, séries…" autocomplete="off"><button class="thBtn" id="thSrX">✕ Fechar</button></div><div class="thSrRes" id="thSrRes"></div></div>';
      document.body.appendChild(d);
      const inp = d.querySelector("#thSrIn"), res = d.querySelector("#thSrRes");
      const back = document.activeElement;
      const close = () => { try{ d.remove(); window.removeEventListener("keydown", onKey, true); }catch(e){} try{ if(back && document.contains(back)) back.focus({preventScroll:true}); }catch(e){} };
      const onKey = e => { if(e.key === "Escape" || e.key === "GoBack" || e.keyCode === 4){ e.preventDefault(); e.stopImmediatePropagation(); close(); return; }
        const x = d.querySelector("#thSrX"), first = res.querySelector(".thSrI"), t = document.activeElement;
        if(e.key === "ArrowUp" && x && (t === inp || t === first)){ e.preventDefault(); e.stopImmediatePropagation(); x.focus(); }
        else if((e.key === "ArrowDown" || e.key === "ArrowLeft") && x && t === x){ e.preventDefault(); e.stopImmediatePropagation(); if(e.key === "ArrowLeft" || !first) inp.focus(); else first.focus(); }
        else if(e.key === "ArrowDown" && t === inp && first){ e.preventDefault(); e.stopImmediatePropagation(); first.focus(); }
        else if(e.key === "ArrowRight" && t === inp && inp.selectionStart === inp.value.length && x){ e.preventDefault(); e.stopImmediatePropagation(); x.focus(); } };
      window.addEventListener("keydown", onKey, true);
      d.querySelector("#thSrX").onclick = close;
      let cur = [], tm = null;
      const run = () => {
        const q = nz(inp.value).split(/\s+/).filter(Boolean);
        if(!q.length){ res.innerHTML = '<p class="thEmpty">Escreve para pesquisar.</p>'; cur = []; return; }
        const pool = [...channels, ...(typeof freeChans !== "undefined" ? freeChans : [])], seen = new Set(), out = [];
        for(const c of pool){
          if(!c || !c.url || seen.has(c.url)) continue;
          const n = nz(c.name); if(!q.every(w => n.indexOf(w) >= 0)) continue;
          if(window.__par && window.__par.blocks(c)) continue;
          seen.add(c.url); out.push(c); if(out.length >= 80) break;
        }
        out.sort((a, b) => (nz(a.name).indexOf(q[0]) === 0 ? 0 : 1) - (nz(b.name).indexOf(q[0]) === 0 ? 0 : 1));
        cur = out;
        const ic = c => c.kind === "movie" ? "🎬" : c.kind === "series" ? "📺" : c.kind === "episode" ? "▶" : "📡";
        res.innerHTML = out.length ? out.map((c, i) => '<button class="thBtn thSrI" data-i="' + i + '">' + ic(c) + ' <b>' + esc(c.name) + '</b><small> ' + esc(c.group || "") + '</small></button>').join("") : '<p class="thEmpty">Sem resultados.</p>';
      };
      inp.addEventListener("input", () => { clearTimeout(tm); tm = setTimeout(run, 180); });
      res.addEventListener("click", e => { const b = e.target.closest("[data-i]"); if(!b) return; const c = cur[+b.dataset.i]; close(); if(!c) return;
        if(c.kind === "live"){ try{ window.__tvShown = cur.filter(x => x && x.kind === "live" && x.url); window.__homeOrigin = true; }catch(x){} }   /* canal da pesquisa: abre no ecrã nativo */
        watch(c); });
      run(); setTimeout(() => { try{ inp.focus(); }catch(e){} }, 60);
    };
    sec.addEventListener("click", e => { const b = e.target.closest("[data-srch]"); if(b){ e.preventDefault(); open(); } }, true);
    window.__globalSearch = open;
  })();

  /* ===== Canal em direto falhou: tenta uma versão alternativa do mesmo canal ===== */
  (function(){
    const nzn = n => String(n || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/\[[^\]]*\]|\([^)]*\)/g, " ").replace(/\b(fhd|uhd|hd|sd|4k|hevc|raw|plus|pt|portugal)\b/g, " ").replace(/[^a-z0-9]+/g, "");
    const tried = new Set();
    window.__altFor = c => {
      try{
        if(!c || c.kind !== "live") return null;
        const k = nzn(c.name); if(!k) return null;
        tried.add(c.url);
        const pool = [...channels, ...(typeof freeChans !== "undefined" ? freeChans : [])];
        return pool.find(x => x && x.url && x.url !== c.url && !tried.has(x.url) && x.kind !== "movie" && x.kind !== "series" && nzn(x.name) === k && !(window.__par && window.__par.blocks(x))) || null;
      }catch(e){ return null; }
    };
    window.__altReset = () => tried.clear();
  })();

  /* ===== Animações de scroll do Início (selecionáveis em Definições → Aparência e layout) ===== */
  (function(){
    const ANS = [["nenhuma", "Sem animação", "Tudo aparece de imediato."], ["suave", "Suave", "Os cartões sobem e aparecem sempre que entram no ecrã."], ["cascata", "Cascata", "Os cartões entram um a um, em sequência."], ["zoom", "Zoom", "Os cartões crescem com um pequeno ressalto."], ["slide", "Deslizar", "As filas entram pelo lado ao descer o ecrã."], ["flow", "Carrossel", "Os cartões do centro da fila ficam maiores; os das pontas encolhem."]];
    const A = window.__thAnim = {id: (function(){ try{ const v = LS.get("tvAnim", "suave"); return ANS.some(x => x[0] === v) ? v : "suave"; }catch(e){ return "suave"; } })()};
    const rows = () => $("thRows");
    const vis = new Set();
    let io = null, raf = 0, fired = false, armT = 0;
    const cls = () => { ANS.forEach(x => document.body.classList.toggle("an-" + x[0], A.id === x[0])); };
    const keyOf = el => { try{ const r = el.closest(".thRow"), h = r && r.querySelector("h2"), t = h ? h.textContent : ""; if(el.classList.contains("thRow")) return HOME.kind + "|" + t; const c = HOME.flat[+el.dataset.k]; return HOME.kind + "|" + t + "|" + (c ? c.url : el.dataset.k); }catch(e){ return ""; } };
    const flowAll = () => {
      raf = 0; if(A.id !== "flow" || currentView !== "tvhome") return;
      document.querySelectorAll("#thRows .thScroll").forEach(sc => {
        const r = sc.getBoundingClientRect(); if(r.bottom < 0 || r.top > innerHeight || r.width < 50) return;
        const cx = r.left + r.width / 2, half = r.width / 2;
        sc.querySelectorAll(".thCard").forEach(c => { const q = c.getBoundingClientRect(); if(q.right < r.left - 60 || q.left > r.right + 60) return;
          const d = Math.min(1, Math.abs(q.left + q.width / 2 - cx) / half);
          c.style.setProperty("--s", (1.08 - d * 0.28).toFixed(3)); c.style.setProperty("--o", (1 - d * 0.5).toFixed(3)); });
      });
    };
    const kick = () => { if(!raf) raf = requestAnimationFrame(flowAll); };
    const onIo = es => {
      fired = true; let n = 0;
      es.filter(e => e.isIntersecting).sort((a, b) => (a.boundingClientRect.top - b.boundingClientRect.top) || (a.boundingClientRect.left - b.boundingClientRect.left)).forEach(e => {
        const el = e.target; vis.add(keyOf(el));
        if(!el.classList.contains("in")){ el.style.setProperty("--d", Math.min(n++, 10) * 70 + "ms"); el.classList.add("in", "thRev"); setTimeout(() => el.classList.remove("thRev"), 1400); }
      });
      es.filter(e => !e.isIntersecting).forEach(e => { const el = e.target; vis.delete(keyOf(el)); el.classList.remove("in", "thRev"); });
      kick();
    };
    const refresh = () => {
      const R = rows(); if(!R) return;
      try{ if(io){ io.disconnect(); io = null; } }catch(e){}
      clearTimeout(armT); R.classList.remove("thArm"); fired = false;
      const all = [...R.querySelectorAll(".thCard")];
      all.forEach(c => c.style.setProperty("--i", 0));
      const sel = A.id === "slide" ? ".thRow" : ".thCard";
      const els = [...R.querySelectorAll(sel)];
      if(A.id === "nenhuma" || typeof IntersectionObserver !== "function"){ els.forEach(c => c.classList.add("in")); kick(); return; }
      /* o que já estava visível (a lista só foi atualizada) mantém-se, sem animar outra vez */
      els.forEach(el => { if(vis.has(keyOf(el))) el.classList.add("in"); else el.classList.remove("in", "thRev"); });
      try{
        io = new IntersectionObserver(onIo, {threshold:0.1});
        R.classList.add("thArm"); els.forEach(el => io.observe(el));
      }catch(e){ R.classList.remove("thArm"); els.forEach(c => c.classList.add("in")); }
      /* rede de segurança: se o observador não responder, mostra tudo */
      armT = setTimeout(() => { if(!fired){ try{ R.querySelectorAll(".thCard,.thRow").forEach(c => c.classList.add("in")); R.classList.remove("thArm"); }catch(e){} } }, 2500);
      kick();
    };
    const apply = () => {
      cls(); try{ LS.set("tvAnim", A.id); }catch(e){}
      document.querySelectorAll("[data-an]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.an === A.id)));
      document.querySelectorAll("#thRows .thCard").forEach(c => { c.style.removeProperty("--s"); c.style.removeProperty("--o"); });
      vis.clear(); document.querySelectorAll("#thRows .thCard,#thRows .thRow").forEach(c => c.classList.remove("in", "thRev"));
      refresh();
    };
    try{ const R = rows(); if(R) new MutationObserver(() => { setTimeout(refresh, 30); }).observe(R, {childList:true}); }catch(e){}
    document.addEventListener("scroll", e => { if(A.id === "flow" && e.target && e.target.classList && e.target.classList.contains("thScroll")) kick(); }, true);
    window.addEventListener("resize", kick);
    /* ao voltar ao Início repete a entrada */
    window.__thAnimReplay = () => { vis.clear(); document.querySelectorAll("#thRows .thCard,#thRows .thRow").forEach(c => c.classList.remove("in", "thRev")); refresh(); };
    /* cartão nas Definições */
    try{
      const card = $("tvLayoutCard");
      if(card){
        const w = document.createElement("div");
        let h = '<h3 style="margin:14px 0 6px">Animação ao deslizar (filmes e canais)</h3><div class="tplGrid">';
        ANS.forEach(([id, nm, ds]) => { h += '<button class="btn tplBtn" data-an="' + id + '"><b>' + nm + '</b><small>' + ds + '</small></button>'; });
        h += '</div><p class="small muted" style="margin:8px 0 0">Para ver o efeito, volta ao Início e desliza as filas.</p>'; w.innerHTML = h; card.appendChild(w);
        w.querySelectorAll("[data-an]").forEach(b => b.onclick = () => { A.id = b.dataset.an; apply(); });
      }
    }catch(e){}
    apply();
  })();

  /* ===== Efeitos ao deslizar o Início para baixo/cima (Definições → Aparência e layout) ===== */
  (function(){
    const VF = [["nenhuma", "Sem efeito", "As filas ficam paradas."], ["profundidade", "Profundidade", "As filas junto às bordas encolhem e ficam transparentes."], ["onda", "Onda", "As filas ondulam para os lados ao deslizar."], ["parallax", "Parallax", "O destaque esmorece e as filas aproximam-se ao subir."]];
    const B = window.__thVfx = {id: (function(){ try{ const v = LS.get("tvVfx", "profundidade"); return VF.some(x => x[0] === v) ? v : "profundidade"; }catch(e){ return "profundidade"; } })()};
    let raf = 0;
    const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
    const clear = () => {
      document.querySelectorAll("#thRows .thRow").forEach(r => { ["--vx", "--vy", "--vs", "--vo"].forEach(k => r.style.removeProperty(k)); });
      const tx = document.querySelector("#thHero .thHeroTx"); if(tx){ tx.style.opacity = ""; tx.style.transform = ""; }
    };
    const upd = () => {
      raf = 0; if(B.id === "nenhuma" || currentView !== "tvhome") return;
      const H = innerHeight || 700;
      document.querySelectorAll("#thRows .thRow").forEach((r, i) => {
        const q = r.getBoundingClientRect(); if(q.bottom < -120 || q.top > H + 120) return;
        const p = clamp((q.top + q.height / 2 - H * 0.5) / (H * 0.55), -1, 1), ap = Math.abs(p);
        let vx = 0, vy = 0, vs = 1, vo = 1;
        if(B.id === "profundidade"){ vs = 1 - ap * 0.07; vo = 1 - ap * 0.55; }
        else if(B.id === "onda"){ vx = p * (i % 2 ? 1 : -1) * 56; vo = 1 - ap * 0.4; }
        else if(B.id === "parallax"){ const d = Math.max(0, p); vy = -p * 16; vs = 1 - d * 0.05; vo = 1 - d * 0.5; }
        r.style.setProperty("--vx", vx.toFixed(1) + "px"); r.style.setProperty("--vy", vy.toFixed(1) + "px"); r.style.setProperty("--vs", vs.toFixed(3)); r.style.setProperty("--vo", vo.toFixed(3));
      });
      /* o vídeo de pré-visualização segue o quadro do destaque: só o texto esmorece, o quadro não se mexe */
      const hero = $("thHero"), tx = hero && hero.querySelector(".thHeroTx");
      if(tx){ if(B.id === "parallax"){ const hr = hero.getBoundingClientRect(); const f = clamp(1 + hr.top / Math.max(120, hr.height * 1.1), 0, 1); tx.style.opacity = f.toFixed(2); } else tx.style.opacity = ""; }
    };
    const kick = () => { if(!raf) raf = requestAnimationFrame(upd); };
    document.addEventListener("scroll", e => { const t = e.target; if(t === document || (t && t.id === "main")) kick(); }, true);
    window.addEventListener("resize", kick);
    try{ const R = $("thRows"); if(R) new MutationObserver(() => setTimeout(kick, 60)).observe(R, {childList:true}); }catch(e){}
    const apply = () => {
      document.body.classList.toggle("vf-on", B.id !== "nenhuma");
      VF.forEach(x => document.body.classList.toggle("vf-" + x[0], B.id === x[0]));
      try{ LS.set("tvVfx", B.id); }catch(e){}
      document.querySelectorAll("[data-vf]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.vf === B.id)));
      clear(); kick();
    };
    try{
      const card = $("tvLayoutCard");
      if(card){
        const w = document.createElement("div");
        let h = '<h3 style="margin:14px 0 6px">Efeito ao deslizar o ecrã para baixo</h3><div class="tplGrid">';
        VF.forEach(([id, nm, ds]) => { h += '<button class="btn tplBtn" data-vf="' + id + '"><b>' + nm + '</b><small>' + ds + '</small></button>'; });
        h += '</div>'; w.innerHTML = h; card.appendChild(w);
        w.querySelectorAll("[data-vf]").forEach(b => b.onclick = () => { B.id = b.dataset.vf; apply(); });
      }
    }catch(e){}
    apply();
  })();

  /* ===== Som suave ao deslizar (Início) ===== */
  (function(){
    const LV = [["off", "Desligado", 0], ["suave", "Suave", 0.035], ["normal", "Normal", 0.09]];
    const S = window.__thSnd = {id: (function(){ try{ const v = LS.get("tvSnd", "suave"); return LV.some(x => x[0] === v) ? v : "suave"; }catch(e){ return "suave"; } })()};
    let ac = null, last = 0, acc = {}, lastFocus = null;
    const ctx = () => { try{ if(!ac){ const C = window.AudioContext || window.webkitAudioContext; if(!C) return null; ac = new C(); } if(ac.state === "suspended") ac.resume(); return ac; }catch(e){ return null; } };
    const tick = (pitch) => {
      try{
        const g0 = (LV.find(x => x[0] === S.id) || [0, 0, 0])[2]; if(!g0) return;
        if(currentView !== "tvhome" || document.hidden) return;
        const now = performance.now(); if(now - last < 70) return; last = now;
        const a = ctx(); if(!a || a.state !== "running") return;
        const t = a.currentTime, o = a.createOscillator(), g = a.createGain();
        o.type = "sine"; o.frequency.setValueAtTime(pitch || 720, t); o.frequency.exponentialRampToValueAtTime((pitch || 720) * 0.62, t + 0.05);
        g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(g0, t + 0.006); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.07);
        o.connect(g); g.connect(a.destination); o.start(t); o.stop(t + 0.08);
      }catch(e){}
    };
    window.__thTick = tick;
    /* o áudio só pode começar depois de um toque/tecla */
    ["touchstart", "pointerdown", "keydown", "click"].forEach(n => document.addEventListener(n, () => { if(S.id !== "off") ctx(); }, {passive:true, capture:true}));
    /* deslizar: um som a cada ~150 px na horizontal e ~220 px na vertical */
    document.addEventListener("scroll", e => {
      if(S.id === "off" || currentView !== "tvhome") return;
      const t = e.target; let key, pos, step, pitch;
      if(t && t.classList && t.classList.contains("thScroll")){ key = "h" + (t.parentElement && t.parentElement.querySelector("h2") ? t.parentElement.querySelector("h2").textContent : ""); pos = t.scrollLeft; step = 150; pitch = 760; }
      else if(t === document || (t && t.id === "main")){ key = "v"; pos = t === document ? (document.scrollingElement || document.documentElement).scrollTop : t.scrollTop; step = 220; pitch = 560; }
      else return;
      const a = acc[key]; if(a == null){ acc[key] = pos; return; }
      if(Math.abs(pos - a) >= step){ acc[key] = pos; tick(pitch); }
    }, true);
    /* comando da TV: som ao mudar de cartão */
    document.addEventListener("focusin", e => { const t = e.target; if(S.id === "off" || !t || !t.dataset || t.dataset.k == null || t === lastFocus) return; lastFocus = t; tick(680); }, true);
    /* cartão nas Definições */
    try{
      const card = $("tvLayoutCard");
      if(card){
        const w = document.createElement("div");
        let h = '<h3 style="margin:14px 0 6px">Som ao deslizar</h3><div class="tplGrid">';
        LV.forEach(([id, nm]) => { h += '<button class="btn tplBtn" data-snd="' + id + '"><b>' + nm + '</b></button>'; });
        h += '</div>'; w.innerHTML = h; card.appendChild(w);
        const paint = () => w.querySelectorAll("[data-snd]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.snd === S.id)));
        w.querySelectorAll("[data-snd]").forEach(b => b.onclick = () => { S.id = b.dataset.snd; try{ LS.set("tvSnd", S.id); }catch(e){} paint(); if(S.id !== "off"){ ctx(); const keep = currentView; setTimeout(() => { const cv = currentView; try{ window.__sndTest = 1; }catch(x){} tickTest(); }, 60); } });
        const tickTest = () => { try{ const g0 = (LV.find(x => x[0] === S.id) || [0, 0, 0])[2]; const a = ctx(); if(!a || !g0) return; const t = a.currentTime, o = a.createOscillator(), g = a.createGain(); o.type = "sine"; o.frequency.setValueAtTime(720, t); o.frequency.exponentialRampToValueAtTime(450, t + 0.05); g.gain.setValueAtTime(0.0001, t); g.gain.exponentialRampToValueAtTime(g0, t + 0.006); g.gain.exponentialRampToValueAtTime(0.0001, t + 0.07); o.connect(g); g.connect(a.destination); o.start(t); o.stop(t + 0.08); }catch(e){} };
        paint();
      }
    }catch(e){}
  })();

  /* ===== Toque longo (ou tecla Menu) num canal/filme recente: remover ===== */
  (function(){
    const ctxOf = b => { try{ const h = b.closest(".thRow") && b.closest(".thRow").querySelector("h2"); const t = h ? h.textContent : ""; return /Favoritos/.test(t) ? "fav" : (/Continuar a ver|Vistos recentemente/.test(t) ? "rec" : ""); }catch(e){ return ""; } };
    const favUrls = () => (window.__favList ? window.__favList(HOME.kind) : []).map(x => x.url);
    const moveFav = (c, d) => { const l = favUrls(), i = l.indexOf(c.url), j = i + d; if(i < 0 || j < 0 || j >= l.length) return; l.splice(j, 0, l.splice(i, 1)[0]); try{ LS.set("favOrd", l.concat((LS.get("favOrd", []) || []).filter(u => l.indexOf(u) < 0))); }catch(e){} HOME._hh = HOME._rr = null; renderHome(true); };
    const ask = (c, ctx) => {
      if(!c || !ctx || document.getElementById("thRmDlg")) return;   /* só nas listas Favoritos / Continuar a ver / Vistos recentemente */
      const isFav = ctx === "fav";
      const inRes = (() => { try{ return !!RES.all()[c.url]; }catch(e){ return false; } })();
      const d = document.createElement("div"); d.id = "thRmDlg";
      d.innerHTML = '<div class="thRmBox" role="dialog"><h3>' + (isFav ? "Favorito" : "Remover dos recentes?") + '</h3><p>' + esc(c.name || "") + (!isFav && inRes ? '<br><small>Perde o ponto onde ficaste.</small>' : "") + '</p><div class="thRmBt"><button class="thBtn" data-x="0">Cancelar</button>' + (isFav ? '<button class="thBtn" data-x="L">◀ Antes</button><button class="thBtn" data-x="R">Depois ▶</button>' : "") + '<button class="thBtn pri" data-x="1">🗑 ' + (isFav ? "Tirar" : "Remover") + '</button></div></div>';
      document.body.appendChild(d);
      const back = document.activeElement;
      const rowEl = back && back.closest ? back.closest(".thRow") : null, rowH = rowEl && rowEl.querySelector("h2") ? rowEl.querySelector("h2").textContent : "";
      const idx = rowEl ? [...rowEl.querySelectorAll("[data-k]")].indexOf(back) : -1;
      const refocus = () => { setTimeout(() => { try{
        const rr = [...sec.querySelectorAll(".thRow")].find(r => r.querySelector("h2") && r.querySelector("h2").textContent === rowH);
        const cs = rr ? [...rr.querySelectorAll("[data-k]")] : [];
        const t = cs[Math.max(0, Math.min(idx, cs.length - 1))] || sec.querySelector("[data-k]") || sec.querySelector("button,[tabindex]");
        if(t) t.focus({preventScroll:true});
      }catch(e){} }, 80); };
      const close = () => { fired = Date.now(); try{ d.remove(); window.removeEventListener("keydown", onKey, true); }catch(e){} try{ if(back && document.contains(back)) back.focus({preventScroll:true}); }catch(e){} };
      const onKey = e => { if(e.key === "Escape" || e.key === "GoBack" || e.keyCode === 4){ e.preventDefault(); e.stopImmediatePropagation(); close(); } };
      window.addEventListener("keydown", onKey, true);
      d.addEventListener("click", e => {
        const b = e.target.closest("[data-x]");
        if(!b){ if(e.target === d) close(); return; }
        if(b.dataset.x === "L" || b.dataset.x === "R"){ close(); moveFav(c, b.dataset.x === "L" ? -1 : 1); return; }
        if(b.dataset.x === "1"){ if(isFav){ try{ favs.delete(c.url); LS.set("tvfavs", [...favs]); }catch(e){} HOME._hh = HOME._rr = null; renderHome(true); } else remove(c); refocus(); }
        close();
      });
      const rb = d.querySelector('[data-x="1"]'); if(rb) rb.focus({preventScroll:true});
    };
    const remove = c => {
      try{
        LS.set(REC, recents().filter(x => x.url !== c.url));
        const a = RES.all(); if(a[c.url]){ delete a[c.url]; LS.set("resume", a); }
        for(const i of [0, 1]){ const l = lastPlayed[i]; if(l && l.url === c.url){ lastPlayed[i] = null; try{ LS.set("last" + i, null); }catch(e){} } }
      }catch(e){}
      /* só tira o cartão das filas de recentes (o resto do Início não é redesenhado); o topo só muda se era o canal em pré-visualização */
      let did = false;
      try{
        const hc = HOME._heroK >= 0 ? HOME.flat[HOME._heroK] : null;
        if(!(hc && hc.url === c.url)){
          sec.querySelectorAll("#thRows .thRow").forEach(r => {
            const tt = (r.querySelector("h2") || {}).textContent || ""; if(!/Continuar a ver|Vistos recentemente/.test(tt)) return;
            r.querySelectorAll("[data-k]").forEach(el => { const x = HOME.flat[+el.dataset.k]; if(x && x.url === c.url){ el.remove(); did = true; } });
            if(!r.querySelector("[data-k]")) r.remove();
          });
        }
      }catch(e){}
      if(!did){ HOME._hh = HOME._rr = null; renderHome(true); }
    };
    let t = null, sx = 0, sy = 0, fired = 0;
    const clear = () => { if(t){ clearTimeout(t); t = null; } };
    sec.addEventListener("touchstart", e => {
      const b = e.target.closest("[data-k]"); if(!b) return; const q = e.touches[0]; sx = q.clientX; sy = q.clientY; clear();
      t = setTimeout(() => { t = null; fired = Date.now(); try{ if(navigator.vibrate) navigator.vibrate(25); }catch(x){} ask(HOME.flat[+b.dataset.k], ctxOf(b)); }, 650);
    }, {passive:true});
    sec.addEventListener("touchmove", e => { const q = e.touches[0]; if(Math.abs(q.clientX - sx) > 10 || Math.abs(q.clientY - sy) > 10) clear(); }, {passive:true});
    ["touchend", "touchcancel"].forEach(n => sec.addEventListener(n, clear, {passive:true}));
    sec.addEventListener("contextmenu", e => { const b = e.target.closest("[data-k]"); if(!b) return; e.preventDefault(); if(Date.now() - fired > 800){ fired = Date.now(); ask(HOME.flat[+b.dataset.k], ctxOf(b)); } });
    /* depois de um toque longo não deixa passar o clique que reproduziria o canal */
    sec.addEventListener("click", e => { if(Date.now() - fired < 900 && e.target.closest("[data-k]")){ e.preventDefault(); e.stopImmediatePropagation(); } }, true);
    /* comando da TV: tecla Menu (ou ContextMenu) com um cartão focado */
    document.addEventListener("keydown", e => {
      if(currentView !== "tvhome") return;
      if(!(e.key === "ContextMenu" || e.key === "Menu" || e.keyCode === 82 || e.keyCode === 93)) return;
      const a = document.activeElement; const b = a && a.closest && a.closest("[data-k]"); if(!b || !sec.contains(b)) return;
      e.preventDefault(); e.stopImmediatePropagation(); ask(HOME.flat[+b.dataset.k], ctxOf(b));
    }, true);
  })();

  /* ligações: atualiza o ecrã quando chegam listas */
  let loading = false;
  async function loadAll(){
    if(loading) return; loading = true;
    try{ await ensureFree(false); }catch(e){}
    renderHome();
    try{ await ensureIntl(false); }catch(e){}
    loading = false; renderHome();
  }
  const _show = window.show;
  window.show = function(v){
    const prevV = currentView;
    const r = _show.apply(this, arguments); syncNav();
    if(prevV === "tv" && currentView !== "tv") stopPlayback();
    if(currentView === "tvhome"){
      HOME._hh = HOME._rr = null; renderHome(true); loadAll();
      if(prevV !== "tvhome") setTimeout(() => { try{ window.__thAnimReplay && window.__thAnimReplay(); }catch(e){} }, 60);
      [60, 250, 700].forEach(ms => setTimeout(() => { if(currentView === "tvhome") restoreScroll(); }, ms));
      setTimeout(() => { if(currentView !== "tvhome") return; const a = document.activeElement; if(a && a !== document.body && sec.contains(a)) return; const k = findCard(HOME.lastId) || (HOME.lastK != null ? sec.querySelector('[data-k="' + HOME.lastK + '"]') : null); (k || sec.querySelector(".thBtn.pri,.thCard") || nav.querySelector(".thTab")).focus({preventScroll:true}); }, 120);
    }
    return r;
  };
  const _ai = window.afterIptv; if(typeof _ai === "function") window.afterIptv = function(){ const r = _ai.apply(this, arguments); try{ renderHome(); }catch(e){} return r; };
  setInterval(() => { if(currentView === "tvhome") renderHome(); }, 60000);


  /* ===== Zoom com dois dedos em todas as páginas (juntar = menos, afastar = mais) ===== */
  (function(){
    const MIN = .6, MAX = 1.8;
    let z = parseFloat(LS.get("thZoom", 1)) || 1; z = Math.min(MAX, Math.max(MIN, z));
    const cinema = () => document.body.classList.contains("vfull") || !!document.querySelector("#v-tv.cinema");
    const apply = () => { const v = (z === 1 || cinema()) ? "" : String(z); document.querySelectorAll("section.view").forEach(e => { e.style.zoom = v; }); };
    apply();
    const _sh2 = window.show; window.show = function(){ const r = _sh2.apply(this, arguments); apply(); return r; };
    new MutationObserver(apply).observe(document.body, {attributes:true, attributeFilter:["class"]});
    let chip = null, ct = 0;
    const show = () => {
      if(!chip){ chip = document.createElement("button"); chip.className = "thBtn"; chip.style.cssText = "position:fixed;left:50%;bottom:90px;transform:translateX(-50%);z-index:99998;padding:8px 18px;font-size:16px"; chip.onclick = () => { z = 1; LS.set("thZoom", 1); apply(); show(); }; document.body.appendChild(chip); }
      chip.textContent = Math.round(z * 100) + "%" + (z !== 1 ? "  ·  tocar para repor" : ""); chip.hidden = false; clearTimeout(ct); ct = setTimeout(() => { chip.hidden = true; }, 2500);
    };
    let d0 = 0, z0 = 1;
    const dist = t => Math.hypot(t[0].clientX - t[1].clientX, t[0].clientY - t[1].clientY);
    const ok = e => !cinema() && !(e.target.closest && e.target.closest("#stage,#nav,.thNav,dialog,.epgdlg,.trkdlg"));
    document.addEventListener("touchstart", e => { if(e.touches.length === 2 && ok(e)){ d0 = dist(e.touches); z0 = z; } else d0 = 0; }, {passive:true});
    document.addEventListener("touchmove", e => {
      if(e.touches.length !== 2 || !d0) return;
      e.preventDefault();
      z = Math.min(MAX, Math.max(MIN, Math.round(z0 * dist(e.touches) / d0 * 20) / 20)); apply(); show();
    }, {passive:false});
    const end = e => { if(d0 && e.touches.length < 2){ d0 = 0; try{ LS.set("thZoom", z); }catch(x){} } };
    document.addEventListener("touchend", end, {passive:true}); document.addEventListener("touchcancel", end, {passive:true});
  })();

  /* ===== Início: o último canal visto a dar no topo (sem som) ===== */
  (function(){
    const PV = window.__pv = {on:false, url:"", key:"", t0:0, off:false};
    /* uma só vez: volta a ligar a pré-visualização (tinha ficado desligada sem querer) */
    try{ if(!LS.get("tvPrevFix", 0)){ LS.set("tvPrev", "on"); LS.set("tvPrevFix", 1); } }catch(e){}
    const pref = () => { try{ return LS.get("tvPrev", "on") !== "off"; }catch(e){ return true; } };
    const sndOn = () => { try{ return LS.get("tvPrevSnd", "off") === "on"; }catch(e){ return false; } };
    window.__pvVol = () => { try{ if(PV.on) Android.nvol(sndOn() ? 1 : 0); }catch(e){} };
    const curCh = () => { try{ return window.__pvPick || (lastPlayed && (lastPlayed[0] || lastPlayed[1])) || recents()[0] || null; }catch(e){ return null; } };
    const stop = () => { if(PV.on){ PV.on = false; PV.key = ""; try{ if(!(window.NATIVE && NATIVE.active) && !(window.__NSC && __NSC.open)) Android.nstop(); }catch(e){} } };
    const blocked = () => !!document.querySelector(".epgdlg:not([hidden]),.trkdlg:not([hidden]),#exitDlg:not([hidden])") || (window.DET && DET.open);
    const tick = () => {
      let c = null, art = null;
      const bt = document.getElementById("boot"), introOver = !bt || bt.hidden || getComputedStyle(bt).display === "none";
      const ok = introOver && typeof Android !== "undefined" && typeof Android.nplay === "function" && typeof Android.nvol === "function" && pref() && currentView === "tvhome" && !document.hidden && !(window.NATIVE && NATIVE.active) && !(window.__NSC && __NSC.open) && !(window.CAST && CAST.active) && !PV.off;
      if(ok){ c = curCh(); art = document.querySelector("#thHero .thHeroArt"); if(!c || /^(movie|series|episode|vod)$/.test(c.kind || "") || !c.url || !art) c = null; }
      if(!c){ if(PV.on) stop(); return; }
      if(PV.on && (window.NATIVE && NATIVE.active)){ PV.on = false; return; }
      if(!PV.on || PV.url !== c.url){
        let ref = ""; try{ ref = (typeof refFor === "function" && refFor(c)) || ""; }catch(e){}
        const u = c.url, hint = /\.m3u8(\?|$)/i.test(u) ? "hls" : (!/\.ts(\?|$)/i.test(u) && !(typeof FILE_EXT === "function" && FILE_EXT(u))) ? "hls" : "";
        try{ const pu = (window.__pxMode() === "all" && typeof px === "function") ? px(u, ref, false) : u; Android.nplay(pu, ref, hint, "", 0); try{ Android.npreview(true); }catch(x){} Android.nvol(sndOn() ? 1 : 0); }catch(e){ PV.off = true; return; }
        PV.on = true; PV.url = c.url; PV.t0 = Date.now(); PV.key = "";
      }
      if(Date.now() - PV.t0 > 10 * 60000){ stop(); PV.off = true; return; }   /* ao fim de 10 min pára, para não gastar ligação nem dados */
      const r = art.getBoundingClientRect(); let d = window.devicePixelRatio || 1;
      try{ if(!PV.si || Date.now() - PV.siT > 1500){ PV.si = JSON.parse(Android.screenInfo()); PV.siT = Date.now(); } if(PV.si && PV.si.w && window.innerWidth) d = PV.si.w / window.innerWidth; }catch(e){}
      let barB = 0; try{ const tb = document.querySelector("body.android .top, .top"); if(tb){ const tr = tb.getBoundingClientRect(); if(tr.height > 0 && tr.top < 200) barB = tr.bottom; } }catch(e){}
      const vis = Date.now() > (PV.settle || 0) && r.width > 20 && r.height > 20 && r.top >= Math.max(0, barB - 2) && r.bottom <= window.innerHeight + 2 && !blocked();
      const k = Math.round(r.left * d) + "," + Math.round(r.top * d) + "," + Math.round(r.width * d) + "," + Math.round(r.height * d) + "," + vis;
      if(k !== PV.key){ PV.key = k; try{ Android.nrect(Math.round(r.left * d), Math.round(r.top * d), Math.round(r.width * d), Math.round(r.height * d), vis); }catch(e){} }
    };
    setInterval(tick, 150); window.__pvTick = tick;
    /* ao rodar o ecrã, esconde já o vídeo e só o volta a mostrar quando a página assentou na nova posição */
    const rot = () => { PV.si = null; PV.key = ""; PV.settle = Date.now() + 600; if(PV.on && !(window.__NSC && __NSC.open)){ try{ Android.nrect(0, 0, 1, 1, false); }catch(e){} } };
    window.addEventListener("resize", rot); window.addEventListener("orientationchange", rot);
    window.__pvReset = () => { PV.off = false; };
    /* reenvia a posição do vídeo nativo várias vezes ao mudar de página ou rodar o ecrã (evita a caixa ficar pequena/parada no sítio da pré-visualização) */
    const resync = () => { [1550, 2600].forEach(ms => setTimeout(() => { try{ if(window.NATIVE && NATIVE.active) NATIVE.sync(true); }catch(e){} }, ms));   /* só depois de a animação acabar */ };
    let lastW = window.innerWidth, lastH = window.innerHeight;
    const rotHold = () => {   /* só quando muda mesmo a orientação/tamanho da janela */
      if(window.innerWidth === lastW && window.innerHeight === lastH) return;
      lastW = window.innerWidth; lastH = window.innerHeight;
      /* (removido a pedido: o vídeo já não é escondido ao rodar) */
    };
    window.addEventListener("resize", rotHold); window.addEventListener("orientationchange", () => setTimeout(rotHold, 50));
    const _sh = window.show; window.show = function(v){ if(v === "tvhome") PV.off = false; if(v !== "tvhome"){ stop(); try{ if(!(window.NATIVE && NATIVE.active) && !(window.__NSC && __NSC.open)) Android.nrect(0, 0, 1, 1, false); }catch(e){} } const r = _sh.apply(this, arguments); if(v === "tv") resync(); return r; };
  })();
  setTimeout(() => { if(currentView === "tvhome" && (!document.activeElement || document.activeElement === document.body)) (sec.querySelector(".thBtn.pri,.thCard") || nav.querySelector(".thTab")).focus({preventScroll:true}); }, 900);

  /* ===== Detalhes de filmes e séries: sinopse, classificação, trailer; depois decides se vês ===== */
  const DET = window.DET = {open:false, c:null, origin:false, cache:new Map(), tk:0};
  const origPlay = window.playChannel, origSeries = window.openSeries;
  const detId = c => { const m = /\/movie\/[^/]+\/[^/]+\/(\d+)\./.exec(c.url || ""); return m ? m[1] : ""; };
  async function detLoad(c){
    if(DET.cache.has(c.url)) return DET.cache.get(c.url);
    let info = null;
    try{
      if(c.kind === "series" && c.sid){ const j = await xApi("get_series_info", "&series_id=" + c.sid); info = Object.assign({}, j.info || {}); }
      else if(c.kind === "movie"){ const id = detId(c); if(id){ const j = await xApi("get_vod_info", "&vod_id=" + id); info = Object.assign({}, j.info || {}); } }
    }catch(e){}
    info = info || {}; DET.cache.set(c.url, info); return info;
  }
  const dlg = document.createElement("div"); dlg.className = "epgdlg"; dlg.id = "detDlg"; dlg.hidden = true;
  dlg.innerHTML = '<div class="panel detbox" role="dialog" aria-label="Detalhes"><div class="detposter" id="detPoster"></div><div class="dettx"><h2 id="detTitle"></h2><div class="detmeta" id="detMeta"></div><div class="detplot" id="detPlot" tabindex="0"></div><div class="detcrew" id="detCrew"></div><div class="detbt"><button class="btn primary" id="detGo"></button><button class="btn" id="detTrailer">🎞 Trailer</button><button class="btn" id="detClose">Fechar</button></div></div></div>';
  document.body.appendChild(dlg);
  const detClose = () => { dlg.hidden = true; DET.open = false; };
  $("detClose").onclick = () => { detClose(); if(!document.querySelector(".app").classList.contains("cinema")) window.__homeOrigin = false; };
  $("detGo").onclick = () => {
    const c = DET.c; if(!c) return; detClose(); window.__homeOrigin = DET.origin;
    if(c.kind === "series" && c.sid){ origSeries(c); if(currentView !== "tv") show("tv"); return; }
    window.__noDet = true; try{ origPlay(c); }finally{ window.__noDet = false; }
    setTimeout(() => { if(currentView === "tv"){ if(!document.querySelector(".app").classList.contains("cinema")) setCinema(true); const st = $("stage"); if(st) st.focus({preventScroll:true}); } }, 160);
  };
  $("detTrailer").onclick = async () => {
    const c = DET.c; if(!c) return; const t = String(DET.trailer || "").trim();
    let id = /^[\w-]{11}$/.test(t) ? t : ((/(?:v=|youtu\.be\/)([\w-]{11})/.exec(t) || [])[1] || "");
    const q = ((typeof osParse === "function" ? osParse(c.name).title : "") || c.name) + " trailer oficial";
    if(!id && cfg.ytKey){   /* sem trailer no servidor: procura-o no YouTube com a tua chave */
      try{ const r = await fetch("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=1&type=video&videoEmbeddable=true&q=" + encodeURIComponent(q) + "&key=" + encodeURIComponent(cfg.ytKey)); const j = await r.json(); id = (((j.items || [])[0] || {}).id || {}).videoId || ""; }catch(e){}
    }
    const url = id ? "https://www.youtube.com/embed/" + id + "?autoplay=1&rel=0&playsinline=1&modestbranding=1" : "https://m.youtube.com/results?search_query=" + encodeURIComponent(q) + "&sp=CAI%3D";   /* ordenado por data: os mais recentes primeiro */
    try{ if(typeof Android.trailer === "function") Android.trailer(url); else window.open(url, "_blank"); }catch(e){ try{ toast("Não consegui abrir o trailer.", true); }catch(x){} }
  };
  /* ===== Tradução automática dos detalhes (sinopse, géneros) para a língua da interface ===== */
  const UL = () => { try{ return uiLang(); }catch(e){ return "pt"; } };
  const T = pt => { try{ const l = UL(); return l === "pt" ? pt : ((I18N[l] && I18N[l][pt]) || pt); }catch(e){ return pt; } };
  window.__T = T;
  const trHash = t => { let h = 5381; for(let i = 0; i < t.length; i++) h = ((h << 5) + h + t.charCodeAt(i)) | 0; return (h >>> 0).toString(36) + t.length; };
  const trChunks = (t, max) => { const out = []; let cur = ""; String(t).split(/(?<=[.!?…])\s+/).forEach(sn => { while(sn.length > max){ if(cur){ out.push(cur); cur = ""; } out.push(sn.slice(0, max)); sn = sn.slice(max); } if((cur + " " + sn).length > max){ out.push(cur); cur = sn; } else cur = cur ? cur + " " + sn : sn; }); if(cur) out.push(cur); return out; };
  async function trOne(q, tl){
    try{
      const r = await fetch("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=" + tl + "&dt=t&q=" + encodeURIComponent(q));
      if(r.ok){ const j = await r.json(); const o = (j[0] || []).map(x => x[0]).join(""); if(o) return o; }
    }catch(e){}
    try{
      const r = await fetch("https://api.mymemory.translated.net/get?q=" + encodeURIComponent(q.slice(0, 480)) + "&langpair=Autodetect|" + tl);
      if(r.ok){ const j = await r.json(); const o = j && j.responseData && j.responseData.translatedText; if(o && !/MYMEMORY WARNING|INVALID/i.test(o)) return o; }
    }catch(e){}
    return null;
  }
  async function trText(text){
    text = String(text || "").trim(); const tl = UL(); if(!text) return text;
    const key = "trc|" + tl + "|" + trHash(text);
    try{ const c = localStorage.getItem(key); if(c) return c; }catch(e){}
    const parts = trChunks(text, 1200), outp = [];
    for(const q of parts){ const o = await trOne(q, tl); if(o == null) return null; outp.push(o); }
    const res = outp.join(" ");
    try{ localStorage.setItem(key, res); }catch(e){}
    return res;
  }
  window.__trText = trText;
  async function showDetails(c){
    const tk = ++DET.tk; DET.c = c; DET.origin = !!window.__homeOrigin; DET.open = true; DET.trailer = "";
    const isSeries = c.kind === "series";
    $("detTitle").textContent = c.name; $("detMeta").textContent = c.group || ""; $("detPlot").textContent = T("A carregar detalhes…"); $("detCrew").textContent = "";
    $("detPoster").innerHTML = c.logo ? '<img src="' + esc(c.logo) + '" alt="" onerror="this.remove()">' : "<b>" + esc((c.name || "?").slice(0, 2).toUpperCase()) + "</b>";
    const at = RES.at(c.url);
    $("detGo").textContent = isSeries ? T("📺 Ver episódios") : at > 0 ? T("▶ Continuar") : T("▶ Ver agora");
    $("detClose").textContent = T("Fechar");
    dlg.hidden = false; setTimeout(() => { if(DET.open) $("detGo").focus({preventScroll:true}); }, 60);
    const i = await detLoad(c); if(tk !== DET.tk || !DET.open) return;
    const y = String(i.releasedate || i.releaseDate || i.year || "").slice(0, 4);
    const rt = parseFloat(i.rating) || (parseFloat(i.rating_5based) || 0) * 2;
    const dur = i.duration || (i.episode_run_time ? i.episode_run_time + " min" : "");
    const metaOf = g => [y, dur, g, i.country, i.age ? i.age : ""].filter(Boolean).join(" · ");
    const rate = (rt ? '<b class="detrate">⭐ ' + rt.toFixed(1) + '/10</b> ' : "");
    $("detMeta").innerHTML = rate + esc(metaOf(i.genre) || c.group || "");
    const plot = i.plot || i.description || "";
    $("detPlot").textContent = plot || T("Sem sinopse disponível para este título.");
    $("detCrew").innerHTML = (i.director ? "<div><b>" + T("Realização:") + "</b> " + esc(i.director) + "</div>" : "") + (i.cast || i.actors ? "<div><b>" + T("Elenco:") + "</b> " + esc(i.cast || i.actors) + "</div>" : "");
    if(plot){   /* traduz a sinopse e o género para a língua da interface (guarda em cache) */
      trText(plot).then(t => { if(t && tk === DET.tk && DET.open) $("detPlot").textContent = t; });
      if(i.genre) trText(i.genre).then(g => { if(g && tk === DET.tk && DET.open) $("detMeta").innerHTML = rate + esc(metaOf(g)); });
    }
    DET.trailer = i.youtube_trailer || i.trailer || "";
    const img = i.movie_image || i.cover || (Array.isArray(i.backdrop_path) ? i.backdrop_path[0] : "") || c.logo;
    if(img) $("detPoster").innerHTML = '<img src="' + esc(img) + '" alt="" onerror="this.remove()">';
  }
  window.playChannel = function(c, slot, auto){
    if(c && (c.kind === "movie" || c.kind === "series") && !auto && !window.__noDet && !c._pct && !document.querySelector(".app").classList.contains("cinema") && !(c.kind === "movie" && RES.at(c.url) > 0 && DET.c && DET.c.url === c.url)){ showDetails(c); return; }
    return origPlay.apply(this, arguments);
  };
  window.openSeries = function(c){
    if(c && c.sid && !window.__noDet && !c._pct && !(DET.open === false && DET.skipSeries)){ showDetails(Object.assign({}, c, {kind:"series"})); return; }
    return origSeries.apply(this, arguments);
  };


  /* ===== Ícones nítidos (SVG) no lugar dos emojis do sistema ===== */
  const SV = {
    home:'<path d="M4 11l8-7 8 7v9h-5.5v-6h-5v6H4z"/>',
    search:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
    guide:'<rect x="3" y="5" width="18" height="16" rx="2.5"/><path d="M3 10h18M8 3v4M16 3v4"/>',
    gear:'<circle cx="12" cy="12" r="3.2"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>',
    play:'<path d="M7 4.5l13 7.5-13 7.5z" fill="currentColor"/>',
    prev:'<path d="M17 5l-10 7 10 7z" fill="currentColor"/>',
    next:'<path d="M7 5l10 7-10 7z" fill="currentColor"/>',
    audio:'<path d="M5 4v16M12 4v16M19 4v16"/><circle cx="5" cy="9" r="2.2" fill="currentColor"/><circle cx="12" cy="15" r="2.2" fill="currentColor"/><circle cx="19" cy="8" r="2.2" fill="currentColor"/>',
    subs:'<path d="M4 5h16v11H10l-4.5 4v-4H4z"/><path d="M8 9h8M8 12h5"/>',
    film:'<rect x="4" y="4" width="16" height="16" rx="2.5"/><path d="M8.5 4v16M15.5 4v16M4 9h4.5M4 15h4.5M15.5 9H20M15.5 15H20"/>',
    cast:'<path d="M3 18a3 3 0 013 3M3 13a8 8 0 018 8M3 8a13 13 0 0113 13"/><path d="M3 5.5V4h18v16h-5.5"/>',
    mirror:'<rect x="3" y="4" width="18" height="12" rx="2.5"/><path d="M8 20h8M12 16v4"/>',
    globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3.2 3 3.2 15 0 18M12 3c-3.2 3-3.2 15 0 18"/>',
    star:'<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z" fill="currentColor"/>',
    pulse:'<path d="M3 12h4l3-7 4 14 3-7h4"/>',
    tv:'<rect x="3" y="5" width="18" height="12" rx="2.5"/><path d="M8 21h8M12 17v4"/>',
    clap:'<rect x="3" y="9" width="18" height="11" rx="2.5"/><path d="M3 9l2.5-5h4L7 9M9.5 9L12 4h4l-2.5 5M16 9l2.5-5H21l-2 5"/>',
    layers:'<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5.2l3.2 2"/>',
    pp:'<path d="M4 4.5l9 7.5-9 7.5z" fill="currentColor"/><path d="M17 5v14M21 5v14"/>',
    stop:'<rect x="6" y="6" width="12" height="12" rx="1.5" fill="currentColor"/>',
    sat:'<circle cx="12" cy="12" r="2" fill="currentColor"/><path d="M7.8 7.8a6 6 0 000 8.4M16.2 7.8a6 6 0 010 8.4M4.9 4.9a10 10 0 000 14.2M19.1 4.9a10 10 0 010 14.2"/>',
    chat:'<path d="M4 5h16v11H10l-4.5 4v-4H4z"/>',
    skipprev:'<path d="M6 5v14"/><path d="M19 5l-10 7 10 7z" fill="currentColor"/>',
    skipnext:'<path d="M18 5v14"/><path d="M5 5l10 7-10 7z" fill="currentColor"/>',
    rew:'<path d="M11 6l-8 6 8 6z" fill="currentColor"/><path d="M21 6l-8 6 8 6z" fill="currentColor"/>',
    fwd:'<path d="M13 6l8 6-8 6z" fill="currentColor"/><path d="M3 6l8 6-8 6z" fill="currentColor"/>',
    full:'<path d="M4 9V4h5M20 9V4h-5M4 15v5h5M20 15v5h-5"/>',
    exitfull:'<path d="M9 4v5H4M15 4v5h5M9 20v-5H4M15 20v-5h5"/>',
    close:'<path d="M6 6l12 12M18 6L6 18"/>',
    aspect:'<rect x="3" y="7" width="18" height="10" rx="1.5"/>',
    frames:'<rect x="3" y="4" width="18" height="16" rx="2"/><path d="M12 4v16M3 12h18"/>',
    sound:'<path d="M4 9.5h3.5L12 5.5v13l-4.5-4H4z"/><path d="M15.5 9a4.5 4.5 0 010 6M18 6.5a8 8 0 010 11"/>',
    stats:'<path d="M5 20V11M12 20V4M19 20v-6"/>',
    phones:'<path d="M4 14v-2a8 8 0 0116 0v2"/><rect x="3" y="14" width="4" height="6" rx="1.5"/><rect x="17" y="14" width="4" height="6" rx="1.5"/>'
  };
  const EM = {"🏠":"home","🔎":"search","🔍":"search","📅":"guide","⚙":"gear","▶":"play","◀":"prev","🎚":"audio","💬":"subs","🎞":"film","📡":"sat","🖥":"mirror","🌍":"globe","🌎":"globe","★":"star","⭐":"star","🩺":"pulse","📺":"tv","🎬":"clap","🍿":"layers","🕘":"clock","⏯":"pp","⏹":"stop","📖":"layers","⏮":"skipprev","⏭":"skipnext","⏪":"rew","⏩":"fwd","⛶":"full","⤡":"exitfull","✕":"close","▭":"aspect","⧉":"frames","🔊":"sound","📊":"stats","🎧":"phones"};
  const EMRE = new RegExp("(" + Object.keys(EM).join("|") + ")[\\uFE0E\\uFE0F]?", "g");
  const icon = n => '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true">' + (SV[n] || "") + '</svg>';
  /* 5 estilos de ícones (definições): traço, pontas e preenchimento; valem para a página e para os botões do ecrã nativo */
  const ICS = {"1":{n:"Linha",w:2,cap:"round",join:"round",duo:0}, "2":{n:"Negrito",w:3,cap:"round",join:"round",duo:0}, "3":{n:"Sólido",w:1.4,cap:"round",join:"round",duo:0,solid:1}, "4":{n:"Duotone",w:2,cap:"round",join:"round",duo:1}, "5":{n:"Emoji do sistema",w:2,cap:"round",join:"round",duo:0,emoji:1}};
  const icKey = () => { let k = "1"; try{ k = String(LS.get("icStyle", "1")); }catch(e){} return ICS[k] ? k : "1"; };
  window.__icSt = () => Object.assign({k: icKey()}, ICS[icKey()]);
  const icApply = () => { try{ for(const k in ICS) document.body.classList.toggle("ics-" + k, k === icKey()); }catch(e){} };
  icApply();
  const SKIP = "#tvList,#gdList,#gdSched,#orgList,#detPlot,#detCrew,#epgBox,#chName,.thMeta,#trkAudio,#trkSubs,#osRes,#icsBtns";
  const NONASCII = /[^\x00-\x7f]/;
  function iconize(root){
    root = root || document.body;
    if(root.nodeType === 1 && root.closest && root.closest(SKIP)) return;
    const w = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {acceptNode: n => { const v = n.nodeValue; if(!v || !NONASCII.test(v) || !EMRE.test(v)) return NodeFilter.FILTER_REJECT; EMRE.lastIndex = 0; const pe = n.parentElement; return (pe && !pe.closest(SKIP) && pe.closest("button,h1,h2,h3,.tab,.thTab,.detmeta,label")) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT; }});
    const list = []; let n; while((n = w.nextNode())) list.push(n);
    list.forEach(t => {
      const frag = document.createElement("span"); frag.style.display = "contents";
      frag.innerHTML = esc(t.nodeValue).replace(EMRE, (m, e) => '<span class="icw" data-e="' + e + '">' + icon(EM[e]) + '</span>');
      t.replaceWith(frag);
    });
  }
  /* só percorre o que mudou (antes percorria a página toda a cada alteração: lento na TV) */
  let icT = 0; const icPend = new Set();
  new MutationObserver(recs => {
    for(const r of recs){
      if(r.type === "characterData"){ if(r.target.parentElement) icPend.add(r.target.parentElement); continue; }
      r.addedNodes.forEach(nd => { if(nd.nodeType === 1) icPend.add(nd); else if(nd.parentElement) icPend.add(nd.parentElement); });
    }
    if(icT || !icPend.size) return;
    icT = requestAnimationFrame(() => { icT = 0; const roots = [...icPend]; icPend.clear(); roots.forEach(r => { try{ if(r.isConnected) iconize(r); }catch(e){} }); });
  }).observe(document.body, {childList:true, subtree:true, characterData:true});
  iconize();


  /* ===== Definições organizadas em cartões (que abrem e fecham) ===== */
  (function(){
    const st = $("v-settings"); if(!st || $("tvSetGrid")) return;
    Object.assign(SV, {
      list:'<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1" fill="currentColor"/><circle cx="3.5" cy="12" r="1" fill="currentColor"/><circle cx="3.5" cy="18" r="1" fill="currentColor"/>',
      palette:'<circle cx="12" cy="12" r="9"/><circle cx="8" cy="10" r="1.3" fill="currentColor"/><circle cx="12" cy="7.5" r="1.3" fill="currentColor"/><circle cx="16" cy="10" r="1.3" fill="currentColor"/>',
      save:'<path d="M5 3h11l3 3v15H5z"/><path d="M8 3v6h8V3M8 21v-7h8v7"/>',
      info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5h.01"/>',
      remote:'<rect x="7" y="2" width="10" height="20" rx="3"/><circle cx="12" cy="8" r="2"/><path d="M12 13v.01M12 17v.01M9 15h.01M15 15h.01"/>',
      chev:'<path d="M9 5l7 7-7 7"/>'
    });
    const META = {"TV e IPTV":["list","Lista IPTV","M3U ou Xtream Codes, guia de programas e qualidade"], "Aparência e layout":["palette","Aparência e layout","Modelos do Início, cor e margens do ecrã"], "Cópia de segurança":["save","Cópia de segurança","Exportar e importar as definições"]};
    const cards = [...st.querySelectorAll(".setcard")].filter(c => !c.hidden);
    const extra = (id, ic, title, sub, html) => { const c = document.createElement("section"); c.className = "setcard panel"; c.id = id; c.innerHTML = "<h2>" + title + "</h2><p class='setsub'>" + sub + "</p>" + html; META[title] = [ic, title, sub]; return c; };
    const keys = [["OK","Abrir / escolher"],["Voltar","Recuar (no Início pede para confirmar a saída)"],["▲ ▼ ◀ ▶","Navegar. No vídeo: ◀ ▶ mudam de canal, ▼ vai aos botões"],["Canal + / −","Mudar de canal"],["Play / Pausa","Pausar o vídeo"],["Avançar / Recuar","Salta 30 s em filmes e séries"],["Info / Guia","Guia de programas do canal"],["Menu","Áudio e legendas, dentro do vídeo"]];
    const remote = extra("setKeys", "remote", "Teclas do comando", "O que faz cada tecla", '<div class="keyList">' + keys.map(k => "<div><b>" + k[0] + "</b><span>" + k[1] + "</span></div>").join("") + "</div>");
    const about = extra("setAbout", "info", "Sobre", "Versão e leitor de vídeo", '<div class="keyList"><div><b>Versão</b><span>' + esc(typeof APP_VERSION !== "undefined" ? APP_VERSION : "") + '</span></div><div><b>Leitor</b><span>' + (HAS_N ? "Nativo (Media3 / ExoPlayer), com recurso ao da página" : "Da página (hls.js / mpegts.js)") + '</span></div><div><b>Teclas</b><span id="kdiag">sem erros</span></div><div><b>Aparelho</b><span>' + (isTvDev ? "Android TV" : "Telemóvel / tablet") + '</span></div></div>');

    Object.assign(SV, {users:'<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><circle cx="17.5" cy="9" r="2.5"/><path d="M17 14.2c2.6.2 4.5 2 4.5 5.3"/>'});
    META["Listas e perfis"] = ["users", "Listas e perfis", "Vários fornecedores ou perfis"];
    const prof = extra("setProf", "users", "Listas e perfis", "Vários fornecedores ou perfis", '<div id="profList" class="keyList"></div><label class="f">Nome do perfil<input type="text" id="profName" placeholder="Ex.: Casa, Família, Desporto"></label><div class="row"><button class="btn primary" id="profSave">Guardar a lista atual como perfil</button></div><p class="small muted">Guarda o link M3U ou o servidor Xtream, o utilizador e o guia. Muda de lista com um OK; a anterior continua guardada.</p>');
    const PK = "tvProfiles";
    const pAll = () => { const a = LS.get(PK, []); return Array.isArray(a) ? a : []; };
    const same = (p) => (p.m3u || "") === (cfg.m3u || "") && (p.xs || "") === (cfg.xs || "") && (p.xu || "") === (cfg.xu || "");
    function profRender(){
      const L = pAll(), box = prof.querySelector("#profList");
      box.innerHTML = L.length ? L.map((p, i) => '<div class="profRow"><span><b>' + esc(p.name) + '</b>' + (same(p) ? ' <small>· em uso</small>' : '') + '</span><button class="btn" data-pu="' + i + '">Usar</button><button class="btn" data-pd="' + i + '">Apagar</button></div>').join("") : '<span class="muted">Ainda não há perfis guardados.</span>';
      box.querySelectorAll("[data-pu]").forEach(b => b.onclick = async () => {
        const p = pAll()[+b.dataset.pu]; if(!p) return;
        cfg.m3u = p.m3u || ""; cfg.xs = p.xs || ""; cfg.xu = p.xu || ""; cfg.xp = p.xp || ""; cfg.epg = p.epg || ""; if(p.maxRes) cfg.maxRes = p.maxRes;
        saveCfg(); try{ $("setM3u").value = cfg.m3u; $("setXs").value = cfg.xs; $("setXu").value = cfg.xu; $("setXp").value = cfg.xp; $("setEpg").value = cfg.epg; }catch(e){}
        try{ await IDB.set("channels", []); }catch(e){}
        try{ channels.length = 0; }catch(e){}
        toast("Perfil «" + p.name + "» ativo. A carregar a lista…"); profRender();
        try{ window.__homeOrigin = false; loadIptv(true); show("tvhome"); }catch(e){}
      });
      box.querySelectorAll("[data-pd]").forEach(b => b.onclick = () => { const a = pAll(); a.splice(+b.dataset.pd, 1); LS.set(PK, a); profRender(); });
    }
    prof.querySelector("#profSave").onclick = () => {
      if(!(cfg.m3u || cfg.xs)){ toast("Primeiro guarda uma lista em «Lista IPTV».", true); return; }
      const name = (prof.querySelector("#profName").value || "").trim() || ("Lista " + (pAll().length + 1));
      const a = pAll().filter(p => p.name !== name); a.push({name, m3u:cfg.m3u || "", xs:cfg.xs || "", xu:cfg.xu || "", xp:cfg.xp || "", epg:cfg.epg || "", maxRes:cfg.maxRes}); LS.set(PK, a); prof.querySelector("#profName").value = ""; profRender(); toast("Perfil «" + name + "» guardado.");
    };
    profRender();
    document.head.insertAdjacentHTML("beforeend", "<style>.profRow{display:flex;gap:10px;align-items:center}.profRow span{flex:1;min-width:0}.profRow small{opacity:.7}</style>");

    META["Ordem dos canais"] = ["list", "Ordem dos canais", "Lista no topo por operador"];
    const opc = extra("setOp", "list", "Ordem dos canais", "Lista no topo por operador", '<p class="small muted">Mostra no Início uma lista com os teus canais pela ordem da grelha do operador. A correspondência é feita pelo nome do canal.</p><div id="opBtns" class="keyList"></div><label class="f">Ordem personalizada (um canal por linha; «a|b» para nomes alternativos)<textarea id="opCustom" rows="6" placeholder="RTP 1&#10;RTP 2&#10;SIC&#10;TVI"></textarea></label><p class="small muted" id="opNote"></p>');
    (function(){
      const O = window.__op, box = opc.querySelector("#opBtns"), ta = opc.querySelector("#opCustom"), note = opc.querySelector("#opNote");
      ta.value = O.opCustom();
      const opts = [["", "Desligado"], ["meo", "MEO"], ["nos", "NOS"], ["vodafone", "Vodafone"], ["custom", "Personalizada"]];
      const paint = () => {
        const cur = O.opKey();
        box.innerHTML = opts.map(([k, t]) => '<button class="btn opB' + (cur === k ? " on" : "") + '" data-op="' + k + '" aria-pressed="' + (cur === k) + '">' + (cur === k ? "● " : "○ ") + t + "</button>").join("");
        box.style.flexDirection = "row"; box.style.flexWrap = "wrap";
        box.querySelectorAll("[data-op]").forEach(b => b.onclick = () => { LS.set("tvOp", b.dataset.op); paint(); });
        const n = cur ? O.opChannels(cur).length : 0;
        note.textContent = !cur ? "Sem lista de operador no Início." : (n ? n + " canais da tua lista encontrados." : "Ainda não encontrei canais da tua lista com estes nomes.") + (cur && cur !== "custom" ? " Fonte: " + O.OPS[cur].src + ". Canais premium (ex.: Sport TV) só entram onde a grelha os indica; completa em «Personalizada»." : "");
      };
      ta.oninput = () => { LS.set("tvOpCustom", ta.value); paint(); };
      paint();
    })();
    setInterval(() => { const k = $("kdiag"); if(k) k.textContent = window.__kerr ? "erro: " + window.__kerr : "sem erros"; }, 1500);
    META["Vídeo"] = ["gear", "Vídeo", "Desentrelaçamento"];
    const vid = extra("setVid", "gear", "Vídeo", "Desentrelaçamento", '<p class="small muted">Canais entrelaçados (alguns de TV e desporto em 1080i) podem mostrar “serrilhado” em movimento. «Adaptativo» corrige só os pixels com efeito pente, na GPU. A maioria das TVs já desentrelaça sozinha; ativa só se vires o defeito. Experimental: se o vídeo falhar, volta a «Desligado».</p><div id="vidBtns" class="keyList"></div><p class="small muted" style="margin-top:12px">Taxa de atualização: «Automática» muda o ecrã da TV para a taxa do vídeo (24, 25, 30, 50, 60 Hz ou múltiplos) quando a TV o permite. A TV pode fazer um breve ecrã preto ao mudar.</p><div id="afrBtns" class="keyList"></div>');
    (function(){
      const box = vid.querySelector("#vidBtns");
      const paint = () => { const cur = LS.get("tvDeint", "off"); box.innerHTML = [["off", "Desligado"], ["adapt", "Adaptativo (GPU)"]].map(([k, t]) => '<button class="btn" data-dv="' + k + '" aria-pressed="' + (cur === k) + '">' + (cur === k ? "● " : "○ ") + t + "</button>").join(""); box.style.flexDirection = "row"; box.style.flexWrap = "wrap"; box.querySelectorAll("[data-dv]").forEach(b => b.onclick = () => { LS.set("tvDeint", b.dataset.dv); try{ if(typeof Android.ndeint === "function") Android.ndeint(b.dataset.dv === "adapt"); }catch(e){} paint(); }); };
      paint();
      const ab = vid.querySelector("#afrBtns");
      const paintA = () => { const cur = LS.get("tvAfr", "on"); ab.innerHTML = [["on", "Automática"], ["off", "Desligada"]].map(([k, t]) => '<button class="btn" data-af="' + k + '" aria-pressed="' + (cur === k) + '">' + (cur === k ? "● " : "○ ") + t + "</button>").join(""); ab.style.flexDirection = "row"; ab.style.flexWrap = "wrap"; ab.querySelectorAll("[data-af]").forEach(b => b.onclick = () => { LS.set("tvAfr", b.dataset.af); try{ if(typeof Android.nafr === "function") Android.nafr(b.dataset.af !== "off"); }catch(e){} paintA(); }); };
      paintA();
    })();
    META["Proxy"] = ["gear", "Proxy", "Deno / Worker para listas e vídeo"];
    const pxc = extra("setPx", "gear", "Proxy", "Deno / Worker para listas e vídeo", '<p class="small muted">Passa as listas, o guia e (se escolheres) o vídeo por um proxy teu, por exemplo o Deno. Usa o endereço e a chave do «2.º proxy» do Cockpit.</p><div class="keyList"><div><b>Endereço</b><span id="pxUrlV"></span></div><div><b>Chave</b><span id="pxKeyV"></span></div></div><div class="row"><button class="btn" id="pxUrlB">Endereço…</button><button class="btn" id="pxKeyB">Chave…</button><button class="btn" id="pxTest">Testar</button></div><div class="small muted" style="margin:10px 0 4px">Usar o proxy em:</div><div id="pxModes" class="keyList"></div><p class="small muted" id="pxNote"></p>');
    (function(){
      const q = id => pxc.querySelector(id), note = q("#pxNote");
      const ask = (title, cur, secret, cb) => { window.__askCb = v => { window.__askCb = null; if(v !== null) cb(String(v).trim()); }; try{ Android.askText(title, cur || "", !!secret); }catch(e){ window.__askCb = null; } };
      const modes = [["off", "Desligado (ligação direta)"], ["lists", "Listas e guia"], ["all", "Listas, guia e vídeo"]];
      const paint = () => {
        q("#pxUrlV").textContent = cfg.proxy2 || "não definido"; q("#pxKeyV").textContent = cfg.pkey2 ? "•".repeat(Math.min(10, cfg.pkey2.length)) : "sem chave";
        const cur = window.__pxMode();
        q("#pxModes").innerHTML = modes.map(([k, t]) => '<button class="btn" data-pm="' + k + '" aria-pressed="' + (cur === k) + '">' + (cur === k ? "● " : "○ ") + t + "</button>").join("");
        q("#pxModes").style.flexDirection = "row"; q("#pxModes").style.flexWrap = "wrap";
        q("#pxModes").querySelectorAll("[data-pm]").forEach(b => b.onclick = () => { try{ localStorage.setItem("tvPxMode", b.dataset.pm); }catch(e){} paint(); toast(b.dataset.pm === "off" ? "Proxy desligado. Volta a abrir a lista." : "Proxy ligado. Volta a abrir a lista ou o canal."); });
        note.textContent = cur !== "off" && !cfg.proxy2 ? "Define primeiro o endereço do proxy." : "";
      };
      q("#pxUrlB").onclick = () => ask("Endereço do proxy (https://…deno.dev)", cfg.proxy2, false, v => { cfg.proxy2 = v.replace(/\/+$/, ""); saveCfg(); paint(); });
      q("#pxKeyB").onclick = () => ask("Chave do proxy", cfg.pkey2, true, v => { cfg.pkey2 = v; saveCfg(); paint(); });
      q("#pxTest").onclick = async () => {
        if(!cfg.proxy2){ note.textContent = "Define primeiro o endereço do proxy."; return; }
        note.textContent = "A testar…";
        try{
          const u = cfg.proxy2.replace(/\/+$/, "") + "/?" + (cfg.pkey2 ? "k=" + encodeURIComponent(cfg.pkey2) + "&" : "") + "url=" + encodeURIComponent("https://www.gstatic.com/generate_204");
          const r = await fetch(u, {cache:"no-store"});
          note.textContent = r.status === 204 || r.ok ? "Proxy a funcionar (resposta " + r.status + ")." : "O proxy respondeu " + r.status + (r.status === 401 || r.status === 403 ? " — confirma a chave." : ".");
        }catch(e){ note.textContent = "Não consegui ligar ao proxy: " + (e && e.message || e); }
      };
      paint();
    })();
    META["VPN (OpenVPN)"] = ["gear", "VPN (OpenVPN)", "Ligar uma VPN OpenVPN"];
    const vpc = extra("setVpn", "gear", "VPN (OpenVPN)", "Ligar uma VPN OpenVPN", '<p class="small muted">Usa a app gratuita «OpenVPN para Android» (de.blinkt.openvpn) com o teu ficheiro .ovpn. O Cockpit TV importa o perfil, liga e desliga a VPN.</p><div class="keyList"><div><b>App OpenVPN</b><span id="vpAppV"></span></div><div><b>Perfil</b><span id="vpNameV"></span></div></div><div class="row"><button class="btn" id="vpInst">Instalar a app OpenVPN</button><button class="btn" id="vpOpen">Abrir a app</button></div><div class="row"><button class="btn" id="vpImp">Importar ficheiro .ovpn…</button><button class="btn" id="vpName">Nome do perfil…</button></div><div class="row"><button class="btn primary" id="vpOn">Ligar VPN</button><button class="btn" id="vpOff">Desligar VPN</button></div><div id="vpAuto" class="keyList"></div><p class="small muted" id="vpNote"></p><p class="small muted">Para a VPN valer só para o Cockpit TV: na app OpenVPN, abre o perfil, escolhe «Editar» → «Por aplicação» e marca só o Cockpit TV. O primeiro «Ligar» pede uma autorização do Android.</p>');
    (function(){
      const q = id => vpc.querySelector(id), note = q("#vpNote");
      const ask = (title, cur, cb) => { window.__askCb = v => { window.__askCb = null; if(v !== null) cb(String(v).trim()); }; try{ Android.askText(title, cur || "", false); }catch(e){ window.__askCb = null; } };
      const getName = () => LS.get("tvVpnName", "") || "";
      const paint = () => {
        let inst = false; try{ inst = !!Android.vpnInstalled(); }catch(e){}
        q("#vpAppV").textContent = inst ? "instalada" : "não instalada"; q("#vpNameV").textContent = getName() || "não definido";
        const a = LS.get("tvVpnAuto", false);
        q("#vpAuto").innerHTML = '<button class="btn" id="vpAutoB" aria-pressed="' + a + '">' + (a ? "● " : "○ ") + "Ligar a VPN ao abrir o Cockpit TV</button>";
        q("#vpAutoB").onclick = () => { LS.set("tvVpnAuto", !LS.get("tvVpnAuto", false)); paint(); };
      };
      q("#vpInst").onclick = () => { try{ Android.vpnInstall(); }catch(e){} };
      q("#vpOpen").onclick = () => { try{ Android.vpnOpenApp(); }catch(e){} };
      q("#vpImp").onclick = () => { note.textContent = "Escolhe o ficheiro .ovpn. A app OpenVPN abre para o importar; dá-lhe um nome e guarda."; try{ Android.vpnImport(); }catch(e){ note.textContent = "Não consegui abrir o seletor de ficheiros."; } };
      q("#vpName").onclick = () => ask("Nome do perfil na app OpenVPN (igual ao que lá aparece)", getName(), v => { LS.set("tvVpnName", v); paint(); });
      q("#vpOn").onclick = () => { if(!getName()){ note.textContent = "Escreve primeiro o nome do perfil."; return; } let ok = false; try{ ok = Android.vpnConnect(getName()); }catch(e){} note.textContent = ok ? "A ligar… confirma no Android se pedir autorização." : "Não consegui ligar. A app OpenVPN está instalada e o nome do perfil está certo?"; };
      q("#vpOff").onclick = () => { try{ Android.vpnDisconnect(); }catch(e){} note.textContent = "A abrir a app OpenVPN para desligares lá…"; };
      window.addEventListener("focus", paint);
      paint();
      const prev = window.__nev;
      if(typeof prev === "function") window.__nev = function(k, m){ if(k === "vpn:error"){ note.textContent = String(m); try{ toast(String(m), true); }catch(e){} return; } return prev.apply(this, arguments); };
      if(LS.get("tvVpnAuto", false) && getName()) setTimeout(() => { try{ Android.vpnConnect(getName()); }catch(e){} }, 2500);
    })();
    META["Idioma / Language"] = ["globe", "Idioma / Language", "Português · English · Français"];
    const lgc = extra("setLang2", "globe", "Idioma / Language", "Português · English · Français", '<div id="lgBtns" class="keyList"></div><p class="small muted">A língua muda já. Os detalhes de filmes e séries também são traduzidos para esta língua.</p>');
    (function(){
      const box = lgc.querySelector("#lgBtns");
      const paint = () => { const cur = uiLang(); box.innerHTML = [["pt", "Português"], ["en", "English"], ["fr", "Français"]].map(([k, t]) => '<button class="btn" data-lg="' + k + '" aria-pressed="' + (cur === k) + '">' + (cur === k ? "● " : "○ ") + t + "</button>").join(""); box.style.flexDirection = "column";
        box.querySelectorAll("[data-lg]").forEach(b => b.onclick = () => { cfg.ui = b.dataset.lg; saveCfg(); applyLang(); paint(); }); };
      paint();
    })();
    META["Pré-visualização no Início"] = ["tv", "Pré-visualização no Início", "Mostra o último canal a dar, com ou sem som"];
    const pvc = extra("setPrev", "tv", "Pré-visualização do canal no Início", "Mostra o último canal a dar, com ou sem som", '<div class="row"><button class="btn" id="pvBtn"></button><button class="btn" id="pvSnd"></button></div><p class="small muted">Usa uma ligação extra ao teu IPTV enquanto estás no Início. Pára sozinha ao fim de 10 minutos. Se o teu fornecedor só permite 1 ligação, desliga.</p>');
    (function(){ const b = pvc.querySelector("#pvBtn"), q = pvc.querySelector("#pvSnd");
      const paint = () => { const on = LS.get("tvPrev", "on") !== "off"; b.textContent = on ? "● Ligada" : "○ Desligada"; q.textContent = LS.get("tvPrevSnd", "off") === "on" ? "🔊 Com som" : "🔇 Sem som"; q.disabled = !on; };
      b.onclick = () => { LS.set("tvPrev", LS.get("tvPrev", "on") !== "off" ? "off" : "on"); paint(); };
      q.onclick = () => { LS.set("tvPrevSnd", LS.get("tvPrevSnd", "off") === "on" ? "off" : "on"); paint(); try{ window.__pvVol && window.__pvVol(); }catch(e){} };
      paint(); })();
    const bootc = extra("setBootTv", "tv", "Animação de arranque", "Animação «COCKPIT» ao abrir a app", '<div class="row"><button class="btn" id="bootBtn"></button><button class="btn" id="bootSndBtn"></button></div><p class="small muted">A animação com o logótipo ao abrir a app, com ou sem som. É independente da pré-visualização do canal no Início.</p>');
    (function(){ const a = bootc.querySelector("#bootBtn"), q = bootc.querySelector("#bootSndBtn"); const paint = () => { const on = cfg.boot !== false; a.textContent = on ? "● Animação ligada" : "○ Animação desligada"; q.textContent = cfg.bootSnd !== false ? "● Com som" : "○ Sem som"; q.disabled = !on; }; a.onclick = () => { cfg.boot = !(cfg.boot !== false); saveCfg(); try{ applyBoot(); }catch(e){} paint(); }; q.onclick = () => { cfg.bootSnd = !(cfg.bootSnd !== false); saveCfg(); try{ applyBoot(); }catch(e){} paint(); }; paint(); })();
    const nsc = extra("setNScr", "tv", "Ecrã de canais nativo (experimental)", "Lista, vídeo e botões todos nativos, sem camadas por cima", '<div class="row"><button class="btn" id="nscBtn"></button></div><p class="small muted">Canais, filmes e episódios, com pesquisa, categorias, vista dupla (canais) e legendas online. Se algo correr mal, desliga. Se algo correr mal, volta a desligar.</p>');
    (function(){ const b = nsc.querySelector("#nscBtn"); const paint = () => { b.textContent = LS.get("tvNativeScr", "on") === "on" ? "● Ligado" : "○ Desligado"; }; b.onclick = () => { LS.set("tvNativeScr", LS.get("tvNativeScr", "on") === "on" ? "off" : "on"); paint(); }; paint(); })();
    META["Diagnóstico do vídeo"] = ["gear", "Diagnóstico do vídeo", "Registo do leitor, para descobrir paragens"];
    const dgc = extra("setDiag", "gear", "Diagnóstico do vídeo", "Registo do leitor, para descobrir paragens", '<div class="row"><button class="btn" id="dgRef">Atualizar</button><button class="btn" id="dgCp">Copiar</button><button class="btn primary" id="dgGh">Enviar para o GitHub</button></div><p class="small muted" id="dgMsg" style="margin:4px 0"></p><details><summary class="small">GitHub (para enviar o registo)</summary><label class="f">Repositório<input type="text" id="dgRepo" placeholder="ramarozte-sketch/cockpit-logs" autocomplete="off"></label><label class="f">Token do GitHub (só fica neste aparelho)<input type="password" id="dgTok" placeholder="github_pat_…" autocomplete="off"></label><p class="small muted" style="margin:0">Token com acesso só ao repositório dos registos e permissão «Contents: Read and write». O envio inclui o registo do leitor nativo e o dos canais, sem utilizador nem palavra-passe.</p></details><pre id="dgOut" style="white-space:pre-wrap;font-size:12px;max-height:46vh;overflow:auto;user-select:text">(toca em Atualizar)</pre><p class="small muted">Vê um canal, deixa acontecer a paragem, volta aqui e toca em Atualizar. Mostra o registo (ou tira uma captura de ecrã) para eu perceber o que o leitor fez.</p>');
    (function(){ const out = dgc.querySelector("#dgOut"); const ref = () => { try{ out.textContent = Android.ndbg() || "(vazio)"; }catch(e){ out.textContent = "Sem registo: " + e; } };
      const dm = t => { dgc.querySelector("#dgMsg").textContent = t; }, dr = dgc.querySelector("#dgRepo"), dt = dgc.querySelector("#dgTok");
      dr.value = cfg.dbgRepo || ""; dt.value = LS.get("dbgTok", "") ? "••••••••" : "";
      dr.onchange = () => { cfg.dbgRepo = dr.value.trim(); saveCfg(); };
      dt.onchange = () => { const v = dt.value.trim(); if(v && !/^•+$/.test(v)){ LS.set("dbgTok", v); dt.value = "••••••••"; dm("Token guardado neste aparelho."); } else if(!v){ LS.set("dbgTok", ""); dm("Token apagado."); } };
      const scr = t => { t = String(t == null ? "" : t);
        t = t.replace(/(\/(?:live|movie|series|timeshift)\/)([^/?#\s]+)\/([^/?#\s]+)\//gi, "$1•••/•••/");
        t = t.replace(/([?&](?:username|password|user|pass|pwd|passwd|token|key|k|auth|apikey|api_key|access_token|signature|sig)=)[^&#"\s]*/gi, "$1•••");
        t = t.replace(/(Bearer\s+)[\w.\-]+/gi, "$1•••");
        for(const x of [cfg.xu, cfg.xp, cfg.pkey, cfg.pkey2, cfg.token, cfg.vin, LS.get("dbgTok", "")]){ if(x && String(x).length >= 4){ const v = String(x); t = t.split(v).join("•••"); try{ const e = encodeURIComponent(v); if(e !== v) t = t.split(e).join("•••"); }catch(z){} } }
        return t; };
      const b64 = t => btoa(unescape(encodeURIComponent(t)));
      const send = async () => {
        const tok = LS.get("dbgTok", ""), repo = (cfg.dbgRepo || "ramarozte-sketch/cockpit-logs").trim();
        if(!tok) throw new Error("Falta o token do GitHub (abre «GitHub» aqui por baixo).");
        let nat = []; try{ nat = String(Android.ndbg() || "").split("\n").slice(-200); }catch(e){ nat = ["sem registo nativo: " + e]; }
        let ch = null; try{ const c = (typeof lastPlayed !== "undefined" && (lastPlayed[0] || lastPlayed[1])) || (window.__recents && window.__recents()[0]) || null; if(c) ch = {nome:c.name, tipo:c.kind, grupo:c.group, ext:c.ext, url:c.url}; }catch(e){}
        let net = {}; try{ const n = navigator.connection; if(n) net = {tipo:n.effectiveType, mbps:n.downlink, rtt:n.rtt}; }catch(e){}
        const rep = {ambiente:{versao:APP_VERSION, app:"Cockpit TV", quando:new Date().toISOString(), browser:navigator.userAgent, ecra:innerWidth + "x" + innerHeight + " @" + (window.devicePixelRatio || 1), rede:net}, canal:ch, nativo:nat, motivo:"manual (app TV)"};
        const body = scr(JSON.stringify(rep, null, 1));
        const d = new Date(), pd = n => String(n).padStart(2, "0"), name = d.getFullYear() + "-" + pd(d.getMonth() + 1) + "-" + pd(d.getDate()) + "_" + pd(d.getHours()) + pd(d.getMinutes()) + pd(d.getSeconds()) + "_tv.json";
        const res = await fetch("https://api.github.com/repos/" + repo + "/contents/logs/" + name, {method:"PUT", headers:{Authorization:"Bearer " + tok, Accept:"application/vnd.github+json", "X-GitHub-Api-Version":"2022-11-28"}, body:JSON.stringify({message:"Registo da app TV " + name, content:b64(body)})});
        if(!res.ok){ let m = ""; try{ m = (await res.json()).message; }catch(e){} throw new Error("GitHub " + res.status + (m ? ": " + m : "") + (res.status === 404 ? " (o repositório não existe ou o token não tem acesso)" : res.status === 401 ? " (token inválido ou expirado)" : "")); }
        return name; };
      dgc.querySelector("#dgGh").onclick = async () => { dm("A enviar…"); try{ const n = await send(); dm("Enviado ✓ logs/" + n); toast("Registo enviado para o GitHub ✓"); }catch(e){ dm(String(e && e.message || e)); } };
      window.__tvSendLog = send;
      ref();
      dgc.querySelector("#dgRef").onclick = ref; dgc.querySelector("#dgCp").onclick = () => { try{ navigator.clipboard.writeText(out.textContent); toast("Copiado."); }catch(e){} }; })();
    META["Países"] = ["globe", "Países", "Ordenar e esconder países nas listas"];
    const cyc = extra("setCty", "globe", "Países", "Ordenar e esconder países nas listas", '<p class="small muted">Os países vêm dos prefixos das categorias do teu IPTV (|PT|, |ES|, …). A ordem e os países escondidos aplicam-se ao Início, Explorar e Guia.</p><div class="row"><button class="btn" id="ctyHideAll">🚫 Ocultar todos</button><button class="btn" id="ctyShowAll">👁 Mostrar todos</button><button class="btn" id="ctyReset">Repor</button></div><div id="ctyList" class="ctyList"></div>');
    (function(){
      const box = cyc.querySelector("#ctyList"), C = window.__cty;
      const scan = () => {
        const m = new Map();
        (typeof channels !== "undefined" ? channels : []).forEach(c => { if(!c.group || (c.kind !== "live" && c.kind !== "movie" && c.kind !== "series")) return; const k = C.ctyOfItem(c); const e = m.get(k) || {code:k, groups:new Set(), n:0}; e.groups.add(c.group); e.n++; m.set(k, e); });
        const st = C.state(), arr = [...m.values()];
        arr.sort((a, b) => { const ra = st.order.indexOf(a.code), rb = st.order.indexOf(b.code); const xa = ra >= 0 ? ra : (a.code === "PT" ? -1 : 1e6), xb = rb >= 0 ? rb : (b.code === "PT" ? -1 : 1e6); return xa - xb || b.n - a.n; });
        return arr;
      };
      const refresh = () => { try{ fillGroups(); }catch(e){} try{ renderTvList(); }catch(e){} try{ if(typeof gdFillGroups === "function") gdFillGroups(); }catch(e){} try{ if(currentView === "tvhome") renderHome(true); }catch(e){} };
      const paint = focusKey => {
        const arr = scan(), st = C.state();
        if(!arr.length){ box.innerHTML = '<p class="small muted">Ainda não há canais. Adiciona primeiro a tua lista IPTV.</p>'; return; }
        box.innerHTML = arr.map((e, i) => {
          const off = st.hide.indexOf(e.code) >= 0;
          return '<div class="orgrow' + (off ? " off" : "") + '"><span class="nm">' + C.flag(e.code) + " " + esc(C.name(e.code)) + ' <span class="muted small">(' + e.groups.size + " categorias · " + e.n + " canais)</span></span>"
            + '<button class="btn" data-a="top" data-c="' + encodeURIComponent(e.code) + '" aria-label="Pôr no topo">⤒</button><button class="btn" data-a="up" data-c="' + encodeURIComponent(e.code) + '" aria-label="Subir">▲</button><button class="btn" data-a="dn" data-c="' + encodeURIComponent(e.code) + '" aria-label="Descer">▼</button>'
            + '<button class="btn" data-a="hide" data-c="' + encodeURIComponent(e.code) + '">' + (off ? "👁 Mostrar" : "🚫 Ocultar") + "</button></div>";
        }).join("");
        box.querySelectorAll("button[data-a]").forEach(b => b.onclick = () => {
          const code = decodeURIComponent(b.dataset.c), a = b.dataset.a, cur = scan().map(x => x.code);
          const s2 = C.state(); s2.order = cur;
          const i = s2.order.indexOf(code);
          if(a === "top"){ s2.order.splice(i, 1); s2.order.unshift(code); }
          else if(a === "up" && i > 0){ s2.order.splice(i, 1); s2.order.splice(i - 1, 0, code); }
          else if(a === "dn" && i < s2.order.length - 1){ s2.order.splice(i, 1); s2.order.splice(i + 1, 0, code); }
          else if(a === "hide"){ const k = s2.hide.indexOf(code); k < 0 ? s2.hide.push(code) : s2.hide.splice(k, 1); }
          C.save(); refresh(); paint(code + "\u0001" + a);
        });
        if(focusKey){ const j = focusKey.lastIndexOf("\u0001"), c = focusKey.slice(0, j), a = focusKey.slice(j + 1); const f = [...box.querySelectorAll("button[data-a]")].find(x => decodeURIComponent(x.dataset.c) === c && x.dataset.a === a); if(f) f.focus({preventScroll:true}); }
      };
      cyc.querySelector("#ctyHideAll").onclick = () => { const s2 = C.state(), cur = scan().map(x => x.code); s2.order = cur.slice(); s2.hide = cur.slice(); C.save(); refresh(); paint(); try{ toast("Todos ocultos. Mostra só os que quiseres."); }catch(e){} };
      cyc.querySelector("#ctyShowAll").onclick = () => { const s2 = C.state(); s2.hide = []; C.save(); refresh(); paint(); };
      cyc.querySelector("#ctyReset").onclick = () => { const s2 = C.state(); s2.order = []; s2.hide = []; C.save(); refresh(); paint(); };
      cyc.addEventListener("click", e => { if(e.target.closest(".setHead")) setTimeout(() => paint(), 40); }, true);
      window.__ctyPaint = paint;   /* só desenha quando abres o cartão «Países» ou as Definições (antes varria a lista toda no arranque) */
    })();
    const order = ["TV e IPTV", "Aparência e layout", "Cópia de segurança"];
    /* ===== Controlo parental (PIN) ===== */
    META["Controlo parental"] = ["gear", "Controlo parental", "Esconde conteúdo adulto atrás de um PIN"];
    const pac = extra("setPar", "gear", "Controlo parental", "Esconde conteúdo adulto atrás de um PIN", '<p id="parSt" class="small"></p><div class="row"><button class="btn" id="parSet">🔢 Definir / mudar PIN</button><button class="btn" id="parUnl">🔓 Desbloquear</button><button class="btn" id="parOff">🗑 Remover PIN</button></div><p class="small muted">Com PIN definido, categorias e canais/filmes com nomes como «adultos», «XXX», «18+» ficam escondidos nas listas. «Desbloquear» mostra-os até fechares a app. Funciona por palavras no nome da categoria ou do título; não é infalível.</p>');
    (function(){
      const P = window.__par, KEY = "ck_parPin";
      const hashPin = p => { let h = 5381; const s = "ck|" + p; for(let i = 0; i < s.length; i++) h = ((h << 5) + h + s.charCodeAt(i)) | 0; return String(h); };
      const pinPad = (title, cb) => {
        const ov = document.createElement("div"); ov.className = "epgdlg";
        ov.style.cssText = "position:fixed;inset:0;z-index:99999;background:rgba(0,0,0,.88);display:flex;align-items:center;justify-content:center";
        let v = "";
        ov.innerHTML = '<div style="background:#14213a;border-radius:16px;padding:18px;width:min(320px,92vw);text-align:center"><h3 style="margin:0 0 8px">' + esc(title) + '</h3><div id="ppDots" style="font-size:28px;letter-spacing:8px;min-height:38px">&nbsp;</div><div id="ppG" style="display:grid;grid-template-columns:repeat(3,1fr);gap:8px;margin-top:8px"></div></div>';
        const g = ov.querySelector("#ppG"), dots = ov.querySelector("#ppDots");
        const done = r => { ov.remove(); setTimeout(() => cb(r), 0); };
        const paint = () => { dots.textContent = v ? "●".repeat(v.length) : " "; };
        ["1","2","3","4","5","6","7","8","9","⌫","0","✔"].forEach(k => { const b = document.createElement("button"); b.className = "btn"; b.type = "button"; b.textContent = k; b.style.cssText = "padding:14px 0;font-size:20px"; b.onclick = () => { if(k === "⌫") v = v.slice(0, -1); else if(k === "✔"){ if(v.length >= 4) return done(v); } else if(v.length < 8) v += k; paint(); }; g.appendChild(b); });
        const c = document.createElement("button"); c.className = "btn"; c.type = "button"; c.textContent = "Cancelar"; c.style.cssText = "grid-column:1/-1"; c.onclick = () => done(null); g.appendChild(c);
        document.body.appendChild(ov); try{ g.children[0].focus(); }catch(e){}
      };
      const st = pac.querySelector("#parSt");
      const paint = () => { const on = !!localStorage.getItem(KEY); st.textContent = on ? (P.unlocked ? "PIN definido · desbloqueado até fechares a app" : "PIN definido · conteúdo adulto escondido") : "Sem PIN · nada escondido"; pac.querySelector("#parUnl").textContent = P.unlocked ? "🔒 Bloquear já" : "🔓 Desbloquear"; };
      const refresh = () => { try{ fillGroups(); }catch(e){} try{ renderTvList(); }catch(e){} try{ if(typeof gdFillGroups === "function") gdFillGroups(); }catch(e){} try{ if(currentView === "tvhome") renderHome(true); }catch(e){} };
      const check = (cb) => { const cur = localStorage.getItem(KEY); if(!cur) return cb(); pinPad("PIN atual", p => { if(p === null) return; if(hashPin(p) === cur) cb(); else toast("PIN errado.", true); }); };
      pac.querySelector("#parSet").onclick = () => check(() => pinPad("Novo PIN (4 a 8 dígitos)", a => { if(a === null) return; pinPad("Repete o PIN", b => { if(b === null) return; if(a !== b){ toast("Os PIN não coincidem.", true); return; } try{ localStorage.setItem(KEY, hashPin(a)); }catch(e){} P.unlocked = false; paint(); refresh(); toast("PIN guardado ✓"); }); }));
      pac.querySelector("#parOff").onclick = () => { if(!localStorage.getItem(KEY)){ toast("Não há PIN."); return; } check(() => { try{ localStorage.removeItem(KEY); }catch(e){} P.unlocked = false; paint(); refresh(); toast("PIN removido ✓"); }); };
      pac.querySelector("#parUnl").onclick = () => { if(!localStorage.getItem(KEY)){ toast("Define primeiro um PIN."); return; } if(P.unlocked){ P.unlocked = false; paint(); refresh(); return; } check(() => { P.unlocked = true; paint(); refresh(); toast("Desbloqueado ✓"); }); };
      paint();
    })();

    /* ===== Diagnóstico da app ===== */
    window.__errRing = window.__errRing || [];
    try{ window.addEventListener("error", e => { window.__errRing.push(new Date().toTimeString().slice(0, 8) + " erro: " + (e.message || e)); if(window.__errRing.length > 30) window.__errRing.shift(); }); window.addEventListener("unhandledrejection", e => { window.__errRing.push(new Date().toTimeString().slice(0, 8) + " promessa: " + (e.reason && e.reason.message || e.reason)); if(window.__errRing.length > 30) window.__errRing.shift(); }); }catch(e){}
    try{ const t0 = window.toast; if(typeof t0 === "function" && !t0.__w){ window.toast = toast = function(m, bad){ if(bad){ window.__errRing.push(new Date().toTimeString().slice(0, 8) + " aviso: " + m); if(window.__errRing.length > 30) window.__errRing.shift(); } return t0.apply(this, arguments); }; window.toast.__w = 1; } }catch(e){}
    META["Diagnóstico da app"] = ["gear", "Diagnóstico da app", "Versão, listas, memória, cache e erros recentes"];
    const dg2 = extra("setDiag2", "gear", "Diagnóstico da app", "Versão, listas, memória, cache e erros recentes", '<div class="row"><button class="btn" id="d2Ref">Atualizar</button><button class="btn" id="d2Cp">Copiar</button><button class="btn" id="d2Save">Guardar ficheiro</button><button class="btn" id="d2Clr">Limpar cache de picons</button></div><pre id="d2Out" style="white-space:pre-wrap;font-size:12px;max-height:46vh;overflow:auto;user-select:text">(toca em Atualizar)</pre>');
    (function(){
      const out = dg2.querySelector("#d2Out");
      const host = u => { try{ return new URL(u).host; }catch(e){ return u ? "(inválido)" : "—"; } };
      const build = () => {
        let d = {}; try{ d = JSON.parse(Android.diag()); }catch(e){}
        const ch = typeof channels !== "undefined" ? channels : [];
        const cnt = k => ch.filter(c => c.kind === k).length;
        const L = [];
        L.push("Página: " + (typeof APP_VERSION !== "undefined" ? APP_VERSION : "?") + " · App: " + (d.version || "?"));
        L.push("Aparelho: " + (d.device || "?") + " · Android SDK " + (d.sdk || "?") + " · janela flutuante: " + (d.pip ? "sim" : "não"));
        L.push("Memória (MB usados/máx.): " + (d.heapMB || "?"));
        L.push("Cache de picons: " + (d.piconFiles != null ? d.piconFiles + " ficheiros, " + d.piconMB + " MB" : "?"));
        L.push("Canais: " + cnt("live") + " · Filmes: " + cnt("movie") + " · Séries: " + cnt("series") + " · Sem categoria: " + ch.filter(c => !c.group || /sem categoria/i.test(c.group)).length);
        L.push("Servidor Xtream: " + host(cfg.xs) + " · M3U: " + host(cfg.m3u) + " · Guia: " + host(cfg.epg));
        L.push("Ecrã nativo: " + (LS.get("tvNativeScr", "on") === "on" ? "ligado" : "desligado") + " · PIN parental: " + (localStorage.getItem("ck_parPin") ? "sim" : "não"));
        L.push("Ligação: " + (navigator.onLine ? "online" : "offline"));
        L.push("", "Erros e avisos recentes:");
        (window.__errRing.length ? window.__errRing.slice().reverse() : ["(nenhum)"]).forEach(x => L.push(" " + x));
        return L.join("\n");
      };
      const ref = () => { out.textContent = build(); };
      dg2.querySelector("#d2Ref").onclick = ref;
      dg2.querySelector("#d2Cp").onclick = () => { ref(); try{ navigator.clipboard.writeText(out.textContent); toast("Copiado ✓"); }catch(e){ toast("Não consegui copiar.", true); } };
      dg2.querySelector("#d2Save").onclick = () => { ref(); try{ Android.saveText("cockpit-diagnostico.json", out.textContent); }catch(e){ toast("Não consegui abrir o seletor.", true); } };
      dg2.querySelector("#d2Clr").onclick = () => { try{ Android.clearPicons(); toast("Cache de picons limpa ✓"); setTimeout(ref, 600); }catch(e){} };
      ref();
    })();
    META["Reprodução em túnel (TV)"] = ["tv", "Reprodução em túnel (TV)", "Melhor sincronia e 4K em algumas TVs"];
    const exc = extra("setExtPlayer", "play", "Leitor externo", "VLC, MX Player, Just Player, Kodi…", '<div class="row"><select id="exSel" class="btn" style="min-width:220px"></select></div><p class="small muted">Abre canais, filmes e episódios na outra app em vez do leitor da Cockpit. Só aparecem as apps instaladas. "Perguntar sempre" mostra o seletor do Android. Limitações: legendas online, picture-in-picture, vários frames, estatísticas e retoma podem não funcionar na outra app; alguns canais que exigem proxy ou cabeçalhos especiais só abrem no leitor da Cockpit. Se falhar, a app usa o leitor interno.</p>');
    (function(){ const sel = exc.querySelector("#exSel"); const L = (window.EXTP && EXTP.list()) || [];
      const opts = [["", "Desligado (usar leitor da app)"], ["*", "Perguntar sempre"]].concat(L.map(x => [x.p, x.n]));
      sel.innerHTML = opts.map(o => '<option value="' + o[0] + '">' + o[1] + '</option>').join(""); sel.value = LS.get("extPlayer", ""); if(sel.value !== LS.get("extPlayer", "")) sel.value = "";
      sel.onchange = () => { LS.set("extPlayer", sel.value); try{ toast(sel.value ? "Leitor externo ativo." : "Leitor externo desligado."); }catch(e){} }; })();
    const zmc = extra("setZoom", "gear", "Tamanho do ecrã (zoom)", "Capas, texto e botões maiores ou mais pequenos", '<div class="row"><button class="btn" id="zmOut">− Menos</button><b id="zmVal" style="min-width:72px;text-align:center;align-self:center"></b><button class="btn" id="zmIn">+ Mais</button><button class="btn" id="zmRst">Automático</button></div><p class="small muted">Altera o tamanho de toda a interface (menu, capas, guia e controlos do leitor). Na TV o automático é 85 %. A app reinicia o ecrã ao mudar e pára a reprodução em curso. Atalhos do teclado: Ctrl + e Ctrl −.</p>');
    (function(){ const v = zmc.querySelector("#zmVal"); const cur = () => { try{ return Math.round(Android.getUiScale() * 100); }catch(e){ return 100; } };
      v.textContent = cur() + " %";
      const set = pc => { pc = Math.max(50, Math.min(160, pc)); try{ Android.setUiScale(pc / 100); }catch(e){} };
      zmc.querySelector("#zmOut").onclick = () => set(cur() - 10); zmc.querySelector("#zmIn").onclick = () => set(cur() + 10);
      zmc.querySelector("#zmRst").onclick = () => { try{ Android.resetUiScale(); }catch(e){} };
      document.addEventListener("keydown", e => { if(!e.ctrlKey) return; if(e.key === "+" || e.key === "=") { e.preventDefault(); set(cur() + 10); } else if(e.key === "-") { e.preventDefault(); set(cur() - 10); } }); })();
    const txc = extra("setTexture", "tv", "Superfície do vídeo (TV)", "Automático ou sempre compatível", '<div class="row"><button class="btn" id="txBtn"></button></div><p class="small muted">Automático (recomendado): com 1 frame o vídeo usa a superfície directa da TV (imagem sem riscos em movimento, desentrelaçada pelo hardware); com 2 a 4 frames muda sozinho para a compatível, que evita o frame 1 preto. Sempre compatível: usa a compatível em tudo, mas pode ver riscos em canais entrelaçados. Aplica-se depois de fechares e reabrires a app.</p>');
    (function(){ const b = txc.querySelector("#txBtn"); const get = () => { try{ return !!Android.getTvTexture(); }catch(e){ return false; } }; const paint = () => { b.textContent = get() ? "● Sempre compatível" : "○ Automático"; }; b.onclick = () => { try{ Android.setTvTexture(!get()); }catch(e){} paint(); try{ toast("Fecha e reabre a app para aplicar."); }catch(e){} }; paint(); })();
    const tnc = extra("setTunnel", "tv", "Reprodução em túnel (TV)", "Melhor sincronia e 4K em algumas TVs", '<div class="row"><button class="btn" id="tnBtn"></button></div><p class="small muted">Entrega o vídeo diretamente ao hardware da TV: menos falhas em 4K/HDR e som sincronizado. Só em Android TV e aplica-se ao próximo vídeo. Fica desligado se o desentrelaçamento estiver ligado. Se aparecer ecrã preto ou sem legendas, desliga.</p>');
    (function(){ const b = tnc.querySelector("#tnBtn"); const paint = () => { b.textContent = LS.get("tvTunnel", false) ? "● Ligado" : "○ Desligado"; }; b.onclick = () => { const v = !LS.get("tvTunnel", false); LS.set("tvTunnel", v); try{ Android.setTunnel(v); }catch(e){} paint(); }; paint(); try{ Android.setTunnel(!!LS.get("tvTunnel", false)); }catch(e){} })();
    const byT = {}; cards.forEach(c => { byT[(c.querySelector("h2") || {}).textContent.trim()] = c; });
    /* Opções do «TV Direto» (Bravia) passam para as Definições; no separador ficam só os canais */
    const brc = (function(){ const el = document.getElementById("tvLiveBr"); if(!el) return null; const c = extra("setBravia", "tv", "TV em direto (Sony Bravia)", "Liga a app à TV para listar e sintonizar os canais do sintonizador", ""); const t = el.querySelector("b"); if(t) t.remove(); el.style.margin = "0"; c.appendChild(el); const dg = document.getElementById("tvLiveDiag"); if(dg) c.appendChild(dg); return c; })();
    const base = order.map(t => byT[t]).filter(Boolean);
    /* agrupa cartões do mesmo género: menos cartões, com subtítulos lá dentro */
    const group = (id, ic, title, sub, members) => {
      members = members.filter(Boolean);
      const g = document.createElement("section"); g.className = "setcard panel"; g.id = id;
      g.innerHTML = "<h2>" + title + "</h2>"; META[title] = [ic, title, sub];
      members.forEach(m => {
        const h = m.querySelector("h2"); const mt = h ? h.textContent.trim() : "";
        const sb = m.querySelector(".setsub"); if(sb) sb.remove();
        if(!m.parentNode){
          /* cartões criados aqui: entram inteiros (os seus elementos e ligações continuam no sítio) */
          if(h){ const h3 = document.createElement("h3"); h3.textContent = mt; h.replaceWith(h3); }
          m.className = "setSect"; g.appendChild(m);
        } else {
          /* cartões que já estavam na página: passam o conteúdo para o grupo */
          const w = document.createElement("div"); w.className = "setSect"; w.innerHTML = "<h3>" + esc(mt) + "</h3>";
          [...m.children].forEach(ch => { if(ch.tagName !== "H2") w.appendChild(ch); });
          g.appendChild(w); m.hidden = true; m.style.display = "none";
        }
      });
      return g;
    };
    document.head.insertAdjacentHTML("beforeend", "<style>.setSect{display:flex;flex-direction:column;gap:12px;padding:6px 0 18px;border-top:1px solid #ffffff1a}.setSect:first-child{border-top:0}.setSect>h3{margin:6px 0 0;font-size:19px}#setFoldBar{display:none !important}</style>");
    const icc = extra("setIcons", "palette", "Estilo dos ícones", "Cinco tipos de ícones, iguais no telemóvel e na TV", '<div id="icsBtns" class="icsGrid"></div><p class="small muted">Muda os ícones da página e os botões do ecrã nativo (transporte, ecrã total, áudio, legendas…).</p>');
    (function(){
      const box = icc.querySelector("#icsBtns"), SAMPLE = ["home", "search", "guide", "play", "sound", "full"];
      const pv = k => { const t = ICS[k]; if(t.emoji) return '<span style="font-size:22px;letter-spacing:6px">🏠🔎📅▶🔊⛶</span>'; const st = "stroke-width:" + t.w + ";stroke-linecap:" + t.cap + ";stroke-linejoin:" + t.join; return SAMPLE.map(n => '<svg class="ic' + (t.duo ? " icduo" : "") + (t.solid ? " icsolid" : "") + '" viewBox="0 0 24 24" style="' + st + '">' + SV[n] + '</svg>').join(""); };
      const paint = () => { const cur = icKey(); box.innerHTML = Object.keys(ICS).map(k => '<button class="btn icsB" data-ics="' + k + '" aria-pressed="' + (cur === k) + '"><b>' + (cur === k ? "● " : "○ ") + k + " · " + ICS[k].n + '</b><span class="icsPv">' + pv(k) + '</span></button>').join("");
        box.querySelectorAll("[data-ics]").forEach(b => b.onclick = () => { LS.set("icStyle", b.dataset.ics); icApply(); paint(); try{ window.__icRefresh(); }catch(e){} }); };
      paint();
    })();
    const G = [
      group("setGList", "list", "Lista IPTV e ligação", "Fornecedor, perfis, proxy e VPN", [base[0], prof, pxc, vpc]),
      group("setGHome", "palette", "Início e canais", "Aparência, países, ordem, pré-visualização e idioma", [base[1], icc, cyc, opc, pvc, bootc, lgc]),
      group("setGVid", "tv", "Vídeo e imagem", "Ecrã nativo, desentrelaçamento, zoom, superfície e túnel", [nsc, vid, zmc, txc, tnc]),
      group("setGPlay", "tv", "Leitores e TV", "Leitor externo e TV em direto (Bravia)", [exc, brc]),
      group("setGSafe", "save", "Segurança e cópia", "Controlo parental e cópia de segurança", [pac, base[2]]),
      group("setGHelp", "info", "Diagnóstico e ajuda", "Diagnósticos, teclas do comando e versão", [dg2, dgc, remote, about])
    ];
    const list = G;
    const _unused = base.slice(0, 1).concat([prof, opc], base.slice(1, 2), [cyc, pvc, nsc].concat(brc ? [brc] : [], [lgc, vid, pxc, exc, zmc, txc, tnc, vpc, pac, dg2, dgc]), base.slice(2), [remote, about]);
    const grid = document.createElement("div"); grid.id = "tvSetGrid";
    const first = cards[0]; if(first && first.parentNode) first.parentNode.insertBefore(grid, first); else st.appendChild(grid);
    list.forEach(card => {
      const t = (card.querySelector("h2") || {}).textContent.trim(), m = META[t] || ["gear", t, ""];
      const sub = card.querySelector(".setsub"); if(sub) sub.remove();
      const body = document.createElement("div"); body.className = "setBody"; body.hidden = true;
      [...card.children].forEach(ch => { if(ch.tagName !== "H2") body.appendChild(ch); });
      const head = document.createElement("button"); head.className = "setHead"; head.setAttribute("aria-expanded", "false");
      head.innerHTML = '<span class="setIc">' + icon(m[0]) + '</span><span class="setT"><b>' + esc(m[1]) + '</b><small>' + esc(m[2]) + '</small></span><span class="chev">' + icon("chev") + '</span>';
      { const h2 = card.querySelector(":scope > h2"); if(h2) h2.remove(); card.classList.remove("fold"); }   /* um só título por grupo: o cabeçalho com ícone (o h2 duplicava-o e abria em dois passos) */
      card.appendChild(head); card.appendChild(body); card.classList.add("setfold");
      head.onclick = () => {
        const open = !card.classList.contains("open");
        grid.querySelectorAll(".setcard.open").forEach(o => { o.classList.remove("open"); o.querySelector(".setBody").hidden = true; o.querySelector(".setHead").setAttribute("aria-expanded", "false"); });
        if(open){ card.classList.add("open"); body.hidden = false; head.setAttribute("aria-expanded", "true"); setTimeout(() => card.scrollIntoView({block:"start"}), 30); }
      };
      grid.appendChild(card);
    });
    /* primeira vez (sem lista IPTV): abre logo o cartão da lista */
    try{ if(!(cfg.m3u || cfg.xs)){ const h = grid.querySelector(".setHead"); if(h) h.click(); } }catch(e){}
  })();

  /* ===== Episódio seguinte automático + Saltar intro ===== */
  (function(){
    const st = {off:"", nextAt:0, tick:null, shown:"", act:null};
    const bar = document.createElement("div"); bar.id = "nxBar"; bar.hidden = true;
    bar.innerHTML = '<span id="nxTx"></span><button class="btn" id="nxGo">OK</button><button class="btn" id="nxNo">Cancelar</button>';
    document.body.appendChild(bar);
    document.head.insertAdjacentHTML("beforeend", "<style>#nxBar{position:fixed;right:24px;bottom:26px;z-index:60;display:flex;align-items:center;gap:10px;padding:12px 16px;border-radius:16px;background:#1a2b44ee;box-shadow:0 8px 30px #000a;font-size:18px}#nxBar[hidden]{display:none}body.phone #nxBar{bottom:78px;right:10px;left:10px;font-size:15px}body.vfull #nxBar{display:none}</style>");
    const cur = () => { try{ return lastPlayed && lastPlayed[0]; }catch(e){ return null; } };
    const pos = () => { try{
      if(NATIVE.active && !NATIVE.live && NATIVE.cur){ const a = String(Android.npos()).split("|").map(Number); if(!a[2]) return {p:a[0] / 1000, d:a[1] / 1000}; return null; }
      const v = $("vid0"); if(v && isFinite(v.duration) && v.duration > 0) return {p:v.currentTime, d:v.duration};
    }catch(e){} return null; };
    const seekBy = s => { try{ if(NATIVE.active) Android.nseek(s * 1000); else { const v = $("vid0"); v.currentTime = Math.min(v.duration - 1, v.currentTime + s); } }catch(e){} };
    const idxOf = c => { const L = window.EPL && EPL.list; if(!L || !c) return -1; return L.findIndex(e => e.url === c.url); };
    function hide(){ bar.hidden = true; st.act = null; st.shown = ""; try{ if(typeof Android.nhud === "function") Android.nhud(""); }catch(e){} }
    function show(txt, goLabel, act, noLabel){
      st.act = act; $("nxTx").textContent = txt; $("nxGo").textContent = goLabel; $("nxNo").textContent = noLabel || "Cancelar"; bar.hidden = false;
      try{ if(typeof Android.nhud === "function") Android.nhud(txt + "  ·  OK: " + goLabel); }catch(e){}
    }
    $("nxGo").onclick = () => { const a = st.act; hide(); if(a) a(); };
    $("nxNo").onclick = () => { const c = cur(); if(c) st.off = c.url + "|" + st.shown; hide(); };
    window.__nxKey = k => { if(bar.hidden || !st.act) return false; if(k === "Enter" && document.body.classList.contains("vfull")){ const a = st.act; hide(); a(); return true; } if(k === "GoBack" && document.body.classList.contains("vfull")){ $("nxNo").onclick(); return true; } return false; };
    setInterval(() => {
      const c = cur(); if(!c || c.kind !== "episode"){ if(!bar.hidden) hide(); return; }
      const t = pos(); if(!t){ return; }
      const i = idxOf(c), L = window.EPL && EPL.list;
      const left = t.d - t.p;
      if(i >= 0 && L[i + 1] && t.d > 120 && left <= 12){
        const key = c.url + "|next"; if(st.off === key) return;
        st.shown = "next"; const n = Math.max(0, Math.ceil(left));
        show("Episódio seguinte em " + n + " s", "Ver agora", () => { const nx = L[i + 1]; if(nx) playChannel(nx); }, "Cancelar");
        if(left <= 1.2){ const nx = L[i + 1]; hide(); st.off = key; if(nx) playChannel(nx); }
        return;
      }
      if(t.p > 4 && t.p < 180 && t.d > 600){
        const key = c.url + "|intro"; if(st.off === key) return;
        st.shown = "intro"; show("Saltar intro?", "Saltar 85 s", () => { st.off = c.url + "|intro"; seekBy(85); }, "Não");
        return;
      }
      if(!bar.hidden) hide();
    }, 1000);
  })();

  /* ===== Pesquisa por voz ===== */
  (function(){
    SV.mic = '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M9 21h6"/>';
    const can = typeof Android.voice === "function";
    const strip = t => String(t || "").toLowerCase().replace(/[.,!?]/g, " ").replace(/\s+/g, " ").trim();
    window.__voice = () => { if(!can){ try{ toast("Pesquisa por voz só existe na app Android.", true); }catch(e){} return; } try{ toast("🎤 A ouvir…"); }catch(e){} try{ Android.voice(); }catch(e){} };
    window.__voiceDone = txt => {
      let q = strip(txt), kind = "live", play = false;
      if(/^(ver|vê|ve|pôr|põe|poe|pôr no|abre|abrir|mostra|mostrar|liga|sintoniza)\b/.test(q)){ play = true; q = q.replace(/^(ver|vê|ve|pôr no|pôr|põe|poe|abre|abrir|mostra|mostrar|liga|sintoniza)\s+/, ""); }
      if(/^(o |a |os |as )?(filme|filmes)\b/.test(q)){ kind = "movie"; q = q.replace(/^(o |a |os |as )?(filmes?)\s*/, ""); }
      else if(/^(o |a |os |as )?(s[ée]rie|s[ée]ries)\b/.test(q)){ kind = "series"; q = q.replace(/^(o |a |os |as )?(s[ée]ries?)\s*/, ""); }
      q = q.replace(/^(o |a |os |as )?(canal)\s+/, "").replace(/^(o |a )\s*/, "").trim();
      if(!q) return;
      try{ toast("🎤 «" + q + "»"); }catch(e){}
      try{ window.__homeOrigin = false; show("tv"); }catch(e){}
      setTimeout(() => {
        try{ const kb = document.querySelector('[data-kind="' + kind + '"]'); if(kb && kb.getAttribute("aria-pressed") !== "true") kb.click(); }catch(e){}
        const inp = $("tvSearch"); if(inp){ inp.value = q; inp.dispatchEvent(new Event("input", {bubbles:true})); }
        if(play){
          setTimeout(() => { try{ const n = (typeof norm === "function" ? norm(q) : q); const best = channels.filter(c => c.kind === kind && (typeof norm === "function" ? norm(c.name) : c.name.toLowerCase()).includes(n)).sort((a, b) => a.name.length - b.name.length)[0]; if(best){ if(best.kind === "series" && best.sid) openSeries(best); else playChannel(best); } }catch(e){} }, 250);
        } else { const f = document.querySelector("#tvList [data-play]"); if(f) f.focus({preventScroll:true}); }
      }, 200);
    };
    /* botão do microfone ao lado da pesquisa */
    const inp = $("tvSearch");
    if(inp && !$("voiceBtn")){
      const b = document.createElement("button"); b.className = "btn"; b.id = "voiceBtn"; b.type = "button"; b.setAttribute("aria-label", "Pesquisa por voz"); b.innerHTML = icon("mic") + " Voz";
      b.onclick = () => window.__voice();
      inp.after(b);
    }
    if(!can){ const b = $("voiceBtn"); if(b) b.hidden = true; }
  })();

  /* ===== Vista dupla: 2 canais lado a lado ===== */
  (function(){
    const cb = $("chSubs") ? $("chSubs").parentNode : (document.querySelector("#v-tv .cinebar")); if(!cb || $("mvBtn")) return;
    SV.dual = '<rect x="3" y="5" width="8" height="14" rx="1.5"/><rect x="13" y="5" width="8" height="14" rx="1.5"/>';
    const mk = (id, html, fn) => { const b = document.createElement("button"); b.className = "btn"; b.id = id; b.type = "button"; b.innerHTML = html; b.onclick = fn; cb.appendChild(b); return b; };
    let on = false;
    const modeBtn = m => document.querySelector('[data-mode="' + m + '"]');
    const paint = () => {
      $("mvBtn").innerHTML = on ? icon("dual") + " Sair" : icon("dual") + " Dupla";
      ["mvT0", "mvT1", "mvAud", "mvMode"].forEach(i => { $(i).hidden = !on; });
      try{ const cur = (["split", "pip", "splitv"].find(m => $("stage").classList.contains(m))) || "split"; $("mvMode").innerHTML = "⧉ " + ({split:"50/50", pip:"PIP", splitv:"Cima/baixo"})[cur]; }catch(e){}
      $("mvT0").setAttribute("aria-pressed", String(tvTarget === 0)); $("mvT1").setAttribute("aria-pressed", String(tvTarget === 1));
      $("mvAud").innerHTML = "🔊 Som " + (audioSlot + 1);
      $("mvT0").classList.toggle("on", tvTarget === 0); $("mvT1").classList.toggle("on", tvTarget === 1);
    };
    let wasCin = false;
    mk("mvBtn", "", () => {
      if(!on){
        const c0 = lastPlayed[0]; on = true;
        wasCin = document.querySelector(".app").classList.contains("cinema");
        try{ NATIVE.stop(); }catch(e){}
        /* a lista de canais tem de estar visível: sai do modo cinema e do ecrã inteiro */
        try{ setCinema(false); }catch(e){} document.body.classList.remove("vfull");
        modeBtn("split").click(); setTarget(1);
        if(c0){ try{ playChannel(c0, 0); }catch(e){} }
        try{ toast("Vista dupla: escolhe na lista o canal do ecrã 2 (OK). «Ecrã 1/2» muda o destino."); }catch(e){}
        setTimeout(() => { const f = document.querySelector("#tvList [data-play]") || document.querySelector("#tvSearch"); if(f) f.focus({preventScroll:true}); }, 200);
      } else {
        const c0 = lastPlayed[0]; on = false;
        try{ stopSlot(1); lastPlayed[1] = null; }catch(e){}
        modeBtn("single").click(); setTarget(0);
        if(c0){ try{ playChannel(c0, 0); }catch(e){} if(wasCin){ try{ setCinema(true); $("stage").focus({preventScroll:true}); }catch(e){} } }
      }
      paint(); try{ updateCinemaBar(); }catch(e){}
    });
    const modes = ["split", "pip", "splitv"], names = {split:"50/50", pip:"PIP", splitv:"Cima/baixo"};
    mk("mvMode", "", () => { const cur = (modes.find(m => $("stage").classList.contains(m))) || "split"; const nx = modes[(modes.indexOf(cur) + 1) % modes.length]; modeBtn(nx).click(); paint(); });
    mk("mvT0", "Ecrã 1", () => { setTarget(0); paint(); });
    mk("mvT1", "Ecrã 2", () => { setTarget(1); paint(); });
    mk("mvAud", "", () => { $("btnSwapAudio").click(); paint(); });
    document.head.insertAdjacentHTML("beforeend", "<style>#mvBtn[hidden],#mvT0[hidden],#mvT1[hidden],#mvAud[hidden],#mvMode[hidden]{display:none!important}.cinebar .btn.on{background:var(--accent);color:var(--accent-ink)}body.android .stage.split .slot{outline:2px solid transparent}body.android .stage.split .slot.active{outline-color:var(--accent);outline-offset:-3px}</style>");
    paint();
    /* Telemóvel: botão Cast no leitor quando há um canal/filme ligado */
    if(!isTvDev && typeof Android.cpick === "function"){
      SV.cast = '<path d="M3 18a3 3 0 0 1 3 3M3 14a7 7 0 0 1 7 7M3 10a11 11 0 0 1 11 11"/><path d="M3 6V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/>';
      const cc = mk("chCast", icon("cast") + " Cast", () => { try{ Android.cpick(); }catch(e){ try{ toast("Google Cast indisponível neste telemóvel.", true); }catch(x){} } });
      const upd = () => { const on = !!(window.CAST && CAST.active), has = !!(lastPlayed && (lastPlayed[0] || lastPlayed[1])); cc.hidden = !(has || on); cc.classList.toggle("on", on); cc.innerHTML = icon("cast") + (on ? " " + (CAST.name || "Cast") : " Cast"); };
      document.head.insertAdjacentHTML("beforeend", "<style>#chCast[hidden]{display:none!important}</style>");
      const _u = window.updateCinemaBar; window.updateCinemaBar = function(){ const r = _u.apply(this, arguments); try{ upd(); }catch(e){} return r; };
      setInterval(upd, 1500); upd();
    }
    /* a vista dupla só faz sentido no Explorar */
    const _sh = window.show; window.show = function(v){ if(on && v !== "tv" && v !== "guide"){ /* mantém */ } return _sh.apply(this, arguments); };
  })();

  /* ===== Picons: logótipos de canais em alta resolução (PT), guardados no aparelho ===== */
  (function(){
    const BASE = "https://cdn.jsdelivr.net/gh/tv-logo/tv-logos@main/countries/portugal/";
    const FB = new Map();            /* candidato -> próximo candidato / logótipo do fornecedor */
    let PIC = {}, MISS = {}, ready = false, dirty = 0, saveT = 0;
    const slug = n => String(n || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()
      .replace(/^[\s\W_]*(pt|portugal)\b[\s|:\-\/]*/i, "").replace(/\[[^\]]*\]|\([^)]*\)/g, " ")
      .replace(/\b(fhd|uhd|hd|sd|4k|8k|hevc|h265|raw)\b/g, " ")
      .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
    const ptc = c => c.kind === "live" && (isPtGroup(c.group) || /^[\s\W_]*(PT|PORTUGAL)\b/i.test(c.name || ""));
    const persist = () => { clearTimeout(saveT); saveT = setTimeout(() => { idle(() => { try{ IDB.set("picons", PIC); IDB.set("picons_miss", MISS); }catch(e){} }); }, 15000); };
    let lastSig = "";
    function patch(){
      if(!ready) return;
      const sig = channels.length + "|" + Object.keys(PIC).length + "|" + Object.keys(MISS).length;   /* nada mudou desde a última vez: não repete a passagem por todos os canais */
      if(sig === lastSig) return; lastSig = sig;
      try{
        for(const c of channels){
          if(!ptc(c)) continue;
          if(c.logo0 === undefined) c.logo0 = c.logo || "";
          const sl = slug(c.name); if(!sl || sl.length < 2) continue;
          const cand = [...new Set([sl + "-pt.png", sl.replace(/-(\d)/g, "$1") + "-pt.png", sl.replace(/^(canal|tv)-/, "").replace(/-(canal|tv)$/, "") + "-pt.png", sl + ".png"])].map(x => BASE + x);
          const hit = cand.find(u => PIC[u]);
          if(hit){ c.logo = PIC[hit]; continue; }                           /* já guardado no aparelho */
          const left = cand.filter(u => !MISS[u]);                           /* ignora os que já sabemos que não existem */
          if(!left.length){ c.logo = c.logo0; continue; }
          left.forEach((u, i) => FB.set(u, i + 1 < left.length ? left[i + 1] : c.logo0));
          c.logo = left[0];
        }
      }catch(e){}
    }
    /* Para outras listas (TV Direto): devolve o logótipo guardado no aparelho, ou o 1.º endereço a tentar (a cadeia de alternativas e a gravação local tratam do resto) */
    window.__piconFor = name => {
      try{
        const sl = slug(name); if(!sl || sl.length < 2) return "";
        const cand = [...new Set([sl + "-pt.png", sl.replace(/([a-z])(\d)/g, "$1-$2") + "-pt.png", sl.replace(/-(\d)/g, "$1") + "-pt.png", sl.replace(/^(canal|tv)-/, "").replace(/-(canal|tv)$/, "") + "-pt.png", sl + ".png"])].map(x => BASE + x);
        const hit = cand.find(u => PIC[u]); if(hit) return PIC[hit];
        const left = cand.filter(u => !MISS[u]); if(!left.length) return "";
        left.forEach((u, i) => FB.set(u, i + 1 < left.length ? left[i + 1] : ""));
        return left[0];
      }catch(e){ return ""; }
    };
    /* falhou: lembra-se para não voltar a pedir */
    document.addEventListener("error", ev => {
      const im = ev.target; if(!im || im.tagName !== "IMG" || !FB.has(im.src)) return;
      const bad = im.src; if(bad.indexOf(BASE) === 0){ MISS[bad] = 1; dirty++; persist(); }
      const o = FB.get(bad); ev.stopImmediatePropagation();
      if(o) im.src = o; else im.remove();
    }, true);
    /* carregou: guarda uma miniatura pequena (≈160 px) no aparelho, feita quando a TV está livre */
    const q = [];
    let busy = false;
    const idle = fn => (window.requestIdleCallback ? requestIdleCallback(fn, {timeout:4000}) : setTimeout(fn, 600));
    function pump(){
      if(busy || !q.length) return; busy = true;
      idle(async () => {
        const u = q.shift();
        try{
          if(!PIC[u] && Object.keys(PIC).length < 700){
            const r = await fetch(u, {cache:"force-cache"}); const blob = r.ok ? await r.blob() : null;
            if(blob && blob.size < 400000){
              const bm = await createImageBitmap(blob), k = Math.min(1, 160 / Math.max(bm.width, bm.height));
              const cv = document.createElement("canvas"); cv.width = Math.max(1, Math.round(bm.width * k)); cv.height = Math.max(1, Math.round(bm.height * k));
              cv.getContext("2d").drawImage(bm, 0, 0, cv.width, cv.height);
              const d = cv.toDataURL("image/webp", 0.85);
              if(d && d.length < 40000){ PIC[u] = d; dirty++; persist(); }
            }
          }
        }catch(e){}
        busy = false; setTimeout(pump, 250);
      });
    }
    document.addEventListener("load", ev => {
      const im = ev.target; if(!im || im.tagName !== "IMG" || !im.src || im.src.indexOf(BASE) !== 0 || PIC[im.src] || q.includes(im.src)) return;
      if(q.length < 200) q.push(im.src); pump();
    }, true);
    const _ai = window.afterIptv;
    if(typeof _ai === "function") window.afterIptv = function(){ patch(); return _ai.apply(this, arguments); };
    Promise.all([IDB.get("picons"), IDB.get("picons_miss")]).then(([a, m]) => { if(a && typeof a === "object") PIC = a; if(m && typeof m === "object") MISS = m; }).catch(() => {}).then(() => {
      ready = true; patch();
      try{ if(channels.length && currentView === "tvhome") window.show("tvhome"); }catch(e){}
    });
    document.head.insertAdjacentHTML("beforeend", "<style>.thArt img,.gch img,#tvList img{object-fit:contain!important}</style>");
  })();

  /* ===== Telemóvel: deteta ecrã estreito e ajusta o layout sozinho ===== */
  (function(){
    let tvd = false; try{ tvd = !!(Android.isTv && Android.isTv()); }catch(e){}
    const mq = window.matchMedia("(max-width: 900px)");
    /* telemóvel na horizontal: desenha como numa TV (1440 px lógicos) e reduz, para caberem muitos cartões e ícones normais */
    const apply = () => {
      const w = window.innerWidth, hh = window.innerHeight;
      const land = !tvd && w > hh && hh <= 560 && w >= 560;
      const ph = !tvd && !land && (mq.matches || w < 900);
      document.documentElement.style.setProperty("--ps", (w / 1440).toFixed(4));
      document.body.classList.toggle("pland", land);
      document.body.classList.toggle("phone", ph); document.documentElement.classList.toggle("phoneh", ph || land);
    };
    apply(); try{ mq.addEventListener("change", apply); }catch(e){ mq.addListener(apply); }
    window.addEventListener("resize", apply); window.addEventListener("orientationchange", () => setTimeout(apply, 200));
  })();

  /* ===== Botão «Colar» nos campos de texto das Definições (no comando/ecrã sem menu de colar) ===== */
  (function(){
    const sel = '#v-settings input:not([type=checkbox]):not([type=radio]):not([type=range]):not([type=button]):not([type=color]):not([type=file]), #v-settings textarea';
    const add = () => {
      document.querySelectorAll(sel).forEach(inp => {
        if(inp.dataset.pasteBtn) return; inp.dataset.pasteBtn = "1";
        const b = document.createElement("button"); b.type = "button"; b.className = "btn pasteBtn"; b.textContent = "📋 Colar"; b.style.cssText = "margin-left:8px;flex:none;white-space:nowrap";
        b.onclick = e => {
          e.preventDefault();
          let t = ""; try{ t = Android.clipGet() || ""; }catch(x){}
          if(!t){ try{ navigator.clipboard.readText().then(v => put(inp, v)); return; }catch(x){} try{ toast("Nada para colar. Copia o texto primeiro.", true); }catch(x){} return; }
          put(inp, t);
        };
        inp.insertAdjacentElement("afterend", b);
      });
    };
    const put = (inp, t) => {
      t = String(t || "").replace(/[\r\n]+/g, inp.tagName === "TEXTAREA" ? "\n" : " ").trim();
      if(!t){ try{ toast("Nada para colar. Copia o texto primeiro.", true); }catch(x){} return; }
      const proto = inp.tagName === "TEXTAREA" ? HTMLTextAreaElement.prototype : HTMLInputElement.prototype;
      const set = Object.getOwnPropertyDescriptor(proto, "value").set;
      set.call(inp, t);
      inp.dispatchEvent(new Event("input", {bubbles:true})); inp.dispatchEvent(new Event("change", {bubbles:true}));
      try{ inp.focus({preventScroll:true}); }catch(x){}
      try{ toast("Colado ✓"); }catch(x){}
    };
    const sec = document.getElementById("v-settings");
    if(sec){ new MutationObserver(add).observe(sec, {childList:true, subtree:true}); }
    add(); setInterval(add, 2500);
  })();

  /* ===== Arranque mais ágil na TV: adia o trabalho pesado que não é preciso para navegar ===== */
  (function(){
    const idle = (fn, ms) => { try{ if(window.requestIdleCallback){ requestIdleCallback(fn, {timeout:ms}); return; } }catch(e){} setTimeout(fn, Math.min(ms, 1500)); };
    const startup = () => performance.now() < 20000;
    /* lista de Explorar (renderTvList/fillGroups) só quando a TV está livre; no arranque o Início não precisa dela já */
    const _ai = window.afterIptv;
    if(typeof _ai === "function"){
      let tm = 0;
      window.afterIptv = function(msg){
        if(!startup() || currentView === "tv") return _ai.apply(this, arguments);
        try{ const st = document.getElementById("iptvStatus"); if(st) st.textContent = msg; }catch(e){}
        const self = this, args = arguments; clearTimeout(tm);
        tm = setTimeout(() => idle(() => { try{ _ai.apply(self, args); }catch(e){} }, 4000), 1200);
      };
    }
    /* a lista do Explorar só é desenhada quando o Explorar está visível (no arranque era desenhada 4 vezes sem se ver) */
    const _rtl = window.renderTvList;
    if(typeof _rtl === "function"){
      let dirty = false, want = false;
      window.renderTvList = function(){ if(currentView === "tv" || want || !startup()){ dirty = false; return _rtl.apply(this, arguments); } dirty = true; };
      const _s = window.show;
      window.show = function(v){
        want = (v === "tv");
        let r; try{ r = _s.apply(this, arguments); } finally { want = false; }
        if(v === "tv" && dirty){ dirty = false; try{ _rtl(); }catch(e){} }
        if(v === "settings" && window.__ctyPaint) setTimeout(() => { try{ window.__ctyPaint(); }catch(e){} }, 300);
        return r;
      };
    }
    /* guia XMLTV (DOMParser grande): depois de a app assentar */
    const _le = window.loadEpg;
    if(typeof _le === "function"){
      let led = 0;
      window.loadEpg = function(){ if(!startup()) return _le.apply(this, arguments); if(led) return; led = 1; const self = this, args = arguments; setTimeout(() => idle(() => { led = 0; try{ _le.apply(self, args); }catch(e){} }, 6000), 4000); };
    }
  })();

  /* ===== Envia ao ecrã nativo de canais o aspeto da barra global (cores, relógio, ícones), para ficar igual à da página ===== */
  (function(){
    if(typeof Android === "undefined" || typeof Android.nnav !== "function") return;
    const rgb = c => { c = String(c || "").trim(); let m = /^#([0-9a-f]{3})$/i.exec(c); if(m) return m[1].split("").map(x => parseInt(x + x, 16)); m = /^#([0-9a-f]{6})/i.exec(c); if(m) return [0, 2, 4].map(i => parseInt(m[1].substr(i, 2), 16)); m = /rgba?\((\d+)[ ,]+(\d+)[ ,]+(\d+)/.exec(c); return m ? [+m[1], +m[2], +m[3]] : [124, 196, 255]; };
    const hex = a => "#" + a.map(v => Math.max(0, Math.min(255, Math.round(v))).toString(16).padStart(2, "0")).join("");
    const mix = (acc, base, p) => { const a = rgb(acc), b = rgb(base); return hex(a.map((v, i) => v * p + b[i] * (1 - p))); };
    const png = (inner, color) => new Promise(res => {
      const st = window.__icSt ? window.__icSt() : {w:2, cap:"round", join:"round", duo:0};
      const css = st.duo ? '<style>:is(circle,rect,path[d$="z"]):not([fill]){fill:' + color + ';fill-opacity:.3}</style>' : (st.solid ? '<style>:is(circle,rect,path[d$="z"]):not([fill]){fill:' + color + '}</style>' : "");
      const svg = '<svg xmlns="http://www.w3.org/2000/svg" width="96" height="96" viewBox="0 0 24 24" color="' + color + '" fill="none" stroke="' + color + '" stroke-width="' + st.w + '" stroke-linecap="' + st.cap + '" stroke-linejoin="' + st.join + '">' + css + inner + '</svg>';
      const im = new Image(); im.onload = () => { try{ const c = document.createElement("canvas"); c.width = c.height = 96; c.getContext("2d").drawImage(im, 0, 0, 96, 96); res(c.toDataURL("image/png").split(",")[1]); }catch(e){ res(""); } }; im.onerror = () => res("");
      im.src = "data:image/svg+xml;charset=utf-8," + encodeURIComponent(svg);
    });
    let lastKey = "";
    async function sync(){
      try{
        const tb = document.querySelector(".top"), nav = document.querySelector(".thNav"); if(!tb || !nav) return;
        const tabs = [...nav.querySelectorAll(".thTab")].filter(b => b.offsetParent !== null && (b.dataset.th || b.id === "thCast" || b.id === "thMirror")); if(!tabs.length) return;
        const cs = getComputedStyle(document.body);
        const acc = cs.getPropertyValue("--accent").trim() || "#7cc4ff", ink = cs.getPropertyValue("--accent-ink").trim() || "#08121f";
        let sc = 1; try{ const si = JSON.parse(Android.screenInfo()); if(si && si.w && innerWidth) sc = si.w / innerWidth; }catch(e){}
        const phone = document.body.classList.contains("phone") && !document.body.classList.contains("pland");
        const r = tb.getBoundingClientRect(), tr = tb.offsetHeight ? r.height / tb.offsetHeight : 1;   /* escala da página (telemóvel na horizontal) */
        const ck = document.getElementById("clock");
        const out = {phone, sc: sc * tr, h: Math.round((phone ? 62 : r.height) * sc), fs: Math.round((parseFloat(getComputedStyle(tabs[0]).fontSize) || 18) * sc * tr), cfs: Math.round((ck ? parseFloat(getComputedStyle(ck).fontSize) : 26) * sc * tr), acc: hex(rgb(acc)), ink: hex(rgb(ink)), c1: mix(acc, "#0b1424", .30), c2: mix(acc, "#08101c", .14), bd: mix(acc, "#0b1424", .55), tabs: []};
        const P = v => Math.round(v * sc), rel = e => { const q = e.getBoundingClientRect(); return {x: P(q.left - r.left), y: P(q.top - r.top), w: P(q.width), h: P(q.height)}; };
        {
          out.geo = true; if(phone){ try{ const t0 = getComputedStyle(tabs[0]); out.tr = P(parseFloat(t0.borderTopLeftRadius) || 14); }catch(e){} } out.bx = P(r.left); out.by = P(r.top); out.bw = P(r.width); out.bh = P(r.height);
          try{ out.br = P(parseFloat(getComputedStyle(tb).borderTopLeftRadius) || 0); }catch(e){}
          if(!phone && ck && ck.offsetParent !== null) out.clk = rel(ck);
          const bs = document.getElementById("bStamp");
          if(!phone && bs && getComputedStyle(bs).display !== "none"){ const q = bs.getBoundingClientRect(); out.stamp = {text: bs.textContent || "", x: P(q.left), y: P(q.top), w: P(q.width), h: P(q.height), fs: Math.round(parseFloat(getComputedStyle(bs).fontSize) * sc)}; }
        }
        for(const b of tabs){
          const svg = b.querySelector("svg.ic"), inner = svg ? svg.innerHTML : "";
          const lab = [...b.childNodes].filter(n => n.nodeType === 3).map(n => n.textContent).join("").trim() || (b.textContent || "").trim();
          let lines = 1; try{ const rg = document.createRange(); const tn = [...b.childNodes].find(n => n.nodeType === 3 && n.textContent.trim()); if(tn){ rg.selectNodeContents(tn); lines = Math.max(1, rg.getClientRects().length); } }catch(e){}
          out.tabs.push(Object.assign({id: b.dataset.th || (b.id === "thCast" ? "cast" : "mirror"), label: (b.textContent || "").trim(), lines, icon: inner ? await png(inner, "#e6eef9") : "", iconA: inner ? await png(inner, hex(rgb(ink))) : ""}, rel(b)));
        }
        const key = JSON.stringify([window.__icSt ? window.__icSt().k : "1", out.phone, out.h, out.acc, out.tabs.map(t => t.id + t.label + t.x + "," + t.w), out.bx, out.by, out.bw]);
        if(key === lastKey) return; lastKey = key;
        Android.nnav(JSON.stringify(out));
      }catch(e){}
    }
    let lastIc = "";
    const IC_NAMES = ["skipprev","skipnext","rew","fwd","pp","full","exitfull","close","aspect","frames","sound","globe","phones","subs","guide","stats","list","search","play"];
    async function sendIcons(){
      try{
        if(typeof Android.nicons !== "function") return;
        const o = {}; if(!(window.__icSt && window.__icSt().emoji)) for(const n of IC_NAMES){ if(SV[n]) o[n] = await png(SV[n], "#ffffff"); }
        const j = JSON.stringify(o); if(j === lastIc) return; lastIc = j; Android.nicons(j);
      }catch(e){}
    }
    window.__sendIcons = sendIcons;
    window.__icRefresh = () => { icApply(); lastIc = ""; sendIcons(); sync(); };
    window.__navSync = sync;
    setTimeout(sendIcons, 2500);
    setTimeout(sync, 4500); setTimeout(sync, 12000);
    window.addEventListener("resize", () => { setTimeout(sync, 350); setTimeout(sync, 900); setTimeout(sync, 1800); });
    try{ screen.orientation.addEventListener("change", () => { setTimeout(sync, 500); setTimeout(sync, 1500); }); }catch(e){}
  })();

  /* ===== Formato da imagem (ajustar, zoom/panscan, esticar, 16:9, 4:3, 21:9) e ecrã total no telemóvel ===== */
  (function(){
    const ASP = [["fit", "Ajustar"], ["zoom", "Zoom / Panscan"], ["stretch", "Esticar"], ["16:9", "16:9"], ["4:3", "4:3"], ["21:9", "21:9 cinema"]];
    const kindNow = () => { try{ const c = lastPlayed[0] || (NAT && NAT.cur && NAT.cur.c); return (c && c.kind) || "live"; }catch(e){ return "live"; } };
    const getA = () => LS.get("tvAspect_" + kindNow(), "fit") || "fit";
    const labelOf = k => (ASP.find(a => a[0] === k) || ASP[0])[1];
    const applyWeb = () => {
      const mode = getA();
      document.querySelectorAll("#stage .slot").forEach(slot => {
        const v = slot.querySelector("video"); if(!v) return;
        const r = slot.getBoundingClientRect(), W = r.width, H = r.height;
        const ratio = {"16:9": 16 / 9, "4:3": 4 / 3, "21:9": 21 / 9}[mode];
        if(ratio && W > 0 && H > 0){
          let w = W, h = W / ratio; if(h > H){ h = H; w = H * ratio; }
          Object.assign(v.style, {position: "absolute", width: w + "px", height: h + "px", left: ((W - w) / 2) + "px", top: ((H - h) / 2) + "px"}); v.style.setProperty("object-fit", "fill", "important");
        } else {
          ["position", "width", "height", "left", "top"].forEach(k => { v.style[k] = ""; });
          v.style.setProperty("object-fit", mode === "zoom" ? "cover" : mode === "stretch" ? "fill" : "contain", "important");
        }
      });
    };
    const apply = (say) => {
      const mode = getA();
      try{ if(typeof Android.naspect === "function") Android.naspect(mode, labelOf(mode)); }catch(e){}
      applyWeb();
      const b = $("chAspect"); if(b) b.textContent = "▭ Formato: " + labelOf(mode);
      if(say){ try{ toast("Formato da imagem: " + labelOf(mode)); }catch(e){}
        try{ Android.nhud && Android.nhud("Formato: " + labelOf(mode)); setTimeout(() => { try{ Android.nhud(""); }catch(e){} }, 1500); }catch(e){} }
    };
    const cycle = () => { window.__aspSay = Date.now(); const i = ASP.findIndex(a => a[0] === getA()); LS.set("tvAspect_" + kindNow(), ASP[(i + 1) % ASP.length][0]); apply(true); };
    window.__aspect = {cycle, apply, get: getA};
    /* ecrã total (também no telemóvel, por toque) */
    const isFull = () => document.body.classList.contains("vfull");
    let wasCinema = false;
    const setFull = on => {
      const app = document.querySelector(".app");
      if(on){ wasCinema = app.classList.contains("cinema"); if(!wasCinema) setCinema(true); document.body.classList.add("vfull"); }
      else { document.body.classList.remove("vfull"); if(!wasCinema && app.classList.contains("cinema")) setCinema(false); }
      try{ Android.nfull && Android.nfull(isFull()); }catch(e){}
      setTimeout(() => { try{ NAT.sync(true); }catch(e){} applyWeb(); }, 80);
      const fb = $("chFull"); if(fb) fb.textContent = isFull() ? "✕ Sair do ecrã total" : "⛶ Ecrã total";
    };
    window.__setFull = setFull;
    const bar = $("chTracks") ? $("chTracks").parentNode : document.querySelector(".cinebar");
    if(bar){
      const mk = (id, t, fn) => { if($(id)) return; const b = document.createElement("button"); b.className = "btn"; b.id = id; b.textContent = t; b.onclick = fn; bar.appendChild(b); return b; };
      mk("chAspect", "▭ Formato: " + labelOf(getA()), cycle);
      mk("chFull", "⛶ Ecrã total", () => setFull(!isFull()));
    }
    new MutationObserver(() => { try{ Android.nfull && Android.nfull(isFull()); }catch(e){} const fb = $("chFull"); if(fb) fb.textContent = isFull() ? "✕ Sair do ecrã total" : "⛶ Ecrã total"; }).observe(document.body, {attributes:true, attributeFilter:["class"]});
    /* botões nativos sobre o vídeo */
    window.__aspSay = 0;
    const _n = window.__nev;
    window.__nev = (k, m) => { if(k === "aspect:info") return; if(k === "hdr:dv5"){ try{ toast("Dolby Vision perfil 5: este aparelho não consegue mostrar as cores corretamente. Escolhe outra versão do filme (HDR10 ou normal).", true); }catch(e){} return; }
      if(k === "ui" && false) return; if(k === "ui"){ if(m === "aspect"){ if(window.__pv && __pv.on && currentView === "tvhome") return; cycle(); } else if(m === "full"){ if(currentView === "tvhome"){ const hb = document.querySelector("#thHero .thBtn.pri[data-k]"); if(hb) hb.click(); return; } setFull(!isFull()); } return; } return _n && _n(k, m); };
    /* tecla vermelha do comando = mudar formato */
    document.addEventListener("keydown", e => { if(currentView === "tv" && (e.keyCode === 183 || e.key === "ColorF0Red")){ e.preventDefault(); cycle(); } }, true);
    /* botões flutuantes (leitor da página); o leitor nativo tem os seus próprios */
    document.head.insertAdjacentHTML("beforeend", "<style>#vfCtl{position:fixed;top:10px;right:10px;z-index:75;display:none;gap:8px}body.vfull #vfCtl.on{display:flex}#vfCtl button{background:#000c;color:#fff;border:0;border-radius:10px;padding:12px 16px;font:600 15px system-ui}body.vfull #bStamp{display:none}</style>");
    const fc = document.createElement("div"); fc.id = "vfCtl"; fc.innerHTML = '<button id="vfA">▭ Formato</button><button id="vfX">✕ Sair do ecrã total</button>'; document.body.appendChild(fc);
    let fcT = 0; const showFc = () => { fc.classList.add("on"); clearTimeout(fcT); fcT = setTimeout(() => fc.classList.remove("on"), 3500); };
    $("vfA").onclick = e => { e.stopPropagation(); cycle(); showFc(); }; $("vfX").onclick = e => { e.stopPropagation(); fc.classList.remove("on"); setFull(false); };
    document.addEventListener("click", e => { if(isFull() && e.target.closest && e.target.closest("#stage")) showFc(); }, true);
    new MutationObserver(() => { if(isFull()) showFc(); else fc.classList.remove("on"); }).observe(document.body, {attributes:true, attributeFilter:["class"]});
    /* duplo toque no vídeo (leitor da página) = ecrã total / sair */
    (function(){ let lt = 0; document.addEventListener("touchend", e => { const st = e.target.closest && e.target.closest("#stage"); if(!st || currentView !== "tv") return; const n = Date.now(); if(n - lt < 320){ lt = 0; e.preventDefault(); setFull(!isFull()); } else lt = n; }, {capture:true, passive:false}); })();
    window.addEventListener("resize", applyWeb); setInterval(applyWeb, 1500);
    /* cada vez que um canal/filme começa, aplica o formato guardado */
    const _pc = window.playChannel;
    if(typeof _pc === "function") window.playChannel = function(){ const r = _pc.apply(this, arguments); setTimeout(() => apply(false), 150); setTimeout(() => apply(false), 1200); return r; };
    applyWeb();
  })();

  /* ===== Guia no telemóvel (vertical): primeiro a lista de canais, depois a programação ===== */
  (function(){
    const dlg = $("gdDlg"), list = $("gdList"); if(!dlg || !list) return;
    document.head.insertAdjacentHTML("beforeend", "<style>" +
      "body.phone #gdDlg .gdbox{width:100vw!important;max-width:100vw!important;height:100%!important;max-height:100%!important;border-radius:0!important;padding:12px!important;box-sizing:border-box;gap:8px}" +
      "body.phone #gdDlg .gdgrid{display:flex!important;flex-direction:column;min-height:0;flex:1}" +
      "body.phone #gdDlg .gdside,body.phone #gdDlg .gdmain{flex:1;min-width:0;min-height:0;width:100%}" +
      "body.phone #gdDlg:not(.showd) .gdmain{display:none}body.phone #gdDlg.showd .gdside{display:none}" +
      "body.phone #gdDlg .gch{min-height:52px;font-size:15px}body.phone #gdDlg .gdbox h2{font-size:18px}" +
      "body.phone #gdDlg .gdhead{gap:6px}body.phone #gdDlg .gdhead .btn{padding:8px 12px;min-height:44px}" +
      "body.phone #gdDlg .gdbox input,body.phone #gdDlg .gdbox select{min-width:0;max-width:100%;box-sizing:border-box}" +
      "body.phone #gdDlg .gdbox{background:#0f1726!important}body.phone #gdDlg .gdbox>.row{flex-wrap:nowrap}body.phone #gdDlg .gdbox>.row .btn{min-height:44px}" +
      "body.phone #gdDlg .gdhead{flex-wrap:wrap!important}body.phone #gdDlg .gdname{flex:1 1 100%;order:-1;white-space:normal;font-size:17px}" +
      "body:has(.epgdlg:not([hidden])) #bStamp,body:has(.trkdlg:not([hidden])) #bStamp{display:none}body.phone #bStamp{font-size:10px;top:2px}" +
      "#gdBack{display:none}body.phone #gdBack{display:inline-flex}" +
      "body.phone #gdDlg .gdbox>.row:first-child{flex-wrap:nowrap;gap:8px}body.phone #gdDlg .gdbox>.row:first-child .spacer{display:none}" +
      "body.phone #gdDlg .gdbox h2{font-size:15px!important;letter-spacing:.02em;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0;flex:1}" +
      "body.phone #gdDlg:not(.showd) .gdside{display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);grid-template-rows:auto minmax(0,1fr);gap:6px;align-content:start}" +
      "body.phone #gdDlg .gdside .gdlist{grid-column:1/-1}" +
      "body.phone #gdDlg .gdbox select,body.phone #gdDlg .gdbox input{font-size:14px;min-height:42px}" +
      "body.phone #gdDlg .gch{min-height:50px;padding:5px 8px;gap:8px}body.phone #gdDlg .gch img,body.phone #gdDlg .gch .ph{width:34px;height:34px}" +
      "body.phone #gdDlg .gch .t b{font-size:14px}body.phone #gdDlg .gch .t span{font-size:12px}" +
      "body.phone #gdDlg .gdp{grid-template-columns:58px minmax(0,1fr);gap:2px 10px;padding:8px 10px}" +
      "body.phone #gdDlg .gdp .st{grid-column:2;flex-direction:row;flex-wrap:wrap;justify-content:flex-start;align-items:center;text-align:left}" +
      "body.phone #gdDlg .gdp .bar{grid-column:1 / 3}body.phone #gdDlg .gdp .mt b{font-size:14.5px}" +
      "body.phone #gdDlg #gdPro,body.phone #gdDlg #gdProgGo{padding:8px 12px}" +
      "</style>");
    try{ const pq = $("gdProgQ"); if(pq) pq.placeholder = "Procurar programa…"; }catch(e){}
    const head = dlg.querySelector(".gdhead");
    if(head && !$("gdBack")){ const b = document.createElement("button"); b.className = "btn"; b.id = "gdBack"; b.textContent = "☰ Canais"; b.onclick = () => dlg.classList.remove("showd"); head.insertBefore(b, head.firstChild); }
    list.addEventListener("click", e => { if(e.target.closest && e.target.closest(".gch")) setTimeout(() => dlg.classList.add("showd"), 0); }, true);
    const _og = window.openGuide; if(typeof _og === "function") window.openGuide = function(){ dlg.classList.remove("showd"); const r = _og.apply(this, arguments);
      try{ const tb = document.querySelector(".top"); if(tb && !document.body.classList.contains("phone")){ const bt = tb.offsetTop + tb.offsetHeight; if(bt > 0 && bt < 200) dlg.style.setProperty("top", bt + "px", "important"); } }catch(e){}   /* o Guia fica por baixo da barra de navegação */
      return r; };
    const gb = $("btnGuide"), cg = $("chGuide"); if(gb) gb.onclick = window.openGuide; if(cg) cg.onclick = window.openGuide;
  })();

  /* ===== Deslizar para os lados: muda de separador (Início, Explorar, Guia, Definições…) ===== */
  (function(){
    let sx = 0, sy = 0, st = 0, ok = false;
    const blocked = t => {
      if(document.querySelector(".epgdlg:not([hidden]),.trkdlg:not([hidden]),#exitDlg:not([hidden]),#orgDlg:not([hidden])")) return true;
      if(document.body.classList.contains("vfull") || document.fullscreenElement) return true;
      for(let e = t; e && e !== document.body; e = e.parentElement){
        if(/^(INPUT|TEXTAREA|SELECT|VIDEO)$/.test(e.tagName) || e.id === "stage" || (e.classList && e.classList.contains("stage"))) return true;
        const cs = getComputedStyle(e);
        if((cs.overflowX === "auto" || cs.overflowX === "scroll") && e.scrollWidth > e.clientWidth + 6) return true;
      }
      return false;
    };
    document.addEventListener("touchstart", e => {
      if(e.touches.length !== 1){ ok = false; return; }
      const t = e.touches[0]; sx = t.clientX; sy = t.clientY; st = Date.now(); ok = !blocked(e.target);
    }, {passive:true});
    document.addEventListener("touchend", e => {
      if(!ok) return; ok = false;
      const t = e.changedTouches[0], dx = t.clientX - sx, dy = t.clientY - sy;
      if(Date.now() - st > 700 || Math.abs(dx) < 80 || Math.abs(dx) < Math.abs(dy) * 2) return;
      const tabs = [...document.querySelectorAll(".thNav .thTab[data-th]")].filter(b => b.offsetParent !== null && b.dataset.th !== "guide");   /* o Guia abre uma janela, não é um ecrã */
      const i = tabs.findIndex(b => b.getAttribute("aria-current") === "page"); if(i < 0) return;
      const n = tabs[i + (dx < 0 ? 1 : -1)]; if(n) n.click();
    }, {passive:true});
  })();

  /* ===== Ecrã: só fica aceso a ver vídeo; sem toques nem teclas durante 30 s, o Android pode apagá-lo ===== */
  (function(){
    if(typeof Android.idleMs !== "function") return;
    const LIMIT = 30000;
    let want = true, dimmed = false;
    const playing = () => {
      try{ if(window.NATIVE && NATIVE.active){ const f = String(Android.npos()).split("|"); if(f.length < 4 || f[3] === "1") return true; } }catch(e){}
      try{ if(window.CAST && CAST.active) return true; }catch(e){}
      try{ return [...document.querySelectorAll("video")].some(v => !v.paused && !v.ended && v.readyState > 2); }catch(e){ return false; }
    };
    setInterval(() => {
      let idle = 0; try{ idle = +Android.idleMs(); }catch(e){}
      const keep = playing() || idle < LIMIT;
      if(keep !== want){ want = keep; try{ Android.keepAwake(keep); }catch(e){} }
      if(!keep !== dimmed){ dimmed = !keep; try{ Android.dim(dimmed); }catch(e){} }
    }, 2000);
  })();

  /* janela flutuante (PiP) só com um canal em visualização, não com a pré-visualização do Início */
  setInterval(() => { try{ if(typeof Android.setPipOk === "function") Android.setPipOk(currentView === "tv"); }catch(e){} }, 500);

  /* ecrã total preso: se se sair do leitor para outro ecrã, o ecrã total desliga-se */
  let fsBad = 0;
  setInterval(() => { try{ if(document.body.classList.contains("vfull") && currentView !== "tv" && window.__setFull && Date.now() > (window.__fsGrace || 0)){ if(++fsBad >= 3){ fsBad = 0; window.__setFull(false); } } else fsBad = 0; }catch(e){} }, 800);

  /* ===== Regresso à app: se o Android a reiniciou em segundo plano, volta ao canal/filme que estava a dar ===== */
  (function(){
    const K = "resumeState", MAXAGE = 12 * 3600 * 1000;
    let st = null; try{ if(typeof Android.takeExitFlag === "function" && Android.takeExitFlag()) LS.set(K, null); st = LS.get(K, null); }catch(e){}
    if(st && st.c && st.t && Date.now() - st.t < MAXAGE){
      let tries = 0;
      const go = () => {
        if(++tries > 40) return;
        if(typeof window.__watch !== "function" || typeof playChannel !== "function" || currentView === undefined){ setTimeout(go, 500); return; }
        try{
          if(st.c.kind === "live"){ window.__resumeFull = true; }
          if(!st.full){ /* estava no ecrã dividido: só retoma o canal */ }
          window.__watch(st.c);
          if(st.c.kind === "live" && !st.full){ setTimeout(() => { try{ window.__setFull && window.__setFull(false); }catch(e){} }, 900); }
        }catch(e){}
      };
      setTimeout(go, 1800);
    }
    /* grava o que está a dar; apaga ao sair do leitor */
    setTimeout(() => setInterval(() => {
      try{
        const c = lastPlayed && lastPlayed[0];
        if(currentView === "tv" && c) LS.set(K, {c: c, t: Date.now(), full: document.body.classList.contains("vfull")});
        else if(currentView !== "tv" && !(window.EXTP && EXTP.active)) LS.set(K, null);
      }catch(e){}
    }, 3000), 25000);
  })();

  /* picons: todas as imagens carregam só quando se aproximam do ecrã, em segundo plano e sem bloquear o arranque */
  (function(){
    const fix = im => { try{ if(im.tagName !== "IMG" || im.dataset.eager) return; if(!im.loading) im.loading = "lazy"; if(!im.decoding || im.decoding === "auto") im.decoding = "async"; if(!im.fetchPriority || im.fetchPriority === "auto") im.fetchPriority = "low"; }catch(e){} };
    try{
      document.querySelectorAll("img").forEach(fix);
      new MutationObserver(ms => { for(const m of ms) m.addedNodes.forEach(n => { if(n.nodeType !== 1) return; if(n.tagName === "IMG") fix(n); else if(n.querySelectorAll) n.querySelectorAll("img").forEach(fix); }); }).observe(document.body, {childList:true, subtree:true});
    }catch(e){}
  })();

  /* Cópia de segurança completa: além das listas/favoritos, leva as definições da app (países, retoma, recentes, combinações…) */
  (function(){
    try{
      const SKIP = /^ck_(tok_|oauth|mailAcct|cfg$|last$|navRecent|notes|parPin)/;
      const grab = () => { const o = {}; for(let i = 0; i < localStorage.length; i++){ const k = localStorage.key(i); if(k && k.indexOf("ck_") === 0 && !SKIP.test(k)) o[k] = localStorage.getItem(k); } return o; };
      const oe = orgExport, oi = orgImport;
      orgExport = function(w){ const o = oe.apply(this, arguments); o.ls = grab(); o.v = 2; return o; };
      orgImport = function(t){
        const r = oi.apply(this, arguments);
        try{ const o = JSON.parse(String(t).trim()); if(o && o.ls && typeof o.ls === "object"){ let n = 0; Object.keys(o.ls).forEach(k => { if(k.indexOf("ck_") === 0 && !SKIP.test(k) && typeof o.ls[k] === "string"){ try{ localStorage.setItem(k, o.ls[k]); n++; }catch(e){} } }); r.settings = n; if(n) setTimeout(() => { try{ location.reload(); }catch(e){} }, 1200); } }catch(e){}
        return r;
      };
    }catch(e){}
  })();

  /* pesquisa por voz vinda do assistente (abriu a app com «procura X») */
  try{ const pv = Android.pendingVoice && Android.pendingVoice(); if(pv && window.__voiceDone) setTimeout(() => window.__voiceDone(pv), 3000); }catch(e){}

  syncNav();
  if(currentView === "tvhome") window.show("tvhome");
})();
</script>
'''

import json as _json
sys.path.insert(0, os.path.dirname(__file__))
from i18n_extra import P as _P
JS3 = "<script>(function(){ try{ const P = " + _json.dumps(_P, ensure_ascii=False).replace("</", "<\\/") + "; P.forEach(r => { I18N.en[r[0]] = r[1]; I18N.fr[r[0]] = r[2]; }); if(uiLang() !== 'pt') applyLang(); }catch(e){ console.log('i18n extra', e); } })();</script>\n"
i = h.rfind("</body>")
h = h[:i] + JS + JS2 + JS3 + h[i:]
os.makedirs(os.path.dirname(out), exist_ok=True)
import time
h = h.replace("__BUILD__", time.strftime("%d/%m %H:%M"))
open(out, "w", encoding="utf-8").write(h)
print("OK ->", os.path.normpath(out), len(h)//1024, "KB")
