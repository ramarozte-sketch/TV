from PIL import Image, ImageDraw
import os
R="app/src/main/res"
def icon(sz):
    im=Image.new("RGBA",(sz,sz),(0,0,0,0)); d=ImageDraw.Draw(im)
    d.rounded_rectangle([0,0,sz-1,sz-1],radius=sz*0.22,fill=(8,14,20,255))
    m=sz*0.18
    d.rounded_rectangle([m,sz*0.26,sz-m,sz*0.70],radius=sz*0.06,outline=(62,198,255,255),width=max(2,int(sz*0.045)))
    cx,cy=sz/2,sz*0.48
    d.polygon([(cx-sz*0.07,cy-sz*0.10),(cx-sz*0.07,cy+sz*0.10),(cx+sz*0.10,cy)],fill=(62,198,255,255))
    d.line([(sz*0.36,sz*0.78),(sz*0.64,sz*0.78)],fill=(62,198,255,255),width=max(2,int(sz*0.04)))
    return im
for n,s in [("mdpi",48),("hdpi",72),("xhdpi",96),("xxhdpi",144),("xxxhdpi",192)]:
    os.makedirs(f"{R}/mipmap-{n}",exist_ok=True); icon(s).save(f"{R}/mipmap-{n}/ic_launcher.png")
os.makedirs(f"{R}/drawable",exist_ok=True)
b=Image.new("RGBA",(320,180),(8,14,20,255)); i=icon(120); b.paste(i,(30,30),i)
d=ImageDraw.Draw(b); d.text((170,70),"COCKPIT TV",fill=(62,198,255,255)); b.save(f"{R}/drawable/banner.png")
