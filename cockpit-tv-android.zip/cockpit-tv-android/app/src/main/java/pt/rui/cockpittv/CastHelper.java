package pt.rui.cockpittv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.widget.ArrayAdapter;

import androidx.mediarouter.media.MediaControlIntent;
import androidx.mediarouter.media.MediaRouteSelector;
import androidx.mediarouter.media.MediaRouter;

import com.google.android.gms.cast.CastMediaControlIntent;
import com.google.android.gms.cast.MediaInfo;
import com.google.android.gms.cast.MediaLoadRequestData;
import com.google.android.gms.cast.MediaMetadata;
import com.google.android.gms.cast.framework.CastContext;
import com.google.android.gms.cast.framework.CastSession;
import com.google.android.gms.cast.framework.SessionManager;
import com.google.android.gms.cast.framework.SessionManagerListener;
import com.google.android.gms.cast.framework.media.RemoteMediaClient;

import java.util.ArrayList;
import java.util.List;

/**
 * Envia o endereço do vídeo (canal, filme, episódio) para uma Google TV / Chromecast.
 * Não usa o MediaRouteButton: mostra a lista de TVs num diálogo simples, sem depender do tema da app.
 */
class CastHelper {
    interface Listener { void onEvent(String kind, String msg); }

    private final Activity act;
    private final Listener listener;
    private CastContext ctx;
    private MediaRouter router;
    private MediaRouteSelector selector;
    private AlertDialog dialog;
    private ArrayAdapter<String> adapter;
    private final List<MediaRouter.RouteInfo> routes = new ArrayList<>();
    private boolean discovering = false;

    private final MediaRouter.Callback routeCb = new MediaRouter.Callback() {
        @Override public void onRouteAdded(MediaRouter r, MediaRouter.RouteInfo i) { refresh(); }
        @Override public void onRouteRemoved(MediaRouter r, MediaRouter.RouteInfo i) { refresh(); }
        @Override public void onRouteChanged(MediaRouter r, MediaRouter.RouteInfo i) { refresh(); }
    };

    private final SessionManagerListener<CastSession> sessionCb = new SessionManagerListener<CastSession>() {
        @Override public void onSessionStarting(CastSession s) { }
        @Override public void onSessionStarted(CastSession s, String id) { connected(s); }
        @Override public void onSessionStartFailed(CastSession s, int e) { listener.onEvent("failed", String.valueOf(e)); }
        @Override public void onSessionEnding(CastSession s) { }
        @Override public void onSessionEnded(CastSession s, int e) { listener.onEvent("ended", ""); }
        @Override public void onSessionResuming(CastSession s, String id) { }
        @Override public void onSessionResumed(CastSession s, boolean w) { connected(s); }
        @Override public void onSessionResumeFailed(CastSession s, int e) { }
        @Override public void onSessionSuspended(CastSession s, int e) { }
    };

    CastHelper(Activity act, Listener l) {
        this.act = act;
        this.listener = l;
    }

    private boolean init() {
        if (ctx != null) return true;
        try {
            ctx = CastContext.getSharedInstance(act);
            router = MediaRouter.getInstance(act);
            selector = new MediaRouteSelector.Builder()
                    .addControlCategory(CastMediaControlIntent.categoryForCast(CastMediaControlIntent.DEFAULT_MEDIA_RECEIVER_APPLICATION_ID))
                    .build();
            ctx.getSessionManager().addSessionManagerListener(sessionCb, CastSession.class);
            return true;
        } catch (Throwable e) {
            ctx = null;
            listener.onEvent("unavailable", String.valueOf(e));
            return false;
        }
    }

    private void connected(CastSession s) {
        String name = "";
        try { name = s.getCastDevice() != null ? s.getCastDevice().getFriendlyName() : ""; } catch (Exception ignored) { }
        listener.onEvent("connected", name);
    }

    private void refresh() {
        if (router == null) return;
        routes.clear();
        for (MediaRouter.RouteInfo r : router.getRoutes()) {
            if (!r.isDefaultOrBluetooth() && r.matchesSelector(selector)) routes.add(r);
        }
        if (adapter != null) {
            adapter.clear();
            for (MediaRouter.RouteInfo r : routes) adapter.add(r.getName());
            adapter.notifyDataSetChanged();
        }
    }

    /** Abre a lista de TVs (Google TV / Chromecast) na rede Wi-Fi. */
    void pick() {
        if (!init()) return;
        if (!discovering) {
            router.addCallback(selector, routeCb, MediaRouter.CALLBACK_FLAG_REQUEST_DISCOVERY | MediaRouter.CALLBACK_FLAG_PERFORM_ACTIVE_SCAN);
            discovering = true;
        }
        adapter = new ArrayAdapter<>(act, android.R.layout.simple_list_item_1, new ArrayList<String>());
        refresh();
        AlertDialog.Builder b = new AlertDialog.Builder(act)
                .setTitle("Transmitir para…")
                .setAdapter(adapter, new DialogInterface.OnClickListener() {
                    @Override public void onClick(DialogInterface d, int which) {
                        if (which >= 0 && which < routes.size()) router.selectRoute(routes.get(which));
                    }
                })
                .setNegativeButton("Fechar", null);
        if (ctx.getSessionManager().getCurrentCastSession() != null) {
            b.setNeutralButton("Parar transmissão", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface d, int w) { stop(); }
            });
        }
        if (dialog != null) { try { dialog.dismiss(); } catch (Exception ignored) { } }
        dialog = b.create();
        dialog.setOnDismissListener(new DialogInterface.OnDismissListener() {
            @Override public void onDismiss(DialogInterface d) { adapter = null; }
        });
        dialog.show();
    }

    void load(String url, String title, String mime, boolean live, long startMs) {
        if (ctx == null) return;
        CastSession s = ctx.getSessionManager().getCurrentCastSession();
        if (s == null) { listener.onEvent("error", "sem sessão"); return; }
        RemoteMediaClient c = s.getRemoteMediaClient();
        if (c == null) { listener.onEvent("error", "sem cliente"); return; }
        MediaMetadata md = new MediaMetadata(MediaMetadata.MEDIA_TYPE_MOVIE);
        md.putString(MediaMetadata.KEY_TITLE, title == null ? "" : title);
        MediaInfo mi = new MediaInfo.Builder(url)
                .setStreamType(live ? MediaInfo.STREAM_TYPE_LIVE : MediaInfo.STREAM_TYPE_BUFFERED)
                .setContentType(mime == null || mime.isEmpty() ? "video/mp4" : mime)
                .setMetadata(md)
                .build();
        MediaLoadRequestData.Builder rb = new MediaLoadRequestData.Builder().setMediaInfo(mi).setAutoplay(true);
        if (startMs > 0) rb.setCurrentTime(startMs);
        c.load(rb.build());
    }

    void toggle() {
        if (ctx == null) return;
        CastSession s = ctx.getSessionManager().getCurrentCastSession();
        if (s == null || s.getRemoteMediaClient() == null) return;
        RemoteMediaClient c = s.getRemoteMediaClient();
        if (c.isPlaying()) c.pause(); else c.play();
    }

    void stopMedia() {
        if (ctx == null) return;
        CastSession s = ctx.getSessionManager().getCurrentCastSession();
        if (s != null && s.getRemoteMediaClient() != null) s.getRemoteMediaClient().stop();
    }

    void stop() {
        if (ctx == null) return;
        try { ctx.getSessionManager().endCurrentSession(true); } catch (Exception ignored) { }
    }

    boolean active() {
        return ctx != null && ctx.getSessionManager().getCurrentCastSession() != null;
    }

    void release() {
        try {
            if (router != null && discovering) router.removeCallback(routeCb);
            if (ctx != null) ctx.getSessionManager().removeSessionManagerListener(sessionCb, CastSession.class);
        } catch (Exception ignored) { }
        discovering = false;
    }
}
