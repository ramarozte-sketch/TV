package pt.rui.cockpittv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Cockpit TV nativo (v271): a única app. Canais, filmes, séries (fichas, temporadas, continuar a ver, vistos),
 * favoritos, pesquisa, legendas online, transmitir (Chromecast), «Continuar a ver» no ecrã inicial da TV e definições.
 * A reprodução usa o NativePlayer e o ecrã de canal NativeScreen.
 */
public class NativeHomeActivity extends Activity {
    private static final int BG = 0xFF0B0F14, PANEL = 0xFF121922, CARD = 0xFF18212C, ACC = 0xFF3EA6FF, TXT = 0xFFE8EEF4, MUT = 0xFF8A9AAA, OK = 0xFF5CD68A;
    private static final String[] TAB_ID = {"live", "movie", "series", "fav", "recent", "search", "settings"};
    private static final String[] TAB_L = {"📺 Canais", "🎬 Filmes", "🎞️ Séries", "★ Favoritos", "🕘 Vistos", "🔍 Pesquisar", "⚙️ Definições"};

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newFixedThreadPool(3);
    private final ExecutorService img = Executors.newFixedThreadPool(6);
    private final LruCache<String, Bitmap> bmp = new LruCache<String, Bitmap>(28 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };

    private NativeData data;
    private FrameLayout root;
    private LinearLayout body;
    private final TextView[] tabs = new TextView[TAB_ID.length];
    private ListView catList;
    private GridView grid;
    private TextView status, sortBtn;
    private ProgressBar spin;
    private EditText searchBox;
    private View settingsView;
    private FrameLayout details;

    private String tab = "live";
    private List<NativeData.Cat> curCats = new ArrayList<>();
    private int curCat = 0;
    private String shownKey = "";
    private List<NativeData.Item> curItems = new ArrayList<>();
    /** série aberta (temporadas na coluna, episódios na grelha); null fora das séries */
    private NativeData.Item openSeries = null;
    private List<NativeData.Item> seriesEps = new ArrayList<>();
    private int seriesCatBefore = 0, seriesPosBefore = 0;
    private int loadSeq = 0;

    private NativePlayer np;
    private NativeScreen nscr;
    private CastHelper cast;
    private boolean castWanted = false;
    private List<NativeData.Item> playing = new ArrayList<>();
    private NativeData.Item nowItem = null;
    private List<String[]> osRes = new ArrayList<>();
    private String pendingOpen = null, pendingQuery = null;

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override
    protected void attachBaseContext(android.content.Context base) {
        try {
            float sc = MainActivity.uiScaleOf(base);
            if (Math.abs(sc - 1f) > 0.01f) {
                android.content.res.Configuration cfg = new android.content.res.Configuration(base.getResources().getConfiguration());
                cfg.densityDpi = Math.round(cfg.densityDpi * sc);
                super.attachBaseContext(base.createConfigurationContext(cfg));
                return;
            }
        } catch (Throwable ignored) { }
        super.attachBaseContext(base);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        overridePendingTransition(0, 0);   /* abre direto, sem animação */
        PiconCache.init(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        data = new NativeData(this);
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root);
        buildUi();
        readIntent(getIntent());
        if (!data.configured()) {
            /* primeira vez: tenta trazer a lista, os favoritos e os vistos da app antiga (estão guardados no aparelho) */
            setStatus("A procurar os dados da app antiga…", true);
            importOld(ok -> showTab(ok ? "live" : "settings"));
            return;
        }
        String last = getSharedPreferences("nativeapp", 0).getString("tab", "live");
        if (pendingQuery != null) last = "search";
        else if (last.equals("settings") || last.equals("search")) last = "live";
        showTab(last);
        afterStart();
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        readIntent(i);
        if (pendingQuery != null) { showTab("search"); }
        afterStart();
    }

    /** cockpittv://play?id=<endereço> (Continuar a ver do ecrã inicial) e pesquisa por voz. */
    private void readIntent(Intent intent) {
        try {
            if (intent == null) return;
            String a = intent.getAction();
            if (a != null && (a.equals(Intent.ACTION_SEARCH) || a.equals("com.google.android.gms.actions.SEARCH_ACTION"))) {
                String q = intent.getStringExtra("query");
                if (q == null || q.isEmpty()) q = intent.getStringExtra(android.app.SearchManager.QUERY);
                if (q != null && !q.trim().isEmpty()) pendingQuery = q.trim();
                return;
            }
            Uri d = intent.getData();
            if (d != null && "cockpittv".equals(d.getScheme())) pendingOpen = d.getQueryParameter("id");
        } catch (Throwable ignored) { }
    }

    private void afterStart() {
        if (pendingQuery != null && searchBox != null) { searchBox.setText(pendingQuery); pendingQuery = null; }
        final String id = pendingOpen; pendingOpen = null;
        if (id == null || id.isEmpty()) return;
        ensureAllLoaded(() -> {
            NativeData.Item it = data.findByUrl(id);
            if (it == null) { Toast.makeText(this, "Já não encontro esse vídeo na lista.", Toast.LENGTH_LONG).show(); return; }
            if ("episode".equals(it.kind) && it.sid.length() > 0) playEpisode(it.sid, it.url);
            else { List<NativeData.Item> one = new ArrayList<>(); one.add(it); play(one, 0, -1); }
        });
    }

    /* ------------------------------------------------------------ importar da app antiga (sem a abrir) */
    private interface Done { void run(boolean ok); }
    private void importOld(final Done done) {
        if (data.importFromWeb()) { done.run(true); return; }   /* a v270 clássica já tinha partilhado os dados */
        final boolean[] fin = {false};
        final Runnable timeout = () -> { if (!fin[0]) { fin[0] = true; done.run(false); } };
        try {
            final WebView w = new WebView(this);
            w.getSettings().setJavaScriptEnabled(true);
            w.getSettings().setDomStorageEnabled(true);
            w.getSettings().setAllowFileAccess(true);
            w.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView v, String u) {
                    v.evaluateJavascript("(function(){try{return JSON.stringify({c:localStorage.getItem('ck_cfg')||'',f:localStorage.getItem('ck_tvfavs')||'[]',r:localStorage.getItem('ck_tvRecent')||'[]'})}catch(e){return ''}})()", val -> {
                        boolean ok = false;
                        try {
                            if (val != null && val.length() > 4 && !"null".equals(val)) {
                                JSONObject o = new JSONObject(new JSONArray("[" + val + "]").getString(0));
                                ok = data.importJson(o.optString("c"), o.optString("f", "[]"), o.optString("r", "[]"));
                            }
                        } catch (Throwable ignored) { }
                        try { w.destroy(); } catch (Throwable ignored) { }
                        if (!fin[0]) { fin[0] = true; ui.removeCallbacks(timeout); done.run(ok); }
                    });
                }
            });
            /* a página antiga corria em file:///android_asset/: o mesmo endereço base dá acesso ao que ela guardou */
            w.loadDataWithBaseURL("file:///android_asset/index.html", "<html><body></body></html>", "text/html", "utf-8", null);
            ui.postDelayed(timeout, 8000);
        } catch (Throwable e) { timeout.run(); }
    }

    /* ------------------------------------------------------------ interface */
    private StateListDrawable sel(int base, int radius) {
        StateListDrawable s = new StateListDrawable();
        GradientDrawable f = new GradientDrawable(); f.setColor(0xFF22364A); f.setStroke(dp(2), ACC); f.setCornerRadius(dp(radius));
        GradientDrawable p = new GradientDrawable(); p.setColor(0xFF1E3044); p.setCornerRadius(dp(radius));
        GradientDrawable n = new GradientDrawable(); n.setColor(base); n.setCornerRadius(dp(radius));
        s.addState(new int[]{android.R.attr.state_focused}, f);
        s.addState(new int[]{android.R.attr.state_selected}, f);
        s.addState(new int[]{android.R.attr.state_pressed}, p);
        s.addState(new int[]{}, n);
        return s;
    }
    private GradientDrawable roundRect(int c, int r) { GradientDrawable g = new GradientDrawable(); g.setColor(c); g.setCornerRadius(dp(r)); return g; }

    private void buildUi() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout bar = new LinearLayout(this);
        bar.setPadding(dp(10), dp(8), dp(10), dp(6));
        for (int i = 0; i < TAB_ID.length; i++) {
            final String id = TAB_ID[i];
            TextView t = new TextView(this);
            t.setText(TAB_L[i]); t.setTextColor(TXT); t.setTextSize(15); t.setGravity(Gravity.CENTER);
            t.setPadding(dp(16), dp(9), dp(16), dp(9));
            t.setBackground(sel(0x00000000, 20));
            t.setFocusable(true); t.setClickable(true);
            t.setOnClickListener(v -> showTab(id));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dp(6);
            bar.addView(t, lp);
            tabs[i] = t;
        }
        hs.addView(bar);
        col.addView(hs, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout st = new LinearLayout(this);
        st.setGravity(Gravity.CENTER_VERTICAL);
        st.setPadding(dp(16), 0, dp(12), dp(4));
        spin = new ProgressBar(this); spin.setIndeterminate(true); spin.setVisibility(View.GONE);
        st.addView(spin, new LinearLayout.LayoutParams(dp(18), dp(18)));
        status = new TextView(this); status.setTextColor(MUT); status.setTextSize(12.5f); status.setPadding(dp(8), 0, 0, 0);
        status.setSingleLine(true); status.setEllipsize(TextUtils.TruncateAt.END);
        st.addView(status, new LinearLayout.LayoutParams(0, -2, 1));
        sortBtn = new TextView(this);
        sortBtn.setTextColor(TXT); sortBtn.setTextSize(13); sortBtn.setPadding(dp(12), dp(5), dp(12), dp(5));
        sortBtn.setBackground(sel(CARD, 14)); sortBtn.setFocusable(true); sortBtn.setClickable(true);
        sortBtn.setOnClickListener(v -> pickSort());
        sortBtn.setVisibility(View.GONE);
        st.addView(sortBtn, new LinearLayout.LayoutParams(-2, -2));
        col.addView(st, new LinearLayout.LayoutParams(-1, -2));

        searchBox = new EditText(this);
        searchBox.setHint("Nome do canal, filme ou série…"); searchBox.setHintTextColor(MUT); searchBox.setTextColor(TXT);
        searchBox.setSingleLine(true); searchBox.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchBox.setBackground(sel(CARD, 10)); searchBox.setPadding(dp(14), dp(10), dp(14), dp(10));
        searchBox.setVisibility(View.GONE);
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) { ui.removeCallbacks(doSearch); ui.postDelayed(doSearch, 350); }
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2); slp.setMargins(dp(14), dp(2), dp(14), dp(8));
        col.addView(searchBox, slp);

        body = new LinearLayout(this);
        col.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));

        catList = new ListView(this);
        catList.setDivider(null); catList.setSelector(sel(0x00000000, 10)); catList.setDrawSelectorOnTop(false);
        catList.setBackgroundColor(PANEL); catList.setPadding(dp(6), dp(6), dp(6), dp(6)); catList.setClipToPadding(false);
        catList.setAdapter(catAdapter);
        catList.setOnItemClickListener((p, v, pos, id) -> pickCat(pos, true));
        catList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                /* comando da TV: percorrer as categorias já mostra os itens (com um pequeno atraso para não pesar) */
                final int ps = pos; ui.removeCallbacks(catSelRun); catSelRun = () -> pickCat(ps, false); ui.postDelayed(catSelRun, 220);
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
        body.addView(catList, new LinearLayout.LayoutParams(dp(250), -1));

        grid = new GridView(this);
        grid.setSelector(sel(0x00000000, 10)); grid.setDrawSelectorOnTop(false);
        grid.setPadding(dp(10), dp(6), dp(10), dp(10)); grid.setClipToPadding(false);
        grid.setVerticalSpacing(dp(8)); grid.setHorizontalSpacing(dp(8));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setLayoutAnimation(null);
        grid.setAdapter(gridAdapter);
        grid.setOnItemClickListener((p, v, pos, id) -> onItem(pos));
        grid.setOnItemLongClickListener((p, v, pos, id) -> { itemMenu(pos); return true; });
        body.addView(grid, new LinearLayout.LayoutParams(0, -1, 1));
    }

    private Runnable catSelRun = () -> { };
    private final Runnable doSearch = () -> runSearch();

    private void setStatus(String s, boolean busy) { status.setText(s); spin.setVisibility(busy ? View.VISIBLE : View.GONE); }

    private void markTabs() {
        for (int i = 0; i < TAB_ID.length; i++) {
            boolean on = TAB_ID[i].equals(tab);
            tabs[i].setTextColor(on ? ACC : TXT);
            tabs[i].setTypeface(null, on ? Typeface.BOLD : Typeface.NORMAL);
        }
    }

    private boolean vodTab() { return "movie".equals(tab) || "series".equals(tab); }
    private void updateSortBtn() {
        boolean on = vodTab() && openSeries == null && catList.getVisibility() == View.VISIBLE;
        sortBtn.setVisibility(on ? View.VISIBLE : View.GONE);
        if (on) sortBtn.setText("⇅ " + NativeData.SORT_L[data.sortMode(tab)]);
    }
    private void pickSort() {
        if (!vodTab()) return;
        final String k = tab;
        new AlertDialog.Builder(this).setTitle("Ordenar").setSingleChoiceItems(NativeData.SORT_L, data.sortMode(k), (d, w) -> {
            d.dismiss();
            data.setSortMode(k, w);
            updateSortBtn();
            shownKey = "";
            pickCat(curCat, false);
            grid.setSelection(0);
        }).show();
    }

    /* ------------------------------------------------------------ separadores */
    private void showTab(String id) {
        closeDetails();
        tab = id;
        openSeries = null;
        loadSeq++;
        getSharedPreferences("nativeapp", 0).edit().putString("tab", id).apply();
        markTabs();
        if (settingsView != null) { body.removeView(settingsView); settingsView = null; }
        catList.setVisibility(View.VISIBLE); grid.setVisibility(View.VISIBLE);
        searchBox.setVisibility(View.GONE);
        curCats = new ArrayList<>(); curItems = new ArrayList<>(); shownKey = "";
        catAdapter.notifyDataSetChanged(); gridAdapter.notifyDataSetChanged();
        switch (id) {
            case "live": case "movie": case "series": loadKind(id, false); break;
            case "fav": case "recent": showFlat(id); break;
            case "search":
                catList.setVisibility(View.GONE);
                searchBox.setVisibility(View.VISIBLE);
                searchBox.requestFocus();
                ensureAllLoaded(() -> runSearch());
                break;
            case "settings": showSettings(); break;
        }
        updateSortBtn();
    }

    /** Categorias do tipo, com «Continuar a ver» e «Adicionados recentemente» no topo (filmes e séries). */
    private List<NativeData.Cat> withVirtual(String kind) {
        List<NativeData.Cat> out = new ArrayList<>();
        List<NativeData.Cat> base = data.cats.get(kind);
        if (!"live".equals(kind)) {
            List<NativeData.Item> cont = "movie".equals(kind) ? data.continueMovies() : data.continueSeries();
            if (!cont.isEmpty()) { NativeData.Cat c = new NativeData.Cat(); c.id = "__cont"; c.name = "▶ Continuar a ver"; c.items.addAll(cont); out.add(c); }
            List<NativeData.Item> allk = data.all.get(kind);
            boolean has = false;
            if (allk != null) for (NativeData.Item x : allk) if (x.added > 0) { has = true; break; }
            if (has) {
                List<NativeData.Item> s = NativeData.sorted(allk, 2);
                NativeData.Cat c = new NativeData.Cat(); c.id = "__new"; c.name = "🆕 Adicionados recentemente"; c.items.addAll(s.subList(0, Math.min(200, s.size()))); out.add(c);
            }
        }
        if (base != null) out.addAll(base);
        return out;
    }

    private int savedCatIndex(String kind) {
        String name = getSharedPreferences("nativeapp", 0).getString("catn_" + kind, "");
        for (int i = 0; i < curCats.size(); i++) if (curCats.get(i).name.equals(name)) return i;
        return "live".equals(kind) ? 0 : Math.min(curCats.size() - 1, 0);
    }

    private void loadKind(final String kind, final boolean force) {
        if (!data.configured()) { setStatus("Sem lista configurada — abre ⚙️ Definições.", false); return; }
        final int seq = ++loadSeq;
        setStatus(force ? "A atualizar a lista…" : "A carregar…", true);
        bg.execute(() -> {
            String err = null;
            try { data.load(kind, force); } catch (Throwable e) { err = e.getMessage() == null ? String.valueOf(e) : e.getMessage(); }
            final String fe = err;
            ui.post(() -> {
                if (seq != loadSeq || !kind.equals(tab) || openSeries != null) return;
                if (fe != null) { setStatus("Erro: " + fe, false); return; }
                curCats = withVirtual(kind);
                catAdapter.notifyDataSetChanged();
                shownKey = "";
                int ci = Math.max(0, savedCatIndex(kind));
                pickCat(ci, false);
                catList.setSelection(curCat);
                int n = 0; List<NativeData.Item> al = data.all.get(kind); if (al != null) n = al.size();
                setStatus(n + (kind.equals("live") ? " canais" : kind.equals("movie") ? " filmes" : " séries") + "   ·   OK longo / Menu: opções", false);
                updateSortBtn();
                if (!data.cacheFresh(kind) && !force) loadKind(kind, true);   /* lista guardada antiga: mostra-a e renova por trás */
            });
        });
    }

    /** Depois de ver algo: atualiza «Continuar a ver» mantendo a categoria aberta. */
    private void refreshCats() {
        if (!vodTab() || openSeries != null || data.cats.get(tab) == null) return;
        String name = curCat < curCats.size() ? curCats.get(curCat).name : "";
        int keep = grid.getFirstVisiblePosition();
        curCats = withVirtual(tab);
        catAdapter.notifyDataSetChanged();
        int ci = 0; for (int i = 0; i < curCats.size(); i++) if (curCats.get(i).name.equals(name)) { ci = i; break; }
        shownKey = "";
        pickCat(ci, false);
        grid.setSelection(keep);
    }

    private void ensureAllLoaded(final Runnable after) {
        if (!data.configured()) return;
        setStatus("A preparar…", true);
        final int seq = loadSeq;
        bg.execute(() -> {
            for (String k : new String[]{"live", "movie", "series"}) { try { data.load(k, false); } catch (Throwable ignored) { } }
            ui.post(() -> { if (seq == loadSeq) setStatus("", false); after.run(); });
        });
    }

    private void showFlat(final String id) {
        catList.setVisibility(View.GONE);
        if ("recent".equals(id)) {
            curItems = data.recents();
            gridAdapter.notifyDataSetChanged(); setColumns(); grid.setSelection(0);
            setStatus(curItems.isEmpty() ? "Ainda não viste nada." : curItems.size() + " vistos recentemente", false);
            return;
        }
        ensureAllLoaded(() -> {
            if (!"fav".equals(tab)) return;
            curItems = data.favItems();
            gridAdapter.notifyDataSetChanged(); setColumns(); grid.setSelection(0);
            setStatus(curItems.isEmpty() ? "Sem favoritos. Mantém OK (ou Menu) num canal, filme ou série para o marcar." : curItems.size() + " favoritos", false);
        });
    }

    private void runSearch() {
        if (!"search".equals(tab)) return;
        String q = searchBox.getText().toString();
        curItems = data.search(q);
        gridAdapter.notifyDataSetChanged(); setColumns();
        setStatus(q.trim().length() < 2 ? "Escreve pelo menos 2 letras." : curItems.size() + " resultados", false);
    }

    private void pickCat(int pos, boolean focusGrid) {
        if (pos < 0 || pos >= curCats.size()) return;
        NativeData.Cat c = curCats.get(pos);
        boolean virt = c.id.startsWith("__");
        int sm = openSeries == null && vodTab() && !virt ? data.sortMode(tab) : 0;
        String key = tab + "|" + (openSeries == null ? "" : openSeries.sid) + "|" + c.id + "|" + c.name + "|" + sm;
        if (!key.equals(shownKey)) {
            shownKey = key;
            curCat = pos;
            curItems = NativeData.sorted(c.items, sm);
            gridAdapter.notifyDataSetChanged(); setColumns();
            grid.setSelection(openSeries == null ? getSharedPreferences("nativeapp", 0).getInt("pos_" + tab + "_" + c.name, 0) : 0);
            if (openSeries == null) getSharedPreferences("nativeapp", 0).edit().putString("catn_" + tab, c.name).apply();
        }
        curCat = pos;
        catAdapter.notifyDataSetChanged();
        if (focusGrid) grid.requestFocus();
    }

    private void setColumns() {
        boolean poster = !curItems.isEmpty() ? isPoster(curItems.get(0)) : vodTab();
        grid.setColumnWidth(dp(poster ? 132 : 300));
        grid.setNumColumns(GridView.AUTO_FIT);
    }

    /* ------------------------------------------------------------ adaptadores */
    private final BaseAdapter catAdapter = new BaseAdapter() {
        @Override public int getCount() { return curCats.size(); }
        @Override public Object getItem(int i) { return curCats.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public View getView(int i, View v, ViewGroup p) {
            TextView t = (TextView) v;
            if (t == null) {
                t = new TextView(NativeHomeActivity.this);
                t.setTextSize(14); t.setPadding(dp(12), dp(10), dp(10), dp(10));
                t.setSingleLine(true); t.setEllipsize(TextUtils.TruncateAt.END);
            }
            NativeData.Cat c = curCats.get(i);
            t.setText(c.name + "  ·  " + c.items.size());
            t.setTextColor(i == curCat ? ACC : TXT);
            t.setTypeface(null, i == curCat ? Typeface.BOLD : Typeface.NORMAL);
            return t;
        }
    };

    private static final class Holder { ImageView im; TextView name, sub; View bar; String url; boolean poster; }

    private final BaseAdapter gridAdapter = new BaseAdapter() {
        @Override public int getCount() { return curItems.size(); }
        @Override public Object getItem(int i) { return curItems.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public int getItemViewType(int i) { return isPoster(curItems.get(i)) ? 1 : 0; }
        @Override public View getView(int i, View v, ViewGroup p) {
            NativeData.Item it = curItems.get(i);
            boolean poster = isPoster(it);
            Holder h = v == null ? null : (Holder) v.getTag();
            if (h == null || h.poster != poster) { v = poster ? makePoster() : makeRow(); h = (Holder) v.getTag(); }
            boolean fav = data.isFav(it.url);
            boolean seen = !"live".equals(it.kind) && data.watched(it.url);
            h.name.setText((fav ? "★ " : "") + (seen ? "✓ " : "") + it.name);
            long ps = "live".equals(it.kind) ? 0 : data.pos(it.url);
            String s;
            if (poster) {
                s = it.year.length() > 0 ? it.year : "";
                if (it.rating.length() > 0 && !"0".equals(it.rating)) s += (s.isEmpty() ? "" : " · ") + "★ " + it.rating;
                if ("series".equals(it.kind)) { String le = data.lastEp(it.sid); if (le.length() > 0) s = "▶ em curso" + (s.isEmpty() ? "" : " · " + s); }
                if (ps > 0) s = "▶ " + (ps / 60000) + " min" + (s.isEmpty() ? "" : " · " + s);
            } else {
                if ("episode".equals(it.kind)) s = ps > 0 ? "▶ continuar aos " + (ps / 60000) + " min" : seen ? "visto" : (it.rating.length() > 0 ? it.rating : "");
                else s = "search".equals(tab) || "fav".equals(tab) || "recent".equals(tab) ? kindLabel(it) + it.group : (it.num > 0 ? "#" + it.num : "");
            }
            h.sub.setText(s); h.sub.setVisibility(s.isEmpty() ? View.GONE : View.VISIBLE);
            h.sub.setTextColor(seen ? OK : MUT);
            loadImg(h, it.logo);
            return v;
        }
    };

    private boolean isPoster(NativeData.Item it) { return "movie".equals(it.kind) || "series".equals(it.kind) || "vod".equals(it.kind); }
    private String kindLabel(NativeData.Item it) { return "live".equals(it.kind) ? "📺 " : "episode".equals(it.kind) || "series".equals(it.kind) ? "🎞️ " : "🎬 "; }

    private View makeRow() {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(10), dp(8), dp(10), dp(8));
        r.setBackground(roundRect(CARD, 10));
        Holder h = new Holder();
        h.im = new ImageView(this); h.im.setScaleType(ImageView.ScaleType.FIT_CENTER);
        r.addView(h.im, new LinearLayout.LayoutParams(dp(64), dp(40)));
        LinearLayout tx = new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.setPadding(dp(12), 0, 0, 0);
        h.name = new TextView(this); h.name.setTextColor(TXT); h.name.setTextSize(15); h.name.setSingleLine(true); h.name.setEllipsize(TextUtils.TruncateAt.END);
        h.sub = new TextView(this); h.sub.setTextColor(MUT); h.sub.setTextSize(12); h.sub.setSingleLine(true); h.sub.setEllipsize(TextUtils.TruncateAt.END);
        tx.addView(h.name); tx.addView(h.sub);
        r.addView(tx, new LinearLayout.LayoutParams(0, -2, 1));
        r.setTag(h);
        return r;
    }

    private View makePoster() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(4), dp(4), dp(4), dp(6));
        Holder h = new Holder(); h.poster = true;
        h.im = new ImageView(this); h.im.setScaleType(ImageView.ScaleType.CENTER_CROP);
        h.im.setBackground(roundRect(CARD, 8)); h.im.setClipToOutline(true);
        r.addView(h.im, new LinearLayout.LayoutParams(-1, dp(178)));
        h.name = new TextView(this); h.name.setTextColor(TXT); h.name.setTextSize(13); h.name.setMaxLines(2); h.name.setEllipsize(TextUtils.TruncateAt.END);
        h.name.setPadding(dp(2), dp(5), dp(2), 0);
        h.sub = new TextView(this); h.sub.setTextColor(MUT); h.sub.setTextSize(11.5f); h.sub.setSingleLine(true); h.sub.setPadding(dp(2), 0, dp(2), 0);
        r.addView(h.name); r.addView(h.sub);
        r.setTag(h);
        return r;
    }

    private void loadImg(final Holder h, final String url) {
        h.url = url;
        if (url == null || url.isEmpty() || !url.startsWith("http")) { h.im.setImageBitmap(null); return; }
        Bitmap c = bmp.get(url);
        if (c != null) { h.im.setImageBitmap(c); return; }
        h.im.setImageBitmap(null);
        if (PiconCache.knownBad(url)) return;
        img.execute(() -> {
            if (!url.equals(h.url)) return;   /* a célula já mostra outro item (deslizou) */
            Bitmap b = null;
            try { File f = PiconCache.get(url); if (f != null) b = BitmapFactory.decodeFile(f.getAbsolutePath()); } catch (Throwable ignored) { }
            final Bitmap fb = b;
            if (fb != null) bmp.put(url, fb);
            ui.post(() -> { if (url.equals(h.url)) h.im.setImageBitmap(fb); });
        });
    }

    /** Imagem grande (fundo da ficha): descarregada com a resolução certa para o ecrã. */
    private void loadBig(final ImageView v, final String url, final int maxW) {
        if (url == null || !url.startsWith("http")) return;
        final String key = "big:" + url;
        Bitmap c = bmp.get(key);
        if (c != null) { v.setImageBitmap(c); return; }
        img.execute(() -> {
            Bitmap b = null;
            HttpURLConnection h = null;
            try {
                h = (HttpURLConnection) new URL(url).openConnection();
                h.setConnectTimeout(5000); h.setReadTimeout(8000); h.setInstanceFollowRedirects(true);
                h.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) CockpitTV");
                InputStream in = h.getInputStream();
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); byte[] buf = new byte[16384]; int n;
                while ((n = in.read(buf)) > 0) { bo.write(buf, 0, n); if (bo.size() > 8 * 1024 * 1024) break; }
                in.close();
                byte[] d = bo.toByteArray();
                BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(d, 0, d.length, o);
                int ss = 1; while (o.outWidth / (ss * 2) >= maxW) ss *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options(); o2.inSampleSize = ss;
                b = BitmapFactory.decodeByteArray(d, 0, d.length, o2);
            } catch (Throwable ignored) { } finally { if (h != null) try { h.disconnect(); } catch (Throwable ignored) { } }
            final Bitmap fb = b;
            if (fb != null) bmp.put(key, fb);
            ui.post(() -> { if (fb != null) v.setImageBitmap(fb); });
        });
    }

    /* ------------------------------------------------------------ ações nos itens */
    private void onItem(int pos) {
        if (pos < 0 || pos >= curItems.size()) return;
        NativeData.Item it = curItems.get(pos);
        if (openSeries == null && vodTab() || "live".equals(tab)) {
            if (openSeries == null && curCat < curCats.size()) getSharedPreferences("nativeapp", 0).edit().putInt("pos_" + tab + "_" + curCats.get(curCat).name, pos).apply();
        }
        if ("series".equals(it.kind)) { openSeriesDetails(it); return; }
        if ("movie".equals(it.kind) || "vod".equals(it.kind)) { openMovieDetails(curItems, pos); return; }
        if ("episode".equals(it.kind)) {
            if (openSeries != null) { int i = indexOf(seriesEps, it.url); if (i >= 0) { play(seriesEps, i, -1); return; } }
            if (it.sid.length() > 0) { playEpisode(it.sid, it.url); return; }
        }
        play(curItems, pos, -1);
    }

    private static int indexOf(List<NativeData.Item> l, String url) { for (int i = 0; i < l.size(); i++) if (l.get(i).url.equals(url)) return i; return -1; }

    private void itemMenu(int pos) {
        if (pos < 0 || pos >= curItems.size()) return;
        final NativeData.Item it = curItems.get(pos);
        final boolean vod = !"live".equals(it.kind) && !"series".equals(it.kind);
        List<String> opts = new ArrayList<>();
        opts.add(data.isFav(it.url) ? "Tirar dos favoritos" : "Juntar aos favoritos");
        if (vod) opts.add(data.watched(it.url) ? "Marcar como não visto" : "Marcar como visto");
        if (vod && data.pos(it.url) > 0) opts.add("Ver do início");
        opts.add("series".equals(it.kind) ? "Abrir" : "Ver");
        final String[] arr = opts.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle(it.name).setItems(arr, (d, w) -> {
            String o = arr[w];
            if (o.contains("favoritos")) {
                boolean on = data.toggleFav(it);
                Toast.makeText(this, on ? "★ Nos favoritos" : "Fora dos favoritos", Toast.LENGTH_SHORT).show();
                if ("fav".equals(tab)) showFlat("fav"); else gridAdapter.notifyDataSetChanged();
            } else if (o.startsWith("Marcar")) {
                data.setWatched(it.url, !data.watched(it.url));
                gridAdapter.notifyDataSetChanged(); refreshCats();
            } else if (o.equals("Ver do início")) {
                if ("episode".equals(it.kind) && openSeries != null) { int i = indexOf(seriesEps, it.url); if (i >= 0) { play(seriesEps, i, 0); return; } }
                play(curItems, pos, 0);
            } else onItem(pos);
        }).show();
    }

    /* ------------------------------------------------------------ fichas de filmes e séries */
    private void closeDetails() {
        if (details == null) return;
        try { root.removeView(details); } catch (Throwable ignored) { }
        details = null;
    }

    private interface Fill { void into(LinearLayout buttons, TextView meta, TextView plot, TextView people, ImageView back, ImageView poster); }

    private View firstBtn;
    /** Ecrã de ficha (fundo, capa, título, dados, sinopse e botões). */
    private void showDetails(String title, String posterUrl, Fill f) {
        closeDetails();
        firstBtn = null;
        details = new FrameLayout(this);
        details.setBackgroundColor(BG);
        details.setClickable(true);
        ImageView back = new ImageView(this); back.setScaleType(ImageView.ScaleType.CENTER_CROP); back.setAlpha(0.35f);
        details.addView(back, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xF20B0F14, 0xC00B0F14, 0x400B0F14}));
        details.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout row = new LinearLayout(this);
        row.setPadding(dp(28), dp(26), dp(28), dp(26));
        boolean narrow = getResources().getDisplayMetrics().widthPixels < dp(600);
        row.setOrientation(narrow ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        ImageView poster = new ImageView(this); poster.setScaleType(ImageView.ScaleType.CENTER_CROP);
        poster.setBackground(roundRect(CARD, 10)); poster.setClipToOutline(true);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(dp(narrow ? 140 : 200), dp(narrow ? 210 : 300));
        plp.rightMargin = dp(26); plp.bottomMargin = dp(14);
        row.addView(poster, plp);
        Bitmap pc = posterUrl == null ? null : bmp.get(posterUrl);
        if (pc != null) poster.setImageBitmap(pc); else loadBig(poster, posterUrl, dp(200));

        LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(this); t.setText(title); t.setTextColor(TXT); t.setTextSize(26); t.setTypeface(null, Typeface.BOLD);
        info.addView(t);
        TextView meta = new TextView(this); meta.setTextColor(ACC); meta.setTextSize(14); meta.setPadding(0, dp(6), 0, dp(10));
        info.addView(meta);
        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL);
        HorizontalScrollView bh = new HorizontalScrollView(this); bh.setHorizontalScrollBarEnabled(false); bh.addView(buttons);
        info.addView(bh);
        TextView plot = new TextView(this); plot.setTextColor(TXT); plot.setTextSize(15); plot.setLineSpacing(0, 1.15f); plot.setPadding(0, dp(14), 0, dp(10));
        info.addView(plot);
        TextView people = new TextView(this); people.setTextColor(MUT); people.setTextSize(13); people.setLineSpacing(0, 1.1f);
        info.addView(people);
        row.addView(info, new LinearLayout.LayoutParams(narrow ? -1 : 0, -2, narrow ? 0 : 1));
        sv.addView(row);
        details.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        root.addView(details, new FrameLayout.LayoutParams(-1, -1));
        f.into(buttons, meta, plot, people, back, poster);
        if (firstBtn != null) firstBtn.requestFocus();
    }

    private Button dBtn(LinearLayout parent, String text, boolean primary, View.OnClickListener l) {
        Button b = btn(text, l);
        if (primary) b.setBackground(sel(0xFF2B6CB0, 12));
        parent.addView(b);
        if (firstBtn == null) firstBtn = b;
        return b;
    }

    private static String mins(String dur) {
        if (dur == null || dur.isEmpty()) return "";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(\\d+):(\\d+)(?::\\d+)?$").matcher(dur.trim());
        if (m.find()) { int h = Integer.parseInt(m.group(1)), mi = Integer.parseInt(m.group(2)); return (h > 0 ? h + " h " : "") + mi + " min"; }
        return dur;
    }

    private void openMovieDetails(final List<NativeData.Item> list, final int idx) {
        final NativeData.Item m = list.get(idx);
        final int seq = ++loadSeq;
        setStatus("A abrir «" + m.name + "»…", true);
        bg.execute(() -> {
            final JSONObject inf = data.vodInfo(m);
            ui.post(() -> {
                if (seq != loadSeq) return;
                setStatus("", false);
                showDetails(m.name, NativeData.firstImg(inf, "movie_image", "cover_big").isEmpty() ? m.logo : NativeData.firstImg(inf, "movie_image", "cover_big"), (buttons, meta, plot, people, back, poster) -> {
                    StringBuilder mt = new StringBuilder();
                    String yr = inf.optString("releasedate", inf.optString("release_date", m.year));
                    if (yr.length() >= 4) mt.append(yr.substring(0, 4));
                    String rt = inf.optString("rating", m.rating); if (rt.length() > 0 && !"0".equals(rt)) mt.append(mt.length() > 0 ? "  ·  " : "").append("★ ").append(rt);
                    String du = mins(inf.optString("duration")); if (du.length() > 0) mt.append(mt.length() > 0 ? "  ·  " : "").append(du);
                    String ge = inf.optString("genre"); if (ge.length() > 0) mt.append(mt.length() > 0 ? "  ·  " : "").append(ge);
                    if (data.watched(m.url)) mt.append("  ·  ✓ visto");
                    meta.setText(mt);
                    String pl = inf.optString("plot", inf.optString("description")); plot.setText(pl.isEmpty() ? "Sem sinopse." : pl);
                    StringBuilder pe = new StringBuilder();
                    String di = inf.optString("director"); if (di.length() > 0) pe.append("Realização: ").append(di);
                    String ca = inf.optString("cast", inf.optString("actors")); if (ca.length() > 0) pe.append(pe.length() > 0 ? "\n" : "").append("Elenco: ").append(ca);
                    people.setText(pe);
                    loadBig(back, NativeData.firstImg(inf, "backdrop_path", "backdrop", "movie_image"), dp(960));
                    final long ps = data.pos(m.url);
                    if (ps > 0) {
                        dBtn(buttons, "▶ Continuar (" + (ps / 60000) + " min)", true, v -> { closeDetails(); play(list, idx, -1); });
                        dBtn(buttons, "↺ Do início", false, v -> { closeDetails(); play(list, idx, 0); });
                    } else dBtn(buttons, "▶ Ver", true, v -> { closeDetails(); play(list, idx, 0); });
                    final String yt = NativeData.trailerId(inf);
                    if (!yt.isEmpty()) dBtn(buttons, "🎬 Trailer", false, v -> trailer(yt));
                    final Button fb = dBtn(buttons, data.isFav(m.url) ? "★ Nos favoritos" : "☆ Favorito", false, null);
                    fb.setOnClickListener(v -> { boolean on = data.toggleFav(m); fb.setText(on ? "★ Nos favoritos" : "☆ Favorito"); });
                    final Button wb = dBtn(buttons, data.watched(m.url) ? "✓ Visto" : "Marcar como visto", false, null);
                    wb.setOnClickListener(v -> { boolean on = !data.watched(m.url); data.setWatched(m.url, on); wb.setText(on ? "✓ Visto" : "Marcar como visto"); gridAdapter.notifyDataSetChanged(); });
                });
            });
        });
    }

    /** Ficha da série: continuar no episódio certo, episódios por temporada, trailer e favorito. */
    private void openSeriesDetails(final NativeData.Item s) {
        final int seq = ++loadSeq;
        setStatus("A abrir «" + s.name + "»…", true);
        bg.execute(() -> {
            List<NativeData.Cat> seasons = null; String err = null;
            try { seasons = data.seriesInfo(s, false); } catch (Throwable e) { err = String.valueOf(e.getMessage()); }
            final List<NativeData.Cat> fs = seasons; final String fe = err;
            ui.post(() -> {
                if (seq != loadSeq) return;
                if (fs == null || fs.isEmpty()) { setStatus(fe != null ? "Erro: " + fe : "Esta série ainda não tem episódios.", false); return; }
                setStatus("", false);
                final List<NativeData.Item> eps = new ArrayList<>(); for (NativeData.Cat c : fs) eps.addAll(c.items);
                JSONObject inf0 = data.seriesMeta.get(s.sid); final JSONObject inf = inf0 == null ? new JSONObject() : inf0;
                showDetails(s.name, s.logo, (buttons, meta, plot, people, back, poster) -> {
                    StringBuilder mt = new StringBuilder();
                    String yr = inf.optString("releaseDate", inf.optString("release_date", s.year)); if (yr.length() >= 4) mt.append(yr.substring(0, 4));
                    String rt = inf.optString("rating", s.rating); if (rt.length() > 0 && !"0".equals(rt)) mt.append(mt.length() > 0 ? "  ·  " : "").append("★ ").append(rt);
                    mt.append(mt.length() > 0 ? "  ·  " : "").append(fs.size()).append(fs.size() == 1 ? " temporada" : " temporadas").append("  ·  ").append(eps.size()).append(" episódios");
                    String ge = inf.optString("genre"); if (ge.length() > 0) mt.append("  ·  ").append(ge);
                    int seen = 0; for (NativeData.Item e : eps) if (data.watched(e.url)) seen++;
                    if (seen > 0) mt.append("  ·  ✓ ").append(seen).append("/").append(eps.size());
                    meta.setText(mt);
                    String pl = inf.optString("plot", s.plot); plot.setText(pl.isEmpty() ? "Sem sinopse." : pl);
                    StringBuilder pe = new StringBuilder();
                    String di = inf.optString("director"); if (di.length() > 0) pe.append("Realização: ").append(di);
                    String ca = inf.optString("cast"); if (ca.length() > 0) pe.append(pe.length() > 0 ? "\n" : "").append("Elenco: ").append(ca);
                    people.setText(pe);
                    loadBig(back, NativeData.firstImg(inf, "backdrop_path", "cover"), dp(960));
                    /* onde continuar: o último episódio aberto (se ficou a meio) ou o seguinte (se acabou) */
                    String last = data.lastEp(s.sid);
                    int ix = 0; String lbl;
                    int li = last.isEmpty() ? -1 : indexOf(eps, last);
                    if (li >= 0) { ix = data.watched(last) && li + 1 < eps.size() ? li + 1 : li; NativeData.Item e = eps.get(ix); lbl = "▶ Continuar T" + e.season + "·E" + e.ep; }
                    else lbl = "▶ Começar T" + eps.get(0).season + "·E" + eps.get(0).ep;
                    final int fix = ix;
                    dBtn(buttons, lbl, true, v -> { closeDetails(); play(eps, fix, -1); });
                    dBtn(buttons, "☰ Episódios", false, v -> { closeDetails(); showSeasons(s, fs, eps, fix); });
                    final String yt = NativeData.trailerId(inf);
                    if (!yt.isEmpty()) dBtn(buttons, "🎬 Trailer", false, v -> trailer(yt));
                    final Button fb = dBtn(buttons, data.isFav(s.url) ? "★ Nos favoritos" : "☆ Favorito", false, null);
                    fb.setOnClickListener(v -> { boolean on = data.toggleFav(s); fb.setText(on ? "★ Nos favoritos" : "☆ Favorito"); });
                });
            });
        });
    }

    /** Temporadas na coluna, episódios na grelha (abre na temporada do episódio a seguir). */
    private void showSeasons(NativeData.Item s, List<NativeData.Cat> seasons, List<NativeData.Item> eps, int focusEp) {
        if (openSeries == null) { seriesCatBefore = curCat; seriesPosBefore = grid.getFirstVisiblePosition(); }
        String prevTab = tab;
        if (!"series".equals(tab) && catList.getVisibility() != View.VISIBLE) { catList.setVisibility(View.VISIBLE); }
        openSeries = s;
        seriesEps = eps;
        curCats = seasons; shownKey = "";
        catAdapter.notifyDataSetChanged();
        int si = 0; String target = focusEp >= 0 && focusEp < eps.size() ? eps.get(focusEp).url : "";
        for (int i = 0; i < seasons.size(); i++) if (indexOf(seasons.get(i).items, target) >= 0) { si = i; break; }
        pickCat(si, true);
        catList.setSelection(si);
        int ei = indexOf(curItems, target); if (ei >= 0) grid.setSelection(ei);
        updateSortBtn();
        setStatus("🎞️ " + s.name + " · " + seasons.size() + " temporadas   ·   Voltar: " + ("series".equals(prevTab) ? "lista de séries" : "anterior"), false);
    }

    private void closeSeries() {
        openSeries = null;
        if (!"series".equals(tab)) { showTab(tab); return; }
        curCats = withVirtual("series"); shownKey = "";
        catAdapter.notifyDataSetChanged();
        pickCat(Math.min(seriesCatBefore, Math.max(0, curCats.size() - 1)), true);
        catList.setSelection(curCat);
        grid.setSelection(seriesPosBefore);
        updateSortBtn();
        setStatus("", false);
    }

    /** Abre um episódio pelo endereço, com a série toda na lista (o seguinte começa sozinho). */
    private void playEpisode(final String sid, final String url) {
        bg.execute(() -> {
            try { data.load("series", false); } catch (Throwable ignored) { }
            NativeData.Item s = data.seriesBySid(sid);
            List<NativeData.Item> eps = new ArrayList<>();
            if (s != null) try { for (NativeData.Cat c : data.seriesInfo(s, false)) eps.addAll(c.items); } catch (Throwable ignored) { }
            final List<NativeData.Item> fe = eps;
            ui.post(() -> {
                int i = indexOf(fe, url);
                if (i >= 0) { play(fe, i, -1); return; }
                NativeData.Item it = data.findByUrl(url);
                if (it != null) { List<NativeData.Item> one = new ArrayList<>(); one.add(it); play(one, 0, -1); }
            });
        });
    }

    private void trailer(String id) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:" + id))); return; } catch (Throwable ignored) { }
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=" + id))); }
        catch (Throwable e) { Toast.makeText(this, "Não há nenhuma app para abrir o trailer (instala o YouTube).", Toast.LENGTH_LONG).show(); }
    }

    /* ------------------------------------------------------------ reprodução */
    /** startOverride: -1 = retoma onde ficou; 0 = do início. */
    private void play(List<NativeData.Item> list, int idx, long startOverride) {
        if (nscr != null && nscr.isOpen()) return;
        /* só os itens reproduzíveis, no máximo 1500 à volta do escolhido: é a lista do ecrã total */
        List<NativeData.Item> src = new ArrayList<>(); int start = 0;
        int from = Math.max(0, idx - 750), to = Math.min(list.size(), from + 1500);
        for (int i = from; i < to; i++) { NativeData.Item it = list.get(i); if ("series".equals(it.kind) || it.url.startsWith("series:")) continue; if (i == idx) start = src.size(); src.add(it); }
        if (src.isEmpty()) return;
        JSONArray a = new JSONArray();
        for (int i = 0; i < src.size(); i++) {
            NativeData.Item it = src.get(i);
            try {
                JSONObject o = new JSONObject();
                String nm = it.name;
                if ("episode".equals(it.kind) && it.group.length() > 0) nm = it.group + " · " + it.name;
                o.put("name", nm); o.put("logo", it.logo); o.put("group", it.group); o.put("url", it.url);
                o.put("kind", "live".equals(it.kind) ? "live" : "movie");
                long p = "live".equals(it.kind) ? 0 : (i == start && startOverride >= 0 ? startOverride : data.pos(it.url));
                if (p > 0) o.put("start", p);
                a.put(o);
            } catch (Throwable ignored) { }
        }
        playing = src;
        try {
            if (np == null) np = new NativePlayer(this, root, (k, m) -> playerEvent(k, m));
            MainActivity.NAV_JSON = "";   /* abas da app nativa no ecrã do canal */
            nscr = new NativeScreen(this, root, np, (k, m) -> runOnUiThread(() -> onScreen(k, m)));
            nscr.open(a.toString(), start);
            if (nscr.isOpen()) nscr.command("full", "");
        } catch (Throwable e) {
            Toast.makeText(this, "Não consegui abrir: " + e, Toast.LENGTH_LONG).show();
        }
    }

    private void playerEvent(String k, String m) {
        NativeScreen s = nscr;
        if ("suberr".equals(k)) { runOnUiThread(() -> Toast.makeText(this, "Legendas: " + m, Toast.LENGTH_LONG).show()); return; }
        if (s != null && s.isOpen()) s.onPlayerEvent(k, m);
    }

    private NativeData.Item playingByUrl(String url) { for (NativeData.Item it : playing) if (it.url.equals(url)) return it; return null; }

    private void onScreen(String k, String m) {
        switch (k) {
            case "nscreen:play": {
                NativeData.Item it = playingByUrl(m);
                nowItem = it;
                osRes = new ArrayList<>();
                if (it != null) {
                    data.pushRecent(it);
                    if ("episode".equals(it.kind) && it.sid.length() > 0) data.setLastEp(it.sid, it.url);
                    if ("live".equals(it.kind)) fetchEpg(it);
                    else if (data.osAuto() && data.osKey().length() > 0) autoSubs(it);
                    if (cast != null && cast.active()) castNow();
                }
                break;
            }
            case "nscreen:pos": {
                String[] p = m.split("\\|");
                if (p.length >= 3) try {
                    long ps = Long.parseLong(p[1]), du = Long.parseLong(p[2]);
                    data.savePos(p[0], ps, du);
                    NativeData.Item it = playingByUrl(p[0]);
                    if (it != null) watchNext(it, ps, du);
                } catch (Throwable ignored) { }
                break;
            }
            case "nscreen:closed":
                try { if (np != null) np.stop(); } catch (Throwable ignored) { }
                nowItem = null;
                gridAdapter.notifyDataSetChanged();
                if ("recent".equals(tab)) showFlat("recent"); else refreshCats();
                grid.requestFocus();
                break;
            case "nscreen:nav":
                if ("search".equals(m) || "movie".equals(m) || "series".equals(m) || "live".equals(m)) showTab(m);
                else if ("settings".equals(m)) showTab("settings");
                break;
            case "nscreen:guide":
                if (!"live".equals(tab)) showTab("live");
                break;
            case "nscreen:subsearch": subSearch(); break;
            case "nscreen:subpick": try { subApply(Integer.parseInt(m), false); } catch (Throwable ignored) { } break;
            case "nscreen:act":
                if ("cast".equals(m)) startCast();
                break;
        }
    }

    /** Programa a decorrer e o seguinte (Xtream), mostrado no ecrã do canal. */
    private void fetchEpg(final NativeData.Item it) {
        bg.execute(() -> {
            String t = data.nowNext(it);
            if (t.isEmpty()) return;
            ui.post(() -> {
                try { if (nscr != null && nscr.isOpen()) { JSONObject o = new JSONObject(); o.put(it.url, t); nscr.command("epg", o.toString()); } } catch (Throwable ignored) { }
            });
        });
    }

    /* ------------------------------------------------------------ legendas online */
    private String subQuery(NativeData.Item it) {
        if ("episode".equals(it.kind) && it.group.length() > 0) return it.group + " S" + it.season + "E" + it.ep;
        return it.name;
    }
    private void subSearch() {
        final NativeData.Item it = nowItem;
        if (it == null) return;
        if (data.osKey().isEmpty()) { Toast.makeText(this, "Falta a chave OpenSubtitles em ⚙️ Definições.", Toast.LENGTH_LONG).show(); return; }
        bg.execute(() -> {
            try {
                final List<String[]> r = data.osSearch(subQuery(it));
                ui.post(() -> {
                    if (nowItem != it || nscr == null || !nscr.isOpen()) return;
                    osRes = r;
                    JSONArray a = new JSONArray(); for (String[] x : r) a.put(x[1]);
                    nscr.command("subres", a.toString());
                });
            } catch (final Throwable e) { ui.post(() -> Toast.makeText(this, "Legendas: " + e.getMessage(), Toast.LENGTH_LONG).show()); }
        });
    }
    private void subApply(final int i, final boolean silent) {
        if (i < 0 || i >= osRes.size() || np == null) return;
        final String fid = osRes.get(i)[0];
        final NativeData.Item it = nowItem;
        bg.execute(() -> {
            try {
                final String txt = data.osDownload(fid);
                ui.post(() -> {
                    if (nowItem != it || np == null) return;
                    np.subtitle(txt, "Português · OpenSubtitles", "pt");
                    Toast.makeText(this, "Legendas em português ativadas ✓", Toast.LENGTH_SHORT).show();
                });
            } catch (final Throwable e) { if (!silent) ui.post(() -> Toast.makeText(this, "Legendas: " + e.getMessage(), Toast.LENGTH_LONG).show()); }
        });
    }
    /** Legendas automáticas: procura e aplica a melhor em português pouco depois de começar. */
    private void autoSubs(final NativeData.Item it) {
        ui.postDelayed(() -> {
            if (nowItem != it || nscr == null || !nscr.isOpen()) return;
            bg.execute(() -> {
                try {
                    final List<String[]> r = data.osSearch(subQuery(it));
                    ui.post(() -> { if (nowItem == it && !r.isEmpty()) { osRes = r; subApply(0, true); } });
                } catch (Throwable ignored) { }
            });
        }, 6000);
    }

    /* ------------------------------------------------------------ transmitir (Chromecast) */
    private void startCast() {
        try {
            if (cast == null) cast = new CastHelper(this, (k, m) -> runOnUiThread(() -> onCast(k, m)));
            if (cast.active()) { castNow(); return; }
            castWanted = true;
            cast.pick();
        } catch (Throwable e) { Toast.makeText(this, "Transmitir não está disponível neste aparelho.", Toast.LENGTH_LONG).show(); }
    }
    private void onCast(String k, String m) {
        if ("connected".equals(k)) { Toast.makeText(this, "Ligado a " + m, Toast.LENGTH_SHORT).show(); if (castWanted) castNow(); castWanted = false; }
        else if ("failed".equals(k) || "error".equals(k) || "unavailable".equals(k)) { castWanted = false; Toast.makeText(this, "Transmitir: " + m, Toast.LENGTH_LONG).show(); }
    }
    private void castNow() {
        NativeData.Item it = nowItem;
        if (it == null || cast == null) return;
        String u = it.url.toLowerCase();
        String mime = u.contains(".m3u8") ? "application/x-mpegURL" : u.endsWith(".ts") ? "video/mp2t" : u.endsWith(".mkv") ? "video/x-matroska" : "video/mp4";
        long st = 0;
        try { st = Long.parseLong(np.pos().split("\\|")[0]); } catch (Throwable ignored) { }
        boolean live = "live".equals(it.kind);
        cast.load(it.url, it.name, mime, live, live ? 0 : st);
        try { np.pause(); } catch (Throwable ignored) { }
        Toast.makeText(this, "A transmitir «" + it.name + "»", Toast.LENGTH_SHORT).show();
    }

    /* ------------------------------------------------------------ «Continuar a ver» no ecrã inicial da TV */
    private void watchNext(NativeData.Item it, long pos, long dur) {
        final String id = it.url, name = "episode".equals(it.kind) && it.group.length() > 0 ? it.group + " · " + it.name : it.name, logo = it.logo;
        final boolean remove = dur > 0 && pos > Math.max(dur * 0.93, dur - 120000) || pos < 30000;
        bg.execute(() -> {
            try {
                android.content.ContentResolver cr = getContentResolver();
                long existing = -1;
                android.database.Cursor c = cr.query(androidx.tvprovider.media.tv.TvContractCompat.WatchNextPrograms.CONTENT_URI,
                        androidx.tvprovider.media.tv.WatchNextProgram.PROJECTION, null, null, null);
                if (c != null) {
                    try {
                        while (c.moveToNext()) {
                            androidx.tvprovider.media.tv.WatchNextProgram p = androidx.tvprovider.media.tv.WatchNextProgram.fromCursor(c);
                            if (id.equals(p.getInternalProviderId())) { existing = p.getId(); break; }
                        }
                    } finally { c.close(); }
                }
                if (remove) { if (existing >= 0) cr.delete(androidx.tvprovider.media.tv.TvContractCompat.buildWatchNextProgramUri(existing), null, null); return; }
                androidx.tvprovider.media.tv.WatchNextProgram.Builder b = new androidx.tvprovider.media.tv.WatchNextProgram.Builder();
                b.setType(androidx.tvprovider.media.tv.TvContractCompat.WatchNextPrograms.TYPE_MOVIE);
                b.setWatchNextType(androidx.tvprovider.media.tv.TvContractCompat.WatchNextPrograms.WATCH_NEXT_TYPE_CONTINUE);
                b.setLastEngagementTimeUtcMillis(System.currentTimeMillis());
                b.setTitle(name);
                b.setInternalProviderId(id);
                b.setLastPlaybackPositionMillis((int) pos);
                b.setDurationMillis((int) dur);
                b.setIntentUri(Uri.parse("cockpittv://play?id=" + Uri.encode(id)));
                if (logo != null && logo.startsWith("http")) {
                    b.setPosterArtUri(Uri.parse(logo));
                    b.setPosterArtAspectRatio(androidx.tvprovider.media.tv.TvContractCompat.PreviewPrograms.ASPECT_RATIO_2_3);
                }
                android.content.ContentValues cv = b.build().toContentValues();
                if (existing >= 0) cr.update(androidx.tvprovider.media.tv.TvContractCompat.buildWatchNextProgramUri(existing), cv, null, null);
                else cr.insert(androidx.tvprovider.media.tv.TvContractCompat.WatchNextPrograms.CONTENT_URI, cv);
            } catch (Throwable ignored) { }
        });
    }

    /* ------------------------------------------------------------ definições */
    private void showSettings() {
        catList.setVisibility(View.GONE); grid.setVisibility(View.GONE);
        setStatus("", false);
        ScrollView sv = new ScrollView(this);
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(20), dp(8), dp(20), dp(30));
        sv.addView(f);

        f.addView(head("Lista IPTV"));
        final EditText xs = field(f, "Servidor Xtream (ex.: http://servidor:8080)", data.server, false);
        final EditText xu = field(f, "Utilizador", data.user, false);
        final EditText xp = field(f, "Palavra-passe", data.pass, true);
        final EditText mm = field(f, "…ou endereço de lista M3U", data.m3u, false);
        LinearLayout row = new LinearLayout(this); row.setPadding(0, dp(12), 0, 0);
        final Button save = btn("Guardar", v -> {
            data.saveCfg(xs.getText().toString(), xu.getText().toString(), xp.getText().toString(), mm.getText().toString());
            Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show();
            if (data.configured()) showTab("live");
        });
        row.addView(save);
        row.addView(btn("Atualizar listas agora", v -> { data.clearCache(); Toast.makeText(this, "As listas vão ser descarregadas de novo", Toast.LENGTH_SHORT).show(); showTab("live"); }));
        row.addView(btn("Importar da app antiga", v -> {
            importOld(res -> { if (res) { data.loadCfg(); data.clearCache(); Toast.makeText(this, "Importado", Toast.LENGTH_SHORT).show(); showTab("live"); } else Toast.makeText(this, "Não encontrei dados da app antiga.", Toast.LENGTH_LONG).show(); });
        }));
        f.addView(row);

        f.addView(head("Legendas online (OpenSubtitles)"));
        final EditText ok = field(f, "Chave da API (opensubtitles.com → Consumers)", data.osKey(), false);
        final EditText ou = field(f, "Utilizador (opcional, dá mais downloads)", data.osUser(), false);
        final EditText op = field(f, "Palavra-passe", data.osPass(), true);
        final CheckBox auto = new CheckBox(this);
        auto.setText("Pôr legendas em português automaticamente nos filmes e séries"); auto.setTextColor(TXT); auto.setChecked(data.osAuto());
        auto.setPadding(dp(4), dp(8), 0, dp(4));
        f.addView(auto);
        LinearLayout row2 = new LinearLayout(this); row2.setPadding(0, dp(8), 0, 0);
        row2.addView(btn("Guardar legendas", v -> { data.saveOs(ok.getText().toString(), ou.getText().toString(), op.getText().toString(), auto.isChecked()); Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show(); }));
        f.addView(row2);

        f.addView(head("Filmes e séries"));
        LinearLayout row3 = new LinearLayout(this); row3.setPadding(0, dp(4), 0, 0);
        row3.addView(btn("Limpar «Continuar a ver»", v -> {
            getSharedPreferences("nativeapp", 0).edit().putString("pos", "{}").putString("slast", "{}").apply();
            Toast.makeText(this, "Limpo", Toast.LENGTH_SHORT).show();
        }));
        row3.addView(btn("Limpar marcas de visto", v -> { getSharedPreferences("nativeapp", 0).edit().putString("watched", "{}").apply(); Toast.makeText(this, "Limpo", Toast.LENGTH_SHORT).show(); }));
        f.addView(row3);

        TextView ver = new TextView(this);
        String vn = ""; try { vn = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Throwable ignored) { }
        ver.setText("Cockpit TV · " + vn + "\nNo ecrã do vídeo: Áudio (faixas, Dolby e atraso do som), Legendas (embutidas e 🌐 online), ⧉ vários ecrãs e 📡 Transmitir.");
        ver.setTextColor(MUT); ver.setTextSize(12); ver.setPadding(0, dp(18), 0, 0);
        f.addView(ver);

        settingsView = sv;
        body.addView(sv, new LinearLayout.LayoutParams(-1, -1));
        (data.configured() ? save : xs).requestFocus();
    }

    private TextView head(String s) {
        TextView h = new TextView(this);
        h.setText(s); h.setTextColor(TXT); h.setTextSize(19); h.setTypeface(null, Typeface.BOLD); h.setPadding(0, dp(16), 0, dp(2));
        return h;
    }

    private EditText field(LinearLayout f, String hint, String val, boolean pw) {
        TextView l = new TextView(this); l.setText(hint); l.setTextColor(MUT); l.setTextSize(12.5f); l.setPadding(0, dp(8), 0, dp(3));
        f.addView(l);
        EditText e = new EditText(this);
        e.setText(val); e.setTextColor(TXT); e.setSingleLine(true);
        e.setInputType(pw ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD) : (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI));
        e.setBackground(sel(CARD, 10)); e.setPadding(dp(14), dp(10), dp(14), dp(10));
        f.addView(e, new LinearLayout.LayoutParams(-1, -2));
        return e;
    }

    private Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t); b.setAllCaps(false); b.setTextColor(TXT); b.setTextSize(14);
        b.setBackground(sel(0xFF1F2B38, 12)); b.setPadding(dp(16), dp(8), dp(16), dp(8));
        b.setStateListAnimator(null);
        if (l != null) b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    /* ------------------------------------------------------------ teclas, voltar e ciclo de vida */
    @Override
    public void onBackPressed() {
        if (nscr != null && nscr.isOpen()) { nscr.onBack(); return; }
        if (details != null) { closeDetails(); grid.requestFocus(); return; }
        if (openSeries != null) { closeSeries(); return; }
        if (grid.hasFocus() && catList.getVisibility() == View.VISIBLE) { catList.requestFocus(); return; }
        if (!"live".equals(tab)) { showTab("live"); return; }
        super.onBackPressed();
    }

    @Override
    public boolean onKeyDown(int code, KeyEvent ev) {
        if (code == KeyEvent.KEYCODE_ESCAPE) { onBackPressed(); return true; }
        if (nscr != null && nscr.isOpen()) { if (nscr.onKey(ev)) return true; return super.onKeyDown(code, ev); }
        if (code == KeyEvent.KEYCODE_MENU || code == KeyEvent.KEYCODE_BOOKMARK) {
            if (details == null && grid.hasFocus()) { itemMenu(grid.getSelectedItemPosition()); return true; }
        }
        return super.onKeyDown(code, ev);
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        if (nscr != null && nscr.isOpen()) nscr.onConfigChanged();
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        try {
            if (android.os.Build.VERSION.SDK_INT < 26 || np == null || !np.isActive() || nscr == null || !nscr.isOpen()) return;
            android.app.UiModeManager um = (android.app.UiModeManager) getSystemService(UI_MODE_SERVICE);
            if (um != null && um.getCurrentModeType() == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION) return;
            if (!getPackageManager().hasSystemFeature(android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE)) return;
            enterPictureInPictureMode(new android.app.PictureInPictureParams.Builder().setAspectRatio(new android.util.Rational(16, 9)).build());
        } catch (Throwable ignored) { }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean in, android.content.res.Configuration cfg) {
        super.onPictureInPictureModeChanged(in, cfg);
        try { if (nscr != null && nscr.isOpen()) nscr.setSystemPip(in); } catch (Throwable ignored) { }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (np != null) np.resumeAfterBackground();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (np != null) np.pause();
    }

    @Override
    protected void onDestroy() {
        try { if (nscr != null && nscr.isOpen()) nscr.close(); } catch (Throwable ignored) { }
        if (np != null) { np.release(); np = null; }
        if (cast != null) { try { cast.release(); } catch (Throwable ignored) { } cast = null; }
        bg.shutdownNow(); img.shutdownNow();
        super.onDestroy();
    }
}
