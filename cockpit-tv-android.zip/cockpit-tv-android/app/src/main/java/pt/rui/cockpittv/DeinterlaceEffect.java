package pt.rui.cockpittv;

import android.content.Context;
import android.opengl.GLES20;

import androidx.media3.common.VideoFrameProcessingException;
import androidx.media3.common.util.GlProgram;
import androidx.media3.common.util.GlUtil;
import androidx.media3.common.util.Size;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.BaseGlShaderProgram;
import androidx.media3.effect.GlEffect;
import androidx.media3.effect.GlShaderProgram;

/**
 * Desentrelaçamento adaptativo (só espacial) feito na GPU.
 * Em cada pixel detecta o "efeito pente" (as duas linhas vizinhas diferem do pixel no mesmo sentido)
 * e só aí interpola a partir das linhas vizinhas, com direção do contorno (edge-directed).
 * Em vídeo progressivo quase não atua. Não é o yadif completo (não usa o campo anterior/seguinte).
 */
@UnstableApi
public final class DeinterlaceEffect implements GlEffect {
    @Override
    public GlShaderProgram toGlShaderProgram(Context context, boolean useHdr) throws VideoFrameProcessingException {
        return new Shader();
    }

    private static final String VERT =
            "attribute vec4 aFramePosition;\n" +
            "varying vec2 vTex;\n" +
            "void main(){ gl_Position = aFramePosition; vTex = aFramePosition.xy * 0.5 + 0.5; }\n";

    private static final String FRAG =
            "precision mediump float;\n" +
            "uniform sampler2D uTexSampler;\n" +
            "uniform vec2 uPx;\n" +
            "varying vec2 vTex;\n" +
            "float Y(vec3 c){ return dot(c, vec3(0.299, 0.587, 0.114)); }\n" +
            "void main(){\n" +
            "  vec3 c = texture2D(uTexSampler, vTex).rgb;\n" +
            "  vec3 u = texture2D(uTexSampler, vTex + vec2(0.0, uPx.y)).rgb;\n" +
            "  vec3 l = texture2D(uTexSampler, vTex - vec2(0.0, uPx.y)).rgb;\n" +
            "  float yc = Y(c), yu = Y(u), yl = Y(l);\n" +
            "  float comb = (yu - yc) * (yl - yc);\n" +
            "  float agree = abs(yu - yl);\n" +
            "  float k = smoothstep(0.0015, 0.012, comb) * (1.0 - smoothstep(0.25, 0.6, agree));\n" +
            "  vec3 ul = texture2D(uTexSampler, vTex + vec2(-uPx.x, uPx.y)).rgb;\n" +
            "  vec3 ur = texture2D(uTexSampler, vTex + vec2( uPx.x, uPx.y)).rgb;\n" +
            "  vec3 ll = texture2D(uTexSampler, vTex + vec2(-uPx.x, -uPx.y)).rgb;\n" +
            "  vec3 lr = texture2D(uTexSampler, vTex + vec2( uPx.x, -uPx.y)).rgb;\n" +
            "  float d1 = abs(Y(ul) - Y(lr)), d2 = abs(Y(ur) - Y(ll)), d0 = abs(yu - yl);\n" +
            "  vec3 ip = (u + l) * 0.5;\n" +
            "  if(d1 < d0 && d1 < d2) ip = (ul + lr) * 0.5;\n" +
            "  else if(d2 < d0 && d2 < d1) ip = (ur + ll) * 0.5;\n" +
            "  gl_FragColor = vec4(mix(c, ip, k), 1.0);\n" +
            "}\n";

    private static final class Shader extends BaseGlShaderProgram {
        private final GlProgram program;
        private int w = 1, h = 1;

        Shader() throws VideoFrameProcessingException {
            super(false, 1);
            try {
                program = new GlProgram(VERT, FRAG);
                program.setBufferAttribute("aFramePosition", GlUtil.getNormalizedCoordinateBounds(),
                        GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE);
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e);
            }
        }

        @Override
        public Size configure(int inputWidth, int inputHeight) {
            w = inputWidth; h = inputHeight;
            return new Size(inputWidth, inputHeight);
        }

        @Override
        public void drawFrame(int inputTexId, long presentationTimeUs) throws VideoFrameProcessingException {
            try {
                program.use();
                program.setSamplerTexIdUniform("uTexSampler", inputTexId, 0);
                program.setFloatsUniform("uPx", new float[]{1f / Math.max(1, w), 1f / Math.max(1, h)});
                program.bindAttributesAndUniforms();
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e, presentationTimeUs);
            }
        }

        @Override
        public void release() throws VideoFrameProcessingException {
            super.release();
            try { program.delete(); } catch (GlUtil.GlException e) { throw new VideoFrameProcessingException(e); }
        }
    }
}
