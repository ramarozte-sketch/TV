package pt.rui.cockpittv;

import android.content.Context;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

/** v497: bandeiras de país para as faixas de áudio e legendas, e as preferências de idioma predefinido. */
final class LangFlag {
    private LangFlag() { }

    /** código de 2 letras -> {nome, país} */
    private static final Map<String, String[]> M = new HashMap<>();
    private static final Map<String, String> M3 = new HashMap<>();
    static {
        put("pt", "Português", "PT"); put("en", "Inglês", "GB"); put("es", "Espanhol", "ES"); put("fr", "Francês", "FR");
        put("de", "Alemão", "DE"); put("it", "Italiano", "IT"); put("nl", "Neerlandês", "NL"); put("ru", "Russo", "RU");
        put("ja", "Japonês", "JP"); put("zh", "Chinês", "CN"); put("ko", "Coreano", "KR"); put("ar", "Árabe", "SA");
        put("tr", "Turco", "TR"); put("pl", "Polaco", "PL"); put("sv", "Sueco", "SE"); put("da", "Dinamarquês", "DK");
        put("no", "Norueguês", "NO"); put("fi", "Finlandês", "FI"); put("el", "Grego", "GR"); put("cs", "Checo", "CZ");
        put("hu", "Húngaro", "HU"); put("ro", "Romeno", "RO"); put("uk", "Ucraniano", "UA"); put("hi", "Hindi", "IN");
        put("he", "Hebraico", "IL"); put("ca", "Catalão", "ES"); put("bg", "Búlgaro", "BG"); put("hr", "Croata", "HR");
        put("sk", "Eslovaco", "SK"); put("sl", "Esloveno", "SI"); put("sr", "Sérvio", "RS"); put("id", "Indonésio", "ID");
        put("th", "Tailandês", "TH"); put("vi", "Vietnamita", "VN");
        String[][] t3 = {{"por","pt"},{"eng","en"},{"spa","es"},{"fra","fr"},{"fre","fr"},{"deu","de"},{"ger","de"},{"ita","it"},
            {"nld","nl"},{"dut","nl"},{"rus","ru"},{"jpn","ja"},{"zho","zh"},{"chi","zh"},{"kor","ko"},{"ara","ar"},{"tur","tr"},
            {"pol","pl"},{"swe","sv"},{"dan","da"},{"nor","no"},{"nob","no"},{"nno","no"},{"fin","fi"},{"ell","el"},{"gre","el"},
            {"ces","cs"},{"cze","cs"},{"hun","hu"},{"ron","ro"},{"rum","ro"},{"ukr","uk"},{"hin","hi"},{"heb","he"},{"cat","ca"},
            {"bul","bg"},{"hrv","hr"},{"slk","sk"},{"slo","sk"},{"slv","sl"},{"srp","sr"},{"ind","id"},{"tha","th"},{"vie","vi"}};
        for (String[] p : t3) M3.put(p[0], p[1]);
    }
    private static void put(String code, String nome, String pais) { M.put(code, new String[]{nome, pais}); }

    /** Idioma normalizado de 2 letras ("por" -> "pt", "pt-BR" -> "pt"); vazio se não for um idioma. */
    static String code(String tag) {
        if (tag == null) return "";
        String t = tag.trim().toLowerCase(Locale.ROOT).replace('_', '-');
        if (t.isEmpty() || "und".equals(t)) return "";
        String l = t.split("-")[0];
        if (l.length() == 3) l = M3.containsKey(l) ? M3.get(l) : l;
        return l;
    }

    /** Bandeira (dois indicadores regionais) do idioma; para pt-BR é a do Brasil. Vazia se não se sabe. */
    static String flag(String tag) {
        String t = tag == null ? "" : tag.trim().toUpperCase(Locale.ROOT).replace('_', '-');
        String country = "";
        String[] parts = t.split("-");
        if (parts.length > 1 && parts[1].length() == 2) country = parts[1];
        if (country.isEmpty()) { String[] m = M.get(code(tag)); if (m != null) country = m[1]; }
        if (country.length() != 2) return "";
        int a = 0x1F1E6 + (country.charAt(0) - 'A'), b = 0x1F1E6 + (country.charAt(1) - 'A');
        return new String(Character.toChars(a)) + new String(Character.toChars(b));
    }

    /** Nome do idioma para as listas, ex.: «🇵🇹 Português». */
    static String label(String tag) {
        String c = code(tag);
        String[] m = M.get(c);
        String nome = m != null ? m[0] : (tag == null ? "" : tag);
        String f = flag(tag);
        return (f.isEmpty() ? "" : f + " ") + nome;
    }

    /** Idiomas oferecidos nas definições, por ordem. «orig» = faixa original do filme; «off» = sem legendas. */
    static final String[] AUD_CODES = {"pt", "en", "es", "fr", "de", "it", "orig"};
    static final String[] SUB_CODES = {"off", "pt", "en", "es", "fr", "de", "it"};

    static String optLabel(String c) {
        if ("orig".equals(c)) return "Original do filme";
        if ("off".equals(c)) return "Sem legendas";
        return label(c);
    }

    static String prefAudio(Context c) {
        String v = c.getSharedPreferences("nativeapp", 0).getString("pref_aud", "pt");
        return "orig".equals(v) ? null : v;
    }
    static String prefSub(Context c) {
        String v = c.getSharedPreferences("nativeapp", 0).getString("pref_sub", "pt");
        return "off".equals(v) ? null : v;
    }
}
