package pt.rui.cockpittv;

import android.app.Activity;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.Tracks;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.DecoderCounters;
import androidx.media3.exoplayer.analytics.AnalyticsListener;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Leitor nativo (Media3 / ExoPlayer) que fica por cima da área do vídeo da página.
 * Usa os descodificadores de hardware (MediaCodec), passagem de áudio AC-3/E-AC-3/DTS pela HDMI,
 * buffer afinado para IPTV e ajuste da taxa de imagem do ecrã. Se falhar, a página volta ao leitor web.
 */
@UnstableApi
class NativePlayer {
    interface Listener { void onEvent(String kind, String msg); }

    private static final String UA = "VLC/3.0.20 LibVLC/3.0.20";
    private static final String UA_BROWSER = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    private final Activity act;
    private final FrameLayout root;
    private final Listener listener;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private FrameLayout box;
    private PlayerView view;
    private TextView label;
    private android.view.SurfaceView hdrSv;   /* telemóvel: superfície para HDR / Dolby Vision (a TextureView mostra cores erradas) */
    private boolean hdrOn = false;
    private boolean hdrContent = false;   /* o vídeo atual é HDR/Dolby Vision (a superfície HDR separada está desligada: no telemóvel estragava a imagem) */
    private static final boolean HDR_SURFACE = false;
    private boolean dv5Warned = false;
    private android.view.TextureView ttv;   /* telemóvel: superfície própria, com o tamanho calculado por nós */
    private TextView hud;
    private ExoPlayer player;
    private boolean deint = false;
    /* v265: acerto do som em ms (+ = a imagem espera, para quando o som chega atrasado), guardado por saída de som */
    static volatile int avOffsetMs = 0;
    private String audDec = "";
    private volatile String avKind = "pcm";   /* o acerto fica guardado à parte para som Dolby/DTS e para o resto (AAC…) */
    private String avKey() {
        try { android.media.AudioManager am = (android.media.AudioManager) act.getSystemService(android.content.Context.AUDIO_SERVICE);
            for (android.media.AudioDeviceInfo d : am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) { int t = d.getType(); if (t == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == 26 || t == 27) return "av_bt_" + avKind; }
        } catch (Throwable ignored) { }
        return "av_spk_" + avKind;
    }
    int getAv() { return avOffsetMs; }
    /** v304: em modo túnel o som e a imagem são sincronizados pelo próprio aparelho e o acerto manual do som não faz efeito; com um acerto guardado, o túnel fica desligado para o acerto valer */
    private boolean avOffsetSet() {
        try { String tk0 = avTitle(); if (!tk0.isEmpty() && titleAv(tk0) != 0) return true;
            for (java.util.Map.Entry<String, ?> en : act.getSharedPreferences("np", 0).getAll().entrySet()) if (en.getKey().startsWith("av_") && !en.getKey().startsWith("av_t_") && en.getValue() instanceof Integer && ((Integer) en.getValue()) != 0) return true; } catch (Throwable ignored) { }
        return false;
    }
    void setAv(int ms) {
        int prev = avOffsetMs;
        avOffsetMs = Math.max(-30000, Math.min(30000, ms));   /* v432: até 30 s (antes ±2 s, insuficiente para desfasamentos de ~20 s) */
        try {
            String tk = avTitle();
            act.getSharedPreferences("np", 0).edit().putInt(tk.isEmpty() ? avKey() : "av_t_" + tk, avOffsetMs).apply();
        } catch (Throwable ignored) { }
        if (prev != avOffsetMs)
            log("acerto do som (" + (avTitle().isEmpty() ? avKey() : "filme " + avTitle()) + "): " + avOffsetMs + " ms");
        /* v343: desligar túnel só uma vez (antes spamava a cada −100 ms no ajuste). */
        if (avOffsetMs != 0 && selector != null) {
            try {
                if (selector.getParameters().tunnelingEnabled) {
                    selector.setParameters(selector.buildUponParameters().setTunnelingEnabled(false).build());
                    log("túnel desligado para o acerto do som fazer efeito");
                }
            } catch (Throwable ignored) { }
        }
    }
    /* v267: telemóvel Samsung + som Dolby pelo altifalante: o descodificador Dolby do telemóvel faz o som chegar ~0,8 s antes
       da imagem (confirmado pelo Rui com −800 ms). Fica como ponto de partida; se o acertares à mão, vale o teu valor. */
    private int avDefault(String k) {
        /* v336: sem acertos por defeito — só valores validados/guardados pelo utilizador.
           O −800 ms Samsung Dolby deixava de aplicar-se sozinho (causava dessinc sem confirmação). */
        return 0;
    }
    /** TsFix activo? (preferência np/tsFix, ligado por omissão) */
    boolean tsFixEnabled() {
        try { return act.getSharedPreferences("np", 0).getBoolean("tsFix", true); } catch (Throwable e) { return true; }
    }
    void setDolbySw(boolean on) { try { act.getSharedPreferences("np", 0).edit().putBoolean("dolbySw", on).apply(); } catch (Throwable ignored) { } log("Dolby pela app: " + on); }
    /** Dolby pelo FFmpeg da app: ligado por omissão no telemóvel/tablet, desligado na TV (Definições guardadas em "np"/"dolbySw"). */
    boolean dolbySw() {
        try { android.content.SharedPreferences sp = act.getSharedPreferences("np", 0); if (sp.contains("dolbySw")) return sp.getBoolean("dolbySw", false); } catch (Throwable ignored) { }
        return !isTvDev();
    }
    /** v322: nos filmes/séries o acerto do som é guardado por título (cada ficheiro tem o seu desfasamento) e volta a aplicar-se sozinho. */
    private String avTitle() {
        try {
            if (!vodUrl || curUrl == null || curUrl.isEmpty()) return "";
            String u = curUrl; int q = u.indexOf('?'); if (q > 0) u = u.substring(0, q);
            return u.substring(u.lastIndexOf('/') + 1);
        } catch (Throwable e) { return ""; }
    }
    /** Acertos já medidos à mão (id do ficheiro → ms): valem logo, sem ninguém mexer. */
    private static Integer avSeed(String tk) {
        /* v328: sem acertos automáticos por título (o −1000 ms do Forgotten Island deixou de se aplicar sozinho).
           Só vale o que o utilizador acertar à mão e fica guardado por título. */
        return null;
    }
    private int titleAv(String tk) {
        try { android.content.SharedPreferences sp = act.getSharedPreferences("np", 0); if (sp.contains("av_t_" + tk)) return sp.getInt("av_t_" + tk, 0); } catch (Throwable ignored) { }
        Integer sd = avSeed(tk); return sd == null ? 0 : sd;
    }
    void loadAv() {
        try {
            String tk = avTitle();
            if (!tk.isEmpty() && act.getSharedPreferences("np", 0).contains("av_t_" + tk)) {
                avOffsetMs = titleAv(tk);
                if (avOffsetMs != 0 && selector != null) { try { selector.setParameters(selector.buildUponParameters().setTunnelingEnabled(false).build()); } catch (Throwable ignored) { } }
                log("acerto do som deste filme (" + tk + "): " + avOffsetMs + " ms");
                return;
            }
            String k = avKey();
            /* v336: só aplica se o utilizador gravou um valor; senão 0 (sem acerto por defeito) */
            if (act.getSharedPreferences("np", 0).contains(k))
                avOffsetMs = act.getSharedPreferences("np", 0).getInt(k, 0);
            else
                avOffsetMs = 0;
        } catch (Throwable ignored) { avOffsetMs = 0; }
    }
    private int capW = Integer.MAX_VALUE, capH = Integer.MAX_VALUE;
    private boolean srvCap = false; private String srvCapUrl = "";   /* limite posto por o servidor recusar (509) */   /* limite de resolução (vista múltipla) */
    private boolean liveGuess = false, userRewound = false;
    /* correções aos pedaços .ts dos canais HLS (vídeo desfasado do som, SPS de 1080i) */
    private final TsFix.State tsFix = new TsFix.State();
    /* v336: diagnóstico a cada 5 s */
    private volatile int sinkSampleRate = 0, sinkChannels = 0, declaredSampleRate = 0;
    private volatile long dropAccum = 0, dropAccumMs = 0;
    private long diagLastRend = -1, diagLastAt = 0;
    private int diagZeroN = 0; private long diagKickMs = 0;   /* v442: imagem parada com som a tocar */
    private final Runnable diagRun = new Runnable() {
        @Override public void run() {
            try { logDiag(); } catch (Throwable ignored) { }
            try { if (player != null && !userPaused) ui.postDelayed(this, 5000); } catch (Throwable ignored) { }
        }
    };
    private void startDiag() {
        try { ui.removeCallbacks(diagRun); ui.postDelayed(diagRun, 5000); } catch (Throwable ignored) { }
    }
    private void logDiag() {
        if (player == null) return;
        int st = player.getPlaybackState();
        if (st != Player.STATE_READY && st != Player.STATE_BUFFERING) return;
        androidx.media3.common.Format vf = player.getVideoFormat(), af = player.getAudioFormat();
        DecoderCounters vdc = player.getVideoDecoderCounters(), adc = player.getAudioDecoderCounters();
        if (vdc != null) vdc.ensureUpdated();
        if (adc != null) adc.ensureUpdated();
        long rend = vdc != null ? vdc.renderedOutputBufferCount : -1;
        long now = android.os.SystemClock.uptimeMillis();
        double fpsReal = -1;
        if (diagLastRend >= 0 && rend >= diagLastRend && diagLastAt > 0 && now > diagLastAt) {
            fpsReal = (rend - diagLastRend) * 1000.0 / (now - diagLastAt);
        }
        diagLastRend = rend; diagLastAt = now;
        /* v442: a imagem parou (nenhum fotograma novo) com o som a tocar: religa a superfície, no máximo uma vez a cada 20 s */
        if (fpsReal == 0.0 && !userPaused && player != null && player.getPlaybackState() == Player.STATE_READY && player.getPlayWhenReady()) {
            diagZeroN++;
            if (diagZeroN >= 2 && now - diagKickMs > 20000) {
                diagKickMs = now; diagZeroN = 0;
                log("imagem parada com som: religa a superfície");
                try { rebindView(); } catch (Throwable ignored) { }
            }
        } else diagZeroN = 0;
        float refresh = 0;
        try { refresh = act.getWindowManager().getDefaultDisplay().getRefreshRate(); } catch (Throwable ignored) { }
        boolean tun = false;
        try { if (selector != null) tun = selector.getParameters().tunnelingEnabled; } catch (Throwable ignored) { }
        StringBuilder sb = new StringBuilder("diag5s:");
        if (vf != null) sb.append(" vid ").append(vf.width).append("x").append(vf.height)
                .append(vf.frameRate > 0 ? " @" + Math.round(vf.frameRate * 10) / 10f + "fps" : "")
                .append(vf.sampleMimeType != null ? " " + vf.sampleMimeType.replace("video/", "") : "");
        if (!decName.isEmpty()) sb.append(" [").append(decName).append("]");
        if (vdc != null) {
            sb.append(" · rend=").append(vdc.renderedOutputBufferCount)
              .append(" skip=").append(vdc.skippedOutputBufferCount)
              .append(" dropIn=").append(vdc.droppedInputBufferCount)
              .append(" dropBuf=").append(vdc.droppedBufferCount)
              .append(" dropKF=").append(vdc.droppedToKeyframeCount);
        }
        if (fpsReal >= 0) sb.append(" · fpsReal=").append(Math.round(fpsReal * 10) / 10f);
        if (dropAccum > 0) sb.append(" · perdidos5s=").append(dropAccum).append(" em ").append(dropAccumMs).append("ms");
        dropAccum = 0; dropAccumMs = 0;
        sb.append(" · refresh=").append(Math.round(refresh)).append("Hz");
        sb.append(" · túnelEfectivo=").append(tun ? "sim" : "não");
        try { if (player.isCurrentMediaItemLive()) { long lo = player.getCurrentLiveOffset(); if (lo != C.TIME_UNSET) sb.append(" · atraso=").append(Math.round(lo / 100f) / 10f).append("s"); } sb.append(" · reserva=").append(Math.round(player.getTotalBufferedDuration() / 100f) / 10f).append("s"); } catch (Throwable ignored) { }
        if (liveSpd != 1f) sb.append(" · vel=").append(liveSpd);
        sb.append(" · TsFix=").append(tsFixEnabled() ? (tsFix.active ? "activo" : "ligado/inactivo") : "desligado");
        try { String ti = tsFix.info(); if (ti != null && !ti.isEmpty()) sb.append(" (").append(ti).append(")"); } catch (Throwable ignored) { }
        if (af != null) sb.append(" · somDecl=").append(af.sampleRate).append("Hz");
        sb.append(" sink=").append(sinkSampleRate).append("Hz/").append(sinkChannels).append("ch");
        if (adc != null) sb.append(" audRend=").append(adc.renderedOutputBufferCount)
                .append(" audSkip=").append(adc.skippedOutputBufferCount);
        sb.append(" · acerto=").append(avOffsetMs).append("ms");
        sb.append(texMode ? " · TextureView" : " · SurfaceView");
        log(sb.toString());
        /* v365: sugestão (não altera nada) quando a imagem perde fotogramas com o som descodificado pela app */
        if (fpsReal >= 0 && fpsReal < 18 && "dolbysw".equals(avKind) && player != null && player.isPlaying()) {
            if (++lowFpsTicks == 3) try { act.runOnUiThread(() -> android.widget.Toast.makeText(act, "A imagem está a perder fotogramas. Experimenta «Pelo aparelho / passthrough» nas Definições (som Dolby).", android.widget.Toast.LENGTH_LONG).show()); } catch (Throwable ignored) { }
        } else lowFpsTicks = 0;
    }
    private int lowFpsTicks = 0;
    private String decName = "";

    /** Limita a resolução do vídeo (0 = sem limite). Útil nos frames pequenos da vista múltipla. */
    void setMaxRes(int w, int h) {
        pvCapState = -1;
        capW = w > 0 ? w : Integer.MAX_VALUE;
        capH = h > 0 ? h : Integer.MAX_VALUE;
        try { if (selector != null) selector.setParameters(selector.buildUponParameters().setMaxVideoSize(capW, capH).build()); } catch (Throwable ignored) { }
    }

    private long rendLast = -1; private int rendDead = 0;
    /** Chamado de 5 em 5 s com vários frames: se a imagem não avança (mas o leitor diz que está a dar), religa a superfície e depois recarrega o canal. */
    void checkFrames() {
        try {
            if (player == null || userPaused || !wantVisible || box == null || box.getVisibility() != View.VISIBLE || curUrl.isEmpty() || !player.getPlayWhenReady() || player.getPlaybackState() != Player.STATE_READY || player.getVideoFormat() == null) { rendDead = 0; rendLast = -1; return; }   /* frame escondido: o decodificador pára sozinho, não é falha */
            /* v333: no caminho hardware da Bravia não forçamos reattach/reload — piora o problema. */
            if (preferHardwarePath()) { rendDead = 0; return; }
            androidx.media3.exoplayer.DecoderCounters dc = player.getVideoDecoderCounters();
            if (dc == null) return;
            dc.ensureUpdated();
            long n = dc.renderedOutputBufferCount;
            if (n != rendLast) { rendLast = n; rendDead = 0; return; }
            rendDead++;
            log("checkFrames: imagem parada (" + rendDead + ")");
            if (rendDead == 1) reattach.run();
            else if (rendDead >= 2) {
                rendDead = 0;
                MediaItem.Builder b = new MediaItem.Builder().setUri(curUrl);
                if (curMime != null) b.setMimeType(curMime);
                player.setMediaItem(b.build()); player.prepare(); player.play();
            }
        } catch (Throwable ignored) { }
    }

    /** Modo leve (frames extra com 3-4 frames): escolhe sempre a versão de menor débito, para a TV não perder fluidez. */
    void setLite(boolean on) {
        try { if (selector != null) selector.setParameters(selector.buildUponParameters().setForceLowestBitrate(on).setForceHighestSupportedBitrate(!on).build()); } catch (Throwable ignored) { }
    }

    /** Túnel só vale com 1 frame: com vários frames o túnel do principal deixa a imagem a preto (o som continua). */
    private boolean tunnelAllowed = true;
    private boolean texMode = false;
    private Boolean texOverride = null;
    void useTexture(boolean tex) { texOverride = tex; }
    /** TV: SurfaceView (directa, com desentrelaçamento do hardware) com 1 frame; TextureView com 2+ frames (várias SurfaceView deixavam o frame 1 preto).
     *  Devolve true se recriou as vistas (quem chama tem de voltar a abrir o canal). */
    boolean switchSurface(boolean tex) {
        boolean pref = false;
        try { pref = act.getSharedPreferences("np", 0).getBoolean("tvTexture", false); } catch (Throwable ignored) { }
        boolean target = tex || pref || !isTvDev();
        texOverride = tex;
        if (box != null && texMode == target) return false;
        if (box == null) return false;
        release();
        ttv = null; hdrSv = null; hdrOn = false; lastRect = null;
        return true;
    }
    void setTunnelAllowed(boolean allowed) {
        if (tunnelAllowed == allowed) return;
        tunnelAllowed = allowed;
        applyTunnelState();
    }

    /** Imagem parada com som (visto ao abrir o 2.º frame): se não saem frames novos em ~3,5 s, religa a superfície e, se for preciso, recarrega o canal. */
    void ensureVideoAlive() {
        try {
            if (player == null || curUrl.isEmpty()) return;
            /* v333: no caminho hardware da Bravia não forçamos reattach (causa timeout e frames perdidos). */
            if (preferHardwarePath()) return;
            long c0 = -1;
            androidx.media3.exoplayer.DecoderCounters dc = player.getVideoDecoderCounters();
            if (dc != null) { dc.ensureUpdated(); c0 = dc.renderedOutputBufferCount; }
            final long base = c0;
            ui.postDelayed(() -> {
                try {
                    if (player == null || userPaused || !wantVisible || box == null || box.getVisibility() != View.VISIBLE || !player.getPlayWhenReady() || player.getPlaybackState() != Player.STATE_READY) return;
                    if (player.getVideoFormat() == null) return;   /* só áudio */
                    androidx.media3.exoplayer.DecoderCounters d2 = player.getVideoDecoderCounters();
                    if (d2 == null) return; d2.ensureUpdated();
                    if (d2.renderedOutputBufferCount > base) return;
                    log("frame 1 preto com som: religa superfície e recarrega");
                    reattach.run();
                    ui.postDelayed(() -> {
                        try {
                            if (player == null) return;
                            androidx.media3.exoplayer.DecoderCounters d3 = player.getVideoDecoderCounters();
                            if (d3 != null) { d3.ensureUpdated(); if (d3.renderedOutputBufferCount > base) return; }
                            MediaItem.Builder b = new MediaItem.Builder().setUri(curUrl);
                            if (curMime != null) b.setMimeType(curMime);
                            player.setMediaItem(b.build()); player.prepare(); player.play();
                        } catch (Throwable ignored) { }
                    }, 2000);
                } catch (Throwable ignored) { }
            }, 3500);
        } catch (Throwable ignored) { }
    }

    /** Religa a superfície do vídeo (depois de mudar o número de frames). */
    volatile boolean gotFrame = false;
    private int liveRebufN = 0;   /* v448: paragens a meio do direto neste canal */
    /** Já apareceu pelo menos um frame de imagem neste vídeo. */
    boolean hasFrame() { return gotFrame; }
    /** v335: instante do 1.º frame (para atrasar AFR e congelar o tamanho da superfície). */
    private long firstFrameAtMs = 0;
    /** v335: na TV, depois do 1.º frame não redimensionar a superfície enquanto o mesmo canal corre. */
    private boolean surfaceFrozen = false;

    /** Ecrã total: só religa a superfície se a imagem estiver mesmo parada (religar à força faz o leitor voltar a carregar: soluço de vários segundos). */
    void reattachIfStalled() {
        ui.post(() -> {
            try {
                if (player == null) return;
                /* v333: no caminho hardware (túnel + SurfaceView) religar a superfície é o que causa
                   Detaching surface timed out e frames perdidos em massa na Bravia. Só actuamos se realmente
                   necessário e com mais tolerância. */
                if (preferHardwarePath()) {
                    log("ecrã total: caminho hardware — sem religar superfície por stall");
                    return;
                }
                androidx.media3.exoplayer.DecoderCounters dc = player.getVideoDecoderCounters();
                if (dc == null) return;
                dc.ensureUpdated();
                final long n0 = dc.renderedOutputBufferCount;
                ui.postDelayed(() -> {
                    try {
                        if (player == null || userPaused) return;
                        androidx.media3.exoplayer.DecoderCounters d2 = player.getVideoDecoderCounters();
                        if (d2 == null) return;
                        d2.ensureUpdated();
                        boolean moving = d2.renderedOutputBufferCount != n0;
                        if (!moving && player.getPlaybackState() == Player.STATE_READY && player.getPlayWhenReady()) {
                            /* v285: nos filmes não religa (no diário a imagem estava a andar: falso alarme logo a seguir a mudar para 24 Hz, e religar já deixou o descodificador da TV preso) */
                            if (vodUrl) { log("ecrã total: sem imagens novas em 0,45 s (filme) — sem religar"); return; }
                            log("ecrã total: imagem parada, religa superfície"); reattach.run();
                        }
                    } catch (Throwable ignored) { }
                }, 450);
            } catch (Throwable ignored) { }
        });
    }
    void reattachSurface() { try { ui.removeCallbacks(reattach); ui.post(reattach); } catch (Throwable ignored) { } }

    private boolean isTvDev() {
        /* v408: além do modo TV, o recurso «leanback» (Android TV) também conta: o limite da pré-visualização (960x540)
           não pode apanhar a TV, senão o canal desce para 720p/540p e troca de qualidade com paragens */
        try { if (act.getPackageManager().hasSystemFeature("android.software.leanback")) return true; } catch (Throwable ignored) { }
        try { android.app.UiModeManager um = (android.app.UiModeManager) act.getSystemService(android.content.Context.UI_MODE_SERVICE); return um != null && um.getCurrentModeType() == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION; } catch (Throwable e) { return false; }
    }

    /** Estatísticas para o ecrã de informação. */
    String stats() {
        try {
            if (player == null) return "Sem vídeo a dar.";
            Format f = player.getVideoFormat(), a = player.getAudioFormat();
            DecoderCounters dc = player.getVideoDecoderCounters();
            if (dc != null) dc.ensureUpdated();
            StringBuilder sb = new StringBuilder();
            if (f != null) {
                sb.append(f.width).append("×").append(f.height);
                if (f.frameRate > 0) sb.append(" · ").append(Math.round(f.frameRate * 10f) / 10f).append(" fps");
                if (f.sampleMimeType != null) sb.append(" · ").append(f.sampleMimeType.replace("video/", ""));
                if (f.bitrate > 0) sb.append(" · ").append(Math.round(f.bitrate / 1e5f) / 10f).append(" Mbps");
            } else sb.append("sem vídeo");
            sb.append("\n");
            if (decName.length() > 0) sb.append(decName).append(" · ");
            if (dc != null) sb.append("perdidos ").append(dc.droppedBufferCount).append(" · ");
            sb.append("buffer ").append(player.getTotalBufferedDuration() / 1000).append(" s");
            if (player.isCurrentMediaItemLive()) { long o = player.getCurrentLiveOffset(); if (o != C.TIME_UNSET) sb.append(" · atraso ").append(Math.round(o / 100f) / 10f).append(" s"); }
            if (a != null && a.sampleMimeType != null) sb.append(" · ").append(a.sampleMimeType.replace("audio/", "")).append(a.channelCount > 0 ? " " + a.channelCount + "c" : "");
            try { if (selector != null && selector.getParameters().tunnelingEnabled) sb.append(" · túnel"); } catch (Throwable ignored) { }
            if (capW != Integer.MAX_VALUE) sb.append(" · máx ").append(capH).append("p");
            { String fx = tsFix.info(); if (fx.length() > 0) sb.append(" · ").append(fx); }
            return sb.toString();
        } catch (Throwable e) { return "Sem estatísticas: " + e; }
    }

    private final Runnable liveCheck = new Runnable() {
        @Override public void run() {
            try {
                if (player == null) return;
                if (liveGuess && !userRewound && !userPaused && player.isCurrentMediaItemLive() && player.getPlaybackState() == Player.STATE_READY) {
                    long off = player.getCurrentLiveOffset();
                    if (off != C.TIME_UNSET && off > 25000) { log("atraso " + off + " ms: salta para o direto"); player.seekToDefaultPosition(); }
                }
            } catch (Throwable ignored) { }
            if (player != null) ui.postDelayed(this, 10000);
        }
    };
    private String aspect = "fit", aspectLabel = "Ajustar";
    private boolean full = false;
    private android.widget.LinearLayout ctl;
    private TextView ctlAspect, ctlFull;

    /** Formato da imagem: fit (ajustar), zoom (preencher, corta), stretch (esticar), 16:9, 4:3, 21:9. */
    public void setAspect(String mode, String label) {
        aspect = mode == null || mode.isEmpty() ? "fit" : mode;
        aspectLabel = label == null || label.isEmpty() ? aspect : label;
        ensureViews();
        applyAspect();
        if (ctlAspect != null) NIcons.set(ctlAspect, "▭  " + aspectLabel);
    }

    private boolean previewMode = false;
    /** Na pré-visualização do Início não há botão de formato (esticar). */
    private boolean wasPv = false;   /* a pré-visualização do Início estava a dar mesmo antes deste pedido */
    private int pvCapState = -1;   /* -1 = por aplicar, 0 = sem limite, 1 = pré-visualização */
    /** Pré-visualização pequena: não vale a pena descodificar 1080p/4K (poupa dados, bateria e CPU). Em ecrã total volta ao automático. */
    private void applyPreviewCap() {
        try {
            if (srvCap) return;
            /* v296: na TV a miniatura já usa a qualidade toda: ao passar para ecrã total não há troca de qualidade
               (a troca obrigava o descodificador da TV a recomeçar e o ecrã ficava preto uns segundos) */
            int want = (previewMode && !full && !isTvDev()) ? 1 : 0;
            if (want == pvCapState) return;
            if (want == 0) { setMaxRes(0, 0); pvCapState = 0; return; }
            boolean metered = false;
            try { android.net.ConnectivityManager cm = (android.net.ConnectivityManager) act.getSystemService(android.content.Context.CONNECTIVITY_SERVICE); metered = cm != null && cm.isActiveNetworkMetered(); } catch (Throwable ignored) { }
            /* v437: o limite só existe em dados móveis (poupança); em Wi-Fi a miniatura usa a melhor qualidade */
            if (!metered) { setMaxRes(0, 0); pvCapState = 0; return; }
            setMaxRes(640, 360);
            pvCapState = 1;
            log("pré-visualização: limite 640x360 (dados móveis)");
        } catch (Throwable ignored) { }
    }

    public void setPreview(boolean p) {
        if (!p && previewMode) wasPv = true;
        previewMode = p;
        applyPreviewCap();
        if (ctlAspect != null) ctlAspect.setVisibility(p ? View.GONE : View.VISIBLE);
    }

    public void setFull(boolean f) {
        full = f;
        /* v335: ao entrar em ecrã total permite um redimensionamento para MATCH_PARENT, depois volta a congelar. */
        if (f && isTvDev()) surfaceFrozen = false;
        applyPreviewCap();
        /* v437: em ecrã total escolhe sempre a variante mais alta (1080p/4K quando o canal a oferece), sem esperar pelo buffer do ABR */
        try { if (selector != null) selector.setParameters(selector.buildUponParameters().setForceHighestSupportedBitrate(f).build()); } catch (Throwable ignored) { }
        applyTunnelState();   /* v334: túnel só em ecrã total na Bravia */
        if (f) matchRefresh();   /* v281: a taxa de atualização só muda em ecrã total */
        /* ecrã total: o vídeo também ocupa a zona do recorte da câmara (senão fica uma faixa preta nesse lado) */
        try {
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                android.view.WindowManager.LayoutParams wl = act.getWindow().getAttributes();
                wl.layoutInDisplayCutoutMode = f
                        ? (android.os.Build.VERSION.SDK_INT >= 30 ? android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                                                                  : android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES)
                        : android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
                act.getWindow().setAttributes(wl);
            }
        } catch (Throwable ignored) { }
        applyRect();
        /* v341: não congelar superfície (mantinha tamanhos errados e não reduzia drops). */
        /* v276: ao mudar de tamanho (pré-visualização → ecrã total) o leitor ficava a carregar ~4 s (diário de 4/11): verifica e religa */
        try { arTries = 0; ui.removeCallbacks(afterResize); ui.postDelayed(afterResize, 900); } catch (Throwable ignored) { }
        /* v281: da miniatura para ecrã total (mesma ligação) o som ficava desfasado (RTP 1 UHD): realinha uma vez */
        /* v293: da miniatura para ecrã total na TV a imagem ficava preta (só som): já não faz o salto de ressincronização
           (que na TV deixava a imagem por mostrar) e verifica 1,5 s depois se a imagem está mesmo a aparecer; se não, religa-a */
        if (f && pvToFull) {
            pvToFull = false; ui.removeCallbacks(fullCheck);
            /* v333 (Bravia/Sony + MediaTek): hardRebind (esconder/mostrar superfície) provocava
               Detaching surface timed out + centenas de frames perdidos. Com túnel activo a superfície
               deve permanecer estável; só se verifica se a imagem aparece após um atraso maior. */
            if (ttv == null && isTvDev()) {
                if (preferHardwarePath()) {
                    log("ecrã total (da miniatura): caminho hardware — sem recriar superfície");
                    ui.postDelayed(fullCheck, 2800);
                } else {
                    ui.postDelayed(this::hardRebind, 250);
                    ui.postDelayed(fullCheck, 2200);
                }
            } else {
                ui.postDelayed(fullCheck, 1500);
            }
        }
        if (!f) schedulePicFix();   /* v308: voltar da janela inteira para a janela do Explorar na TV deixava a imagem preta */
        if (ctlFull != null) NIcons.set(ctlFull, full ? "✕  Sair do ecrã total" : "⛶  Ecrã total");
    }

    private void applyAspect() {
        if (view == null || box == null) return;
        if (ttv != null) {
            view.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
            applyTexture();
            applyDeint();
            view.removeCallbacks(reportAspect);
            view.postDelayed(reportAspect, 600);
            return;
        }
        View sv0 = view.getVideoSurfaceView();
        if (sv0 instanceof android.view.TextureView) {
            /* telemóvel (TextureView): ajustar sempre em FIT e aplicar a escala nós próprios; não depende dos modos do PlayerView */
            view.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
            view.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            view.post(this::applyScale);
            view.removeCallbacks(reportAspect);
            view.postDelayed(reportAspect, 600);
            return;
        }
        if (sv0 instanceof android.view.SurfaceView && isTvDev()) {
            /* v307: na TV, mudar o tamanho da SurfaceView (esticar, zoom, 4:3…) fazia o descodificador MediaTek parar e o direto ficar atrasado.
               A superfície fica sempre do mesmo tamanho (ajustada) e o formato aplica-se com escala, que é feita pelo compositor sem mexer no vídeo. */
            view.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
            FrameLayout.LayoutParams lp0 = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
            if (view.getLayoutParams() instanceof FrameLayout.LayoutParams) { FrameLayout.LayoutParams cur = (FrameLayout.LayoutParams) view.getLayoutParams(); if (cur.width != lp0.width || cur.height != lp0.height || cur.gravity != lp0.gravity) view.setLayoutParams(lp0); }
            else view.setLayoutParams(lp0);
            view.post(this::applyScale);
            view.postDelayed(this::applyScale, 300);
            view.removeCallbacks(reportAspect);
            view.postDelayed(reportAspect, 600);
            return;
        }
        int bw = box.getWidth(), bh = box.getHeight();
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        lp.gravity = Gravity.CENTER;
        int mode = AspectRatioFrameLayout.RESIZE_MODE_FIT;
        float r = 0f;
        if ("zoom".equals(aspect)) mode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM;
        else if ("stretch".equals(aspect)) mode = AspectRatioFrameLayout.RESIZE_MODE_FILL;
        else if ("16:9".equals(aspect)) r = 16f / 9f;
        else if ("4:3".equals(aspect)) r = 4f / 3f;
        else if ("21:9".equals(aspect)) r = 21f / 9f;
        if (r > 0f) {
            mode = AspectRatioFrameLayout.RESIZE_MODE_FILL;
            if (bw > 0 && bh > 0) {
                int w = bw, h = Math.round(bw / r);
                if (h > bh) { h = bh; w = Math.round(bh * r); }
                lp.width = w; lp.height = h;
            }
        }
        view.setResizeMode(mode);
        view.setLayoutParams(lp);
        view.removeCallbacks(reportAspect);
        view.postDelayed(reportAspect, 600);
    }

    /** Telemóvel: conteúdo HDR / Dolby Vision vai para uma SurfaceView em modo de cor HDR; o resto continua na TextureView. */
    private void updateHdrSurface() {
        try {
            if (player == null || ttv == null || hdrSv == null) return;
            androidx.media3.common.Format f = player.getVideoFormat();
            if (f == null) return;
            String codecs = f.codecs == null ? "" : f.codecs.toLowerCase(java.util.Locale.ROOT);
            boolean dv = androidx.media3.common.MimeTypes.VIDEO_DOLBY_VISION.equals(f.sampleMimeType) || codecs.startsWith("dvh") || codecs.startsWith("dva");
            boolean hdr = dv || (f.colorInfo != null && (f.colorInfo.colorTransfer == C.COLOR_TRANSFER_ST2084 || f.colorInfo.colorTransfer == C.COLOR_TRANSFER_HLG));
            hdrContent = hdr; applyDeint();
            boolean dv5 = codecs.matches("^dv(he|h1|av|a1)\\.05.*");
            if (dv5 && !dv5Warned) {
                dv5Warned = true;
                listener.onEvent("hdr:dv5", codecs);
                if (label != null) {
                    label.setText("Dolby Vision perfil 5\nEste telemóvel não mostra este perfil com as cores certas.\nUsa uma versão HDR10 ou SDR do ficheiro.");
                    label.setVisibility(View.VISIBLE); label.removeCallbacks(hideLabel); label.postDelayed(hideLabel, 9000);
                }
            } else if (!dv5) dv5Warned = false;
            if (!HDR_SURFACE) return;
            if (hdr == hdrOn) return;
            hdrOn = hdr;
            applyDeint();
            if (hdr) {
                player.setVideoSurfaceView(hdrSv);
                ttv.setVisibility(View.GONE); hdrSv.setVisibility(View.VISIBLE);
                try { act.getWindow().setColorMode(android.content.pm.ActivityInfo.COLOR_MODE_HDR); } catch (Throwable ignored) { }
            } else {
                player.setVideoTextureView(ttv);
                hdrSv.setVisibility(View.GONE); ttv.setVisibility(View.VISIBLE);
                try { act.getWindow().setColorMode(android.content.pm.ActivityInfo.COLOR_MODE_DEFAULT); } catch (Throwable ignored) { }
            }
            applyAspect();
        } catch (Throwable ignored) { }
    }

    /** Telemóvel: dá à TextureView o tamanho exato do formato pedido; a TextureView estica a imagem até aos seus limites e a caixa corta o que sobra. */
    private void applyTexture() {
        try {
            if (ttv == null || box == null) return;
            float bw = box.getWidth(), bh = box.getHeight();
            if (bw <= 0 || bh <= 0) return;
            final View tgt = hdrOn && hdrSv != null ? hdrSv : ttv;
            if (fxApplied) { tgt.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)); return; }
            androidx.media3.common.VideoSize vs = player != null ? player.getVideoSize() : null;
            float vw = 0f, vh = 0f;
            if (vs != null && vs.width > 0 && vs.height > 0) { vw = vs.width * (vs.pixelWidthHeightRatio > 0 ? vs.pixelWidthHeightRatio : 1f); vh = vs.height; }
            float tw, th;
            if ("stretch".equals(aspect)) { tw = bw; th = bh; }
            else {
                float r = "16:9".equals(aspect) ? 16f / 9f : "4:3".equals(aspect) ? 4f / 3f : "21:9".equals(aspect) ? 21f / 9f : (vh > 0 ? vw / vh : bw / bh);
                /* retângulo "ajustar" para a proporção r dentro da caixa */
                float fw = bw, fh = bw / r;
                if (fh > bh) { fh = bh; fw = bh * r; }
                if ("zoom".equals(aspect)) {
                    float k = Math.max(bw / fw, bh / fh); tw = fw * k; th = fh * k;
                } else { tw = fw; th = fh; }
            }
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Math.round(tw), Math.round(th));
            lp.gravity = Gravity.CENTER;
            tgt.setLayoutParams(lp);
            tgt.setScaleX(1f); tgt.setScaleY(1f);
        } catch (Throwable ignored) { }
    }

    /** TextureView: escala a superfície (já ajustada em FIT) até ao retângulo pedido pelo formato. */
    private void applyScale() {
        try {
            if (view == null || box == null) return;
            View sv = view.getVideoSurfaceView();
            if (!(sv instanceof android.view.TextureView) && !(sv instanceof android.view.SurfaceView && ttv == null && isTvDev())) return;
            float bw = box.getWidth(), bh = box.getHeight(), fw = sv.getWidth(), fh = sv.getHeight();
            if (bw <= 0 || bh <= 0 || fw <= 0 || fh <= 0) return;
            float tw = fw, th = fh;
            if ("stretch".equals(aspect)) { tw = bw; th = bh; }
            else if ("zoom".equals(aspect)) { float k = Math.max(bw / fw, bh / fh); tw = fw * k; th = fh * k; }
            else {
                float r = "16:9".equals(aspect) ? 16f / 9f : "4:3".equals(aspect) ? 4f / 3f : "21:9".equals(aspect) ? 21f / 9f : 0f;
                if (r > 0f) { tw = bw; th = bw / r; if (th > bh) { th = bh; tw = bh * r; } }
            }
            sv.setPivotX(fw / 2f); sv.setPivotY(fh / 2f);
            sv.setScaleX(tw / fw); sv.setScaleY(th / fh);
        } catch (Throwable ignored) { }
    }

    private final Runnable reportAspect = this::reportAspectNow;

    private void reportAspectNow() {
        try {
            androidx.media3.common.VideoSize vs = player != null ? player.getVideoSize() : null;
            View sv = ttv != null ? ttv : (view != null ? view.getVideoSurfaceView() : null);
            String info = aspect + "|" + (vs != null ? vs.width + "x" + vs.height : "?") + "|" + (box != null ? box.getWidth() + "x" + box.getHeight() : "?") + "|" + (sv != null ? sv.getWidth() + "x" + sv.getHeight() : "?");
            listener.onEvent("aspect:info", info);
        } catch (Throwable ignored) { }
    }

    private final Runnable hideCtl = () -> { if (ctl != null) ctl.setVisibility(View.GONE); if (this.seekWrap != null) this.seekWrap.setVisibility(View.GONE); };

    /* barra de progresso (filmes/episódios): aparece com os botões, ao tocar no vídeo */
    private android.widget.LinearLayout seekWrap;
    private android.widget.SeekBar seekBar;
    private TextView seekPos, seekDur;
    private boolean seeking = false;
    private long seekTempUntil = 0;

    private static String fmtT(long ms) {
        long s = Math.max(0, ms / 1000), h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        return h > 0 ? String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec) : String.format(java.util.Locale.US, "%d:%02d", m, sec);
    }

    private boolean seekable() {
        try { return player != null && !player.isCurrentMediaItemLive() && player.getDuration() > 0 && player.getDuration() != C.TIME_UNSET; } catch (Throwable e) { return false; }
    }

    private void updateSeekVis() {
        if (seekWrap == null || ctl == null) return;
        boolean want = (ctl.getVisibility() == View.VISIBLE || System.currentTimeMillis() < seekTempUntil) && seekable() && full;   /* v291: fora do ecrã total há a barra do ecrã do canal (uma só barra) */
        seekWrap.setVisibility(want ? View.VISIBLE : View.GONE);
        if (seekWrap.getVisibility() == View.VISIBLE) updateSeekPos();
    }

    private void updateSeekPos() {
        if (seekBar == null || seeking || !seekable()) return;
        long d = player.getDuration(), p = Math.min(player.getCurrentPosition(), d);
        seekBar.setProgress((int) (p * 1000L / d));
        seekPos.setText(fmtT(p));
        seekDur.setText(remain(p, d));
    }
    /** «−1:23:45 · 2:18:06»: o que falta e a duração total. */
    static String remain(long p, long d) { return "−" + fmtT(Math.max(0, d - p)) + "  ·  " + fmtT(d); }

    private void buildSeek() {
        seekWrap = new android.widget.LinearLayout(act);
        seekWrap.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        seekWrap.setGravity(Gravity.CENTER_VERTICAL);
        seekWrap.setBackgroundColor(0xAA000000);
        seekWrap.setPadding(24, 8, 24, 8);
        seekPos = new TextView(act);
        seekPos.setTextColor(Color.WHITE);
        seekPos.setTextSize(15f);
        seekPos.setText("0:00");
        seekDur = new TextView(act);
        seekDur.setTextColor(Color.WHITE);
        seekDur.setTextSize(15f);
        seekDur.setText("0:00");
        seekBar = new android.widget.SeekBar(act);
        seekBar.setMax(1000);
        seekBar.setFocusable(false);
        seekBar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar sb, int progress, boolean fromUser) {
                if (fromUser && seekable()) seekPos.setText(fmtT(player.getDuration() * progress / 1000L));
            }
            @Override public void onStartTrackingTouch(android.widget.SeekBar sb) { seeking = true; if (box != null) box.removeCallbacks(hideCtl); }
            @Override public void onStopTrackingTouch(android.widget.SeekBar sb) {
                if (seekable()) player.seekTo(player.getDuration() * sb.getProgress() / 1000L);
                seeking = false;
                if (box != null) { box.removeCallbacks(hideCtl); box.postDelayed(hideCtl, 3500); }
            }
        });
        android.widget.LinearLayout.LayoutParams bp = new android.widget.LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        bp.leftMargin = 16; bp.rightMargin = 16;
        seekWrap.addView(seekPos);
        seekWrap.addView(seekBar, bp);
        seekWrap.addView(seekDur);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.BOTTOM;
        seekWrap.setVisibility(View.GONE);
        box.addView(seekWrap, lp);
    }

    private TextView ctlBtn(String t, final String ev) {
        TextView b = new TextView(act);
        float d = act.getResources().getDisplayMetrics().density;
        NIcons.set(b, t);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14f);
        b.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD));
        b.setLetterSpacing(0.02f);
        b.setGravity(Gravity.CENTER);
        b.setPadding((int) (18 * d), (int) (10 * d), (int) (18 * d), (int) (10 * d));
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(0xB3141E32); g.setCornerRadius(28 * d); g.setStroke((int) Math.max(1, d), 0x45FFFFFF);
        b.setBackground(g);
        b.setElevation(6 * d);
        b.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (a == android.view.MotionEvent.ACTION_DOWN) v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start();
            else if (a == android.view.MotionEvent.ACTION_UP || a == android.view.MotionEvent.ACTION_CANCEL) v.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
            return false;
        });
        b.setOnClickListener(v -> { listener.onEvent("ui", ev); if (box != null) { box.removeCallbacks(hideCtl); box.postDelayed(hideCtl, 3500); } });
        return b;
    }

    private void buildCtl() {
        ctl = new android.widget.LinearLayout(act) {
            private void sv(int v) { super.setVisibility(v); }
            /* aparece a deslizar de cima com fade; some com fade */
            @Override public void setVisibility(int v) {
                float d = getResources().getDisplayMetrics().density;
                if (v == VISIBLE && getVisibility() != VISIBLE) {
                    sv(v); animate().cancel(); setAlpha(0f); setTranslationY(-14 * d);
                    animate().alpha(1f).translationY(0f).setDuration(240).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
                } else if (v != VISIBLE && getVisibility() == VISIBLE) {
                    animate().cancel();
                    animate().alpha(0f).translationY(-10 * d).setDuration(180).withEndAction(() -> sv(v)).start();
                } else sv(v);
            }
        };
        ctl.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        ctlAspect = ctlBtn("▭  " + aspectLabel, "aspect");
        ctlFull = ctlBtn(full ? "✕  Sair do ecrã total" : "⛶  Ecrã total", "full");
        android.widget.LinearLayout.LayoutParams gap = new android.widget.LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gap.rightMargin = 12;
        ctl.addView(ctlAspect, gap);
        if (previewMode) ctlAspect.setVisibility(View.GONE);
        ctl.addView(ctlFull);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.TOP | Gravity.RIGHT;
        lp.topMargin = 16; lp.rightMargin = 16;
        ctl.setVisibility(View.GONE);
        box.addView(ctl, lp);
        buildSeek();
        /* toque no vídeo mostra/esconde os botões (telemóvel) */
        box.setClickable(true);
        final android.view.GestureDetector gd = new android.view.GestureDetector(act, new android.view.GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(android.view.MotionEvent e) { gStart = -1f; gMode = 0; gLastVol = -1; return true; }
            /* ecrã total: deslizar na metade direita = volume, na esquerda = brilho (de baixo para cima aumenta) */
            @Override public boolean onScroll(android.view.MotionEvent e1, android.view.MotionEvent e2, float dx, float dy) {
                try {
                    if (e1 == null || e2 == null || box == null || box.getHeight() <= 0) return false;
                    android.view.View dv = act.getWindow().getDecorView();
                    if (box.getWidth() < dv.getWidth() * 0.85f || box.getHeight() < dv.getHeight() * 0.85f) return false;
                    float ddy = e1.getY() - e2.getY(), ddx = e2.getX() - e1.getX();
                    if (gMode == 0) {
                        if (Math.abs(ddy) < 10 * act.getResources().getDisplayMetrics().density * 0.5f || Math.abs(ddy) < Math.abs(ddx) * 1.2f) return false;   /* v268: começa mais cedo */
                        gMode = e1.getX() < box.getWidth() / 2f ? 2 : 1;
                        if (gMode == 1) {
                            android.media.AudioManager am = (android.media.AudioManager) act.getSystemService(android.content.Context.AUDIO_SERVICE);
                            gStart = am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC);
                        } else {
                            float b = act.getWindow().getAttributes().screenBrightness;
                            if (b < 0) { try { b = android.provider.Settings.System.getInt(act.getContentResolver(), android.provider.Settings.System.SCREEN_BRIGHTNESS) / 255f; } catch (Throwable t) { b = 0.5f; } }
                            gStart = b;
                        }
                    }
                    float frac = ddy / (box.getHeight() * 0.8f);
                    if (gMode == 1) {
                        android.media.AudioManager am = (android.media.AudioManager) act.getSystemService(android.content.Context.AUDIO_SERVICE);
                        int max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC);
                        int v = Math.max(0, Math.min(max, Math.round(gStart + frac * max)));
                        if (v != gLastVol) { gLastVol = v; am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, v, 0); }   /* v268: só quando muda de degrau */
                        lastGestLevel = v / (float) Math.max(1, max); gestIcon = v == 0 ? "🔇" : (lastGestLevel < 0.5f ? "🔉" : "🔊");
                    } else {
                        float b = Math.max(0.02f, Math.min(1f, gStart + frac));
                        userBright = b; gPendBright = b;
                        /* v268: o brilho da janela muda no máximo uma vez por imagem do ecrã (cada mudança obriga a janela a refazer-se) */
                        if (!gBrightPosted) { gBrightPosted = true; box.postOnAnimation(() -> { gBrightPosted = false; try {
                            android.view.WindowManager.LayoutParams lp = act.getWindow().getAttributes();
                            if (Math.abs(lp.screenBrightness - gPendBright) > 0.004f) { lp.screenBrightness = gPendBright; act.getWindow().setAttributes(lp); } } catch (Throwable ignored) { } }); }
                        lastGestLevel = b; gestIcon = "☀️";
                    }
                    showGest(gMode == 1, gMode == 1 ? lastGestLevel : lastGestLevel, gestIcon);
                    return true;
                } catch (Throwable t) { return false; }
            }
            @Override public boolean onDoubleTap(android.view.MotionEvent e) { listener.onEvent("ui", "full"); return true; }
            @Override public boolean onSingleTapConfirmed(android.view.MotionEvent e) {
                try { listener.onEvent("ui", "tap"); } catch (Throwable ignored) { }   /* vários frames: o toque escolhe o frame e o seu som */
                if (!full) return true;   /* fora do ecrã total o ecrã já tem os seus botões (⛶, Ajustar): sem sobreposição «Esticar / Ecrã total» */
                if (ctl.getVisibility() == View.VISIBLE) { ctl.setVisibility(View.GONE); box.removeCallbacks(hideCtl); updateSeekVis(); }
                else { ctl.setVisibility(View.VISIBLE); box.removeCallbacks(hideCtl); box.postDelayed(hideCtl, 3500); updateSeekVis(); }
                return true;
            }
        });
        box.setOnTouchListener((v, ev) -> gd.onTouchEvent(ev));
        box.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> { if ((r - l) != (or - ol) || (b - t) != (ob - ot)) { view.post(this::applyAspect); } });
    }
    private boolean afr = true;
    private int lastMode = 0;
    /** Brilho escolhido por gesto (-1 = o do sistema); a MainActivity repõe-no depois de escurecer. */
    static float userBright = -1f;
    private float gStart = -1f;
    private int gMode = 0;
    private float lastGestLevel = 0f;
    private int gLastVol = -1; private float gPendBright = -1f; private boolean gBrightPosted = false; private int gHudSide = -1;
    private String gestIcon = "🔊";
    private GestHud gestHud;

    /** Barra moderna de volume (direita) / brilho (esquerda). */
    private void showGest(boolean right, float level, String icon) {
        if (box == null) return;
        if (gestHud == null) {
            gestHud = new GestHud(act);
            box.addView(gestHud);
        }
        /* v268: o lugar da barra só se refaz quando muda de lado (antes refazia o layout a cada movimento do dedo) */
        int side = right ? 1 : 0;
        if (side != gHudSide || gestHud.getVisibility() != View.VISIBLE) {
            gHudSide = side;
            float d = act.getResources().getDisplayMetrics().density;
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) (64 * d), (int) (230 * d));
            lp.gravity = Gravity.CENTER_VERTICAL | (right ? Gravity.RIGHT : Gravity.LEFT);
            lp.leftMargin = (int) (36 * d); lp.rightMargin = (int) (36 * d);
            gestHud.setLayoutParams(lp);
            gestHud.bringToFront();
        }
        gestHud.show(level, icon);
    }

    /** Acompanhar a taxa de atualização: liga/desliga a troca do modo do ecrã da TV. */
    public void setAfr(boolean on) { afr = on; if (on) matchRefresh(); else setDisplayMode(0); }

    /** Escolhe o modo do ecrã (mesma resolução) cuja taxa é um múltiplo exato da taxa do vídeo (24→24/48/72/120, 25→50, 30→60, 50→50/100...). */
    private void matchRefresh() {
        if (!afr || player == null || android.os.Build.VERSION.SDK_INT < 23) return;
        if (previewMode && !full) return;   /* v281: a miniatura do Início não muda o modo da TV (o ecrã total muda) */
        /* v335: nos primeiros 5 s após o 1.º frame não muda a taxa — na Bravia a troca de modo
           a meio do arranque coincide com o início dos frames perdidos em massa. */
        if (isTvDev() && firstFrameAtMs > 0 && android.os.SystemClock.uptimeMillis() - firstFrameAtMs < 5000) {
            ui.postDelayed(this::matchRefresh, 5200);
            return;
        }
        try {
            Format f = player.getVideoFormat();
            if (f == null || f.frameRate <= 0) return;
            /* v343: 23.976 → tratar como 24 para casar modos 24/48 Hz da TV. */
            float fpsRaw = f.frameRate;
            final float fps = (fpsRaw > 23.5f && fpsRaw < 24.5f) ? 24f
                    : (fpsRaw > 29.5f && fpsRaw < 30.5f) ? 30f
                    : (fpsRaw > 24.5f && fpsRaw < 25.5f) ? 25f
                    : fpsRaw;
            android.view.Display d = act.getWindowManager().getDefaultDisplay();
            android.view.Display.Mode cur = d.getMode();
            /* v295/v343: 25→50 ou 30→60 já servem (múltiplo ≤2). Filme 24 fps em 60 Hz NÃO serve
               (2,5×) — continua à procura de 24/48 Hz. */
            { float r0 = cur.getRefreshRate(); int m0 = Math.max(1, Math.round(r0 / fps));
              boolean film24on60 = fps >= 23.5f && fps <= 24.5f && r0 >= 59f && r0 <= 61f;
              if (!film24on60 && Math.abs(r0 - fps * m0) <= 0.6f && m0 <= 2) return;
            }
            android.view.Display.Mode best = null; float bestErr = 1e9f; int bestMul = 99;
            for (android.view.Display.Mode m : d.getSupportedModes()) {
                if (m.getPhysicalWidth() != cur.getPhysicalWidth() || m.getPhysicalHeight() != cur.getPhysicalHeight()) continue;
                float r = m.getRefreshRate();
                int mul = Math.max(1, Math.round(r / fps));
                float err = Math.abs(r - fps * mul);
                if (err > 0.6f) continue;
                /* v343: em ~24 fps preferir 24 ou 48 Hz a 72/120 (arranque mais rápido, menos judder residual). */
                int mulScore = mul;
                if (fps >= 23.5f && fps <= 24.5f) {
                    if (mul == 1 || mul == 2) mulScore = mul; /* 24 / 48 */
                    else mulScore = mul + 10;                 /* 72/120 menos prioritário */
                }
                if (err < bestErr - 0.05f || (Math.abs(err - bestErr) <= 0.05f && mulScore < bestMul)) {
                    best = m; bestErr = err; bestMul = mulScore;
                }
            }
            if (best != null && best.getModeId() != cur.getModeId()) {
                setDisplayMode(best.getModeId());
                final int hz = Math.round(best.getRefreshRate());
                if (label != null && full) { label.setText("A ajustar a TV para " + hz + " Hz…"); label.setVisibility(View.VISIBLE); label.removeCallbacks(hideLabel); label.postDelayed(hideLabel, 4500); }
                log("taxa de atualização: " + Math.round(cur.getRefreshRate()) + " → " + hz + " Hz (vídeo " + fpsRaw + " fps)");
            }
        } catch (Throwable ignored) { }
    }

    private void setDisplayMode(final int id) {
        if (id == lastMode) return;
        lastMode = id;
        act.runOnUiThread(() -> {
            try {
                android.view.WindowManager.LayoutParams lp = act.getWindow().getAttributes();
                lp.preferredDisplayModeId = id;
                act.getWindow().setAttributes(lp);
            } catch (Throwable ignored) { }
        });
    }

    /** Desentrelaçamento adaptativo na GPU (experimental). Falha em silêncio e volta ao vídeo normal. */
    public void setDeint(boolean on) { deint = on; applyDeint(); }
    /** v298: modo do desentrelaçamento e nitidez para canais SD. */
    private int deintMode = DeinterlaceEffect.ADAPT; private float sdSharp = 0f;
    public void setDeintMode(int mode, float sharpSd) {
        boolean ch = mode != deintMode || sharpSd != sdSharp;
        deintMode = mode; sdSharp = sharpSd;
        if (ch) { fxKey = ""; applyDeint(); }
    }
    /** túnel: o próprio processador de imagem da TV trata o vídeo (inclui o desentrelaçamento da TV) */
    private boolean tunnelPref() {
        try { android.content.SharedPreferences p = act.getSharedPreferences("np", 0); return p.getBoolean("tunnel", false) || "tv".equals(p.getString("deintMode", "")); } catch (Throwable e) { return false; }
    }
    /** Caminho estável na Bravia/Sony/MediaTek: sem efeitos GPU + sem religações agressivas.
     *  v335: inclui TextureView (Sony por omissão) — o importante é não destruir/redimensionar a superfície. */
    private boolean preferHardwarePath() {
        return isTvDev() && !deint && tunnelAllowed;
    }
    /** Menor = melhor. Hardware MTK primeiro; software Google sempre no fim. */
    private static int videoCodecPref(androidx.media3.exoplayer.mediacodec.MediaCodecInfo ci) {
        String n = ci.name == null ? "" : ci.name.toLowerCase(java.util.Locale.US);
        if (ci.softwareOnly || n.contains("c2.android") || n.contains("omx.google")) return 50;
        if (n.contains("c2.mtk")) return 0;
        if (n.contains("omx.mtk")) return 1;
        if (n.contains("c2.")) return 2;
        if (n.contains("omx.")) return 3;
        return 10;
    }
    /** Túnel só em ecrã total + SurfaceView (túnel não funciona com TextureView). */
    private boolean tunnelShouldBeOn() {
        return preferHardwarePath() && !texMode && full && tunnelPref() && !shareAudio && !avOffsetSet();
    }
    private void applyTunnelState() {
        try {
            if (selector == null || !isTvDev()) return;
            boolean on = tunnelShouldBeOn();
            boolean cur = false;
            try { cur = selector.getParameters().tunnelingEnabled; } catch (Throwable ignored) { }
            if (on == cur) return;
            /* Túnel só em DefaultTrackSelector.Parameters (não existe em TrackSelectionParameters).
               setParameters() notifica o player e re-selecciona as pistas. */
            selector.setParameters(selector.buildUponParameters().setTunnelingEnabled(on).build());
            log(on ? "túnel ligado (ecrã total)" : "túnel desligado (janela/miniatura ou preferência)");
        } catch (Throwable ignored) { }
    }
    private String sdNoteUrl = "";

    private boolean fxApplied = false;
    private String fxKey = "";

    /** Com a cadeia de efeitos ligada o vídeo é ajustado à superfície pela própria cadeia; por isso o formato é pedido aqui (Presentation). */
    private androidx.media3.common.Effect presentationFor() {
        try {
            if (box == null || "fit".equals(aspect)) return null;
            int bw = box.getWidth(), bh = box.getHeight();
            if (bw <= 0 || bh <= 0) return null;
            if ("stretch".equals(aspect)) return androidx.media3.effect.Presentation.createForWidthAndHeight(bw, bh, androidx.media3.effect.Presentation.LAYOUT_STRETCH_TO_FIT);
            if ("zoom".equals(aspect)) return androidx.media3.effect.Presentation.createForWidthAndHeight(bw, bh, androidx.media3.effect.Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP);
            float r = "16:9".equals(aspect) ? 16f / 9f : "4:3".equals(aspect) ? 4f / 3f : "21:9".equals(aspect) ? 21f / 9f : 0f;
            if (r <= 0f) return null;
            int w = bw, h = Math.round(bw / r);
            if (h > bh) { h = bh; w = Math.round(bh * r); }
            return androidx.media3.effect.Presentation.createForWidthAndHeight(w, h, androidx.media3.effect.Presentation.LAYOUT_STRETCH_TO_FIT);
        } catch (Throwable t) { return null; }
    }

    private boolean fxBroken = false;   /* a cadeia de efeitos falhou neste aparelho: não voltar a usar */
    private long fxLastAt = 0;
    private final Runnable fxRetry = this::applyDeint;

    /* ===== Aspeto das legendas (tamanho, cor, fundo, contorno, posição) ===== */
    static int subSizePct = 100, subFg = 0xFFFFFFFF, subBg = 0x99000000, subEdge = 0;
    static float subBottom = 0.08f;

    void applySubStyle() {
        try {
            if (view == null) return;
            androidx.media3.ui.SubtitleView sv = view.getSubtitleView();
            if (sv == null) return;
            sv.setApplyEmbeddedStyles(false);
            sv.setApplyEmbeddedFontSizes(false);
            sv.setFractionalTextSize(0.0533f * subSizePct / 100f);
            int edge = subEdge == 1 ? androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW : subEdge == 2 ? androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE : androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_NONE;
            sv.setStyle(new androidx.media3.ui.CaptionStyleCompat(subFg, subBg, Color.TRANSPARENT, edge, 0xFF000000, null));
            sv.setBottomPaddingFraction(subBottom);
        } catch (Throwable ignored) { }
    }

    public void setSubStyle(int sizePct, int fg, int bg, int edge, float bottom) {
        subSizePct = sizePct; subFg = fg; subBg = bg; subEdge = edge; subBottom = bottom;
        applySubStyle();
    }

    /** v264: no diário, o que importa para o som acertado: formatos, descodificadores, efeitos e saída de som (Bluetooth tem atraso próprio). */
    private void logAv() {
        try {
            StringBuilder sb = new StringBuilder("A/V:");
            androidx.media3.common.Format vf = player.getVideoFormat(), af = player.getAudioFormat();
            if (vf != null) sb.append(" vídeo ").append(vf.sampleMimeType).append(" ").append(vf.width).append("x").append(vf.height).append(vf.frameRate > 0 ? " " + Math.round(vf.frameRate) + "fps" : "");
            if (!decName.isEmpty()) sb.append(" [").append(decName).append("]");
            if (af != null) sb.append(" · som ").append(af.sampleMimeType).append(" ").append(af.channelCount).append("ch ").append(af.sampleRate).append("Hz");
            if (!audDec.isEmpty()) sb.append(" (").append(audDec).append(")");
            sb.append(" · acerto ").append(avOffsetMs).append(" ms");
            try { androidx.media3.exoplayer.DecoderCounters dc = player.getAudioDecoderCounters(); if (dc != null) sb.append(" · tramas som ").append(dc.renderedOutputBufferCount); } catch (Throwable ignored) { }
            sb.append(fxApplied ? " · efeitos GPU ligados" : " · sem efeitos");
            if (texMode) sb.append(" · TextureView");
            else sb.append(" · SurfaceView");
            if (surfaceFrozen) sb.append(" · superfície congelada");
            try {
                android.media.AudioManager am = (android.media.AudioManager) act.getSystemService(android.content.Context.AUDIO_SERVICE);
                String out = "altifalante";
                for (android.media.AudioDeviceInfo d : am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
                    int t = d.getType();
                    if (t == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == 26 /* BLE headset */ || t == 27 /* BLE speaker */) { out = "Bluetooth (" + d.getProductName() + ")"; break; }
                    if (t == android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES || t == android.media.AudioDeviceInfo.TYPE_USB_HEADSET) out = "auscultadores com fio";
                    if (t == android.media.AudioDeviceInfo.TYPE_HDMI || t == android.media.AudioDeviceInfo.TYPE_HDMI_ARC || t == 29 /* eARC */) out = "HDMI";
                }
                sb.append(" · saída ").append(out);
            } catch (Throwable ignored) { }
            log(sb.toString());
        } catch (Throwable ignored) { }
    }

    private void applyDeint() {
        if (player == null) return;
        try {
            /* A cadeia de efeitos (desentrelaçamento / formato) só entra com o vídeo já conhecido e só em SD/HD: em 4K ou HDR falha a criar a superfície EGL (0x3003). */
            androidx.media3.common.Format vf = player.getVideoFormat();
            /* v264: filmes e séries (ficheiros) são sempre progressivos — a cadeia de efeitos (GPU) só atrasava a imagem face ao som
               no telemóvel (diário: filme .mp4 com som dessincronizado). Fica só para os diretos, onde há 1080i/576i. */
            boolean sd = vf != null && vf.height > 0 && vf.height <= 600;
            float sharp = sd ? sdSharp : 0f;
            /* v302: caixa escondida ou minúscula (app a ir para trás, sair do Início): não mexe na cadeia de efeitos —
               refazê-la a meio, com a superfície a desaparecer, deitava abaixo o motor de vídeo no telemóvel */
            if (box == null || box.getWidth() <= 4 || box.getHeight() <= 4 || box.getVisibility() != View.VISIBLE) return;
            /* v333: com túnel activo (caminho hardware da Bravia) NUNCA aplicar efeitos GPU —
               invalida o tunneling e provoca frames perdidos em massa + Detaching surface timed out. */
            if (preferHardwarePath()) {
                if (fxApplied) {
                    player.setVideoEffects(new java.util.ArrayList<androidx.media3.common.Effect>());
                    fxApplied = false; fxKey = "";
                    log("efeitos GPU desligados (caminho hardware / túnel)");
                }
                return;
            }
            boolean want = (deint || sharp > 0f) && !vodUrl && !hdrContent && !fxBroken && vf != null && vf.height > 0 && vf.height <= 1100 && vf.width <= 2000
                    && (isTvDev() || full);   /* telemóvel: só em ecrã total (na miniatura não se vê a diferença) */
            if (want) {
                int mode = deint ? deintMode : DeinterlaceEffect.NONE;
                androidx.media3.common.Effect pres0 = presentationFor();
                String key = aspect + "|" + (pres0 != null ? box.getWidth() + "x" + box.getHeight() : "") + "|" + mode + "|" + sharp + "|" + vf.width + "x" + vf.height;
                if (fxApplied && key.equals(fxKey)) return;
                long now = System.currentTimeMillis();
                if (fxApplied && now - fxLastAt < 1500) { if (box != null) { box.removeCallbacks(fxRetry); box.postDelayed(fxRetry, 1600); } return; }   /* não refaz a cadeia várias vezes seguidas */
                fxLastAt = now;
                java.util.List<androidx.media3.common.Effect> fx = new java.util.ArrayList<>();
                fx.add(new DeinterlaceEffect(mode, sharp));
                log("efeitos de imagem: " + (deint ? new String[]{"desentrelaçar adaptativo", "desentrelaçar por linhas", "desentrelaçar por mistura", "sem desentrelaçar"}[Math.max(0, Math.min(3, mode))] : "sem desentrelaçar") + (sharp > 0 ? " · nitidez SD" : "") + " (" + vf.width + "x" + vf.height + ")");
                androidx.media3.common.Effect pres = presentationFor();
                if (pres != null) fx.add(pres);
                player.setVideoEffects(fx);
                fxApplied = true; fxKey = key;
            } else if (fxApplied) {
                player.setVideoEffects(new java.util.ArrayList<androidx.media3.common.Effect>());
                fxApplied = false; fxKey = "";
            }
        } catch (Throwable e) {
            listener.onEvent("deint:error", String.valueOf(e));
        }
    }
    /** v298: aviso quando o fornecedor só envia o canal em SD (720x576): não é a app a baixar a qualidade. */
    /* Refaz a fonte do canal (novo pedido ao servidor) em vez de repetir o loader que já falhou */
    private void rebuildSource() {
        if (player == null || curUrl == null || curUrl.isEmpty()) return;
        MediaItem.Builder b = new MediaItem.Builder().setUri(curUrl);
        if (curMime != null) b.setMimeType(curMime);
        player.setMediaItem(b.build()); player.prepare(); player.play();
    }

    /* Canal UHD/4K: se a ligação abrir abaixo de 2160p, pede a fonte outra vez (o fornecedor por vezes envia 4K numa nova ligação) */
    private void uhdCheck(androidx.media3.common.VideoSize v) {
        try {
            if (v == null || v.width <= 0 || player == null || curUrl.isEmpty() || previewMode || uhdOk) return;
            String t = curTitle.toUpperCase(java.util.Locale.ROOT);
            if (!(t.contains("UHD") || t.contains("ᵁᴴᴰ") || t.contains("4K"))) return;
            if (v.width >= 3000 || v.height >= 2000) { uhdOk = true; log("UHD: 4K confirmado (" + v.width + "x" + v.height + ")"); return; }
            if (uhdTries >= 2) return;
            uhdTries++;
            log("UHD: abriu em " + v.width + "x" + v.height + "; a pedir de novo a versão 4K (" + uhdTries + "/2)");
            ui.postDelayed(() -> { try { if (!uhdOk) rebuildSource(); } catch (Throwable ignored) { } }, 1500);
        } catch (Throwable ignored) { }
    }

    private void sdNote(androidx.media3.common.VideoSize v) {
        try {
            if (v == null || v.height <= 0 || v.height > 600 || vodUrl || curUrl.equals(sdNoteUrl) || previewMode || !full) return;
            sdNoteUrl = curUrl;
            /* v431: a resolução só vai para o registo; já não aparece como legenda ao abrir o canal */
            log("canal em SD: o fornecedor envia " + v.width + "x" + v.height + " (sem versão melhor nesta ligação)");
        } catch (Throwable ignored) { }
    }
    private DefaultTrackSelector selector;
    private volatile boolean forceStereo;

    /** 5.1 / 7.1 em PCM de 16 bits → estéreo, com o canal central (vozes) à frente. Ordem Android: FL FR FC LFE BL BR (SL SR). */
    private static final class StereoDownmix extends androidx.media3.common.audio.BaseAudioProcessor {
        private final java.util.function.BooleanSupplier on; private int chs;
        StereoDownmix(java.util.function.BooleanSupplier on) { this.on = on; }
        @Override protected AudioFormat onConfigure(AudioFormat in) {
            if (!on.getAsBoolean() || in.encoding != androidx.media3.common.C.ENCODING_PCM_16BIT || (in.channelCount != 6 && in.channelCount != 8)) return AudioFormat.NOT_SET;
            chs = in.channelCount;
            return new AudioFormat(in.sampleRate, 2, androidx.media3.common.C.ENCODING_PCM_16BIT);
        }
        @Override public void queueInput(java.nio.ByteBuffer b) {
            b.order(java.nio.ByteOrder.nativeOrder());
            int frames = b.remaining() / (2 * chs);
            java.nio.ByteBuffer out = replaceOutputBuffer(frames * 4);
            for (int i = 0; i < frames; i++) {
                int fl = b.getShort(), fr = b.getShort(), c = b.getShort(), lfe = b.getShort(), bl = b.getShort(), br = b.getShort(), sl = 0, sr = 0;
                if (chs == 8) { sl = b.getShort(); sr = b.getShort(); }
                float l = 0.60f * fl + 1.00f * c + 0.12f * lfe + 0.33f * bl + 0.25f * sl;
                float r = 0.60f * fr + 1.00f * c + 0.12f * lfe + 0.33f * br + 0.25f * sr;
                out.putShort((short) Math.max(-32768, Math.min(32767, Math.round(l))));
                out.putShort((short) Math.max(-32768, Math.min(32767, Math.round(r))));
            }
            out.flip();
        }
    }
    private int retries = 0;
    private boolean wantVisible = true;
    private final List<Object[]> audio = new ArrayList<>();
    private final List<Object[]> text = new ArrayList<>();
    private String curUrl = "";
    private String curTitle = "";
    /* 4K: se o canal UHD abrir numa versão mais baixa, pede a fonte outra vez (até 2 vezes) */
    private int uhdTries = 0; private boolean uhdOk = false;
    private String curMime = null;
    private volatile String posInfo = "0|0|1";
    /* v449: direto o mais perto possível sem parar. Estes canais não trazem relógio da emissão (o atraso é desconhecido), por isso o
       controlo de velocidade do leitor não atua. Mede-se a reserva mínima dos últimos 12 s (um ciclo de segmentos):
       pouca reserva → abranda 3 % (impercetível) até ganhar folga; reserva a mais → acelera 3 % para voltar a aproximar-se da emissão. */
    private final float[] resWin = new float[12]; private int resN = 0; private float liveSpd = 1f;
    private void liveKeep() {
        try {
            if (player == null || !liveGuess || vodUrl) return;
            boolean ok = gotFrame && !userPaused && !userRewound && player.getPlaybackState() == Player.STATE_READY && player.getPlayWhenReady()
                    && player.getCurrentLiveOffset() == C.TIME_UNSET && !"passthrough".equals(audDec);
            try { if (selector != null && selector.getParameters().tunnelingEnabled) ok = false; } catch (Throwable ignored) { }
            if (!ok) { resN = 0; if (liveSpd != 1f) { liveSpd = 1f; player.setPlaybackSpeed(1f); } return; }
            resWin[resN % resWin.length] = player.getTotalBufferedDuration() / 1000f; resN++;
            if (resN < resWin.length) return;
            float mn = Float.MAX_VALUE; for (float v : resWin) mn = Math.min(mn, v);
            float want = liveSpd;
            if (liveSpd == 1f) { if (mn < liveLowS() + 0.5f) want = 0.97f; else if (mn > 9f) want = 1.03f; }
            else if (liveSpd < 1f) { if (mn >= liveLowS() + 2f) want = 1f; }
            else { if (mn <= 6f) want = 1f; }
            if (want != liveSpd) {
                liveSpd = want; player.setPlaybackSpeed(want);
                log("direto: reserva mínima " + Math.round(mn * 10f) / 10f + " s → velocidade " + want);
            }
        } catch (Throwable ignored) { }
    }
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (player == null) return;
            long d = player.getDuration();
            posInfo = player.getCurrentPosition() + "|" + (d == C.TIME_UNSET ? 0 : d) + "|" + (player.isCurrentMediaItemLive() ? 1 : 0) + "|" + (player.getPlayWhenReady() ? 1 : 0);
            watchdog();
            liveKeep();
            updateSeekVis();
            ui.postDelayed(this, 1000);
        }
    };

    /* Deteção de bloqueio: a reproduzir (ou a carregar) mas sem avançar há 8 s -> recomeça sozinho. */
    /* desligado: o diário mostrou falsos positivos (religava a superfície a reproduzir bem e causava 5 s de paragem) */
    private static final boolean FRAME_WATCHDOG = false;
    private long bufSince = 0;
    /* v396: aviso discreto quando a reprodução pára mais de 2 s a carregar (tempo parado e buffer disponível) */
    private boolean bufHudOn = false;
    private final Runnable bufHudTick = new Runnable() {
        @Override public void run() {
            try {
                if (player == null) return;
                if (player.getPlaybackState() == Player.STATE_BUFFERING && bufSince != 0) {
                    long s = (System.currentTimeMillis() - bufSince) / 1000;
                    if (s >= 2) { hud("A carregar… parado há " + s + " s · buffer " + (player.getTotalBufferedDuration() / 1000) + " s"); bufHudOn = true; }
                    ui.postDelayed(this, 500);
                } else if (bufHudOn) { bufHudOn = false; hud(""); }
            } catch (Throwable ignored) { }
        }
    };
    private boolean gotFrameLogged = false;
    private long playAtMs = 0, lastStuckRetry = 0; private int surfRaceN = 0;
    private long wdPos = -1, wdFr = -1; private int wdStuck = 0, wdOk = 0, wdTries = 0, vStuck = 0, vTries = 0;
    /* v261: enquanto espera para tentar de novo depois de um erro de rede (ex.: 509) e nos 15 s seguintes, o vigia não mexe:
       o diário mostrou-o a contar a espera como «parado» e a religar a superfície logo a seguir (superfície 0x0 e mais paragens) */
    private long retryGraceUntil = 0;
    private void watchdog() {
        try {
            if (player == null || userPaused || !player.getPlayWhenReady() || !wantVisible) { wdStuck = 0; return; }
            if (android.os.SystemClock.uptimeMillis() < retryGraceUntil) { wdStuck = 0; wdPos = player.getCurrentPosition(); return; }
            if (vodUrl && !everReady) { wdStuck = 0; return; }   /* ainda a arrancar */
            int st = player.getPlaybackState();
            if (st == Player.STATE_ENDED || st == Player.STATE_IDLE && wdTries > 0) { wdStuck = 0; return; }
            long p = player.getCurrentPosition();
            if (p != wdPos) {
                wdPos = p; wdStuck = 0; if (++wdOk >= 5) wdTries = 0;
                /* o tempo avança (há som) mas nenhuma imagem nova há 3 s: a superfície do vídeo congelou */
                long fr = -1;
                try { androidx.media3.exoplayer.DecoderCounters dc = player.getVideoDecoderCounters(); if (dc != null) { dc.ensureUpdated(); fr = dc.renderedOutputBufferCount; } } catch (Throwable ignored) { }
                if (FRAME_WATCHDOG && fr >= 0 && st == Player.STATE_READY && fr == wdFr) {
                    if (++vStuck >= 3) {
                        vStuck = 0; vTries++;
                        if (vTries <= 2) {
                            log("watchdog: imagem parada, religa superfície");
                            if (hdrOn && hdrSv != null) { player.setVideoSurfaceView(null); player.setVideoSurfaceView(hdrSv); }
                            else if (ttv != null) { player.setVideoTextureView(null); player.setVideoTextureView(ttv); }
                        } else if (!curUrl.isEmpty()) {
                            vTries = 0;
                            MediaItem.Builder b = new MediaItem.Builder().setUri(curUrl);
                            if (curMime != null) b.setMimeType(curMime);
                            if (player.isCurrentMediaItemLive()) player.setMediaItem(b.build()); else player.setMediaItem(b.build(), Math.max(0, p - 1000));
                            player.prepare(); player.play();
                        }
                    }
                } else { vStuck = 0; if (fr != wdFr) vTries = 0; }
                wdFr = fr;
                return;
            }
            wdOk = 0;
            if (++wdStuck < (st == Player.STATE_BUFFERING ? (vodUrl ? 12 : 4) : 5)) return;   /* v282: filmes a carregar de servidores lentos: mais paciência */
            wdStuck = 0; wdTries++; log("watchdog: sem avanço, tentativa " + wdTries);
            if (wdTries == 1) {                       /* 1.ª vez: religa a superfície e retoma */
                /* v262: só religa quando há TextureView própria. Na TV a imagem vai para a superfície do PlayerView: setVideoTextureView(null)
                   tirava-a e nunca mais a repunha — ecrã preto só com som (visto no diário depois de um 509) */
                if (ttv != null && !hdrOn && !vodUrl) { player.setVideoTextureView(null); player.setVideoTextureView(ttv); }   /* v282: nos filmes não mexe na superfície (deixava o descodificador da TV preso) */
                if (player.isCurrentMediaItemLive()) player.seekToDefaultPosition(); else player.seekTo(Math.max(0, p));
                player.prepare(); player.play();
            } else if (wdTries == 2 && !curUrl.isEmpty()) {   /* 2.ª vez: recarrega o endereço */
                MediaItem.Builder b = new MediaItem.Builder().setUri(curUrl);
                if (curMime != null) b.setMimeType(curMime);
                boolean live = player.isCurrentMediaItemLive();
                if (live) player.setMediaItem(b.build()); else player.setMediaItem(b.build(), Math.max(0, p - 2000));
                player.prepare(); player.play();
            } else if (wdTries >= 3) {                /* 3.ª vez: avisa a página, que tenta de novo ou muda de leitor */
                wdTries = 0; listener.onEvent("error", "vídeo bloqueado");
            }
        } catch (Throwable ignored) { }
    }
    String pos() { return posInfo; }
    private volatile String tracksJson = "{\"audio\":[],\"text\":[]}";
    private final Runnable hideLabel = new Runnable() { @Override public void run() { if (label != null) label.setVisibility(View.GONE); } };

    NativePlayer(Activity act, FrameLayout root, Listener l) {
        this.act = act;
        this.root = root;
        this.listener = l;
        /* v281: quando a TV muda de modo (taxa de atualização), o som pode ficar desfasado da imagem: volta a acertá-los */
        try {
            final android.hardware.display.DisplayManager dm = (android.hardware.display.DisplayManager) act.getSystemService(android.content.Context.DISPLAY_SERVICE);
            final float[] lastHz = {act.getWindowManager().getDefaultDisplay().getRefreshRate()};
            dm.registerDisplayListener(dispL = new android.hardware.display.DisplayManager.DisplayListener() {
                @Override public void onDisplayAdded(int id) { }
                @Override public void onDisplayRemoved(int id) { }
                @Override public void onDisplayChanged(int id) {
                    try {
                        float hz = act.getWindowManager().getDefaultDisplay().getRefreshRate();
                        if (Math.abs(hz - lastHz[0]) < 0.5f) return;
                        log("modo do ecrã: " + Math.round(lastHz[0]) + " → " + Math.round(hz) + " Hz");
                        lastHz[0] = hz;
                        if (isTvDev()) { ui.removeCallbacks(avResync); ui.postDelayed(avResync, 1500); }   /* v447: no telemóvel é o ecrã a poupar (60↔24 Hz): ressincronizar só provocava um carregamento */
                    } catch (Throwable ignored) { }
                }
            }, ui);
        } catch (Throwable ignored) { }
    }
    private android.hardware.display.DisplayManager.DisplayListener dispL;
    private boolean codecStuck = false;
    private int decInitFails = 0;
    private boolean pvToFull = false;
    /** Volta a acertar som e imagem: salta para o ponto atual (o leitor esvazia e realinha os dois). */
    final Runnable avResync = new Runnable() { @Override public void run() { avResyncNow(); } };
    private long lastAvResync = 0L;
    private void avResyncNow() {
        try {
            if (player == null || userPaused || player.getPlaybackState() != Player.STATE_READY) return;
            /* v356: cada mudança de frequência do ecrã (24/60/120 Hz) disparava um salto; isto parava o filme a cada 2-3 s.
               No máximo um realinhamento a cada 30 s. */
            long now = android.os.SystemClock.elapsedRealtime();
            if (now - lastAvResync < 30000L) return;
            lastAvResync = now;
            log("ressincroniza som/imagem (salto para o ponto atual)");
            if (player.isCurrentMediaItemLive()) player.seekTo(Math.max(0, player.getCurrentPosition()));
            else player.seekTo(player.getCurrentPosition());
        } catch (Throwable ignored) { }
    }

    String tracks() { return tracksJson; }

    /** Aviso por cima do vídeo (episódio seguinte, saltar intro). Texto vazio esconde. */
    void hud(String t) {
        ensureViews();
        if (t == null || t.isEmpty()) { hud.setVisibility(View.GONE); return; }
        hud.setText(t);
        hud.setVisibility(View.VISIBLE);
    }

    /** Frames extra da vista múltipla: não pedem o foco de áudio (senão pausam os outros) e usam menos memória. */
    boolean shareAudio = false;

    void prepareViews() { ensureViews(); }

    void bringBoxToFront() { if (box != null) box.bringToFront(); }

    private void ensureViews() {
        if (box != null) return;
        box = new FrameLayout(act);
        box.setFocusable(false);
        box.setBackgroundColor(Color.BLACK);
        boolean tvDev = false;
        try { android.app.UiModeManager um = (android.app.UiModeManager) act.getSystemService(android.content.Context.UI_MODE_SERVICE); tvDev = um != null && um.getCurrentModeType() == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION; } catch (Throwable ignored) { }
        PlayerView pv = null;
        /* v341: SurfaceView + OMX.MTK + FFmpeg AAC. TextureView + HW decoder causa cópia GPU
           e fpsReal≈1 em 1080p (log 1.315). Só TextureView se o utilizador escolher «Sempre compatível». */
        boolean tvTexPref = false;
        try { tvTexPref = act.getSharedPreferences("np", 0).getBoolean("tvTexture", false); } catch (Throwable ignored) { }
        /* Limpar forçamento v339 (gravava tvTexture=true na Sony). */
        try {
            if (tvDev && "sony".equalsIgnoreCase(android.os.Build.MANUFACTURER)
                    && act.getSharedPreferences("np", 0).getBoolean("tvTexture", false)
                    && !act.getSharedPreferences("np", 0).getBoolean("tvTextureUser", false)) {
                act.getSharedPreferences("np", 0).edit().putBoolean("tvTexture", false).apply();
                tvTexPref = false;
            }
        } catch (Throwable ignored) { }
        if (tvDev) log(tvTexPref ? "TV: TextureView (preferência)" : "TV: SurfaceView + HW vídeo + FFmpeg AAC");
        texMode = !tvDev || tvTexPref || Boolean.TRUE.equals(texOverride);
        if (texMode) {
            /* superfície TextureView, que respeita zoom/corte/esticar dentro da área do vídeo */
            try { pv = (PlayerView) android.view.LayoutInflater.from(act).inflate(R.layout.player_texture, null); } catch (Throwable ignored) { pv = null; }
        }
        view = pv != null ? pv : new PlayerView(act);
        if (texMode && pv != null) {
            ttv = new android.view.TextureView(act);
            ttv.setOpaque(true);
            box.addView(ttv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER));
            hdrSv = new android.view.SurfaceView(act);
            hdrSv.setVisibility(View.GONE);
            box.addView(hdrSv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER));
        }
        view.setClipChildren(false);   /* a escala (esticar/zoom) desenha para lá da área do vídeo ajustado */
        box.setClipChildren(true);
        view.setUseController(false);
        view.setFocusable(false);
        view.setFocusableInTouchMode(false);
        view.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        view.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        view.setShutterBackgroundColor(ttv != null ? Color.TRANSPARENT : Color.BLACK);
        box.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        label = new TextView(act);
        label.setTextColor(Color.WHITE);
        label.setTextSize(22f);
        label.setPadding(28, 14, 28, 14);
        label.setBackgroundColor(0x99000000);
        label.setVisibility(View.GONE);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.leftMargin = 24;
        lp.topMargin = 24;
        box.addView(label, lp);
        hud = new TextView(act);
        hud.setTextColor(Color.WHITE);
        hud.setTextSize(20f);
        hud.setPadding(28, 16, 28, 16);
        hud.setBackgroundColor(0xCC1A2B44);
        hud.setVisibility(View.GONE);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.gravity = Gravity.BOTTOM | Gravity.RIGHT;
        hp.rightMargin = 32;
        hp.bottomMargin = 48;
        box.addView(hud, hp);
        view.addOnLayoutChangeListener((vv, l, t, r2, b2, ol, ot, or2, ob) -> { if (r2 - l != or2 - ol || b2 - t != ob - ot) view.post(this::applyScale); });
        box.addOnLayoutChangeListener((vv, l, t, r2, b2, ol, ot, or2, ob) -> { if (r2 - l != or2 - ol || b2 - t != ob - ot) view.post(this::applyScale); });
        buildCtl();
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(10, 10);
        p.gravity = Gravity.TOP | Gravity.LEFT;
        box.setVisibility(View.INVISIBLE);
        root.addView(box, p);
    }

    private void ensurePlayer(String referer) {
        releasePlayer();
        boolean hasRef = referer != null && !referer.isEmpty();
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent(hasRef ? UA_BROWSER : UA)
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(25000);
        if (hasRef) {
            Map<String, String> h = new HashMap<>();
            h.put("Referer", referer);
            h.put("Origin", referer.replaceAll("^(https?://[^/]+).*$", "$1"));
            http.setDefaultRequestProperties(h);
        }
        DefaultExtractorsFactory ex = new DefaultExtractorsFactory()
                .setConstantBitrateSeekingEnabled(true)
                .setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES
                        | DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS
                        | DefaultTsPayloadReaderFactory.FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS);
        /* v265: acerto manual do som (ms). O relógio do som é o que manda na imagem: atrasar o relógio atrasa a imagem. */
        try { forceStereo = act.getSharedPreferences("np", 0).getBoolean("stereoDown", false); } catch (Throwable ignored) { }
        DefaultRenderersFactory rf = new DefaultRenderersFactory(act) {
            @Override protected androidx.media3.exoplayer.audio.AudioSink buildAudioSink(android.content.Context ctx, boolean flt, boolean params) {
                /* v304: filmes com som AAC 5.1 saem do descodificador em 6 canais PCM e algumas TV (HDMI só estéreo) recusam o AudioTrack
                   (AUDIO_TRACK_INIT_FAILED, filme sem som ou a preto). A mistura para estéreo, com a voz (canal central) à frente, só se liga depois da 1.ª recusa. */
                androidx.media3.exoplayer.audio.AudioSink base;
                try {
                    base = new androidx.media3.exoplayer.audio.DefaultAudioSink.Builder(ctx)
                            .setEnableFloatOutput(flt).setEnableAudioTrackPlaybackParams(params)
                            .setAudioProcessors(new androidx.media3.common.audio.AudioProcessor[]{ new StereoDownmix(() -> forceStereo) })
                            .build();
                } catch (Throwable t) { base = super.buildAudioSink(ctx, flt, params); }
                if (base == null) return null;
                return new androidx.media3.exoplayer.audio.ForwardingAudioSink(base) {
                    @Override public void configure(androidx.media3.common.Format f, int size, int[] ch) throws androidx.media3.exoplayer.audio.AudioSink.ConfigurationException {
                        /* PCM = taxa REAL do MediaCodec. NÃO forçar 48 kHz:
                           v336 forçou 24→48 em HE-AAC → som a 2× → fpsReal≈1–2 e drops em massa (log 1.310). */
                        final boolean rawPcm = f != null && "audio/raw".equals(f.sampleMimeType);
                        final int sinkRate = f != null ? f.sampleRate : 0;
                        final int sinkCh = f != null ? f.channelCount : 0;
                        ui.post(() -> { try {
                            androidx.media3.common.Format af = player != null ? player.getAudioFormat() : null;
                            String m = af != null && af.sampleMimeType != null ? af.sampleMimeType : "";
                            int decl = af != null ? af.sampleRate : 0;
                            boolean dolby = m.contains("ac3") || m.contains("ac4") || m.contains("dts") || m.contains("true-hd");
                            avKind = dolby ? (rawPcm ? "dolbysw" : "dolby") : "pcm";
                            if (!rawPcm) audDec = "passthrough";
                            sinkSampleRate = sinkRate; sinkChannels = sinkCh; declaredSampleRate = decl;
                            log("saída de som: " + m + " decl=" + decl + " Hz → " + (rawPcm ? "PCM " + sinkRate + " Hz " + sinkCh + "ch" : "direto (passthrough)") + " · chave " + avKey());
                            if (rawPcm && decl > 0 && sinkRate > 0 && decl != sinkRate)
                                log("som: taxa declarada " + decl + " ≠ sink " + sinkRate + " Hz (normal em HE-AAC/SBR)");
                        } catch (Throwable ignored) { } loadAv(); });
                        super.configure(f, size, ch);
                    }
                    @Override public long getCurrentPositionUs(boolean sourceEnded) {
                        long p = super.getCurrentPositionUs(sourceEnded);
                        if (p == androidx.media3.exoplayer.audio.AudioSink.CURRENT_POSITION_NOT_SET) return p;
                        return Math.max(0, p - avOffsetMs * 1000L);
                    }
                };
            }
        }
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
                .setEnableDecoderFallback(true)
                /* v269: som Dolby (AC-3 / E-AC-3) no telemóvel é descodificado pelo FFmpeg da app em vez do descodificador Dolby do
                   aparelho, que dessincronizava o som (~0,8 s nos Samsung). Na TV fica como está: se a TV/barra de som aceitar
                   Dolby, segue direto (passthrough); senão usa o descodificador da TV e, se não houver, o FFmpeg. */
                .setMediaCodecSelector((mime, secure, tunnel) -> {
                    /* v339: na TV, AAC via FFmpeg (MediaCodec AAC vazio). O c2.android.aac.decoder
                       (único na VH2) parte o sync HE-AAC → fpsReal≈1–2 em 1080p. */
                    if (isTvDev() && mime != null && (mime.equals(androidx.media3.common.MimeTypes.AUDIO_AAC)
                            || "audio/mp4a-latm".equals(mime))) {
                        return java.util.Collections.emptyList();
                    }
                    java.util.List<androidx.media3.exoplayer.mediacodec.MediaCodecInfo> l =
                            new java.util.ArrayList<>(androidx.media3.exoplayer.mediacodec.MediaCodecSelector.DEFAULT.getDecoderInfos(mime, secure, tunnel));
                    if (dolbySw() && mime != null && (mime.equals(androidx.media3.common.MimeTypes.AUDIO_E_AC3) || mime.equals(androidx.media3.common.MimeTypes.AUDIO_AC3) || mime.equals(androidx.media3.common.MimeTypes.AUDIO_E_AC3_JOC)))
                        return java.util.Collections.emptyList();
                    /* v340: vídeo hardware primeiro. c2.android.avc.decoder é software — em 1080p
                       ficou rend=1 e buffering em loop (log 1.314). Nunca preferir software a OMX.MTK. */
                    if (mime != null && (mime.contains("avc") || mime.contains("hevc") || mime.contains("vp9")) && l.size() > 1) {
                        l.sort((a, b) -> Integer.compare(videoCodecPref(a), videoCodecPref(b)));
                    }
                    return l;
                })
                .setAllowedVideoJoiningTimeMs(0);   /* arranque mais rápido: não espera pela junção do vídeo */
        selector = new DefaultTrackSelector(act);
        selector.setParameters(selector.buildUponParameters()
                /* 4K: sem limitar a qualidade ao tamanho do ecrã e sempre a melhor versão que o aparelho descodifica */
                .setForceHighestSupportedBitrate(true)
                .setAllowVideoMixedMimeTypeAdaptiveness(true)
                .setAllowVideoNonSeamlessAdaptiveness(true)
                .setExceedRendererCapabilitiesIfNecessary(true)
                .setMaxVideoSize(capW, capH)
                .setTunnelingEnabled(tunnelShouldBeOn())
                /* v342: preferir HEVC a AVC quando o manifesto oferece os dois (HEVC = fps estável na MTK). */
                .setPreferredVideoMimeTypes(
                        androidx.media3.common.MimeTypes.VIDEO_H265,
                        androidx.media3.common.MimeTypes.VIDEO_DOLBY_VISION,
                        androidx.media3.common.MimeTypes.VIDEO_H264,
                        androidx.media3.common.MimeTypes.VIDEO_VP9)
                .setPreferredAudioLanguage("pt")
                .setPreferredTextLanguage("pt")
                .setSelectUndeterminedTextLanguage(false)
                .build());
        /* Buffers: live arranca depressa; VOD (filme) também prioriza tempo — senão espera dezenas de MB
           e o 1.º frame demora ~9 s (log 1.318 Forgotten Island). */
        DefaultLoadControl lc = new DefaultLoadControl.Builder()
                /* v393: em filmes/séries (sobretudo 4K, 15-40 Mbps) o buffer mínimo sobe para 25 s e a retoma após uma pausa
                   exige 5 s de reserva (antes 2,5 s: voltava a parar logo); o teto de bytes sobe para 64 MB */
                /* v406/v407: em direto o buffer é curto (5–15 s) para o canal ficar perto da emissão; antes 25–90 s de atraso.
                   Com prioridade ao tempo, o limite em MB deixa de atrasar o direto. */
                .setBufferDurationsMs(
                        liveGuess ? 5000 : 25000,
                        liveGuess ? 15000 : 60000,
                        liveGuess ? 500 : 1200,
                        liveGuess ? 1500 : 5000)
                .setTargetBufferBytes((shareAudio ? 24 : (liveGuess ? 32 : 64)) * 1024 * 1024)
                .setPrioritizeTimeOverSizeThresholds(true)  /* v343: filmes começam quando há ~1,2 s, não 48 MB */
                .setBackBuffer(shareAudio ? 15000 : (liveGuess ? 120000 : 60000), false)
                .build();
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build();
        androidx.media3.datasource.DataSource.Factory dataFac = new DefaultDataSource.Factory(act, http);
        if (tsFixEnabled()) dataFac = new TsFix.Factory(dataFac, tsFix);
        else log("TsFix desligado (definição)");
        player = new ExoPlayer.Builder(act, rf)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(dataFac, ex))
                .setTrackSelector(selector)
                .setLoadControl(lc)
                /* v448: direto adaptativo — cada recarregamento afasta o alvo 1,5 s (por omissão 0,5 s), para não parar repetidamente
                   numa ligação instável; com a ligação estável o leitor volta a aproximar-se sozinho do alvo (6 s) */
                .setLivePlaybackSpeedControl(new androidx.media3.exoplayer.DefaultLivePlaybackSpeedControl.Builder()
                        .setTargetLiveOffsetIncrementOnRebufferMs(1500)
                        .build())
                .setAudioAttributes(aa, !shareAudio)
                .setWakeMode(C.WAKE_MODE_NETWORK)
                .build();
        applyDeint();
        player.addAnalyticsListener(new AnalyticsListener() {
            @Override public void onVideoDecoderInitialized(AnalyticsListener.EventTime t, String name, long a, long b) { decName = name == null ? "" : name; }
            @Override public void onAudioDecoderInitialized(AnalyticsListener.EventTime t, String name, long a, long b) { audDec = name == null ? "" : name; }
            /* v329: imagens que o descodificador largou (como o «perdidos» do registo do Tesla) */
            @Override public void onDroppedVideoFrames(AnalyticsListener.EventTime t, int n, long ms) {
                dropAccum += n; dropAccumMs += ms;
                if (n >= 5) log("imagens perdidas: " + n + " em " + ms + " ms");
            }
        });
        startDiag();
        player.setSeekParameters(androidx.media3.exoplayer.SeekParameters.CLOSEST_SYNC);   /* saltos rápidos em ficheiros grandes */
        player.setVideoChangeFrameRateStrategy(C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_ONLY_IF_SEAMLESS);
        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_BUFFERING) { if (bufSince == 0) bufSince = System.currentTimeMillis(); } else bufSince = 0;
                try { if (state == Player.STATE_BUFFERING && gotFrame && liveGuess && player != null && player.isCurrentMediaItemLive()) { long lo = player.getCurrentLiveOffset(); log("recarregamento em direto n.º " + (++liveRebufN) + (lo != C.TIME_UNSET ? " · atraso " + Math.round(lo / 100f) / 10f + " s" : "")); } } catch (Throwable ignored) { }
                ui.removeCallbacks(bufHudTick);
                if (state == Player.STATE_BUFFERING) ui.postDelayed(bufHudTick, 2000); else bufHudTick.run();   /* v396 */
                log("estado=" + (state == Player.STATE_IDLE ? "IDLE" : state == Player.STATE_BUFFERING ? "BUFFERING" : state == Player.STATE_READY ? "READY" : "ENDED"));
                if (state == Player.STATE_READY) { if (retries > 0) retryGraceUntil = Math.max(retryGraceUntil, android.os.SystemClock.uptimeMillis() + 12000); retries = 0; everReady = true; listener.onEvent("ready", ""); }
                else if (state == Player.STATE_BUFFERING) listener.onEvent("buffering", "");
                else if (state == Player.STATE_ENDED) listener.onEvent("ended", "");
            }

            @Override
            public void onPlayWhenReadyChanged(boolean pw, int reason) { log("playWhenReady=" + pw + " motivo=" + reason + (reason == Player.PLAY_WHEN_READY_CHANGE_REASON_AUDIO_FOCUS_LOSS ? " (perdeu foco de áudio)" : "")); }

            @Override
            public void onIsPlayingChanged(boolean p) { log("a reproduzir=" + p); }

            @Override
            public void onRenderedFirstFrame() {
                gotFrame = true;
                firstFrameAtMs = android.os.SystemClock.uptimeMillis();
                /* v339: superfície congelada desactivada — em 1.310–1.313 não reduziu drops e
                   mantinha tamanhos errados (2x1). Só TextureView + FFmpeg AAC. */
                surfaceFrozen = false;
                log("primeiro frame" + (!gotFrameLogged && playAtMs > 0 ? " (" + (firstFrameAtMs - playAtMs) + " ms depois do play)" : ""));
                gotFrameLogged = true;
                logAv();
            }

            @Override
            public void onSurfaceSizeChanged(int w, int h) { if (w != lastSurfW || h != lastSurfH) { lastSurfW = w; lastSurfH = h; log("superfície " + w + "x" + h); } }

            @Override
            public void onTracksChanged(Tracks t) { rebuildTracks(t); matchRefresh(); updateHdrSurface(); }

            @Override
            public void onVideoSizeChanged(androidx.media3.common.VideoSize v) { matchRefresh(); updateHdrSurface(); applyDeint(); sdNote(v); uhdCheck(v); if (view != null) view.postDelayed(NativePlayer.this::applyAspect, 150); }

            @Override
            public void onPlayerError(PlaybackException e) {
                if (player == null) return;
                int httpCode = 0;
                try {   /* regista o motivo real: código do erro e, se houver, o código HTTP do servidor */
                    String http = "";
                    for (Throwable c = e; c != null; c = c.getCause()) {
                        if (c instanceof androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) { http = " HTTP " + ((androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) c).responseCode; httpCode = ((androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) c).responseCode;
                            try { android.net.Uri u0 = ((androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) c).dataSpec.uri; http += " (servidor " + u0.getHost() + (u0.getPort() > 0 ? ":" + u0.getPort() : "") + ")"; } catch (Throwable ignored2) { }
                            break; }
                        if (c.getCause() == c) break;
                    }
                    Throwable rc = e.getCause();
                    log("erro: " + e.getErrorCodeName() + http + (rc != null ? " · " + rc.getClass().getSimpleName() + (rc.getMessage() != null ? ": " + rc.getMessage().replaceAll("https?://\\S+", "…") : "") : ""));
                } catch (Throwable ignored) { }
                /* v282: o descodificador da TV ficou preso (não liberta em 0,5 s); depois disso nenhum vídeo abre: reinicia a app */
                try {
                    String em = String.valueOf(e.getCause() != null ? e.getCause().getMessage() : e.getMessage());
                    if (em.contains("release timed out") || em.contains("Detaching surface timed out")) { codecStuck = true; log("descodificador preso (" + em + ")"); }
                    if (e.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED) {
                        decInitFails++;
                        if (codecStuck || decInitFails >= 2) { log("descodificador indisponível: reinicia a app para o libertar"); listener.onEvent("restartapp", curUrl); return; }
                    }
                } catch (Throwable ignored) { }
                if (e.errorCode == PlaybackException.ERROR_CODE_AUDIO_TRACK_INIT_FAILED && !forceStereo) {
                    forceStereo = true;
                    try { act.getSharedPreferences("np", 0).edit().putBoolean("stereoDown", true).apply(); } catch (Throwable ignored) { }
                    log("a TV não aceita som multicanal (PCM): mistura para estéreo e tenta outra vez");
                    player.prepare(); player.play();
                    return;
                }
                if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition();
                    player.prepare();
                    return;
                }
                /* v329: «width -1 must be positive» = a superfície foi religada (0x0) enquanto saía uma imagem; não é falha dos efeitos: não os desliga, só tenta outra vez */
                try {
                    String em2 = String.valueOf(e.getCause() != null ? e.getCause().getMessage() : "") + String.valueOf(e.getCause() != null && e.getCause().getCause() != null ? e.getCause().getCause().getMessage() : "");
                    if (e.errorCode == PlaybackException.ERROR_CODE_VIDEO_FRAME_PROCESSING_FAILED && em2.contains("must be positive") && surfRaceN++ < 3) {
                        log("superfície religada durante uma imagem: tenta outra vez (efeitos mantidos)");
                        ui.postDelayed(() -> { try { if (player != null) { player.prepare(); player.play(); } } catch (Throwable ignored) { } }, 500);
                        return;
                    }
                } catch (Throwable ignored) { }
                /* v329: descodificador preso a largar a superfície/leitor: recarrega o canal sozinho (antes ficava ~17 s parado à espera de o utilizador tentar outra vez) */
                /* v333: no caminho hardware da Bravia estes timeouts vinham das religações agressivas de superfície.
                   Agora evitamos as religações; se ainda acontecer, esperamos mais e não recarregamos de imediato em ciclo. */
                if (e.errorCode == PlaybackException.ERROR_CODE_TIMEOUT && codecStuck && !curUrl.isEmpty() && android.os.SystemClock.uptimeMillis() - lastStuckRetry > (preferHardwarePath() ? 25000 : 15000)) {
                    lastStuckRetry = android.os.SystemClock.uptimeMillis();
                    log("descodificador preso: a recarregar o canal sozinho");
                    ui.postDelayed(() -> { try { if (player == null) return; MediaItem.Builder b = new MediaItem.Builder().setUri(curUrl); if (curMime != null) b.setMimeType(curMime); player.setMediaItem(b.build()); player.prepare(); player.play(); } catch (Throwable ignored) { } }, preferHardwarePath() ? 1200 : 700);
                    return;
                }
                try { if (e.errorCode == PlaybackException.ERROR_CODE_PARSING_MANIFEST_MALFORMED && curUrl.contains("/live/") && curUrl.matches("(?i).*\\.m3u8(\\?.*)?$")) { HLS_BAD.add(hostOf(curUrl)); } } catch (Throwable ignored) { }
                if ((e.errorCode == PlaybackException.ERROR_CODE_VIDEO_FRAME_PROCESSING_FAILED || e.errorCode == PlaybackException.ERROR_CODE_VIDEO_FRAME_PROCESSOR_INIT_FAILED) && !fxBroken) {
                    /* v332: «width -1 must be positive» = a cadeia foi montada com a superfície a 0x0 (janela a mudar): não é o aparelho, volta a tentar depois */
                    String em = String.valueOf(e.getCause() != null ? e.getCause().getMessage() : e.getMessage());
                    boolean surf = em.contains("must be positive") || em.contains("width -1") || em.contains("height -1");
                    if (surf) {
                        log("efeitos de imagem: a janela estava a mudar de tamanho; tenta de novo quando assentar");
                        try { player.setVideoEffects(new java.util.ArrayList<androidx.media3.common.Effect>()); } catch (Throwable ignored) { }
                        fxApplied = false; fxKey = "";
                        player.prepare(); player.play();
                        if (box != null) { box.removeCallbacks(fxRetry); box.postDelayed(fxRetry, 2500); }
                        return;
                    }
                    fxBroken = true;
                    log("efeitos de imagem falharam neste aparelho: desligados (o vídeo continua sem eles)");
                    try { player.setVideoEffects(new java.util.ArrayList<androidx.media3.common.Effect>()); } catch (Throwable ignored) { }
                    fxApplied = false; fxKey = "";
                    player.prepare(); player.play();
                    return;
                }
                boolean io = e.errorCode >= 2000 && e.errorCode < 3000;
                int maxRetries = liveGuess ? ((httpCode == 509 || httpCode == 429 || httpCode == 503 || httpCode == 458) ? 8 : 5) : 2;
                if (io && retries < maxRetries) {
                    retries++;
                    long dly = Math.min(8000L, 1000L << Math.min(4, retries - 1));   /* 1 s, 2 s, 4 s, 8 s… */
                    if (httpCode == 509 || httpCode == 429 || httpCode == 503 || httpCode == 458) {
                        /* o servidor está a limitar (509 = limite de ligações / largura de banda): espera mais, para não insistir.
                           v439: já não baixa a resolução por conta própria; a qualidade pedida mantém-se */
                        dly = Math.min(20000L, 5000L * retries);
                        log("servidor a limitar (HTTP " + httpCode + "): a tentar de novo na mesma qualidade");
                    }
                    retryGraceUntil = android.os.SystemClock.uptimeMillis() + dly + 15000;
                    /* NPE do loader ou recusa de autenticação (407/401/403): o loader fica num estado partido; refaz a fonte */
                    String ex = String.valueOf(e.getMessage()) + " " + String.valueOf(e.getCause());
                    boolean refaz = ex.contains("NullPointerException") || ex.contains("UnexpectedLoaderException") || httpCode == 407 || httpCode == 401 || httpCode == 403;
                    log("erro de rede, nova tentativa " + retries + "/" + maxRetries + " em " + dly + " ms" + (refaz ? " (refaz a fonte)" : ""));
                    try { listener.onEvent("note", (httpCode == 509 || httpCode == 429 || httpCode == 503 || httpCode == 458)
                            ? "O servidor limitou as ligações (" + httpCode + "). A tentar de novo em " + (dly / 1000) + " s…"
                            : "Sem ligação. A tentar de novo em " + (dly / 1000) + " s…"); } catch (Throwable ignored) { }
                    ui.postDelayed(new Runnable() { @Override public void run() { if (player != null) { if (refaz) rebuildSource(); else { player.prepare(); player.play(); } } } }, dly);
                    return;
                }
                { Throwable c = e.getCause(); String cm = c != null ? (c.getClass().getSimpleName() + (c.getMessage() != null ? ": " + c.getMessage() : "")) : ""; listener.onEvent("error", e.getErrorCodeName() + (cm.isEmpty() ? "" : " (" + cm + ")")); }
            }
        });
        view.setPlayer(player);
        applySubStyle();
        if (ttv != null) {
            hdrOn = false;
            if (hdrSv != null) hdrSv.setVisibility(View.GONE);
            ttv.setVisibility(View.VISIBLE);
            player.setVideoTextureView(ttv);
            try { act.getWindow().setColorMode(android.content.pm.ActivityInfo.COLOR_MODE_DEFAULT); } catch (Throwable ignored) { }
        }
    }

    private void releasePlayer() {
        ui.removeCallbacksAndMessages(null);
        if (view != null) view.setPlayer(null);
        if (player != null) {
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }
        audio.clear();
        text.clear();
        tracksJson = "{\"audio\":[],\"text\":[]}";
    }

    private static final java.util.concurrent.ExecutorService WARM = java.util.concurrent.Executors.newSingleThreadExecutor();
    private static final java.util.HashMap<String, Long> WARMED = new java.util.HashMap<>();

    /** Aquece DNS/TLS/ligação do canal vizinho (zapping mais rápido): lê só o início da lista. */
    static void warm(final String url, final String referer) {
        if (url == null || !url.startsWith("http")) return;
        String l = url.toLowerCase();
        if (l.contains("/movie/") || l.contains("/series/")) return;
        synchronized (WARMED) {
            Long t = WARMED.get(url);
            if (t != null && System.currentTimeMillis() - t < 60000) return;
            if (WARMED.size() > 60) WARMED.clear();
            WARMED.put(url, System.currentTimeMillis());
        }
        try {
            WARM.execute(new Runnable() { @Override public void run() {
                java.net.HttpURLConnection c = null;
                try {
                    c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                    c.setConnectTimeout(4000); c.setReadTimeout(4000);
                    c.setRequestProperty("User-Agent", "Mozilla/5.0");
                    if (referer != null && !referer.isEmpty()) c.setRequestProperty("Referer", referer);
                    c.setRequestProperty("Range", "bytes=0-4095");
                    java.io.InputStream in = c.getInputStream();
                    byte[] b = new byte[2048]; int n = 0, tot = 0;
                    while (tot < 4096 && (n = in.read(b)) > 0) tot += n;
                    in.close();
                } catch (Throwable ignored) {
                } finally { try { if (c != null) c.disconnect(); } catch (Throwable ignored) { } }
            } });
        } catch (Throwable ignored) { }
    }

    /* v332: servidores onde o .m3u8 dos diretos não é uma lista HLS (resposta «sem #EXTM3U»): vai logo ao .ts, sem perder 1–2 s por canal */
    static final java.util.Set<String> HLS_BAD = java.util.Collections.synchronizedSet(new java.util.HashSet<String>());
    private static String hostOf(String u) { try { return new java.net.URL(u).getHost(); } catch (Throwable t) { return ""; } }
    /* v441: trocar de canal com uma sessão ativa fecha essa sessão e espera 1,5 s antes de abrir a nova
       (o servidor conta uma ligação por conta; abrir logo a seguir dava 509 e cortes). Mesmo canal (miniatura → ecrã total) continua imediato. */
    private Runnable pendingPlay = null;
    void play(String url, String referer, String hint, String title, long startMs) {
        if (pendingPlay != null) { ui.removeCallbacks(pendingPlay); pendingPlay = null; }
        boolean sameChan = url != null && url.equals(curUrl);
        boolean busy = player != null && curUrl != null && !curUrl.isEmpty() && pendingStop == null
                && player.getPlaybackState() != Player.STATE_IDLE && player.getPlaybackState() != Player.STATE_ENDED;
        if (busy && !sameChan && startMs <= 0) {
            stop();
            final String u = url, rf = referer, hn = hint, ti = title;
            /* v447: durante a espera a página já enviou a posição da janela; o arranque escondia a caixa e ninguém a voltava a mostrar
               (imagem preta com som até rodar o ecrã). Depois de arrancar, repõe a janela que a página pediu. */
            pendingPlay = () -> {
                pendingPlay = null;
                final boolean vis = lastVis; final int[] lr = lastRect == null ? null : lastRect.clone();
                playNow(u, rf, hn, ti, 0);
                if (vis && lr != null && !full && lr[2] > 2 && lr[3] > 2) { log("troca de canal: repõe a janela do vídeo"); rect(lr[0], lr[1], lr[2], lr[3], true); }
            };
            ui.postDelayed(pendingPlay, 1500);
            return;
        }
        playNow(url, referer, hint, title, startMs);
    }
    /* v449: duração dos segmentos HLS por servidor (lida da lista do canal). Com segmentos de 10 s, arrancar a 6 s do fim deixava
       menos de 1 s de reserva antes de cada segmento novo, e o direto parava a recarregar. */
    private static final java.util.HashMap<String, Integer> SEG_S = new java.util.HashMap<>();
    /* v450: modo de atraso escolhido em Definições › Reprodução: 0 = mínimo, 1 = equilibrado (predefinido), 2 = estável */
    static volatile int liveMode = 1;
    private static int liveTargetMs(String url) {
        Integer sg; synchronized (SEG_S) { sg = SEG_S.get(hostOf(url)); }
        int seg = sg == null ? 6 : sg;
        if (liveMode == 0) return Math.max(3000, Math.min(8000, seg * 300));
        if (liveMode == 2) return Math.max(15000, Math.min(25000, seg * 1000 + 5000));
        if (sg == null) return 6000;
        return Math.max(6000, Math.min(15000, sg * 500 + 4000));
    }
    private static int liveLowS() { return liveMode == 0 ? 1 : liveMode == 2 ? 4 : 2; }   /* reserva mínima antes de abrandar, em segundos */
    private void playNow(String url, String referer, String hint, String title, long startMs) {
        try { if (url != null && url.contains("/live/") && url.matches("(?i).*\\.m3u8(\\?.*)?$") && HLS_BAD.contains(hostOf(url))) { url = url.replaceFirst("(?i)\\.m3u8", ".ts"); hint = ""; log("servidor sem HLS nos diretos: abre logo o .ts"); } } catch (Throwable ignored) { }
        ensureViews();
        loadAv();
        /* v438: regista as variantes (resolução, codec, débito) que a lista principal do fornecedor anuncia, para diagnosticar a qualidade */
        if (url != null && url.matches("(?i).*\\.m3u8(\\?.*)?$")) {
            final String vurl = url;
            new Thread(() -> {
                try {
                    String m = NativeData.http(vurl, 8000);
                    StringBuilder sb = new StringBuilder();
                    for (String ln : m.split("\\r?\\n")) {
                        if (!ln.startsWith("#EXT-X-STREAM-INF")) continue;
                        java.util.regex.Matcher r = java.util.regex.Pattern.compile("RESOLUTION=(\\d+x\\d+)").matcher(ln);
                        java.util.regex.Matcher c = java.util.regex.Pattern.compile("CODECS=\"([^\"]*)\"").matcher(ln);
                        java.util.regex.Matcher b = java.util.regex.Pattern.compile("BANDWIDTH=(\\d+)").matcher(ln);
                        sb.append(r.find() ? r.group(1) : "?").append(' ').append(c.find() ? c.group(1) : "?").append(' ')
                          .append(b.find() ? (Integer.parseInt(b.group(1)) / 1000) + "kbps" : "?").append(" | ");
                    }
                    try {
                        java.util.regex.Matcher td = java.util.regex.Pattern.compile("#EXT-X-TARGETDURATION:(\\d+)").matcher(m);
                        if (td.find()) { int sg = Integer.parseInt(td.group(1)); if (sg > 0 && sg <= 30) { Integer old; synchronized (SEG_S) { old = SEG_S.put(hostOf(vurl), sg); } if (old == null || old != sg) log("segmentos do direto: " + sg + " s"); } }
                    } catch (Throwable ignored) { }
                    log("variantes do fornecedor: " + (sb.length() == 0 ? (m.contains("#EXTINF") ? "lista direta, sem variantes" : "nenhuma") : sb.toString()));
                } catch (Throwable e) { log("variantes do fornecedor: não lidas (" + e.getClass().getSimpleName() + ")"); }
            }, "variantes").start();
        }
        final boolean fromPv = wasPv || previewMode;
        wasPv = false; previewMode = false;
        try { if (ctlAspect != null) ctlAspect.setVisibility(View.VISIBLE); } catch (Throwable ignored) { }
        /* da miniatura do Início para o ecrã total: o mesmo canal já está a dar, por isso reutiliza a ligação (v440: sem reabrir;
           a melhor variante é escolhida na mesma ligação). Abrir uma segunda sessão do mesmo canal faz o servidor (1 ligação por conta) responder 509 e corta o vídeo. */
        if (fromPv && player != null && url != null && url.equals(curUrl) && startMs <= 0 && everReady && retries == 0
                && player.getPlaybackState() == Player.STATE_READY && pendingStop == null) {
            log("miniatura → ecrã: reutiliza a mesma ligação (sem abrir outra sessão)");
            pvToFull = true;
            wantVisible = true; lastVis = true;
            try { if (box != null) { box.setVisibility(View.VISIBLE); box.bringToFront(); } } catch (Throwable ignored) { }
            try { player.setPlayWhenReady(true); player.setVolume(1f); } catch (Throwable ignored) { }
            userPaused = false;
            try { listener.onEvent("ready", ""); } catch (Throwable ignored) { }   /* esconde «A carregar…» e aplica o volume */
            return;
        }
        if (pendingStop != null) {
            ui.removeCallbacks(pendingStop); pendingStop = null;
            if (player != null && url != null && url.equals(curUrl) && startMs <= 0 && player.getPlaybackState() != Player.STATE_IDLE && player.getPlaybackState() != Player.STATE_ENDED) {
                log("mesmo canal: continua sem recarregar (pré-visualização)");
                try { player.setPlayWhenReady(true); } catch (Throwable ignored) { }
                return;
            }
            stop();
        }
        /* pedido repetido do mesmo canal em menos de 1,2 s (p.ex. página + ecrã nativo): ignora o segundo, evita recarregar e piscar */
        if (player != null && startMs <= 0 && url != null && url.equals(curUrl) && System.currentTimeMillis() - playStart < 1200 && !everReady && player.getPlaybackState() != Player.STATE_IDLE) {
            log("play() repetido ignorado");
            return;
        }
        if (srvCap && (url == null || !url.equals(srvCapUrl))) { srvCap = false; srvCapUrl = ""; setMaxRes(0, 0); }
        playAtMs = android.os.SystemClock.uptimeMillis(); gotFrameLogged = false; surfRaceN = 0;
        firstFrameAtMs = 0; surfaceFrozen = false;   /* v335: novo canal — permite redimensionar até ao 1.º frame */
        log("play() " + (url == null ? "" : url.replaceAll("^https?://[^/]+", "").replaceAll("/[^/]+/[^/]+/", "/…/")) + " hint=" + hint);
        try { liveMode = act.getSharedPreferences("np", 0).getInt("liveLat", 1); } catch (Throwable ignored) { }
        retries = 0; gotFrame = false; liveRebufN = 0; resN = 0; liveSpd = 1f;
        userPaused = false; wdPos = -1; wdFr = -1; wdStuck = 0; wdOk = 0; wdTries = 0; vStuck = 0; vTries = 0;
        { String l0 = url == null ? "" : url.toLowerCase(); liveGuess = !l0.contains("/movie/") && !l0.contains("/series/") && (l0.contains("/live/") || l0.matches(".*\\.(m3u8|ts)(\\?.*)?$")); }
        userRewound = false;
        ensurePlayer(referer);
        ui.postDelayed(liveCheck, 10000);
        MediaItem.Builder b = new MediaItem.Builder().setUri(url);
        /* v406/v407: direto (HLS): fica a ~6 s da emissão; se atrasar, acelera até 5 % para apanhar o direto sem saltos */
        if (liveGuess) b.setLiveConfiguration(new MediaItem.LiveConfiguration.Builder().setTargetOffsetMs(liveTargetMs(url)).setMaxOffsetMs(liveTargetMs(url) + 10000).setMinPlaybackSpeed(0.97f).setMaxPlaybackSpeed(1.05f).build());
        if (url == null || !url.equals(curUrl)) { uhdTries = 0; uhdOk = false; }
        curUrl = url;
        curTitle = title == null ? "" : title;
        everReady = false;
        playStart = System.currentTimeMillis();
        { String lu = url == null ? "" : url.toLowerCase(); vodUrl = lu.contains("/movie/") || lu.contains("/series/") || lu.matches(".*\\.(mkv|mp4|avi|mov|m4v)(\\?.*)?$"); }
        curMime = "hls".equals(hint) ? MimeTypes.APPLICATION_M3U8 : "dash".equals(hint) ? MimeTypes.APPLICATION_MPD : null;
        { String lu2 = url == null ? "" : url.toLowerCase(); tsFix.reset("hls".equals(hint) || lu2.matches(".*\\.m3u8?(\\?.*)?$")); }
        if (curMime != null) b.setMimeType(curMime);
        if (startMs > 0) player.setMediaItem(b.build(), startMs); else player.setMediaItem(b.build());
        player.setPlayWhenReady(true);
        player.prepare();
        posInfo = "0|0|1";
        ui.postDelayed(ticker, 1000);
        /* começa escondido: a página envia logo a posição certa (evita ficar no sítio antigo, p.ex. o da pré-visualização do Início) */
        if (full) { wantVisible = true; lastVis = true; box.setVisibility(View.VISIBLE); }   /* ecrã total: ninguém volta a enviar a posição, por isso não esconde */
        else { wantVisible = false; lastVis = false; box.setVisibility(View.INVISIBLE); }
        if (title != null && !title.isEmpty()) {
            label.setText(title);
            label.setVisibility(View.VISIBLE);
            ui.postDelayed(hideLabel, 2800);
        }
    }

    /** Volta ao ponto em direto (depois de recuar/pausar). */
    void goLive() {
        try { if (player != null) { player.seekToDefaultPosition(); player.setPlayWhenReady(true); userPaused = false; userRewound = false; } } catch (Throwable ignored) { }
    }

    /** Há um vídeo a dar (usado para entrar em janela flutuante ao sair da app). */
    boolean isActive() {
        try { return player != null && player.getPlayWhenReady() && player.getPlaybackState() != androidx.media3.common.Player.STATE_IDLE && player.getPlaybackState() != androidx.media3.common.Player.STATE_ENDED; } catch (Throwable e) { return false; }
    }

    void volume(float v) {
        try { if (player != null) player.setVolume(Math.max(0f, Math.min(1f, v))); } catch (Throwable e) { }
    }

    void stop() {
        if (pendingStop != null) { ui.removeCallbacks(pendingStop); pendingStop = null; }
        releasePlayer();
        setDisplayMode(0);
        if (box != null) box.setVisibility(View.GONE);
    }

    /* Ao sair do ecrã do canal para o Início: em vez de parar logo, mantém o canal a dar (sem som, fora da vista) uns
       segundos. Se a pré-visualização do Início pedir o mesmo canal, continua sem recarregar (transição imediata). */
    private volatile Runnable pendingStop = null;
    private int[] pageRect = null;   // última janela visível pedida pela página (a miniatura do Início)
    void notePageRect(int x, int y, int w, int h) { if (w > 20 && h > 20) pageRect = new int[]{x, y, w, h}; }
    boolean softStopping() { return pendingStop != null; }
    void stopSoon(long ms) { stopSoon(ms, false); }
    /** restore=true (veio do Início): o canal volta logo, sem som, à janela da miniatura em vez de ficar escondido; a página só confirma o mesmo canal. */
    void stopSoon(long ms, boolean restore) {
        if (player == null) { stop(); return; }
        try { setFull(false); } catch (Throwable ignored) { }
        try { player.setVolume(0f); } catch (Throwable ignored) { }
        if (restore && pageRect != null) {
            lastRect = pageRect.clone(); lastVis = true; wantVisible = true;
            try { applyRect(); if (box != null) box.setVisibility(View.VISIBLE); } catch (Throwable ignored) { }
            log("volta ao Início: canal na janela da miniatura " + pageRect[0] + "," + pageRect[1] + " " + pageRect[2] + "x" + pageRect[3]);
        } else { lastRect = new int[]{0, 0, 1, 1}; try { applyRect(); } catch (Throwable ignored) { } }
        if (pendingStop != null) ui.removeCallbacks(pendingStop);
        pendingStop = () -> { pendingStop = null; log("pré-visualização não pediu o canal: pára"); stop(); if (restore) { try { listener.onEvent("pv:lost", ""); } catch (Throwable ignored) { } } };
        ui.postDelayed(pendingStop, ms);
        log("canal mantido " + ms + " ms para a pré-visualização");
    }

    private int[] lastRect = null;

    /** Em ecrã total o leitor ocupa o ecrã inteiro (medido pelo Android, não pela página). */
    private void applyRect() {
        if (box == null) return;
        FrameLayout.LayoutParams p;
        if (full) {
            p = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        } else if (lastRect != null) {
            /* v334: nunca aplicar largura/altura 0 na TV — superfície 0x0 destrói o MediaCodec na Bravia. */
            int w = Math.max(lastRect[2], isTvDev() ? 2 : 1);
            int h = Math.max(lastRect[3], isTvDev() ? 2 : 1);
            p = new FrameLayout.LayoutParams(w, h);
            p.gravity = Gravity.TOP | Gravity.LEFT;
            p.leftMargin = lastRect[0];
            p.topMargin = lastRect[1];
        } else return;
        box.setLayoutParams(p);
    }

    /* diário de eventos do leitor (para diagnosticar paragens): mostrado em Definições › Diagnóstico do vídeo */
    private final java.util.ArrayDeque<String> dbg = new java.util.ArrayDeque<>();
    void log(String m) {
        /* v424: um só formatador (antes criava-se um por linha, e o registo tinha centenas de linhas por minuto) */
        String l;
        synchronized (dbg) {
            l = HHMMSSMS.format(new java.util.Date()) + " " + m;
            dbg.addLast(l);
            while (dbg.size() > 400) dbg.removeFirst();   /* v329: mais linhas (as religações da superfície enchiam o registo e apagavam o que interessava) */
        }
        NativeData.persist(l);
    }
    private static final java.text.SimpleDateFormat HHMMSSMS = new java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.US);
    /* v424: as linhas «rect» e «superfície» repetem-se a cada quadro da animação: regista-se só quando muda o estado, ou a cada 1 s */
    private long lastRectLogMs = 0; private boolean lastRectLogVis = false;
    private void logRect(String m, boolean vis) {
        long t = android.os.SystemClock.uptimeMillis();
        if (vis != lastRectLogVis || t - lastRectLogMs > 1000) { log(m); lastRectLogMs = t; lastRectLogVis = vis; }
    }
    private int lastSurfW = -1, lastSurfH = -1;
    String dbgDump() { synchronized (dbg) { return android.text.TextUtils.join("\n", dbg); } }
    /* 0,6 s depois de a janela do vídeo deixar de mudar: se o leitor ficou a carregar/parado (superfície presa), religa-a; volta a verificar 2,5 s depois */
    private int arTries = 0;
    private final Runnable afterResize = new Runnable() { @Override public void run() {
        if (player == null || userPaused) return;
        try {
            /* v333: no caminho hardware da Bravia não forçamos detach/reattach após redimensionar. */
            if (preferHardwarePath()) { arTries = 0; return; }
            int st = player.getPlaybackState();
            boolean buffering = st == Player.STATE_BUFFERING;
            if (buffering && bufSince != 0 && System.currentTimeMillis() - bufSince < (everReady ? 1200 : 2500)) { ui.postDelayed(this, 600); return; }   /* carregar no início é normal: dá-lhe 2,5 s */
            /* a arrancar: só é «preso» se passaram 8 s desde o play() (arrancar demora 2-3 s e causava religações desnecessárias) */
            if (!everReady && System.currentTimeMillis() - playStart < 8000) { ui.postDelayed(this, 1500); return; }
            boolean bad = player.getPlayWhenReady() && buffering && (everReady || !vodUrl);
            if (bad && arTries < 3) {
                arTries++; log("após redimensionar: leitor preso (estado=" + st + "), tentativa #" + arTries);
                if (hdrOn && hdrSv != null) { player.setVideoSurfaceView(null); player.setVideoSurfaceView(hdrSv); }
                else if (ttv != null) { player.setVideoTextureView(null); player.setVideoTextureView(ttv); }
                if (arTries >= 2) {   /* só religar a superfície não chegou (visto no diário): recria o descodificador e volta ao direto */
                    if (arTries == 2 || curUrl.isEmpty()) { player.seekToDefaultPosition(); player.prepare(); player.play(); }
                    else {
                        MediaItem.Builder b = new MediaItem.Builder().setUri(curUrl);
                        if (curMime != null) b.setMimeType(curMime);
                        if (player.isCurrentMediaItemLive()) player.setMediaItem(b.build()); else player.setMediaItem(b.build(), Math.max(0, player.getCurrentPosition() - 1000));
                        player.prepare(); player.play();
                    }
                }
                ui.postDelayed(this, arTries >= 2 ? 3000 : 1500);
            } else if (!bad) arTries = 0;
        } catch (Throwable ignored) { }
    } };
    private boolean lastVis = true;
    private long playStart = 0;
    private boolean everReady = false, vodUrl = false;   /* filmes/séries grandes demoram a arrancar: não os «recuperar» antes de terem começado */
    /** Religa a superfície do vídeo (a TextureView perde-a quando a caixa fica invisível e volta a aparecer: imagem parada com som). */
    private long fcFrames = -1; private int fcTries = 0;
    private final Runnable fullCheck = new Runnable() { @Override public void run() {
        try {
            if (player == null || !full) return;
            androidx.media3.exoplayer.DecoderCounters dc = player.getVideoDecoderCounters();
            long n = -1; if (dc != null) { dc.ensureUpdated(); n = dc.renderedOutputBufferCount; }
            boolean ready = player.getPlaybackState() == Player.STATE_READY && player.getPlayWhenReady();
            if (fcFrames < 0) { fcFrames = n; ui.postDelayed(this, 700); return; }
            boolean moving = n > fcFrames;
            fcFrames = -1;
            if (!ready) { if (fcTries++ < 4) ui.postDelayed(this, 1000); else fcTries = 0; return; }
            fcTries = 0;
            if (moving && view != null && view.getVideoSurfaceView() != null && view.getVideoSurfaceView().getVisibility() == View.VISIBLE) { log("ecrã total (da miniatura): imagem a aparecer"); return; }
            log("ecrã total (da miniatura): sem imagem visível — religa a imagem ao ecrã");
            rebindView();
        } catch (Throwable ignored) { }
    } };
    /** v296: recria a superfície do vídeo (esconde e volta a mostrar a caixa) e liga-lhe outra vez o leitor. */
    void hardRebind() {
        try {
            if (player == null || box == null || view == null || !full) return;
            /* v333: no caminho hardware da Bravia isto causava Detaching surface timed out e frames perdidos em massa. */
            if (preferHardwarePath()) {
                log("ecrã total (da miniatura): caminho hardware — hardRebind ignorado");
                if (box != null) { box.setVisibility(View.VISIBLE); wantVisible = true; lastVis = true; box.bringToFront(); }
                return;
            }
            log("ecrã total (da miniatura): recria a superfície do vídeo");
            final View sv = view.getVideoSurfaceView();
            view.setPlayer(null);
            if (sv != null) sv.setVisibility(View.GONE);
            box.setVisibility(View.INVISIBLE);
            ui.postDelayed(() -> {
                try {
                    box.setVisibility(View.VISIBLE); wantVisible = true; lastVis = true;
                    if (sv != null) sv.setVisibility(View.VISIBLE);
                    applyRect(); box.bringToFront();
                    view.setPlayer(player);
                    player.setPlayWhenReady(true);
                } catch (Throwable ignored) { }
            }, 120);
        } catch (Throwable ignored) { }
    }
    /** v308 (TV): depois de a janela do vídeo mudar (miniatura→janela, ecrã total→janela) a SurfaceView ficava preta com as imagens a serem desenhadas.
     *  500 ms depois de a janela assentar, religa a superfície uma vez; se ainda não houver imagens novas, religa outra vez e, por fim, recarrega o canal. */
    private int picFixN = 0; private boolean picChecked = false;
    private final Runnable picFix = new Runnable() { @Override public void run() {
        try {
            if (player == null || box == null || full || !wantVisible || ttv != null || !isTvDev() || userPaused || box.getVisibility() != View.VISIBLE) return;
            if (player.getVideoFormat() == null || curUrl.isEmpty()) return;
            androidx.media3.exoplayer.DecoderCounters dc = player.getVideoDecoderCounters();
            final long base; if (dc != null) { dc.ensureUpdated(); base = dc.renderedOutputBufferCount; } else base = -1;
            /* v332: só religa se a imagem estiver mesmo parada — religar sempre fazia o leitor voltar a carregar (soluço) a cada mudança de janela */
            if (picFixN == 0 && base >= 0 && !picChecked) {
                picChecked = true;
                ui.postDelayed(() -> { try { if (player == null) { picChecked = false; return; } androidx.media3.exoplayer.DecoderCounters d1 = player.getVideoDecoderCounters();
                    if (d1 != null) { d1.ensureUpdated(); if (d1.renderedOutputBufferCount > base){ picChecked = false; return; } } ui.post(picFix); } catch (Throwable t) { picChecked = false; } }, 600);
                return;
            }
            picChecked = false;
            log("janela do vídeo (TV): religa a superfície");
            rebindView(); applyRect();
            ui.postDelayed(() -> {
                try {
                    if (player == null || full || userPaused || !wantVisible) return;
                    androidx.media3.exoplayer.DecoderCounters d2 = player.getVideoDecoderCounters();
                    if (d2 == null) return; d2.ensureUpdated();
                    if (d2.renderedOutputBufferCount > base && base >= 0) return;
                    if (picFixN++ < 2) { log("janela do vídeo (TV): sem imagens novas, repete"); ui.post(picFix); return; }
                    picFixN = 0;
                    log("janela do vídeo (TV): recarrega o canal");
                    MediaItem.Builder b = new MediaItem.Builder().setUri(curUrl);
                    if (curMime != null) b.setMimeType(curMime);
                    player.setMediaItem(b.build()); player.prepare(); player.play();
                } catch (Throwable ignored) { }
            }, 1200);
        } catch (Throwable ignored) { }
    } };
    void schedulePicFix() {
        try {
            if (ttv != null || !isTvDev() || !everReady && vodUrl) return;
            /* v333: com túnel activo na Bravia, a lógica de «religa superfície» era a principal causa
               de Detaching surface timed out e frames perdidos. Desactivamos o picFix no caminho hardware. */
            if (preferHardwarePath()) return;
            picFixN = 0; ui.removeCallbacks(picFix); ui.postDelayed(picFix, 700);
        } catch (Throwable ignored) { }
    }
    /** Volta a ligar o leitor à vista (TV: superfície do PlayerView; telemóvel: TextureView). */
    void rebindView() {
        try {
            if (player == null) return;
            if (preferHardwarePath()) {
                log("rebindView: caminho hardware — só garante visibilidade, sem detach");
                if (box != null) { box.setVisibility(View.VISIBLE); box.bringToFront(); }
                if (view != null) {
                    View sv = view.getVideoSurfaceView();
                    if (sv != null && sv.getVisibility() != View.VISIBLE) sv.setVisibility(View.VISIBLE);
                }
                return;
            }
            if (ttv != null || (hdrOn && hdrSv != null)) { reattach.run(); return; }
            if (view != null) {
                View sv = view.getVideoSurfaceView();
                if (sv != null) { sv.setVisibility(View.GONE); sv.setVisibility(View.VISIBLE); }
                view.setPlayer(null); view.setPlayer(player);
                if (box != null) { box.setVisibility(View.VISIBLE); box.bringToFront(); }
            }
        } catch (Throwable ignored) { }
    }
    private final Runnable reattach = () -> {
        if (player == null) return;
        try {
            /* v333: no caminho hardware evitar setVideoSurface(null) — provoca timeout na Bravia. */
            if (preferHardwarePath()) {
                log("reattach: caminho hardware — ignorado (evita Detaching surface timed out)");
                return;
            }
            if (hdrOn && hdrSv != null) { player.setVideoSurfaceView(null); player.setVideoSurfaceView(hdrSv); }
            else if (ttv != null) { player.setVideoTextureView(null); player.setVideoTextureView(ttv); }
        } catch (Throwable ignored) { }
    };

    void rect(int x, int y, int w, int h, boolean visible) {
        if (box == null) return;
        if (full && !visible) { logRect("rect escondido ignorado (ecrã total)", false); return; }   /* a página escondia o vídeo ao mudar de canal em ecrã total */
        if (lastRect != null && lastRect[0] == x && lastRect[1] == y && lastRect[2] == w && lastRect[3] == h && lastVis == visible) return;   /* nada mudou: não mexe na vista */
        /* v335: superfície congelada na TV — ignora redimensionamentos após o 1.º frame. */
        if (surfaceFrozen && isTvDev() && !full && w > 2 && h > 2) {
            logRect("rect " + x + "," + y + " " + w + "x" + h + " ignorado (superfície congelada)", visible);
            lastVis = visible; wantVisible = visible; lastRect = new int[]{x, y, w, h};
            if (player != null && visible) box.setVisibility(View.VISIBLE);
            return;
        }
        logRect("rect " + x + "," + y + " " + w + "x" + h + (visible ? " visível" : " escondido"), visible);
        if (visible) { ui.removeCallbacks(afterResize); ui.postDelayed(afterResize, 600); if (!full) schedulePicFix(); }
        lastVis = visible;
        wantVisible = visible;
        lastRect = new int[]{x, y, w, h};
        applyRect();
        if (player != null) {
            /* v335: na TV não esconder a caixa com INVISIBLE durante reprodução — provoca superfície 0x0. */
            if (!visible && isTvDev() && gotFrame && !previewMode) {
                log("rect esconder ignorado na TV (mantém superfície)");
            } else {
                box.setVisibility(visible ? View.VISIBLE : View.INVISIBLE);
            }
        }
    }

    /** Legendas externas (SRT/VTT em texto): recria o item mantendo a posição. */
    void subtitle(String text, String label, String lang) {
        if (player == null || curUrl.isEmpty() || text == null || text.isEmpty()) return;
        try {
            boolean vtt = text.trim().startsWith("WEBVTT");
            File f = new File(act.getCacheDir(), vtt ? "sub.vtt" : "sub.srt");
            FileOutputStream o = new FileOutputStream(f);
            o.write(text.getBytes("UTF-8"));
            o.close();
            MediaItem.SubtitleConfiguration sc = new MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(f))
                    .setMimeType(vtt ? MimeTypes.TEXT_VTT : MimeTypes.APPLICATION_SUBRIP)
                    .setLanguage(lang == null || lang.isEmpty() ? "pt" : lang)
                    .setLabel(label == null ? "Legendas" : label)
                    .setSelectionFlags(C.SELECTION_FLAG_DEFAULT | C.SELECTION_FLAG_FORCED)
                    .build();
            MediaItem.Builder b = new MediaItem.Builder().setUri(curUrl).setSubtitleConfigurations(java.util.Collections.singletonList(sc));
            if (curMime != null) b.setMimeType(curMime);
            long pos = player.isCurrentMediaItemLive() ? C.TIME_UNSET : player.getCurrentPosition();
            boolean play = player.getPlayWhenReady();
            player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build());
            if (pos != C.TIME_UNSET) player.setMediaItem(b.build(), pos); else player.setMediaItem(b.build());
            player.prepare();
            player.setPlayWhenReady(play);
        } catch (Exception e) {
            listener.onEvent("suberr", String.valueOf(e));
        }
    }

    void toggle() {
        if (player == null) return;
        if (player.getPlayWhenReady()) { userPaused = true; if (player.isCurrentMediaItemLive()) userRewound = true; player.pause(); } else { userPaused = false; player.play(); }
    }

    private boolean userPaused = false;
    /** Depois de rodar o ecrã / mudar o tamanho: volta a ligar a superfície de vídeo e retoma a reprodução (a menos que tenhas pausado). */
    private final Runnable recover = () -> {
        if (player == null) return;
        try {
            if (ttv != null && !hdrOn) { player.setVideoTextureView(null); player.setVideoTextureView(ttv); }
            if (!userPaused) {
                if (player.getPlaybackState() == Player.STATE_IDLE) player.prepare();
                if (!player.getPlayWhenReady()) player.play();
            }
        } catch (Throwable ignored) { }
    };

    /** Ao voltar à app: retoma, a menos que tenhas pausado tu. */
    void resumeAfterBackground() {
        try { if (player != null && !userPaused && !player.getPlayWhenReady()) { log("app voltou ao ecrã: retoma"); player.play(); } } catch (Throwable ignored) { }
    }

    void pause() { log("pause() chamado (app em segundo plano)"); if (player != null) player.pause(); }

    /** v289: mostra a barra de progresso uns segundos (comando da TV). */
    void showSeekBar() {
        if (seekWrap == null || !seekable() || !full) return;
        seekTempUntil = System.currentTimeMillis() + 3500;
        seekWrap.setVisibility(View.VISIBLE);
        updateSeekPos();
        if (box != null) { box.removeCallbacks(hideCtl); box.postDelayed(hideCtl, 3500); }
    }
    boolean canSeek() { return seekable(); }
    private volatile long lastSeekAt = 0;
    void seek(long deltaMs) {
        lastSeekAt = System.currentTimeMillis();
        if (player == null || (player.isCurrentMediaItemLive() && !player.isCurrentMediaItemSeekable())) return;   /* direto HLS com janela: permite recuar (timeshift) */
        if (player.isCurrentMediaItemLive() && deltaMs < 0) userRewound = true;   /* recuaste de propósito: não saltar sozinho para o direto */
        long to = Math.max(0, player.getCurrentPosition() + deltaMs);
        long d = player.getDuration();
        if (d != C.TIME_UNSET && to > d) to = d;
        player.seekTo(to);
        if (seekWrap != null && full) {   /* no comando (TV) mostra a barra um instante (só em ecrã total) */
            seekTempUntil = System.currentTimeMillis() + 3500;
            seekWrap.setVisibility(View.VISIBLE);
            seekBar.setProgress((int) (to * 1000L / Math.max(1, d)));
            seekPos.setText(fmtT(to));
            seekDur.setText(remain(to, d));
            if (box != null) { box.removeCallbacks(hideCtl); box.postDelayed(hideCtl, 3500); }
        }
    }

    void pick(String type, int idx) {
        if (player == null) return;
        boolean isText = "text".equals(type);
        List<Object[]> list = isText ? text : audio;
        int ttype = isText ? C.TRACK_TYPE_TEXT : C.TRACK_TYPE_AUDIO;
        /* filmes e episódios: trocar a faixa não pode mexer na posição */
        final boolean keepPos = !player.isCurrentMediaItemLive() && player.getPlaybackState() != Player.STATE_IDLE && player.getPlaybackState() != Player.STATE_ENDED;
        final long keep = keepPos ? player.getCurrentPosition() : -1, t0 = System.currentTimeMillis();
        final String url0 = curUrl;
        TrackSelectionParameters.Builder b = player.getTrackSelectionParameters().buildUpon();
        if (idx < 0 || idx >= list.size()) {
            if (isText) b.setTrackTypeDisabled(ttype, true);
        } else {
            Object[] t = list.get(idx);
            Tracks.Group g = (Tracks.Group) t[0];
            int i = (Integer) t[1];
            b.setTrackTypeDisabled(ttype, false);
            b.setOverrideForType(new TrackSelectionOverride(g.getMediaTrackGroup(), i));
        }
        player.setTrackSelectionParameters(b.build());
        if (keep > 3000) {
            for (long d : new long[]{600, 1500, 3000, 6000}) {
                ui.postDelayed(() -> {
                    try {
                        if (player == null || lastSeekAt > t0 || !url0.equals(curUrl)) return;
                        long p = player.getCurrentPosition();
                        if (p < keep - 4000) { log("faixa trocada: a posição voltou atrás (" + p / 1000 + " s), repõe " + keep / 1000 + " s"); player.seekTo(keep); }
                    } catch (Throwable ignored) { }
                }, d);
            }
        }
    }

    private static String q(String s) {
        return "\"" + s.replace("\\", "\\\\").replace("\"", "'").replace("\n", " ") + "\"";
    }

    private static String name(Format f, int n) {
        StringBuilder s = new StringBuilder();
        if (f.label != null && !f.label.isEmpty()) s.append(f.label);
        if (f.language != null && !"und".equals(f.language)) {
            if (s.length() > 0) s.append(" · ");
            s.append(f.language);
        }
        if (f.channelCount > 2) s.append(" · ").append(f.channelCount == 6 ? "5.1" : f.channelCount == 8 ? "7.1" : f.channelCount + "ch");
        String m = f.sampleMimeType;
        if (m != null) {
            String c = MimeTypes.AUDIO_AC3.equals(m) ? "AC-3" : MimeTypes.AUDIO_E_AC3.equals(m) || MimeTypes.AUDIO_E_AC3_JOC.equals(m) ? "E-AC-3"
                    : MimeTypes.AUDIO_AAC.equals(m) ? "AAC" : m.startsWith("audio/") ? m.substring(6).toUpperCase() : "";
            if (!c.isEmpty()) s.append(" · ").append(c);
        }
        return s.length() == 0 ? "Faixa " + (n + 1) : s.toString();
    }

    private void rebuildTracks(Tracks t) {
        audio.clear();
        text.clear();
        StringBuilder a = new StringBuilder(), x = new StringBuilder();
        boolean anyAudio = false, okAudio = false;
        for (Tracks.Group g : t.getGroups()) {
            int type = g.getType();
            if (type == C.TRACK_TYPE_AUDIO) {
                anyAudio = true;
                if (g.isSelected() && g.isSupported()) okAudio = true;
            }
            if (type != C.TRACK_TYPE_AUDIO && type != C.TRACK_TYPE_TEXT) continue;
            for (int i = 0; i < g.length; i++) {
                if (!g.isTrackSupported(i)) continue;
                boolean isAudio = type == C.TRACK_TYPE_AUDIO;
                List<Object[]> list = isAudio ? audio : text;
                StringBuilder sb = isAudio ? a : x;
                if (sb.length() > 0) sb.append(',');
                sb.append("{\"i\":").append(list.size()).append(",\"name\":").append(q(name(g.getTrackFormat(i), list.size())))
                        .append(",\"on\":").append(g.isTrackSelected(i)).append('}');
                list.add(new Object[]{g, i});
            }
        }
        tracksJson = "{\"audio\":[" + a + "],\"text\":[" + x + "]}";
        if (anyAudio && !okAudio) listener.onEvent("noaudio", "");
    }

    void release() {
        try { if (dispL != null) ((android.hardware.display.DisplayManager) act.getSystemService(android.content.Context.DISPLAY_SERVICE)).unregisterDisplayListener(dispL); dispL = null; } catch (Throwable ignored) { }
        releasePlayer();
        if (box != null) { try { root.removeView(box); } catch (Exception ignored) { } box = null; view = null; label = null; }
    }
}
