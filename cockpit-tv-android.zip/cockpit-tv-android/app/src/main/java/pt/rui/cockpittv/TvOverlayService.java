package pt.rui.cockpittv;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.content.pm.ServiceInfo;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Contorno ao bloqueio do sintonizador Sony: o canal é sintonizado pela API Bravia
 * (setPlayContent -> leitor nativo da Sony em ecrã inteiro) e esta janela de
 * sobreposição desenha por cima o painel do Cockpit TV.
 *
 * Comando com o painel aberto: OK muda de canal · CH+/CH- zapping · VOLTAR fecha o painel.
 * Requer "Sobrepor a outras apps" (SYSTEM_ALERT_WINDOW); na Bravia ativa-se por adb:
 *   adb shell appops set pt.rui.cockpittv SYSTEM_ALERT_WINDOW allow
 */
public class TvOverlayService extends Service {
    public static final String EXTRA_IP = "ip", EXTRA_PSK = "psk", EXTRA_URI = "uri", EXTRA_LIST = "list";
    private static final String NOTIF_CH = "cockpit_overlay";

    private static class Ch { String num, title, uri; }

    private final List<Ch> channels = new ArrayList<>();
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final Handler main = new Handler(Looper.getMainLooper());
    private WindowManager wm;
    private View panel;
    private LinearLayout listView;
    private TextView status;
    private String ip = "", psk = "";
    private int current = 0;
    private boolean panelHidden = false;
    private static final long HIDE_MS = 5000;
    private final Runnable hideRun = this::hidePanel;

    public static void start(Context ctx, String ip, String psk, String listJson, String uri) {
        Intent i = new Intent(ctx, TvOverlayService.class)
                .putExtra(EXTRA_IP, ip).putExtra(EXTRA_PSK, psk)
                .putExtra(EXTRA_LIST, listJson).putExtra(EXTRA_URI, uri);
        if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i); else ctx.startService(i);
    }

    public static void stop(Context ctx) { ctx.stopService(new Intent(ctx, TvOverlayService.class)); }

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override
    public void onCreate() {
        super.onCreate();
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        startAsForeground();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) { stopSelf(); return START_NOT_STICKY; }
        ip = str(intent.getStringExtra(EXTRA_IP));
        psk = str(intent.getStringExtra(EXTRA_PSK));
        String uri = str(intent.getStringExtra(EXTRA_URI));
        channels.clear();
        try {
            JSONArray a = new JSONArray(str(intent.getStringExtra(EXTRA_LIST)));
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Ch c = new Ch(); c.num = o.optString("num"); c.title = o.optString("name"); c.uri = o.optString("uri");
                channels.add(c);
            }
        } catch (Exception ignored) { }
        current = 0;
        for (int i = 0; i < channels.size(); i++) if (channels.get(i).uri.equals(uri)) { current = i; break; }
        if (panel != null) { removePanel(); }
        zap(current);
        // dá tempo à app TV da Sony para abrir antes de desenhar por cima
        main.postDelayed(this::showPanel, 1200);
        return START_NOT_STICKY;
    }

    private static String str(String s) { return s == null ? "" : s; }

    private void zap(int index) {
        if (channels.isEmpty()) return;
        current = ((index % channels.size()) + channels.size()) % channels.size();
        final Ch c = channels.get(current);
        setStatus("A sintonizar " + c.num + " " + c.title + "…");
        if (panel != null) scheduleHide();
        highlightCurrent();
        io.execute(() -> {
            final String msg = setPlayContent(c.uri) ? "A ver: " + c.num + "  " + c.title : lastError;
            main.post(() -> setStatus(msg));
        });
    }

    private volatile String lastError = "";

    /** JSON-RPC avContent.setPlayContent na API Bravia. */
    private boolean setPlayContent(String uri) {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("http://" + ip + "/sony/avContent").openConnection();
            c.setConnectTimeout(3000); c.setReadTimeout(6000);
            c.setRequestMethod("POST"); c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            if (!psk.isEmpty()) c.setRequestProperty("X-Auth-PSK", psk);
            JSONObject body = new JSONObject().put("method", "setPlayContent").put("id", 1).put("version", "1.0")
                    .put("params", new JSONArray().put(new JSONObject().put("uri", uri)));
            c.getOutputStream().write(body.toString().getBytes("UTF-8"));
            int code = c.getResponseCode();
            if (code == 403) { lastError = "Erro: chave PSK errada (403)"; return false; }
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            ByteArrayOutputStream o = new ByteArrayOutputStream();
            if (in != null) { byte[] b = new byte[4096]; int n; while ((n = in.read(b)) > 0) o.write(b, 0, n); }
            JSONObject r = new JSONObject(o.toString("UTF-8"));
            JSONArray err = r.optJSONArray("error");
            if (err != null) { lastError = "Erro " + err.optInt(0) + ": " + err.optString(1); return false; }
            return true;
        } catch (Exception e) {
            lastError = "Erro: não consegui ligar à TV (" + e.getMessage() + ")";
            return false;
        } finally { if (c != null) c.disconnect(); }
    }

    private void setStatus(String t) { if (status != null) status.setText(t); }

    private int dp(int v) {
        return (int) TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, getResources().getDisplayMetrics());
    }

    private GradientDrawable itemBg(boolean focused, boolean playing) {
        GradientDrawable g = new GradientDrawable();
        g.setCornerRadius(dp(12));
        g.setColor(focused ? 0xFF5AA9F0 : playing ? 0x553B82F6 : 0x22FFFFFF);
        return g;
    }

    private void highlightCurrent() {
        if (listView == null) return;
        for (int i = 0; i < channels.size() && i < listView.getChildCount(); i++) {
            View v = listView.getChildAt(i);
            v.setBackground(itemBg(v.hasFocus(), i == current));
        }
    }

    private void scheduleHide() {
        main.removeCallbacks(hideRun);
        main.postDelayed(hideRun, HIDE_MS);
    }

    /** Esconde a lista (a janela continua a receber o comando). */
    private void hidePanel() {
        if (panel == null) return;
        panelHidden = true;
        panel.animate().alpha(0f).setDuration(250).start();
    }

    private void showPanelAgain() {
        if (panel == null) return;
        panelHidden = false;
        panel.animate().cancel();
        panel.setAlpha(1f);
        View f = listView != null ? listView.getChildAt(current) : null;
        if (f != null && (listView.findFocus() == null)) f.requestFocus();
        scheduleHide();
    }

    /** Traz o Cockpit TV para a frente e fecha o painel. */
    private void backToApp() {
        try {
            Intent a = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_REORDER_TO_FRONT | Intent.FLAG_ACTIVITY_SINGLE_TOP);
            startActivity(a);
        } catch (Throwable ignored) { }
        stopSelf();
    }

    private void showPanel() {
        if (panel != null) return;
        FrameLayout root = new FrameLayout(this) {
            @Override public boolean dispatchKeyEvent(KeyEvent e) {
                int k = e.getKeyCode();
                if (e.getAction() == KeyEvent.ACTION_DOWN) {
                    boolean wasHidden = panelHidden;
                    if (wasHidden) showPanelAgain(); else scheduleHide();
                    // com a lista escondida, a 1.ª seta/OK só a mostra (não muda de canal por engano)
                    if (wasHidden && (k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN || k == KeyEvent.KEYCODE_DPAD_LEFT
                            || k == KeyEvent.KEYCODE_DPAD_RIGHT || k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER)) return true;
                }
                if (panelHidden && e.getAction() == KeyEvent.ACTION_UP && (k == KeyEvent.KEYCODE_DPAD_UP || k == KeyEvent.KEYCODE_DPAD_DOWN
                        || k == KeyEvent.KEYCODE_DPAD_LEFT || k == KeyEvent.KEYCODE_DPAD_RIGHT || k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER)) return true;
                if (k == KeyEvent.KEYCODE_BACK || k == KeyEvent.KEYCODE_CHANNEL_UP || k == KeyEvent.KEYCODE_CHANNEL_DOWN) {
                    if (e.getAction() == KeyEvent.ACTION_UP) {
                        if (k == KeyEvent.KEYCODE_BACK) backToApp();
                        else zap(current + (k == KeyEvent.KEYCODE_CHANNEL_UP ? 1 : -1));
                    }
                    return true;
                }
                return super.dispatchKeyEvent(e);
            }
        };
        GradientDrawable bg = new GradientDrawable();
        bg.setColor(0xE60F1A3D);
        float r = dp(24);
        bg.setCornerRadii(new float[]{0, 0, r, r, r, r, 0, 0});
        root.setBackground(bg);

        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        col.setPadding(dp(24), dp(24), dp(24), dp(24));

        TextView title = new TextView(this);
        title.setText("Cockpit TV · TV Direto");
        title.setTextColor(Color.WHITE); title.setTextSize(22);
        col.addView(title);

        status = new TextView(this);
        status.setTextColor(0xFF9EC9FF); status.setTextSize(15);
        status.setPadding(0, dp(8), 0, dp(16));
        col.addView(status);

        listView = new LinearLayout(this);
        listView.setOrientation(LinearLayout.VERTICAL);
        for (int i = 0; i < channels.size(); i++) {
            final int idx = i;
            Ch c = channels.get(i);
            listView.addView(item(c.num + "    " + c.title, v -> zap(idx)));
        }
        listView.addView(item("⟵  Voltar ao Cockpit", v -> backToApp()));
        ScrollView sv = new ScrollView(this);
        sv.addView(listView);
        col.addView(sv, new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView hint = new TextView(this);
        hint.setText("OK mudar · CH+/CH− zapping · a lista esconde-se após 5 s · VOLTAR regressa ao Cockpit");
        hint.setTextColor(0xFFB0B8D0); hint.setTextSize(13);
        hint.setPadding(0, dp(12), 0, 0);
        col.addView(hint);
        root.addView(col);

        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                (int) (getResources().getDisplayMetrics().widthPixels * 0.32f),
                WindowManager.LayoutParams.MATCH_PARENT, type,
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN, // focável: recebe o comando
                PixelFormat.TRANSLUCENT);
        lp.gravity = Gravity.START | Gravity.TOP;
        try {
            wm.addView(root, lp);
        } catch (Exception e) { // sem permissão de sobreposição
            stopSelf();
            return;
        }
        panel = root;
        panelHidden = false;
        scheduleHide();
        highlightCurrent();
        View f = listView.getChildAt(current);
        if (f != null) f.requestFocus();
    }

    private TextView item(String text, View.OnClickListener click) {
        TextView t = new TextView(this);
        t.setText(text);
        t.setTextSize(18);
        t.setTextColor(Color.WHITE);
        t.setPadding(dp(16), dp(12), dp(16), dp(12));
        t.setFocusable(true);
        t.setClickable(true);
        t.setOnFocusChangeListener((v, has) -> highlightCurrent());
        t.setOnClickListener(click);
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        p.bottomMargin = dp(6);
        t.setLayoutParams(p);
        t.setBackground(itemBg(false, false));
        return t;
    }

    private void removePanel() {
        if (panel != null) try { wm.removeView(panel); } catch (Exception ignored) { }
        panel = null; listView = null; status = null; panelHidden = false; main.removeCallbacks(hideRun);
    }

    private void startAsForeground() {
        Notification.Builder b;
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            nm.createNotificationChannel(new NotificationChannel(NOTIF_CH, "Painel TV Direto", NotificationManager.IMPORTANCE_MIN));
            b = new Notification.Builder(this, NOTIF_CH);
        } else b = new Notification.Builder(this);
        Notification n = b.setContentTitle("Cockpit TV").setContentText("Painel de canais ativo")
                .setSmallIcon(android.R.drawable.ic_media_play).build();
        if (Build.VERSION.SDK_INT >= 34) startForeground(7, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        else startForeground(7, n);
    }

    @Override
    public void onDestroy() {
        main.removeCallbacksAndMessages(null);
        removePanel();
        io.shutdownNow();
        super.onDestroy();
    }
}
