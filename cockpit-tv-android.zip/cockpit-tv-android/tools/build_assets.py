#!/usr/bin/env python3
"""Gera app/src/main/assets/index.html (só IPTV) a partir do index.html do Cockpit.
Uso: python3 tools/build_assets.py [caminho/para/cockpit/index.html]"""
import sys, os
src = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), "..", "..", "cockpit", "index.html")
out = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "index.html")
h = open(src, encoding="utf-8").read()

def rep(old, new, count=1):
    global h
    if h.count(old) != count:
        sys.exit("Não encontrei (ou há repetições) de: " + old[:70])
    h = h.replace(old, new)

rep("<head>", '<head>\n<script>window.ANDROID = (typeof Android !== "undefined");</script>')
rep("<title>Cockpit", "<title>Cockpit TV")
rep('id="bootLogo">COCKPIT<', 'id="bootLogo">COCKPIT TV<')
rep("function px(url, ref, ua){\n  if(!url) return url;", "function px(url, ref, ua){\n  if(!url || window.ANDROID) return url;")
rep("function px2(url, ref, ua){\n  if(!url || !cfg.proxy2 || !cfg.proxy) return url;", "function px2(url, ref, ua){\n  if(!url || window.ANDROID || !cfg.proxy2 || !cfg.proxy) return url;")
rep("const HASPX = () => !!(PHONE || cfg.proxy2 || cfg.proxy);", "const HASPX = () => !window.ANDROID && !!(PHONE || cfg.proxy2 || cfg.proxy);")
rep('const PAGE_HTTP = location.protocol === "http:" && !PHONE;', 'const PAGE_HTTP = (location.protocol === "http:" && !PHONE) || !!window.ANDROID;')
rep('let mirrorOn = LS.get("mirror", false);', 'let mirrorOn = LS.get("mirror", false) && !window.ANDROID;')
rep('if(window.top !== window || location.protocol==="file:") return',
    'if(window.ANDROID) return "Não consegui ligar ao servidor (" + e.message + "). Confirma o endereço, o utilizador e a palavra-passe e a ligação à internet.";\n  if(window.top !== window || location.protocol==="file:") return')
rep("function show(view){\n", 'function show(view){\n  if(window.ANDROID && !["settings","tv","tvhome"].includes(view)) view = "tvhome";\n')
rep("applyPassenger(); applyLayout();", 'if(window.ANDROID){ cfg.layout = "classic"; cfg.passenger = false; }\napplyPassenger(); applyLayout();')
rep('\nif(passengerImport()) show("tv");', '\nif(window.ANDROID) show("tvhome");\nelse if(passengerImport()) show("tv");')

# --- leitor nativo (Media3): ganchos no código do Cockpit ---
rep("  if(isTs && live){ tryTs(); }\n  else if(isFlv || isFileTs){", "  if(window.NATIVE && NATIVE.go(c, slot, playId, fail)){ /* leitor nativo */ }\n  else if(isTs && live){ tryTs(); }\n  else if(isFlv || isFileTs){")
rep("  audioWatch(slot, c, playId, () => fileViaHls && fileViaHls());", "  if(!(window.NATIVE && NATIVE.active)) audioWatch(slot, c, playId, () => fileViaHls && fileViaHls());")
rep("function stopSlot(slot){\n", "function stopSlot(slot){\n  if(window.NATIVE && slot === 0) NATIVE.stop();\n")
rep("function trkAddExt(slot, text, label){\n", "function trkAddExt(slot, text, label){\n  if(window.NATIVE && NATIVE.active && slot === 0){ NATIVE.subText(text, label); return; }\n")
rep("function trkShift(slot, d){\n", "function trkShift(slot, d){\n  if(window.NATIVE && NATIVE.active && slot === 0){ NATIVE.shift(d); return; }\n")
rep("function osHasPt(slot){", "function osHasPt(slot){ if(window.NATIVE && NATIVE.active && slot === 0) return NATIVE.tracks('text').some(t => trkIsPt(t.name)) || !!NATIVE.subBase;\n  return osHasPt0(slot); }\nfunction osHasPt0(slot){")
rep("function trkAudioList(slot){\n", "function trkAudioList(slot){\n  if(window.NATIVE && NATIVE.active && slot === 0){ const t = NATIVE.tracks('audio'); if(t.length) return {kind:'nat', items:t}; }\n")
rep("function trkSetAudio(slot, kind, i){\n", "function trkSetAudio(slot, kind, i){\n  if(kind === 'nat'){ NATIVE.pick('audio', i); return; }\n")
rep("function trkSubList(slot){\n  const h = hlsInst[slot], v = $(\"vid\"+slot), items = [];\n", "function trkSubList(slot){\n  const h = hlsInst[slot], v = $(\"vid\"+slot), items = [];\n  if(window.NATIVE && NATIVE.active && slot === 0){ NATIVE.tracks('text').forEach(t => items.push({kind:'nat', i:t.i, name:t.name, on:t.on})); return items; }\n")
rep("function trkSubsOff(slot){\n", "function trkSubsOff(slot){\n  if(window.NATIVE && NATIVE.active && slot === 0){ NATIVE.pick('text', -1); return; }\n")
rep("function trkSetSub(slot, it){\n  trkSubsOff(slot); if(!it) return;\n", "function trkSetSub(slot, it){\n  trkSubsOff(slot); if(!it) return;\n  if(it.kind === 'nat'){ NATIVE.pick('text', it.i); return; }\n")

CSS = """
/* ===== Cockpit TV (Android) ===== */
body.android .rail,body.android .tsonly,body.android #tsPanel,body.android #chipCar,body.android #chipNet,body.android #lockNow,body.android #teslaFs,body.android #heard,body.android #micBtn{display:none!important}
body.android .app{grid-template-columns:1fr!important;grid-template-rows:54px 1fr!important}
body.android .top{grid-column:1!important;grid-row:1!important;padding:0 14px;gap:10px}
body.android main{grid-column:1!important;grid-row:2!important}
body.android .app.cinema{grid-template-rows:54px 1fr!important}
body.android .clock{font-size:22px}
body.android :focus-visible{outline:4px solid var(--accent)!important;outline-offset:3px;box-shadow:0 0 0 8px color-mix(in srgb,var(--accent) 30%,transparent)}
body.android .item:focus-visible{background:var(--panel-2)}
body.android.tv .app{padding:14px 22px 0;box-sizing:border-box}
body.android.tv .btn,body.android.tv .tab{min-height:46px;padding-block:6px}
body.android.tv .item{min-height:52px}
body.android.tv{font-size:16px}
body.android #btnFull,body.android #btnMirror{display:none!important}
/* ===== Android TV: visual moderno ===== */
body.android{background:radial-gradient(1100px 520px at 85% -8%,color-mix(in srgb,var(--accent) 20%,transparent),transparent),linear-gradient(180deg,#0a101c,#04070d)!important}
body.android .top{background:linear-gradient(180deg,color-mix(in srgb,var(--accent) 30%,#0b1424),color-mix(in srgb,var(--accent) 14%,#08101c))!important;border:0!important;border-bottom:2px solid color-mix(in srgb,var(--accent) 55%,transparent)!important;box-shadow:0 6px 24px rgba(0,0,0,.45)!important;height:72px;padding:0 28px;gap:18px;position:relative;z-index:5}
body.android .top .btn[data-v],body.android #atvHome,body.android #chipDrive,body.android #chipCar,body.android #chipNet{display:none!important}
body.android .clock{font-size:26px;font-weight:700;letter-spacing:.02em}
.thNav{display:flex;gap:8px;margin-left:18px}
.thTab{display:inline-flex;align-items:center;gap:8px;min-height:50px;padding:6px 22px;border:0;border-radius:999px;background:transparent;color:inherit;font:600 18px/1 inherit;opacity:.78}
.thTab span{font-size:20px}
.thTab[aria-current="page"]{background:var(--accent);color:var(--accent-ink);opacity:1}
body.android .thTab:focus-visible{outline:3px solid #fff!important;outline-offset:2px;box-shadow:none;opacity:1}
#v-tvhome{padding:4px 28px 40px;box-sizing:border-box}
#exitDlg{position:fixed;inset:0;z-index:300;background:#000b;display:flex;align-items:center;justify-content:center}
#exitDlg[hidden]{display:none}
#exitDlg .exBox{background:#121b2e;border-radius:22px;padding:28px 36px;min-width:min(520px,80vw);text-align:center;box-shadow:0 20px 60px #000a}
#exitDlg h2{margin:0 0 6px;font-size:28px}#exitDlg p{margin:0 0 20px;font-size:18px;opacity:.8}
#exitDlg .exBt{display:flex;gap:14px;justify-content:center}#exitDlg .btn{min-width:150px;min-height:54px;font-size:19px}
body.exitOpen .app{pointer-events:none}
.thBar{position:absolute;left:0;right:0;bottom:0;height:6px;background:#0008;z-index:2}.thBar i{display:block;height:100%;background:var(--accent,#7cc4ff)}
.tplGrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px}
.tplBtn{flex-direction:column;align-items:flex-start!important;justify-content:flex-start!important;text-align:left!important;height:auto;padding:12px 16px!important;gap:3px}
.tplBtn small{font-size:13px;opacity:.7;font-weight:400;white-space:normal}
.tplBtn[aria-pressed=true]{background:var(--accent)!important;color:var(--accent-ink)!important}
body.tl-cinema .thCard{flex-basis:340px}body.tl-cinema .thHero{min-height:300px}body.tl-cinema .thHeroTx h1{font-size:50px}body.tl-cinema .thMeta b{font-size:22px}body.tl-cinema .thHeroArt{flex-basis:340px}
body.tl-compacto .thHero{display:none}body.tl-compacto .thCard{flex-basis:190px}body.tl-compacto .thMeta b{font-size:15px}body.tl-compacto .thMeta small{display:none}body.tl-compacto .thRow h2{font-size:20px;margin-top:8px}body.tl-compacto .thScroll{gap:12px;padding-bottom:14px}
body.tl-grelha .thScroll{flex-wrap:wrap;overflow:visible}
body.tl-grande{font-size:22px!important}body.tl-grande .thCard{flex-basis:300px}body.tl-grande .thMeta b{font-size:24px}body.tl-grande .thMeta small{font-size:18px}body.tl-grande .thRow h2{font-size:30px}body.tl-grande .thTab{font-size:22px}body.tl-grande .thBtn{font-size:23px}body.tl-grande .btn,body.tl-grande .tab{font-size:20px!important}
body.ov-1.android .app{padding:32px 48px 0!important}body.ov-2.android .app{padding:56px 80px 0!important}
#castBanner{position:fixed;left:50%;bottom:18px;transform:translateX(-50%);z-index:260;display:flex;align-items:center;gap:10px;padding:10px 16px;border-radius:16px;background:#121b2ef2;box-shadow:0 10px 36px #000a;max-width:94vw}
#castBanner[hidden]{display:none}#castBanner span{font-weight:700;max-width:46vw;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.epgdlg .detbox{display:flex!important;flex-direction:row!important;align-items:flex-start;gap:26px;width:min(1100px,94vw);max-height:90vh;padding:24px;box-sizing:border-box;overflow:hidden}
.detposter{flex:0 0 240px;aspect-ratio:2/3;border-radius:16px;background:linear-gradient(135deg,#1d2a47,#0d1424);display:flex;align-items:center;justify-content:center;overflow:hidden;align-self:flex-start}
.detposter img{width:100%;height:100%;object-fit:cover}.detposter b{font-size:56px;opacity:.4}
.dettx{flex:1;min-width:0;display:flex;flex-direction:column;gap:10px;overflow:hidden}
.dettx h2{margin:0;font-size:30px;line-height:1.15}
.detmeta{font-size:17px;opacity:.9}.detrate{color:#ffd166;margin-right:6px}
.detplot{flex:0 1 auto;min-height:96px;font-size:17px;line-height:1.45;overflow-y:auto;max-height:36vh;padding:4px 8px 4px 2px;border-radius:10px}
.detplot:focus-visible{outline:3px solid var(--accent)!important}
.detcrew{font-size:15px;opacity:.8;display:flex;flex-direction:column;gap:4px;max-height:16vh;overflow:hidden}
.detbt{display:flex;gap:12px;flex-wrap:wrap;margin-top:auto;padding-top:6px}
@media (max-width:700px){.epgdlg .detbox{flex-direction:column!important;overflow-y:auto}.detposter{flex-basis:auto;width:42%}}
.ic{width:1.2em;height:1.2em;flex:none;vertical-align:-.22em;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;margin-inline:.1em}
.thTab .ic{width:1.35em;height:1.35em}
#tvSetGrid{grid-column:1/-1;width:100%;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;align-items:start;padding-bottom:48px}
#tvSetGrid .setcard{padding:0!important;overflow:hidden;scroll-margin-top:96px}
#tvSetGrid .setcard.open{grid-column:1/-1}
#tvSetGrid .setcard>h2{display:none}
.setHead{display:flex;align-items:center;gap:16px;width:100%;padding:16px 22px;border:0;background:transparent;color:inherit;text-align:left;font:inherit;border-radius:20px;min-height:84px;cursor:pointer}
.setHead .setIc{width:52px;height:52px;border-radius:14px;background:color-mix(in srgb,var(--accent) 22%,transparent);display:flex;align-items:center;justify-content:center;flex:none}
.setHead .setIc .ic{width:28px;height:28px;margin:0}
.setHead .setT{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}.setHead b{font-size:21px}.setHead small{font-size:15px;opacity:.7}
.setHead .chev .ic{width:22px;height:22px;opacity:.7;transition:transform .15s}.setcard.open .chev .ic{transform:rotate(90deg)}
.setBody{padding:4px 22px 22px;display:flex;flex-direction:column;gap:12px}.setBody[hidden]{display:none}
.keyList{display:flex;flex-direction:column;gap:8px}.keyList div{display:flex;gap:16px;align-items:baseline}.keyList b{flex:0 0 190px;font-size:17px}.keyList span{opacity:.85;font-size:16px}
@media (max-width:800px){#tvSetGrid{grid-template-columns:1fr}.keyList b{flex-basis:120px}}
.thKinds{display:flex;gap:12px;margin:6px 0 4px}
.thKind{min-width:150px}
.thKind[aria-pressed=true]{background:#7cc4ff;color:#06101f;border-color:#7cc4ff}
.thHero{display:flex;align-items:center;gap:30px;padding:26px 32px;margin:2px 0 14px;border-radius:26px;min-height:210px;background:linear-gradient(120deg,color-mix(in srgb,var(--accent) 38%,#0d1526),#0d1526 72%);box-shadow:0 18px 50px #0007}
.thHeroArt{flex:0 0 250px;aspect-ratio:16/9;border-radius:18px;background:#0b1220cc;display:flex;align-items:center;justify-content:center;overflow:hidden}
.thHeroArt img{max-width:70%;max-height:70%;object-fit:contain}
.thHeroArt b{font-size:44px;opacity:.6}
.thHeroTx{flex:1;min-width:0;display:flex;flex-direction:column;gap:8px}
.thHeroTx small{font-size:15px;letter-spacing:.14em;text-transform:uppercase;opacity:.7}
.thHeroTx h1{margin:0;font-size:38px;line-height:1.1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.thHeroTx p{margin:0;font-size:19px;opacity:.85;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.thHeroBt{display:flex;gap:12px;margin-top:8px;flex-wrap:wrap}
.thBtn{min-height:54px;padding:8px 26px;border:0;border-radius:14px;background:#ffffff1f;color:inherit;font:600 19px/1 inherit}
.thBtn.pri{background:var(--accent);color:var(--accent-ink)}
body.android .thBtn:focus-visible{outline:3px solid #fff!important;outline-offset:3px;box-shadow:none;transform:scale(1.04)}
.thRow h2{margin:18px 4px 2px;font-size:24px;font-weight:700;letter-spacing:.01em;text-transform:none}
@media (max-height:800px){.thHero{min-height:0;padding:14px 24px;gap:20px;margin-bottom:6px}.thHeroArt{flex-basis:170px}.thHeroTx h1{font-size:28px}.thHeroTx p{font-size:16px}.thHeroTx small{font-size:12px}.thHeroBt{margin-top:2px}.thBtn{min-height:44px;padding:6px 20px;font-size:17px}.thKind{min-width:120px}.thRow h2{margin-top:10px;font-size:21px}}
.thScroll{display:flex;gap:18px;overflow-x:auto;padding:12px 10px 26px;scrollbar-width:none;scroll-padding:0 40px}
.thScroll::-webkit-scrollbar{display:none}
.thCard{flex:0 0 244px;border:0;border-radius:18px;background:var(--panel,#121b2e);color:inherit;padding:0;text-align:left;overflow:hidden;transition:transform .09s,box-shadow .09s;box-shadow:0 6px 18px #0006}
.thCard.sm{flex-basis:200px}
body.android .thCard:focus-visible{outline:none!important;transform:scale(1.08);box-shadow:0 0 0 4px var(--accent),0 20px 44px #000b;position:relative;z-index:3}
.thArt{display:flex;align-items:center;justify-content:center;aspect-ratio:16/9;background:linear-gradient(135deg,#1d2a47,#0d1424);position:relative}
.thArt img{max-width:60%;max-height:62%;object-fit:contain}
.thArt img+.thInit{display:none}
.thInit{font-size:34px;font-weight:800;opacity:.45;letter-spacing:.04em}
.thMeta{display:block;padding:10px 14px 13px}
.thMeta b{display:block;font-size:18px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.thMeta small{display:block;margin-top:3px;font-size:14px;opacity:.7;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.thMore{display:flex;align-items:center;justify-content:center;min-height:170px;font:700 20px/1 inherit;background:#ffffff14}
.thEmpty{padding:30px 6px;font-size:20px;opacity:.75}
/* Explorar e leitor: sem confusão de ecrã duplo */
body.android #v-tv>.row .tabs,body.android #btnCinema,body.android #btnSwapAudio,body.android .slot .rot,body.android .slot .lbl,body.android #v-tv .tvwrap>.panel:last-child>.row,body.android #mirDelMinus,body.android #mirDelVal,body.android #mirDelPlus,body.android #v-tv>.row>h1{display:none!important}
body.android #v-tv.cinema .cinebar{display:grid!important;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;width:min(100%,calc((100vh - 180px) * 16 / 9))!important;margin:12px auto 0!important;flex-wrap:wrap}
body.android #v-tv.cinema .cinebar .cinename{grid-column:1/-1;order:0;text-align:center;font-size:24px;font-weight:700;margin-bottom:2px}
body.android #v-tv.cinema .cinebar .btn{width:100%;white-space:nowrap;justify-content:center}
body.android #v-tv.cinema #chPrev{order:1}body.android #v-tv.cinema #chGuide{order:2}body.android #v-tv.cinema #chTracks{order:3}body.android #v-tv.cinema #chSubs{order:4}body.android #v-tv.cinema #chNext{order:5}
body.android #v-tv.cinema .stage{width:min(100%,calc((100vh - 180px) * 16 / 9))!important}
body.android .view{max-width:none!important}
body.android.tv{font-size:18px}
body.android.tv .btn,body.android.tv .tab{min-height:52px!important;font-size:17px}
body.android .panel{border-radius:20px;border:0;background:color-mix(in srgb,var(--panel,#121b2e) 92%,transparent)}

/* ===== Botões uniformes, alinhados e sem sobreposição ===== */
body.android .btn,body.android .tab{min-height:44px!important;padding:8px 14px;font-size:15px;line-height:1.15;box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;text-align:center;gap:6px}
body.android .row{align-items:center;gap:10px}
body.android #v-tv>.row{display:flex!important;flex-wrap:wrap!important;gap:10px;align-items:center}
body.android #v-tv>.row .tabs{display:flex;gap:6px;flex-wrap:nowrap}
body.android .tvwrap>.panel:first-child .tabs{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;overflow:visible!important}
body.android .tvwrap>.panel:first-child .tab{min-width:0;font-size:12px!important;padding:6px 2px!important;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
body.android #freeTools{display:grid!important;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:center}
body.android #freeTools .btn{width:100%}
body.android #freeTools #healthMsg{grid-column:1/-1;margin:0}
body.android .tvwrap>.panel:first-child input[type=search],body.android .tvwrap>.panel:first-child select,body.android #btnOrg{width:100%;box-sizing:border-box;min-height:44px!important}
body.android #v-tv:not(.cinema) .cinebar{display:grid!important;grid-template-columns:repeat(auto-fit,minmax(84px,1fr));gap:6px;align-items:stretch}
body.android #v-tv:not(.cinema) #chPrev{order:1}body.android #v-tv:not(.cinema) #chGuide{order:2}body.android #v-tv:not(.cinema) #chTracks{order:3}body.android #v-tv:not(.cinema) #chSubs{order:4}body.android #v-tv:not(.cinema) #chNext{order:5}body.android #v-tv:not(.cinema) #mirDelMinus{order:6}body.android #v-tv:not(.cinema) #mirDelVal{order:7;grid-column:span 2;text-align:center;align-self:center}body.android #v-tv:not(.cinema) #mirDelPlus{order:8}
#chSubs[hidden]{display:none!important}
body.android #v-tv:not(.cinema) .cinebar .cinename{grid-column:1/-1;order:0;text-align:center}
body.android #v-tv:not(.cinema) .cinebar .btn{width:100%;white-space:nowrap;padding-inline:8px;font-size:14px}
body.android #v-tv:not(.cinema) .cinebar #avDelay,body.android #v-tv:not(.cinema) .cinebar .avd{align-self:center;text-align:center}
body.android .tvwrap>.panel:last-child>.row{display:flex;flex-wrap:wrap;gap:10px;align-items:center}
body.android .setcard .row,body.android #v-settings .row{flex-wrap:wrap}
body.android .epgdlg .row{flex-wrap:wrap}

@media (max-width:1100px){body.android #v-tv>.row{gap:8px;flex-wrap:nowrap}body.android #v-tv>.row .btn,body.android #v-tv>.row .tab{font-size:14px;padding:6px 11px;white-space:nowrap;min-height:42px}body.android #v-tv>.row>h1{display:none}}
@media (max-height:640px){body.android #v-tv>h1,body.android #v-tv .row>h1{display:none}body.android .app{grid-template-rows:48px 1fr!important}}
@media (min-width:600px){
  body.android main{min-height:0;overflow-y:auto}
  body.android #v-tv{height:100%;min-height:0;display:flex;flex-direction:column}
  body.android #v-tv:not([hidden]){display:flex}
  body.android .tvwrap{flex:1;min-height:0;grid-template-columns:minmax(250px,34%) minmax(0,1fr)!important;grid-template-rows:minmax(0,1fr);gap:14px}
  body.android .tvwrap>.panel{min-height:0}
  body.android .tvwrap>.panel:last-child{order:0!important;overflow-y:auto}
  body.android .tvwrap>.panel:first-child{display:flex;flex-direction:column;overflow:hidden;gap:8px;padding:12px}
  body.android .tvwrap>.panel:first-child{overflow-y:auto!important}
  body.android .tvwrap>.panel:first-child>*{flex:none}
  body.android .tvwrap>.panel:first-child>.tabs{order:0}
  body.android .tvwrap>.panel:first-child>#tvGroup{order:1}
  body.android .tvwrap>.panel:first-child>#tvSearch{order:2}
  body.android #tvList{order:3;overflow-y:auto;flex:1 1 auto!important;min-height:min(46vh,340px)}
  body.android #btnOrg{order:4}
  body.android #freeTools{order:5}
  body.android #freeTools[hidden]{display:none!important}
  body.android #tvCount{order:6}
  body.android.tv #tvEmpty{display:none!important}
  body.android.tv .tvwrap>.panel:first-child .tabs{flex-wrap:nowrap;overflow-x:auto;gap:6px}
  body.android.tv .tvwrap>.panel:first-child .tab{font-size:13px;padding:5px 10px;min-height:38px;white-space:nowrap}
  body.android.tv .tvwrap>.panel:first-child input,body.android.tv .tvwrap>.panel:first-child select{min-height:40px;padding-block:6px}
  body.android.tv #btnOrg{white-space:nowrap;font-size:14px;min-height:40px}
  body.android.tv #tvCount{display:none}
}
/* modo cinema (ecrã inteiro do leitor) */
body.android .app.cinema{grid-template-rows:1fr!important}
body.android .app.cinema .top{display:none!important}
body.android .app.cinema main{grid-row:1!important;padding:8px 14px!important}
body.android #v-tv.cinema>.row,body.android #v-tv.cinema>.banner{display:none!important}
body.android #v-tv.cinema .tvwrap{display:block!important;grid-template-columns:1fr!important}
body.android #v-tv.cinema .tvwrap>.panel:first-child{display:none!important}
body.android #v-tv.cinema .tvwrap>.panel:last-child{display:flex!important;flex-direction:column;align-items:center;gap:8px;overflow:visible;padding:0!important;border:0!important;background:none!important;height:100%}
body.android #v-tv.cinema .stage{width:min(100%,calc((100vh - 120px) * 16 / 9))!important;margin:0 auto}
body.android #v-tv.cinema .cinebar{width:100%;flex-wrap:nowrap;gap:10px}
body.android #v-tv.cinema .cinebar .btn{min-height:50px;font-size:16px;padding-inline:16px;white-space:nowrap}
body.android #v-tv.cinema .cinename{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:center}
body.android #v-tv.cinema .tvwrap>.panel:last-child>.row,body.android #v-tv.cinema #epgBox{display:none!important}
/* ecrã inteiro do vídeo (OK no vídeo) */
body.android.vfull #v-tv.cinema .cinebar,body.android.vfull #v-tv.cinema .tvwrap>.panel:last-child>.row{display:none!important}
body.android.vfull .app.cinema main{padding:0!important}
body.android.vfull #v-tv.cinema .tvwrap>.panel:last-child{justify-content:center}
body.android.vfull .app{padding:0!important}
body.android.vfull #v-tv.cinema .stage{position:fixed!important;inset:0;z-index:60;width:100vw!important;height:100vh!important;max-height:none;aspect-ratio:auto!important;border-radius:0!important;margin:0!important;background:#000}
body.android.vfull #stage .slot{width:100%!important;height:100%!important;aspect-ratio:auto!important;border-radius:0!important}
body.android.vfull #stage video{object-fit:contain}
body.android.vfull #stage:focus-visible{outline:none!important;box-shadow:none!important}
#fsName{position:fixed;left:24px;bottom:24px;z-index:80;background:rgba(0,0,0,.72);color:#fff;font:600 24px var(--f-display,sans-serif);padding:10px 20px;border-radius:12px;opacity:0;transition:opacity .25s;pointer-events:none;max-width:80vw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#fsName.on{opacity:1}
body.android .top .btn[aria-pressed="true"]{background:var(--accent);color:var(--accent-ink);border-color:var(--accent)}
"""
rep("</style>", CSS + "</style>", count=h.count("</style>")) if h.count("</style>") == 1 else None
if h.count("</style>") != 1:
    i = h.rfind("</style>"); h = h[:i] + CSS + h[i:]

JS = r"""
<script>
/* ===== Cockpit TV (Android): só IPTV ===== */
(function(){
  if(!window.ANDROID) return;
  document.body.classList.add("android");
  const top = document.querySelector(".top"), sp = top.querySelector(".spacer");
  const mk = (txt, v) => { const b = document.createElement("button"); b.className = "btn"; b.textContent = txt; b.onclick = () => show(v); b.dataset.v = v; top.insertBefore(b, sp); return b; };
  const bTv = mk("📺 TV", "tv"), bSet = mk("⚙ Definições", "settings");
  const sync = () => { bTv.setAttribute("aria-pressed", currentView === "tv" ? "true" : "false"); bSet.setAttribute("aria-pressed", currentView === "settings" ? "true" : "false"); };
  const _show = window.show;
  window.show = function(v){ const r = _show.apply(this, arguments); sync(); return r; };
  sync();

  /* Definições: só o que interessa à TV (cartões "TV e IPTV" e "Cópia de segurança") */
  const keep = ["TV e IPTV", "Cópia de segurança"];
  $("v-settings").querySelectorAll(".setgrp, .setcard").forEach(e => {
    if(e.classList.contains("setgrp")){ e.hidden = true; return; }
    const t = (e.querySelector("h2") || {}).textContent || "";
    if(!keep.includes(t.trim())) e.hidden = true;
  });
  const tvCard = [...$("v-settings").querySelectorAll(".setcard")].find(e => (e.querySelector("h2") || {}).textContent.trim() === "TV e IPTV");
  if(tvCard){ const info = document.createElement("p"); info.className = "small muted"; info.style.margin = "0"; info.textContent = "Esta aplicação liga-se diretamente ao servidor IPTV (não precisa de proxy)."; tvCard.insertBefore(info, tvCard.children[1] || null); }

  /* Ficheiro de exportação: o Android abre o seletor para escolheres a pasta e o nome */
  window.androidSaved = (ok, where) => { orgXferMsg(ok ? "Ficheiro guardado: " + where : "Não guardei o ficheiro (cancelaste ou não há seletor de ficheiros). Copia o código da caixa em baixo.", !ok); };
  const eb = $("orgExpFile");
  if(eb){ eb.textContent = "Guardar ficheiro…"; eb.onclick = () => {
    const txt = JSON.stringify(orgExport($("orgInclAcc").checked), null, 1); $("orgXfer").value = txt;
    let ok = false; try{ ok = Android.saveText("cockpit-iptv-definicoes.json", txt); }catch(e){}
    if(!ok) orgXferMsg("Não consegui abrir o seletor. Copia o código da caixa.", true);
  }; }

  /* Informar a parte nativa do Referer a usar nos canais abertos (RTP, SIC, …) */
  const _pc = window.playChannel;
  window.playChannel = function(c){ try{ Android.ctx(refFor(c) || ""); }catch(e){} return _pc.apply(this, arguments); };


  /* ===== Navegação com o comando da TV (D-pad) ===== */
  let dpad = false;
  try{ if(Android.isTv && Android.isTv()){ document.body.classList.add("tv"); dpad = true; } }catch(e){}
  /* Toque ou rato: deixa de ser navegação com o comando. Tocar num campo de texto abre logo o teclado (antes era escondido e ficava a piscar). */
  document.addEventListener("pointerdown", e => {
    dpad = false;
    const t = e.target && e.target.closest ? e.target.closest(TXT) : null;
    if(t){ if(editing && editing !== t) editing = null; t.readOnly = false; }
  }, true);
  const FOC = 'button:not([disabled]),a[href],input:not([type=hidden]):not([disabled]),select:not([disabled]),textarea:not([disabled]),summary,label.btn,[tabindex="0"]';
  const TXT = 'input:not([type]),input[type=text],input[type=search],input[type=url],input[type=password],input[type=email],input[type=number],input[type=tel],textarea';
  const isTxt = el => !!(el && el.matches && el.matches(TXT));
  const prep = () => { document.querySelectorAll(".gdp:not([tabindex])").forEach(e => { e.tabIndex = 0; }); document.querySelectorAll("label.btn").forEach(l => { if(!l.hasAttribute("tabindex")) l.tabIndex = 0; }); const st = $("stage"); if(st && !st.hasAttribute("tabindex")) st.tabIndex = 0; };
  prep();
  const vis = el => el.getClientRects().length > 0 && getComputedStyle(el).visibility !== "hidden" && !el.closest("[inert]");
  const openDlg = () => document.querySelector(".epgdlg:not([hidden]),.trkdlg:not([hidden])");
  const focusables = () => [...(openDlg() || document).querySelectorAll(FOC)].filter(vis);
  const cinema = () => document.querySelector(".app").classList.contains("cinema");
  const scrollParent = el => { for(let n = el; n && n !== document.body; n = n.parentElement){ const s = getComputedStyle(n); if(/(auto|scroll)/.test(s.overflowY) && n.scrollHeight > n.clientHeight + 4) return n; } return document.scrollingElement; };
  const kb = (on) => { try{ on ? Android.showKeyboard() : Android.hideKeyboard(); }catch(e){} };

  /* Campos de texto: o foco com as setas não abre o teclado; só o OK começa a escrever */
  let editing = null;
  const startEdit = el => {
    editing = el; el.readOnly = false;
    /* o campo já tinha o foco só de leitura: volta a focar para o Android ligar o teclado ao campo */
    el.blur(); editing = el;
    setTimeout(() => { editing = el; el.readOnly = false; el.focus(); try{ const n = el.value.length; el.setSelectionRange(n, n); }catch(x){} kb(true); setTimeout(() => kb(true), 250); }, 40);
  };
  const endEdit = () => { if(editing){ const el = editing; editing = null; el.readOnly = true; kb(false); } };
  document.addEventListener("focusin", e => { const el = e.target; if(dpad && isTxt(el) && el !== editing){ el.readOnly = true; kb(false); } }, true);
  let refocusing = 0;
  document.addEventListener("focusout", e => { if(e.target === editing && !refocusing){ setTimeout(() => { if(editing === e.target && document.activeElement !== e.target) endEdit(); }, 120); } }, true);

  /* Atalhos sem medir centenas de elementos: listas e filas do Início */
  function fastMove(cur, dx, dy){
    if(!cur || cur === document.body) return false;
    const go = el => { if(!el) return false; el.focus({preventScroll:true}); el.scrollIntoView({block:"nearest", inline:"nearest"}); return true; };
    const sib = (el, f) => { let n = el; do{ n = f > 0 ? n.nextElementSibling : n.previousElementSibling; }while(n && !(n.matches && n.matches(FOC) && vis(n))); return n; };
    if(dy && cur.classList && (cur.classList.contains("gch") || cur.classList.contains("gdp"))) return go(sib(cur, dy));
    const row = cur.closest && cur.closest("#tvList > .item");
    if(row && dy){
      const idx = [...row.querySelectorAll(FOC)].indexOf(cur); let n = row;
      do{ n = dy > 0 ? n.nextElementSibling : n.previousElementSibling; }while(n && !n.querySelector(FOC));
      if(n){ const f = [...n.querySelectorAll(FOC)]; return go(f[Math.min(Math.max(idx, 0), f.length - 1)]); }
      return false;
    }
    if(currentView === "tvhome" && dy){
      const kp = () => document.querySelector(".thKind[aria-pressed=true]") || document.querySelector(".thKind");
      const hero = () => document.querySelector("#thHero .thBtn.pri") || document.querySelector("#thHero .thBtn");
      const firstCard = () => { const c = document.querySelector(".thRow .thCard"); return c; };
      if(cur.classList.contains("thTab")){ if(dy > 0) return go(hero() || kp() || firstCard()); }
      else if(cur.closest("#thHero")){ if(dy > 0) return go(kp() || firstCard()); const t = document.querySelector(".thTab[aria-current=page]"); if(t) return go(t); }
      else if(cur.classList.contains("thKind")){
        if(dy < 0) return go(hero() || document.querySelector(".thTab[aria-current=page]"));
        const row = document.querySelector(".thRow"); if(row){ const cx = cur.getBoundingClientRect().left + cur.offsetWidth / 2; let best = null, bd = Infinity; for(const c of row.querySelectorAll(".thCard")){ const r = c.getBoundingClientRect(), d = Math.abs(r.left + r.width / 2 - cx); if(d < bd){ bd = d; best = c; } } return go(best); }
      }
      else if(dy < 0 && cur.classList.contains("thCard") && cur.closest(".thRow") && !cur.closest(".thRow").previousElementSibling.classList.contains("thRow")) return go(kp());
    }
    const sc = cur.closest && cur.closest(".thScroll");
    if(sc && dx && cur.classList.contains("thCard")) return go(sib(cur, dx));
    if(sc && dy){
      const tr = cur.closest(".thRow"); let n = tr;
      do{ n = dy > 0 ? n.nextElementSibling : n.previousElementSibling; }while(n && !n.querySelector(".thCard"));
      if(!n || !n.classList.contains("thRow")) return false;
      const cx = cur.getBoundingClientRect().left + cur.offsetWidth / 2; let best = null, bd = Infinity;
      for(const c of n.querySelectorAll(".thCard")){ const r = c.getBoundingClientRect(), d = Math.abs(r.left + r.width / 2 - cx); if(d < bd){ bd = d; best = c; } }
      return go(best);
    }
    return false;
  }
  function move(dx, dy){
    if(fastMove(document.activeElement, dx, dy)) return;
    const els = focusables(), cur = document.activeElement;
    if(!cur || cur === document.body || !els.includes(cur)){ if(els[0]) els[0].focus(); return; }
    const cr = cur.getBoundingClientRect(), ccx = cr.left + cr.width/2, ccy = cr.top + cr.height/2;
    let best = null, bs = Infinity;
    for(const el of els){
      if(el === cur) continue;
      const r = el.getBoundingClientRect(), cx = r.left + r.width/2, cy = r.top + r.height/2;
      let main, cross;
      if(dx){ if((cx - ccx) * dx <= 1) continue; main = Math.max(0, dx > 0 ? r.left - cr.right : cr.left - r.right); cross = Math.max(0, r.top - cr.bottom, cr.top - r.bottom); }
      else  { if((cy - ccy) * dy <= 1) continue; main = Math.max(0, dy > 0 ? r.top - cr.bottom : cr.top - r.bottom); cross = Math.max(0, r.left - cr.right, cr.left - r.right); }
      const off = dx ? Math.abs(cy - ccy) : Math.abs(cx - ccx);
      const sc = main + cross * 3 + off * 0.15;
      if(sc < bs){ bs = sc; best = el; }
    }
    if(best){ best.focus({preventScroll:true}); best.scrollIntoView({block:"nearest", inline:"nearest"}); }
    else if(dy){ const sp = scrollParent(cur); if(sp) sp.scrollBy(0, dy * 180); }
  }
  const clickId = id => { const b = $(id); if(b) b.click(); };
  const onStage = () => document.activeElement === $("stage");
  let lastItem = null;
  const fsEl = document.createElement("div"); fsEl.id = "fsName"; document.body.appendChild(fsEl);
  let fsT = 0;
  const flashName = () => { if(!document.body.classList.contains("vfull")) return; fsEl.textContent = $("chName").textContent; fsEl.classList.add("on"); clearTimeout(fsT); fsT = setTimeout(() => fsEl.classList.remove("on"), 2600); };
  const setVfull = on => { document.body.classList.toggle("vfull", !!on); if(on) flashName(); else fsEl.classList.remove("on"); };
  new MutationObserver(flashName).observe($("chName"), {childList:true, characterData:true, subtree:true});

  /* Ao escolher um canal (OK) passa para o ecrã do leitor; Voltar regressa à lista */
  $("tvList").addEventListener("click", e => {
    const b = e.target.closest("[data-play]"); if(!b || !dpad) return;
    lastItem = b;
    setTimeout(() => {
      if($("stage").classList.contains("single") && currentView === "tv" && !(window.DET && DET.open)){ setVfull(false); if(!cinema()) setCinema(true); $("stage").focus({preventScroll:true}); }
    }, 60);
  });

  /* Nome da tecla: alguns comandos/TVs enviam key vazio ou "Unidentified" para o OK e para as teclas de multimédia */
  const KC = {13:"Enter", 23:"Enter", 66:"Enter", 160:"Enter", 19:"ArrowUp", 20:"ArrowDown", 21:"ArrowLeft", 22:"ArrowRight", 33:"PageUp", 34:"PageDown", 166:"ChannelUp", 167:"ChannelDown", 85:"MediaPlayPause", 179:"MediaPlayPause", 126:"MediaPlay", 127:"MediaPause", 86:"MediaStop", 90:"MediaFastForward", 89:"MediaRewind", 87:"MediaTrackNext", 88:"MediaTrackPrevious", 175:"Guide", 172:"Guide", 165:"Info", 82:"ContextMenu", 4:"GoBack", 111:"Escape"};
  const keyName = e => { const k = e.key; if(k && k !== "Unidentified" && k !== "Dead") return k === "Return" ? "Enter" : k; if(e.code === "NumpadEnter" || e.code === "Enter") return "Enter"; return KC[e.keyCode || e.which] || k || ""; };
  document.addEventListener("keydown", e => {
    const a = document.activeElement, k = keyName(e);
    if(e.altKey || e.ctrlKey || e.metaKey) return;
    if(!exitDlg.hidden){   /* janela "Sair?": só Esq./Dir. e OK */
      if(k === "ArrowLeft" || k === "ArrowRight"){ e.preventDefault(); e.stopImmediatePropagation(); ($("exNo") === a ? $("exYes") : $("exNo")).focus(); }
      else if(k === "Enter"){ if(a && a.id !== "exNo" && a.id !== "exYes"){ e.preventDefault(); e.stopImmediatePropagation(); $("exNo").focus(); } }
      else if(k === "GoBack" || k === "Escape" || k === "MediaStop"){ e.preventDefault(); e.stopImmediatePropagation(); exClose(); }
      else { e.preventDefault(); e.stopImmediatePropagation(); }
      return;
    }
    const arrow = {ArrowUp:[0,-1], ArrowDown:[0,1], ArrowLeft:[-1,0], ArrowRight:[1,0]}[k];
    if(arrow || k === "PageUp" || k === "PageDown") dpad = true;
    /* a app original muda de canal com Cima/Baixo: aqui isso fica só para o ecrã do leitor */
    const eat = () => { e.preventDefault(); e.stopImmediatePropagation(); };

    /* escrever num campo */
    if(editing && a === editing){
      if(k === "Enter"){ const el = editing; setTimeout(() => { if(editing === el) endEdit(); }, 30); return; }   /* deixa a pesquisa do campo correr e fecha o teclado */
      if(k === "ArrowUp" || k === "ArrowDown"){ eat(); endEdit(); move(0, arrow[1]); return; }
      return; /* resto das teclas escreve normalmente */
    }
    if(k === "Enter" && isTxt(a) && (a.readOnly || dpad)){ eat(); startEdit(a); return; }

    if(window.NATIVE && NATIVE.active){
      if(k === "MediaPlayPause" || k === "MediaPlay" || k === "MediaPause"){ eat(); try{ Android.ntoggle(); }catch(x){} return; }
      if((k === "MediaFastForward" || k === "MediaRewind") && !NATIVE.live){ eat(); try{ Android.nseek(k === "MediaFastForward" ? 30000 : -30000); }catch(x){} return; }
    }
    if(k === "Guide" || k === "Info"){ const g = $("chGuide"); if(g && g.offsetParent){ eat(); g.click(); } return; }
    if(k === "ContextMenu" || k === "Settings"){ eat(); if(currentView === "tv" && cinema() && typeof trkOpen === "function") trkOpen(); else show("settings"); return; }
    if(k === "MediaStop" || k === "GoBack" || k === "Escape"){ eat(); window.androidBack(); return; }
    if(k === "MediaTrackNext"){ eat(); clickId("chNext"); return; }
    if(k === "MediaTrackPrevious"){ eat(); clickId("chPrev"); return; }
    if(k === "MediaFastForward" || k === "MediaRewind"){ const v = $("vid" + (typeof tvTarget === "number" ? tvTarget : 0)); if(v && isFinite(v.duration) && v.duration > 0){ eat(); v.currentTime = Math.max(0, Math.min(v.duration, v.currentTime + (k === "MediaFastForward" ? 30 : -30))); } return; }
    if(k === "ChannelUp"){ eat(); clickId("chNext"); return; }
    if(k === "ChannelDown"){ eat(); clickId("chPrev"); return; }
    if(k === "PageDown" || k === "PageUp"){ eat(); clickId(k === "PageDown" ? "chNext" : "chPrev"); return; }
    if(k === "MediaPlayPause" || k === "MediaPlay" || k === "MediaPause"){
      const v = $("vid" + (typeof tvTarget === "number" ? tvTarget : 0)); if(v){ eat(); (k === "MediaPause" || (k === "MediaPlayPause" && !v.paused)) ? v.pause() : v.play().catch(()=>{}); } return; }

    if(arrow){
      if(arrow[0] && a && a.type === "range") return;
      eat();
      if(onStage() && cinema() && !openDlg()){
        /* ecrã inteiro: todas as setas mudam de canal; com a barra visível: Baixo vai para os botões, Esq./Dir. mudam de canal */
        if(document.body.classList.contains("vfull")){ clickId(arrow[1] < 0 || arrow[0] > 0 ? "chNext" : "chPrev"); return; }
        if(arrow[1] > 0){ const f = [...document.querySelectorAll("#v-tv .cinebar .btn")].find(b => !b.disabled && vis(b)); if(f) f.focus({preventScroll:true}); return; }
        if(arrow[0]) clickId(arrow[0] < 0 ? "chPrev" : "chNext");
        return;
      }
      move(arrow[0], arrow[1]); return;
    }
    if(k === "Enter" && a){
      if(a === $("stage") && cinema()){ eat(); setVfull(!document.body.classList.contains("vfull")); return; }   /* OK no vídeo: ecrã inteiro / sair do ecrã inteiro */
      if(a.type === "checkbox" || a.type === "radio" || a.tagName === "LABEL" || (a.classList && a.classList.contains("gdp"))){ e.preventDefault(); a.click(); }
    }
  }, true);

  /* Foco inicial e foco ao abrir/fechar janelas */
  setTimeout(() => { if(!document.activeElement || document.activeElement === document.body) bTv.focus(); }, 600);
  let prevFocus = null;
  new MutationObserver(() => {
    prep();
    const d = openDlg();
    if(d && !d.contains(document.activeElement)){ if(!prevFocus) prevFocus = document.activeElement; const f = [...d.querySelectorAll(FOC)].filter(vis)[0]; if(f) f.focus(); }
    else if(!d && prevFocus){ const p = prevFocus; prevFocus = null; if(p !== document.body && document.contains(p) && vis(p)) p.focus(); }
  }).observe(document.body, {subtree:true, attributes:true, attributeFilter:["hidden"]});

  /* Botão Voltar */
  /* Confirmação ao sair da app */
  const exitDlg = document.createElement("div"); exitDlg.id = "exitDlg"; exitDlg.hidden = true;
  exitDlg.innerHTML = '<div class="exBox" role="dialog" aria-modal="true"><h2>Sair do Cockpit TV?</h2><p>Queres mesmo fechar a app?</p><div class="exBt"><button class="btn" id="exNo">Ficar</button><button class="btn" id="exYes">Sair</button></div></div>';
  document.body.appendChild(exitDlg);
  const exClose = () => { exitDlg.hidden = true; document.body.classList.remove("exitOpen"); if(exPrev && document.contains(exPrev)) try{ exPrev.focus({preventScroll:true}); }catch(x){} exPrev = null; };
  let exPrev = null;
  const exOpen = () => { exPrev = document.activeElement; exitDlg.hidden = false; document.body.classList.add("exitOpen"); setTimeout(() => $("exNo").focus(), 30); };
  $("exNo").onclick = exClose;
  $("exYes").onclick = () => { try{ Android.exitApp(); }catch(x){} };
  window.androidBack = function(){
    if(!exitDlg.hidden){ exClose(); return true; }
    if(editing){ endEdit(); return true; }
    const d = document.querySelector(".epgdlg:not([hidden]),.trkdlg:not([hidden])");
    if(d){ const b = [...d.querySelectorAll("button")].find(x => /^(fechar|✕|×|close)/i.test(x.textContent.trim())); if(b) b.click(); else d.hidden = true; return true; }
    if(document.querySelector(".app").classList.contains("cinema")){
      if(document.body.classList.contains("vfull")){ setVfull(false); $("stage").focus({preventScroll:true}); return true; }
      if(!onStage() && $("stage").offsetParent){ $("stage").focus({preventScroll:true}); return true; }   /* dos botões volta ao vídeo */
      setCinema(false); setVfull(false); if(window.__stopPlayback) window.__stopPlayback();
      if(window.__homeOrigin){ window.__homeOrigin = false; show("tvhome"); return true; }
      setTimeout(() => { const it = lastItem && document.contains(lastItem) && vis(lastItem) ? lastItem : null; (it || bTv).focus(); if(it) it.scrollIntoView({block:"nearest"}); }, 60);
      return true;
    }
    if(currentView === "settings"){ show("tvhome"); return true; }
    if(currentView === "tv"){ show("tvhome"); return true; }
    exOpen(); return true;
  };
})();
</script>
"""

JS2 = r'''
<script>
/* ===== Cockpit TV: ecrã Início (estilo Android TV) ===== */
(function(){
  if(!window.ANDROID) return;
  const $ = id => document.getElementById(id);
  const esc = t => String(t == null ? "" : t).replace(/[&<>"]/g, m => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[m]));
  /* ===== Retomar filmes e episódios onde ficaste ===== */
  const RES = window.RES = {
    all(){ try{ return LS.get("resume", {}) || {}; }catch(e){ return {}; } },
    at(url){ const e = RES.all()[url]; return e && e.p > 30 && e.d > 0 && e.p < e.d * 0.95 ? Math.max(0, e.p - 5) : 0; },
    save(c, p, d){
      if(!c || !c.url || !(c.kind === "movie" || c.kind === "episode") || !(d > 300) || !(p >= 0)) return;
      const a = RES.all();
      if(p > d * 0.95) delete a[c.url];
      else if(p > 20) a[c.url] = {name:c.name, logo:c.logo || "", url:c.url, kind:c.kind, group:c.group || "", id:c.id || "", p:Math.round(p), d:Math.round(d), t:Date.now()};
      else return;
      const keys = Object.keys(a).sort((x, y) => a[y].t - a[x].t);
      keys.slice(40).forEach(k => delete a[k]);
      try{ LS.set("resume", a); }catch(e){}
    },
    list(kind){ return Object.values(RES.all()).filter(e => e.p > 30 && e.p < e.d * 0.95 && (kind === "movie" ? e.kind === "movie" : e.kind === "episode")).sort((x, y) => y.t - x.t); }
  };
  /* leitor da página (fora do nativo): retoma e guarda a posição */
  const _pcR = window.playChannel;
  window.playChannel = function(c){
    const r = _pcR.apply(this, arguments);
    try{
      if(c && (c.kind === "movie" || c.kind === "episode") && !(window.NATIVE && NATIVE.active)){
        const v = $("vid0"), at = RES.at(c.url);
        if(at > 0){ const go = () => { try{ if(isFinite(v.duration) && at < v.duration - 30) v.currentTime = at; }catch(e){} }; v.addEventListener("loadedmetadata", go, {once:true}); }
        if(v._resT) clearInterval(v._resT);
        v._resT = setInterval(() => { if(!lastPlayed[0] || lastPlayed[0].url !== c.url){ clearInterval(v._resT); return; } if(!v.paused && isFinite(v.duration)) RES.save(c, v.currentTime, v.duration); }, 5000);
      }
    }catch(e){}
    return r;
  };
  setInterval(() => { try{ if(NATIVE.active && !NATIVE.live && NATIVE.cur){ const [p, d, lv] = String(Android.npos()).split("|").map(Number); if(!lv) RES.save(NATIVE.cur.c, p / 1000, d / 1000); } }catch(e){} }, 5000);

  /* ===== Google Cast: envia o endereço do vídeo para a Google TV / Chromecast (só no telemóvel) ===== */
  const CAST = window.CAST = {active:false, name:"", cur:null, banner:null,
    mime(c){
      const u = c.url, fx = (typeof fileExt === "function" ? fileExt(u) : "");
      if(/\.m3u8(\?|$)/i.test(u) || (c.kind === "live" && !/\.ts(\?|$)/i.test(u) && !fx)) return "application/x-mpegURL";
      if(fx === "mpd") return "application/dash+xml";
      if(fx === "mkv") return "video/x-matroska";
      if(fx === "webm") return "video/webm";
      if(/^(ts|m2ts|mts)$/.test(fx) || /\.ts(\?|$)/i.test(u)) return "video/mp2t";
      return "video/mp4";
    },
    send(c){
      CAST.cur = c;
      let ref = ""; try{ ref = (typeof refFor === "function" && refFor(c)) || ""; }catch(e){}
      if(ref){ try{ toast("Este canal precisa de cabeçalhos especiais; a TV pode não o conseguir abrir.", true); }catch(e){} }
      try{ Android.cload(c.url, c.name || "", CAST.mime(c), c.kind === "live", Math.round(RES.at(c.url) * 1000)); }catch(e){}
      CAST.ui();
    },
    ui(){
      if(!CAST.banner){
        const d = document.createElement("div"); d.id = "castBanner"; d.hidden = true;
        d.innerHTML = '<span id="castTx"></span><button class="btn" id="castPp">⏯</button><button class="btn" id="castSt">⏹ Parar</button><button class="btn" id="castOff">Desligar</button>';
        document.body.appendChild(d); CAST.banner = d;
        $("castPp").onclick = () => { try{ Android.ctoggle(); }catch(e){} };
        $("castSt").onclick = () => { try{ Android.cmstop(); }catch(e){} };
        $("castOff").onclick = () => { try{ Android.cstop(); }catch(e){} };
      }
      CAST.banner.hidden = !CAST.active;
      $("castTx").textContent = "📡 " + (CAST.cur ? CAST.cur.name + " · " : "") + (CAST.name || "Google TV");
    },
    ev(kind, msg){
      if(kind === "connected"){
        CAST.active = true; CAST.name = msg || "Google TV";
        try{ toast("Ligado a " + CAST.name + ". Escolhe um canal, filme ou série."); }catch(e){}
        const cur = NATIVE.active && NATIVE.cur ? NATIVE.cur.c : null;
        if(cur){ NATIVE.stop(); CAST.send(cur); } else CAST.ui();
      }
      else if(kind === "ended"){ CAST.active = false; CAST.cur = null; CAST.ui(); try{ toast("Transmissão terminada."); }catch(e){} }
      else if(kind === "failed"){ try{ toast("Não consegui ligar à TV (código " + msg + ").", true); }catch(e){} }
      else if(kind === "unavailable"){ try{ toast("Google Cast indisponível neste telemóvel (precisa dos Serviços Google Play).", true); }catch(e){} }
      else if(kind === "error"){ try{ toast("Cast: " + msg, true); }catch(e){} }
    }
  };

  /* ===== Leitor nativo (Media3/ExoPlayer) por cima da área do vídeo ===== */
  const HAS_N = typeof Android.nplay === "function";
  const NAT = window.NATIVE = {active:false, live:false, ready:false, off:new Set(), cur:null, id:0, key:"", timer:0, poll:0,
    go(c, slot, playId, fail){
      if(CAST.active && slot === 0 && c && c.url && c.url.indexOf("series:") !== 0){ NAT.stop(); CAST.send(c); return true; }
      if(!HAS_N || slot !== 0 || !c || !c.url || NAT.off.has(c.url) || !$("stage").classList.contains("single")){ NAT.stop(); return false; }
      const u = c.url, fx = (typeof fileExt === "function" ? fileExt(u) : "");
      const hint = /\.m3u8(\?|$)/i.test(u) ? "hls" : fx === "mpd" ? "dash" : (c.kind === "live" && !/\.ts(\?|$)/i.test(u) && !(typeof FILE_EXT === "function" && FILE_EXT(u))) ? "hls" : "";
      NAT.cur = {c, slot, playId, fail, url:u, triedTs:false}; NAT.live = c.kind === "live"; NAT.id = playId;
      NAT.start(u, hint, c.name);
      return true;
    },
    start(u, hint, title){
      let ref = ""; try{ ref = (typeof refFor === "function" && refFor(NAT.cur.c)) || ""; }catch(e){}
      NAT.active = true; NAT.key = ""; NAT.ready = false; if(!NAT.cur.triedTs || NAT.cur.url === u){ NAT.subBase = ""; NAT.subOff = 0; }
      try{ Android.nplay(u, ref, hint, title || "", Math.round(RES.at(NAT.cur.c.url) * 1000)); }catch(e){ NAT.fallback("sem leitor nativo"); return; }
      clearTimeout(NAT.timer); NAT.timer = setTimeout(() => { if(NAT.active && NAT.cur && !NAT.ready) NAT.fallback("tempo esgotado"); }, 22000);
      NAT.sync(true);
      if(!NAT.poll) NAT.poll = setInterval(() => NAT.sync(false), 160);
    },
    stop(){ clearTimeout(NAT.timer); if(NAT.active){ NAT.saveNow(); NAT.active = false; NAT.cur = null; try{ Android.nstop(); }catch(e){} } },
    fallback(why){
      const cur = NAT.cur; if(!cur) return;
      if(cur.playId !== playSeq[cur.slot]) return;
      NAT.off.add(cur.url); NAT.stop();
      try{ toast("Leitor nativo: " + why + ". A usar o leitor da página…"); }catch(e){}
      window.playChannel(cur.c, cur.slot, true);
    },
    sync(force){
      if(!NAT.active) return;
      const st = $("stage"); if(!st) return;
      const r = st.getBoundingClientRect(), d = window.devicePixelRatio || 1;
      const blocked = !!document.querySelector(".epgdlg:not([hidden]),.trkdlg:not([hidden]),#exitDlg:not([hidden])");
      const vis = currentView === "tv" && r.width > 20 && r.height > 20 && !blocked && !document.hidden;
      const x = Math.round(r.left * d), y = Math.round(r.top * d), w = Math.round(r.width * d), h = Math.round(r.height * d);
      const key = x + "," + y + "," + w + "," + h + "," + vis;
      if(force || key !== NAT.key){ NAT.key = key; try{ Android.nrect(x, y, w, h, vis); }catch(e){} }
    },
    saveNow(){ try{ if(!NAT.cur || NAT.live) return; const [p, d, lv] = String(Android.npos()).split("|").map(Number); if(!lv) RES.save(NAT.cur.c, p / 1000, d / 1000); }catch(e){} },
    subBase:"", subOff:0, subLabel:"", subTimer:0,
    subText(text, label){ NAT.subBase = text; NAT.subOff = 0; NAT.subLabel = label || "Português"; try{ $("trkOff").textContent = "0 s"; }catch(e){} try{ Android.nsub(text, NAT.subLabel, "pt"); }catch(e){} },
    shift(d){
      if(!NAT.subBase) return toast("Carrega primeiro um ficheiro de legendas.", true);
      NAT.subOff = Math.round((NAT.subOff + d) * 10) / 10;
      try{ $("trkOff").textContent = (NAT.subOff > 0 ? "+" : "") + NAT.subOff.toLocaleString("pt-PT") + " s"; }catch(e){}
      clearTimeout(NAT.subTimer);
      NAT.subTimer = setTimeout(() => {   /* espera um pouco para juntar vários toques */
        const off = NAT.subOff * 1000;
        const t = NAT.subBase.replace(/(\d{2}):(\d{2}):(\d{2})([,.])(\d{3})/g, (m, h, mi, s, sep, ms) => {
          let v = Math.max(0, ((+h * 60 + +mi) * 60 + +s) * 1000 + +ms + off);
          const H = Math.floor(v / 3600000), M = Math.floor(v / 60000) % 60, S = Math.floor(v / 1000) % 60, MS = Math.floor(v) % 1000;
          const z = (n, l = 2) => String(n).padStart(l, "0");
          return z(H) + ":" + z(M) + ":" + z(S) + sep + z(MS, 3);
        });
        try{ Android.nsub(t, NAT.subLabel, "pt"); }catch(e){}
      }, 700);
    },
    tracks(type){ try{ const j = JSON.parse(Android.ntracks()); return j[type] || []; }catch(e){ return []; } },
    pick(type, i){ try{ Android.ntrack(type, i); }catch(e){} }
  };
  window.__nev = (kind, msg) => {
    if(String(kind).indexOf("cast:") === 0) return CAST.ev(kind.slice(5), msg);
    const cur = NAT.cur; if(!NAT.active || !cur) return;
    if(kind === "ready"){ NAT.ready = true; clearTimeout(NAT.timer); }
    else if(kind === "error"){
      if(cur.playId !== playSeq[cur.slot]) return;
      if(cur.c.kind === "live" && /\.m3u8(\?|$)/i.test(cur.url) && /\/live\//.test(cur.url) && !cur.triedTs){
        cur.triedTs = true; NAT.ready = false;
        NAT.start(cur.url.replace(/\.m3u8(\?|$)/i, ".ts$1"), "", cur.c.name); return;
      }
      NAT.fallback(msg || "erro");
    }
    else if(kind === "noaudio"){ try{ toast("Este vídeo tem áudio que a TV não descodifica. Escolhe outra faixa em Áudio.", true); }catch(e){} }
  };


  /* guia: linhas de programas navegáveis pelo comando */
  const _gp = window.gdRenderProg; if(typeof _gp === "function") window.gdRenderProg = function(){ const r = _gp.apply(this, arguments); document.querySelectorAll(".gdp").forEach(e => { e.tabIndex = 0; }); return r; };

  /* parar a reprodução ao sair do canal/filme */
  const stopPlayback = () => { try{ if(window.CAST && CAST.active) Android.cmstop(); }catch(e){} try{ stopSlot(0); lastPlayed[0] = null; epgSlot[0] = null; updateCinemaBar(); }catch(e){} };
  window.__stopPlayback = stopPlayback;

  /* ===== Botão Legendas na barra do leitor ===== */
  (function(){
    const tr = $("chTracks"); if(!tr || $("chSubs")) return;
    const b = document.createElement("button"); b.className = "btn"; b.id = "chSubs"; b.textContent = "💬 Legendas";
    b.onclick = () => { trkOpen(); setTimeout(() => { const f = $("trkSubs").querySelector("button") || $("osGo"); if(f) f.focus({preventScroll:true}); }, 120); };
    tr.after(b);
    const upd = () => { const c = lastPlayed && lastPlayed[0]; b.hidden = !!(c && c.kind === "live"); };
    const _u = window.updateCinemaBar; window.updateCinemaBar = function(){ const r = _u.apply(this, arguments); try{ upd(); }catch(e){} return r; };
    upd();
  })();

  /* ===== Definições: modelos de layout, cor e margens ===== */
  const TPL = [
    ["equilibrado", "Equilibrado", "O padrão: destaque + filas de canais."],
    ["cinema", "Cinema", "Cartões grandes e destaque maior; menos itens por ecrã."],
    ["compacto", "Compacto", "Sem destaque, cartões pequenos: vês muitas categorias de uma vez."],
    ["grelha", "Grelha", "Os canais ficam em grelha, sem deslizar para os lados."],
    ["grande", "Texto grande", "Letra e botões maiores, para ler de longe."]
  ];
  const OVS = [["0", "Sem margem"], ["1", "Margem média"], ["2", "Margem grande"]];
  const TL = window.TVLAYOUT = Object.assign({t:"equilibrado", ov:"0"}, (function(){ try{ return LS.get("tvLayout", {}) || {}; }catch(e){ return {}; } })());
  const applyLayout2 = () => {
    TPL.forEach(([id]) => document.body.classList.toggle("tl-" + id, TL.t === id));
    document.body.classList.remove("ov-0", "ov-1", "ov-2"); document.body.classList.add("ov-" + TL.ov);
    try{ LS.set("tvLayout", {t:TL.t, ov:TL.ov}); }catch(e){}
    document.querySelectorAll("[data-tpl]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.tpl === TL.t)));
    document.querySelectorAll("[data-ov]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.ov === TL.ov)));
    try{ if(currentView === "tvhome") renderHome(); }catch(e){}
  };
  (function(){
    const st = $("v-settings"); if(!st) return;
    const card = document.createElement("section"); card.className = "setcard panel"; card.id = "tvLayoutCard";
    let h = '<h2>Aparência e layout</h2><p class="small muted" style="margin:0 0 8px">Escolhe um modelo para o ecrã Início. A mudança é imediata.</p><div class="tplGrid">';
    TPL.forEach(([id, nm, ds]) => { h += '<button class="btn tplBtn" data-tpl="' + id + '"><b>' + nm + '</b><small>' + ds + '</small></button>'; });
    h += '</div><h3 style="margin:14px 0 6px">Cor de destaque</h3><div class="tplGrid" id="tvSchemes"></div>';
    h += '<h3 style="margin:14px 0 6px">Margens do ecrã (para TVs que cortam as bordas)</h3><div class="tplGrid">';
    OVS.forEach(([v, nm]) => { h += '<button class="btn tplBtn" data-ov="' + v + '"><b>' + nm + '</b></button>'; });
    h += '</div>';
    card.innerHTML = h;
    const first = [...st.children].find(e => !e.hidden && e.classList && e.classList.contains("setcard"));
    st.insertBefore(card, first || null);
    try{
      const box = $("tvSchemes");
      (typeof SCHEMES !== "undefined" ? SCHEMES : []).forEach(([id, nm, c]) => {
        const b = document.createElement("button"); b.className = "btn tplBtn"; b.dataset.sch = id; b.innerHTML = '<b>' + nm + '</b>';
        b.style.cssText = "border-left:10px solid " + (c && c[1] || "var(--accent)");
        b.onclick = () => { cfg.scheme = id; cfg.light = (id === "claro" || id === "areia"); saveCfg(); applyTheme(); card.querySelectorAll("[data-sch]").forEach(x => x.setAttribute("aria-pressed", String(x.dataset.sch === cfg.scheme))); };
        b.setAttribute("aria-pressed", String(cfg.scheme === id)); box.appendChild(b);
      });
    }catch(e){}
    card.querySelectorAll("[data-tpl]").forEach(b => b.onclick = () => { TL.t = b.dataset.tpl; applyLayout2(); });
    card.querySelectorAll("[data-ov]").forEach(b => b.onclick = () => { TL.ov = b.dataset.ov; applyLayout2(); });
  })();
  applyLayout2();
  const sec = document.createElement("section"); sec.className = "view"; sec.id = "v-tvhome"; sec.hidden = true;
  sec.innerHTML = '<div class="thHero" id="thHero"></div><div id="thRows"></div>';
  $("main").appendChild(sec);

  /* barra de navegação */
  const top = document.querySelector(".top"), sp = top.querySelector(".spacer");
  const nav = document.createElement("nav"); nav.className = "thNav"; nav.setAttribute("aria-label", "Menu");
  [["tvhome","🏠","Início"],["tv","🔎","Explorar"],["guide","📅","Guia"],["settings","⚙","Definições"]].forEach(([v, ic, t]) => {
    const b = document.createElement("button"); b.className = "thTab"; b.dataset.th = v; b.innerHTML = "<span>" + ic + "</span>" + t;
    b.onclick = () => { window.__homeOrigin = false; if(v === "guide") openGuide(); else show(v); };
    nav.appendChild(b);
  });
  top.insertBefore(nav, sp);
  /* Telemóvel: transmitir o ecrã para uma TV (Miracast / Wi-Fi Direct / Cast) */
  let isTvDev = false; try{ isTvDev = !!(Android.isTv && Android.isTv()); }catch(e){}
  if(!isTvDev && typeof Android.cpick === "function"){
    const cb = document.createElement("button"); cb.className = "thTab"; cb.id = "thCast"; cb.innerHTML = "<span>📡</span>Google TV";
    cb.onclick = () => { try{ Android.cpick(); }catch(e){ try{ toast("Google Cast indisponível neste telemóvel.", true); }catch(x){} } };
    nav.appendChild(cb);
    if(typeof Android.castScreen === "function"){
      const mb = document.createElement("button"); mb.className = "thTab"; mb.id = "thMirror"; mb.innerHTML = "<span>🖥</span>Espelhar";
      mb.onclick = () => { try{ toast("Escolhe a TV na lista. O ecrã do telemóvel passa a aparecer nela."); }catch(e){} try{ Android.castScreen(); }catch(e){} };
      nav.appendChild(mb);
    }
  }
  const syncNav = () => nav.querySelectorAll(".thTab").forEach(b => b.setAttribute("aria-current", b.dataset.th === currentView ? "page" : "false"));

  /* recentes */
  const REC = "tvRecent";
  const recents = () => LS.get(REC, []) || [];
  const pushRecent = c => { try{ const a = recents().filter(x => x.url !== c.url); a.unshift({name:c.name, logo:c.logo || "", url:c.url, kind:c.kind, group:c.group, id:c.id, free:c.free, intl:c.intl, sid:c.sid}); LS.set(REC, a.slice(0, 24)); }catch(e){} };
  const _pc = window.playChannel;
  window.playChannel = function(c){ try{ if(c && c.url) pushRecent(c); }catch(e){} return _pc.apply(this, arguments); };

  const HOME = {flat:[], lastK:null, kind:(LS.get("thKind", "live") || "live")};
  const KINDS = [["live","📺","Live"],["movie","🎬","Filmes"],["series","🍿","Séries"]];
  const ptGroups = kind => { const m = groupsOf(kind), names = orgGroupList(kind, [...m.keys()], false).filter(isPtGroup); return names.map(n => [n, m.get(n)]); };
  const allCh = () => [...(typeof channels !== "undefined" ? channels : []), ...freeChans, ...intlChans];
  const uniq = l => { const s = new Set(); return l.filter(c => c && c.url && !s.has(c.url) && s.add(c.url)); };
  const groupsOf = kind => { const m = new Map(); channels.filter(c => c.kind === kind).forEach(c => { const g = c.group || "Outros"; if(!m.has(g)) m.set(g, []); m.get(g).push(c); }); return m; };

  function card(c, k, small){
    let sub = c.group || "";
    try{ const nn = nowNext(c); if(nn) sub = hm(nn.now.start) + " " + nn.now.title; }catch(e){}
    if(c._sub) sub = c._sub;
    return '<button class="thCard' + (small ? " sm" : "") + '" data-k="' + k + '"><span class="thArt">' + (c._pct ? '<span class="thBar"><i style="width:' + c._pct + '%"></i></span>' : "") + (c.logo ? '<img src="' + esc(c.logo) + '" alt="" loading="lazy" onerror="this.remove()">' : "") + '<b class="thInit">' + esc((c.name || "?").replace(/[^\p{L}\p{N}]/gu, "").slice(0, 2).toUpperCase()) + '</b></span><span class="thMeta"><b>' + esc(c.name) + '</b><small>' + esc(sub) + '</small></span></button>';
  }
  function row(title, list, more){
    list = uniq(list); if(!list.length) return "";
    const k0 = HOME.flat.length; list.forEach(c => HOME.flat.push(c));
    return '<div class="thRow"><h2>' + title + '</h2><div class="thScroll">' + list.map((c, i) => card(c, k0 + i)).join("") + (more ? '<button class="thCard thMore" data-more="' + more + '"><span>Ver tudo →</span></button>' : "") + '</div></div>';
  }

  function renderHome(){
    if(currentView !== "tvhome") return;
    const keep = document.activeElement && document.activeElement.dataset ? document.activeElement.dataset.k : null;
    HOME.flat = [];
    const cur = (lastPlayed && (lastPlayed[0] || lastPlayed[1])) || recents()[0] || null;
    const hasList = channels.length > 0;
    let hero = "";
    if(cur){
      let sub = cur.group || ""; try{ const nn = nowNext(cur); if(nn) sub = hm(nn.now.start) + " " + nn.now.title; }catch(e){}
      HOME.flat.push(cur); const k = HOME.flat.length - 1;
      hero = '<div class="thHeroArt">' + (cur.logo ? '<img src="' + esc(cur.logo) + '" alt="" onerror="this.remove()">' : '<b>' + esc((cur.name || "?").slice(0, 2).toUpperCase()) + '</b>') + '</div><div class="thHeroTx"><small>Continuar a ver</small><h1>' + esc(cur.name) + '</h1><p>' + esc(sub) + '</p><div class="thHeroBt"><button class="thBtn pri" data-k="' + k + '">▶ Ver agora</button><button class="thBtn" data-go="tv">🔎 Explorar canais</button></div></div>';
    } else {
      hero = '<div class="thHeroTx"><small>Cockpit TV</small><h1>Bem-vindo</h1><p>' + (hasList ? "Escolhe um canal em baixo para começar." : "Os canais abertos portugueses já estão disponíveis. Para ver mais, adiciona a tua lista IPTV nas Definições.") + '</p><div class="thHeroBt"><button class="thBtn pri" data-go="tv">🔎 Explorar canais</button><button class="thBtn" data-go="settings">⚙ Definições</button></div></div>';
    }
    $("thHero").innerHTML = hero;
    let rows = '<div class="thKinds">' + KINDS.map(([k, ic, t]) => '<button class="thBtn thKind" data-kind2="' + k + '" aria-pressed="' + (HOME.kind === k) + '">' + ic + " " + t + '</button>').join("") + '</div>';
    if(HOME.kind !== "live"){
      const rl = RES.list(HOME.kind).slice(0, 20).map(e => Object.assign({}, e, {_pct:Math.round(e.p / e.d * 100), _sub:(e.group ? e.group + " · " : "") + Math.max(1, Math.round((e.d - e.p) / 60)) + " min restantes"}));
      rows += row("▶ Continuar a ver", rl, "");
    }
    const pg = ptGroups(HOME.kind);
    for(const [g, l] of pg.slice(0, 14)) rows += row(esc(g), l.slice(0, 40), "");
    if(!pg.length && HOME.kind === "live" && !channels.some(c => c.kind === "live")) rows += row("📡 Canais abertos PT", freeChans.filter(c => typeof hState !== "function" || hState(c) !== "dead").slice(0, 40), "free");
    if(!pg.length && !rows.includes("thRow")) rows += '<p class="thEmpty">Sem categorias PT em ' + (KINDS.find(x => x[0] === HOME.kind) || [])[2] + '. Usa Explorar para ver todas.</p>';
    if(!rows.includes("thRow") && !rows.includes("thEmpty")) rows += '<p class="thEmpty">' + (typeof freeLoading !== "undefined" && freeLoading ? "A carregar canais…" : "Sem canais para mostrar. Verifica a ligação à internet.") + '</p>';
    $("thRows").innerHTML = rows;
    if(keep != null){ const el = sec.querySelector('[data-k="' + keep + '"]'); if(el) el.focus({preventScroll:true}); }
  }

  function watch(c){
    if(!c) return;
    window.__homeOrigin = true;
    if(c.kind === "series" && c.sid){ openSeries(c); return; }
    playChannel(c);
    setTimeout(() => { if(currentView === "tv"){ if(!document.querySelector(".app").classList.contains("cinema")) setCinema(true); const st = $("stage"); if(st) st.focus({preventScroll:true}); } }, 140);
  }
  sec.addEventListener("click", e => {
    const b = e.target.closest("[data-k],[data-more],[data-go],[data-kind2]"); if(!b) return;
    if(b.dataset.kind2){ HOME.kind = b.dataset.kind2; HOME.lastK = null; try{ LS.set("thKind", HOME.kind); }catch(x){} renderHome(); const nb = sec.querySelector('[data-kind2="' + HOME.kind + '"]'); if(nb) nb.focus({preventScroll:true}); return; }
    if(b.dataset.k != null){ HOME.lastK = b.dataset.k; watch(HOME.flat[+b.dataset.k]); }
    else if(b.dataset.more){ window.__homeOrigin = false; show("tv"); const t = document.querySelector('[data-kind="' + b.dataset.more + '"]'); if(t) t.click(); }
    else if(b.dataset.go){ window.__homeOrigin = false; show(b.dataset.go); }
  });

  /* ligações: atualiza o ecrã quando chegam listas */
  let loading = false;
  async function loadAll(){
    if(loading) return; loading = true;
    try{ await ensureFree(false); }catch(e){}
    renderHome();
    try{ await ensureIntl(false); }catch(e){}
    loading = false; renderHome();
  }
  const _show = window.show;
  window.show = function(v){
    const prevV = currentView;
    const r = _show.apply(this, arguments); syncNav();
    if(prevV === "tv" && currentView !== "tv") stopPlayback();
    if(currentView === "tvhome"){
      renderHome(); loadAll();
      setTimeout(() => { if(currentView !== "tvhome") return; const a = document.activeElement; if(a && a !== document.body && sec.contains(a)) return; const k = HOME.lastK != null ? sec.querySelector('[data-k="' + HOME.lastK + '"]') : null; (k || sec.querySelector(".thBtn.pri,.thCard") || nav.querySelector(".thTab")).focus({preventScroll:true}); }, 120);
    }
    return r;
  };
  const _ai = window.afterIptv; if(typeof _ai === "function") window.afterIptv = function(){ const r = _ai.apply(this, arguments); try{ renderHome(); }catch(e){} return r; };
  setInterval(() => { if(currentView === "tvhome") renderHome(); }, 60000);
  setTimeout(() => { if(currentView === "tvhome" && (!document.activeElement || document.activeElement === document.body)) (sec.querySelector(".thBtn.pri,.thCard") || nav.querySelector(".thTab")).focus({preventScroll:true}); }, 900);

  /* ===== Detalhes de filmes e séries: sinopse, classificação, trailer; depois decides se vês ===== */
  const DET = window.DET = {open:false, c:null, origin:false, cache:new Map(), tk:0};
  const origPlay = window.playChannel, origSeries = window.openSeries;
  const detId = c => { const m = /\/movie\/[^/]+\/[^/]+\/(\d+)\./.exec(c.url || ""); return m ? m[1] : ""; };
  async function detLoad(c){
    if(DET.cache.has(c.url)) return DET.cache.get(c.url);
    let info = null;
    try{
      if(c.kind === "series" && c.sid){ const j = await xApi("get_series_info", "&series_id=" + c.sid); info = Object.assign({}, j.info || {}); }
      else if(c.kind === "movie"){ const id = detId(c); if(id){ const j = await xApi("get_vod_info", "&vod_id=" + id); info = Object.assign({}, j.info || {}); } }
    }catch(e){}
    info = info || {}; DET.cache.set(c.url, info); return info;
  }
  const dlg = document.createElement("div"); dlg.className = "epgdlg"; dlg.id = "detDlg"; dlg.hidden = true;
  dlg.innerHTML = '<div class="panel detbox" role="dialog" aria-label="Detalhes"><div class="detposter" id="detPoster"></div><div class="dettx"><h2 id="detTitle"></h2><div class="detmeta" id="detMeta"></div><div class="detplot" id="detPlot" tabindex="0"></div><div class="detcrew" id="detCrew"></div><div class="detbt"><button class="btn primary" id="detGo"></button><button class="btn" id="detTrailer">🎞 Trailer</button><button class="btn" id="detClose">Fechar</button></div></div></div>';
  document.body.appendChild(dlg);
  const detClose = () => { dlg.hidden = true; DET.open = false; };
  $("detClose").onclick = () => { detClose(); if(!document.querySelector(".app").classList.contains("cinema")) window.__homeOrigin = false; };
  $("detGo").onclick = () => {
    const c = DET.c; if(!c) return; detClose(); window.__homeOrigin = DET.origin;
    if(c.kind === "series" && c.sid){ origSeries(c); if(currentView !== "tv") show("tv"); return; }
    window.__noDet = true; try{ origPlay(c); }finally{ window.__noDet = false; }
    setTimeout(() => { if(currentView === "tv"){ if(!document.querySelector(".app").classList.contains("cinema")) setCinema(true); const st = $("stage"); if(st) st.focus({preventScroll:true}); } }, 160);
  };
  $("detTrailer").onclick = async () => {
    const c = DET.c; if(!c) return; const t = String(DET.trailer || "").trim();
    let id = /^[\w-]{11}$/.test(t) ? t : ((/(?:v=|youtu\.be\/)([\w-]{11})/.exec(t) || [])[1] || "");
    const q = ((typeof osParse === "function" ? osParse(c.name).title : "") || c.name) + " trailer oficial";
    if(!id && cfg.ytKey){   /* sem trailer no servidor: procura-o no YouTube com a tua chave */
      try{ const r = await fetch("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=1&type=video&videoEmbeddable=true&q=" + encodeURIComponent(q) + "&key=" + encodeURIComponent(cfg.ytKey)); const j = await r.json(); id = (((j.items || [])[0] || {}).id || {}).videoId || ""; }catch(e){}
    }
    const url = id ? "https://www.youtube.com/embed/" + id + "?autoplay=1&rel=0&playsinline=1&modestbranding=1" : "https://m.youtube.com/results?search_query=" + encodeURIComponent(q);
    try{ if(typeof Android.trailer === "function") Android.trailer(url); else window.open(url, "_blank"); }catch(e){ try{ toast("Não consegui abrir o trailer.", true); }catch(x){} }
  };
  async function showDetails(c){
    const tk = ++DET.tk; DET.c = c; DET.origin = !!window.__homeOrigin; DET.open = true; DET.trailer = "";
    const isSeries = c.kind === "series";
    $("detTitle").textContent = c.name; $("detMeta").textContent = c.group || ""; $("detPlot").textContent = "A carregar detalhes…"; $("detCrew").textContent = "";
    $("detPoster").innerHTML = c.logo ? '<img src="' + esc(c.logo) + '" alt="" onerror="this.remove()">' : "<b>" + esc((c.name || "?").slice(0, 2).toUpperCase()) + "</b>";
    const at = RES.at(c.url);
    $("detGo").textContent = isSeries ? "📺 Ver episódios" : at > 0 ? "▶ Continuar" : "▶ Ver agora";
    dlg.hidden = false; setTimeout(() => { if(DET.open) $("detGo").focus({preventScroll:true}); }, 60);
    const i = await detLoad(c); if(tk !== DET.tk || !DET.open) return;
    const y = String(i.releasedate || i.releaseDate || i.year || "").slice(0, 4);
    const rt = parseFloat(i.rating) || (parseFloat(i.rating_5based) || 0) * 2;
    const dur = i.duration || (i.episode_run_time ? i.episode_run_time + " min" : "");
    const meta = [y, dur, i.genre, i.country, i.age ? i.age : ""].filter(Boolean).join(" · ");
    $("detMeta").innerHTML = (rt ? '<b class="detrate">⭐ ' + rt.toFixed(1) + '/10</b> ' : "") + esc(meta || c.group || "");
    $("detPlot").textContent = i.plot || i.description || "Sem sinopse disponível para este título.";
    $("detCrew").innerHTML = (i.director ? "<div><b>Realização:</b> " + esc(i.director) + "</div>" : "") + (i.cast || i.actors ? "<div><b>Elenco:</b> " + esc(i.cast || i.actors) + "</div>" : "");
    DET.trailer = i.youtube_trailer || i.trailer || "";
    const img = i.movie_image || i.cover || (Array.isArray(i.backdrop_path) ? i.backdrop_path[0] : "") || c.logo;
    if(img) $("detPoster").innerHTML = '<img src="' + esc(img) + '" alt="" onerror="this.remove()">';
  }
  window.playChannel = function(c, slot, auto){
    if(c && (c.kind === "movie" || c.kind === "series") && !auto && !window.__noDet && !c._pct && !document.querySelector(".app").classList.contains("cinema") && !(c.kind === "movie" && RES.at(c.url) > 0 && DET.c && DET.c.url === c.url)){ showDetails(c); return; }
    return origPlay.apply(this, arguments);
  };
  window.openSeries = function(c){
    if(c && c.sid && !window.__noDet && !c._pct && !(DET.open === false && DET.skipSeries)){ showDetails(Object.assign({}, c, {kind:"series"})); return; }
    return origSeries.apply(this, arguments);
  };


  /* ===== Ícones nítidos (SVG) no lugar dos emojis do sistema ===== */
  const SV = {
    home:'<path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
    search:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
    guide:'<rect x="3" y="5" width="18" height="16" rx="2.5"/><path d="M3 10h18M8 3v4M16 3v4"/>',
    gear:'<circle cx="12" cy="12" r="3.2"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>',
    play:'<path d="M7 4.5l13 7.5-13 7.5z" fill="currentColor"/>',
    prev:'<path d="M17 5l-10 7 10 7z" fill="currentColor"/>',
    next:'<path d="M7 5l10 7-10 7z" fill="currentColor"/>',
    audio:'<path d="M5 4v16M12 4v16M19 4v16"/><circle cx="5" cy="9" r="2.2" fill="currentColor"/><circle cx="12" cy="15" r="2.2" fill="currentColor"/><circle cx="19" cy="8" r="2.2" fill="currentColor"/>',
    subs:'<path d="M4 5h16v11H10l-4.5 4v-4H4z"/><path d="M8 9h8M8 12h5"/>',
    film:'<rect x="4" y="4" width="16" height="16" rx="2.5"/><path d="M8.5 4v16M15.5 4v16M4 9h4.5M4 15h4.5M15.5 9H20M15.5 15H20"/>',
    cast:'<path d="M3 18a3 3 0 013 3M3 13a8 8 0 018 8M3 8a13 13 0 0113 13"/><path d="M3 5.5V4h18v16h-5.5"/>',
    mirror:'<rect x="3" y="4" width="18" height="12" rx="2.5"/><path d="M8 20h8M12 16v4"/>',
    globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3.2 3 3.2 15 0 18M12 3c-3.2 3-3.2 15 0 18"/>',
    star:'<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z" fill="currentColor"/>',
    pulse:'<path d="M3 12h4l3-7 4 14 3-7h4"/>',
    tv:'<rect x="3" y="5" width="18" height="12" rx="2.5"/><path d="M8 21h8M12 17v4"/>',
    clap:'<rect x="3" y="9" width="18" height="11" rx="2.5"/><path d="M3 9l2.5-5h4L7 9M9.5 9L12 4h4l-2.5 5M16 9l2.5-5H21l-2 5"/>',
    layers:'<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5.2l3.2 2"/>',
    pp:'<path d="M4 4.5l9 7.5-9 7.5z" fill="currentColor"/><path d="M17 5v14M21 5v14"/>',
    stop:'<rect x="6" y="6" width="12" height="12" rx="1.5" fill="currentColor"/>',
    sat:'<circle cx="12" cy="12" r="2" fill="currentColor"/><path d="M7.8 7.8a6 6 0 000 8.4M16.2 7.8a6 6 0 010 8.4M4.9 4.9a10 10 0 000 14.2M19.1 4.9a10 10 0 010 14.2"/>',
    chat:'<path d="M4 5h16v11H10l-4.5 4v-4H4z"/>'
  };
  const EM = {"🏠":"home","🔎":"search","🔍":"search","📅":"guide","⚙":"gear","▶":"play","◀":"prev","🎚":"audio","💬":"subs","🎞":"film","📡":"sat","🖥":"mirror","🌍":"globe","🌎":"globe","★":"star","⭐":"star","🩺":"pulse","📺":"tv","🎬":"clap","🍿":"layers","🕘":"clock","⏯":"pp","⏹":"stop","📖":"layers"};
  const EMRE = new RegExp("(" + Object.keys(EM).join("|") + ")[\\uFE0E\\uFE0F]?", "g");
  const icon = n => '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true">' + (SV[n] || "") + '</svg>';
  const SKIP = "#tvList,#gdList,#gdSched,#orgList,#detPlot,#detCrew,#epgBox,#chName,.thMeta,#trkAudio,#trkSubs,#osRes";
  function iconize(root){
    const w = document.createTreeWalker(root || document.body, NodeFilter.SHOW_TEXT, {acceptNode: n => (n.nodeValue && EMRE.test(n.nodeValue) && (EMRE.lastIndex = 0, true) && n.parentElement && !n.parentElement.closest(SKIP) && n.parentElement.closest("button,h1,h2,h3,.tab,.thTab,.detmeta,label") ) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT});
    const list = []; let n; while((n = w.nextNode())) list.push(n);
    list.forEach(t => {
      const frag = document.createElement("span"); frag.style.display = "contents";
      frag.innerHTML = esc(t.nodeValue).replace(EMRE, (m, e) => icon(EM[e]));
      t.replaceWith(frag);
    });
  }
  let icT = 0;
  new MutationObserver(() => { if(icT) return; icT = requestAnimationFrame(() => { icT = 0; try{ iconize(); }catch(e){} }); }).observe(document.body, {childList:true, subtree:true, characterData:true});
  iconize();


  /* ===== Definições organizadas em cartões (que abrem e fecham) ===== */
  (function(){
    const st = $("v-settings"); if(!st || $("tvSetGrid")) return;
    Object.assign(SV, {
      list:'<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1" fill="currentColor"/><circle cx="3.5" cy="12" r="1" fill="currentColor"/><circle cx="3.5" cy="18" r="1" fill="currentColor"/>',
      palette:'<circle cx="12" cy="12" r="9"/><circle cx="8" cy="10" r="1.3" fill="currentColor"/><circle cx="12" cy="7.5" r="1.3" fill="currentColor"/><circle cx="16" cy="10" r="1.3" fill="currentColor"/>',
      save:'<path d="M5 3h11l3 3v15H5z"/><path d="M8 3v6h8V3M8 21v-7h8v7"/>',
      info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5h.01"/>',
      remote:'<rect x="7" y="2" width="10" height="20" rx="3"/><circle cx="12" cy="8" r="2"/><path d="M12 13v.01M12 17v.01M9 15h.01M15 15h.01"/>',
      chev:'<path d="M9 5l7 7-7 7"/>'
    });
    const META = {"TV e IPTV":["list","Lista IPTV","M3U ou Xtream Codes, guia de programas e qualidade"], "Aparência e layout":["palette","Aparência e layout","Modelos do Início, cor e margens do ecrã"], "Cópia de segurança":["save","Cópia de segurança","Exportar e importar as definições"]};
    const cards = [...st.querySelectorAll(".setcard")].filter(c => !c.hidden);
    const extra = (id, ic, title, sub, html) => { const c = document.createElement("section"); c.className = "setcard panel"; c.id = id; c.innerHTML = "<h2>" + title + "</h2><p class='setsub'>" + sub + "</p>" + html; META[title] = [ic, title, sub]; return c; };
    const keys = [["OK","Abrir / escolher"],["Voltar","Recuar (no Início pede para confirmar a saída)"],["▲ ▼ ◀ ▶","Navegar. No vídeo: ◀ ▶ mudam de canal, ▼ vai aos botões"],["Canal + / −","Mudar de canal"],["Play / Pausa","Pausar o vídeo"],["Avançar / Recuar","Salta 30 s em filmes e séries"],["Info / Guia","Guia de programas do canal"],["Menu","Áudio e legendas, dentro do vídeo"]];
    const remote = extra("setKeys", "remote", "Teclas do comando", "O que faz cada tecla", '<div class="keyList">' + keys.map(k => "<div><b>" + k[0] + "</b><span>" + k[1] + "</span></div>").join("") + "</div>");
    const about = extra("setAbout", "info", "Sobre", "Versão e leitor de vídeo", '<div class="keyList"><div><b>Versão</b><span>' + esc(typeof APP_VERSION !== "undefined" ? APP_VERSION : "") + '</span></div><div><b>Leitor</b><span>' + (HAS_N ? "Nativo (Media3 / ExoPlayer), com recurso ao da página" : "Da página (hls.js / mpegts.js)") + '</span></div><div><b>Aparelho</b><span>' + (isTvDev ? "Android TV" : "Telemóvel / tablet") + '</span></div></div>');
    const order = ["TV e IPTV", "Aparência e layout", "Cópia de segurança"];
    const byT = {}; cards.forEach(c => { byT[(c.querySelector("h2") || {}).textContent.trim()] = c; });
    const list = order.map(t => byT[t]).filter(Boolean).concat([remote, about]);
    const grid = document.createElement("div"); grid.id = "tvSetGrid";
    const first = cards[0]; if(first && first.parentNode) first.parentNode.insertBefore(grid, first); else st.appendChild(grid);
    list.forEach(card => {
      const t = (card.querySelector("h2") || {}).textContent.trim(), m = META[t] || ["gear", t, ""];
      const sub = card.querySelector(".setsub"); if(sub) sub.remove();
      const body = document.createElement("div"); body.className = "setBody"; body.hidden = true;
      [...card.children].forEach(ch => { if(ch.tagName !== "H2") body.appendChild(ch); });
      const head = document.createElement("button"); head.className = "setHead"; head.setAttribute("aria-expanded", "false");
      head.innerHTML = '<span class="setIc">' + icon(m[0]) + '</span><span class="setT"><b>' + esc(m[1]) + '</b><small>' + esc(m[2]) + '</small></span><span class="chev">' + icon("chev") + '</span>';
      card.appendChild(head); card.appendChild(body); card.classList.add("setfold");
      head.onclick = () => {
        const open = !card.classList.contains("open");
        grid.querySelectorAll(".setcard.open").forEach(o => { o.classList.remove("open"); o.querySelector(".setBody").hidden = true; o.querySelector(".setHead").setAttribute("aria-expanded", "false"); });
        if(open){ card.classList.add("open"); body.hidden = false; head.setAttribute("aria-expanded", "true"); setTimeout(() => card.scrollIntoView({block:"start"}), 30); }
      };
      grid.appendChild(card);
    });
    /* primeira vez (sem lista IPTV): abre logo o cartão da lista */
    try{ if(!(cfg.m3u || cfg.xs)){ const h = grid.querySelector(".setHead"); if(h) h.click(); } }catch(e){}
  })();

  /* ===== Picons: logótipos de canais em alta resolução (PT) ===== */
  (function(){
    const BASE = "https://cdn.jsdelivr.net/gh/tv-logos/tv-logos@main/countries/portugal/";
    const FB = new Map();   /* url nova -> logótipo do fornecedor */
    const slug = n => String(n || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()
      .replace(/^[\s\W_]*(pt|portugal)\b[\s|:\-\/]*/i, "").replace(/\[[^\]]*\]|\([^)]*\)/g, " ")
      .replace(/\b(fhd|uhd|hd|sd|4k|8k|hevc|h265|raw|plus|tv por assinatura)\b/g, " ")
      .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
    const ptc = c => c.kind === "live" && (isPtGroup(c.group) || /^[\s\W_]*(PT|PORTUGAL)\b/i.test(c.name || ""));
    function patch(){
      try{ for(const c of channels){ if(!ptc(c) || c.logo0 !== undefined) continue; const sl = slug(c.name); if(!sl || sl.length < 2) continue; c.logo0 = c.logo || ""; const u = BASE + sl + "-pt.png"; FB.set(u, c.logo0); c.logo = u; } }catch(e){}
    }
    document.addEventListener("error", ev => {
      const im = ev.target; if(!im || im.tagName !== "IMG" || !FB.has(im.src)) return;
      const o = FB.get(im.src); FB.delete(im.src);
      ev.stopImmediatePropagation();
      if(o) im.src = o; else im.remove();
    }, true);
    const _ai = window.afterIptv;
    if(typeof _ai === "function") window.afterIptv = function(){ patch(); return _ai.apply(this, arguments); };
    patch();
    /* o logótipo do fornecedor (se o do repositório falhar) é guardado em cache, mas o novo não: evita pedidos repetidos */
    document.head.insertAdjacentHTML("beforeend", "<style>.thArt img,.gch img,#tvList img{object-fit:contain!important;image-rendering:auto}</style>");
  })();

  syncNav();
  if(currentView === "tvhome") window.show("tvhome");
})();
</script>
'''

i = h.rfind("</body>")
h = h[:i] + JS + JS2 + h[i:]
os.makedirs(os.path.dirname(out), exist_ok=True)
open(out, "w", encoding="utf-8").write(h)
print("OK ->", os.path.normpath(out), len(h)//1024, "KB")
