package pt.rui.cockpittv;

import android.content.Context;
import android.database.DataSetObserver;
import android.graphics.Rect;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LayoutAnimationController;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.FrameLayout;
import android.widget.GridView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

/**
 * v417: grelha de Explorar.
 * «Atual» usa o GridView de sempre (comportamento inalterado).
 * «Moderno» usa um RecyclerView em mosaico: na TV, em 4 colunas, a cada três capas uma ocupa 2 colunas.
 * Expõe os mesmos métodos que o GridView, para o resto da app não mudar.
 */
class GridHost extends FrameLayout {
    private final GridView gv;
    private final RecyclerView rv;
    private final GridLayoutManager lm;
    private final Drawable ring;
    private final int dpSpacing;
    private BaseAdapter adapter;
    private MosaicAdapter mAdapter;
    private AdapterView.OnItemClickListener clickL;
    private AdapterView.OnItemLongClickListener longL;
    private AdapterView.OnItemSelectedListener selL;
    private int columns = 4, colWidth = 0, spacingPx = 0;
    private boolean mosaicPosters = false;

    GridHost(Context c, boolean moderno, Drawable focusRing) {
        super(c);
        ring = focusRing;
        dpSpacing = Math.round(7 * c.getResources().getDisplayMetrics().density);
        if (moderno) {
            gv = null;
            rv = new RecyclerView(c);
            lm = new GridLayoutManager(c, columns);
            lm.setSpanSizeLookup(new GridLayoutManager.SpanSizeLookup() {
                @Override public int getSpanSize(int p) { return spanOf(p); }
            });
            rv.setLayoutManager(lm);
            rv.setClipToPadding(false);
            rv.setItemAnimator(null);
            rv.setOverScrollMode(View.OVER_SCROLL_NEVER);
            rv.addItemDecoration(new RecyclerView.ItemDecoration() {
                @Override public void getItemOffsets(Rect out, View view, RecyclerView parent, RecyclerView.State state) {
                    out.set(dpSpacing, dpSpacing, dpSpacing, dpSpacing);
                }
            });
            addView(rv, new LayoutParams(-1, -1));
        } else {
            rv = null; lm = null;
            gv = new GridView(c);
            addView(gv, new LayoutParams(-1, -1));
        }
    }

    /* ---- espelho da API do GridView ---- */
    void setSelector(Drawable d) { if (gv != null) gv.setSelector(d); }
    void setDrawSelectorOnTop(boolean on) { if (gv != null) gv.setDrawSelectorOnTop(on); }
    void setVerticalSpacing(int px) { if (gv != null) gv.setVerticalSpacing(px); spacingPx = Math.max(spacingPx, px); }
    void setHorizontalSpacing(int px) { if (gv != null) gv.setHorizontalSpacing(px); spacingPx = Math.max(spacingPx, px); }
    void setStretchMode(int mode) { if (gv != null) gv.setStretchMode(mode); }
    void setLayoutAnimation(LayoutAnimationController c) { if (gv != null) gv.setLayoutAnimation(c); }
    void setColumnWidth(int px) { colWidth = px; if (gv != null) gv.setColumnWidth(px); }
    void setNumColumns(int n) {
        if (gv != null) { gv.setNumColumns(n); return; }
        mosaicPosters = n > 0;   /* só as capas usam o mosaico; as linhas (canais) ficam em colunas automáticas */
        if (n > 0) columns = n;
        requestLayout();
    }

    @Override public void setPadding(int l, int t, int r, int b) {
        if (gv != null) gv.setPadding(l, t, r, b); else if (rv != null) rv.setPadding(l, t, r, b); else super.setPadding(l, t, r, b);
    }
    @Override public void setClipToPadding(boolean clip) {
        if (gv != null) gv.setClipToPadding(clip); else if (rv != null) rv.setClipToPadding(clip); else super.setClipToPadding(clip);
    }

    void setAdapter(BaseAdapter a) {
        adapter = a;
        if (gv != null) { gv.setAdapter(a); return; }
        mAdapter = new MosaicAdapter();
        rv.setAdapter(mAdapter);
        a.registerDataSetObserver(new DataSetObserver() {
            @Override public void onChanged() { if (mAdapter != null) mAdapter.notifyDataSetChanged(); }
            @Override public void onInvalidated() { if (mAdapter != null) mAdapter.notifyDataSetChanged(); }
        });
    }
    void setOnItemClickListener(AdapterView.OnItemClickListener l) { clickL = l; if (gv != null) gv.setOnItemClickListener(l); }
    void setOnItemLongClickListener(AdapterView.OnItemLongClickListener l) { longL = l; if (gv != null) gv.setOnItemLongClickListener(l); }
    void setOnItemSelectedListener(AdapterView.OnItemSelectedListener l) { selL = l; if (gv != null) gv.setOnItemSelectedListener(l); }

    int getCount() { return gv != null ? gv.getCount() : (adapter == null ? 0 : adapter.getCount()); }
    int getFirstVisiblePosition() { return gv != null ? gv.getFirstVisiblePosition() : Math.max(0, lm.findFirstVisibleItemPosition()); }
    int getSelectedItemPosition() {
        if (gv != null) return gv.getSelectedItemPosition();
        for (int i = 0; i < rv.getChildCount(); i++) {
            View ch = rv.getChildAt(i);
            if (ch.hasFocus()) return rv.getChildAdapterPosition(ch);
        }
        return -1;
    }
    void setSelection(final int pos) {
        if (gv != null) { gv.setSelection(pos); return; }
        rv.scrollToPosition(Math.max(0, pos));
        if (hasFocus()) rv.postDelayed(() -> {
            RecyclerView.ViewHolder vh = rv.findViewHolderForAdapterPosition(pos);
            if (vh != null) vh.itemView.requestFocus();
        }, 60);
    }

    @Override protected void onLayout(boolean changed, int l, int t, int r, int b) {
        if (rv != null) {   /* número de colunas: 4 no mosaico de capas; nas linhas, as que cabem na largura */
            int want = mosaicPosters ? columns : Math.max(1, (getWidth() - getPaddingLeft() - getPaddingRight()) / Math.max(1, colWidth));
            if (lm.getSpanCount() != want) lm.setSpanCount(want);
        }
        super.onLayout(changed, l, t, r, b);
    }

    private int spanOf(int p) {
        if (!mosaicPosters || adapter == null) return 1;
        return p % 3 == 0 ? 2 : 1;   /* 2 + 1 + 1 = 4 colunas: uma capa grande por cada linha */
    }

    /** Adaptador do RecyclerView: reaproveita as vistas que o BaseAdapter já sabe construir. */
    private class MosaicAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
        @Override public int getItemCount() { return adapter == null ? 0 : adapter.getCount(); }

        @Override public RecyclerView.ViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
            FrameLayout f = new FrameLayout(parent.getContext());
            f.setFocusable(true); f.setClickable(true);
            return new RecyclerView.ViewHolder(f) { };
        }

        @Override public void onBindViewHolder(final RecyclerView.ViewHolder h, int pos) {
            FrameLayout f = (FrameLayout) h.itemView;
            View cur = f.getChildCount() > 0 ? f.getChildAt(0) : null;
            View v = adapter.getView(pos, cur, f);
            if (v != cur) { f.removeAllViews(); f.addView(v, new FrameLayout.LayoutParams(-1, -2)); }
            f.setOnClickListener(x -> { if (clickL != null) clickL.onItemClick(null, x, h.getAdapterPosition(), h.getItemId()); });
            f.setOnLongClickListener(x -> longL != null && longL.onItemLongClick(null, x, h.getAdapterPosition(), h.getItemId()));
            f.setOnFocusChangeListener((x, focused) -> {
                x.setForeground(focused && ring != null ? (ring.getConstantState() != null ? ring.getConstantState().newDrawable() : ring) : null);
                x.animate().cancel();
                x.animate().scaleX(focused ? 1.06f : 1f).scaleY(focused ? 1.06f : 1f).setDuration(120).start();
                if (focused && selL != null) selL.onItemSelected(null, x, h.getAdapterPosition(), h.getItemId());
            });
        }
    }
}
