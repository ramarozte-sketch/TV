package pt.rui.cockpittv;

import android.content.Context;

import org.xmlpull.v1.XmlPullParser;

import java.io.BufferedInputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;
import java.util.zip.GZIPInputStream;

/**
 * Guia completo (XMLTV): descarregado de uma vez, guardado no aparelho e consultado localmente.
 * O «agora / a seguir» é calculado pelas horas de cada programa, por isso nunca fica desatualizado
 * quando um programa acaba. Os canais sem dados no XMLTV usam o pedido por canal (get_short_epg),
 * também guardado com as horas.
 */
final class Epg {
    private Epg() { }

    /** Programação de um canal, ordenada por início. */
    static final class Ch {
        long[] st, en; String[] ti, de;
        int size() { return st.length; }
    }
    /** Resultado da pesquisa: canal + programa encontrado. */
    static final class Hit {
        NativeData.Item ch; long st, en; String title; int more;
    }

    private static volatile Map<String, Ch> MAP = new HashMap<>();     /* chave: epgId em minúsculas */
    private static volatile Map<String, String> NAMES = new HashMap<>(); /* nome normalizado do canal → id do XMLTV (canais sem epgId) */
    private static final Map<String, Ch> SHORT = new ConcurrentHashMap<>();   /* chave: url do canal (pedido por canal) */
    private static volatile long savedAt = 0, until = 0;
    private static volatile int progCount = 0;
    private static volatile String lastError = "";
    private static volatile boolean loaded = false, running = false;
    static volatile long dlBytes = 0;

    private static final long PAST = 3 * 3600_000L, AHEAD = 4 * 86400_000L;
    private static final int MAX_PROGS = 350_000, MAX_DESC = 260;

    private static File file(Context c) { return new File(c.getFilesDir(), "epg_xmltv.bin"); }
    static String key(NativeData.Item it) { return it == null || it.epgId == null ? "" : it.epgId.trim().toLowerCase(Locale.ROOT); }
    private static final java.util.regex.Pattern NOISE = java.util.regex.Pattern.compile("\\b(fhd|uhd|hd|sd|4k|8k|hevc|h265|h264|1080p|720p|576p|50fps|60fps|backup|alt|raw|vip)\\b|\\(.*?\\)|\\[.*?\\]");
    /** Nome do canal reduzido para comparar com o XMLTV: «PT: SIC Notícias HD» → «sicnoticias». */
    static String nameKey(String n) {
        if (n == null) return "";
        String s = NativeData.norm(NativeData.shownName(n)).trim();
        s = s.replaceFirst("^[a-z]{2,3}\\s*[:|\\-]\\s+", "");
        s = NOISE.matcher(s).replaceAll(" ");
        s = s.replaceAll("[^a-z0-9]", "");
        return s.length() < 2 ? "" : s;
    }

    static boolean loaded() { return loaded; }
    static boolean running() { return running; }
    static long savedAt() { return savedAt; }
    static long until() { return until; }
    static int channels() { return MAP.size(); }
    static int programmes() { return progCount; }
    static String lastError() { return lastError; }

    /** Lê o guia guardado (chamar numa thread de fundo). */
    static synchronized void load(Context c) {
        if (loaded) return;
        loaded = true;
        File f = file(c);
        if (!f.exists()) return;
        try (DataInputStream in = new DataInputStream(new BufferedInputStream(new FileInputStream(f), 1 << 16))) {
            int ver = in.readInt();
            if (ver != 0x45504731 && ver != 0x45504732) return;
            long at = in.readLong(); int nch = in.readInt();
            Map<String, Ch> m = new HashMap<>(nch * 2); Map<String, String> pool = new HashMap<>();
            int total = 0; long last = 0, now = System.currentTimeMillis();
            for (int i = 0; i < nch; i++) {
                String k = in.readUTF(); int n = in.readInt();
                long[] st = new long[n], en = new long[n]; String[] ti = new String[n], de = new String[n];
                int w = 0;
                for (int j = 0; j < n; j++) {
                    long s = in.readLong(), e = in.readLong(); String t = in.readUTF(), d = in.readUTF();
                    if (e < now - PAST) continue;
                    String tp = pool.get(t); if (tp == null) { pool.put(t, t); tp = t; }
                    st[w] = s; en[w] = e; ti[w] = tp; de[w] = d; w++;
                    if (e > last) last = e;
                }
                if (w == 0) continue;
                Ch ch = new Ch(); ch.st = Arrays.copyOf(st, w); ch.en = Arrays.copyOf(en, w); ch.ti = Arrays.copyOf(ti, w); ch.de = Arrays.copyOf(de, w);
                m.put(k, ch); total += w;
            }
            Map<String, String> nm = new HashMap<>();
            if (ver == 0x45504732) { int nn = in.readInt(); for (int i = 0; i < nn; i++) { String a = in.readUTF(), b = in.readUTF(); nm.put(a, b); } }
            MAP = m; NAMES = nm; savedAt = at; until = last; progCount = total;
            NativeData.dbg("guia: lido do aparelho, " + m.size() + " canais, " + total + " programas, até " + fmtDay(last));
        } catch (Throwable e) { NativeData.dbg("guia: cópia no aparelho ilegível: " + e); }
    }

    private static void save(Context c, Map<String, Ch> m, Map<String, String> names, long at) {
        File tmp = new File(c.getFilesDir(), "epg_xmltv.tmp");
        try (DataOutputStream o = new DataOutputStream(new java.io.BufferedOutputStream(new FileOutputStream(tmp), 1 << 16))) {
            o.writeInt(0x45504732); o.writeLong(at); o.writeInt(m.size());
            for (Map.Entry<String, Ch> e : m.entrySet()) {
                Ch ch = e.getValue();
                o.writeUTF(e.getKey()); o.writeInt(ch.size());
                for (int j = 0; j < ch.size(); j++) { o.writeLong(ch.st[j]); o.writeLong(ch.en[j]); o.writeUTF(cut(ch.ti[j], 300)); o.writeUTF(cut(ch.de[j], MAX_DESC)); }
            }
            o.writeInt(names.size());
            for (Map.Entry<String, String> e : names.entrySet()) { o.writeUTF(cut(e.getKey(), 200)); o.writeUTF(cut(e.getValue(), 200)); }
        } catch (Throwable e) { NativeData.dbg("guia: não consegui guardar: " + e); tmp.delete(); return; }
        if (!tmp.renameTo(file(c))) { file(c).delete(); tmp.renameTo(file(c)); }
    }
    private static String cut(String s, int n) { return s == null ? "" : s.length() > n ? s.substring(0, n) : s; }

    /** Precisa de nova transferência? (idade maior que o intervalo, ou a programação está a acabar) */
    static boolean stale(int hours) {
        if (running) return false;
        long now = System.currentTimeMillis();
        if (savedAt == 0) return true;
        if (until > 0 && until - now < 6 * 3600_000L) return true;
        return hours > 0 && now - savedAt > hours * 3600_000L;
    }

    interface Progress { void on(long bytes, int progs); }

    /** Descarrega e lê o XMLTV. Devolve o número de programas, ou lança erro. */
    static int refresh(Context c, NativeData d, Progress p) throws Exception {
        String url = d.xmltvUrl();
        if (url.isEmpty()) throw new Exception(Tr.t("a lista não indica um guia XMLTV"));
        synchronized (Epg.class) { if (running) throw new Exception(Tr.t("o guia já está a ser atualizado")); running = true; }
        dlBytes = 0;
        HttpURLConnection con = null;
        try {
            /* só guardamos os canais da lista (poupa memória em listas com milhares de canais) */
            Set<String> want = new HashSet<>();
            List<NativeData.Item> live = d.all.get("live");
            if (live != null) for (NativeData.Item it : live) { String k = key(it); if (!k.isEmpty()) want.add(k); }
            if (want.size() > 6000) {   /* listas enormes: só os canais das categorias visíveis */
                Set<String> v = new HashSet<>();
                try { for (NativeData.Cat cat : d.visibleCats("live")) for (NativeData.Item it : cat.items) { String k = key(it); if (!k.isEmpty()) v.add(k); } } catch (Throwable ignored) { }
                if (!v.isEmpty()) want = v;
            }
            /* canais sem epgId (ou com um id que o XMLTV não tem): tenta pelo nome */
            Set<String> wantNames = new HashSet<>();
            if (live != null) for (NativeData.Item it : live) { String nk = nameKey(it.name); if (!nk.isEmpty()) wantNames.add(nk); if (wantNames.size() > 20000) break; }
            Map<String, String> names = new HashMap<>();
            Set<String> xmlIds = new HashSet<>();
            int byName = 0;
            String cur = url;
            for (int i = 0; ; i++) {
                con = (HttpURLConnection) new URL(cur).openConnection();
                con.setInstanceFollowRedirects(false);
                con.setConnectTimeout(15000); con.setReadTimeout(90000);
                con.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) CockpitTV");
                con.setRequestProperty("Accept-Encoding", "gzip");
                int code = con.getResponseCode();
                if (code >= 300 && code < 400 && i < 6) { String loc = con.getHeaderField("Location"); con.disconnect(); if (loc == null) throw new Exception("HTTP " + code); cur = new URL(new URL(cur), loc).toString(); continue; }
                if (code >= 400) throw new Exception("HTTP " + code);
                break;
            }
            InputStream raw = new CountingStream(con.getInputStream());
            BufferedInputStream bin = new BufferedInputStream(raw, 1 << 16);
            bin.mark(4); int b1 = bin.read(), b2 = bin.read(); bin.reset();
            InputStream in = (b1 == 0x1f && b2 == 0x8b) ? new BufferedInputStream(new GZIPInputStream(bin, 1 << 16), 1 << 16) : bin;

            long now = System.currentTimeMillis(), from = now - PAST, to = now + AHEAD;
            Map<String, List<Object[]>> tmp = new HashMap<>(); Map<String, String> pool = new HashMap<>();
            int count = 0, seen = 0;
            XmlPullParser x = android.util.Xml.newPullParser();
            x.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false);
            x.setInput(in, null);
            String chId = null, title = null, desc = null; long s = 0, e = 0; boolean keep = false;
            String xmlCh = null; List<String> dn = new ArrayList<>();
            for (int ev = x.getEventType(); ev != XmlPullParser.END_DOCUMENT; ev = x.next()) {
                if (ev == XmlPullParser.START_TAG) {
                    String n = x.getName();
                    if ("channel".equals(n)) { xmlCh = x.getAttributeValue(null, "id"); xmlCh = xmlCh == null ? null : xmlCh.trim().toLowerCase(Locale.ROOT); dn.clear(); if (xmlCh != null) xmlIds.add(xmlCh); }
                    else if (xmlCh != null && "display-name".equals(n)) { try { dn.add(x.nextText()); } catch (Throwable ignored) { } }
                    else if ("programme".equals(n)) {
                        seen++;
                        chId = x.getAttributeValue(null, "channel");
                        String k = chId == null ? "" : chId.trim().toLowerCase(Locale.ROOT);
                        s = xmlTime(x.getAttributeValue(null, "start")); e = xmlTime(x.getAttributeValue(null, "stop"));
                        if (e <= 0 && s > 0) e = s + 3600_000L;
                        keep = want.contains(k) && s > 0 && e > from && s < to && count < MAX_PROGS;
                        chId = k; title = null; desc = null;
                        if (p != null && (seen & 1023) == 0) p.on(dlBytes, count);
                    } else if (keep && "title".equals(n) && title == null) title = x.nextText();
                    else if (keep && "desc".equals(n) && desc == null) desc = x.nextText();
                } else if (ev == XmlPullParser.END_TAG && "channel".equals(x.getName())) {
                    if (xmlCh != null) {
                        for (String d0 : dn) { String nk = nameKey(d0); if (!nk.isEmpty() && wantNames.contains(nk) && !names.containsKey(nk)) { names.put(nk, xmlCh); if (want.add(xmlCh)) byName++; } }
                        String nk = nameKey(xmlCh.replaceAll("\\.[a-z]{2,3}$", ""));   /* ids do tipo «sicnoticias.pt» */
                        if (!nk.isEmpty() && wantNames.contains(nk) && !names.containsKey(nk)) { names.put(nk, xmlCh); if (want.add(xmlCh)) byName++; }
                    }
                    xmlCh = null;
                } else if (ev == XmlPullParser.END_TAG && "programme".equals(x.getName())) {
                    if (keep && title != null && !title.trim().isEmpty()) {
                        String t = title.trim(); String tp = pool.get(t); if (tp == null) { pool.put(t, t); tp = t; }
                        List<Object[]> l = tmp.get(chId); if (l == null) { l = new ArrayList<>(); tmp.put(chId, l); }
                        l.add(new Object[]{s, e, tp, cut(desc == null ? "" : desc.trim(), MAX_DESC)});
                        count++;
                    }
                    keep = false;
                }
            }
            if (count == 0) throw new Exception(seen == 0 ? Tr.t("o servidor não enviou programas") : Tr.t("nenhum programa corresponde aos canais da lista"));
            Map<String, Ch> m = new HashMap<>(tmp.size() * 2); long last = 0;
            for (Map.Entry<String, List<Object[]>> en : tmp.entrySet()) {
                List<Object[]> l = en.getValue();
                Collections.sort(l, (a, b) -> Long.compare((Long) a[0], (Long) b[0]));
                Ch ch = new Ch(); int n = l.size();
                ch.st = new long[n]; ch.en = new long[n]; ch.ti = new String[n]; ch.de = new String[n];
                for (int i = 0; i < n; i++) { Object[] o = l.get(i); ch.st[i] = (Long) o[0]; ch.en[i] = (Long) o[1]; ch.ti[i] = (String) o[2]; ch.de[i] = (String) o[3]; if (ch.en[i] > last) last = ch.en[i]; }
                m.put(en.getKey(), ch);
            }
            long at = System.currentTimeMillis();
            /* só fica o atalho pelo nome se esse canal tiver programas */
            Map<String, String> nm = new HashMap<>();
            for (Map.Entry<String, String> en : names.entrySet()) if (m.containsKey(en.getValue())) nm.put(en.getKey(), en.getValue());
            MAP = m; NAMES = nm; savedAt = at; until = last; progCount = count; loaded = true; lastError = "";
            SHORT.clear();
            save(c, m, nm, at);
            int linked = 0, total = 0;
            if (live != null) { Set<String> u = new HashSet<>(); for (NativeData.Item it : live) { if (!u.add(it.url)) continue; total++; if (chOf(it) != null) linked++; } }
            NativeData.dbg("guia: " + linked + " de " + total + " canais da lista com programação (" + byName + " canais do XMLTV ligados pelo nome, " + xmlIds.size() + " canais no XMLTV)");
            NativeData.dbg("guia: XMLTV lido, " + (dlBytes / 1024) + " KB, " + seen + " programas no ficheiro, " + count + " guardados em " + m.size() + " canais (de " + want.size() + " pedidos), até " + fmtDay(last));
            return count;
        } catch (Exception ex) {
            lastError = String.valueOf(ex.getMessage());
            NativeData.dbg("guia: XMLTV falhou: " + ex);
            throw ex;
        } finally {
            running = false;
            if (con != null) try { con.disconnect(); } catch (Throwable ignored) { }
        }
    }

    private static final class CountingStream extends java.io.FilterInputStream {
        CountingStream(InputStream in) { super(in); }
        @Override public int read() throws java.io.IOException { int r = super.read(); if (r >= 0) dlBytes++; return r; }
        @Override public int read(byte[] b, int o, int l) throws java.io.IOException { int r = super.read(b, o, l); if (r > 0) dlBytes += r; return r; }
    }

    /** «20261127210000 +0000» → milissegundos (UTC). */
    static long xmlTime(String v) {
        if (v == null) return 0;
        v = v.trim();
        if (v.length() < 12) return 0;
        try {
            int y = Integer.parseInt(v.substring(0, 4)), mo = Integer.parseInt(v.substring(4, 6)), d = Integer.parseInt(v.substring(6, 8));
            int h = Integer.parseInt(v.substring(8, 10)), mi = Integer.parseInt(v.substring(10, 12));
            int se = v.length() >= 14 && Character.isDigit(v.charAt(12)) ? Integer.parseInt(v.substring(12, 14)) : 0;
            long days = daysFromCivil(y, mo, d);
            long t = ((days * 24 + h) * 60 + mi) * 60 + se;
            int sp = v.indexOf(' ');
            String tz = sp > 0 ? v.substring(sp + 1).trim() : "";
            if (tz.length() >= 5 && (tz.charAt(0) == '+' || tz.charAt(0) == '-')) {
                int off = Integer.parseInt(tz.substring(1, 3)) * 60 + Integer.parseInt(tz.substring(3, 5));
                t -= (tz.charAt(0) == '+' ? 1 : -1) * off * 60L;
            }
            return t * 1000L;
        } catch (Throwable e) { return 0; }
    }
    private static long daysFromCivil(int y, int m, int d) {
        y -= m <= 2 ? 1 : 0;
        long era = (y >= 0 ? y : y - 399) / 400;
        long yoe = y - era * 400;
        long doy = (153L * (m + (m > 2 ? -3 : 9)) + 2) / 5 + d - 1;
        long doe = yoe * 365 + yoe / 4 - yoe / 100 + doy;
        return era * 146097 + doe - 719468;
    }

    /* ------------------------------------------------------------ consultas */

    private static Ch chOf(NativeData.Item it) {
        if (it == null) return null;
        String k = key(it);
        Ch c = k.isEmpty() ? null : MAP.get(k);
        if (c != null) return c;
        String nid = NAMES.get(nameKey(it.name));
        if (nid != null) { c = MAP.get(nid); if (c != null) return c; }
        return it.url == null ? null : SHORT.get(it.url);
    }
    /** Tem programação (do XMLTV ou do pedido por canal) que cubra o momento atual? */
    static boolean covers(NativeData.Item it) {
        Ch c = chOf(it); if (c == null || c.size() == 0) return false;
        return c.en[c.size() - 1] > System.currentTimeMillis();
    }
    static boolean inXmltv(NativeData.Item it) {
        String k = key(it); if (!k.isEmpty() && MAP.containsKey(k)) return true;
        String nid = NAMES.get(nameKey(it == null ? null : it.name)); return nid != null && MAP.containsKey(nid);
    }

    /** Guarda a programação pedida por canal (get_short_epg / get_simple_data_table). */
    static void putShort(NativeData.Item it, List<NativeData.Prog> ps) {
        if (it == null || it.url == null || ps == null) return;
        Ch c = new Ch(); int n = ps.size();
        c.st = new long[n]; c.en = new long[n]; c.ti = new String[n]; c.de = new String[n];
        for (int i = 0; i < n; i++) { NativeData.Prog p = ps.get(i); c.st[i] = p.start; c.en[i] = p.end; c.ti[i] = p.title; c.de[i] = p.desc; }
        SHORT.put(it.url, c);
    }

    /** Índice do programa a dar agora (ou -1). */
    private static int nowIdx(Ch c, long now) {
        int lo = 0, hi = c.size() - 1, ans = -1;
        while (lo <= hi) { int mid = (lo + hi) >>> 1; if (c.st[mid] <= now) { ans = mid; lo = mid + 1; } else hi = mid - 1; }
        return ans >= 0 && c.en[ans] > now ? ans : -1;
    }
    private static int nextIdx(Ch c, long now) {
        for (int i = 0; i < c.size(); i++) if (c.st[i] > now) return i;
        return -1;
    }

    /** «21:00 Telejornal   ·   a seguir 22:00 Futebol»; null se não houver dados. */
    static String nowNext(NativeData.Item it) {
        Ch c = chOf(it); if (c == null || c.size() == 0) return null;
        long now = System.currentTimeMillis();
        int a = nowIdx(c, now), b = nextIdx(c, now);
        if (a < 0 && b < 0) return null;
        StringBuilder sb = new StringBuilder();
        if (a >= 0) sb.append(hm(c.st[a])).append(' ').append(c.ti[a]);
        if (b >= 0 && (a < 0 || b != a)) { if (sb.length() > 0) sb.append("   ·   "); sb.append(Tr.t("a seguir")).append(' ').append(hm(c.st[b])).append(' ').append(c.ti[b]); }
        return sb.toString();
    }
    /** Fração já vista do programa atual (0..1), ou -1. */
    static float progress(NativeData.Item it) {
        Ch c = chOf(it); if (c == null) return -1;
        long now = System.currentTimeMillis(); int a = nowIdx(c, now);
        if (a < 0) return -1;
        return Math.max(0f, Math.min(1f, (now - c.st[a]) / (float) Math.max(1, c.en[a] - c.st[a])));
    }
    /** Programas que ainda não acabaram (para gravações e a lista de programas). */
    static List<NativeData.Prog> progs(NativeData.Item it) {
        List<NativeData.Prog> out = new ArrayList<>();
        Ch c = chOf(it); if (c == null) return out;
        long now = System.currentTimeMillis();
        for (int i = 0; i < c.size(); i++) {
            if (c.en[i] <= now) continue;
            NativeData.Prog p = new NativeData.Prog(); p.title = c.ti[i]; p.desc = c.de[i]; p.start = c.st[i]; p.end = c.en[i]; out.add(p);
        }
        return out;
    }

    /**
     * Pesquisa por título (todas as palavras, sem acentos) e, com menos peso, pela descrição,
     * em toda a programação guardada que ainda não acabou. Um resultado por canal: o primeiro
     * programa encontrado (a dar agora primeiro), com o número de outras sessões.
     */
    static List<Hit> search(String q, List<NativeData.Item> chans, int max) {
        List<Hit> out = new ArrayList<>();
        if (q == null || chans == null) return out;
        String[] words = NativeData.norm(q).trim().split("\\s+");
        if (words.length == 0 || words[0].isEmpty()) return out;
        long now = System.currentTimeMillis();
        Map<Ch, Hit> byCh = new HashMap<>();
        Map<String, String> normCache = new HashMap<>();
        List<Hit> descHits = new ArrayList<>();
        Set<String> urls = new HashSet<>();
        for (NativeData.Item it : chans) {
            if (it == null || it.url == null || !urls.add(it.url)) continue;
            Ch c = chOf(it); if (c == null) continue;
            Hit h = byCh.get(c);
            if (h != null) continue;   /* o mesmo canal repetido noutra categoria */
            for (int i = 0; i < c.size(); i++) {
                if (c.en[i] <= now) continue;
                String t = normCache.get(c.ti[i]);
                if (t == null) { t = NativeData.norm(c.ti[i]); normCache.put(c.ti[i], t); }
                boolean inTitle = all(t, words);
                boolean inDesc = !inTitle && c.de[i] != null && c.de[i].length() > 0 && all(NativeData.norm(c.de[i]), words);
                if (!inTitle && !inDesc) continue;
                if (h == null) {
                    h = new Hit(); h.ch = it; h.st = c.st[i]; h.en = c.en[i]; h.title = c.ti[i];
                    byCh.put(c, h);
                    (inTitle ? out : descHits).add(h);
                } else h.more++;
            }
        }
        Collections.sort(out, (a, b) -> {
            boolean na = a.st <= now, nb = b.st <= now;
            if (na != nb) return na ? -1 : 1;
            return Long.compare(a.st, b.st);
        });
        Collections.sort(descHits, (a, b) -> Long.compare(a.st, b.st));
        out.addAll(descHits);
        return out.size() > max ? new ArrayList<>(out.subList(0, max)) : out;
    }
    private static boolean all(String t, String[] w) { for (String x : w) if (!t.contains(x)) return false; return true; }

    /** Texto do resultado: «● Agora · 21:00–22:30 Título (+2)» ou «Sáb 28 · 21:00 Título». */
    static String hitText(Hit h) {
        long now = System.currentTimeMillis();
        String when = h.st <= now ? "● " + Tr.t("Agora") + " · " + hm(h.st) + "–" + hm(h.en) : day(h.st) + " · " + hm(h.st);
        return when + "  " + h.title + (h.more > 0 ? "  (+" + h.more + ")" : "");
    }

    static String hm(long t) { Calendar c = Calendar.getInstance(); c.setTimeInMillis(t); return String.format(Locale.ROOT, "%02d:%02d", c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE)); }
    static String day(long t) {
        Calendar c = Calendar.getInstance(); c.setTimeInMillis(t);
        Calendar n = Calendar.getInstance();
        int dd = c.get(Calendar.DAY_OF_YEAR) - n.get(Calendar.DAY_OF_YEAR) + (c.get(Calendar.YEAR) - n.get(Calendar.YEAR)) * 365;
        if (dd == 0) return Tr.t("Hoje");
        if (dd == 1) return Tr.t("Amanhã");
        Locale l = "pt".equals(Tr.lang) ? new Locale("pt", "PT") : new Locale(Tr.lang);
        String s = new java.text.SimpleDateFormat("EEE d", l).format(c.getTime()).replace(".", "");
        return s.isEmpty() ? s : s.substring(0, 1).toUpperCase(l) + s.substring(1);
    }
    static String fmtDay(long t) { return t <= 0 ? "—" : day(t) + " " + hm(t); }
}
