package pt.rui.cockpittv;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Cockpit TV: WebView que carrega a parte IPTV do Cockpit (assets/index.html).
 * Faz de "proxy" local: pedidos http(s) GET passam por aqui com o User-Agent do VLC
 * (e o Referer da estação nos canais abertos), por isso não é preciso Cloudflare Worker.
 */
public class MainActivity extends Activity {
    private static final String UA = "VLC/3.0.20 LibVLC/3.0.20";
    private static final String UA_BROWSER = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    private static final int REQ_FILE = 11;
    private static final int REQ_SAVE = 12;
    private static final int REQ_VOICE = 13;
    private static final int REQ_OVPN = 14;
    private String pendingName = "";
    private String pendingText = "";

    private NativePlayer np;
    private CastHelper cast;
    private FrameLayout root;
    private android.media.tv.TvView tvv;
    private long tvvCur;
    private WebView web;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private ValueCallback<Uri[]> fileCb;
    private volatile String ctxRef = "";
    private volatile String pendingOpenId = "";
    private volatile long lastInteraction = System.currentTimeMillis();
    private boolean dimmed = false;

    @Override
    public void onUserInteraction() {
        super.onUserInteraction();
        lastInteraction = System.currentTimeMillis();
        if (dimmed) setDim(false);
    }

    private void setDim(boolean on) {
        dimmed = on;
        WindowManager.LayoutParams lp = getWindow().getAttributes();
        lp.screenBrightness = on ? WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_OFF : WindowManager.LayoutParams.BRIGHTNESS_OVERRIDE_NONE;
        getWindow().setAttributes(lp);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        setContentView(root);
        buildWeb();
        if (b != null) web.restoreState(b); else web.loadUrl("file:///android_asset/index.html");
        readOpenIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        String id = readOpenIntent(intent);
        if (id != null && !id.isEmpty()) { jsEvent("open", id); pendingOpenId = ""; }
    }

    /** Ligação vinda do "Continuar a ver" do ecrã inicial do Android TV: cockpittv://play?id=... */
    private String readOpenIntent(Intent intent) {
        try {
            Uri d = intent == null ? null : intent.getData();
            if (d != null && "cockpittv".equals(d.getScheme())) {
                String id = d.getQueryParameter("id");
                if (id != null) pendingOpenId = id;
                return id;
            }
        } catch (Exception ignored) { }
        return null;
    }

    /** Linha "Continuar a ver" no ecrã inicial do Android TV (Watch Next). */
    private void watchNext(String id, String name, String logo, long pos, long dur, boolean remove) {
        try {
            android.content.ContentResolver cr = getContentResolver();
            long existing = -1;
            android.database.Cursor c = cr.query(androidx.tvprovider.media.tv.TvContractCompat.WatchNextPrograms.CONTENT_URI,
                    androidx.tvprovider.media.tv.WatchNextProgram.PROJECTION, null, null, null);
            if (c != null) {
                try {
                    while (c.moveToNext()) {
                        androidx.tvprovider.media.tv.WatchNextProgram p = androidx.tvprovider.media.tv.WatchNextProgram.fromCursor(c);
                        if (id.equals(p.getInternalProviderId())) { existing = p.getId(); break; }
                    }
                } finally { c.close(); }
            }
            if (remove) {
                if (existing >= 0) cr.delete(androidx.tvprovider.media.tv.TvContractCompat.buildWatchNextProgramUri(existing), null, null);
                return;
            }
            androidx.tvprovider.media.tv.WatchNextProgram.Builder b = new androidx.tvprovider.media.tv.WatchNextProgram.Builder();
            b.setType(androidx.tvprovider.media.tv.TvContractCompat.WatchNextPrograms.TYPE_MOVIE);
            b.setWatchNextType(androidx.tvprovider.media.tv.TvContractCompat.WatchNextPrograms.WATCH_NEXT_TYPE_CONTINUE);
            b.setLastEngagementTimeUtcMillis(System.currentTimeMillis());
            b.setTitle(name);
            b.setInternalProviderId(id);
            b.setLastPlaybackPositionMillis((int) pos);
            b.setDurationMillis((int) dur);
            b.setIntentUri(Uri.parse("cockpittv://play?id=" + Uri.encode(id)));
            if (logo != null && logo.startsWith("http")) {
                b.setPosterArtUri(Uri.parse(logo));
                b.setPosterArtAspectRatio(androidx.tvprovider.media.tv.TvContractCompat.PreviewPrograms.ASPECT_RATIO_16_9);
            }
            android.content.ContentValues cv = b.build().toContentValues();
            if (existing >= 0) cr.update(androidx.tvprovider.media.tv.TvContractCompat.buildWatchNextProgramUri(existing), cv, null, null);
            else cr.insert(androidx.tvprovider.media.tv.TvContractCompat.WatchNextPrograms.CONTENT_URI, cv);
        } catch (Throwable ignored) { }
    }

    private void buildWeb() {
        web = new WebView(this);
        web.setBackgroundColor(0xFF000000);
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocus();
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setLoadWithOverviewMode(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());
        web.setDownloadListener((url, ua, cd, mime, len) ->
                Toast.makeText(this, "Descarregamentos diretos não são suportados.", Toast.LENGTH_SHORT).show());
    }

    /* ---------------- ponte JS <-> Android ---------------- */
    private class Bridge {
        /** Milissegundos desde o último toque ou tecla. */
        @JavascriptInterface
        public long idleMs() { return System.currentTimeMillis() - lastInteraction; }

        /** Ligado: o ecrã não adormece (a ver vídeo). Desligado: o Android pode apagar o ecrã. */
        @JavascriptInterface
        public void keepAwake(final boolean on) {
            runOnUiThread(() -> {
                if (on) getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                else getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            });
        }

        /** Escurece o ecrã ao mínimo até ao próximo toque ou tecla. */
        @JavascriptInterface
        public void dim(final boolean on) { runOnUiThread(() -> setDim(on)); }

        @JavascriptInterface
        public void ctx(String ref) {
            ctxRef = ref == null ? "" : ref.trim();
        }

        /** Abre o seletor do Android para o utilizador escolher a pasta e o nome do ficheiro. */
        @JavascriptInterface
        public boolean saveText(String name, String text) {
            pendingName = (name == null || name.isEmpty()) ? "cockpit-iptv-definicoes.json" : name;
            pendingText = text == null ? "" : text;
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/json");
                    i.putExtra(Intent.EXTRA_TITLE, pendingName);
                    startActivityForResult(i, REQ_SAVE);
                } catch (Exception e) {
                    // Sem seletor de ficheiros (comum em Android TV): guarda em Transferências
                    String where = saveFallback(pendingName, pendingText);
                    jsSaved(where != null, where == null ? "" : where);
                }
            });
            return true;
        }

        @JavascriptInterface
        public void showKeyboard() {
            runOnUiThread(() -> {
                web.requestFocus();
                android.view.inputmethod.InputMethodManager m = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (m != null) { m.restartInput(web); m.showSoftInput(web, android.view.inputmethod.InputMethodManager.SHOW_FORCED); }
            });
        }

        @JavascriptInterface
        public void hideKeyboard() {
            runOnUiThread(() -> {
                android.view.inputmethod.InputMethodManager m = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (m != null) m.hideSoftInputFromWindow(web.getWindowToken(), 0);
            });
        }

        /* ---- leitor nativo (Media3) ---- */
        @JavascriptInterface
        public void nplay(final String url, final String ref, final String hint, final String title, final long startMs) {
            runOnUiThread(() -> {
                try {
                    if (np == null) np = new NativePlayer(MainActivity.this, root, (k, m) -> playerEvent(k, m));
                    np.play(url, ref, hint, title, startMs);
                } catch (Throwable e) {
                    jsEvent("error", "init " + e);
                }
            });
        }

        @JavascriptInterface
        public void nrect(final int x, final int y, final int w, final int h, final boolean vis) {
            runOnUiThread(() -> { if (np != null) np.rect(x, y, w, h, vis); });
        }

        @JavascriptInterface
        public void nafr(final boolean on) {
            runOnUiThread(() -> { try { if (np == null) np = new NativePlayer(MainActivity.this, root, (k, m) -> playerEvent(k, m)); np.setAfr(on); } catch (Throwable e) { } });
        }

        /** Resolução real do ecrã (pixéis) e densidade, para a página ajustar tamanhos. */
        @JavascriptInterface
        public String screenInfo() {
            try {
                android.util.DisplayMetrics dm = new android.util.DisplayMetrics();
                getWindowManager().getDefaultDisplay().getRealMetrics(dm);
                android.util.DisplayMetrics rm = new android.util.DisplayMetrics();
                int rw = root != null ? root.getWidth() : 0, rh = root != null ? root.getHeight() : 0;
                org.json.JSONObject o = new org.json.JSONObject();
                o.put("w", rw > 0 ? rw : dm.widthPixels); o.put("h", rh > 0 ? rh : dm.heightPixels);
                o.put("rw", dm.widthPixels); o.put("rh", dm.heightPixels);
                o.put("dpr", dm.density); o.put("dpi", dm.densityDpi);
                return o.toString();
            } catch (Throwable e) { return "{}"; }
        }

        @JavascriptInterface
        public void naspect(final String mode, final String label) {
            runOnUiThread(() -> { try { if (np == null) np = new NativePlayer(MainActivity.this, root, (k, m) -> playerEvent(k, m)); np.setAspect(mode, label); } catch (Throwable e) { } });
        }

        @JavascriptInterface
        public void nfull(final boolean on) {
            runOnUiThread(() -> { try { if (np != null) np.setFull(on); } catch (Throwable e) { } });
        }

        @JavascriptInterface
        public void ndeint(final boolean on) {
            runOnUiThread(() -> { try { if (np == null) np = new NativePlayer(MainActivity.this, root, (k, m) -> playerEvent(k, m)); np.setDeint(on); } catch (Throwable e) { jsEvent("deint:error", String.valueOf(e)); } });
        }

        @JavascriptInterface
        public void nsubstyle(final int sizePct, final int fg, final int bg, final int edge, final float bottom) {
            runOnUiThread(() -> { try {
                NativePlayer.subSizePct = sizePct; NativePlayer.subFg = fg; NativePlayer.subBg = bg; NativePlayer.subEdge = edge; NativePlayer.subBottom = bottom;
                if (np != null) np.setSubStyle(sizePct, fg, bg, edge, bottom);
            } catch (Throwable e) { } });
        }

        @JavascriptInterface
        public void nscmd(final String cmd, final String payload) {
            runOnUiThread(() -> { try { if (nscr != null && nscr.isOpen()) nscr.command(cmd, payload); } catch (Throwable e) { } });
        }

        @JavascriptInterface
        public void nscreen(final String json, final int start) {
            runOnUiThread(() -> {
                try {
                    if (np == null) np = new NativePlayer(MainActivity.this, root, (k, m) -> playerEvent(k, m));
                    if (nscr != null && nscr.isOpen()) return;
                    nscr = new NativeScreen(MainActivity.this, root, np, (k, m) -> jsEvent(k, m));
                    nscr.open(json, start);
                } catch (Throwable e) { jsEvent("nscreen:error", String.valueOf(e)); }
            });
        }

        @JavascriptInterface
        public String ndbg() { return np == null ? "(leitor ainda não iniciado)" : np.dbgDump(); }

        @JavascriptInterface
        public void nlogjs(final String m) { if (np != null) np.log("JS " + m); }

        @JavascriptInterface
        public void nvol(final float v) {
            runOnUiThread(() -> { if (np != null) np.volume(v); });
        }

        @JavascriptInterface
        public void nstop() {
            runOnUiThread(() -> { if (np != null) np.stop(); });
        }

        @JavascriptInterface
        public void nsub(final String text, final String label, final String lang) {
            runOnUiThread(() -> { if (np != null) np.subtitle(text, label, lang); });
        }

        /** Pesquisa por voz: abre o reconhecimento de voz do sistema (Google) e devolve o texto à página. */
        @JavascriptInterface
        public void voice() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(android.speech.RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
                    i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE_MODEL, android.speech.RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
                    i.putExtra(android.speech.RecognizerIntent.EXTRA_LANGUAGE, "pt-PT");
                    i.putExtra(android.speech.RecognizerIntent.EXTRA_PROMPT, "Diz o canal, filme ou série");
                    i.putExtra(android.speech.RecognizerIntent.EXTRA_MAX_RESULTS, 1);
                    startActivityForResult(i, REQ_VOICE);
                } catch (Exception e) {
                    jsEvent("voice:error", "Esta TV não tem reconhecimento de voz instalado.");
                }
            });
        }

        @JavascriptInterface
        public void watchNext(final String id, final String name, final String logo, final double pos, final double dur, final boolean remove) {
            new Thread(() -> MainActivity.this.watchNext(id, name, logo, (long) pos, (long) dur, remove)).start();
        }

        /** Canais sintonizados pela própria TV (TV Input Framework). Devolve JSON; vazio se o sistema não deixar ler. */
        @JavascriptInterface
        public String tvChannels() {
            org.json.JSONArray arr = new org.json.JSONArray();
            android.database.Cursor cur = null;
            try {
                cur = getContentResolver().query(android.media.tv.TvContract.Channels.CONTENT_URI,
                        new String[]{android.media.tv.TvContract.Channels._ID,
                                android.media.tv.TvContract.Channels.COLUMN_DISPLAY_NUMBER,
                                android.media.tv.TvContract.Channels.COLUMN_DISPLAY_NAME,
                                android.media.tv.TvContract.Channels.COLUMN_INPUT_ID,
                                android.media.tv.TvContract.Channels.COLUMN_BROWSABLE},
                        null, null, null);
                if (cur != null) {
                    while (cur.moveToNext() && arr.length() < 2000) {
                        org.json.JSONObject o = new org.json.JSONObject();
                        o.put("id", cur.getLong(0));
                        o.put("num", cur.getString(1) == null ? "" : cur.getString(1));
                        o.put("name", cur.getString(2) == null ? "" : cur.getString(2));
                        o.put("input", cur.getString(3) == null ? "" : cur.getString(3));
                        arr.put(o);
                    }
                }
            } catch (Throwable e) {
                try { org.json.JSONObject o = new org.json.JSONObject(); o.put("error", String.valueOf(e)); return o.toString(); } catch (Throwable x) { }
            } finally {
                if (cur != null) try { cur.close(); } catch (Throwable x) { }
            }
            return arr.toString();
        }

        /** Diagnóstico: entradas de TV do sistema e apps que sabem abrir um canal. */
        @JavascriptInterface
        public String tvDiag() {
            org.json.JSONObject o = new org.json.JSONObject();
            try {
                org.json.JSONArray ins = new org.json.JSONArray();
                android.media.tv.TvInputManager tm = (android.media.tv.TvInputManager) getSystemService(TV_INPUT_SERVICE);
                if (tm != null) for (android.media.tv.TvInputInfo i : tm.getTvInputList()) {
                    ins.put(i.getId() + " | " + i.loadLabel(MainActivity.this) + (i.isPassthroughInput() ? " | externa" : " | sintonizador"));
                }
                o.put("inputs", ins);
                org.json.JSONArray hs = new org.json.JSONArray();
                Intent v = new Intent(Intent.ACTION_VIEW, android.media.tv.TvContract.buildChannelUri(1));
                for (android.content.pm.ResolveInfo r : getPackageManager().queryIntentActivities(v, 0)) hs.put(r.activityInfo.packageName + "/" + r.activityInfo.name);
                o.put("handlers", hs);
                o.put("sdk", Build.VERSION.SDK_INT);
            } catch (Throwable e) {
                try { o.put("error", String.valueOf(e)); } catch (Throwable x) { }
            }
            return o.toString();
        }

        /** Sintoniza um canal: tenta, por ordem, a app de TV que sabe abrir canais, o sistema e a app de TV do fabricante. Devolve o que funcionou. */
        @JavascriptInterface
        public String tvTune(final long id) {
            final Uri cu = android.media.tv.TvContract.buildChannelUri(id);
            java.util.List<Intent> tries = new java.util.ArrayList<>();
            try {
                for (android.content.pm.ResolveInfo r : getPackageManager().queryIntentActivities(new Intent(Intent.ACTION_VIEW, cu), 0)) {
                    tries.add(new Intent(Intent.ACTION_VIEW, cu).setClassName(r.activityInfo.packageName, r.activityInfo.name));
                }
            } catch (Throwable ignored) { }
            tries.add(new Intent(Intent.ACTION_VIEW, cu));
            tries.add(new Intent("com.sony.dtv.tvx.action.VIEW", cu).setPackage("com.sony.dtv.tvx"));
            for (Intent i : tries) {
                try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); return "ok:" + (i.getComponent() != null ? i.getComponent().flattenToShortString() : String.valueOf(i.getAction())); }
                catch (Throwable ignored) { }
            }
            /* último recurso: abre a app de TV do fabricante (Sony, TCL, Philips...) para escolheres lá o canal */
            return tvOpenLiveInternal() ? "app" : "falhou";
        }

        private boolean tvOpenLiveInternal() {
            String[] pk = {"com.sony.dtv.tvx", "com.google.android.tv", "com.android.tv", "org.droidtv.playtv", "com.tcl.tv", "com.mediatek.wwtv.tvcenter"};
            for (String p : pk) {
                try { Intent i = getPackageManager().getLaunchIntentForPackage(p); if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(i); return true; } } catch (Throwable ignored) { }
            }
            try { startActivity(new Intent(Intent.ACTION_VIEW, android.media.tv.TvContract.Channels.CONTENT_URI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true; } catch (Throwable ignored) { }
            return false;
        }

        /** Experiência: mostra um canal de TV dentro da app (TvView) numa janela no canto. Resultado por jsEvent "tvv:*". */
        @JavascriptInterface
        public void tvvTune(final String inputId, final long channelId) {
            runOnUiThread(() -> {
                try {
                    if (tvv == null) {
                        tvv = new android.media.tv.TvView(MainActivity.this);
                        tvv.setZOrderOnTop(true);
                        tvv.setCallback(new android.media.tv.TvView.TvInputCallback() {
                            @Override public void onVideoAvailable(String id) { jsEvent("tvv:video", String.valueOf(tvvCur)); }
                            @Override public void onVideoUnavailable(String id, int reason) { jsEvent("tvv:unavail", tvvCur + "|" + reason); }
                            @Override public void onConnectionFailed(String id) { jsEvent("tvv:connfail", id); }
                            @Override public void onDisconnected(String id) { jsEvent("tvv:disc", id); }
                        });
                        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(640, 360, android.view.Gravity.BOTTOM | android.view.Gravity.END);
                        lp.setMargins(0, 0, 40, 40);
                        root.addView(tvv, lp);
                    }
                    tvv.setVisibility(android.view.View.VISIBLE);
                    tvvCur = channelId;
                    tvv.tune(inputId, android.content.ContentUris.withAppendedId(android.media.tv.TvContract.Channels.CONTENT_URI, channelId));
                } catch (Throwable t) { jsEvent("tvv:error", String.valueOf(t)); }
            });
        }

        @JavascriptInterface
        public void tvvStop() {
            runOnUiThread(() -> { try { if (tvv != null) { tvv.reset(); tvv.setVisibility(android.view.View.GONE); } } catch (Throwable ignored) { } });
        }

        /** Caixa de texto nativa (o teclado do Android TV funciona melhor aqui do que dentro da página). O resultado volta por window.__askCb(texto|null). */
        @JavascriptInterface
        public void askText(final String title, final String initial, final boolean secret) {
            runOnUiThread(() -> {
                final android.widget.EditText et = new android.widget.EditText(MainActivity.this);
                et.setSingleLine(true);
                et.setText(initial == null ? "" : initial);
                et.setSelection(et.getText().length());
                if (secret) et.setInputType(android.text.InputType.TYPE_CLASS_TEXT | android.text.InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                final android.app.AlertDialog d = new android.app.AlertDialog.Builder(MainActivity.this)
                        .setTitle(title).setView(et)
                        .setPositiveButton("OK", (dlg, w) -> web.evaluateJavascript("window.__askCb&&window.__askCb(" + org.json.JSONObject.quote(et.getText().toString()) + ")", null))
                        .setNegativeButton("Cancelar", (dlg, w) -> web.evaluateJavascript("window.__askCb&&window.__askCb(null)", null))
                        .create();
                d.setOnCancelListener(x -> web.evaluateJavascript("window.__askCb&&window.__askCb(null)", null));
                if (d.getWindow() != null) d.getWindow().setSoftInputMode(android.view.WindowManager.LayoutParams.SOFT_INPUT_STATE_VISIBLE);
                d.show();
                et.requestFocus();
            });
        }

        /** Endereço IP local da TV (Wi-Fi ou cabo), para a API de rede da Sony. */
        @JavascriptInterface
        public String lanIp() {
            try {
                for (java.util.Enumeration<java.net.NetworkInterface> en = java.net.NetworkInterface.getNetworkInterfaces(); en.hasMoreElements(); ) {
                    java.net.NetworkInterface ni = en.nextElement();
                    if (!ni.isUp() || ni.isLoopback()) continue;
                    for (java.util.Enumeration<java.net.InetAddress> ad = ni.getInetAddresses(); ad.hasMoreElements(); ) {
                        java.net.InetAddress a = ad.nextElement();
                        if (a instanceof java.net.Inet4Address && !a.isLoopbackAddress()) return a.getHostAddress();
                    }
                }
            } catch (Throwable ignored) { }
            return "";
        }

        /** Chamada JSON-RPC à API Bravia da Sony (IP Control). Bloqueante: o JS chama-a a partir de uma thread do WebView. */
        @JavascriptInterface
        public String bravia(String ip, String psk, String service, String body) {
            java.net.HttpURLConnection c = null;
            try {
                java.net.URL u = new java.net.URL("http://" + ip + "/sony/" + service);
                c = (java.net.HttpURLConnection) u.openConnection();
                c.setConnectTimeout(4000); c.setReadTimeout(8000);
                c.setRequestMethod("POST"); c.setDoOutput(true);
                c.setRequestProperty("Content-Type", "application/json");
                if (psk != null && psk.length() > 0) c.setRequestProperty("X-Auth-PSK", psk);
                byte[] b = body.getBytes("UTF-8");
                c.getOutputStream().write(b);
                int code = c.getResponseCode();
                java.io.InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
                java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
                if (in != null) { byte[] buf = new byte[8192]; int n; while ((n = in.read(buf)) > 0) o.write(buf, 0, n); }
                String r = o.toString("UTF-8");
                if (code >= 400) return "{\"httpError\":" + code + ",\"body\":" + org.json.JSONObject.quote(r) + "}";
                return r;
            } catch (Throwable t) {
                return "{\"httpError\":0,\"body\":" + org.json.JSONObject.quote(String.valueOf(t)) + "}";
            } finally { if (c != null) c.disconnect(); }
        }

        /** Sobreposição (painel do Cockpit por cima da TV da Sony): tem permissão? */
        @JavascriptInterface
        public boolean overlayAllowed() {
            return Build.VERSION.SDK_INT < 23 || android.provider.Settings.canDrawOverlays(MainActivity.this);
        }

        /* ===== OpenVPN: usa a app oficial «OpenVPN para Android» (de.blinkt.openvpn) ===== */
        @JavascriptInterface
        public boolean vpnInstalled() {
            try { getPackageManager().getPackageInfo("de.blinkt.openvpn", 0); return true; } catch (Throwable t) { return false; }
        }

        @JavascriptInterface
        public void vpnInstall() {
            runOnUiThread(() -> {
                try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("market://details?id=de.blinkt.openvpn")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); }
                catch (Throwable t) {
                    try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://f-droid.org/packages/de.blinkt.openvpn/")).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); } catch (Throwable ignored) { }
                }
            });
        }

        @JavascriptInterface
        public void vpnOpenApp() {
            runOnUiThread(() -> { try { Intent i = getPackageManager().getLaunchIntentForPackage("de.blinkt.openvpn"); if (i != null) startActivity(i); else jsEvent("vpn:error", "A app OpenVPN não está instalada."); } catch (Throwable t) { jsEvent("vpn:error", String.valueOf(t)); } });
        }

        /** Escolhe um ficheiro .ovpn e entrega-o à app OpenVPN para o importar. */
        @JavascriptInterface
        public void vpnImport() {
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_OPEN_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    startActivityForResult(i, REQ_OVPN);
                } catch (Throwable t) { jsEvent("vpn:error", "Não consegui abrir o seletor de ficheiros: " + t); }
            });
        }

        @JavascriptInterface
        public boolean vpnConnect(final String profile) {
            try {
                Intent i = new Intent(Intent.ACTION_MAIN);
                i.setClassName("de.blinkt.openvpn", "de.blinkt.openvpn.LaunchVPN");
                i.putExtra("de.blinkt.openvpn.shortcutProfileName", profile == null ? "" : profile);
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                return true;
            } catch (Throwable t) { jsEvent("vpn:error", "Não consegui ligar a VPN: " + t); return false; }
        }

        @JavascriptInterface
        public boolean vpnDisconnect() {
            /* A app OpenVPN não deixa outras apps abrir o ecrã de desligar (activity não exportada, SecurityException).
               Por isso abre a própria app: lá tocas em «Desligar» (ou no ícone da VPN na barra de notificações). */
            try {
                Intent i = getPackageManager().getLaunchIntentForPackage("de.blinkt.openvpn");
                if (i == null) { jsEvent("vpn:error", "A app OpenVPN não está instalada."); return false; }
                i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
                jsEvent("vpn:error", "Abri a app OpenVPN: toca em «Desligar» para terminar a VPN (o Android não deixa a Cockpit TV fazê-lo por ti).");
                return true;
            } catch (Throwable t) { jsEvent("vpn:error", "Não consegui abrir a app OpenVPN: " + t); return false; }
        }

        /** Tenta abrir o ecrã do sistema para dar a permissão. false = a TV não tem esse ecrã (usar adb). */
        @JavascriptInterface
        public boolean overlayRequest() {
            try {
                startActivity(new Intent(android.provider.Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                        Uri.parse("package:" + getPackageName())).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                return true;
            } catch (Throwable t) { return false; }
        }

        /** Sintoniza o canal pela API Bravia e mostra o painel por cima. listJson = [{num,name,uri}] */
        @JavascriptInterface
        public boolean overlayStart(String ip, String psk, String listJson, String uri) {
            if (!overlayAllowed()) return false;
            try { TvOverlayService.start(MainActivity.this, ip, psk, listJson, uri); return true; }
            catch (Throwable t) { return false; }
        }

        @JavascriptInterface
        public void overlayStop() { try { TvOverlayService.stop(MainActivity.this); } catch (Throwable ignored) { } }

        /** Abre a app de TV em direto do sistema (sem canal específico). */
        @JavascriptInterface
        public boolean tvOpenLive() { return tvOpenLiveInternal(); }

        @JavascriptInterface
        public String pendingOpen() {
            String id = pendingOpenId;
            pendingOpenId = "";
            return id == null ? "" : id;
        }

        @JavascriptInterface
        public void nhud(final String text) {
            runOnUiThread(() -> { if (np != null) np.hud(text); });
        }

        @JavascriptInterface
        public void ntoggle() {
            runOnUiThread(() -> { if (np != null) np.toggle(); });
        }

        @JavascriptInterface
        public void nseek(final long ms) {
            runOnUiThread(() -> { if (np != null) np.seek(ms); });
        }

        @JavascriptInterface
        public void ntrack(final String type, final int idx) {
            runOnUiThread(() -> { if (np != null) np.pick(type, idx); });
        }

        @JavascriptInterface
        public String npos() {
            NativePlayer n = np;
            return n == null ? "0|0|1" : n.pos();
        }

        @JavascriptInterface
        public String ntracks() {
            NativePlayer n = np;
            return n == null ? "{\"audio\":[],\"text\":[]}" : n.tracks();
        }

        /** Telemóvel: abre o seletor de transmissão do Android (Miracast / Wi-Fi Direct, Google Cast) para espelhar o ecrã numa TV. */
        /* ---- Google Cast (envia o endereço do vídeo para a Google TV) ---- */
        /** Abre um endereço fora da app (ex.: trailer no YouTube). */
        @JavascriptInterface
        public void openUrl(final String url) {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Não há nenhuma app para abrir o trailer (instala o YouTube).", Toast.LENGTH_LONG).show();
                }
            });
        }

        /** Trailer dentro da app: janela própria com o leitor do YouTube (Voltar fecha). */
        @JavascriptInterface
        public void trailer(final String url) {
            runOnUiThread(() -> showTrailer(url));
        }

        @JavascriptInterface
        public void cpick() {
            runOnUiThread(() -> {
                try {
                    if (cast == null) cast = new CastHelper(MainActivity.this, (k, m) -> jsEvent("cast:" + k, m));
                    cast.pick();
                } catch (Throwable e) {
                    jsEvent("cast:unavailable", String.valueOf(e));
                }
            });
        }

        @JavascriptInterface
        public void cload(final String url, final String title, final String mime, final boolean live, final long startMs) {
            runOnUiThread(() -> { if (cast != null) cast.load(url, title, mime, live, startMs); });
        }

        @JavascriptInterface
        public void ctoggle() {
            runOnUiThread(() -> { if (cast != null) cast.toggle(); });
        }

        @JavascriptInterface
        public void cmstop() {
            runOnUiThread(() -> { if (cast != null) cast.stopMedia(); });
        }

        @JavascriptInterface
        public void cstop() {
            runOnUiThread(() -> { if (cast != null) cast.stop(); });
        }

        @JavascriptInterface
        public boolean castScreen() {
            final boolean[] ok = {false};
            runOnUiThread(() -> {
                String[] acts = {"android.settings.CAST_SETTINGS", "com.samsung.android.smartmirroring.SETTINGS", android.provider.Settings.ACTION_WIFI_SETTINGS};
                for (String a : acts) {
                    try {
                        startActivity(new Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        ok[0] = true;
                        return;
                    } catch (Exception ignored) { }
                }
                Toast.makeText(MainActivity.this, "Abre o painel rápido do Android e toca em Transmitir / Smart View / Espelhar ecrã.", Toast.LENGTH_LONG).show();
            });
            return true;
        }

        @JavascriptInterface
        public void exitApp() {
            runOnUiThread(() -> finish());
        }

        @JavascriptInterface
        public boolean isTv() {
            android.app.UiModeManager um = (android.app.UiModeManager) getSystemService(UI_MODE_SERVICE);
            return um != null && um.getCurrentModeType() == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION;
        }

        @JavascriptInterface
        public void toast(String msg) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }
    }

    private void showTrailer(String url) {
        try {
            final android.app.Dialog d = new android.app.Dialog(this, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
            FrameLayout box = new FrameLayout(this);
            box.setBackgroundColor(0xFF000000);
            final WebView w = new WebView(this);
            WebSettings s = w.getSettings();
            s.setJavaScriptEnabled(true);
            s.setDomStorageEnabled(true);
            s.setMediaPlaybackRequiresUserGesture(false);
            w.setWebViewClient(new WebViewClient());
            w.setWebChromeClient(new WebChromeClient());
            w.setFocusable(true);
            w.setFocusableInTouchMode(true);
            box.addView(w, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            android.widget.TextView hint = new android.widget.TextView(this);
            hint.setText("Voltar para fechar o trailer");
            hint.setTextColor(0xFFFFFFFF);
            hint.setBackgroundColor(0x99000000);
            hint.setPadding(24, 10, 24, 10);
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            lp.gravity = android.view.Gravity.BOTTOM | android.view.Gravity.RIGHT;
            box.addView(hint, lp);
            d.setContentView(box);
            d.setOnDismissListener(x -> { try { w.loadUrl("about:blank"); w.destroy(); } catch (Exception ignored) { } });
            final Map<String, String> h = new HashMap<>();
            h.put("Referer", "https://www.youtube.com/");
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("/embed/([\\w-]{11})").matcher(url);
            if (m.find()) {
                /* Leitor do YouTube com origem própria (evita o erro 153) e, se o vídeo não deixar incorporar (erro 101/150/152),
                   abre a página normal do vídeo em vez de ficar na mensagem de erro. */
                final String vid = m.group(1);
                w.addJavascriptInterface(new Object() {
                    @JavascriptInterface
                    public void fail(String code) {
                        runOnUiThread(() -> { try { w.loadUrl("https://m.youtube.com/watch?v=" + vid, h); } catch (Exception ignored) { } });
                    }
                }, "T");
                String html = "<!doctype html><html><head><meta name=viewport content='width=device-width,initial-scale=1'><style>html,body{margin:0;height:100%;background:#000}</style></head><body><div id=p></div>"
                        + "<script src='https://www.youtube.com/iframe_api'></script><script>var ok=false;"
                        + "function onYouTubeIframeAPIReady(){new YT.Player('p',{width:'100%',height:'100%',videoId:'" + vid + "',playerVars:{autoplay:1,rel:0,playsinline:1,modestbranding:1,origin:'https://www.youtube.com'},"
                        + "events:{onReady:function(e){e.target.playVideo()},onStateChange:function(e){ok=true},onError:function(e){T.fail(String(e.data))}}})}"
                        + "setTimeout(function(){if(!ok)T.fail('timeout')},12000);</script></body></html>";
                w.loadDataWithBaseURL("https://www.youtube.com/", html, "text/html", "utf-8", null);
            } else {
                w.setWebViewClient(new WebViewClient() {
                    int tries = 0;
                    @Override
                    public void onPageFinished(WebView v, String u) {
                        /* página de resultados: toca no primeiro vídeo (se falhar, escolhes tu) */
                        if (u == null || !u.contains("/results")) return;
                        final String js = "(function(){var n=0,t=setInterval(function(){var a=document.querySelector('a[href^=\"/watch\"]');if(a){clearInterval(t);a.click()}else if(++n>16)clearInterval(t)},500)})()";
                        v.evaluateJavascript(js, null);
                    }
                });
                w.loadUrl(url, h);
            }
            d.show();
            w.requestFocus();
        } catch (Exception e) {
            Toast.makeText(this, "Não consegui abrir o trailer.", Toast.LENGTH_SHORT).show();
        }
    }

    /* ---------------- ecrã nativo (Fase 1, opcional) ---------------- */
    private NativeScreen nscr;

    private void playerEvent(String k, String m) {
        NativeScreen s = nscr;
        if (s != null && s.isOpen() && s.onPlayerEvent(k, m)) return;
        jsEvent(k, m);
    }

    private void jsEvent(String kind, String msg) {
        final String js = "window.__nev&&window.__nev(" + org.json.JSONObject.quote(kind) + "," + org.json.JSONObject.quote(msg == null ? "" : msg) + ")";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        if (nscr != null && nscr.isOpen()) nscr.onConfigChanged();
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (np != null) np.resumeAfterBackground();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (np != null) np.pause();
    }

    /* ---------------- "proxy" local ---------------- */
    private class Client extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            try {
                Uri u = req.getUrl();
                String scheme = u.getScheme();
                if (scheme == null || !(scheme.equals("http") || scheme.equals("https"))) return null;
                String host = u.getHost() == null ? "" : u.getHost();
                if (host.endsWith("cdnjs.cloudflare.com") || host.endsWith("opensubtitles.com")
                        || host.endsWith("googleapis.com") || host.endsWith("gstatic.com")) return null;
                String method = req.getMethod();
                Map<String, String> rh = req.getRequestHeaders();
                if ("OPTIONS".equalsIgnoreCase(method)) {
                    Map<String, String> h = new HashMap<>();
                    h.put("Access-Control-Allow-Origin", "*");
                    h.put("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
                    String ah = rh == null ? null : rh.get("Access-Control-Request-Headers");
                    h.put("Access-Control-Allow-Headers", ah == null ? "*" : ah);
                    h.put("Access-Control-Max-Age", "86400");
                    return new WebResourceResponse("text/plain", "utf-8", 200, "OK", h, new ByteArrayInputStream(new byte[0]));
                }
                if (!"GET".equalsIgnoreCase(method)) return null;
                String full = u.toString();
                // Vídeo (segmentos .ts/.m3u8/mp4) passa direto pelo WebView; só interceptamos
                // listas/APIs/EPG (para usar o User-Agent do VLC) e os canais que precisam de Referer.
                boolean api = full.matches("(?i).*(player_api\\.php|/get\\.php|panel_api|xmltv|\\.xml(\\.gz)?|\\.m3u(\\?.*)?$|\\.json).*");
                if (!api && ctxRef.isEmpty()) return null;
                return fetch(full, rh);
            } catch (Exception e) {
                return null; // deixa o WebView tentar normalmente
            }
        }

        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            runOnUiThread(() -> {
                try { root.removeView(web); web.destroy(); } catch (Exception ignored) { }
                buildWeb();
                web.loadUrl("file:///android_asset/index.html");
            });
            return true;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            ctxRef = "";
        }
    }

    private WebResourceResponse fetch(String url, Map<String, String> rh) {
        try {
            String cur = url;
            HttpURLConnection c = null;
            for (int i = 0; i < 8; i++) {
                c = (HttpURLConnection) new URL(cur).openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                c.setRequestMethod("GET");
                // canais abertos (com Referer) devolvem 204 vazio ao VLC: precisam de um User-Agent de browser
                c.setRequestProperty("User-Agent", ctxRef.isEmpty() ? UA : UA_BROWSER);
                c.setRequestProperty("Accept", "*/*");
                if (rh != null) {
                    String range = rh.get("Range");
                    if (range != null) c.setRequestProperty("Range", range);
                    String auth = rh.get("Authorization");
                    if (auth != null) c.setRequestProperty("Authorization", auth);
                }
                String ref = ctxRef;
                if (!ref.isEmpty()) {
                    c.setRequestProperty("Referer", ref);
                    c.setRequestProperty("Origin", ref.replaceAll("^(https?://[^/]+).*$", "$1"));
                }
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) {
                    String loc = c.getHeaderField("Location");
                    c.disconnect();
                    if (loc == null) return null;
                    cur = new URL(new URL(cur), loc).toString();
                    continue;
                }
                break;
            }
            if (c == null) return null;
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) return null;
            String ct = c.getContentType();
            String mime = "application/octet-stream";
            String enc = null;
            if (ct != null) {
                String[] parts = ct.split(";");
                mime = parts[0].trim();
                for (String p : parts) {
                    p = p.trim();
                    if (p.toLowerCase().startsWith("charset=")) enc = p.substring(8).trim();
                }
            }
            Map<String, String> h = new HashMap<>();
            for (Map.Entry<String, List<String>> e : c.getHeaderFields().entrySet()) {
                String k = e.getKey();
                if (k == null || e.getValue() == null || e.getValue().isEmpty()) continue;
                String kl = k.toLowerCase();
                if (kl.equals("content-encoding") || kl.equals("content-length") || kl.equals("transfer-encoding")
                        || kl.equals("connection") || kl.startsWith("access-control-")) continue;
                h.put(k, e.getValue().get(0));
            }
            h.put("Access-Control-Allow-Origin", "*");
            h.put("Access-Control-Expose-Headers", "*");
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in == null) in = new ByteArrayInputStream(new byte[0]);
            String reason = c.getResponseMessage();
            if (reason == null || reason.isEmpty()) reason = code == 206 ? "Partial Content" : (code >= 400 ? "Error" : "OK");
            return new WebResourceResponse(mime, enc, code, reason, h, in);
        } catch (Exception e) {
            return null;
        }
    }

    /* ---------------- janela do WebView (ficheiros, ecrã inteiro) ---------------- */
    private class Chrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            try {
                startActivityForResult(params.createIntent(), REQ_FILE);
            } catch (Exception e) {
                fileCb = null;
                return false;
            }
            return true;
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) { cb.onCustomViewHidden(); return; }
            customView = view;
            customCb = cb;
            web.setVisibility(View.GONE);
            root.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            immersive();
        }

        @Override
        public void onHideCustomView() {
            hideCustom();
        }
    }

    private void hideCustom() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        web.setVisibility(View.VISIBLE);
        if (customCb != null) { customCb.onCustomViewHidden(); customCb = null; }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
            return;
        }
        if (req == REQ_OVPN) {
            if (res != RESULT_OK || data == null || data.getData() == null) return;
            try {
                Intent i = new Intent(Intent.ACTION_VIEW);
                i.setDataAndType(data.getData(), "application/x-openvpn-profile");
                i.setPackage("de.blinkt.openvpn");
                i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                startActivity(i);
            } catch (Throwable t) { jsEvent("vpn:error", "Não consegui entregar o perfil à app OpenVPN (está instalada?): " + t); }
            return;
        }
        if (req == REQ_VOICE) {
            try {
                java.util.ArrayList<String> r = data == null ? null : data.getStringArrayListExtra(android.speech.RecognizerIntent.EXTRA_RESULTS);
                if (res == RESULT_OK && r != null && !r.isEmpty()) jsEvent("voice", r.get(0));
            } catch (Exception ignored) { }
            return;
        }
        if (req == REQ_SAVE) {
            if (res != RESULT_OK || data == null || data.getData() == null) { jsSaved(false, ""); return; }
            try (OutputStream os = getContentResolver().openOutputStream(data.getData(), "wt")) {
                if (os == null) throw new IOException("sem saída");
                os.write(pendingText.getBytes(StandardCharsets.UTF_8));
                jsSaved(true, data.getData().getLastPathSegment() == null ? pendingName : data.getData().getLastPathSegment());
            } catch (Exception e) {
                jsSaved(false, "");
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    private void jsSaved(boolean ok, String where) {
        String w = where.replace("\\", "\\\\").replace("'", "\\'");
        web.evaluateJavascript("window.androidSaved&&androidSaved(" + ok + ",'" + w + "')", null);
    }

    private String saveFallback(String name, String text) {
        try {
            byte[] data = text.getBytes(StandardCharsets.UTF_8);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (u == null) return null;
                try (OutputStream os = getContentResolver().openOutputStream(u)) {
                    if (os == null) return null;
                    os.write(data);
                }
                return "Transferências/" + name;
            }
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (dir == null || (!dir.exists() && !dir.mkdirs())) dir = getExternalFilesDir(null);
            if (dir == null) return null;
            File f = new File(dir, name);
            try (FileOutputStream os = new FileOutputStream(f)) {
                os.write(data);
            }
            return f.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }

    /* ---------------- botão Voltar e ecrã inteiro ---------------- */
    @Override
    public void onBackPressed() {
        if (customView != null) { hideCustom(); return; }
        if (nscr != null && nscr.isOpen()) { nscr.onBack(); return; }
        web.evaluateJavascript("(function(){try{return window.androidBack()?1:0}catch(e){return 0}})()", v -> {
            if (!"1".equals(v)) finish();
        });
    }

    @Override
    public boolean onKeyDown(int code, KeyEvent ev) {
        if (code == KeyEvent.KEYCODE_ESCAPE) { onBackPressed(); return true; }
        if (nscr != null && nscr.isOpen() && nscr.onKey(ev)) return true;
        return super.onKeyDown(code, ev);
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) immersive();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    protected void onDestroy() {
        if (np != null) { np.release(); np = null; }
        if (cast != null) { cast.release(); cast = null; }
        if (web != null) { root.removeAllViews(); web.destroy(); }
        super.onDestroy();
    }
}
