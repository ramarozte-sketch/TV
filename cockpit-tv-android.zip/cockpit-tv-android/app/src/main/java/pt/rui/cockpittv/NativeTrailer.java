package pt.rui.cockpittv;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Color;
import android.view.Gravity;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.TextView;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** v310: trailer dentro da app. Procura no YouTube o trailer mais recente do título e toca-o numa janela própria (Voltar fecha). */
final class NativeTrailer {
    private NativeTrailer() { }

    static void open(final Activity a, final String rawTitle, final String year, final boolean series, final String providerId) {
        final android.os.Handler ui = new android.os.Handler(android.os.Looper.getMainLooper());
        final Dialog d = new Dialog(a, android.R.style.Theme_Black_NoTitleBar_Fullscreen);
        FrameLayout box = new FrameLayout(a);
        box.setBackgroundColor(Color.BLACK);
        final WebView w = new WebView(a);
        WebSettings s = w.getSettings();
        s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setMediaPlaybackRequiresUserGesture(false);
        try { s.setUserAgentString("Mozilla/5.0 (Linux; Android 12; BRAVIA 4K VH2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Mobile Safari/537.36"); } catch (Throwable ignored) { }
        w.setWebViewClient(new WebViewClient());
        w.setWebChromeClient(new WebChromeClient());
        w.setBackgroundColor(Color.BLACK);
        w.setFocusable(true); w.setFocusableInTouchMode(true);
        box.addView(w, new FrameLayout.LayoutParams(-1, -1));
        final TextView msg = new TextView(a);
        final String titleClean = clean(rawTitle);
        msg.setText("🎬 A procurar o trailer de «" + titleClean + "»…");
        msg.setTextColor(Color.WHITE); msg.setTextSize(22); msg.setGravity(Gravity.CENTER);
        box.addView(msg, new FrameLayout.LayoutParams(-1, -1));
        TextView hint = new TextView(a);
        hint.setText("Voltar para fechar o trailer"); hint.setTextColor(Color.WHITE); hint.setBackgroundColor(0x99000000); hint.setPadding(24, 10, 24, 10);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.BOTTOM | Gravity.RIGHT; box.addView(hint, lp);
        d.setContentView(box);
        d.setOnDismissListener(x -> { try { w.loadUrl("about:blank"); w.destroy(); } catch (Throwable ignored) { } });
        d.show();
        w.requestFocus();
        /* v344: se o YouTube embutido falhar, abrir a app YouTube / browser em vez de ecrã preto eterno. */
        final Runnable openExternal = () -> {
            try {
                String q = titleClean + (year != null && year.length() >= 4 ? " " + year : "") + " trailer";
                String first = providerId != null && providerId.length() == 11 ? providerId : null;
                android.content.Intent it;
                if (first != null) {
                    try {
                        it = new android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("vnd.youtube:" + first));
                        a.startActivity(it); d.dismiss(); return;
                    } catch (Throwable ignored) { }
                    it = new android.content.Intent(android.content.Intent.ACTION_VIEW, android.net.Uri.parse("https://www.youtube.com/watch?v=" + first));
                } else {
                    it = new android.content.Intent(android.content.Intent.ACTION_VIEW,
                            android.net.Uri.parse("https://www.youtube.com/results?search_query=" + URLEncoder.encode(q, "UTF-8")));
                }
                a.startActivity(it);
                d.dismiss();
            } catch (Throwable e) {
                try { msg.setText("Não foi possível abrir o trailer. Instala o YouTube ou tenta noutro aparelho."); } catch (Throwable ignored) { }
            }
        };
        Thread t = new Thread(() -> {
            List<String> found = new ArrayList<>();
            /* ID do fornecedor (TMDB/Xtream) primeiro — evita pesquisa falhada em títulos CAM. */
            if (providerId != null && providerId.matches("[\\w-]{11}")) found.add(providerId);
            try {
                List<String> more = findAll(rawTitle, year, series);
                for (String id : more) if (!found.contains(id)) found.add(id);
            } catch (Throwable ignored) { }
            final List<String> vids = found;
            ui.post(() -> {
                try {
                    if (!d.isShowing()) return;
                    if (vids.isEmpty()) {
                        /* v355: sem candidatos — não abre a pesquisa do YouTube (pede login); aviso dentro da app. */
                        msg.setText("🎬 Não encontrei trailer para «" + titleClean + "».");
                        msg.setVisibility(android.view.View.VISIBLE);
                        return;
                    }
                    msg.setText("🎬 A carregar o trailer de «" + titleClean + "»…");
                    play(w, ui, vids, 0, msg, openExternal, d);
                } catch (Throwable ignored) { }
            });
        }, "trailer-find");
        t.setDaemon(true); t.start();
    }

    /** Tenta cada candidato no leitor incorporado; se o vídeo não permitir (erro 100/101/150/153) passa ao seguinte; no fim app YouTube. */
    private static void play(final WebView w, final android.os.Handler ui, final List<String> vids, final int idx, final TextView msg, final Runnable openExternal, final Dialog d) {
        final String vid = vids.get(idx);
        final boolean[] done = {false};
        try { w.removeJavascriptInterface("T"); } catch (Throwable ignored) { }
        w.setWebViewClient(new WebViewClient());
        w.addJavascriptInterface(new Object() {
            @JavascriptInterface public void ok() { ui.post(() -> { done[0] = true; msg.setVisibility(android.view.View.GONE); }); }
            @JavascriptInterface public void fail(String code) {
                ui.post(() -> {
                    if (done[0]) return; done[0] = true;
                    try {
                        if (idx + 1 < vids.size() && idx < 4) { play(w, ui, vids, idx + 1, msg, openExternal, d); return; }
                        /* v344: na TV o embed costuma falhar (153); tenta página mobile e, se ainda falhar, app externa. */
                        watchPage(w, msg, vids.get(0), () -> {
                            if (d != null && d.isShowing()) openExternal.run();
                        }, ui);
                    } catch (Throwable e) {
                        try { openExternal.run(); } catch (Throwable ignored) { }
                    }
                });
            }
        }, "T");
        String html = "<!doctype html><html><head><meta name=viewport content='width=device-width,initial-scale=1'><style>html,body{margin:0;height:100%;background:#000}#p{position:absolute;inset:0}</style></head><body><div id=p></div>"
                + "<script src='https://www.youtube.com/iframe_api'></script><script>var ok=false;"
                + "function onYouTubeIframeAPIReady(){new YT.Player('p',{width:'100%',height:'100%',videoId:'" + vid + "',playerVars:{autoplay:1,rel:0,playsinline:1,modestbranding:1,hl:'pt',cc_lang_pref:'pt',origin:'https://www.youtube.com'},"
                + "events:{onReady:function(e){try{e.target.mute();e.target.playVideo();setTimeout(function(){try{e.target.unMute()}catch(x){}},800)}catch(x){}},onStateChange:function(e){if(e.data==1||e.data==3){ok=true;T.ok()}},onError:function(e){T.fail(String(e.data))}}})}"
                + "setTimeout(function(){if(!ok)T.fail('timeout')},7000);</script></body></html>";
        w.loadDataWithBaseURL("https://www.youtube.com/", html, "text/html", "utf-8", null);
    }

    /** Página mobile do YouTube; se em 8 s não houver playback, chama onFail (app externa). */
    private static void watchPage(final WebView w, final TextView msg, final String vid, final Runnable onFail, final android.os.Handler ui) {
        Map<String, String> h = new HashMap<>(); h.put("Referer", "https://www.youtube.com/");
        final boolean[] ok = {false};
        msg.setText("🎬 A abrir no YouTube…");
        w.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView v, String u) {
                v.evaluateJavascript("(function(){var n=0,g=0,t=setInterval(function(){var x=document.querySelector('video');if(x){if(x.paused){try{x.play()}catch(e){}}var u=document.querySelector('.ytp-unmute,.ytp-unmute-inner,button[aria-label*=\"Ativar o som\"],button[aria-label*=\"Unmute\"],button[aria-label*=\"Reativar\"]');if(u&&u.offsetParent!==null){u.click()}x.muted=false;x.volume=1;if(!x.paused&&x.currentTime>0.3){if(++g>2){clearInterval(t);try{T.ok()}catch(e){}}}else g=0}var b=document.querySelector('.ytp-large-play-button,.ytm-large-play-button');if(b&&x&&x.paused)b.click();if(++n>50)clearInterval(t)},500)})()", null);
            }
        });
        try {
            w.addJavascriptInterface(new Object() {
                @JavascriptInterface public void ok() { ui.post(() -> { ok[0] = true; msg.setVisibility(android.view.View.GONE); }); }
            }, "T");
        } catch (Throwable ignored) { }
        /* v355: embed sem cookies (sem login) em vez da página de watch */
        w.loadUrl("https://www.youtube-nocookie.com/embed/" + vid + "?autoplay=1&playsinline=1&rel=0&modestbranding=1&hl=pt&cc_lang_pref=pt", h);
        if (onFail != null) ui.postDelayed(() -> { if (!ok[0] && onFail != null) onFail.run(); }, 8000);
    }

    /** Nome da lista IPTV sem prefixos de país, qualidade, ano e parênteses. */
    static String clean(String n) {
        String s = n == null ? "" : n;
        s = s.replaceAll("^\\s*[A-Za-z]{2,3}\\s*[|:]\\s*", "");
        /* v348: prefixo de país da lista («EN - », «PT - », «|BR| »…) não entra na pesquisa do trailer */
        s = s.replaceAll("(?i)^\\s*[\\[(|]?\\s*(PT|BR|EN|US|UK|GB|FR|ES|DE|IT|NL|BE|AL|TR|AR|MX|PL|RO|CA|AU|IN|GR|SE|NO|DK|FI|CH|AT|RU|UA|BG|HR|RS|CZ|HU|IE|IL|JP|KR|CN|ZA|LAT|MULTI|VOST)\\s*[\\])|]?\\s*[-–—|:]\\s*", "");
        s = s.replaceAll("[\\[(][^\\])]*[\\])]", " ");
        /* v344: remover marcas de rip/CAM e ano solto no fim (ex.: «Wildwood - 2026 CAM»). */
        s = s.replaceAll("(?i)\\b(fhd|uhd|4k|hd|sd|1080p|720p|dublado|legendado|vostpt|pt-pt|multi|dual|cam|hdcam|telesync|ts|tc|screener|web-?dl|webrip|bluray|bdrip|hdtv|dvdrip)\\b", " ");
        s = s.replaceAll("\\s*[-–|]\\s*\\d{4}\\s*$", " ");
        s = s.replaceAll("\\s+[-–|]\\s*$", "").replaceAll("\\s+", " ").trim();
        return s.isEmpty() ? (n == null ? "" : n.trim()) : s;
    }

    private static long ageDays(String t) {
        if (t == null) return 99999;
        Matcher m = Pattern.compile("(\\d+)\\s*(segundo|minuto|hora|dia|semana|m[eê]s|meses|ano|second|minute|hour|day|week|month|year)", Pattern.CASE_INSENSITIVE).matcher(t);
        if (!m.find()) return 99999;
        long n = Long.parseLong(m.group(1)); String u = m.group(2).toLowerCase();
        if (u.startsWith("seg") || u.startsWith("sec") || u.startsWith("min") || u.startsWith("hor") || u.startsWith("hou")) return 0;
        if (u.startsWith("dia") || u.startsWith("day")) return n;
        if (u.startsWith("sem") || u.startsWith("wee")) return n * 7;
        if (u.startsWith("m")) return n * 30;
        return n * 365;
    }
    private static int lenSec(String l) {
        if (l == null) return 0;
        String[] p = l.split(":"); int s = 0;
        for (String x : p) { try { s = s * 60 + Integer.parseInt(x.trim()); } catch (Throwable e) { return 0; } }
        return s;
    }
    private static String unesc(String s) {
        try { return String.valueOf(new org.json.JSONTokener("\"" + s + "\"").nextValue()); } catch (Throwable e) { return s; }
    }
    private static String get(String url) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(url).openConnection();
        c.setConnectTimeout(8000); c.setReadTimeout(12000);
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 12; BRAVIA 4K VH2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36");
        c.setRequestProperty("Accept-Language", "pt-PT,pt;q=0.9,en;q=0.5");
        c.setRequestProperty("Cookie", "CONSENT=YES+1; SOCS=CAI");
        try (InputStream in = c.getInputStream()) {
            java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream(); byte[] b = new byte[65536]; int n;
            while ((n = in.read(b)) > 0 && o.size() < 3_000_000) o.write(b, 0, n);
            return o.toString("UTF-8");
        } finally { c.disconnect(); }
    }

    /** Segunda via (a página HTML pode vir com o ecrã de consentimento): API interna de pesquisa do YouTube. */
    private static String innertube(String q) throws Exception {
        String body = "{\"context\":{\"client\":{\"clientName\":\"WEB\",\"clientVersion\":\"2.20240101.00.00\",\"hl\":\"pt-PT\",\"gl\":\"PT\"}},\"query\":" + org.json.JSONObject.quote(q) + ",\"params\":\"EgIQAQ==\"}";
        HttpURLConnection c = (HttpURLConnection) new URL("https://www.youtube.com/youtubei/v1/search?prettyPrint=false").openConnection();
        c.setConnectTimeout(8000); c.setReadTimeout(12000); c.setRequestMethod("POST"); c.setDoOutput(true);
        c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("Accept-Language", "pt-PT,pt;q=0.9");
        c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 12; BRAVIA 4K VH2) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Safari/537.36");
        c.getOutputStream().write(body.getBytes("UTF-8"));
        try (InputStream in = c.getInputStream()) {
            java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream(); byte[] b = new byte[65536]; int n;
            while ((n = in.read(b)) > 0 && o.size() < 3_000_000) o.write(b, 0, n);
            return o.toString("UTF-8");
        } finally { c.disconnect(); }
    }

    /** O trailer mais recente que corresponda ao título (ignora reações, críticas, resumos e vídeos longos). */
    static List<String> findAll(String raw, String year, boolean series) throws Exception {
        String title = clean(raw);
        String yr = year != null && year.matches("(19|20)\\d\\d.*") ? year.substring(0, 4) : "";
        String q = title + (series ? " série" : "") + " trailer oficial";
        String html = get("https://www.youtube.com/results?hl=pt-PT&gl=PT&sp=EgIQAQ%253D%253D&search_query=" + URLEncoder.encode(q, "UTF-8"));
        if (!Pattern.compile("\"videoRenderer\":\\{\"videoId\"").matcher(html).find()) {
            try { html = innertube(q); } catch (Throwable ignored) { }
        }
        Matcher m = Pattern.compile("\"videoRenderer\":\\{\"videoId\":\"([\\w-]{11})\"").matcher(html);
        List<int[]> pos = new ArrayList<>(); List<String> ids = new ArrayList<>();
        while (m.find()) { ids.add(m.group(1)); pos.add(new int[]{m.start()}); }
        String nt = NativeData.norm(title).replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
        String[] words = nt.split(" ");
        List<String> out = new ArrayList<>(); final Map<String, Long> ages = new HashMap<>(); java.util.HashSet<String> seen = new java.util.HashSet<>();
        for (int i = 0; i < ids.size() && i < 14; i++) {
            if (!seen.add(ids.get(i))) continue;
            int from = pos.get(i)[0], to = i + 1 < ids.size() ? pos.get(i + 1)[0] : Math.min(html.length(), from + 8000);
            String ch = html.substring(from, Math.min(to, from + 9000));
            Matcher tm = Pattern.compile("\"title\":\\{\"runs\":\\[\\{\"text\":\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(ch);
            if (!tm.find()) continue;
            String vt = unesc(tm.group(1));
            String nv = NativeData.norm(vt).replaceAll("[^a-z0-9 ]", " ").replaceAll("\\s+", " ").trim();
            if (!(nv.contains("trailer") || nv.contains("teaser") || nv.contains("anuncio"))) continue;
            if (nv.matches(".*\\b(reaction|reacao|react|review|critica|analise|explicacao|fan ?made|recap|resumo|cena|scene|parody|parodia|gameplay|tiktok|shorts?)\\b.*")) continue;
            boolean all = true; for (String x : words) if (x.length() > 2 && !nv.contains(x)) { all = false; break; }
            if (!all || nt.isEmpty()) continue;
            Matcher lm = Pattern.compile("\"lengthText\":\\{\"accessibility\":\\{\"accessibilityData\":\\{\"label\":\"[^\"]*\"\\}\\},\"simpleText\":\"([\\d:]+)\"").matcher(ch);
            int ls = lm.find() ? lenSec(lm.group(1)) : 0;
            if (ls > 420) continue;
            Matcher pm = Pattern.compile("\"publishedTimeText\":\\{\"simpleText\":\"((?:[^\"\\\\]|\\\\.)*)\"").matcher(ch);
            long age = pm.find() ? ageDays(unesc(pm.group(1))) : 99998;
            ages.put(ids.get(i), age); out.add(ids.get(i));
        }
        java.util.Collections.sort(out, (x, y) -> Long.compare(ages.get(x), ages.get(y)));
        for (int i = 0; i < ids.size() && i < 5; i++) if (!out.contains(ids.get(i))) out.add(ids.get(i));
        return out;
    }
}
