package pt.rui.cockpittv;

import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.text.SpannableStringBuilder;
import android.text.Spanned;
import android.text.style.ReplacementSpan;
import android.util.Base64;
import android.widget.TextView;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Iterator;

/** Ícones dos botões nativos: os mesmos SVG da página (e o mesmo estilo escolhido nas definições), enviados como PNG. */
final class NIcons {
    private static String src = "";
    private static final HashMap<String, Bitmap> M = new HashMap<>();
    private static final String[][] G = {
            {"⏮", "skipprev"}, {"⏪", "rew"}, {"⏯", "pp"}, {"⏩", "fwd"}, {"⏭", "skipnext"},
            {"⛶", "full"}, {"⤡", "exitfull"}, {"✕", "close"}, {"▭", "aspect"}, {"⧉", "frames"},
            {"🔊", "sound"}, {"🌐", "globe"}, {"🎧", "phones"}, {"💬", "subs"}, {"📅", "guide"},
            {"📊", "stats"}, {"☰", "list"}, {"🔎", "search"}, {"▶", "play"}
    };

    private NIcons() { }

    private static synchronized void load() {
        String j = MainActivity.ICONS_JSON;
        if (j == null || j.length() < 3 || j.equals(src)) return;
        src = j;
        M.clear();
        try {
            JSONObject o = new JSONObject(j);
            for (Iterator<String> it = o.keys(); it.hasNext(); ) {
                String k = it.next();
                byte[] b = Base64.decode(o.optString(k), Base64.DEFAULT);
                Bitmap bm = BitmapFactory.decodeByteArray(b, 0, b.length);
                if (bm != null) M.put(k, bm);
            }
        } catch (Throwable ignored) { }
    }

    /** Põe o texto no botão; o símbolo inicial (emoji) é trocado pelo ícone da página, se já o recebemos. */
    static void set(TextView tv, CharSequence text) {
        if (text == null) { tv.setText(""); return; }
        load();
        String s = text.toString();
        String t = s.replaceFirst("^\\s+", "");
        Bitmap bm = null;
        int cut = 0;
        synchronized (NIcons.class) {
            for (String[] g : G) {
                if (t.startsWith(g[0])) {
                    Bitmap b = M.get(g[1]);
                    if (b != null) { bm = b; cut = g[0].length(); }
                    break;
                }
            }
        }
        if (bm == null) { tv.setText(text); return; }
        String rest = t.substring(cut).replaceFirst("^\\s+", "");
        SpannableStringBuilder sb = new SpannableStringBuilder("￼");
        if (rest.length() > 0) sb.append(" ").append(rest);
        final Bitmap fb = bm;
        final boolean hasText = rest.length() > 0;
        final float gap = tv.getResources().getDisplayMetrics().density * 5f;
        sb.setSpan(new ReplacementSpan() {
            private int sz(Paint p) { return Math.round(p.getTextSize() * 1.3f); }
            @Override public int getSize(Paint p, CharSequence tx, int st, int en, Paint.FontMetricsInt fm) { return sz(p) + (hasText ? Math.round(gap - p.measureText(" ")) : 0); }
            @Override public void draw(Canvas c, CharSequence tx, int st, int en, float x, int top, int y, int bottom, Paint p) {
                int z = sz(p);
                Paint.FontMetrics m = p.getFontMetrics();
                float cy = y + (m.ascent + m.descent) / 2f;
                Paint q = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
                c.drawBitmap(fb, null, new RectF(x, cy - z / 2f, x + z, cy + z / 2f), q);
            }
        }, 0, 1, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        tv.setText(sb);
    }
}
