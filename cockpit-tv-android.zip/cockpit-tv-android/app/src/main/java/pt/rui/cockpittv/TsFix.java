package pt.rui.cockpittv;

import android.net.Uri;

import androidx.annotation.Nullable;
import androidx.media3.common.C;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DataSource;
import androidx.media3.datasource.DataSpec;
import androidx.media3.datasource.TransferListener;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Correções aos pedaços .ts dos canais HLS, antes de chegarem ao ExoPlayer (as mesmas da versão Tesla):
 *  1) relógio do vídeo desfasado do som (ex.: Sport TV 2, vídeo ~125 s à frente): mede a diferença no 1.º pedaço
 *     (1.º PTS do vídeo vs 1.º PTS do som, que chegam juntos) e, se passar de 3 s, acerta o PTS/DTS do vídeo;
 *  3) salto do relógio a meio do canal (troca de emissão sem marca de descontinuidade: o PTS/DTS de cada faixa salta horas):
 *     cada faixa é recolocada logo a seguir ao fim do pedaço anterior (só em pedaços consecutivos);
 *  2) SPS de vídeo H.264 entrelaçado (1080i) que declara menos imagens de referência do que usa (4 em vez de 5):
 *     passa max_num_ref_frames a 8, sem mudar o tamanho do pedaço.
 * Só atua em pedaços MPEG-TS de listas HLS. Trabalha em fluxo (não espera pelo pedaço inteiro): guarda só uma cauda
 * de ~96 KB por analisar, para o SPS e os cabeçalhos que cruzam blocos de rede.
 */
@UnstableApi
final class TsFix {
    /** Estado de uma reprodução (o desfasamento medido vale para todos os pedaços seguintes). */
    static final class State {
        volatile boolean active = false;     // só em listas .m3u8
        volatile boolean measured = false;
        volatile long offset = 0;            // em unidades de 90 kHz
        volatile int fixedSps = 0, shifted = 0;
        volatile int pmt = -1, vpid = -1, vtype = 0, apid = -1;
        /* continuidade dos relógios entre pedaços: por PID {fim, pedaço, desvio, base, máx, mín, n} */
        final java.util.HashMap<Integer, long[]> cont = new java.util.HashMap<>();
        volatile int segSeq = 0, contShifts = 0; volatile long contThr = 180000L, lastSegNum = -1, lastReadMs = 0, lastShift = 0;
        void reset(boolean on) { active = on; measured = false; offset = 0; fixedSps = 0; shifted = 0; pmt = -1; vpid = -1; vtype = 0; apid = -1; synchronized (cont) { cont.clear(); segSeq = 0; contShifts = 0; lastSegNum = -1; lastReadMs = 0; lastShift = 0; } }
        /** Chamado ao abrir cada pedaço: decide se vale comparar o relógio com o do pedaço anterior. */
        void newSegment(Uri u) {
            long n = segNum(u), now = System.currentTimeMillis();
            synchronized (cont) {
                segSeq++;
                if (n >= 0 && lastSegNum >= 0 && n == lastSegNum + 1) contThr = 180000L;                 /* pedaço seguinte: mais de 2 s fora de sítio é salto */
                else if (!cont.isEmpty() && now - lastReadMs < 20000) contThr = 30L * 60 * 90000L;       /* sequência incerta (procurar no direto): só saltos enormes (>30 min) */
                else cont.clear();                                                                          /* recomeça */
                lastSegNum = n;
            }
        }
        String info() {
            String a = offset != 0 ? "vídeo desfasado " + Math.round(offset / 900.0) / 100.0 + " s (corrigido)" : "";
            String b = fixedSps > 0 ? "1080i corrigido" : "";
            String c = contShifts > 0 ? "relógio corrigido " + contShifts + "× (último " + Math.round(lastShift / 900.0) / 100.0 + " s)" : "";
            StringBuilder r = new StringBuilder();
            for (String x : new String[]{a, b, c}) if (!x.isEmpty()) { if (r.length() > 0) r.append(" · "); r.append(x); }
            return r.toString();
        }
        /** Número do pedaço pelo nome («…/123.ts», também dentro de um endereço de proxy), ou -1. */
        static long segNum(Uri u) {
            try { java.util.regex.Matcher m = java.util.regex.Pattern.compile("(\\d{1,12})\\.ts(?=$|[?&#])").matcher(Uri.decode(u.toString())); long r = -1; while (m.find()) r = Long.parseLong(m.group(1)); return r; }
            catch (Throwable t) { return -1; }
        }
    }

    static final class Factory implements DataSource.Factory {
        private final DataSource.Factory up; private final State st;
        Factory(DataSource.Factory up, State st) { this.up = up; this.st = st; }
        @Override public DataSource createDataSource() { return new Src(up.createDataSource(), st); }
    }

    static final class Src implements DataSource {
        private static final int TAIL = 96 * 1024, CHUNK = 64 * 1024, FIRST = 768 * 1024;
        private final DataSource up; private final State st;
        private boolean passthrough, eof, started;
        private byte[] pend = new byte[0]; private int pendLen = 0;   // por analisar (inclui a cauda)
        private byte[] out = new byte[0]; private int outPos = 0, outLen = 0;   // já analisado, pronto a entregar
        private final byte[] tmp = new byte[CHUNK];
        Src(DataSource up, State st) { this.up = up; this.st = st; }
        @Override public void addTransferListener(TransferListener l) { up.addTransferListener(l); }
        @Override public long open(DataSpec spec) throws IOException {
            passthrough = true; eof = false; started = false; pendLen = 0; outPos = outLen = 0;
            String p = spec.uri.getPath() == null ? "" : spec.uri.getPath().toLowerCase();
            long n = up.open(spec);
            if (!st.active || p.endsWith(".m3u8") || p.endsWith(".m3u") || p.endsWith(".key") || p.endsWith(".vtt") || p.endsWith(".aac") || p.endsWith(".mp4") || p.endsWith(".m4s")) return n;
            passthrough = false;
            if (st.active) st.newSegment(spec.uri);
            return n;   // o tamanho não muda
        }
        private void append(byte[] b, int l) {
            if (pend.length < pendLen + l) { byte[] nb = new byte[Math.max(pend.length * 2, pendLen + l)]; System.arraycopy(pend, 0, nb, 0, pendLen); pend = nb; }
            System.arraycopy(b, 0, pend, pendLen, l); pendLen += l;
        }
        /* lê da rede e passa para "out" tudo o que já pode ser entregue */
        private void fill() throws IOException {
            while (outPos >= outLen && !(eof && pendLen == 0)) {
                if (!eof) {
                    int r = up.read(tmp, 0, tmp.length);
                    if (r == C.RESULT_END_OF_INPUT) eof = true; else if (r > 0) { append(tmp, r); st.lastReadMs = System.currentTimeMillis(); }
                }
                if (!started) {
                    /* não é MPEG-TS alinhado: entrega tal como veio */
                    if (pendLen >= 376 && ((pend[0] & 0xff) != 0x47 || (pend[188] & 0xff) != 0x47)) { passthroughRest(); return; }
                    /* 1.º bloco: espera até ter o vídeo e o som (para medir o desfasamento) ou ~768 KB */
                    if (!eof && pendLen < FIRST && !(st.measured || pendLen >= 376 && haveBoth())) continue;
                    started = true;
                }
                int commit = eof ? pendLen : ((pendLen - TAIL) / 188) * 188;
                if (commit <= 0) { if (eof) commit = pendLen; else continue; }
                try { process(pend, pendLen, commit, st); } catch (Throwable ignored) { }
                if (out.length < commit) out = new byte[commit];
                System.arraycopy(pend, 0, out, 0, commit); outPos = 0; outLen = commit;
                System.arraycopy(pend, commit, pend, 0, pendLen - commit); pendLen -= commit;
            }
        }
        private boolean haveBoth() { try { process(pend, pendLen, 0, st); } catch (Throwable ignored) { } return st.measured; }
        private void passthroughRest() { if (out.length < pendLen) out = new byte[pendLen]; System.arraycopy(pend, 0, out, 0, pendLen); outPos = 0; outLen = pendLen; pendLen = 0; passthrough = true; }
        @Override public int read(byte[] b, int off, int l) throws IOException {
            if (l == 0) return 0;
            if (outPos < outLen) { int k = Math.min(l, outLen - outPos); System.arraycopy(out, outPos, b, off, k); outPos += k; return k; }
            if (passthrough) return up.read(b, off, l);
            fill();
            if (outPos < outLen) { int k = Math.min(l, outLen - outPos); System.arraycopy(out, outPos, b, off, k); outPos += k; return k; }
            if (passthrough) return up.read(b, off, l);
            return C.RESULT_END_OF_INPUT;
        }
        @Nullable @Override public Uri getUri() { return up.getUri(); }
        @Override public Map<String, List<String>> getResponseHeaders() { return up.getResponseHeaders(); }
        @Override public void close() throws IOException { pendLen = 0; outPos = outLen = 0; up.close(); }
    }

    /* ---------------- MPEG-TS ---------------- */
    private static int u(byte[] d, int i) { return d[i] & 0xff; }
    private static int pid(byte[] d, int o) { return ((u(d, o + 1) & 0x1f) << 8) | u(d, o + 2); }
    private static int pay(byte[] d, int o) { int afc = (u(d, o + 3) >> 4) & 3; if ((afc & 1) == 0) return -1; int p = o + 4; if ((afc & 2) != 0) p += 1 + u(d, o + 4); return p < o + 188 ? p : -1; }
    private static long readPts(byte[] d, int q) { return (((long) (u(d, q) >> 1) & 7) << 30) | ((long) u(d, q + 1) << 22) | ((long) (u(d, q + 2) >> 1) << 15) | ((long) u(d, q + 3) << 7) | (u(d, q + 4) >> 1); }
    private static void writePts(byte[] d, int q, long v) {
        int pre = u(d, q) & 0xf0;
        d[q] = (byte) (pre | (((v >> 30) & 7) << 1) | 1); d[q + 1] = (byte) ((v >> 22) & 0xff);
        d[q + 2] = (byte) ((((v >> 15) & 0x7f) << 1) | 1); d[q + 3] = (byte) ((v >> 7) & 0xff); d[q + 4] = (byte) (((v & 0x7f) << 1) | 1);
    }

    /** Analisa d[0..n): PMT e medição do desfasamento; corrige os PES de vídeo que começam antes de "commit". */
    static void process(byte[] d, int n, int commit, State st) {
        if (st.vpid < 0) {
            for (int o = 0; o + 188 <= n && (st.pmt < 0 || st.vpid < 0); o += 188) {
                if (u(d, o) != 0x47 || (u(d, o + 1) & 0x40) == 0) continue;
                int id = pid(d, o), p = pay(d, o); if (p < 0) continue; p += 1 + u(d, p);
                if (id == 0 && st.pmt < 0) { int sl = ((u(d, p + 1) & 0xf) << 8) | u(d, p + 2); for (int i = p + 8; i < p + 3 + sl - 4 && i + 3 < n; i += 4) { if (((u(d, i) << 8) | u(d, i + 1)) != 0) { st.pmt = ((u(d, i + 2) & 0x1f) << 8) | u(d, i + 3); break; } } }
                else if (id == st.pmt) {
                    int sl = ((u(d, p + 1) & 0xf) << 8) | u(d, p + 2), pil = ((u(d, p + 10) & 0xf) << 8) | u(d, p + 11);
                    int vp = -1, vt = 0, ap = -1;
                    for (int i = p + 12 + pil; i < p + 3 + sl - 4 && i + 4 < n; ) {
                        int t = u(d, i), ep = ((u(d, i + 1) & 0x1f) << 8) | u(d, i + 2), il = ((u(d, i + 3) & 0xf) << 8) | u(d, i + 4);
                        if ((t == 0x1b || t == 0x24 || t == 0x02) && vp < 0) { vp = ep; vt = t; }
                        else if ((t == 0x0f || t == 0x11 || t == 0x03 || t == 0x04 || t == 0x81 || t == 0x87 || t == 0x06) && ap < 0) ap = ep;
                        i += 5 + il;
                    }
                    st.vtype = vt; st.apid = ap; st.vpid = vp;
                    if (vp < 0) { st.vpid = -2; break; }
                }
            }
        }
        int vpid = st.vpid, apid = st.apid, vtype = st.vtype;
        if (vpid < 0) { if (vpid == -2) st.measured = true; return; }
        /* 1) desfasamento vídeo/som, medido uma vez */
        if (!st.measured) {
            if (apid < 0) st.measured = true;
            else {
                long vp = firstPts(d, n, vpid), ap = firstPts(d, n, apid);
                if (vp >= 0 && ap >= 0) {
                    long df = vp - ap; if (df > (1L << 32)) df -= (1L << 33); if (df < -(1L << 32)) df += (1L << 33);
                    st.offset = Math.abs(df) > 3 * 90000L ? df : 0; st.measured = true;
                }
            }
        }
        if (commit <= 0) return;
        if (st.active) { try { continuity(d, commit, st); } catch (Throwable ignored) { } }
        /* percorre os PES de vídeo que começam antes de "commit" */
        for (int o = 0; o + 188 <= commit; o += 188) {
            if (u(d, o) != 0x47 || pid(d, o) != vpid || (u(d, o + 1) & 0x40) == 0) continue;
            int p = pay(d, o); if (p < 0 || p + 19 > o + 188) continue;
            if (u(d, p) != 0 || u(d, p + 1) != 0 || u(d, p + 2) != 1) continue;
            int fl = u(d, p + 7) >> 6;
            if (st.offset != 0 && (fl & 2) != 0) {
                long M = 1L << 33;
                writePts(d, p + 9, ((readPts(d, p + 9) - st.offset) % M + M) % M);
                if (fl == 3) writePts(d, p + 14, ((readPts(d, p + 14) - st.offset) % M + M) % M);
                st.shifted++;
            }
            if (vtype == 0x1b && fixSps(d, n, o, vpid)) st.fixedSps++;
        }
    }

    private static final long W33 = 1L << 33;
    private static long sdiff(long a, long b) { long x = ((a - b) % W33 + W33) % W33; return x >= W33 / 2 ? x - W33 : x; }

    /** 3) Continuidade dos relógios: o 1.º PES de cada faixa num pedaço tem de vir logo a seguir ao fim do pedaço anterior; se estiver fora de sítio, desloca o pedaço dessa faixa. */
    static void continuity(byte[] d, int commit, State st) {
        synchronized (st.cont) {
            for (int o = 0; o + 188 <= commit; o += 188) {
                if (u(d, o) != 0x47 || (u(d, o + 1) & 0x40) == 0) continue;
                int p = pay(d, o); if (p < 0 || p + 14 > o + 188) continue;
                if (u(d, p) != 0 || u(d, p + 1) != 0 || u(d, p + 2) != 1 || (u(d, p + 7) & 0x80) == 0) continue;
                int sid = u(d, p + 3); if (!((sid >= 0xC0 && sid <= 0xEF) || sid == 0xBD)) continue;
                int id = pid(d, o); long pts = readPts(d, p + 9);
                long[] c = st.cont.get(id); if (c == null) { c = new long[]{-1, -1, 0, 0, 0, 0, 0}; st.cont.put(id, c); }
                if (c[1] != st.segSeq) {
                    long sh = 0;
                    if (c[0] >= 0) { long delta = sdiff(pts, c[0]); if (Math.abs(delta) > st.contThr) sh = -delta; }
                    c[1] = st.segSeq; c[2] = sh; c[3] = (((pts + sh) % W33) + W33) % W33; c[4] = 0; c[5] = 0; c[6] = 1;
                    if (sh != 0) { st.contShifts++; st.lastShift = sh; }
                } else {
                    long np = (((pts + c[2]) % W33) + W33) % W33, rel = sdiff(np, c[3]);
                    if (rel > c[4]) c[4] = rel; if (rel < c[5]) c[5] = rel; c[6]++;
                }
                if (c[2] != 0) {
                    writePts(d, p + 9, (((readPts(d, p + 9) + c[2]) % W33) + W33) % W33);
                    if ((u(d, p + 7) & 0x40) != 0 && p + 19 <= o + 188) writePts(d, p + 14, (((readPts(d, p + 14) + c[2]) % W33) + W33) % W33);
                }
                long dur = c[6] > 1 ? (c[4] - c[5]) / (c[6] - 1) : 0;
                c[0] = (((c[3] + c[4] + dur) % W33) + W33) % W33;
            }
        }
    }

    private static long firstPts(byte[] d, int n, int id) {
        for (int o = 0; o + 188 <= n; o += 188) {
            if (u(d, o) != 0x47 || pid(d, o) != id || (u(d, o + 1) & 0x40) == 0) continue;
            int p = pay(d, o); if (p < 0 || p + 14 > o + 188) continue;
            if (u(d, p) != 0 || u(d, p + 1) != 0 || u(d, p + 2) != 1 || (u(d, p + 7) & 0x80) == 0) continue;
            return readPts(d, p + 9);
        }
        return -1;
    }

    /* 2) SPS: junta os primeiros ~600 bytes do PES (podem cruzar pacotes) e reescreve no mesmo sítio */
    private static boolean fixSps(byte[] d, int n, int o, int vpid) {
        final int LIM = 600; int[] map = new int[LIM]; int m = 0;
        for (int o2 = o; o2 + 188 <= n && m < LIM; o2 += 188) {
            if (pid(d, o2) != vpid) continue;
            if (o2 != o && (u(d, o2 + 1) & 0x40) != 0) break;
            int p = pay(d, o2); if (p < 0) continue;
            for (int k = p; k < o2 + 188 && m < LIM; k++) map[m++] = k;
        }
        if (m < 20) return false;
        int hl = 9 + u(d, map[8]);
        List<int[]> sc = new ArrayList<>();   // {start, four, nalStart}
        for (int i = hl; i + 3 < m; i++) if (u(d, map[i]) == 0 && u(d, map[i + 1]) == 0 && u(d, map[i + 2]) == 1) { sc.add(new int[]{i, (i > hl && u(d, map[i - 1]) == 0) ? 1 : 0, i + 3}); i += 2; }
        for (int k = 0; k < sc.size(); k++) {
            int nb = sc.get(k)[2]; if ((u(d, map[nb]) & 0x1f) != 7) continue;
            if (k + 1 >= sc.size()) return false;
            int end = sc.get(k + 1)[1] == 1 ? sc.get(k + 1)[0] - 1 : sc.get(k + 1)[0];
            int[] raw = new int[end - nb - 1]; for (int i = nb + 1; i < end; i++) raw[i - nb - 1] = u(d, map[i]);
            int[] out = rewriteSps(raw, 8); if (out == null) return false;
            int diff = out.length - raw.length; if (diff < 0) return false;
            List<Integer> shrink = new ArrayList<>();
            for (int q = 0; q <= k && shrink.size() < diff; q++) { int[] c = sc.get(q); if (c[1] == 1 && c[0] - 1 >= hl) shrink.add(c[0] - 1); }
            if (shrink.size() < diff) return false;
            int[] nw = new int[end - hl]; int w = 0;
            for (int i = hl; i < nb + 1; i++) { if (shrink.contains(i)) continue; nw[w++] = u(d, map[i]); }
            for (int x : out) { if (w >= nw.length) return false; nw[w++] = x; }
            if (w != nw.length) return false;
            for (int i = 0; i < nw.length; i++) d[map[hl + i]] = (byte) nw[i];
            return true;
        }
        return false;
    }

    /** Devolve o SPS (sem cabeçalho NAL, com prevenção de emulação) com max_num_ref_frames = refs, ou null se não for preciso. */
    private static int[] rewriteSps(int[] raw, int refs) {
        int[] rb = new int[raw.length]; int rn = 0, z = 0;
        for (int x : raw) { if (z >= 2 && x == 3) { z = 0; continue; } rb[rn++] = x; z = x == 0 ? z + 1 : 0; }
        int[] bits = new int[rn * 8]; for (int i = 0; i < rn; i++) for (int j = 0; j < 8; j++) bits[i * 8 + j] = (rb[i] >> (7 - j)) & 1;
        final int[] ix = {0};
        java.util.function.IntUnaryOperator U = k -> { int v = 0; for (int j = 0; j < k; j++) v = v * 2 + (ix[0] < bits.length ? bits[ix[0]++] : 0); return v; };
        java.util.function.IntSupplier UE = () -> { int zc = 0; while (ix[0] < bits.length && bits[ix[0]] == 0) { zc++; ix[0]++; } ix[0]++; return (1 << zc) - 1 + U.applyAsInt(zc); };
        java.util.function.IntSupplier SE = () -> { int k = UE.getAsInt(); return (k & 1) != 0 ? (k + 1) / 2 : -(k / 2); };
        try {
            int prof = U.applyAsInt(8); U.applyAsInt(16); UE.getAsInt();
            int[] hi = {100, 110, 122, 244, 44, 83, 86, 118, 128, 138, 139, 134, 135};
            boolean isHi = false; for (int h : hi) if (h == prof) isHi = true;
            if (isHi) {
                int cf = UE.getAsInt(); if (cf == 3) U.applyAsInt(1); UE.getAsInt(); UE.getAsInt(); U.applyAsInt(1);
                if (U.applyAsInt(1) == 1) for (int k = 0; k < (cf != 3 ? 8 : 12); k++) if (U.applyAsInt(1) == 1) { int sz = k < 6 ? 16 : 64, last = 8, nxt = 8; for (int j = 0; j < sz; j++) { if (nxt != 0) nxt = (last + SE.getAsInt() + 256) % 256; last = nxt == 0 ? last : nxt; } }
            }
            UE.getAsInt(); int poc = UE.getAsInt();
            if (poc == 0) UE.getAsInt(); else if (poc == 1) { U.applyAsInt(1); SE.getAsInt(); SE.getAsInt(); int c = UE.getAsInt(); for (int k = 0; k < c; k++) SE.getAsInt(); }
            int a = ix[0], old = UE.getAsInt(), e = ix[0];
            U.applyAsInt(1); UE.getAsInt(); UE.getAsInt(); int fmo = U.applyAsInt(1);
            if (fmo == 1 || old >= refs) return null;   // só vídeo entrelaçado
            int last = bits.length - 1; while (last > e && bits[last] == 0) last--;
            List<Integer> nb = new ArrayList<>();
            for (int i = 0; i < a; i++) nb.add(bits[i]);
            int nv = refs + 1, nl = 31 - Integer.numberOfLeadingZeros(nv);
            for (int j = 0; j < nl; j++) nb.add(0); for (int j = nl; j >= 0; j--) nb.add((nv >> j) & 1);
            for (int i = e; i < last; i++) nb.add(bits[i]);
            nb.add(1); while (nb.size() % 8 != 0) nb.add(0);
            int[] by = new int[nb.size() / 8]; for (int i = 0; i < by.length; i++) { int v = 0; for (int k = 0; k < 8; k++) v = v * 2 + nb.get(i * 8 + k); by[i] = v; }
            List<Integer> out = new ArrayList<>(); int zz = 0;
            for (int x : by) { if (zz >= 2 && x <= 3) { out.add(3); zz = 0; } out.add(x); zz = x == 0 ? zz + 1 : 0; }
            int[] r = new int[out.size()]; for (int i = 0; i < r.length; i++) r[i] = out.get(i);
            return r;
        } catch (Throwable t) { return null; }
    }
}
