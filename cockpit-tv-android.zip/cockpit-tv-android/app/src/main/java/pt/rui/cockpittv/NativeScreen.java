package pt.rui.cockpittv;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Handler;
import android.os.Looper;
import android.util.LruCache;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.text.Editable;
import android.text.TextWatcher;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Ecrã de canais 100% nativo (Fase 1, opcional): lista à esquerda, vídeo ao centro e botões por baixo.
 * Só usa o leitor nativo (NativePlayer). A página (WebView) fica por baixo, parada, até saíres.
 */
final class NativeScreen {
    interface Host { void js(String kind, String msg); }

    private static final class Item { String name = "", logo = "", group = "", url = "", ref = "", epg = "", kind = "live"; long start = 0; }

    /** Grelha dos frames de vídeo (1 a 4, ou PIP). Cada frame é 16:9; a grelha nunca ocupa mais do que a altura livre menos a reserva. */
    private final class VideoGrid extends FrameLayout {
        int reserve = 0, cw = 0, chh = 0, gap = 0, gridW = 0;
        VideoGrid(Activity a) { super(a); }
        @Override
        protected void onMeasure(int wSpec, int hSpec) {
            int w = MeasureSpec.getSize(wSpec);
            int availH = MeasureSpec.getSize(hSpec);
            gap = dp(3);
            int cols = (nslots == 1 || pip) ? 1 : 2, rows = (nslots <= 2 || pip) ? 1 : 2;
            cw = (w - gap * (cols - 1)) / cols;
            chh = cw * 9 / 16;
            int maxH = availH > 0 ? Math.max(availH - reserve, 120) : Integer.MAX_VALUE;
            if (chh * rows + gap * (rows - 1) > maxH) { chh = (maxH - gap * (rows - 1)) / rows; cw = chh * 16 / 9; }
            gridW = cw * cols + gap * (cols - 1);
            setMeasuredDimension(w, chh * rows + gap * (rows - 1));
            for (int s = 0; s < MAXS; s++) {
                View v = hs[s];
                if (v == null || v.getVisibility() == View.GONE) continue;
                int vw = cw, vh = chh;
                if (pip && s > 0) { vw = Math.max(cw * 34 / 100, dp(90)); vh = vw * 9 / 16; }
                v.measure(MeasureSpec.makeMeasureSpec(vw, MeasureSpec.EXACTLY), MeasureSpec.makeMeasureSpec(vh, MeasureSpec.EXACTLY));
            }
        }
        @Override
        protected void onLayout(boolean changed, int l, int t, int r, int b) {
            int ox = ((r - l) - gridW) / 2;
            for (int s = 0; s < MAXS; s++) {
                View v = hs[s];
                if (v == null || v.getVisibility() == View.GONE) continue;
                int x, y;
                if (pip && s > 0) { x = ox + cw - v.getMeasuredWidth() - dp(8); y = chh - v.getMeasuredHeight() - dp(8); }
                else if (nslots == 1 || pip) { x = ox; y = 0; }
                else { x = ox + (s % 2) * (cw + gap); y = (s / 2) * (chh + gap); }
                v.layout(x, y, x + v.getMeasuredWidth(), y + v.getMeasuredHeight());
            }
        }
    }

    private final Activity act;
    private final FrameLayout root;
    private final NativePlayer np;
    private final Host host;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService pool = Executors.newFixedThreadPool(6);
    private final LruCache<String, Bitmap> cache = new LruCache<String, Bitmap>(80);

    private final ArrayList<Item> items = new ArrayList<Item>();
    private static final int MAXS = 4;
    private int index = -1;                       /* canal do frame 0 */
    private boolean full = false, closed = false;
    private final NativePlayer[] sp = new NativePlayer[MAXS];
    private final FrameLayout[] hs = new FrameLayout[MAXS];
    private final TextView[] ls = new TextView[MAXS];
    private final int[] sidx = {-1, -1, -1, -1}, sret = new int[MAXS], sasp = new int[MAXS];
    private final boolean[] sts = new boolean[MAXS], sfirst = {true, true, true, true};
    private int nslots = 1, fullSlot = 0;
    private boolean pip = false;
    private VideoGrid grid;

    private FrameLayout screen;
    private LinearLayout main, right, row1, row2, row3;
    private ListView list;
    private LinearLayout listBox;
    private TextView title, epg, btnAspect, btnFull, btnGroup, btnDual;
    private EditText search;
    private final ArrayList<Integer> vis = new ArrayList<Integer>();
    private String query = "", groupFilter = "";
    private int active = 0, soundSlot = 0;
    private TextView btnSound, btnSubs;
    private BaseAdapter adapter;

    private static final String[] ASP = {"fit", "zoom", "stretch", "16:9", "4:3", "21:9"};
    private static final String[] ASP_L = {"Ajustar", "Zoom", "Esticar", "16:9", "4:3", "21:9"};

    NativeScreen(Activity act, FrameLayout root, NativePlayer np, Host host) {
        this.act = act;
        this.root = root;
        this.np = np;
        this.sp[0] = np;
        this.host = host;
    }

    private int dp(int v) { return (int) (v * act.getResources().getDisplayMetrics().density + 0.5f); }

    /* ------------------------------------------------------------ abrir / fechar */
    void open(String json, int start) {
        try {
            JSONArray a = new JSONArray(json);
            for (int i = 0; i < a.length(); i++) {
                JSONObject o = a.getJSONObject(i);
                Item it = new Item();
                it.name = o.optString("name");
                it.logo = o.optString("logo");
                it.group = o.optString("group");
                it.url = o.optString("url");
                it.ref = o.optString("ref");
                it.epg = o.optString("epg");
                it.kind = o.optString("kind", "live");
                it.start = o.optLong("start", 0);
                if (it.url.length() > 0) items.add(it);
            }
        } catch (Throwable e) {
            Toast.makeText(act, "Lista inválida: " + e, Toast.LENGTH_LONG).show();
            host.js("nscreen:closed", "");
            return;
        }
        if (items.isEmpty()) { host.js("nscreen:closed", ""); return; }
        buildVis();
        build();
        np.prepareViews();
        root.addView(screen, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        np.bringBoxToFront();
        applyOrientation();
        np.setAspect("fit", "Ajustar");
        play(Math.max(0, Math.min(start, items.size() - 1)));
        ui.postDelayed(posRun, 5000);
        selectInList(index);
        /* o foco do comando tem de ir para o ecrã nativo (senão as setas continuam a mexer na página escondida) */
        screen.setFocusable(true);
        screen.setFocusableInTouchMode(false);
        screen.post(() -> { try { list.requestFocus(); } catch (Throwable ignored) { } });
    }

    boolean isOpen() { return !closed && screen != null; }

    void close() {
        if (closed) return;
        reportPos();
        closed = true;
        ui.removeCallbacksAndMessages(null);
        try { np.setFull(false); } catch (Throwable ignored) { }
        try { np.stop(); } catch (Throwable ignored) { }
        for (int q = 1; q < MAXS; q++) {
            try { if (sp[q] != null) { sp[q].setFull(false); sp[q].stop(); sp[q].release(); sp[q] = null; } } catch (Throwable ignored) { }
        }
        try { root.removeView(screen); } catch (Throwable ignored) { }
        pool.shutdownNow();
        host.js("nscreen:closed", index >= 0 && index < items.size() ? items.get(index).url : "");
    }

    /** Botão Voltar: primeiro sai do ecrã total, depois fecha. */
    boolean onBack() {
        if (full) { setFull(false); return true; }
        close();
        return true;
    }

    /** Teclas do comando (TV): cima/baixo muda de canal fora do ecrã total. */
    boolean onKey(KeyEvent ev) {
        if (ev.getAction() != KeyEvent.ACTION_DOWN) return false;
        int k = ev.getKeyCode();
        if (full) {
            if (k == KeyEvent.KEYCODE_CHANNEL_UP || k == KeyEvent.KEYCODE_DPAD_UP) { step(-1); return true; }
            if (k == KeyEvent.KEYCODE_CHANNEL_DOWN || k == KeyEvent.KEYCODE_DPAD_DOWN) { step(1); return true; }
            if (k == KeyEvent.KEYCODE_DPAD_CENTER || k == KeyEvent.KEYCODE_ENTER) { setFull(false); return true; }
        }
        if (k == KeyEvent.KEYCODE_CHANNEL_UP) { step(-1); return true; }
        if (k == KeyEvent.KEYCODE_CHANNEL_DOWN) { step(1); return true; }
        return false;
    }

    /* ------------------------------------------------------------ interface */
    private GradientDrawable round(int color, int r) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(color);
        g.setCornerRadius(dp(r));
        return g;
    }

    private TextView button(String text, View.OnClickListener l) {
        TextView b = new TextView(act);
        b.setText(text);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15f);
        b.setGravity(Gravity.CENTER);
        b.setSingleLine(true);
        b.setMaxLines(1);
        b.setPadding(dp(4), dp(10), dp(4), dp(10));
        /* o texto encolhe para caber no botão (telemóvel na vertical tem 5 botões por linha) */
        final TextView tb = b;
        b.addOnLayoutChangeListener((vw, x1, y1, x2, y2, ox1, oy1, ox2, oy2) -> { if (x2 - x1 != ox2 - ox1) fitText(tb); });
        b.setFocusable(true);
        b.setClickable(true);
        StateListDrawable sl = new StateListDrawable();
        GradientDrawable focus = round(0xFF2F7DD1, 12);
        focus.setStroke(dp(2), Color.WHITE);
        sl.addState(new int[]{android.R.attr.state_focused}, focus);
        sl.addState(new int[]{android.R.attr.state_pressed}, round(0xFF2F7DD1, 12));
        sl.addState(new int[]{}, round(0xFF1B2B47, 12));
        b.setBackground(sl);
        b.setOnClickListener(l);
        return b;
    }

    private void setBtn(final TextView tv, String text) {
        tv.setText(text);
        tv.setTextSize(15f);
        tv.post(() -> fitText(tv));
    }

    /** Encolhe o texto até caber na largura do botão. */
    private void fitText(TextView tv) {
        int avail = tv.getWidth() - tv.getPaddingLeft() - tv.getPaddingRight();
        if (avail <= 0 || tv.getText() == null) return;
        float sp = 15f;
        String t = tv.getText().toString();
        float dens = act.getResources().getDisplayMetrics().scaledDensity;
        android.graphics.Paint p = new android.graphics.Paint(tv.getPaint());
        while (sp > 8f) {
            p.setTextSize(sp * dens);
            if (p.measureText(t) <= avail) break;
            sp -= 0.5f;
        }
        tv.setTextSize(sp);
    }

    private LinearLayout row() {
        LinearLayout r = new LinearLayout(act);
        r.setOrientation(LinearLayout.HORIZONTAL);
        return r;
    }

    private void addBtn(LinearLayout r, TextView b) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        lp.setMargins(dp(3), dp(3), dp(3), dp(3));
        r.addView(b, lp);
    }

    private void build() {
        screen = new FrameLayout(act);
        screen.setBackgroundColor(0xFF0B1220);
        screen.setKeepScreenOn(true);
        screen.setClickable(true);   /* não deixa toques passarem para a página */

        main = new LinearLayout(act);

        list = new ListView(act);
        list.setDivider(null);
        list.setBackgroundColor(0xFF111B2E);
        list.setSelector(new android.graphics.drawable.ColorDrawable(0x332F7DD1));
        adapter = new BaseAdapter() {
            @Override public int getCount() { return vis.size(); }
            @Override public Object getItem(int i) { return items.get(vis.get(i)); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View v, ViewGroup parent) {
                Row r;
                if (v == null) { r = new Row(act); v = r; } else r = (Row) v;
                int ix = vis.get(i);
                r.bind(items.get(ix), isShown(ix));
                return v;
            }
        };
        list.setAdapter(adapter);
        listBox = new LinearLayout(act);
        listBox.setOrientation(LinearLayout.VERTICAL);
        listBox.setBackgroundColor(0xFF111B2E);
        LinearLayout sr = row();
        search = new EditText(act);
        search.setHint("🔍 Pesquisar");
        search.setHintTextColor(0xFF8DA2BD);
        search.setTextColor(Color.WHITE);
        search.setTextSize(14f);
        search.setSingleLine(true);
        search.setImeOptions(android.view.inputmethod.EditorInfo.IME_ACTION_SEARCH);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void onTextChanged(CharSequence c, int a, int b, int d) { }
            @Override public void afterTextChanged(Editable e) { query = e.toString().trim().toLowerCase(); buildVis(); adapter.notifyDataSetChanged(); }
        });
        btnGroup = button("☰ Todos", v -> pickGroup());
        LinearLayout.LayoutParams sp = new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        sr.addView(search, sp);
        sr.addView(btnGroup, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        sr.setPadding(dp(4), dp(4), dp(4), dp(4));
        listBox.addView(sr, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        listBox.addView(list, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
        if (items.size() < 2) sr.setVisibility(View.GONE);
        buildVis();
        list.setOnItemClickListener((p, v, i, id) -> { if (i >= 0 && i < vis.size()) playOnActive(vis.get(i)); });

        right = new LinearLayout(act);
        right.setOrientation(LinearLayout.VERTICAL);
        right.setPadding(dp(8), dp(6), dp(8), dp(6));

        grid = new VideoGrid(act);
        for (int q = 0; q < MAXS; q++) {
            final int sq = q;
            FrameLayout h = new FrameLayout(act);
            h.setBackgroundColor(Color.BLACK);
            h.setFocusable(true);
            h.setClickable(true);
            TextView t = new TextView(act);
            t.setTextColor(0xFFCBD5E1);
            t.setTextSize(q == 0 ? 15f : 13f);
            t.setGravity(Gravity.CENTER);
            h.addView(t, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            h.addOnLayoutChangeListener((v, l, tt, r, b, ol, ot, or, ob) -> {
                if (r - l != or - ol || b - tt != ob - ot || tt != ot || l != ol) scheduleRect();
            });
            h.setOnFocusChangeListener((v, f) -> updateFrames());
            h.setOnClickListener(v -> onFrameClick(sq));
            h.setOnLongClickListener(v -> { if (sq < nslots) setSound(sq); return true; });
            hs[q] = h;
            ls[q] = t;
            if (q > 0) h.setVisibility(View.GONE);
            grid.addView(h);
        }

        title = new TextView(act);
        title.setTextColor(Color.WHITE);
        title.setTextSize(18f);
        title.setSingleLine(true);
        title.setEllipsize(android.text.TextUtils.TruncateAt.END);
        title.setPadding(dp(4), dp(6), dp(4), 0);

        epg = new TextView(act);
        epg.setTextColor(0xFF9FB3CC);
        epg.setTextSize(14f);
        epg.setMaxLines(2);
        epg.setEllipsize(android.text.TextUtils.TruncateAt.END);
        epg.setPadding(dp(4), 0, dp(4), dp(4));

        row1 = row();
        row2 = row();
        row3 = row();
        btnAspect = button("▭ Ajustar", v -> cycleAspect());
        btnFull = button("⛶ Ecrã total", v -> setFull(!full));
        addBtn(row1, btnAspect);
        addBtn(row1, btnFull);
        btnDual = button("⧉ 1 frame", v -> pickLayout());
        addBtn(row1, btnDual);
        addBtn(row1, button("📅 Guia", v -> { close(); host.js("nscreen:guide", ""); }));
        addBtn(row1, button("✕ Sair", v -> close()));
        addBtn(row2, button("◀ Anterior", v -> step(-1)));
        addBtn(row2, button("🔊 Áudio", v -> tracks("audio", "Áudio")));
        btnSound = button("🔊 Som F1", v -> cycleSound());
        addBtn(row2, btnSound);
        addBtn(row2, button("💬 Legendas", v -> tracks("text", "Legendas")));
        addBtn(row2, button("Seguinte ▶", v -> step(1)));

        right.addView(grid, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        right.addView(title, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        right.addView(epg, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        right.addView(row1, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        addBtn(row3, button("⏪ 10 s", v -> cp().seek(-10000)));
        addBtn(row3, button("⏯ Pausa", v -> cp().toggle()));
        addBtn(row3, button("30 s ⏩", v -> cp().seek(30000)));
        btnSubs = button("🌐 Legendas", v -> { if (isVod()) onlineSubs(); else cp().goLive(); });
        addBtn(row3, btnSubs);
        right.addView(row2, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        right.addView(row3, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        screen.addView(main, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    /** (Re)organiza conforme a orientação: horizontal = lista | vídeo+botões; vertical = vídeo+botões por cima da lista. */
    private void applyOrientation() {
        boolean land = act.getResources().getDisplayMetrics().widthPixels > act.getResources().getDisplayMetrics().heightPixels;
        main.removeAllViews();
        ((ViewGroup) screen).setPadding(0, 0, 0, 0);
        if (land) {
            main.setOrientation(LinearLayout.HORIZONTAL);
            setReserve();
            main.addView(listBox, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.32f));
            main.addView(right, new LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.MATCH_PARENT, 0.68f));
        } else {
            main.setOrientation(LinearLayout.VERTICAL);
            setReserve();
            main.addView(right, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
            main.addView(listBox, new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));
            ((ViewGroup) screen).setPadding(0, dp(24), 0, 0);   /* margem da barra de estado */
        }
    }

    /** Chamado quando o ecrã roda: reorganiza e reposiciona o vídeo quando a vista assenta (sem o esconder). */
    void onConfigChanged() {
        if (closed || screen == null || pipEntered) return;
        if (full) {   /* em ecrã total, rodar só reajusta a imagem (não volta ao menu) */
            applyOrientation();
            main.setVisibility(View.INVISIBLE);
            ui.postDelayed(() -> { if (!closed && full) applyFullLayout(); }, 350);
            ui.postDelayed(() -> { if (!closed && full) applyFullLayout(); }, 900);
            return;
        }
        lastKey = "";
        ui.removeCallbacks(rectRun);
        applyOrientation();
        ui.postDelayed(rectRun, 350);
    }

    /* ------------------------------------------------------------ posição do vídeo */
    private String lastKey = "";
    private final Runnable rectRun = new Runnable() {
        @Override public void run() {
            if (closed || grid == null || full) return;
            int[] b = new int[2];
            root.getLocationInWindow(b);
            int ins = nslots > 1 ? dp(3) : 0;
            int[][] r = new int[MAXS][];
            StringBuilder k = new StringBuilder();
            for (int q = 0; q < nslots; q++) {
                if (sp[q] == null || ix(q) < 0) continue;
                int w = hs[q].getWidth(), h = hs[q].getHeight();
                if (w < 20 || h < 20) { ui.postDelayed(this, 150); return; }
                int[] a = new int[2];
                hs[q].getLocationInWindow(a);
                r[q] = new int[]{a[0] - b[0] + ins, a[1] - b[1] + ins, w - 2 * ins, h - 2 * ins};
                k.append(q).append(':').append(r[q][0]).append(',').append(r[q][1]).append(',').append(r[q][2]).append(',').append(r[q][3]).append('|');
            }
            String ks = k.toString();
            if (ks.equals(lastKey)) return;
            lastKey = ks;
            for (int q = 0; q < MAXS; q++) {
                if (sp[q] == null) continue;
                if (r[q] != null) sp[q].rect(r[q][0], r[q][1], r[q][2], r[q][3], true);
                else if (q > 0) sp[q].rect(0, 0, 1, 1, false);
            }
        }
    };

    private void scheduleRect() {
        ui.removeCallbacks(rectRun);
        ui.postDelayed(rectRun, 250);   /* só depois de a vista parar de mudar */
    }

    /* ------------------------------------------------------------ reprodução */
    private static String hintFor(String u, boolean live) {
        String l = u.toLowerCase();
        if (l.matches(".*\\.m3u8(\\?.*)?$")) return "hls";
        if (l.matches(".*\\.mpd(\\?.*)?$")) return "dash";
        if (!live) return "";
        if (l.matches(".*\\.ts(\\?.*)?$")) return "";
        return "hls";
    }

    private boolean isVod() { return index >= 0 && index < items.size() ? !"live".equals(items.get(index).kind) : (!items.isEmpty() && !"live".equals(items.get(0).kind)); }

    /** Envia à página a posição atual (filmes/episódios) para guardar a retoma. */
    private void reportPos() {
        if (closed || index < 0 || index >= items.size() || !isVod()) return;
        try {
            String[] a = np.pos().split("\\|");
            long p = Long.parseLong(a[0]), d = Long.parseLong(a[1]);
            if (d > 0 && "0".equals(a[2])) host.js("nscreen:pos", items.get(index).url + "|" + p + "|" + d);
        } catch (Throwable ignored) { }
    }

    private final Runnable posRun = new Runnable() {
        @Override public void run() {
            if (closed) return;
            reportPos();
            ui.postDelayed(this, 5000);
        }
    };

    private void applyMode() {
        boolean vod = isVod();
        row3.setVisibility(View.VISIBLE);   /* também em direto: recuar/pausar (timeshift) e voltar ao direto */
        if (btnSubs != null) setBtn(btnSubs, vod ? "🌐 Legendas" : "⏭ Direto");
        applyOrientationKeep();
    }

    private void applyOrientationKeep() { /* a reserva do vídeo depende de haver a linha extra */
        boolean land = act.getResources().getDisplayMetrics().widthPixels > act.getResources().getDisplayMetrics().heightPixels;
        setReserve();
    }

    private int ix(int q) { return q == 0 ? index : sidx[q]; }

    private boolean isShown(int itemIdx) {
        for (int q = 0; q < nslots; q++) if (ix(q) == itemIdx) return true;
        return false;
    }

    /** Frame 0 (o principal, que também serve filmes e episódios). */
    private void play(int i) {
        if (i < 0 || i >= items.size()) return;
        reportPos();
        index = i;
        sret[0] = 0;
        sts[0] = false;
        sfirst[0] = true;
        Item it = items.get(i);
        ls[0].setText("A carregar…");
        ls[0].setVisibility(View.VISIBLE);
        adapter.notifyDataSetChanged();
        refreshInfo();
        applyMode();
        startSlotUrl(0, it.url, it);
        host.js("nscreen:play", it.url);
        scheduleRect();
    }

    /** Frames 1..3 (só canais em direto). */
    private void playSlot(int q, int i) {
        if (q == 0) { play(i); return; }
        if (q >= nslots || sp[q] == null || i < 0 || i >= items.size()) return;
        sidx[q] = i;
        sret[q] = 0;
        sts[q] = false;
        sfirst[q] = true;
        Item it = items.get(i);
        ls[q].setText("A carregar…");
        ls[q].setVisibility(View.VISIBLE);
        adapter.notifyDataSetChanged();
        refreshInfo();
        startSlotUrl(q, it.url, it);
        scheduleRect();
    }

    private void startSlotUrl(int q, String url, Item it) {
        try {
            sp[q].play(url, it.ref, hintFor(url, "live".equals(it.kind)), "", sfirst[q] ? it.start : 0);
            sfirst[q] = false;
            lastKey = "";   /* o leitor esconde a caixa ao começar: obriga a reenviar a posição */
            scheduleRect();
            applyVolumes();
            ui.postDelayed(() -> applyVolumes(), 1500);
            ui.postDelayed(() -> applyVolumes(), 4000);
        } catch (Throwable e) {
            ls[q].setText("Erro: " + e);
        }
    }

    private void playOnActive(int i) { playSlot(active, i); }

    private void step(int d) {
        if (items.isEmpty()) return;
        int cur = ix(active);
        int n = (cur + d + items.size()) % items.size();
        playOnActive(n);
        selectInList(n);
    }

    /** Eventos do leitor principal (vindos da atividade). Devolve true se tratou o evento. */
    boolean onPlayerEvent(String k, String m) {
        if (closed) return false;
        return onSlotEvent(0, k, m);
    }

    private boolean onSlotEvent(int q, String k, String m) {
        if (closed || q >= nslots) return true;
        if ("ready".equals(k)) { sret[q] = 0; ls[q].setVisibility(View.GONE); applyVolumes(); return true; }
        if ("buffering".equals(k)) return true;
        if ("ended".equals(k)) { if (q == 0 && isVod() && index + 1 < items.size()) step(1); return true; }
        if ("ui".equals(k)) {
            if (q != active) setActive(q);
            if ("aspect".equals(m)) cycleAspect();
            else if ("full".equals(m)) setFull(!full);
            return true;
        }
        if ("error".equals(k)) {
            final int i = ix(q);
            if (i < 0 || i >= items.size()) return true;
            final Item it = items.get(i);
            String u = it.url;
            final int fq = q;
            if ("live".equals(it.kind) && !sts[q] && u.matches("(?i).*\\.m3u8(\\?.*)?$") && u.contains("/live/")) {
                sts[q] = true;   /* mesmo canal em .ts, como na página */
                startSlotUrl(q, u.replaceFirst("(?i)\\.m3u8", ".ts"), it);
                return true;
            }
            if (sret[q] < 3) {
                sret[q]++;
                ls[q].setText("Sem sinal. A tentar de novo (" + sret[q] + "/3)…");
                ls[q].setVisibility(View.VISIBLE);
                ui.postDelayed(() -> { if (!closed && fq < nslots && ix(fq) == i) { sts[fq] = false; sfirst[fq] = true; startSlotUrl(fq, it.url, it); } }, 1500L * sret[q]);
            } else {
                ls[q].setText("Sem sinal neste canal.");
                ls[q].setVisibility(View.VISIBLE);
            }
            return true;
        }
        if ("noaudio".equals(k)) { Toast.makeText(act, "Este canal tem áudio que o aparelho não descodifica. Tenta outra faixa em Áudio.", Toast.LENGTH_LONG).show(); return true; }
        return true;   /* o resto (aspect:info, hdr…) não interessa à página nesta altura */
    }

    /** Título e linha de informação conforme o frame ativo. */
    private void refreshInfo() {
        int i = ix(active);
        boolean multi = nslots > 1;
        if (i >= 0 && i < items.size()) {
            Item it = items.get(i);
            title.setText((multi ? "Frame " + (active + 1) + " · " : "") + it.name);
            epg.setText(multi ? "Toca noutro frame para o escolher; depois escolhe o canal na lista." : (it.epg.length() > 0 ? it.epg : it.group));
        } else {
            title.setText("Frame " + (active + 1) + " vazio");
            epg.setText("Escolhe agora o canal na lista para este frame.");
        }
    }

    /* ------------------------------------------------------------ pesquisa, categorias, vista dupla, legendas online */
    private NativePlayer cp() { return (active < nslots && sp[active] != null) ? sp[active] : np; }

    private void setReserve() {
        boolean land = act.getResources().getDisplayMetrics().widthPixels > act.getResources().getDisplayMetrics().heightPixels;
        grid.reserve = land ? dp(200) : 0;
        grid.requestLayout();
    }

    private void buildVis() {
        vis.clear();
        for (int i = 0; i < items.size(); i++) {
            Item it = items.get(i);
            if (groupFilter.length() > 0 && !groupFilter.equals(it.group)) continue;
            if (query.length() > 0 && !(it.name.toLowerCase().contains(query) || it.group.toLowerCase().contains(query))) continue;
            vis.add(i);
        }
        if (btnGroup != null) btnGroup.setText("☰ " + (groupFilter.length() > 0 ? groupFilter : "Todos") + " · " + vis.size());
    }

    private void selectInList(int itemIdx) {
        int p = vis.indexOf(itemIdx);
        if (p >= 0 && list != null) list.setSelection(Math.max(0, p - 2));
    }

    private void pickGroup() {
        final ArrayList<String> gs = new ArrayList<String>();
        final ArrayList<String> labels = new ArrayList<String>();
        gs.add("");
        labels.add("Todos (" + items.size() + ")");
        for (Item it : items) {
            if (it.group.length() == 0 || gs.contains(it.group)) continue;
            int n = 0;
            for (Item x : items) if (x.group.equals(it.group)) n++;
            gs.add(it.group);
            labels.add(it.group + " (" + n + ")");
        }
        new AlertDialog.Builder(act).setTitle("Categoria")
                .setItems(labels.toArray(new String[0]), (d, which) -> { groupFilter = gs.get(which); buildVis(); adapter.notifyDataSetChanged(); })
                .show();
    }

    private void applyVolumes() {
        for (int q = 0; q < MAXS; q++) {
            try { if (sp[q] != null) sp[q].volume(q == soundSlot && q < nslots ? 1f : 0f); } catch (Throwable ignored) { }
        }
    }

    /** Realça o frame escolhido (moldura azul) e o que tem o foco do comando (moldura branca). */
    private void updateFrames() {
        for (int q = 0; q < MAXS; q++) {
            if (hs[q] == null) continue;
            int c = Color.BLACK;
            if (nslots > 1) c = q == active ? 0xFF2F7DD1 : (hs[q].isFocused() ? 0xFFFFFFFF : 0xFF1B2B47);
            hs[q].setBackgroundColor(c);
        }
    }

    private void setActive(int a) {
        if (a < 0 || a >= nslots) a = 0;
        active = a;
        applyVolumes();
        if (btnSound != null) setBtn(btnSound, "🔊 Som F" + (soundSlot + 1));
        updateFrames();
        refreshInfo();
        setBtn(btnAspect, "▭ " + ASP_L[sasp[active]]);
    }

    private void setSound(int q) {
        soundSlot = q;
        applyVolumes();
        if (btnSound != null) setBtn(btnSound, "🔊 Som F" + (soundSlot + 1));
        Toast.makeText(act, "Som do frame " + (q + 1), Toast.LENGTH_SHORT).show();
    }

    private void cycleSound() { setSound((soundSlot + 1) % nslots); }

    private void onFrameClick(int q) {
        if (nslots == 1) { setFull(true); return; }
        if (q != active) { setActive(q); return; }
        if (ix(q) >= 0) setFull(true);
    }

    private void pickLayout() {
        if (full) return;
        final String[] labels = {"1 frame (normal)", "2 frames lado a lado", "2 frames · PIP (janela pequena)", "3 frames", "4 frames (grelha 2×2)", "💾 Guardar esta combinação", "📂 Combinações guardadas (" + presets().length() + ")"};
        new AlertDialog.Builder(act).setTitle("Frames · escolhe o frame e depois o canal")
                .setItems(labels, (d, which) -> {
                    if (which == 0) setLayout(1, false);
                    else if (which == 1) setLayout(2, false);
                    else if (which == 2) setLayout(2, true);
                    else if (which == 3) setLayout(3, false);
                    else if (which == 4) setLayout(4, false);
                    else if (which == 5) savePreset();
                    else listPresets();
                }).show();
    }

    /* ---------------------------------------------------- combinações de frames guardadas */
    private JSONArray presets() {
        try { return new JSONArray(act.getSharedPreferences("nsc", 0).getString("presets", "[]")); } catch (Throwable e) { return new JSONArray(); }
    }

    private void putPresets(JSONArray a) { act.getSharedPreferences("nsc", 0).edit().putString("presets", a.toString()).apply(); }

    private void savePreset() {
        try {
            if (nslots < 2) { Toast.makeText(act, "Põe 2 ou mais canais em frames antes de guardar.", Toast.LENGTH_LONG).show(); return; }
            JSONObject o = new JSONObject();
            JSONArray urls = new JSONArray();
            StringBuilder nm = new StringBuilder();
            for (int q = 0; q < nslots; q++) {
                int i = ix(q);
                urls.put(i >= 0 && i < items.size() ? items.get(i).url : "");
                if (i >= 0 && i < items.size()) { if (nm.length() > 0) nm.append(" + "); nm.append(items.get(i).name); }
            }
            o.put("name", (pip ? "PIP · " : nslots + "× · ") + nm);
            o.put("n", nslots);
            o.put("pip", pip);
            o.put("sound", soundSlot);
            o.put("urls", urls);
            JSONArray all = presets();
            all.put(o);
            putPresets(all);
            Toast.makeText(act, "Combinação guardada ✓", Toast.LENGTH_SHORT).show();
        } catch (Throwable e) { Toast.makeText(act, "Não guardei: " + e, Toast.LENGTH_LONG).show(); }
    }

    private void listPresets() {
        final JSONArray all = presets();
        if (all.length() == 0) { Toast.makeText(act, "Ainda não guardaste combinações.", Toast.LENGTH_LONG).show(); return; }
        final String[] names = new String[all.length()];
        for (int i = 0; i < names.length; i++) names[i] = all.optJSONObject(i) == null ? "?" : all.optJSONObject(i).optString("name");
        new AlertDialog.Builder(act).setTitle("Combinações guardadas")
                .setItems(names, (d, which) -> {
                    final JSONObject o = all.optJSONObject(which);
                    if (o == null) return;
                    new AlertDialog.Builder(act).setTitle(o.optString("name"))
                            .setPositiveButton("Abrir", (d2, w2) -> openPreset(o))
                            .setNegativeButton("Apagar", (d2, w2) -> {
                                try {
                                    JSONArray n2 = new JSONArray();
                                    for (int i = 0; i < all.length(); i++) if (i != which) n2.put(all.get(i));
                                    putPresets(n2);
                                } catch (Throwable ignored) { }
                            }).show();
                }).show();
    }

    private void openPreset(JSONObject o) {
        try {
            setLayout(o.optInt("n", 2), o.optBoolean("pip", false));
            JSONArray urls = o.optJSONArray("urls");
            int missing = 0;
            for (int q = 0; urls != null && q < urls.length() && q < nslots; q++) {
                String u = urls.optString(q);
                int found = -1;
                for (int i = 0; i < items.size(); i++) if (items.get(i).url.equals(u)) { found = i; break; }
                if (found >= 0) playSlot(q, found); else if (u.length() > 0) missing++;
            }
            soundSlot = Math.min(o.optInt("sound", 0), nslots - 1);
            setActive(0);
            if (missing > 0) Toast.makeText(act, missing + " canal(is) da combinação já não estão na lista.", Toast.LENGTH_LONG).show();
        } catch (Throwable e) { Toast.makeText(act, "Combinação: " + e, Toast.LENGTH_LONG).show(); }
    }

    /** Janela flutuante do sistema (Android PiP): o vídeo ocupa a janela toda, sem lista nem botões. */
    private boolean pipEntered = false;
    void setSystemPip(boolean in) {
        if (closed || screen == null) return;
        if (in) { if (!full) { pipEntered = true; setFull(true); } }
        else if (pipEntered) { pipEntered = false; if (full) setFull(false); }
    }

    private void setLayout(int n, boolean p) {
        if (full) return;
        if (n > 1 && (isVod() || items.size() < 2)) { Toast.makeText(act, "Vários frames são para canais em direto.", Toast.LENGTH_SHORT).show(); return; }
        int old = nslots;
        nslots = n;
        pip = p;
        for (int q = 1; q < MAXS; q++) {
            if (q < n) {
                if (sp[q] == null) {
                    try {
                        final int fq = q;
                        sp[q] = new NativePlayer(act, root, (k, m) -> onSlotEvent(fq, k, m));
                        sp[q].shareAudio = true;
                        sp[q].prepareViews();
                        sp[q].setAspect("fit", "Ajustar");
                    } catch (Throwable e) {
                        Toast.makeText(act, "Frame " + (q + 1) + " indisponível: " + e, Toast.LENGTH_LONG).show();
                        sp[q] = null;
                        nslots = q;
                        break;
                    }
                }
                hs[q].setVisibility(View.VISIBLE);
                if (q >= old && sidx[q] < 0) { ls[q].setText("Frame " + (q + 1) + "\nescolhe um canal na lista"); ls[q].setVisibility(View.VISIBLE); }
            } else {
                hs[q].setVisibility(View.GONE);
                sidx[q] = -1;
                try { if (sp[q] != null) { sp[q].stop(); sp[q].rect(0, 0, 1, 1, false); } } catch (Throwable ignored) { }
            }
        }
        for (int q = 1; q < nslots; q++) { try { sp[q].bringBoxToFront(); } catch (Throwable ignored) { } }   /* frames seguintes por cima (PIP) */
        setBtn(btnDual, "⧉ " + (pip ? "PIP" : nslots + (nslots == 1 ? " frame" : " frames")));
        applyOrientationKeep();
        grid.requestLayout();
        adapter.notifyDataSetChanged();
        if (soundSlot >= nslots) soundSlot = 0;
        setActive(nslots > old ? old : Math.min(active, nslots - 1));
        lastKey = "";
        scheduleRect();
        if (nslots > old && hs[old] != null) hs[old].requestFocus();
    }

    private void onlineSubs() {
        if (index < 0 || index >= items.size()) return;
        Toast.makeText(act, "A procurar legendas…", Toast.LENGTH_SHORT).show();
        host.js("nscreen:subsearch", items.get(index).name);
    }

    /** Comandos vindos da página (resultados de legendas, avisos). */
    void command(String cmd, String payload) {
        if (closed) return;
        try {
            if ("msg".equals(cmd)) { Toast.makeText(act, payload, Toast.LENGTH_LONG).show(); return; }
            if ("subres".equals(cmd)) {
                JSONArray a = new JSONArray(payload);
                if (a.length() == 0) { Toast.makeText(act, "Não encontrei legendas em português.", Toast.LENGTH_LONG).show(); return; }
                final String[] labels = new String[a.length()];
                for (int i = 0; i < labels.length; i++) labels[i] = a.getString(i);
                new AlertDialog.Builder(act).setTitle("Legendas online")
                        .setItems(labels, (d, which) -> { Toast.makeText(act, "A descarregar legenda…", Toast.LENGTH_SHORT).show(); host.js("nscreen:subpick", String.valueOf(which)); })
                        .show();
            }
        } catch (Throwable e) { Toast.makeText(act, "Legendas: " + e, Toast.LENGTH_LONG).show(); }
    }

    /* ------------------------------------------------------------ botões */
    private void cycleAspect() {
        sasp[active] = (sasp[active] + 1) % ASP.length;
        cp().setAspect(ASP[sasp[active]], ASP_L[sasp[active]]);
        setBtn(btnAspect, "▭ " + ASP_L[sasp[active]]);
    }

    /** Posiciona os vídeos em ecrã total (também chamado depois de rodar o ecrã, sem sair do ecrã total). */
    private void applyFullLayout() {
            if (nslots > 1 && !pip) {   /* grelha em ecrã total: todos os frames a ocupar o ecrã */
                int W = root.getWidth(), H = root.getHeight(), g = dp(2);
                int rows = nslots <= 2 ? 1 : 2;
                int cw = (W - g) / 2, chh = (H - g * (rows - 1)) / rows;
                for (int q = 0; q < MAXS; q++) {
                    if (sp[q] == null) continue;
                    try {
                        if (q < nslots && ix(q) >= 0) { sp[q].bringBoxToFront(); sp[q].rect((q % 2) * (cw + g), (q / 2) * (chh + g), cw, chh, true); }
                        else sp[q].rect(0, 0, 1, 1, false);
                    } catch (Throwable ignored) { }
                }
                fullSlot = active;
                for (int q = 0; q < nslots; q++) { try { if (sp[q] != null) sp[q].setAspect("stretch", "Esticar"); } catch (Throwable ignored) { } }
                setBtn(btnFull, "✕ Sair do ecrã total");
                return;
            }
            fullSlot = pip && nslots > 1 ? 0 : active;   /* PIP: o principal ocupa o ecrã e a janela pequena continua por cima */
            for (int q = 0; q < MAXS; q++) { if (q != fullSlot && sp[q] != null) { try { sp[q].rect(0, 0, 1, 1, false); } catch (Throwable ignored) { } } }
            try { sp[fullSlot].bringBoxToFront(); } catch (Throwable ignored) { }
            sp[fullSlot].setFull(true);
            if (pip && nslots > 1) { for (int q = 0; q < nslots; q++) { try { if (sp[q] != null) sp[q].setAspect("stretch", "Esticar"); } catch (Throwable ignored) { } } }
            if (pip && nslots > 1 && sp[1] != null && sidx[1] >= 0) {
                int W = root.getWidth(), H = root.getHeight();
                int sw = Math.max(W * 28 / 100, dp(140)), sh = sw * 9 / 16;
                try { sp[1].bringBoxToFront(); sp[1].rect(W - sw - dp(16), H - sh - dp(16), sw, sh, true); } catch (Throwable ignored) { }
            }
    }

    private void setFull(boolean on) {
        if (on == full) return;
        if (on && ix(active) < 0) return;
        full = on;
        main.setVisibility(on ? View.INVISIBLE : View.VISIBLE);
        if (on) {
            applyFullLayout();
        } else {
            for (int q = 0; q < MAXS; q++) { if (sp[q] != null) { try { sp[q].setFull(false); sp[q].setAspect(ASP[sasp[q]], ASP_L[sasp[q]]); } catch (Throwable ignored) { } } }
            for (int q = 0; q < nslots; q++) { if (sp[q] != null) { try { sp[q].bringBoxToFront(); } catch (Throwable ignored) { } } }
        }
        setBtn(btnFull, on ? "✕ Sair do ecrã total" : "⛶ Ecrã total");
        if (!on) { lastKey = ""; ui.removeCallbacks(rectRun); ui.postDelayed(rectRun, 200); }
    }

    private void tracks(final String type, String label) {
        try {
            JSONObject j = new JSONObject(cp().tracks());
            JSONArray a = j.optJSONArray(type);
            final boolean text = "text".equals(type);
            int n = a == null ? 0 : a.length();
            final ArrayList<String> names = new ArrayList<String>();
            final ArrayList<Integer> ids = new ArrayList<Integer>();
            if (text) { names.add("Sem legendas"); ids.add(-1); }
            for (int i = 0; i < n; i++) {
                JSONObject o = a.getJSONObject(i);
                names.add((o.optBoolean("on") ? "● " : "○ ") + o.optString("name"));
                ids.add(o.optInt("i"));
            }
            if (names.isEmpty()) { Toast.makeText(act, "Este canal só tem a faixa de áudio por defeito.", Toast.LENGTH_SHORT).show(); return; }
            new AlertDialog.Builder(act).setTitle(label)
                    .setItems(names.toArray(new String[0]), (d, which) -> cp().pick(type, ids.get(which)))
                    .show();
        } catch (Throwable e) {
            Toast.makeText(act, "Sem faixas: " + e, Toast.LENGTH_SHORT).show();
        }
    }

    /* ------------------------------------------------------------ linha da lista */
    private final class Row extends LinearLayout {
        final ImageView img;
        final TextView name, sub;
        String shown = "";

        Row(Activity a) {
            super(a);
            setOrientation(HORIZONTAL);
            setGravity(Gravity.CENTER_VERTICAL);
            setPadding(dp(8), dp(6), dp(8), dp(6));
            img = new ImageView(a);
            img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            img.setBackground(round(0xFF1B2B47, 8));
            addView(img, new LayoutParams(dp(54), dp(40)));
            LinearLayout col = new LinearLayout(a);
            col.setOrientation(VERTICAL);
            col.setPadding(dp(10), 0, 0, 0);
            name = new TextView(a);
            name.setTextColor(Color.WHITE);
            name.setTextSize(15f);
            name.setSingleLine(true);
            name.setEllipsize(android.text.TextUtils.TruncateAt.END);
            sub = new TextView(a);
            sub.setTextColor(0xFF8DA2BD);
            sub.setTextSize(12f);
            sub.setSingleLine(true);
            sub.setEllipsize(android.text.TextUtils.TruncateAt.END);
            col.addView(name);
            col.addView(sub);
            addView(col, new LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f));
        }

        void bind(Item it, boolean current) {
            name.setText(it.name);
            sub.setText(it.epg.length() > 0 ? it.epg : it.group);
            setBackgroundColor(current ? 0x552F7DD1 : Color.TRANSPARENT);
            shown = it.logo;
            img.setImageBitmap(null);
            if (it.logo.length() == 0) return;
            Bitmap b = cache.get(it.logo);
            if (b != null) { img.setImageBitmap(b); return; }
            final String u = it.logo;
            pool.execute(() -> {
                Bitmap bm = null;
                java.io.File pf = PiconCache.get(u);
                if (pf != null) bm = BitmapFactory.decodeFile(pf.getAbsolutePath());
                if (bm == null) bm = download(u);
                if (bm == null) return;
                cache.put(u, bm);
                final Bitmap fbm = bm;
                ui.post(() -> { if (u.equals(shown)) img.setImageBitmap(fbm); });
            });
        }
    }

    private Bitmap download(String u) {
        HttpURLConnection c = null;
        InputStream in = null;
        try {
            c = (HttpURLConnection) new URL(u).openConnection();
            c.setConnectTimeout(6000);
            c.setReadTimeout(6000);
            c.setInstanceFollowRedirects(true);
            in = c.getInputStream();
            BitmapFactory.Options o = new BitmapFactory.Options();
            o.inSampleSize = 2;
            return BitmapFactory.decodeStream(in, null, o);
        } catch (Throwable e) {
            return null;
        } finally {
            try { if (in != null) in.close(); } catch (Throwable ignored) { }
            try { if (c != null) c.disconnect(); } catch (Throwable ignored) { }
        }
    }
}
