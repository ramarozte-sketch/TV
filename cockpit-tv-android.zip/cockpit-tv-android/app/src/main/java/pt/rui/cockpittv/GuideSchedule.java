package pt.rui.cockpittv;

import android.app.Activity;
import android.app.Dialog;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.widget.BaseAdapter;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

/**
 * Programação de um canal na tab Guia: dias em cima, programas do dia em baixo.
 * Escolher um programa mostra o detalhe, com gravar (ou cancelar a gravação) e ver o canal.
 */
final class GuideSchedule {
    private GuideSchedule() { }

    private static final Handler UI = new Handler(Looper.getMainLooper());

    static void show(final Activity act, final NativeData data, final NativeData.Item ch, final Runnable watch, final long focusAt) {
        final float den = act.getResources().getDisplayMetrics().density;
        final int ACC = NativeHomeActivity.lookAcc(), INK = NativeHomeActivity.lookInk(), TXT = NativeHomeActivity.lookTxt(),
                MUT = NativeHomeActivity.lookMut(), CARD = NativeHomeActivity.lookCard(), BG = NativeHomeActivity.lookBg(), CHIP = NativeHomeActivity.lookChip();

        final Dialog dlg = new Dialog(act, android.R.style.Theme_DeviceDefault_Dialog_NoActionBar);
        final LinearLayout root = new LinearLayout(act); root.setOrientation(LinearLayout.VERTICAL);
        int pad = dp(den, 22); root.setPadding(pad, dp(den, 18), pad, dp(den, 14));

        /* cabeçalho: logótipo, canal, ver canal */
        LinearLayout head = new LinearLayout(act); head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView logo = new ImageView(act); logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        try { android.graphics.Bitmap b = PiconCache.mem(data.logo(ch)); if (b != null) logo.setImageBitmap(b); else logo.setVisibility(View.GONE); } catch (Throwable e) { logo.setVisibility(View.GONE); }
        head.addView(logo, new LinearLayout.LayoutParams(dp(den, 72), dp(den, 44)));
        LinearLayout ht = new LinearLayout(act); ht.setOrientation(LinearLayout.VERTICAL); ht.setPadding(dp(den, 14), 0, dp(den, 10), 0);
        TextView title = new TextView(act); title.setText(NativeData.shownName(ch.name)); title.setTextColor(TXT); title.setTypeface(null, Typeface.BOLD);
        title.setTextSize(TypedValue.COMPLEX_UNIT_SP, 21); title.setSingleLine(true); title.setEllipsize(TextUtils.TruncateAt.END);
        final TextView sub = new TextView(act); sub.setText(Tr.t("Programação")); sub.setTextColor(MUT); sub.setTextSize(TypedValue.COMPLEX_UNIT_SP, 14);
        ht.addView(title); ht.addView(sub);
        head.addView(ht, new LinearLayout.LayoutParams(0, -2, 1));
        final TextView watchBtn = chip(act, den, Tr.t("▶ Ver canal"), ACC, INK, CHIP, TXT, true);
        watchBtn.setOnClickListener(v -> { dlg.dismiss(); if (watch != null) watch.run(); });
        head.addView(watchBtn);
        root.addView(head);

        /* dias */
        final HorizontalScrollView dayScroll = new HorizontalScrollView(act); dayScroll.setHorizontalScrollBarEnabled(false);
        final LinearLayout days = new LinearLayout(act); days.setPadding(0, dp(den, 14), 0, dp(den, 10));
        dayScroll.addView(days); root.addView(dayScroll);

        /* programas */
        final ProgressBar wait = new ProgressBar(act); root.addView(wait, new LinearLayout.LayoutParams(-2, dp(den, 40)));
        final TextView empty = new TextView(act); empty.setTextColor(MUT); empty.setTextSize(TypedValue.COMPLEX_UNIT_SP, 15); empty.setVisibility(View.GONE); empty.setPadding(0, dp(den, 10), 0, dp(den, 10));
        root.addView(empty);
        final ListView lv = new ListView(act); lv.setDivider(null); lv.setDividerHeight(dp(den, 6)); lv.setItemsCanFocus(false);
        lv.setSelector(new android.graphics.drawable.ColorDrawable(0));
        root.addView(lv, new LinearLayout.LayoutParams(-1, 0, 1));

        final List<NativeData.Prog> shown = new ArrayList<>();
        final BaseAdapter ad = new BaseAdapter() {
            @Override public int getCount() { return shown.size(); }
            @Override public Object getItem(int i) { return shown.get(i); }
            @Override public long getItemId(int i) { return i; }
            @Override public View getView(int i, View cv, ViewGroup parent) {
                LinearLayout row; TextView tm, ti, de;
                if (cv == null) {
                    row = new LinearLayout(act); row.setGravity(Gravity.CENTER_VERTICAL); row.setPadding(dp(den, 16), dp(den, 12), dp(den, 16), dp(den, 12));
                    row.setBackground(rowBg(den, CARD, ACC));
                    tm = new TextView(act); tm.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16); tm.setTypeface(Typeface.MONOSPACE, Typeface.BOLD); tm.setMinWidth(dp(den, 120));
                    LinearLayout col = new LinearLayout(act); col.setOrientation(LinearLayout.VERTICAL); col.setPadding(dp(den, 12), 0, 0, 0);
                    ti = new TextView(act); ti.setTextSize(TypedValue.COMPLEX_UNIT_SP, 17); ti.setTypeface(null, Typeface.BOLD); ti.setSingleLine(true); ti.setEllipsize(TextUtils.TruncateAt.END);
                    de = new TextView(act); de.setTextSize(TypedValue.COMPLEX_UNIT_SP, 13); de.setMaxLines(1); de.setEllipsize(TextUtils.TruncateAt.END);
                    col.addView(ti); col.addView(de);
                    row.addView(tm); row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
                    row.setTag(new TextView[]{tm, ti, de});
                } else row = (LinearLayout) cv;
                TextView[] t = (TextView[]) row.getTag(); tm = t[0]; ti = t[1]; de = t[2];
                NativeData.Prog p = shown.get(i);
                long now = System.currentTimeMillis();
                boolean live = p.start <= now && now < p.end, past = p.end <= now;
                boolean rec = Recorder.has(act, ch.url, p.start);
                tm.setText(Epg.hm(p.start) + "–" + Epg.hm(p.end));
                tm.setTextColor(live ? ACC : past ? MUT : TXT);
                String pre = (rec ? "⏺ " : "") + (live ? "● " + Tr.t("Agora") + " · " : "");
                ti.setText(pre + p.title); ti.setTextColor(past ? MUT : TXT);
                String d0 = p.desc == null ? "" : p.desc;
                if (live) { int pc = Math.round(100f * (now - p.start) / Math.max(1, p.end - p.start)); d0 = pc + "% · " + Tr.t("faltam ") + Math.max(1, (p.end - now) / 60000) + Tr.t(" min") + (d0.isEmpty() ? "" : " · " + d0); }
                de.setText(d0); de.setTextColor(MUT); de.setVisibility(d0.isEmpty() ? View.GONE : View.VISIBLE);
                row.setAlpha(past ? 0.6f : 1f);
                return row;
            }
        };
        lv.setAdapter(ad);

        final List<NativeData.Prog> all = new ArrayList<>();
        final List<Long> dayKeys = new ArrayList<>();
        final long[] curDay = {-1};
        final Runnable[] fill = new Runnable[1];
        fill[0] = () -> {
            shown.clear();
            for (NativeData.Prog p : all) if (dayOf(p.start) == curDay[0] || (dayOf(p.end - 1) == curDay[0] && dayOf(p.start) < curDay[0])) shown.add(p);
            ad.notifyDataSetChanged();
            for (int i = 0; i < days.getChildCount(); i++) paintChip((TextView) days.getChildAt(i), den, dayKeys.get(i) == curDay[0], ACC, INK, CHIP, TXT);
            empty.setVisibility(shown.isEmpty() ? View.VISIBLE : View.GONE);
            empty.setText(Tr.t("Sem programação para este dia."));
            /* posiciona no programa a dar (ou no pedido pela pesquisa) */
            long target = focusAt > 0 && dayOf(focusAt) == curDay[0] ? focusAt : System.currentTimeMillis();
            int sel = 0;
            for (int i = 0; i < shown.size(); i++) if (shown.get(i).end > target) { sel = i; break; }
            final int fs = sel;
            lv.post(() -> { lv.setSelection(Math.max(0, fs - 1)); });
        };

        lv.setOnItemClickListener((p, v, pos, id) -> {
            if (pos < 0 || pos >= shown.size()) return;
            detail(act, data, ch, shown.get(pos), () -> { dlg.dismiss(); if (watch != null) watch.run(); }, ad::notifyDataSetChanged);
        });

        dlg.setContentView(root);
        dlg.setOnShowListener(x -> {
            Window w = dlg.getWindow();
            if (w == null) return;
            GradientDrawable g = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{(CARD & 0x00FFFFFF) | 0xF8000000, (BG & 0x00FFFFFF) | 0xFA000000});
            g.setCornerRadius(18 * den); g.setStroke(Math.max(1, Math.round(1.5f * den)), (ACC & 0x00FFFFFF) | 0x66000000);
            w.setBackgroundDrawable(g); w.setDimAmount(0.6f);
            android.util.DisplayMetrics dm = act.getResources().getDisplayMetrics();
            w.setLayout(Math.min(dp(den, 1100), (int) (dm.widthPixels * 0.94f)), (int) (dm.heightPixels * 0.88f));
        });
        dlg.show();

        /* lê a programação: guia guardado; sem ele, pede ao servidor */
        new Thread(() -> {
            List<NativeData.Prog> ps = Epg.progsAll(ch);
            if (ps.isEmpty()) { try { ps = data.epgFull(ch); } catch (Throwable ignored) { } }
            if (ps.isEmpty()) { try { data.nowNext(ch); ps = Epg.progsAll(ch); } catch (Throwable ignored) { } }
            final List<NativeData.Prog> fp = ps;
            UI.post(() -> {
                if (!dlg.isShowing()) return;
                wait.setVisibility(View.GONE);
                all.clear(); all.addAll(fp);
                if (all.isEmpty()) {
                    empty.setText(Tr.t("Este canal não tem programação no guia."));
                    empty.setVisibility(View.VISIBLE); watchBtn.requestFocus(); return;
                }
                java.util.LinkedHashSet<Long> ks = new java.util.LinkedHashSet<>();
                for (NativeData.Prog p : all) ks.add(dayOf(p.start));
                dayKeys.clear(); dayKeys.addAll(ks);
                long today = dayOf(System.currentTimeMillis());
                curDay[0] = focusAt > 0 && ks.contains(dayOf(focusAt)) ? dayOf(focusAt) : ks.contains(today) ? today : dayKeys.get(0);
                days.removeAllViews();
                for (final Long k : dayKeys) {
                    TextView c = chip(act, den, Epg.day(k + 12 * 3600_000L), ACC, INK, CHIP, TXT, false);
                    c.setOnClickListener(v -> { curDay[0] = k; fill[0].run(); });
                    c.setOnFocusChangeListener((v, has) -> { if (has && curDay[0] != k) { curDay[0] = k; fill[0].run(); } });
                    LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dp(den, 10);
                    days.addView(c, lp);
                }
                sub.setText(Tr.t("Programação") + " · " + all.size() + Tr.t(" programas"));
                fill[0].run();
                lv.requestFocus();
            });
        }).start();
    }

    /** Detalhe de um programa: horas, descrição, gravar / cancelar gravação, ver o canal. */
    private static void detail(final Activity act, final NativeData data, final NativeData.Item ch, final NativeData.Prog p, final Runnable watch, final Runnable changed) {
        long now = System.currentTimeMillis();
        boolean live = p.start <= now && now < p.end, past = p.end <= now;
        final boolean rec = Recorder.has(act, ch.url, p.start);
        StringBuilder m = new StringBuilder();
        m.append(Epg.day(p.start)).append(" · ").append(Epg.hm(p.start)).append("–").append(Epg.hm(p.end))
                .append(" (").append(Math.max(1, (p.end - p.start) / 60000)).append(Tr.t(" min")).append(")\n").append(NativeData.shownName(ch.name));
        if (live) m.append("\n\n● ").append(Tr.t("A dar agora")).append(" · ").append(Tr.t("faltam ")).append(Math.max(1, (p.end - now) / 60000)).append(Tr.t(" min"));
        if (rec) m.append("\n\n⏺ ").append(Tr.t("Já está marcado para gravar."));
        if (p.desc != null && !p.desc.isEmpty()) m.append("\n\n").append(p.desc);
        android.app.AlertDialog.Builder b = NativeHomeActivity.dlg(act).setTitle(p.title).setMessage(m.toString());
        if (rec) b.setPositiveButton(Tr.t("Cancelar gravação"), (d, w) -> { Recorder.remove(act, Recorder.idOf(ch.url, p.start), false); if (changed != null) changed.run(); });
        else if (!past) b.setPositiveButton(live ? Tr.t("⏺ Gravar o resto") : Tr.t("⏺ Gravar"), (d, w) -> GuideRecUi.askRecord(act, ch, p, changed));
        if (live) b.setNeutralButton(Tr.t("▶ Ver canal"), (d, w) -> { if (watch != null) watch.run(); });
        b.setNegativeButton(Tr.t("Fechar"), null).show();
    }

    private static long dayOf(long t) {
        Calendar c = Calendar.getInstance(); c.setTimeInMillis(t);
        c.set(Calendar.HOUR_OF_DAY, 0); c.set(Calendar.MINUTE, 0); c.set(Calendar.SECOND, 0); c.set(Calendar.MILLISECOND, 0);
        return c.getTimeInMillis();
    }
    private static int dp(float den, float v) { return Math.round(v * den); }

    private static TextView chip(Activity act, float den, String text, int acc, int ink, int chip, int txt, boolean primary) {
        TextView t = new TextView(act); t.setText(text); t.setTextSize(TypedValue.COMPLEX_UNIT_SP, 16); t.setTypeface(null, Typeface.BOLD);
        t.setPadding(dp(den, 18), dp(den, 9), dp(den, 18), dp(den, 9)); t.setFocusable(true); t.setClickable(true); t.setGravity(Gravity.CENTER);
        paintChip(t, den, primary, acc, ink, chip, txt);
        return t;
    }
    private static void paintChip(TextView t, float den, boolean on, int acc, int ink, int chip, int txt) {
        GradientDrawable base = new GradientDrawable(); base.setCornerRadius(22 * den); base.setColor(on ? acc : chip);
        GradientDrawable foc = new GradientDrawable(); foc.setCornerRadius(22 * den); foc.setColor(on ? acc : chip); foc.setStroke(Math.round(3 * den), txt);
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_focused}, foc); s.addState(new int[]{}, base);
        t.setBackground(s); t.setTextColor(on ? ink : txt);
    }
    private static StateListDrawable rowBg(float den, int card, int acc) {
        GradientDrawable base = new GradientDrawable(); base.setCornerRadius(12 * den); base.setColor(card);
        GradientDrawable foc = new GradientDrawable(); foc.setCornerRadius(12 * den); foc.setColor((acc & 0x00FFFFFF) | 0x40000000); foc.setStroke(Math.round(2 * den), acc);
        StateListDrawable s = new StateListDrawable();
        s.addState(new int[]{android.R.attr.state_selected}, foc); s.addState(new int[]{android.R.attr.state_pressed}, foc); s.addState(new int[]{android.R.attr.state_focused}, foc);
        s.addState(new int[]{}, base);
        return s;
    }
}
