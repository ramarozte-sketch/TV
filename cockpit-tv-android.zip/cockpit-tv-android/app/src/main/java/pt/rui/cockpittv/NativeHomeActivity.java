package pt.rui.cockpittv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * App nativa (v270): Início, canais, filmes, séries, favoritos, vistos, pesquisa e definições, sem WebView.
 * Atividade separada e opcional (ícone «Cockpit TV Nativo»): a app clássica continua igual.
 * A reprodução usa o mesmo leitor (NativePlayer) e o mesmo ecrã de canal (NativeScreen) da app clássica.
 */
public class NativeHomeActivity extends Activity {
    private static final int BG = 0xFF0B0F14, PANEL = 0xFF121922, CARD = 0xFF18212C, ACC = 0xFF3EA6FF, TXT = 0xFFE8EEF4, MUT = 0xFF8A9AAA;
    private static final String[] TAB_ID = {"live", "movie", "series", "fav", "recent", "search", "settings", "classic"};
    private static final String[] TAB_L = {"📺 Canais", "🎬 Filmes", "🎞️ Séries", "★ Favoritos", "🕘 Vistos", "🔍 Pesquisar", "⚙️ Definições", "↩ App clássica"};

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newFixedThreadPool(2);
    private final ExecutorService img = Executors.newFixedThreadPool(6);
    private final LruCache<String, Bitmap> bmp = new LruCache<String, Bitmap>(24 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };

    private NativeData data;
    private FrameLayout root;
    private LinearLayout body;
    private final TextView[] tabs = new TextView[TAB_ID.length];
    private ListView catList;
    private GridView grid;
    private TextView status;
    private ProgressBar spin;
    private EditText searchBox;
    private View settingsView;

    private String tab = "live";
    private List<NativeData.Cat> curCats = new ArrayList<>();
    private int curCat = 0;
    private List<NativeData.Item> curItems = new ArrayList<>();
    /** série aberta (temporadas na coluna, episódios na grelha); null fora das séries */
    private NativeData.Item openSeries = null;
    private int seriesCatBefore = 0, seriesPosBefore = 0;
    private int loadSeq = 0;

    private NativePlayer np;
    private NativeScreen nscr;
    private List<NativeData.Item> playing = new ArrayList<>();
    private String navBefore = null;

    private int dp(float v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override
    protected void attachBaseContext(android.content.Context base) {
        try {
            float sc = MainActivity.uiScaleOf(base);
            if (Math.abs(sc - 1f) > 0.01f) {
                android.content.res.Configuration cfg = new android.content.res.Configuration(base.getResources().getConfiguration());
                cfg.densityDpi = Math.round(cfg.densityDpi * sc);
                super.attachBaseContext(base.createConfigurationContext(cfg));
                return;
            }
        } catch (Throwable ignored) { }
        super.attachBaseContext(base);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        PiconCache.init(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        data = new NativeData(this);
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root);
        buildUi();
        String last = getSharedPreferences("nativeapp", 0).getString("tab", "live");
        if (!data.configured()) last = "settings";
        else if (last.equals("settings") || last.equals("classic") || last.equals("search")) last = "live";
        showTab(last);
    }

    /* ------------------------------------------------------------ interface */
    private StateListDrawable sel(int base, int radius) {
        StateListDrawable s = new StateListDrawable();
        GradientDrawable f = new GradientDrawable(); f.setColor(0xFF22364A); f.setStroke(dp(2), ACC); f.setCornerRadius(dp(radius));
        GradientDrawable p = new GradientDrawable(); p.setColor(0xFF1E3044); p.setCornerRadius(dp(radius));
        GradientDrawable n = new GradientDrawable(); n.setColor(base); n.setCornerRadius(dp(radius));
        s.addState(new int[]{android.R.attr.state_focused}, f);
        s.addState(new int[]{android.R.attr.state_selected}, f);
        s.addState(new int[]{android.R.attr.state_pressed}, p);
        s.addState(new int[]{}, n);
        return s;
    }

    private void buildUi() {
        LinearLayout col = new LinearLayout(this);
        col.setOrientation(LinearLayout.VERTICAL);
        root.addView(col, new FrameLayout.LayoutParams(-1, -1));

        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false);
        LinearLayout bar = new LinearLayout(this);
        bar.setPadding(dp(10), dp(8), dp(10), dp(6));
        for (int i = 0; i < TAB_ID.length; i++) {
            final String id = TAB_ID[i];
            TextView t = new TextView(this);
            t.setText(TAB_L[i]); t.setTextColor(TXT); t.setTextSize(15); t.setGravity(Gravity.CENTER);
            t.setPadding(dp(16), dp(9), dp(16), dp(9));
            t.setBackground(sel(0x00000000, 20));
            t.setFocusable(true); t.setClickable(true);
            t.setOnClickListener(v -> showTab(id));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dp(6);
            bar.addView(t, lp);
            tabs[i] = t;
        }
        hs.addView(bar);
        col.addView(hs, new LinearLayout.LayoutParams(-1, -2));

        LinearLayout st = new LinearLayout(this);
        st.setGravity(Gravity.CENTER_VERTICAL);
        st.setPadding(dp(16), 0, dp(16), dp(4));
        spin = new ProgressBar(this); spin.setIndeterminate(true); spin.setVisibility(View.GONE);
        st.addView(spin, new LinearLayout.LayoutParams(dp(18), dp(18)));
        status = new TextView(this); status.setTextColor(MUT); status.setTextSize(12.5f); status.setPadding(dp(8), 0, 0, 0);
        status.setSingleLine(true); status.setEllipsize(TextUtils.TruncateAt.END);
        st.addView(status, new LinearLayout.LayoutParams(0, -2, 1));
        col.addView(st, new LinearLayout.LayoutParams(-1, -2));

        searchBox = new EditText(this);
        searchBox.setHint("Nome do canal, filme ou série…"); searchBox.setHintTextColor(MUT); searchBox.setTextColor(TXT);
        searchBox.setSingleLine(true); searchBox.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchBox.setBackground(sel(CARD, 10)); searchBox.setPadding(dp(14), dp(10), dp(14), dp(10));
        searchBox.setVisibility(View.GONE);
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) { ui.removeCallbacks(doSearch); ui.postDelayed(doSearch, 350); }
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2); slp.setMargins(dp(14), dp(2), dp(14), dp(8));
        col.addView(searchBox, slp);

        body = new LinearLayout(this);
        col.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));

        catList = new ListView(this);
        catList.setDivider(null); catList.setSelector(sel(0x00000000, 10)); catList.setDrawSelectorOnTop(false);
        catList.setBackgroundColor(PANEL); catList.setPadding(dp(6), dp(6), dp(6), dp(6)); catList.setClipToPadding(false);
        catList.setAdapter(catAdapter);
        catList.setOnItemClickListener((p, v, pos, id) -> pickCat(pos, true));
        catList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                /* comando da TV: percorrer as categorias já mostra os itens (com um pequeno atraso para não pesar) */
                final int ps = pos; ui.removeCallbacks(catSelRun); catSelRun = () -> pickCat(ps, false); ui.postDelayed(catSelRun, 220);
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
        body.addView(catList, new LinearLayout.LayoutParams(dp(250), -1));

        grid = new GridView(this);
        grid.setSelector(sel(0x00000000, 10)); grid.setDrawSelectorOnTop(false);
        grid.setPadding(dp(10), dp(6), dp(10), dp(10)); grid.setClipToPadding(false);
        grid.setVerticalSpacing(dp(8)); grid.setHorizontalSpacing(dp(8));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setAdapter(gridAdapter);
        grid.setOnItemClickListener((p, v, pos, id) -> onItem(pos));
        grid.setOnItemLongClickListener((p, v, pos, id) -> { itemMenu(pos); return true; });
        body.addView(grid, new LinearLayout.LayoutParams(0, -1, 1));
    }

    private Runnable catSelRun = () -> { };
    private final Runnable doSearch = () -> runSearch();

    private void setStatus(String s, boolean busy) { status.setText(s); spin.setVisibility(busy ? View.VISIBLE : View.GONE); }

    private void markTabs() {
        for (int i = 0; i < TAB_ID.length; i++) {
            boolean on = TAB_ID[i].equals(tab);
            tabs[i].setTextColor(on ? ACC : TXT);
            tabs[i].setTypeface(null, on ? Typeface.BOLD : Typeface.NORMAL);
        }
    }

    /* ------------------------------------------------------------ separadores */
    private void showTab(String id) {
        if ("classic".equals(id)) { openClassic(); return; }
        tab = id;
        openSeries = null;
        loadSeq++;
        getSharedPreferences("nativeapp", 0).edit().putString("tab", id).apply();
        markTabs();
        if (settingsView != null) { body.removeView(settingsView); settingsView = null; }
        catList.setVisibility(View.VISIBLE); grid.setVisibility(View.VISIBLE);
        searchBox.setVisibility(View.GONE);
        curCats = new ArrayList<>(); curItems = new ArrayList<>(); catAdapter.notifyDataSetChanged(); gridAdapter.notifyDataSetChanged();
        switch (id) {
            case "live": case "movie": case "series": loadKind(id, false); break;
            case "fav": case "recent": showFlat(id); break;
            case "search":
                catList.setVisibility(View.GONE);
                searchBox.setVisibility(View.VISIBLE);
                searchBox.requestFocus();
                ensureAllLoaded(() -> runSearch());
                break;
            case "settings": showSettings(); break;
        }
    }

    private void loadKind(final String kind, final boolean force) {
        if (!data.configured()) { setStatus("Sem lista configurada — abre ⚙️ Definições.", false); return; }
        final int seq = ++loadSeq;
        setStatus(force ? "A atualizar a lista…" : "A carregar…", true);
        bg.execute(() -> {
            String err = null;
            try { data.load(kind, force); } catch (Throwable e) { err = e.getMessage() == null ? String.valueOf(e) : e.getMessage(); }
            final String fe = err;
            ui.post(() -> {
                if (seq != loadSeq || !kind.equals(tab)) return;
                if (fe != null) { setStatus("Erro: " + fe, false); return; }
                List<NativeData.Cat> c = data.cats.get(kind);
                curCats = c == null ? new ArrayList<>() : c;
                catAdapter.notifyDataSetChanged();
                int saved = getSharedPreferences("nativeapp", 0).getInt("cat_" + kind, 0);
                pickCat(Math.max(0, Math.min(saved, curCats.size() - 1)), false);
                catList.setSelection(curCat);
                int n = 0; for (NativeData.Cat x : curCats) n += x.items.size();
                setStatus(curCats.size() + " categorias · " + n + (kind.equals("live") ? " canais" : kind.equals("movie") ? " filmes" : " séries") + "   ·   OK longo / Menu: favorito", false);
                if (!data.cacheFresh(kind) && !force) loadKind(kind, true);   /* lista guardada antiga: mostra-a e renova por trás */
            });
        });
    }

    private void ensureAllLoaded(final Runnable after) {
        if (!data.configured()) return;
        setStatus("A preparar a pesquisa…", true);
        final int seq = loadSeq;
        bg.execute(() -> {
            for (String k : new String[]{"live", "movie", "series"}) { try { data.load(k, false); } catch (Throwable ignored) { } }
            ui.post(() -> { if (seq == loadSeq) { setStatus("", false); after.run(); } });
        });
    }

    private void showFlat(final String id) {
        catList.setVisibility(View.GONE);
        if ("recent".equals(id)) {
            curItems = data.recents();
            gridAdapter.notifyDataSetChanged(); setColumns(); grid.setSelection(0);
            setStatus(curItems.isEmpty() ? "Ainda não viste nada nesta app." : curItems.size() + " vistos recentemente", false);
            return;
        }
        ensureAllLoaded(() -> {
            if (!"fav".equals(tab)) return;
            curItems = data.favItems();
            gridAdapter.notifyDataSetChanged(); setColumns(); grid.setSelection(0);
            setStatus(curItems.isEmpty() ? "Sem favoritos. Mantém OK (ou Menu) num canal para o marcar." : curItems.size() + " favoritos", false);
        });
    }

    private void runSearch() {
        if (!"search".equals(tab)) return;
        String q = searchBox.getText().toString();
        curItems = data.search(q);
        gridAdapter.notifyDataSetChanged(); setColumns();
        setStatus(q.trim().length() < 2 ? "Escreve pelo menos 2 letras." : curItems.size() + " resultados", false);
    }

    private void pickCat(int pos, boolean focusGrid) {
        if (pos < 0 || pos >= curCats.size()) return;
        boolean same = pos == curCat && !curItems.isEmpty() && curItems == curCats.get(pos).items;
        curCat = pos;
        if (openSeries == null) getSharedPreferences("nativeapp", 0).edit().putInt("cat_" + tab, pos).apply();
        catAdapter.notifyDataSetChanged();
        if (!same) {
            curItems = curCats.get(pos).items;
            gridAdapter.notifyDataSetChanged(); setColumns();
            grid.setSelection(openSeries == null ? getSharedPreferences("nativeapp", 0).getInt("pos_" + tab + "_" + pos, 0) : 0);
        }
        if (focusGrid) grid.requestFocus();
    }

    private boolean posterMode() {
        if (curItems.isEmpty()) return !"live".equals(tab);
        String k = curItems.get(0).kind;
        return "movie".equals(k) || "series".equals(k) || "vod".equals(k);
    }

    private void setColumns() {
        if (posterMode()) { grid.setColumnWidth(dp(132)); grid.setNumColumns(GridView.AUTO_FIT); }
        else { grid.setColumnWidth(dp(300)); grid.setNumColumns(GridView.AUTO_FIT); }
    }

    /* ------------------------------------------------------------ adaptadores */
    private final BaseAdapter catAdapter = new BaseAdapter() {
        @Override public int getCount() { return curCats.size(); }
        @Override public Object getItem(int i) { return curCats.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public View getView(int i, View v, ViewGroup p) {
            TextView t = (TextView) v;
            if (t == null) {
                t = new TextView(NativeHomeActivity.this);
                t.setTextSize(14); t.setPadding(dp(12), dp(10), dp(10), dp(10));
                t.setSingleLine(true); t.setEllipsize(TextUtils.TruncateAt.END);
            }
            NativeData.Cat c = curCats.get(i);
            t.setText(c.name + "  ·  " + c.items.size());
            t.setTextColor(i == curCat ? ACC : TXT);
            t.setTypeface(null, i == curCat ? Typeface.BOLD : Typeface.NORMAL);
            return t;
        }
    };

    private static final class Holder { ImageView im; TextView name, sub; String url; boolean poster; }

    private final BaseAdapter gridAdapter = new BaseAdapter() {
        @Override public int getCount() { return curItems.size(); }
        @Override public Object getItem(int i) { return curItems.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public int getItemViewType(int i) { return isPoster(curItems.get(i)) ? 1 : 0; }
        @Override public View getView(int i, View v, ViewGroup p) {
            NativeData.Item it = curItems.get(i);
            boolean poster = isPoster(it);
            Holder h = v == null ? null : (Holder) v.getTag();
            if (h == null || h.poster != poster) { v = poster ? makePoster() : makeRow(); h = (Holder) v.getTag(); }
            boolean fav = data.isFav(it.url);
            h.name.setText((fav ? "★ " : "") + it.name);
            if (poster) {
                String s = it.year.length() > 0 ? it.year : "";
                if (it.rating.length() > 0 && !"0".equals(it.rating)) s += (s.isEmpty() ? "" : " · ") + "★ " + it.rating;
                if ("movie".equals(it.kind) && data.pos(it.url) > 0) s += (s.isEmpty() ? "" : " · ") + "▶ continuar";
                h.sub.setText(s); h.sub.setVisibility(s.isEmpty() ? View.GONE : View.VISIBLE);
            } else {
                String s = "search".equals(tab) || "fav".equals(tab) || "recent".equals(tab) ? kindLabel(it) + it.group : (it.num > 0 ? "#" + it.num : "");
                if ("episode".equals(it.kind) && data.pos(it.url) > 0) s = "▶ continuar";
                h.sub.setText(s); h.sub.setVisibility(s.isEmpty() ? View.GONE : View.VISIBLE);
            }
            loadImg(h, it.logo);
            return v;
        }
    };

    private boolean isPoster(NativeData.Item it) { return "movie".equals(it.kind) || "series".equals(it.kind) || "vod".equals(it.kind); }
    private String kindLabel(NativeData.Item it) { return "live".equals(it.kind) ? "📺 " : "series".equals(it.kind) ? "🎞️ " : "episode".equals(it.kind) ? "🎞️ " : "🎬 "; }

    private View makeRow() {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(10), dp(8), dp(10), dp(8));
        r.setBackground(roundRect(CARD, 10));
        Holder h = new Holder();
        h.im = new ImageView(this); h.im.setScaleType(ImageView.ScaleType.FIT_CENTER);
        r.addView(h.im, new LinearLayout.LayoutParams(dp(64), dp(40)));
        LinearLayout tx = new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.setPadding(dp(12), 0, 0, 0);
        h.name = new TextView(this); h.name.setTextColor(TXT); h.name.setTextSize(15); h.name.setSingleLine(true); h.name.setEllipsize(TextUtils.TruncateAt.END);
        h.sub = new TextView(this); h.sub.setTextColor(MUT); h.sub.setTextSize(12); h.sub.setSingleLine(true); h.sub.setEllipsize(TextUtils.TruncateAt.END);
        tx.addView(h.name); tx.addView(h.sub);
        r.addView(tx, new LinearLayout.LayoutParams(0, -2, 1));
        r.setTag(h);
        return r;
    }

    private View makePoster() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(4), dp(4), dp(4), dp(6));
        Holder h = new Holder(); h.poster = true;
        h.im = new ImageView(this); h.im.setScaleType(ImageView.ScaleType.CENTER_CROP);
        h.im.setBackground(roundRect(CARD, 8)); h.im.setClipToOutline(true);
        r.addView(h.im, new LinearLayout.LayoutParams(-1, dp(178)));
        h.name = new TextView(this); h.name.setTextColor(TXT); h.name.setTextSize(13); h.name.setMaxLines(2); h.name.setEllipsize(TextUtils.TruncateAt.END);
        h.name.setPadding(dp(2), dp(5), dp(2), 0);
        h.sub = new TextView(this); h.sub.setTextColor(MUT); h.sub.setTextSize(11.5f); h.sub.setSingleLine(true); h.sub.setPadding(dp(2), 0, dp(2), 0);
        r.addView(h.name); r.addView(h.sub);
        r.setTag(h);
        return r;
    }

    private GradientDrawable roundRect(int c, int r) { GradientDrawable g = new GradientDrawable(); g.setColor(c); g.setCornerRadius(dp(r)); return g; }

    private void loadImg(final Holder h, final String url) {
        h.url = url;
        if (url == null || url.isEmpty() || !url.startsWith("http")) { h.im.setImageBitmap(null); return; }
        Bitmap c = bmp.get(url);
        if (c != null) { h.im.setImageBitmap(c); return; }
        h.im.setImageBitmap(null);
        if (PiconCache.knownBad(url)) return;
        img.execute(() -> {
            if (!url.equals(h.url)) return;   /* a célula já mostra outro item (deslizou) */
            Bitmap b = null;
            try { File f = PiconCache.get(url); if (f != null) b = BitmapFactory.decodeFile(f.getAbsolutePath()); } catch (Throwable ignored) { }
            final Bitmap fb = b;
            if (fb != null) bmp.put(url, fb);
            ui.post(() -> { if (url.equals(h.url)) h.im.setImageBitmap(fb); });
        });
    }

    /* ------------------------------------------------------------ ações nos itens */
    private void onItem(int pos) {
        if (pos < 0 || pos >= curItems.size()) return;
        NativeData.Item it = curItems.get(pos);
        if (openSeries == null && ("live".equals(tab) || "movie".equals(tab) || "series".equals(tab)))
            getSharedPreferences("nativeapp", 0).edit().putInt("pos_" + tab + "_" + curCat, pos).apply();
        if ("series".equals(it.kind)) { openSeries(it); return; }
        play(curItems, pos);
    }

    private void itemMenu(int pos) {
        if (pos < 0 || pos >= curItems.size()) return;
        final NativeData.Item it = curItems.get(pos);
        boolean fav = data.isFav(it.url);
        String[] opts = {fav ? "Tirar dos favoritos" : "Juntar aos favoritos", "Ver"};
        new AlertDialog.Builder(this).setTitle(it.name).setItems(opts, (d, w) -> {
            if (w == 0) {
                boolean on = data.toggleFav(it);
                Toast.makeText(this, on ? "★ Nos favoritos" : "Fora dos favoritos", Toast.LENGTH_SHORT).show();
                if ("fav".equals(tab)) showFlat("fav"); else gridAdapter.notifyDataSetChanged();
            } else onItem(pos);
        }).show();
    }

    private void openSeries(final NativeData.Item s) {
        final int seq = ++loadSeq;
        setStatus("A abrir «" + s.name + "»…", true);
        bg.execute(() -> {
            List<NativeData.Cat> seasons = null; String err = null;
            try { seasons = data.seriesInfo(s, false); } catch (Throwable e) { err = String.valueOf(e.getMessage()); }
            final List<NativeData.Cat> fs = seasons; final String fe = err;
            ui.post(() -> {
                if (seq != loadSeq) return;
                if (fs == null || fs.isEmpty()) { setStatus(fe != null ? "Erro: " + fe : "Esta série não tem episódios.", false); return; }
                seriesCatBefore = curCat; seriesPosBefore = grid.getFirstVisiblePosition();
                openSeries = s;
                curCats = fs; curItems = new ArrayList<>();
                catAdapter.notifyDataSetChanged();
                pickCat(0, true);
                catList.setSelection(0);
                setStatus("🎞️ " + s.name + " · " + fs.size() + " temporadas   ·   Voltar: lista de séries", false);
            });
        });
    }

    private void closeSeries() {
        openSeries = null;
        List<NativeData.Cat> c = data.cats.get("series");
        curCats = c == null ? new ArrayList<>() : c;
        catAdapter.notifyDataSetChanged();
        curItems = new ArrayList<>();
        pickCat(Math.min(seriesCatBefore, Math.max(0, curCats.size() - 1)), true);
        catList.setSelection(curCat);
        grid.setSelection(seriesPosBefore);
        setStatus(curCats.size() + " categorias", false);
    }

    /* ------------------------------------------------------------ reprodução (leitor e ecrã da app clássica) */
    private void play(List<NativeData.Item> list, int idx) {
        if (nscr != null && nscr.isOpen()) return;
        /* só os itens reproduzíveis, no máximo 1500 à volta do escolhido */
        List<NativeData.Item> src = new ArrayList<>(); int start = 0;
        int from = Math.max(0, idx - 750), to = Math.min(list.size(), from + 1500);
        for (int i = from; i < to; i++) { NativeData.Item it = list.get(i); if ("series".equals(it.kind) || it.url.startsWith("series:")) continue; if (i == idx) start = src.size(); src.add(it); }
        if (src.isEmpty()) return;
        JSONArray a = new JSONArray();
        for (NativeData.Item it : src) {
            try {
                JSONObject o = new JSONObject();
                o.put("name", it.name); o.put("logo", it.logo); o.put("group", it.group); o.put("url", it.url);
                o.put("kind", "live".equals(it.kind) ? "live" : "movie");
                long p = "live".equals(it.kind) ? 0 : data.pos(it.url);
                if (p > 0) o.put("start", p);
                a.put(o);
            } catch (Throwable ignored) { }
        }
        playing = src;
        try {
            if (np == null) np = new NativePlayer(this, root, (k, m) -> playerEvent(k, m));
            /* o ecrã de canal usa as abas da app clássica quando existem; aqui usa as simples (Início, Explorar, Guia, Definições) */
            navBefore = MainActivity.NAV_JSON; MainActivity.NAV_JSON = "";
            nscr = new NativeScreen(this, root, np, (k, m) -> runOnUiThread(() -> onScreen(k, m)));
            nscr.open(a.toString(), start);
            if (nscr.isOpen()) nscr.command("full", "");
        } catch (Throwable e) {
            Toast.makeText(this, "Não consegui abrir: " + e, Toast.LENGTH_LONG).show();
        }
    }

    private void playerEvent(String k, String m) {
        NativeScreen s = nscr;
        if (s != null && s.isOpen()) s.onPlayerEvent(k, m);
    }

    private NativeData.Item playingByUrl(String url) { for (NativeData.Item it : playing) if (it.url.equals(url)) return it; return null; }

    private void onScreen(String k, String m) {
        switch (k) {
            case "nscreen:play": {
                NativeData.Item it = playingByUrl(m);
                if (it != null) { data.pushRecent(it); if ("live".equals(it.kind)) fetchEpg(it); }
                break;
            }
            case "nscreen:pos": {
                String[] p = m.split("\\|");
                if (p.length >= 3) try { data.savePos(p[0], Long.parseLong(p[1]), Long.parseLong(p[2])); } catch (Throwable ignored) { }
                break;
            }
            case "nscreen:closed":
                if (navBefore != null) { if (MainActivity.NAV_JSON.isEmpty()) MainActivity.NAV_JSON = navBefore; navBefore = null; }
                try { if (np != null) np.stop(); } catch (Throwable ignored) { }
                gridAdapter.notifyDataSetChanged();
                if ("recent".equals(tab)) showFlat("recent");
                grid.requestFocus();
                break;
            case "nscreen:nav":
                if ("settings".equals(m)) showTab("settings");
                else if ("tv".equals(m) || "tvhome".equals(m) || "guide".equals(m)) { if (!tab.equals("live")) showTab("live"); }
                break;
            case "nscreen:subsearch":
                Toast.makeText(this, "Legendas online: usa a app clássica.", Toast.LENGTH_SHORT).show();
                break;
            case "nscreen:act":
                Toast.makeText(this, "Disponível na app clássica.", Toast.LENGTH_SHORT).show();
                break;
        }
    }

    /** Programa a decorrer e o seguinte (Xtream), mostrado no ecrã do canal. */
    private void fetchEpg(final NativeData.Item it) {
        bg.execute(() -> {
            String t = data.nowNext(it);
            if (t.isEmpty()) return;
            ui.post(() -> {
                try { if (nscr != null && nscr.isOpen()) { JSONObject o = new JSONObject(); o.put(it.url, t); nscr.command("epg", o.toString()); } } catch (Throwable ignored) { }
            });
        });
    }

    /* ------------------------------------------------------------ definições */
    private void showSettings() {
        catList.setVisibility(View.GONE); grid.setVisibility(View.GONE);
        setStatus("", false);
        ScrollView sv = new ScrollView(this);
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(20), dp(8), dp(20), dp(30));
        sv.addView(f);

        TextView h = new TextView(this);
        h.setText("Lista IPTV"); h.setTextColor(TXT); h.setTextSize(20); h.setTypeface(null, Typeface.BOLD);
        f.addView(h);
        TextView note = new TextView(this);
        note.setText("A app nativa usa a mesma lista da app clássica. Se já a configuraste lá, carrega em «Importar da app clássica» (abre a app clássica uma vez antes, para ela partilhar os dados).");
        note.setTextColor(MUT); note.setTextSize(13); note.setPadding(0, dp(4), 0, dp(12));
        f.addView(note);

        final EditText xs = field(f, "Servidor Xtream (ex.: http://servidor:8080)", data.server, false);
        final EditText xu = field(f, "Utilizador", data.user, false);
        final EditText xp = field(f, "Palavra-passe", data.pass, true);
        final EditText mm = field(f, "…ou endereço de lista M3U", data.m3u, false);

        LinearLayout row = new LinearLayout(this); row.setPadding(0, dp(12), 0, 0);
        row.addView(btn("Guardar", v -> {
            data.saveCfg(xs.getText().toString(), xu.getText().toString(), xp.getText().toString(), mm.getText().toString());
            Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show();
            if (data.configured()) showTab("live");
        }));
        row.addView(btn("Importar da app clássica", v -> {
            if (data.importFromWeb()) { data.clearCache(); Toast.makeText(this, "Importado", Toast.LENGTH_SHORT).show(); showTab("live"); }
            else Toast.makeText(this, "Nada para importar. Abre a app clássica uma vez e volta.", Toast.LENGTH_LONG).show();
        }));
        f.addView(row);

        LinearLayout row2 = new LinearLayout(this); row2.setPadding(0, dp(8), 0, 0);
        row2.addView(btn("Atualizar listas agora", v -> { data.clearCache(); Toast.makeText(this, "As listas vão ser descarregadas de novo", Toast.LENGTH_SHORT).show(); showTab("live"); }));
        row2.addView(btn("Abrir a app clássica", v -> openClassic()));
        f.addView(row2);

        TextView ver = new TextView(this);
        String vn = ""; try { vn = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Throwable ignored) { }
        ver.setText("Cockpit TV nativo · " + vn + "\nO leitor, o ecrã total, o som (Dolby/atraso), as legendas embutidas e os gestos são os mesmos da app clássica.");
        ver.setTextColor(MUT); ver.setTextSize(12); ver.setPadding(0, dp(18), 0, 0);
        f.addView(ver);

        settingsView = sv;
        body.addView(sv, new LinearLayout.LayoutParams(-1, -1));
        (data.configured() ? row.getChildAt(0) : xs).requestFocus();
    }

    private EditText field(LinearLayout f, String hint, String val, boolean pw) {
        TextView l = new TextView(this); l.setText(hint); l.setTextColor(MUT); l.setTextSize(12.5f); l.setPadding(0, dp(8), 0, dp(3));
        f.addView(l);
        EditText e = new EditText(this);
        e.setText(val); e.setTextColor(TXT); e.setSingleLine(true);
        e.setInputType(pw ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD) : (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI));
        e.setBackground(sel(CARD, 10)); e.setPadding(dp(14), dp(10), dp(14), dp(10));
        f.addView(e, new LinearLayout.LayoutParams(-1, -2));
        return e;
    }

    private Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t); b.setAllCaps(false); b.setTextColor(TXT); b.setTextSize(14);
        b.setBackground(sel(0xFF1F2B38, 12)); b.setPadding(dp(16), dp(8), dp(16), dp(8));
        b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    private void openClassic() {
        try { startActivity(new Intent(this, MainActivity.class)); } catch (Throwable e) { Toast.makeText(this, String.valueOf(e), Toast.LENGTH_SHORT).show(); }
    }

    /* ------------------------------------------------------------ teclas, voltar e ciclo de vida */
    @Override
    public void onBackPressed() {
        if (nscr != null && nscr.isOpen()) { nscr.onBack(); return; }
        if (openSeries != null) { closeSeries(); return; }
        if (grid.hasFocus() && catList.getVisibility() == View.VISIBLE) { catList.requestFocus(); return; }
        if (!"live".equals(tab)) { showTab("live"); return; }
        super.onBackPressed();
    }

    @Override
    public boolean onKeyDown(int code, KeyEvent ev) {
        if (code == KeyEvent.KEYCODE_ESCAPE) { onBackPressed(); return true; }
        if (nscr != null && nscr.isOpen()) { if (nscr.onKey(ev)) return true; return super.onKeyDown(code, ev); }
        if (code == KeyEvent.KEYCODE_MENU || code == KeyEvent.KEYCODE_BOOKMARK) {
            if (grid.hasFocus()) { itemMenu(grid.getSelectedItemPosition()); return true; }
        }
        return super.onKeyDown(code, ev);
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        if (nscr != null && nscr.isOpen()) nscr.onConfigChanged();
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        try {
            if (android.os.Build.VERSION.SDK_INT < 26 || np == null || !np.isActive() || nscr == null || !nscr.isOpen()) return;
            android.app.UiModeManager um = (android.app.UiModeManager) getSystemService(UI_MODE_SERVICE);
            if (um != null && um.getCurrentModeType() == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION) return;
            if (!getPackageManager().hasSystemFeature(android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE)) return;
            enterPictureInPictureMode(new android.app.PictureInPictureParams.Builder().setAspectRatio(new android.util.Rational(16, 9)).build());
        } catch (Throwable ignored) { }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean in, android.content.res.Configuration cfg) {
        super.onPictureInPictureModeChanged(in, cfg);
        try { if (nscr != null && nscr.isOpen()) nscr.setSystemPip(in); } catch (Throwable ignored) { }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (np != null) np.resumeAfterBackground();
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (np != null) np.pause();
    }

    @Override
    protected void onDestroy() {
        try { if (nscr != null && nscr.isOpen()) nscr.close(); } catch (Throwable ignored) { }
        if (navBefore != null && MainActivity.NAV_JSON.isEmpty()) MainActivity.NAV_JSON = navBefore;
        if (np != null) { np.release(); np = null; }
        bg.shutdownNow(); img.shutdownNow();
        super.onDestroy();
    }
}
