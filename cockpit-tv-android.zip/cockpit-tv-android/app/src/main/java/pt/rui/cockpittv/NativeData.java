package pt.rui.cockpittv;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/**
 * App nativa (v270): dados da lista IPTV sem a página web.
 * Lê a configuração que a app clássica guardou (servidor Xtream / M3U, favoritos, vistos), descarrega as listas
 * pela API Xtream (ou M3U), guarda-as em disco (abre instantaneamente da vez seguinte) e organiza por categorias.
 * Tudo corre fora da thread da interface.
 */
final class NativeData {
    static final class Item {
        String name = "", logo = "", group = "", url = "", kind = "live", id = "", sid = "", epgId = "", plot = "", rating = "", year = "";
        int num = 0;
        JSONObject json() {
            JSONObject o = new JSONObject();
            try { o.put("name", name); o.put("logo", logo); o.put("group", group); o.put("url", url); o.put("kind", kind); o.put("id", id); o.put("sid", sid); o.put("epgId", epgId); } catch (Throwable ignored) { }
            return o;
        }
        static Item from(JSONObject o) {
            Item it = new Item();
            it.name = o.optString("name"); it.logo = o.optString("logo"); it.group = o.optString("group"); it.url = o.optString("url");
            it.kind = o.optString("kind", "live"); it.id = o.optString("id"); it.sid = o.optString("sid"); it.epgId = o.optString("epgId");
            return it;
        }
    }
    static final class Cat { String id = "", name = ""; final List<Item> items = new ArrayList<>(); }

    private static final long TTL = 12L * 3600 * 1000;
    private static final String UA = "Mozilla/5.0 (Linux; Android) CockpitTV";
    private final Context ctx;
    private final SharedPreferences sp;
    String server = "", user = "", pass = "", m3u = "";
    /** por tipo (live / movie / series): categorias por ordem, com os itens de cada uma */
    final Map<String, List<Cat>> cats = new HashMap<>();
    final Map<String, List<Item>> all = new HashMap<>();

    NativeData(Context c) {
        ctx = c.getApplicationContext();
        sp = ctx.getSharedPreferences("nativeapp", 0);
        loadCfg();
    }

    /* ------------------------------------------------------------ configuração */
    void loadCfg() {
        server = sp.getString("xs", ""); user = sp.getString("xu", ""); pass = sp.getString("xp", ""); m3u = sp.getString("m3u", "");
        /* primeira vez: vem da app clássica (a MainActivity copia o localStorage da página para «webexport») */
        if (server.isEmpty() && m3u.isEmpty()) importFromWeb();
    }
    boolean importFromWeb() {
        try {
            SharedPreferences w = ctx.getSharedPreferences("webexport", 0);
            String c = w.getString("cfg", "");
            if (c.length() < 3) return false;
            JSONObject o = new JSONObject(c);
            SharedPreferences.Editor e = sp.edit();
            e.putString("xs", o.optString("xs")).putString("xu", o.optString("xu")).putString("xp", o.optString("xp")).putString("m3u", o.optString("m3u")).putString("epg", o.optString("epg"));
            if (!sp.contains("favs")) e.putString("favs", w.getString("favs", "[]"));
            if (!sp.contains("recents")) e.putString("recents", w.getString("recents", "[]"));
            e.apply();
            server = o.optString("xs"); user = o.optString("xu"); pass = o.optString("xp"); m3u = o.optString("m3u");
            return server.length() > 0 || m3u.length() > 0;
        } catch (Throwable e) { return false; }
    }
    void saveCfg(String xs, String xu, String xp, String m) {
        sp.edit().putString("xs", xs.trim()).putString("xu", xu.trim()).putString("xp", xp).putString("m3u", m.trim()).apply();
        server = xs.trim(); user = xu.trim(); pass = xp; m3u = m.trim();
        clearCache();
    }
    boolean configured() { return (server.length() > 0 && user.length() > 0) || m3u.length() > 0; }
    private String base() {
        String s = server.trim(); if (s.isEmpty()) return "";
        if (!s.startsWith("http")) s = "http://" + s;
        s = s.replaceAll("/(player_api|get)\\.php.*$", "");
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }
    private String enc(String s) { try { return URLEncoder.encode(s, "UTF-8"); } catch (Throwable e) { return s; } }
    private String api(String action, String extra) { return base() + "/player_api.php?username=" + enc(user) + "&password=" + enc(pass) + "&action=" + action + (extra == null ? "" : extra); }

    /* ------------------------------------------------------------ rede e cache em disco */
    private File cacheFile(String k) { File d = new File(ctx.getFilesDir(), "nlist"); d.mkdirs(); return new File(d, k.replaceAll("[^a-zA-Z0-9_]", "_") + ".json"); }
    void clearCache() { try { File d = new File(ctx.getFilesDir(), "nlist"); File[] fs = d.listFiles(); if (fs != null) for (File f : fs) f.delete(); } catch (Throwable ignored) { } cats.clear(); all.clear(); }
    boolean cacheFresh(String kind) { File f = cacheFile("x_" + kind + "_streams"); return f.exists() && System.currentTimeMillis() - f.lastModified() < TTL; }

    static String http(String u, int timeoutMs) throws Exception {
        HttpURLConnection c = null;
        try {
            String cur = u;
            for (int i = 0; i < 6; i++) {
                c = (HttpURLConnection) new URL(cur).openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(timeoutMs); c.setReadTimeout(timeoutMs * 3);
                c.setRequestProperty("User-Agent", UA);
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) { String loc = c.getHeaderField("Location"); c.disconnect(); if (loc == null) break; cur = new URL(new URL(cur), loc).toString(); continue; }
                if (code >= 400) throw new Exception("HTTP " + code);
                InputStream in = c.getInputStream();
                BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"), 65536);
                StringBuilder sb = new StringBuilder(65536); char[] buf = new char[16384]; int n;
                while ((n = r.read(buf)) > 0) sb.append(buf, 0, n);
                r.close();
                return sb.toString();
            }
            throw new Exception("demasiados redirecionamentos");
        } finally { if (c != null) try { c.disconnect(); } catch (Throwable ignored) { } }
    }
    private String cached(String key, String url, boolean force) throws Exception {
        File f = cacheFile(key);
        if (!force && f.exists() && System.currentTimeMillis() - f.lastModified() < TTL) return readFile(f);
        try {
            String s = http(url, 15000);
            try (FileOutputStream o = new FileOutputStream(f)) { o.write(s.getBytes("UTF-8")); }
            return s;
        } catch (Exception e) {
            if (f.exists()) return readFile(f);   /* sem rede: usa a última lista guardada, mesmo antiga */
            throw e;
        }
    }
    private static String readFile(File f) throws Exception {
        try (FileInputStream in = new FileInputStream(f)) { byte[] b = new byte[(int) f.length()]; int o = 0, n; while (o < b.length && (n = in.read(b, o, b.length - o)) > 0) o += n; return new String(b, 0, o, "UTF-8"); }
    }

    /* ------------------------------------------------------------ carregar listas */
    /** kind: live | movie | series. Força a renovação com force=true. */
    synchronized void load(String kind, boolean force) throws Exception {
        if (!force && cats.containsKey(kind)) return;
        if (server.length() > 0 && user.length() > 0) loadXtream(kind, force);
        else if (m3u.length() > 0) loadM3u(force);
        else throw new Exception("Sem lista configurada. Abre as Definições.");
    }
    private void loadXtream(String kind, boolean force) throws Exception {
        String ca = kind.equals("live") ? "get_live_categories" : kind.equals("movie") ? "get_vod_categories" : "get_series_categories";
        String st = kind.equals("live") ? "get_live_streams" : kind.equals("movie") ? "get_vod_streams" : "get_series";
        JSONArray jc = new JSONArray(cached("x_" + kind + "_cats", api(ca, null), force));
        JSONArray js = new JSONArray(cached("x_" + kind + "_streams", api(st, null), force));
        LinkedHashMap<String, Cat> m = new LinkedHashMap<>();
        for (int i = 0; i < jc.length(); i++) { JSONObject o = jc.optJSONObject(i); if (o == null) continue; Cat c = new Cat(); c.id = o.optString("category_id"); c.name = o.optString("category_name"); m.put(c.id, c); }
        List<Item> list = new ArrayList<>(js.length());
        String b = base(), u = enc(user), p = enc(pass);
        for (int i = 0; i < js.length(); i++) {
            JSONObject o = js.optJSONObject(i); if (o == null) continue;
            Item it = new Item(); it.kind = kind; it.name = o.optString("name").trim();
            String cid = o.optString("category_id");
            Cat c = m.get(cid); if (c == null) { c = new Cat(); c.id = cid; c.name = "Sem categoria"; m.put(cid, c); }
            it.group = c.name;
            if (kind.equals("live")) {
                it.id = o.optString("stream_id"); it.logo = o.optString("stream_icon"); it.epgId = o.optString("epg_channel_id"); it.num = o.optInt("num");
                it.url = b + "/live/" + u + "/" + p + "/" + it.id + ".m3u8";
            } else if (kind.equals("movie")) {
                it.id = o.optString("stream_id"); it.logo = o.optString("stream_icon"); it.rating = o.optString("rating"); it.year = o.optString("year");
                String ext = o.optString("container_extension", "mp4"); if (ext.isEmpty()) ext = "mp4";
                it.url = b + "/movie/" + u + "/" + p + "/" + it.id + "." + ext;
            } else {
                it.sid = o.optString("series_id"); it.id = it.sid; it.logo = o.optString("cover"); it.plot = o.optString("plot"); it.rating = o.optString("rating");
                it.url = "series:" + it.sid;
            }
            c.items.add(it); list.add(it);
        }
        List<Cat> out = new ArrayList<>();
        for (Cat c : m.values()) if (!c.items.isEmpty()) out.add(c);
        cats.put(kind, out); all.put(kind, list);
    }
    private void loadM3u(boolean force) throws Exception {
        String s = cached("m3u", m3u, force);
        LinkedHashMap<String, Map<String, Cat>> byKind = new LinkedHashMap<>();
        Map<String, List<Item>> lists = new HashMap<>();
        for (String k : new String[]{"live", "movie", "series"}) { byKind.put(k, new LinkedHashMap<>()); lists.put(k, new ArrayList<>()); }
        Item pend = null;
        for (String line : s.split("\n")) {
            line = line.trim();
            if (line.startsWith("#EXTINF")) {
                pend = new Item();
                pend.logo = attr(line, "tvg-logo"); pend.group = attr(line, "group-title"); pend.epgId = attr(line, "tvg-id");
                int k = line.lastIndexOf(','); pend.name = k >= 0 ? line.substring(k + 1).trim() : "";
            } else if (pend != null && line.length() > 0 && !line.startsWith("#")) {
                pend.url = line; String l = line.toLowerCase();
                pend.kind = l.contains("/movie/") ? "movie" : l.contains("/series/") ? "series" : "live";
                if (pend.kind.equals("series")) pend.kind = "movie";   /* M3U: episódios soltos tratados como filmes */
                if (pend.group.isEmpty()) pend.group = "Sem categoria";
                Map<String, Cat> mc = byKind.get(pend.kind);
                Cat c = mc.get(pend.group); if (c == null) { c = new Cat(); c.id = pend.group; c.name = pend.group; mc.put(pend.group, c); }
                c.items.add(pend); lists.get(pend.kind).add(pend);
                pend = null;
            }
        }
        for (String k : byKind.keySet()) { cats.put(k, new ArrayList<>(byKind.get(k).values())); all.put(k, lists.get(k)); }
    }
    private static String attr(String line, String a) {
        int i = line.indexOf(a + "=\""); if (i < 0) return "";
        int s0 = i + a.length() + 2, e = line.indexOf('"', s0); return e > s0 ? line.substring(s0, e) : "";
    }

    /** Temporadas e episódios de uma série (Xtream get_series_info). */
    List<Cat> seriesInfo(Item s, boolean force) throws Exception {
        JSONObject o = new JSONObject(cached("x_series_" + s.sid, api("get_series_info", "&series_id=" + enc(s.sid)), force));
        JSONObject eps = o.optJSONObject("episodes");
        List<Cat> out = new ArrayList<>();
        if (eps == null) return out;
        List<String> keys = new ArrayList<>(); java.util.Iterator<String> itk = eps.keys(); while (itk.hasNext()) keys.add(itk.next());
        java.util.Collections.sort(keys, (a, b) -> { try { return Integer.parseInt(a) - Integer.parseInt(b); } catch (Throwable e) { return a.compareTo(b); } });
        String b = base(), u = enc(user), p = enc(pass);
        for (String k : keys) {
            JSONArray a = eps.optJSONArray(k); if (a == null) continue;
            Cat c = new Cat(); c.id = k; c.name = "Temporada " + k;
            for (int i = 0; i < a.length(); i++) {
                JSONObject e = a.optJSONObject(i); if (e == null) continue;
                Item it = new Item(); it.kind = "episode"; it.id = e.optString("id"); it.sid = s.sid;
                it.name = "T" + k + "·E" + e.optString("episode_num") + " — " + e.optString("title");
                String ext = e.optString("container_extension", "mp4"); if (ext.isEmpty()) ext = "mp4";
                it.url = b + "/series/" + u + "/" + p + "/" + it.id + "." + ext;
                JSONObject inf = e.optJSONObject("info"); it.logo = inf != null ? inf.optString("movie_image", s.logo) : s.logo; if (it.logo.isEmpty()) it.logo = s.logo;
                it.group = s.name;
                c.items.add(it);
            }
            out.add(c);
        }
        return out;
    }

    /** O que está a dar agora e a seguir (Xtream get_short_epg). */
    String nowNext(Item ch) {
        try {
            if (server.isEmpty() || ch.id.isEmpty()) return "";
            JSONObject o = new JSONObject(http(api("get_short_epg", "&stream_id=" + enc(ch.id) + "&limit=2"), 6000));
            JSONArray a = o.optJSONArray("epg_listings"); if (a == null || a.length() == 0) return "";
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < Math.min(2, a.length()); i++) {
                JSONObject e = a.getJSONObject(i);
                String t = b64(e.optString("title")), st = e.optString("start");
                String hm = st.length() >= 16 ? st.substring(11, 16) : "";
                if (sb.length() > 0) sb.append("   ·   a seguir ");
                sb.append(hm).append(" ").append(t);
            }
            return sb.toString();
        } catch (Throwable e) { return ""; }
    }
    private static String b64(String s) { try { return new String(android.util.Base64.decode(s, android.util.Base64.DEFAULT), "UTF-8"); } catch (Throwable e) { return s; } }

    /* ------------------------------------------------------------ favoritos, vistos e posição dos filmes */
    LinkedHashSet<String> favs() {
        LinkedHashSet<String> s = new LinkedHashSet<>();
        try { JSONArray a = new JSONArray(sp.getString("favs", "[]")); for (int i = 0; i < a.length(); i++) s.add(a.getString(i)); } catch (Throwable ignored) { }
        return s;
    }
    boolean isFav(String url) { return favs().contains(url); }
    boolean toggleFav(Item it) {
        LinkedHashSet<String> s = favs(); boolean on;
        if (s.contains(it.url)) { s.remove(it.url); on = false; } else { s.add(it.url); on = true; }
        sp.edit().putString("favs", new JSONArray(s).toString()).apply();
        return on;
    }
    /** Favoritos (todos os tipos), pela ordem em que foram marcados. */
    List<Item> favItems() {
        LinkedHashSet<String> s = favs(); Map<String, Item> by = new HashMap<>();
        for (List<Item> l : all.values()) for (Item it : l) if (s.contains(it.url)) by.put(it.url, it);
        List<Item> out = new ArrayList<>(); for (String u : s) { Item it = by.get(u); if (it != null) out.add(it); }
        return out;
    }
    void pushRecent(Item it) {
        try {
            JSONArray a = new JSONArray(sp.getString("recents", "[]")), b = new JSONArray();
            b.put(it.json());
            for (int i = 0; i < a.length() && b.length() < 40; i++) { JSONObject o = a.optJSONObject(i); if (o != null && !it.url.equals(o.optString("url"))) b.put(o); }
            sp.edit().putString("recents", b.toString()).apply();
        } catch (Throwable ignored) { }
    }
    List<Item> recents() {
        List<Item> out = new ArrayList<>();
        try { JSONArray a = new JSONArray(sp.getString("recents", "[]")); for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o != null && o.optString("url").length() > 0) out.add(Item.from(o)); } } catch (Throwable ignored) { }
        return out;
    }
    void savePos(String url, long pos, long dur) {
        try { JSONObject o = new JSONObject(sp.getString("pos", "{}")); if (dur > 0 && pos > dur - 120000) o.remove(url); else o.put(url, pos); sp.edit().putString("pos", o.toString()).apply(); } catch (Throwable ignored) { }
    }
    long pos(String url) { try { return new JSONObject(sp.getString("pos", "{}")).optLong(url, 0); } catch (Throwable e) { return 0; } }

    /** Pesquisa em todos os tipos já carregados (sem acentos, sem maiúsculas). */
    List<Item> search(String q) {
        String n = norm(q); List<Item> out = new ArrayList<>();
        if (n.length() < 2) return out;
        for (String k : new String[]{"live", "movie", "series"}) { List<Item> l = all.get(k); if (l == null) continue; for (Item it : l) { if (norm(it.name).contains(n)) { out.add(it); if (out.size() >= 300) return out; } } }
        return out;
    }
    static String norm(String s) { return java.text.Normalizer.normalize(s == null ? "" : s, java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase(); }
}
