#!/usr/bin/env python3
"""Gera app/src/main/assets/index.html (só IPTV) a partir do index.html do Cockpit.
Uso: python3 tools/build_assets.py [caminho/para/cockpit/index.html]"""
import sys, os
src = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), "..", "..", "cockpit", "index.html")
out = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "index.html")
h = open(src, encoding="utf-8").read()

def rep(old, new, count=1):
    global h
    if h.count(old) != count:
        sys.exit("Não encontrei (ou há repetições) de: " + old[:70])
    h = h.replace(old, new)

rep("<head>", '<head>\n<script>window.ANDROID = (typeof Android !== "undefined");</script>')
rep("<title>Cockpit", "<title>Cockpit TV")
rep('id="bootLogo">COCKPIT<', 'id="bootLogo">COCKPIT TV<')
rep("if(!url || !cfg.proxy) return url;", "if(!url || !cfg.proxy || window.ANDROID) return url;")
rep("if(!url || !cfg.proxy2) return url;", "if(!url || !cfg.proxy2 || window.ANDROID) return url;")
rep('if(window.top !== window || location.protocol==="file:") return',
    'if(window.ANDROID) return "Não consegui ligar ao servidor (" + e.message + "). Confirma o endereço, o utilizador e a palavra-passe e a ligação à internet.";\n  if(window.top !== window || location.protocol==="file:") return')
rep("function show(view){\n", 'function show(view){\n  if(window.ANDROID && view !== "settings") view = "tv";\n')
rep("applyPassenger(); applyLayout();", 'if(window.ANDROID){ cfg.layout = "classic"; cfg.passenger = false; }\napplyPassenger(); applyLayout();')
rep('\nif(passengerImport()) show("tv");', '\nif(window.ANDROID) show("tv");\nelse if(passengerImport()) show("tv");')

CSS = """
/* ===== Cockpit TV (Android) ===== */
body.android .rail,body.android .tsonly,body.android #tsPanel,body.android #chipCar,body.android #chipNet,body.android #lockNow,body.android #teslaFs,body.android #heard,body.android #micBtn{display:none!important}
body.android .app{grid-template-columns:1fr!important;grid-template-rows:54px 1fr!important}
body.android .top{grid-column:1!important;grid-row:1!important;padding:0 14px;gap:10px}
body.android main{grid-column:1!important;grid-row:2!important}
body.android .app.cinema{grid-template-rows:54px 1fr!important}
body.android .clock{font-size:22px}
body.android .top .btn[aria-pressed="true"]{background:var(--accent);color:var(--accent-ink);border-color:var(--accent)}
"""
rep("</style>", CSS + "</style>", count=h.count("</style>")) if h.count("</style>") == 1 else None
if h.count("</style>") != 1:
    i = h.rfind("</style>"); h = h[:i] + CSS + h[i:]

JS = r"""
<script>
/* ===== Cockpit TV (Android): só IPTV ===== */
(function(){
  if(!window.ANDROID) return;
  document.body.classList.add("android");
  const top = document.querySelector(".top"), sp = top.querySelector(".spacer");
  const mk = (txt, v) => { const b = document.createElement("button"); b.className = "btn"; b.textContent = txt; b.onclick = () => show(v); b.dataset.v = v; top.insertBefore(b, sp); return b; };
  const bTv = mk("📺 TV", "tv"), bSet = mk("⚙ Definições", "settings");
  const sync = () => { bTv.setAttribute("aria-pressed", currentView === "tv" ? "true" : "false"); bSet.setAttribute("aria-pressed", currentView === "settings" ? "true" : "false"); };
  const _show = window.show;
  window.show = function(v){ const r = _show.apply(this, arguments); sync(); return r; };
  sync();

  /* Definições: só o que interessa à TV */
  const v = $("v-settings");
  const panels = v.querySelectorAll(".grid2 > .panel");
  const h2txt = el => el.tagName === "H2" ? el.textContent.trim() : "";
  if(panels[0]){
    const kids = [...panels[0].children];
    const iLay = kids.findIndex(e => h2txt(e) === "Layout");
    kids.forEach((e, i) => { if(i <= iLay || e.classList.contains("layouts")) e.hidden = true; });
  }
  if(panels[1]){
    const kids = [...panels[1].children];
    const iProxy = kids.findIndex(e => h2txt(e) === "Proxy");
    const iLoad = kids.findIndex(e => e.querySelector && e.querySelector("#btnLoadIptv"));
    const iStat = kids.findIndex(e => e.id === "iptvStatus");
    kids.forEach((e, i) => { if((iProxy >= 0 && i >= iProxy && i < iLoad) || i > iStat) e.hidden = true; });
    const info = document.createElement("p"); info.className = "small muted"; info.style.margin = "0";
    info.textContent = "Esta aplicação liga-se diretamente ao servidor IPTV (não precisa de proxy).";
    panels[1].insertBefore(info, kids[iLoad]);
  }

  /* Ficheiro de exportação: guarda em Transferências */
  const eb = $("orgExpFile");
  if(eb) eb.onclick = () => {
    const txt = JSON.stringify(orgExport($("orgInclAcc").checked), null, 1); $("orgXfer").value = txt;
    let ok = false; try{ ok = Android.saveText("cockpit-iptv-definicoes.json", txt); }catch(e){}
    orgXferMsg(ok ? "Guardado na pasta Transferências (Downloads). O código também ficou na caixa." : "Não consegui guardar o ficheiro; copia o código da caixa.", !ok);
  };

  /* Informar a parte nativa do Referer a usar nos canais abertos (RTP, SIC, …) */
  const _pc = window.playChannel;
  window.playChannel = function(c){ try{ Android.ctx(refFor(c) || ""); }catch(e){} return _pc.apply(this, arguments); };

  /* Botão Voltar */
  window.androidBack = function(){
    const d = document.querySelector(".epgdlg:not([hidden]),.trkdlg:not([hidden])");
    if(d){ const b = [...d.querySelectorAll("button")].find(x => /^(fechar|✕|×|close)/i.test(x.textContent.trim())); if(b) b.click(); else d.hidden = true; return true; }
    if(document.querySelector(".app").classList.contains("cinema")){ setCinema(false); return true; }
    if(currentView === "settings"){ show("tv"); return true; }
    return false;
  };
})();
</script>
"""
i = h.rfind("</body>")
h = h[:i] + JS + h[i:]
os.makedirs(os.path.dirname(out), exist_ok=True)
open(out, "w", encoding="utf-8").write(h)
print("OK ->", os.path.normpath(out), len(h)//1024, "KB")
