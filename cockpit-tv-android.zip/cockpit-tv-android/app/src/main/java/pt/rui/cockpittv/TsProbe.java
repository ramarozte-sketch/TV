package pt.rui.cockpittv;

import java.io.ByteArrayOutputStream;

/** v457: lê a altura real do vídeo (H.264 ou HEVC) dos primeiros bytes de um segmento MPEG-TS, sem descodificar nada. */
final class TsProbe {
    private TsProbe() { }

    /** Altura em píxeis do vídeo, ou 0 se não foi possível ler. O tipo de fluxo declarado na PMT não é de confiança (alguns
     *  fornecedores usam 0x80): o PID do vídeo vem do PES (stream_id 0xE0–0xEF) e o codec vem dos próprios NAL. */
    static int height(byte[] ts) {
        try {
            if (ts == null || ts.length < 3760) return 0;
            int off = 0;
            while (off + 188 < ts.length && (ts[off] & 0xFF) != 0x47) off++;
            int vPid = -1;
            ByteArrayOutputStream es = new ByteArrayOutputStream();
            boolean inPes = false;
            for (int p = off; p + 188 <= ts.length; p += 188) {
                if ((ts[p] & 0xFF) != 0x47) continue;
                boolean pusi = (ts[p + 1] & 0x40) != 0;
                int pid = ((ts[p + 1] & 0x1F) << 8) | (ts[p + 2] & 0xFF);
                int afc = (ts[p + 3] >> 4) & 3;
                int s = p + 4;
                if ((afc & 2) != 0) s += 1 + (ts[s] & 0xFF);
                if ((afc & 1) == 0 || s + 9 > p + 188) continue;
                if (vPid < 0 && pusi && ts[s] == 0 && ts[s + 1] == 0 && ts[s + 2] == 1 && (ts[s + 3] & 0xF0) == 0xE0) vPid = pid;
                if (pid != vPid) continue;
                if (pusi) { s += 9 + (ts[s + 8] & 0xFF); inPes = true; }
                if (inPes && s < p + 188) es.write(ts, s, p + 188 - s);
                if (es.size() > 400000) break;
            }
            byte[] b = es.toByteArray();
            for (int i = 0; i + 5 < b.length; i++) {
                if (b[i] != 0 || b[i + 1] != 0 || b[i + 2] != 1) continue;
                int h = b[i + 3] & 0xFF;
                if (h == 0x67 || h == 0x27 || h == 0x47) { int r = avcHeight(b, i + 4); if (r > 0) return r; }
                else if (h == 0x42 && (b[i + 4] & 0xFF) == 0x01) { int r = hevcHeight(b, i + 5); if (r > 0) return r; }
            }
        } catch (Throwable ignored) { }
        return 0;
    }

    /** Dados do NAL sem os bytes de «emulation prevention» (00 00 03). */
    private static byte[] rbsp(byte[] b, int from) {
        ByteArrayOutputStream o = new ByteArrayOutputStream();
        int z = 0;
        for (int i = from; i < b.length && o.size() < 200; i++) {
            int v = b[i] & 0xFF;
            if (z >= 2 && v == 1) break;                       /* próximo start code */
            if (z >= 2 && v == 3) { z = 0; continue; }
            o.write(v);
            z = v == 0 ? z + 1 : 0;
        }
        return o.toByteArray();
    }

    private static final class Bits {
        final byte[] d; int pos;
        Bits(byte[] d) { this.d = d; }
        int u(int n) { int v = 0; for (int i = 0; i < n; i++) { int by = pos >> 3; if (by >= d.length) throw new RuntimeException("fim"); v = (v << 1) | ((d[by] >> (7 - (pos & 7))) & 1); pos++; } return v; }
        int ue() { int z = 0; while (u(1) == 0) { if (++z > 31) throw new RuntimeException("ue"); } return z == 0 ? 0 : (int) ((1L << z) - 1 + u(z)); }
        int se() { int k = ue(); return (k & 1) != 0 ? (k + 1) / 2 : -(k / 2); }
        void skip(int n) { pos += n; }
    }

    private static int avcHeight(byte[] b, int from) {
        try {
            Bits r = new Bits(rbsp(b, from));
            int profile = r.u(8); r.u(8); r.u(8); r.ue();
            int chroma = 1;
            if (profile == 100 || profile == 110 || profile == 122 || profile == 244 || profile == 44 || profile == 83 || profile == 86 || profile == 118 || profile == 128 || profile == 138 || profile == 139 || profile == 134 || profile == 135) {
                chroma = r.ue(); if (chroma == 3) r.u(1);
                r.ue(); r.ue(); r.u(1);
                if (r.u(1) == 1) {
                    for (int i = 0; i < (chroma != 3 ? 8 : 12); i++) {
                        if (r.u(1) == 1) { int size = i < 6 ? 16 : 64, last = 8, next = 8; for (int j = 0; j < size; j++) { if (next != 0) { next = (last + r.se() + 256) % 256; } last = next == 0 ? last : next; } }
                    }
                }
            }
            r.ue();
            int poc = r.ue();
            if (poc == 0) r.ue();
            else if (poc == 1) { r.u(1); r.se(); r.se(); int n = r.ue(); for (int i = 0; i < n; i++) r.se(); }
            r.ue(); r.u(1);
            r.ue();                                              /* largura em macroblocos - 1 */
            int hMap = r.ue();
            int frameMbsOnly = r.u(1);
            if (frameMbsOnly == 0) r.u(1);
            r.u(1);
            int h = (2 - frameMbsOnly) * (hMap + 1) * 16;
            if (r.u(1) == 1) {
                r.ue(); r.ue(); int top = r.ue(), bottom = r.ue();
                int subH = chroma == 1 ? 2 : 1;
                h -= (chroma == 0 ? 1 : subH) * (2 - frameMbsOnly) * (top + bottom);
            }
            return h >= 100 && h <= 4400 ? h : 0;
        } catch (Throwable e) { return 0; }
    }

    private static int hevcHeight(byte[] b, int from) {
        try {
            Bits r = new Bits(rbsp(b, from));
            r.u(4); int maxSub = r.u(3); r.u(1);
            r.skip(96);   /* profile_tier_level geral: 8 + 32 + 48 + 8 bits */
            boolean[] pp = new boolean[8], lp = new boolean[8];
            for (int i = 0; i < maxSub; i++) { pp[i] = r.u(1) == 1; lp[i] = r.u(1) == 1; }
            if (maxSub > 0) for (int i = maxSub; i < 8; i++) r.u(2);
            for (int i = 0; i < maxSub; i++) { if (pp[i]) r.skip(88); if (lp[i]) r.skip(8); }
            r.ue();
            int chroma = r.ue(); if (chroma == 3) r.u(1);
            r.ue();
            int h = r.ue();
            if (r.u(1) == 1) {
                r.ue(); r.ue(); int top = r.ue(), bottom = r.ue();
                h -= (chroma == 1 ? 2 : 1) * (top + bottom);
            }
            return h >= 100 && h <= 4400 ? h : 0;
        } catch (Throwable e) { return 0; }
    }
}
