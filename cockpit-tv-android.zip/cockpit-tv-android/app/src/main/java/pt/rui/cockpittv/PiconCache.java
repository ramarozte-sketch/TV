package pt.rui.cockpittv;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.MessageDigest;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.Semaphore;
import java.util.concurrent.TimeUnit;

/**
 * Cache em disco dos logótipos (picons) e posters: descarrega uma vez, reduz para um tamanho pequeno
 * e serve daí nas aberturas seguintes (instantâneo, mesmo sem rede). Limita os pedidos simultâneos
 * e lembra durante 10 minutos os endereços que falharam, para não atrasar o arranque.
 */
final class PiconCache {
    private static final int MAX_DIM = 400;
    private static final long MAX_BYTES = 120L * 1024 * 1024;
    private static final long MAX_AGE_MS = 30L * 24 * 3600 * 1000;
    private static final Semaphore SEM = new Semaphore(12);
    private static final ConcurrentHashMap<String, Long> BAD = new ConcurrentHashMap<String, Long>();
    private static File dir;

    private PiconCache() { }

    static void init(Context c) {
        try {
            dir = new File(c.getCacheDir(), "picons");
            dir.mkdirs();
            new Thread(PiconCache::trim).start();
        } catch (Throwable ignored) { }
    }

    /** v312: apaga os logótipos guardados (voltam a descarregar quando forem precisos). */
    static int clearAll() { int n = 0; try { File[] fs = dir == null ? null : dir.listFiles(); if (fs != null) for (File f : fs) if (f.delete()) n++; BAD.clear(); } catch (Throwable ignored) { } return n; }

    private static void trim() {
        try {
            File[] fs = dir.listFiles();
            if (fs == null) return;
            long now = System.currentTimeMillis(), total = 0;
            for (File f : fs) {
                if (now - f.lastModified() > MAX_AGE_MS) { f.delete(); continue; }
                total += f.length();
            }
            if (total > MAX_BYTES) {
                java.util.Arrays.sort(fs, (a, b) -> Long.compare(a.lastModified(), b.lastModified()));
                for (File f : fs) { if (total <= MAX_BYTES * 3 / 4) break; if (f.exists()) { total -= f.length(); f.delete(); } }
            }
        } catch (Throwable ignored) { }
    }

    private static String key(String url) {
        try {
            byte[] d = MessageDigest.getInstance("SHA-1").digest(url.getBytes("UTF-8"));
            StringBuilder sb = new StringBuilder();
            for (byte b : d) sb.append(String.format("%02x", b));
            return sb.toString();
        } catch (Throwable e) { return Integer.toHexString(url.hashCode()); }
    }

    static String mime(File f) { return f.getName().endsWith(".jpg") ? "image/jpeg" : "image/png"; }

    /** Ficheiro já em cache (sem rede) ou null. */
    static File cached(String url) {
        if (dir == null) return null;
        String k = key(url);
        File p = new File(dir, k + ".png"), j = new File(dir, k + ".jpg");
        if (p.length() > 0) return p;
        if (j.length() > 0) return j;
        return null;
    }

    static boolean knownBad(String url) {
        Long t = BAD.get(url);
        if (t == null) return false;
        if (System.currentTimeMillis() - t > 10 * 60 * 1000) { BAD.remove(url); return false; }
        return true;
    }

    /** Devolve o ficheiro reduzido (da cache ou descarregado agora); null se não deu. */
    static File get(String url) {
        if (dir == null || url == null || !url.startsWith("http")) return null;
        File c = cached(url);
        if (c != null) { c.setLastModified(System.currentTimeMillis()); return c; }
        if (knownBad(url)) return null;
        boolean got = false;
        try {
            got = SEM.tryAcquire(8, TimeUnit.SECONDS);
            if (!got) return null;
            c = cached(url);
            if (c != null) return c;
            HttpURLConnection h = null;
            InputStream in = null;
            try {
                h = (HttpURLConnection) new URL(url).openConnection();
                h.setConnectTimeout(3000);
                h.setReadTimeout(5000);
                h.setUseCaches(false);
                h.setInstanceFollowRedirects(true);
                h.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 12) AppleWebKit/537.36 Chrome/120 Safari/537.36");
                if (h.getResponseCode() / 100 != 2) { BAD.put(url, System.currentTimeMillis()); return null; }
                in = h.getInputStream();
                ByteArrayOutputStream bo = new ByteArrayOutputStream();
                byte[] buf = new byte[8192];
                int n;
                while ((n = in.read(buf)) > 0) { bo.write(buf, 0, n); if (bo.size() > 4 * 1024 * 1024) { BAD.put(url, System.currentTimeMillis()); return null; } }
                byte[] data = bo.toByteArray();
                BitmapFactory.Options o = new BitmapFactory.Options();
                o.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(data, 0, data.length, o);
                if (o.outWidth <= 0) { BAD.put(url, System.currentTimeMillis()); return null; }
                int ss = 1;
                while (Math.max(o.outWidth, o.outHeight) / (ss * 2) >= MAX_DIM) ss *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options();
                o2.inSampleSize = ss;
                Bitmap bm = BitmapFactory.decodeByteArray(data, 0, data.length, o2);
                if (bm == null) { BAD.put(url, System.currentTimeMillis()); return null; }
                int m = Math.max(bm.getWidth(), bm.getHeight());
                if (m > MAX_DIM) {
                    float f = MAX_DIM / (float) m;
                    Bitmap s2 = Bitmap.createScaledBitmap(bm, Math.max(1, Math.round(bm.getWidth() * f)), Math.max(1, Math.round(bm.getHeight() * f)), true);
                    if (s2 != bm) { bm.recycle(); bm = s2; }
                }
                boolean alpha = bm.hasAlpha();
                File out = new File(dir, key(url) + (alpha ? ".png" : ".jpg"));
                File tmp = new File(dir, key(url) + ".tmp");
                FileOutputStream fo = new FileOutputStream(tmp);
                bm.compress(alpha ? Bitmap.CompressFormat.PNG : Bitmap.CompressFormat.JPEG, 85, fo);
                fo.close();
                bm.recycle();
                if (!tmp.renameTo(out)) { tmp.delete(); return null; }
                return out;
            } catch (Throwable e) {
                BAD.put(url, System.currentTimeMillis());
                return null;
            } finally {
                try { if (in != null) in.close(); } catch (Throwable ignored) { }
                try { if (h != null) h.disconnect(); } catch (Throwable ignored) { }
            }
        } catch (InterruptedException e) {
            return null;
        } finally {
            if (got) SEM.release();
        }
    }

    /* ------------------------------------------------------------ v277: carregamento rápido (memória partilhada, os visíveis primeiro, pré-carregamento) */
    private static final android.util.LruCache<String, Bitmap> MEM = new android.util.LruCache<String, Bitmap>((int) Math.min(48L * 1024 * 1024, Runtime.getRuntime().maxMemory() / 8)) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };
    /** Fila «último pedido primeiro»: o que acabou de aparecer no ecrã é descarregado antes do que já saiu dele. */
    private static java.util.concurrent.ThreadPoolExecutor lifo(int n, int prio) {
        java.util.concurrent.ThreadPoolExecutor ex = new java.util.concurrent.ThreadPoolExecutor(n, n, 30, TimeUnit.SECONDS,
                new java.util.concurrent.LinkedBlockingDeque<Runnable>() {
                    @Override public boolean offer(Runnable r) { return offerFirst(r); }
                }, r -> { Thread t = new Thread(r, "picons"); t.setPriority(prio); t.setDaemon(true); return t; });
        ex.allowCoreThreadTimeOut(true);
        return ex;
    }
    private static final java.util.concurrent.ThreadPoolExecutor FG = lifo(10, Thread.NORM_PRIORITY);
    private static final java.util.concurrent.ThreadPoolExecutor BG = lifo(3, Thread.MIN_PRIORITY);
    private static final android.os.Handler UI = new android.os.Handler(android.os.Looper.getMainLooper());
    private static final ConcurrentHashMap<String, java.util.List<Cb>> WAIT = new ConcurrentHashMap<>();
    interface Cb { void done(Bitmap b); }

    /** Já descodificado em memória (instantâneo) ou null. */
    static Bitmap mem(String url) { return url == null || url.isEmpty() ? null : MEM.get(url); }

    /** Carrega o logótipo (memória → disco → rede) e chama cb na thread da interface; pedidos iguais juntam-se num só. */
    static void load(final String url, final Cb cb) {
        if (url == null || !url.startsWith("http")) { cb.done(null); return; }
        Bitmap m = MEM.get(url);
        if (m != null) { cb.done(m); return; }
        if (knownBad(url)) { cb.done(null); return; }
        java.util.List<Cb> l = new java.util.concurrent.CopyOnWriteArrayList<>(); l.add(cb);
        java.util.List<Cb> prev = WAIT.putIfAbsent(url, l);
        if (prev != null) { prev.add(cb); return; }
        FG.execute(() -> {
            Bitmap b = null;
            try { File f = get(url); if (f != null) b = BitmapFactory.decodeFile(f.getAbsolutePath()); } catch (Throwable ignored) { }
            if (b != null) MEM.put(url, b);
            final Bitmap fb = b;
            final java.util.List<Cb> cbs = WAIT.remove(url);
            if (cbs != null) UI.post(() -> { for (Cb c : cbs) try { c.done(fb); } catch (Throwable ignored) { } });
        });
    }

    /** Pré-carrega para o disco (em baixa prioridade) os logótipos que ainda não estão guardados. */
    static void prefetch(java.util.Collection<String> urls) {
        if (dir == null || urls == null) return;
        int n = 0;
        for (final String u : urls) {
            if (u == null || !u.startsWith("http") || cached(u) != null || knownBad(u)) continue;
            if (++n > 600) break;
            BG.execute(() -> { try { if (cached(u) == null) get(u); } catch (Throwable ignored) { } });
        }
    }
    /** Limpa os pré-carregamentos pendentes (mudou de lista). */
    static void cancelPrefetch() { try { BG.getQueue().clear(); } catch (Throwable ignored) { } }
}
