#!/usr/bin/env python3
"""Gera app/src/main/assets/index.html (só IPTV) a partir do index.html do Cockpit.
Uso: python3 tools/build_assets.py [caminho/para/cockpit/index.html]"""
import sys, os
src = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), "..", "..", "cockpit", "index.html")
out = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "index.html")
h = open(src, encoding="utf-8").read()

def rep(old, new, count=1):
    global h
    if h.count(old) != count:
        sys.exit("Não encontrei (ou há repetições) de: " + old[:70])
    h = h.replace(old, new)

rep('$("tvList").querySelectorAll("[data-ep]").forEach(bt=>bt.onclick=()=>playChannel(eps[+bt.dataset.ep]));', 'window.EPL = {list:eps, series:c}; $("tvList").querySelectorAll("[data-ep]").forEach(bt=>bt.onclick=()=>playChannel(eps[+bt.dataset.ep]));')
rep("<head>", '<head>\n<script>window.ANDROID = (typeof Android !== "undefined");</script>')
rep("<title>Cockpit", "<title>Cockpit TV")
rep('id="bootLogo">COCKPIT<', 'id="bootLogo">COCKPIT TV<')
rep("function px(url, ref, ua){\n  if(!url) return url;", "function px(url, ref, ua){\n  if(!url || window.ANDROID) return url;")
rep("function px2(url, ref, ua){\n  if(!url || !cfg.proxy2 || !cfg.proxy) return url;", "function px2(url, ref, ua){\n  if(!url || window.ANDROID || !cfg.proxy2 || !cfg.proxy) return url;")
rep("const HASPX = () => !!(PHONE || cfg.proxy2 || cfg.proxy);", "const HASPX = () => !window.ANDROID && !!(PHONE || cfg.proxy2 || cfg.proxy);")
rep('const PAGE_HTTP = location.protocol === "http:" && !PHONE;', 'const PAGE_HTTP = (location.protocol === "http:" && !PHONE) || !!window.ANDROID;')
rep('let mirrorOn = LS.get("mirror", false);', 'let mirrorOn = LS.get("mirror", false) && !window.ANDROID;')
rep('if(window.top !== window || location.protocol==="file:") return',
    'if(window.ANDROID) return "Não consegui ligar ao servidor (" + e.message + "). Confirma o endereço, o utilizador e a palavra-passe e a ligação à internet.";\n  if(window.top !== window || location.protocol==="file:") return')
rep("function show(view){\n", 'function show(view){\n  if(window.ANDROID && !["settings","tv","tvhome","tvlive"].includes(view)) view = "tvhome";\n')
rep("applyPassenger(); applyLayout();", 'if(window.ANDROID){ cfg.layout = "classic"; cfg.passenger = false; }\napplyPassenger(); applyLayout();')
rep('\nif(passengerImport()) show("tv");', '\nif(window.ANDROID) show("tvhome");\nelse if(passengerImport()) show("tv");')

# --- leitor nativo (Media3): ganchos no código do Cockpit ---
rep("  if(isTs && live){ tryTs(); }\n  else if(isFlv || isFileTs){", "  if(window.NATIVE && NATIVE.go(c, slot, playId, fail)){ /* leitor nativo */ }\n  else if(isTs && live){ tryTs(); }\n  else if(isFlv || isFileTs){")
rep("  audioWatch(slot, c, playId, () => fileViaHls && fileViaHls());", "  if(!(window.NATIVE && NATIVE.active)) audioWatch(slot, c, playId, () => fileViaHls && fileViaHls());")
rep("function stopSlot(slot){\n", "function stopSlot(slot){\n  if(window.NATIVE && slot === 0) NATIVE.stop();\n")
rep("function trkAddExt(slot, text, label){\n", "function trkAddExt(slot, text, label){\n  if(window.NATIVE && NATIVE.active && slot === 0){ NATIVE.subText(text, label); return; }\n")
rep("function trkShift(slot, d){\n", "function trkShift(slot, d){\n  if(window.NATIVE && NATIVE.active && slot === 0){ NATIVE.shift(d); return; }\n")
rep("function osHasPt(slot){", "function osHasPt(slot){ if(window.NATIVE && NATIVE.active && slot === 0) return NATIVE.tracks('text').some(t => trkIsPt(t.name)) || !!NATIVE.subBase;\n  return osHasPt0(slot); }\nfunction osHasPt0(slot){")
rep("function trkAudioList(slot){\n", "function trkAudioList(slot){\n  if(window.NATIVE && NATIVE.active && slot === 0){ const t = NATIVE.tracks('audio'); if(t.length) return {kind:'nat', items:t}; }\n")
rep("function trkSetAudio(slot, kind, i){\n", "function trkSetAudio(slot, kind, i){\n  if(kind === 'nat'){ NATIVE.pick('audio', i); return; }\n")
rep("function trkSubList(slot){\n  const h = hlsInst[slot], v = $(\"vid\"+slot), items = [];\n", "function trkSubList(slot){\n  const h = hlsInst[slot], v = $(\"vid\"+slot), items = [];\n  if(window.NATIVE && NATIVE.active && slot === 0){ NATIVE.tracks('text').forEach(t => items.push({kind:'nat', i:t.i, name:t.name, on:t.on})); return items; }\n")
rep("function trkSubsOff(slot){\n", "function trkSubsOff(slot){\n  if(window.NATIVE && NATIVE.active && slot === 0){ NATIVE.pick('text', -1); return; }\n")
rep("function trkSetSub(slot, it){\n  trkSubsOff(slot); if(!it) return;\n", "function trkSetSub(slot, it){\n  trkSubsOff(slot); if(!it) return;\n  if(it.kind === 'nat'){ NATIVE.pick('text', it.i); return; }\n")

CSS = """
/* ===== Cockpit TV (Android) ===== */
body.android .rail,body.android .tsonly,body.android #tsPanel,body.android #chipCar,body.android #chipNet,body.android #lockNow,body.android #teslaFs,body.android #heard,body.android #micBtn{display:none!important}
body.android .app{grid-template-columns:1fr!important;grid-template-rows:54px 1fr!important}
body.android .top{grid-column:1!important;grid-row:1!important;padding:0 14px;gap:10px}
body.android main{grid-column:1!important;grid-row:2!important}
body.android .app.cinema{grid-template-rows:54px 1fr!important}
body.android .clock{font-size:22px}
body.android :focus-visible{outline:4px solid var(--accent)!important;outline-offset:3px;box-shadow:0 0 0 8px color-mix(in srgb,var(--accent) 30%,transparent)}
body.android .item:focus-visible{background:var(--panel-2)}
body.android.tv .app{padding:14px 22px 0;box-sizing:border-box}
body.android.tv .btn,body.android.tv .tab{min-height:46px;padding-block:6px}
body.android.tv .item{min-height:52px}
body.android.tv{font-size:16px}
body.android #btnFull,body.android #btnMirror{display:none!important}
/* ===== Android TV: visual moderno ===== */
body.android{background:radial-gradient(1100px 520px at 85% -8%,color-mix(in srgb,var(--accent) 20%,transparent),transparent),linear-gradient(180deg,#0a101c,#04070d)!important}
body.android .top{background:linear-gradient(180deg,color-mix(in srgb,var(--accent) 30%,#0b1424),color-mix(in srgb,var(--accent) 14%,#08101c))!important;border:0!important;border-bottom:2px solid color-mix(in srgb,var(--accent) 55%,transparent)!important;box-shadow:0 6px 24px rgba(0,0,0,.45)!important;height:72px;padding:0 28px;gap:18px;position:relative;z-index:5}
body.android .top .btn[data-v],body.android #atvHome,body.android #chipDrive,body.android #chipCar,body.android #chipNet{display:none!important}
body.android .clock{font-size:26px;font-weight:700;letter-spacing:.02em}
.thNav{display:flex;gap:8px;margin-left:18px}
.thTab{display:inline-flex;align-items:center;gap:8px;min-height:50px;padding:6px 22px;border:0;border-radius:999px;background:transparent;color:inherit;font:600 18px/1 inherit;opacity:.78}
.thTab span{font-size:20px}
.thTab[aria-current="page"]{background:var(--accent);color:var(--accent-ink);opacity:1}
body.android .thTab:focus-visible{outline:3px solid #fff!important;outline-offset:2px;box-shadow:none;opacity:1}
#v-tvhome{padding:4px 28px 40px;box-sizing:border-box}
#exitDlg{position:fixed;inset:0;z-index:300;background:#000b;display:flex;align-items:center;justify-content:center}
#exitDlg[hidden]{display:none}
#exitDlg .exBox{background:#121b2e;border-radius:22px;padding:28px 36px;min-width:min(520px,80vw);text-align:center;box-shadow:0 20px 60px #000a}
#exitDlg h2{margin:0 0 6px;font-size:28px}#exitDlg p{margin:0 0 20px;font-size:18px;opacity:.8}
#exitDlg .exBt{display:flex;gap:14px;justify-content:center}#exitDlg .btn{min-width:150px;min-height:54px;font-size:19px}
body.exitOpen .app{pointer-events:none}
.thBar{position:absolute;left:0;right:0;bottom:0;height:6px;background:#0008;z-index:2}.thBar i{display:block;height:100%;background:var(--accent,#7cc4ff)}
.tplGrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px}
.tplBtn{flex-direction:column;align-items:flex-start!important;justify-content:flex-start!important;text-align:left!important;height:auto;padding:12px 16px!important;gap:3px}
.tplBtn small{font-size:13px;opacity:.7;font-weight:400;white-space:normal}
.tplBtn[aria-pressed=true]{background:var(--accent)!important;color:var(--accent-ink)!important}
body.tl-cinema .thCard{flex-basis:340px}body.tl-cinema .thHero{min-height:300px}body.tl-cinema .thHeroTx h1{font-size:50px}body.tl-cinema .thMeta b{font-size:22px}body.tl-cinema .thHeroArt{flex-basis:340px}
body.tl-compacto .thHero{display:none}body.tl-compacto .thCard{flex-basis:190px}body.tl-compacto .thMeta b{font-size:15px}body.tl-compacto .thMeta small{display:none}body.tl-compacto .thRow h2{font-size:20px;margin-top:8px}body.tl-compacto .thScroll{gap:12px;padding-bottom:14px}
body.tl-grelha .thScroll{flex-wrap:wrap;overflow:visible}
body.tl-grande{font-size:22px!important}body.tl-grande .thCard{flex-basis:300px}body.tl-grande .thMeta b{font-size:24px}body.tl-grande .thMeta small{font-size:18px}body.tl-grande .thRow h2{font-size:30px}body.tl-grande .thTab{font-size:22px}body.tl-grande .thBtn{font-size:23px}body.tl-grande .btn,body.tl-grande .tab{font-size:20px!important}
body.ov-1.android .app{padding:32px 48px 0!important}body.ov-2.android .app{padding:56px 80px 0!important}
#castBanner{position:fixed;left:50%;bottom:18px;transform:translateX(-50%);z-index:260;display:flex;align-items:center;gap:10px;padding:10px 16px;border-radius:16px;background:#121b2ef2;box-shadow:0 10px 36px #000a;max-width:94vw}
#castBanner[hidden]{display:none}#castBanner span{font-weight:700;max-width:46vw;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.epgdlg .detbox{display:flex!important;flex-direction:row!important;align-items:flex-start;gap:26px;width:min(1100px,94vw);max-height:90vh;padding:24px;box-sizing:border-box;overflow:hidden}
.detposter{flex:0 0 240px;aspect-ratio:2/3;border-radius:16px;background:linear-gradient(135deg,#1d2a47,#0d1424);display:flex;align-items:center;justify-content:center;overflow:hidden;align-self:flex-start}
.detposter img{width:100%;height:100%;object-fit:cover}.detposter b{font-size:56px;opacity:.4}
.dettx{flex:1;min-width:0;display:flex;flex-direction:column;gap:10px;overflow:hidden}
.dettx h2{margin:0;font-size:30px;line-height:1.15}
.detmeta{font-size:17px;opacity:.9}.detrate{color:#ffd166;margin-right:6px}
.detplot{flex:0 1 auto;min-height:96px;font-size:17px;line-height:1.45;overflow-y:auto;max-height:36vh;padding:4px 8px 4px 2px;border-radius:10px}
.detplot:focus-visible{outline:3px solid var(--accent)!important}
.detcrew{font-size:15px;opacity:.8;display:flex;flex-direction:column;gap:4px;max-height:16vh;overflow:hidden}
.detbt{display:flex;gap:12px;flex-wrap:wrap;margin-top:auto;padding-top:6px}
/* detalhes de filme/série: nada cortado. A coluna de texto rola inteira (sinopse completa, elenco completo) e os botões ficam sempre à vista */
.epgdlg .detbox{max-height:92vh!important}
.epgdlg .dettx{overflow-y:auto!important;max-height:calc(92vh - 48px);padding-right:4px}
.epgdlg .detplot{max-height:none!important;overflow:visible!important;flex:0 0 auto}
.epgdlg .detcrew{max-height:none!important;overflow:visible!important}
.epgdlg .detbt{position:sticky;bottom:0;margin-top:auto;padding:10px 0 2px;background:linear-gradient(to bottom,transparent,var(--panel,#111a2c) 35%);z-index:2}
body.pland .epgdlg .detbox{max-height:calc(94vh / var(--ps,1))!important;width:min(1100px,94%)}
body.pland .epgdlg .dettx{max-height:calc(94vh / var(--ps,1) - 48px)}
@media (max-width:700px){
  body:not(.pland) .epgdlg .detbox{overflow-y:auto!important;max-height:90vh!important}
  body:not(.pland) .epgdlg .dettx{overflow:visible!important;max-height:none!important}
  body:not(.pland) .epgdlg .detbt{position:static;background:none}
}
@media (max-width:700px){.epgdlg .detbox{flex-direction:column!important;overflow-y:auto}.detposter{flex-basis:auto;width:42%}}
.ic{width:1.2em;height:1.2em;flex:none;vertical-align:-.22em;fill:none;stroke:currentColor;stroke-width:2;stroke-linecap:round;stroke-linejoin:round;margin-inline:.1em}
.thTab .ic{width:1.35em;height:1.35em}
#tvSetGrid{grid-column:1/-1;width:100%;display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px;align-items:start;padding-bottom:48px}
#tvSetGrid .setcard{padding:0!important;overflow:hidden;scroll-margin-top:96px}
#tvSetGrid .setcard.open{grid-column:1/-1}
#tvSetGrid .setcard>h2{display:none}
#tvSetGrid .setcard:focus-within{box-shadow:0 0 0 3px var(--accent),0 10px 30px #0008}
.setHead:focus,.setHead:focus-visible{outline:4px solid #fff!important;outline-offset:-4px;background:color-mix(in srgb,var(--accent) 24%,transparent)!important}
.setHead:focus b{text-decoration:underline}
#tvSetGrid input:focus,#tvSetGrid select:focus,#tvSetGrid textarea:focus,#tvSetGrid .btn:focus,#tvSetGrid .btn:focus-visible{outline:3px solid #fff!important;outline-offset:2px}
.setHead{display:flex;align-items:center;gap:16px;width:100%;padding:16px 22px;border:0;background:transparent;color:inherit;text-align:left;font:inherit;border-radius:20px;min-height:84px;cursor:pointer}
.setHead .setIc{width:52px;height:52px;border-radius:14px;background:color-mix(in srgb,var(--accent) 22%,transparent);display:flex;align-items:center;justify-content:center;flex:none}
.setHead .setIc .ic{width:28px;height:28px;margin:0}
.setHead .setT{flex:1;min-width:0;display:flex;flex-direction:column;gap:3px}.setHead b{font-size:21px}.setHead small{font-size:15px;opacity:.7}
.setHead .chev .ic{width:22px;height:22px;opacity:.7;transition:transform .15s}.setcard.open .chev .ic{transform:rotate(90deg)}
.setBody{padding:4px 22px 22px;display:flex;flex-direction:column;gap:12px}.setBody[hidden]{display:none}
textarea{width:100%;box-sizing:border-box;background:var(--panel2,#1a2438);color:inherit;border:1px solid #fff2;border-radius:12px;padding:10px;font:inherit}.opB.on{background:var(--accent);color:var(--accent-ink)}
.keyList{display:flex;flex-direction:column;gap:8px}.keyList div{display:flex;gap:16px;align-items:baseline}.keyList b{flex:0 0 190px;font-size:17px}.keyList span{opacity:.85;font-size:16px}
@media (max-width:800px){#tvSetGrid{grid-template-columns:1fr}.keyList b{flex-basis:120px}}


/* ===== Telemóvel na horizontal: layout de TV reduzido ===== */
html.phoneh{overflow:hidden!important}
body.pland{transform:scale(var(--ps,.6));transform-origin:0 0;width:calc(100vw / var(--ps,.6))!important;height:calc(100vh / var(--ps,.6))!important;overflow:hidden!important;position:absolute;top:0;left:0}
body.pland .app{height:100%!important;min-height:0!important}
body.pland .thCard{flex-basis:178px}body.pland .thCard.sm{flex-basis:150px}
body.pland .thHero{min-height:0;padding:12px 24px;gap:20px;margin-bottom:8px}body.pland .thHeroArt{flex-basis:150px}body.pland .thHeroTx h1{font-size:28px}body.pland .thHeroTx p{font-size:16px}body.pland .thHeroBt{margin-top:2px}body.pland .thBtn{min-height:44px;font-size:17px}body.pland .thKind{min-width:120px}body.pland .thRow h2{margin-top:6px}
body.pland #bStamp{display:none}
html body.pland.vfull.android #v-tv.cinema .stage{width:100%!important;height:100%!important;inset:0!important;max-width:none!important}html body.pland.vfull.android #stage .slot{width:100%!important;height:100%!important}
/* ===== Telemóvel: layout automático ===== */
html.phoneh,body.phone{overflow-x:hidden!important;max-width:100vw}
body.phone{font-size:15px;min-width:0!important}
body.phone .top{position:fixed!important;top:auto!important;bottom:0;left:0;right:0;height:62px!important;padding:0 4px calc(env(safe-area-inset-bottom,0px)) !important;gap:0!important;border-bottom:0!important;border-top:2px solid color-mix(in srgb,var(--accent) 55%,transparent)!important;box-shadow:0 -6px 24px rgba(0,0,0,.5)!important;z-index:50}
body.phone .top .clock,body.phone .top .spacer,body.phone .top>*:not(.thNav){display:none!important}
body.phone .thNav{margin:0;flex:1;gap:0;justify-content:space-around}
body.phone .thTab{flex-direction:column;gap:2px;min-height:54px;padding:4px 6px;font-size:11px;border-radius:14px;flex:1;min-width:0;justify-content:center}
body.phone .thTab span{font-size:20px;line-height:1}body.phone .thTab .ic{width:22px;height:22px;margin:0}
body.phone .app{display:flex!important;flex-direction:column;height:100dvh}body.phone #main{flex:1;min-height:0;overflow-y:auto;padding:12px 10px 76px!important}body.phone #v-tvhome{padding-left:2px!important;padding-right:2px!important}body.phone #thCast .lb,body.phone #thMirror .lb{display:none}
body.phone .thHero{flex-direction:column;align-items:stretch;padding:16px;gap:14px;min-height:0;border-radius:20px}
body.phone .thHeroArt{flex:none;width:100%}
body.phone .thHeroTx h1{font-size:24px}body.phone .thHeroTx p{font-size:15px}
body.phone .thRow h2{font-size:19px;margin-top:12px}
body.phone .thCard{flex-basis:44vw}body.phone .thCard.sm{flex-basis:36vw}
body.phone .thMeta b{font-size:14px}body.phone .thMeta small{font-size:12px}
body.phone .thKinds{overflow-x:auto;scrollbar-width:none}
body.phone .thBtn{font-size:15px;min-height:44px;padding:8px 16px}
body.phone #tvSetGrid{grid-template-columns:1fr}
body.phone .setHead{min-height:68px;padding:12px 16px}body.phone .setHead b{font-size:17px}
body.phone .epgdlg{width:100vw!important;max-width:100vw!important;height:100%!important;border-radius:0!important}
.thKinds{display:flex;gap:12px;margin:6px 0 4px}
.thKind{min-width:150px}
.thKind[aria-pressed=true]{background:#7cc4ff;color:#06101f;border-color:#7cc4ff}
.thHero{display:flex;align-items:center;gap:30px;padding:26px 32px;margin:2px 0 14px;border-radius:26px;min-height:210px;background:linear-gradient(120deg,color-mix(in srgb,var(--accent) 38%,#0d1526),#0d1526 72%);box-shadow:0 18px 50px #0007}
.thHeroArt{flex:0 0 250px;aspect-ratio:16/9;border-radius:18px;background:#0b1220cc;display:flex;align-items:center;justify-content:center;overflow:hidden}
.thHeroArt img{max-width:70%;max-height:70%;object-fit:contain}
.thHeroArt b{font-size:44px;opacity:.6}
.thHeroTx{flex:1;min-width:0;display:flex;flex-direction:column;gap:8px}
.thHeroTx small{font-size:15px;letter-spacing:.14em;text-transform:uppercase;opacity:.7}
.thHeroTx h1{margin:0;font-size:38px;line-height:1.1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.thHeroTx p{margin:0;font-size:19px;opacity:.85;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.thHeroBt{display:flex;gap:12px;margin-top:8px;flex-wrap:wrap}
.thBtn{min-height:54px;padding:8px 26px;border:0;border-radius:14px;background:#ffffff1f;color:inherit;font:600 19px/1 inherit}
.thBtn.pri{background:var(--accent);color:var(--accent-ink)}
body.android .thBtn:focus-visible{outline:3px solid #fff!important;outline-offset:3px;box-shadow:none;transform:scale(1.04)}
.thRow h2{margin:18px 4px 2px;font-size:24px;font-weight:700;letter-spacing:.01em;text-transform:none}
@media (max-height:800px){.thHero{min-height:0;padding:14px 24px;gap:20px;margin-bottom:6px}.thHeroArt{flex-basis:170px}.thHeroTx h1{font-size:28px}.thHeroTx p{font-size:16px}.thHeroTx small{font-size:12px}.thHeroBt{margin-top:2px}.thBtn{min-height:44px;padding:6px 20px;font-size:17px}.thKind{min-width:120px}.thRow h2{margin-top:10px;font-size:21px}}
.thScroll{display:flex;gap:18px;overflow-x:auto;padding:12px 10px 26px;scrollbar-width:none;scroll-padding:0 40px}
.thScroll::-webkit-scrollbar{display:none}
.thCard{flex:0 0 244px;border:0;border-radius:18px;background:var(--panel,#121b2e);color:inherit;padding:0;text-align:left;overflow:hidden;transition:transform .09s,box-shadow .09s;box-shadow:0 6px 18px #0006}
.thCard.sm{flex-basis:200px}
body.android .thCard:focus-visible{outline:none!important;transform:scale(1.08);box-shadow:0 0 0 4px var(--accent),0 20px 44px #000b;position:relative;z-index:3}
.thArt{display:flex;align-items:center;justify-content:center;aspect-ratio:16/9;background:linear-gradient(135deg,#1d2a47,#0d1424);position:relative}
.thArt img{max-width:60%;max-height:62%;object-fit:contain}
.thArt img+.thInit{display:none}
.thInit{font-size:34px;font-weight:800;opacity:.45;letter-spacing:.04em}
.thMeta{display:block;padding:10px 14px 13px}
.thMeta b{display:block;font-size:18px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.thMeta small{display:block;margin-top:3px;font-size:14px;opacity:.7;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.thMore{display:flex;align-items:center;justify-content:center;min-height:170px;font:700 20px/1 inherit;background:#ffffff14}
.thEmpty{padding:30px 6px;font-size:20px;opacity:.75}
/* Explorar e leitor: sem confusão de ecrã duplo */
body.android #v-tv>.row .tabs,body.android #btnCinema,body.android #btnSwapAudio,body.android .slot .rot,body.android .slot .lbl,body.android #v-tv .tvwrap>.panel:last-child>.row,body.android #mirDelMinus,body.android #mirDelVal,body.android #mirDelPlus,body.android #v-tv>.row>h1{display:none!important}
body.android #v-tv.cinema .cinebar{display:grid!important;grid-template-columns:repeat(auto-fit,minmax(120px,1fr));gap:10px;width:min(100%,calc((100vh - 180px) * 16 / 9))!important;margin:12px auto 0!important;flex-wrap:wrap}
body.android #v-tv.cinema .cinebar .cinename{grid-column:1/-1;order:0;text-align:center;font-size:24px;font-weight:700;margin-bottom:2px}
body.android #v-tv.cinema .cinebar .btn{width:100%;white-space:nowrap;justify-content:center}
body.android #v-tv.cinema #chPrev{order:1}body.android #v-tv.cinema #chGuide{order:2}body.android #v-tv.cinema #chTracks{order:3}body.android #v-tv.cinema #chSubs{order:4}body.android #v-tv.cinema #chNext{order:5}
body.android #v-tv.cinema .stage{width:min(100%,calc((100vh - 180px) * 16 / 9))!important}
body.android .view{max-width:none!important}
body.android.tv{font-size:18px}
body.android.tv .btn,body.android.tv .tab{min-height:52px!important;font-size:17px}
body.android .panel{border-radius:20px;border:0;background:color-mix(in srgb,var(--panel,#121b2e) 92%,transparent)}

/* ===== Botões uniformes, alinhados e sem sobreposição ===== */
body.android .btn,body.android .tab{min-height:44px!important;padding:8px 14px;font-size:15px;line-height:1.15;box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;text-align:center;gap:6px}
body.android .row{align-items:center;gap:10px}
body.android #v-tv>.row{display:flex!important;flex-wrap:wrap!important;gap:10px;align-items:center}
body.android #v-tv>.row .tabs{display:flex;gap:6px;flex-wrap:nowrap}
body.android .tvwrap>.panel:first-child .tabs{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;overflow:visible!important}
body.android .tvwrap>.panel:first-child .tab{min-width:0;font-size:12px!important;padding:6px 2px!important;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
body.android #freeTools{display:grid!important;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:center}
body.android #freeTools .btn{width:100%}
body.android #freeTools #healthMsg{grid-column:1/-1;margin:0}
body.android .tvwrap>.panel:first-child input[type=search],body.android .tvwrap>.panel:first-child select,body.android #btnOrg{width:100%;box-sizing:border-box;min-height:44px!important}
body.android #v-tv:not(.cinema) .cinebar{display:grid!important;grid-template-columns:repeat(auto-fit,minmax(84px,1fr));gap:6px;align-items:stretch}
body.android #v-tv:not(.cinema) #chPrev{order:1}body.android #v-tv:not(.cinema) #chGuide{order:2}body.android #v-tv:not(.cinema) #chTracks{order:3}body.android #v-tv:not(.cinema) #chSubs{order:4}body.android #v-tv:not(.cinema) #chNext{order:5}body.android #v-tv:not(.cinema) #mirDelMinus{order:6}body.android #v-tv:not(.cinema) #mirDelVal{order:7;grid-column:span 2;text-align:center;align-self:center}body.android #v-tv:not(.cinema) #mirDelPlus{order:8}
#chSubs[hidden]{display:none!important}
body.android #v-tv:not(.cinema) .cinebar .cinename{grid-column:1/-1;order:0;text-align:center}
body.android #v-tv:not(.cinema) .cinebar .btn{width:100%;white-space:nowrap;padding-inline:8px;font-size:14px}
body.android #v-tv:not(.cinema) .cinebar #avDelay,body.android #v-tv:not(.cinema) .cinebar .avd{align-self:center;text-align:center}
body.android .tvwrap>.panel:last-child>.row{display:flex;flex-wrap:wrap;gap:10px;align-items:center}
body.android .setcard .row,body.android #v-settings .row{flex-wrap:wrap}
body.android .epgdlg .row{flex-wrap:wrap}

@media (max-width:1100px){body.android #v-tv>.row{gap:8px;flex-wrap:nowrap}body.android #v-tv>.row .btn,body.android #v-tv>.row .tab{font-size:14px;padding:6px 11px;white-space:nowrap;min-height:42px}body.android #v-tv>.row>h1{display:none}}
@media (max-height:640px){body.android #v-tv>h1,body.android #v-tv .row>h1{display:none}body.android .app{grid-template-rows:48px 1fr!important}}
@media (min-width:600px){
  body.android main{min-height:0;overflow-y:auto}
  body.android #v-tv{height:100%;min-height:0;display:flex;flex-direction:column}
  body.android #v-tv:not([hidden]){display:flex}
  body.android .tvwrap{flex:1;min-height:0;grid-template-columns:minmax(250px,34%) minmax(0,1fr)!important;grid-template-rows:minmax(0,1fr);gap:14px}
  body.android .tvwrap>.panel{min-height:0}
  body.android .tvwrap>.panel:last-child{order:0!important;overflow-y:auto}
  body.android .tvwrap>.panel:first-child{display:flex;flex-direction:column;overflow:hidden;gap:8px;padding:12px}
  body.android .tvwrap>.panel:first-child{overflow-y:auto!important}
  body.android .tvwrap>.panel:first-child>*{flex:none}
  body.android .tvwrap>.panel:first-child>.tabs{order:0}
  body.android .tvwrap>.panel:first-child>#tvGroup{order:1}
  body.android .tvwrap>.panel:first-child>#tvSearch{order:2}
  body.android #tvList{order:3;overflow-y:auto;flex:1 1 auto!important;min-height:min(46vh,340px)}
  body.android #btnOrg{order:4}
  body.android #freeTools{order:5}
  body.android #freeTools[hidden]{display:none!important}
  body.android #tvCount{order:6}
  body.android.tv #tvEmpty{display:none!important}
  body.android.tv .tvwrap>.panel:first-child .tabs{flex-wrap:nowrap;overflow-x:auto;gap:6px}
  body.android.tv .tvwrap>.panel:first-child .tab{font-size:13px;padding:5px 10px;min-height:38px;white-space:nowrap}
  body.android.tv .tvwrap>.panel:first-child input,body.android.tv .tvwrap>.panel:first-child select{min-height:40px;padding-block:6px}
  body.android.tv #btnOrg{white-space:nowrap;font-size:14px;min-height:40px}
  body.android.tv #tvCount{display:none}
}
/* modo cinema (ecrã inteiro do leitor) */
body.android .app.cinema{grid-template-rows:1fr!important}
body.android .app.cinema .top{display:none!important}
body.android .app.cinema main{grid-row:1!important;padding:8px 14px!important}
body.android #v-tv.cinema>.row,body.android #v-tv.cinema>.banner{display:none!important}
body.android #v-tv.cinema .tvwrap{display:block!important;grid-template-columns:1fr!important}
body.android #v-tv.cinema .tvwrap>.panel:first-child{display:none!important}
body.android #v-tv.cinema .tvwrap>.panel:last-child{display:flex!important;flex-direction:column;align-items:center;gap:8px;overflow:visible;padding:0!important;border:0!important;background:none!important;height:100%}
body.android #v-tv.cinema .stage{width:min(100%,calc((100vh - 120px) * 16 / 9))!important;margin:0 auto}
body.android #v-tv.cinema .cinebar{width:100%;flex-wrap:nowrap;gap:10px}
body.android #v-tv.cinema .cinebar .btn{min-height:50px;font-size:16px;padding-inline:16px;white-space:nowrap}
body.android #v-tv.cinema .cinename{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:center}
body.android #v-tv.cinema .tvwrap>.panel:last-child>.row,body.android #v-tv.cinema #epgBox{display:none!important}
/* ecrã inteiro do vídeo (OK no vídeo) */
body.android.vfull #v-tv.cinema .cinebar,body.android.vfull #v-tv.cinema .tvwrap>.panel:last-child>.row{display:none!important}
body.android.vfull .app.cinema main{padding:0!important}
body.android.vfull #v-tv.cinema .tvwrap>.panel:last-child{justify-content:center}
body.android.vfull .app{padding:0!important}
body.android.vfull #v-tv.cinema .stage{position:fixed!important;inset:0;z-index:60;width:100vw!important;height:100vh!important;max-height:none;aspect-ratio:auto!important;border-radius:0!important;margin:0!important;background:#000}
body.android.vfull #stage .slot{width:100%!important;height:100%!important;aspect-ratio:auto!important;border-radius:0!important}
body.android.vfull #stage video{object-fit:contain}
body.android.vfull #stage:focus-visible{outline:none!important;box-shadow:none!important}
#fsName{position:fixed;left:24px;bottom:24px;z-index:80;background:rgba(0,0,0,.72);color:#fff;font:600 24px var(--f-display,sans-serif);padding:10px 20px;border-radius:12px;opacity:0;transition:opacity .25s;pointer-events:none;max-width:80vw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#fsName.on{opacity:1}
body.android .top .btn[aria-pressed="true"]{background:var(--accent);color:var(--accent-ink);border-color:var(--accent)}
"""
rep("</style>", CSS + "</style>", count=h.count("</style>")) if h.count("</style>") == 1 else None
if h.count("</style>") != 1:
    i = h.rfind("</style>"); h = h[:i] + CSS + h[i:]

JS = r"""
<script>
/* ===== Cockpit TV (Android): só IPTV ===== */
(function(){
  if(!window.ANDROID) return;
  document.body.classList.add("android");
  const top = document.querySelector(".top"), sp = top.querySelector(".spacer");
  const mk = (txt, v) => { const b = document.createElement("button"); b.className = "btn"; b.textContent = txt; b.onclick = () => show(v); b.dataset.v = v; top.insertBefore(b, sp); return b; };
  const bTv = mk("📺 TV", "tv"), bSet = mk("⚙ Definições", "settings");
  const sync = () => { bTv.setAttribute("aria-pressed", currentView === "tv" ? "true" : "false"); bSet.setAttribute("aria-pressed", currentView === "settings" ? "true" : "false"); };
  const _show = window.show;
  window.show = function(v){ const r = _show.apply(this, arguments); sync(); return r; };
  sync();

  /* Definições: só o que interessa à TV (cartões "TV e IPTV" e "Cópia de segurança") */
  const keep = ["TV e IPTV", "Cópia de segurança"];
  $("v-settings").querySelectorAll(".setgrp, .setcard").forEach(e => {
    if(e.classList.contains("setgrp")){ e.hidden = true; return; }
    const t = (e.querySelector("h2") || {}).textContent || "";
    if(!keep.includes(t.trim())) e.hidden = true;
  });
  const tvCard = [...$("v-settings").querySelectorAll(".setcard")].find(e => (e.querySelector("h2") || {}).textContent.trim() === "TV e IPTV");
  if(tvCard){ const info = document.createElement("p"); info.className = "small muted"; info.style.margin = "0"; info.textContent = "Esta aplicação liga-se diretamente ao servidor IPTV (não precisa de proxy)."; tvCard.insertBefore(info, tvCard.children[1] || null); }

  /* Ficheiro de exportação: o Android abre o seletor para escolheres a pasta e o nome */
  window.androidSaved = (ok, where) => { orgXferMsg(ok ? "Ficheiro guardado: " + where : "Não guardei o ficheiro (cancelaste ou não há seletor de ficheiros). Copia o código da caixa em baixo.", !ok); };
  const eb = $("orgExpFile");
  if(eb){ eb.textContent = "Guardar ficheiro…"; eb.onclick = () => {
    const txt = JSON.stringify(orgExport($("orgInclAcc").checked), null, 1); $("orgXfer").value = txt;
    let ok = false; try{ ok = Android.saveText("cockpit-iptv-definicoes.json", txt); }catch(e){}
    if(!ok) orgXferMsg("Não consegui abrir o seletor. Copia o código da caixa.", true);
  }; }

  /* Informar a parte nativa do Referer a usar nos canais abertos (RTP, SIC, …) */
  const _pc = window.playChannel;
  window.playChannel = function(c){ try{ Android.ctx(refFor(c) || ""); }catch(e){} return _pc.apply(this, arguments); };


  /* ===== Navegação com o comando da TV (D-pad) ===== */
  let dpad = false;
  try{ if(Android.isTv && Android.isTv()){ document.body.classList.add("tv"); dpad = true; } }catch(e){}
  /* Toque ou rato: deixa de ser navegação com o comando. Tocar num campo de texto abre logo o teclado (antes era escondido e ficava a piscar). */
  document.addEventListener("pointerdown", e => {
    dpad = false;
    const t = e.target && e.target.closest ? e.target.closest(TXT) : null;
    if(t){ if(editing && editing !== t) editing = null; t.readOnly = false; }
  }, true);
  const FOC = 'button:not([disabled]),a[href],input:not([type=hidden]):not([disabled]),select:not([disabled]),textarea:not([disabled]),summary,label.btn,[tabindex="0"]';
  const TXT = 'input:not([type]),input[type=text],input[type=search],input[type=url],input[type=password],input[type=email],input[type=number],input[type=tel],textarea';
  const isTxt = el => !!(el && el.matches && el.matches(TXT));
  const prep = () => { document.querySelectorAll(".gdp:not([tabindex])").forEach(e => { e.tabIndex = 0; }); document.querySelectorAll("label.btn").forEach(l => { if(!l.hasAttribute("tabindex")) l.tabIndex = 0; }); const st = $("stage"); if(st && !st.hasAttribute("tabindex")) st.tabIndex = 0; };
  prep();
  const vis = el => el.getClientRects().length > 0 && getComputedStyle(el).visibility !== "hidden" && !el.closest("[inert]");
  const openDlg = () => document.querySelector(".epgdlg:not([hidden]),.trkdlg:not([hidden])");
  const focusables = () => [...(openDlg() || document).querySelectorAll(FOC)].filter(vis);
  const cinema = () => document.querySelector(".app").classList.contains("cinema");
  const scrollParent = el => { for(let n = el; n && n !== document.body; n = n.parentElement){ const s = getComputedStyle(n); if(/(auto|scroll)/.test(s.overflowY) && n.scrollHeight > n.clientHeight + 4) return n; } return document.scrollingElement; };
  const kb = (on) => { try{ on ? Android.showKeyboard() : Android.hideKeyboard(); }catch(e){} };

  /* Campos de texto: o foco com as setas não abre o teclado; só o OK começa a escrever */
  let editing = null;
  const startEdit = el => {
    editing = el; el.readOnly = false;
    /* o campo já tinha o foco só de leitura: volta a focar para o Android ligar o teclado ao campo */
    el.blur(); editing = el;
    setTimeout(() => { editing = el; el.readOnly = false; el.focus(); try{ const n = el.value.length; el.setSelectionRange(n, n); }catch(x){} kb(true); setTimeout(() => kb(true), 250); }, 40);
  };
  const endEdit = () => { if(editing){ const el = editing; editing = null; el.readOnly = true; kb(false); } };
  document.addEventListener("focusin", e => { const el = e.target; if(dpad && isTxt(el) && el !== editing){ el.readOnly = true; kb(false); } }, true);
  let refocusing = 0;
  document.addEventListener("focusout", e => { if(e.target === editing && !refocusing){ setTimeout(() => { if(editing === e.target && document.activeElement !== e.target) endEdit(); }, 120); } }, true);

  /* Atalhos sem medir centenas de elementos: listas e filas do Início */
  function fastMove(cur, dx, dy){
    if(!cur || cur === document.body) return false;
    const go = el => { if(!el) return false; el.focus({preventScroll:true}); el.scrollIntoView({block:"nearest", inline:"nearest"}); return true; };
    const sib = (el, f) => { let n = el; do{ n = f > 0 ? n.nextElementSibling : n.previousElementSibling; }while(n && !(n.matches && n.matches(FOC) && vis(n))); return n; };
    if(dy && cur.classList && (cur.classList.contains("gch") || cur.classList.contains("gdp"))) return go(sib(cur, dy));
    const row = cur.closest && cur.closest("#tvList > .item");
    if(row && dy){
      const idx = [...row.querySelectorAll(FOC)].indexOf(cur); let n = row;
      do{ n = dy > 0 ? n.nextElementSibling : n.previousElementSibling; }while(n && !n.querySelector(FOC));
      if(n){ const f = [...n.querySelectorAll(FOC)]; return go(f[Math.min(Math.max(idx, 0), f.length - 1)]); }
      return false;
    }
    if(currentView === "tvhome" && dy){
      const kp = () => document.querySelector(".thKind[aria-pressed=true]") || document.querySelector(".thKind");
      const hero = () => document.querySelector("#thHero .thBtn.pri") || document.querySelector("#thHero .thBtn");
      const firstCard = () => { const c = document.querySelector(".thRow .thCard"); return c; };
      if(cur.classList.contains("thTab")){ window.__lastTab = cur; if(dy > 0) return go(hero() || kp() || firstCard()); }
      else if(cur.closest("#thHero")){ if(dy > 0) return go(kp() || firstCard()); const lt = window.__lastTab && document.contains(window.__lastTab) ? window.__lastTab : null; const t = lt || document.querySelector(".thTab[aria-current=page]"); if(t) return go(t); }
      else if(cur.classList.contains("thKind")){
        if(dy < 0) return go(hero() || (window.__lastTab && document.contains(window.__lastTab) ? window.__lastTab : null) || document.querySelector(".thTab[aria-current=page]"));
        const row = document.querySelector(".thRow"); if(row){ const cx = cur.getBoundingClientRect().left + cur.offsetWidth / 2; let best = null, bd = Infinity; for(const c of row.querySelectorAll(".thCard")){ const r = c.getBoundingClientRect(), d = Math.abs(r.left + r.width / 2 - cx); if(d < bd){ bd = d; best = c; } } return go(best); }
      }
      else if(dy < 0 && cur.classList.contains("thCard") && cur.closest(".thRow") && !cur.closest(".thRow").previousElementSibling.classList.contains("thRow")) return go(kp());
    }
    const sc = cur.closest && cur.closest(".thScroll");
    if(sc && dx && cur.classList.contains("thCard")) return go(sib(cur, dx));
    if(sc && dy){
      const tr = cur.closest(".thRow"); let n = tr;
      do{ n = dy > 0 ? n.nextElementSibling : n.previousElementSibling; }while(n && !n.querySelector(".thCard"));
      if(!n || !n.classList.contains("thRow")) return false;
      const cx = cur.getBoundingClientRect().left + cur.offsetWidth / 2; let best = null, bd = Infinity;
      for(const c of n.querySelectorAll(".thCard")){ const r = c.getBoundingClientRect(), d = Math.abs(r.left + r.width / 2 - cx); if(d < bd){ bd = d; best = c; } }
      return go(best);
    }
    return false;
  }
  function simpleMove(dx, dy){
    const cur = document.activeElement, els = focusables(); if(!els.length) return false;
    if(!cur || cur === document.body || !els.includes(cur)){ const f = els.find(e => !(e.closest && e.closest(".top"))) || els[0]; f.focus({preventScroll:true}); return true; }
    const cr = cur.getBoundingClientRect(), cx = cr.left + cr.width / 2, cy = cr.top + cr.height / 2;
    let best = null, bd = 1e12;
    for(const el of els){
      if(el === cur) continue; const r = el.getBoundingClientRect(); const mx = r.left + r.width / 2 - cx, my = r.top + r.height / 2 - cy;
      if(dx && mx * dx <= 1) continue; if(dy && my * dy <= 1) continue;
      const d = dx ? Math.abs(mx) + Math.abs(my) * 3 : Math.abs(my) + Math.abs(mx) * 3;
      if(d < bd){ bd = d; best = el; }
    }
    if(!best) return false;
    best.focus({preventScroll:true}); best.scrollIntoView({block:"nearest", inline:"nearest"}); return true;
  }
  function move(dx, dy){
    if(fastMove(document.activeElement, dx, dy)) return;
    const els = focusables(), cur = document.activeElement;
    if(!cur || cur === document.body || !els.includes(cur)){
      const lost = (currentView === "tvhome" ? document.querySelector("#v-tvhome .thBtn.pri,#v-tvhome .thCard,#v-tvhome .thBtn") : null) || els.find(e => !(e.closest && e.closest(".top"))) || els[0];
      if(lost) lost.focus({preventScroll:true}); return;
    }
    const cr = cur.getBoundingClientRect(), ccx = cr.left + cr.width/2, ccy = cr.top + cr.height/2;
    const inTop = e => !!(e.closest && e.closest(".top"));
    if(inTop(cur) && cur.classList && cur.classList.contains("thTab")) window.__lastTab = cur;
    /* Da barra do topo para baixo: entra no conteúdo pelo sítio certo de cada ecrã */
    const entry = () => {
      const q = sel => { const e = document.querySelector(sel); return e && vis(e) ? e : null; };
      if(currentView === "tv") return q('#v-tv .tab[data-kind][aria-selected="true"]') || q("#tvSearch") || q("#tvList .item button");
      if(currentView === "settings") return q("#tvSetGrid .setHead") || null;
      if(currentView === "tvlive") return q("#tvLiveList button") || q("#tvLiveOpen");
      return null;
    };
    if(dy > 0 && inTop(cur) && !openDlg()){
      const en = entry(); if(en){ en.focus({preventScroll:true}); en.scrollIntoView({block:"nearest"}); return; }
      const body = els.filter(e => !inTop(e));
      if(body.length){
        const mt = Math.min(...body.map(e => e.getBoundingClientRect().top));
        let best = null, bd = Infinity;
        for(const e of body){ const r = e.getBoundingClientRect(); if(r.top > mt + 60) continue; const d = Math.abs(r.left + r.width / 2 - ccx); if(d < bd){ bd = d; best = e; } }
        if(best){ best.focus({preventScroll:true}); best.scrollIntoView({block:"nearest", inline:"nearest"}); return; }
      }
    }
    let best = null, bs = Infinity;
    for(const el of els){
      if(el === cur) continue;
      const r = el.getBoundingClientRect(), cx = r.left + r.width/2, cy = r.top + r.height/2;
      let main, cross;
      if(dx){ if((cx - ccx) * dx <= 1) continue; main = Math.max(0, dx > 0 ? r.left - cr.right : cr.left - r.right); cross = Math.max(0, r.top - cr.bottom, cr.top - r.bottom); }
      else  { if((cy - ccy) * dy <= 1) continue; main = Math.max(0, dy > 0 ? r.top - cr.bottom : cr.top - r.bottom); cross = Math.max(0, r.left - cr.right, cr.left - r.right); }
      const off = dx ? Math.abs(cy - ccy) : Math.abs(cx - ccx);
      const sc = main + cross * 3 + off * 0.15;
      if(sc < bs){ bs = sc; best = el; }
    }
    /* Para cima, quando já não há nada acima no conteúdo: volta ao separador atual (caminho inverso) */
    /* linha de cima do conteúdo: Cima volta ao separador atual */
    const topRow = (() => { const body = els.filter(e => !inTop(e)); if(!body.length) return false; const mt = Math.min(...body.map(e => e.getBoundingClientRect().top)); return cr.top <= mt + 70; })();
    if(dy < 0 && !inTop(cur) && !openDlg() && (!best || inTop(best) || topRow || (currentView === "tv" && cur.matches && cur.matches("#v-tv .tab[data-kind]")))){
      const lt = window.__lastTab && document.contains(window.__lastTab) && vis(window.__lastTab) ? window.__lastTab : null; const t = lt || document.querySelector(".thTab[aria-current=page]") || (best && inTop(best) ? best : null) || document.querySelector(".thTab");
      if(t){ t.focus({preventScroll:true}); return; }
    }
    if(best){ best.focus({preventScroll:true}); best.scrollIntoView({block:"nearest", inline:"nearest"}); }
    else if(dy){ const sp = scrollParent(cur); if(sp) sp.scrollBy(0, dy * 180); }
  }
  const clickId = id => { const b = $(id); if(b) b.click(); };
  const onStage = () => document.activeElement === $("stage");
  let lastItem = null;
  const fsEl = document.createElement("div"); fsEl.id = "fsName"; document.body.appendChild(fsEl);
  let fsT = 0;
  const flashName = () => { if(!document.body.classList.contains("vfull")) return; fsEl.textContent = $("chName").textContent; fsEl.classList.add("on"); clearTimeout(fsT); fsT = setTimeout(() => fsEl.classList.remove("on"), 2600); };
  const setVfull = on => { document.body.classList.toggle("vfull", !!on); if(on) flashName(); else fsEl.classList.remove("on"); };
  new MutationObserver(flashName).observe($("chName"), {childList:true, characterData:true, subtree:true});

  /* Ao escolher um canal (OK) passa para o ecrã do leitor; Voltar regressa à lista */
  $("tvList").addEventListener("click", e => {
    const b = e.target.closest("[data-play]"); if(!b || !dpad) return;
    lastItem = b;
    setTimeout(() => {
      if($("stage").classList.contains("single") && currentView === "tv" && !(window.DET && DET.open)){ setVfull(false); if(!cinema()) setCinema(true); $("stage").focus({preventScroll:true}); }
    }, 60);
  });

  /* Nome da tecla: alguns comandos/TVs enviam key vazio ou "Unidentified" para o OK e para as teclas de multimédia */
  const KC = {13:"Enter", 23:"Enter", 66:"Enter", 160:"Enter", 19:"ArrowUp", 20:"ArrowDown", 21:"ArrowLeft", 22:"ArrowRight", 33:"PageUp", 34:"PageDown", 166:"ChannelUp", 167:"ChannelDown", 85:"MediaPlayPause", 179:"MediaPlayPause", 126:"MediaPlay", 127:"MediaPause", 86:"MediaStop", 90:"MediaFastForward", 89:"MediaRewind", 87:"MediaTrackNext", 88:"MediaTrackPrevious", 175:"Guide", 172:"Guide", 165:"Info", 82:"ContextMenu", 4:"GoBack", 111:"Escape", 84:"Voice", 219:"Voice", 231:"Voice"};
  const keyName = e => { const k = e.key; if(k && k !== "Unidentified" && k !== "Dead") return k === "Return" ? "Enter" : k; if(e.code === "NumpadEnter" || e.code === "Enter") return "Enter"; return KC[e.keyCode || e.which] || k || ""; };
  /* diagnóstico: mostra no ecrã o último erro de JavaScript (para saber porque falha algo) */
  (function(){
    let bar = null, t = 0;
    const show = m => { window.__kerr = m; try{ if(!bar){ bar = document.createElement("div"); bar.id = "kerrBar"; bar.style.cssText = "position:fixed;left:8px;bottom:8px;max-width:70vw;z-index:2147483000;background:#7a1020ee;color:#fff;font:12px/1.3 monospace;padding:6px 10px;border-radius:8px;pointer-events:none"; document.body.appendChild(bar); } bar.textContent = "⚠ " + m; bar.style.display = "block"; clearTimeout(t); t = setTimeout(() => { bar.style.display = "none"; }, 20000); }catch(e){} };
    window.addEventListener("error", ev => { if(ev && ev.target && ev.target !== window) return; show(String(ev.message || "erro") + (ev.lineno ? " (linha " + ev.lineno + ")" : "")); });
    window.addEventListener("unhandledrejection", ev => { show("promessa: " + String(ev.reason && ev.reason.message || ev.reason)); });
  })();
  const keyHandler = e => {
    const a = document.activeElement, k = keyName(e);
    if(e.altKey || e.ctrlKey || e.metaKey) return;
    if(!exitDlg.hidden){   /* janela "Sair?": só Esq./Dir. e OK */
      if(k === "ArrowLeft" || k === "ArrowRight"){ e.preventDefault(); e.stopImmediatePropagation(); ($("exNo") === a ? $("exYes") : $("exNo")).focus(); }
      else if(k === "Enter"){ if(a && a.id !== "exNo" && a.id !== "exYes"){ e.preventDefault(); e.stopImmediatePropagation(); $("exNo").focus(); } }
      else if(k === "GoBack" || k === "Escape" || k === "MediaStop"){ e.preventDefault(); e.stopImmediatePropagation(); exClose(); }
      else { e.preventDefault(); e.stopImmediatePropagation(); }
      return;
    }
    const arrow = {ArrowUp:[0,-1], ArrowDown:[0,1], ArrowLeft:[-1,0], ArrowRight:[1,0]}[k];
    if(arrow || k === "PageUp" || k === "PageDown") dpad = true;
    /* a app original muda de canal com Cima/Baixo: aqui isso fica só para o ecrã do leitor */
    const eat = () => { e.preventDefault(); e.stopImmediatePropagation(); };
    if(window.__nxKey && (k === "Enter" || k === "GoBack") && window.__nxKey(k)){ eat(); return; }

    /* escrever num campo */
    if(editing && a === editing){
      if(k === "Enter"){ const el = editing; setTimeout(() => { if(editing === el) endEdit(); }, 30); return; }   /* deixa a pesquisa do campo correr e fecha o teclado */
      if(k === "ArrowUp" || k === "ArrowDown"){ eat(); endEdit(); move(0, arrow[1]); return; }
      return; /* resto das teclas escreve normalmente */
    }
    if(k === "Enter" && isTxt(a) && (a.readOnly || dpad)){ eat(); startEdit(a); return; }

    if(window.NATIVE && NATIVE.active){
      if(k === "MediaPlayPause" || k === "MediaPlay" || k === "MediaPause"){ eat(); try{ Android.ntoggle(); }catch(x){} return; }
      if((k === "MediaFastForward" || k === "MediaRewind") && !NATIVE.live){ eat(); try{ Android.nseek(k === "MediaFastForward" ? 30000 : -30000); }catch(x){} return; }
    }
    if(k === "Voice" && window.__voice){ eat(); window.__voice(); return; }
    if(k === "Guide" || k === "Info"){ const g = $("chGuide"); if(g && g.offsetParent){ eat(); g.click(); } return; }
    if(k === "ContextMenu" || k === "Settings"){ eat(); if(currentView === "tv" && cinema() && typeof trkOpen === "function") trkOpen(); else show("settings"); return; }
    if(k === "MediaStop" || k === "GoBack" || k === "Escape"){ eat(); window.androidBack(); return; }
    if(k === "MediaTrackNext"){ eat(); clickId("chNext"); return; }
    if(k === "MediaTrackPrevious"){ eat(); clickId("chPrev"); return; }
    if(k === "MediaFastForward" || k === "MediaRewind"){ const v = $("vid" + (typeof tvTarget === "number" ? tvTarget : 0)); if(v && isFinite(v.duration) && v.duration > 0){ eat(); v.currentTime = Math.max(0, Math.min(v.duration, v.currentTime + (k === "MediaFastForward" ? 30 : -30))); } return; }
    if(k === "ChannelUp"){ eat(); clickId("chNext"); return; }
    if(k === "ChannelDown"){ eat(); clickId("chPrev"); return; }
    if(k === "PageDown" || k === "PageUp"){ eat(); clickId(k === "PageDown" ? "chNext" : "chPrev"); return; }
    if(k === "MediaPlayPause" || k === "MediaPlay" || k === "MediaPause"){
      const v = $("vid" + (typeof tvTarget === "number" ? tvTarget : 0)); if(v){ eat(); (k === "MediaPause" || (k === "MediaPlayPause" && !v.paused)) ? v.pause() : v.play().catch(()=>{}); } return; }

    if(arrow){
      if(arrow[0] && a && a.type === "range") return;
      eat();
      if(onStage() && cinema() && !openDlg()){
        /* filmes e episódios: Esq./Dir. duas vezes seguidas recuam/avançam 10 s (e continua a saltar enquanto carregares depressa) */
        if(arrow[0]){
          const lp = (typeof lastPlayed !== "undefined" && lastPlayed[0]) || null;
          if(lp && lp.kind !== "live"){
            const now = Date.now(), dir = arrow[0];
            if(window.__lr && window.__lr.d === dir && now - window.__lr.t < 480){
              window.__lr.t = now;
              try{
                if(window.NATIVE && NATIVE.active) Android.nseek(dir * 10000);
                else { const v = $("vid0"); if(v && isFinite(v.duration)) v.currentTime = Math.max(0, Math.min(v.duration, v.currentTime + dir * 10)); }
              }catch(x){}
              const msg = (dir < 0 ? "⏪ −10 s" : "+10 s ⏩");
              try{ if(typeof Android.nhud === "function") Android.nhud(msg); }catch(x){}
              try{ toast(msg); }catch(x){}
              clearTimeout(window.__lrT); window.__lrT = setTimeout(() => { try{ if(typeof Android.nhud === "function") Android.nhud(""); }catch(x){} }, 1100);
            } else window.__lr = {d:dir, t:now};
            return;
          }
        }
        /* ecrã inteiro: todas as setas mudam de canal; com a barra visível: Baixo vai para os botões, Esq./Dir. mudam de canal */
        if(document.body.classList.contains("vfull")){ clickId(arrow[1] < 0 || arrow[0] > 0 ? "chNext" : "chPrev"); return; }
        if(arrow[1] > 0){ const f = [...document.querySelectorAll("#v-tv .cinebar .btn")].find(b => !b.disabled && vis(b)); if(f) f.focus({preventScroll:true}); return; }
        if(arrow[0]) clickId(arrow[0] < 0 ? "chPrev" : "chNext");
        return;
      }
      const before = document.activeElement;
      try{ move(arrow[0], arrow[1]); }catch(err){ window.__kerr = String(err && err.message || err); try{ if(simpleMove(arrow[0], arrow[1])) return; }catch(x){} }
      /* rede de segurança: se o foco não mexeu, tenta o movimento simples (por posição) */
      setTimeout(() => { const n = document.activeElement; if(n === before || n === document.body){ try{ simpleMove(arrow[0], arrow[1]); }catch(x){} } }, 70);
      return;
    }
    if(k === "Enter" && a){
      if(a.classList && (a.classList.contains("setHead") || (a.closest && a.closest("#tvLiveList")))){ e.preventDefault(); e.stopImmediatePropagation(); a.click(); return; }
      if(a === $("stage") && cinema()){ eat(); setVfull(!document.body.classList.contains("vfull")); return; }   /* OK no vídeo: ecrã inteiro / sair do ecrã inteiro */
      if(a.type === "checkbox" || a.type === "radio" || a.tagName === "LABEL" || (a.classList && a.classList.contains("gdp"))){ e.preventDefault(); a.click(); }
    }
  };
  document.addEventListener("keydown", e => {
    try{ keyHandler(e); }
    catch(err){
      window.__kerr = String(err && err.message || err);
      const m = {ArrowUp:[0,-1], ArrowDown:[0,1], ArrowLeft:[-1,0], ArrowRight:[1,0]}[keyName(e)];
      if(m){ try{ e.preventDefault(); e.stopImmediatePropagation(); simpleMove(m[0], m[1]); }catch(x){} }
    }
  }, true);

  /* Foco inicial e foco ao abrir/fechar janelas */
  setTimeout(() => { if(!document.activeElement || document.activeElement === document.body) bTv.focus(); }, 600);
  let prevFocus = null;
  new MutationObserver(() => {
    prep();
    const d = openDlg();
    if(d && !d.contains(document.activeElement)){ if(!prevFocus) prevFocus = document.activeElement; const f = [...d.querySelectorAll(FOC)].filter(vis)[0]; if(f) f.focus(); }
    else if(!d && prevFocus){ const p = prevFocus; prevFocus = null; if(p !== document.body && document.contains(p) && vis(p)) p.focus(); }
  }).observe(document.body, {subtree:true, attributes:true, attributeFilter:["hidden"]});

  /* Botão Voltar */
  /* Confirmação ao sair da app */
  const exitDlg = document.createElement("div"); exitDlg.id = "exitDlg"; exitDlg.hidden = true;
  exitDlg.innerHTML = '<div class="exBox" role="dialog" aria-modal="true"><h2>Sair do Cockpit TV?</h2><p>Queres mesmo fechar a app?</p><div class="exBt"><button class="btn" id="exNo">Ficar</button><button class="btn" id="exYes">Sair</button></div></div>';
  document.body.appendChild(exitDlg);
  const exClose = () => { exitDlg.hidden = true; document.body.classList.remove("exitOpen"); if(exPrev && document.contains(exPrev)) try{ exPrev.focus({preventScroll:true}); }catch(x){} exPrev = null; };
  let exPrev = null;
  const exOpen = () => { exPrev = document.activeElement; exitDlg.hidden = false; document.body.classList.add("exitOpen"); setTimeout(() => $("exNo").focus(), 30); };
  $("exNo").onclick = exClose;
  $("exYes").onclick = () => { try{ Android.exitApp(); }catch(x){} };
  window.androidBack = function(){
    if(!exitDlg.hidden){ exClose(); return true; }
    if(editing){ endEdit(); return true; }
    const d = document.querySelector(".epgdlg:not([hidden]),.trkdlg:not([hidden])");
    if(d){ const b = [...d.querySelectorAll("button")].find(x => /^(fechar|✕|×|close)/i.test(x.textContent.trim())); if(b) b.click(); else d.hidden = true; return true; }
    if(document.querySelector(".app").classList.contains("cinema")){
      if(document.body.classList.contains("vfull")){ setVfull(false); $("stage").focus({preventScroll:true}); return true; }
      if(!onStage() && $("stage").offsetParent){ $("stage").focus({preventScroll:true}); return true; }   /* dos botões volta ao vídeo */
      setCinema(false); setVfull(false); if(window.__stopPlayback) window.__stopPlayback();
      if(window.__homeOrigin){ window.__homeOrigin = false; show("tvhome"); return true; }
      setTimeout(() => { const it = lastItem && document.contains(lastItem) && vis(lastItem) ? lastItem : null; (it || bTv).focus(); if(it) it.scrollIntoView({block:"nearest"}); }, 60);
      return true;
    }
    if(currentView === "settings"){ show("tvhome"); return true; }
    if(currentView === "tv"){ show("tvhome"); return true; }
    exOpen(); return true;
  };
})();
</script>
"""

JS2 = r'''
<script>
/* ===== Cockpit TV: ecrã Início (estilo Android TV) ===== */
(function(){
  if(!window.ANDROID) return;
  const $ = id => document.getElementById(id);
  const esc = t => String(t == null ? "" : t).replace(/[&<>"]/g, m => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[m]));
  /* ===== Retomar filmes e episódios onde ficaste ===== */
  const RES = window.RES = {
    all(){ try{ return LS.get("resume", {}) || {}; }catch(e){ return {}; } },
    at(url){ const e = RES.all()[url]; return e && e.p > 30 && e.d > 0 && e.p < e.d * 0.95 ? Math.max(0, e.p - 5) : 0; },
    save(c, p, d){
      if(!c || !c.url || !(c.kind === "movie" || c.kind === "episode") || !(d > 300) || !(p >= 0)) return;
      const a = RES.all();
      if(p > d * 0.95) delete a[c.url];
      else if(p > 20) a[c.url] = {name:c.name, logo:c.logo || "", url:c.url, kind:c.kind, group:c.group || "", id:c.id || "", p:Math.round(p), d:Math.round(d), t:Date.now()};
      else return;
      const keys = Object.keys(a).sort((x, y) => a[y].t - a[x].t);
      keys.slice(40).forEach(k => delete a[k]);
      try{ LS.set("resume", a); }catch(e){}
    },
    list(kind){ return Object.values(RES.all()).filter(e => e.p > 30 && e.p < e.d * 0.95 && (kind === "movie" ? e.kind === "movie" : e.kind === "episode")).sort((x, y) => y.t - x.t); }
  };
  /* "Continuar a ver" no ecrã inicial do Android TV (Watch Next) */
  const hid = u => { let h = 2166136261; const t = String(u); for(let i = 0; i < t.length; i++){ h ^= t.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0).toString(36); };
  window.__hid = hid;
  (function(){
    const _rs = RES.save; let lastWn = 0;
    RES.save = function(c, p, d){
      _rs.apply(this, arguments);
      try{
        if(typeof Android.watchNext !== "function" || !c || !c.url || !(c.kind === "movie" || c.kind === "episode") || !(d > 300)) return;
        if(p > d * 0.95){ Android.watchNext(hid(c.url), "", "", 0, 0, true); return; }
        if(p > 20 && Date.now() - lastWn > 30000){ lastWn = Date.now(); Android.watchNext(hid(c.url), c.name || "", c.logo || "", Math.round(p * 1000), Math.round(d * 1000), false); }
      }catch(e){}
    };
    window.__openId = id => {
      try{ const e = Object.values(RES.all()).find(x => hid(x.url) === id); if(!e) return; window.__homeOrigin = false; show("tv"); setTimeout(() => playChannel(e), 300); }catch(x){}
    };
    try{ const id = typeof Android.pendingOpen === "function" ? Android.pendingOpen() : ""; if(id) setTimeout(() => window.__openId(id), 1800); }catch(e){}
  })();
  /* leitor da página (fora do nativo): retoma e guarda a posição */
  const _pcR = window.playChannel;
  window.playChannel = function(c){
    const r = _pcR.apply(this, arguments);
    try{
      if(c && (c.kind === "movie" || c.kind === "episode") && !(window.NATIVE && NATIVE.active)){
        const v = $("vid0"), at = RES.at(c.url);
        if(at > 0){ const go = () => { try{ if(isFinite(v.duration) && at < v.duration - 30) v.currentTime = at; }catch(e){} }; v.addEventListener("loadedmetadata", go, {once:true}); }
        if(v._resT) clearInterval(v._resT);
        v._resT = setInterval(() => { if(!lastPlayed[0] || lastPlayed[0].url !== c.url){ clearInterval(v._resT); return; } if(!v.paused && isFinite(v.duration)) RES.save(c, v.currentTime, v.duration); }, 5000);
      }
    }catch(e){}
    return r;
  };
  setInterval(() => { try{ if(NATIVE.active && !NATIVE.live && NATIVE.cur){ const [p, d, lv] = String(Android.npos()).split("|").map(Number); if(!lv) RES.save(NATIVE.cur.c, p / 1000, d / 1000); } }catch(e){} }, 5000);

  /* ===== Google Cast: envia o endereço do vídeo para a Google TV / Chromecast (só no telemóvel) ===== */
  const CAST = window.CAST = {active:false, name:"", cur:null, banner:null,
    mime(c){
      const u = c.url, fx = (typeof fileExt === "function" ? fileExt(u) : "");
      if(/\.m3u8(\?|$)/i.test(u) || (c.kind === "live" && !/\.ts(\?|$)/i.test(u) && !fx)) return "application/x-mpegURL";
      if(fx === "mpd") return "application/dash+xml";
      if(fx === "mkv") return "video/x-matroska";
      if(fx === "webm") return "video/webm";
      if(/^(ts|m2ts|mts)$/.test(fx) || /\.ts(\?|$)/i.test(u)) return "video/mp2t";
      return "video/mp4";
    },
    send(c){
      CAST.cur = c;
      let ref = ""; try{ ref = (typeof refFor === "function" && refFor(c)) || ""; }catch(e){}
      if(ref){ try{ toast("Este canal precisa de cabeçalhos especiais; a TV pode não o conseguir abrir.", true); }catch(e){} }
      try{ Android.cload(c.url, c.name || "", CAST.mime(c), c.kind === "live", Math.round(RES.at(c.url) * 1000)); }catch(e){}
      CAST.ui();
    },
    ui(){
      if(!CAST.banner){
        const d = document.createElement("div"); d.id = "castBanner"; d.hidden = true;
        d.innerHTML = '<span id="castTx"></span><button class="btn" id="castPp">⏯</button><button class="btn" id="castSt">⏹ Parar</button><button class="btn" id="castOff">Desligar</button>';
        document.body.appendChild(d); CAST.banner = d;
        $("castPp").onclick = () => { try{ Android.ctoggle(); }catch(e){} };
        $("castSt").onclick = () => { try{ Android.cmstop(); }catch(e){} };
        $("castOff").onclick = () => { try{ Android.cstop(); }catch(e){} };
      }
      CAST.banner.hidden = !CAST.active;
      $("castTx").textContent = "📡 " + (CAST.cur ? CAST.cur.name + " · " : "") + (CAST.name || "Google TV");
    },
    ev(kind, msg){
      if(kind === "connected"){
        CAST.active = true; CAST.name = msg || "Google TV";
        try{ toast("Ligado a " + CAST.name + ". Escolhe um canal, filme ou série."); }catch(e){}
        const cur = NATIVE.active && NATIVE.cur ? NATIVE.cur.c : null;
        if(cur){ NATIVE.stop(); CAST.send(cur); } else CAST.ui();
      }
      else if(kind === "ended"){ CAST.active = false; CAST.cur = null; CAST.ui(); try{ toast("Transmissão terminada."); }catch(e){} }
      else if(kind === "failed"){ try{ toast("Não consegui ligar à TV (código " + msg + ").", true); }catch(e){} }
      else if(kind === "unavailable"){ try{ toast("Google Cast indisponível neste telemóvel (precisa dos Serviços Google Play).", true); }catch(e){} }
      else if(kind === "error"){ try{ toast("Cast: " + msg, true); }catch(e){} }
    }
  };

  /* ===== Leitor nativo (Media3/ExoPlayer) por cima da área do vídeo ===== */
  const HAS_N = typeof Android.nplay === "function";
  const NAT = window.NATIVE = {active:false, live:false, ready:false, off:new Set(), cur:null, id:0, key:"", timer:0, poll:0,
    go(c, slot, playId, fail){
      if(CAST.active && slot === 0 && c && c.url && c.url.indexOf("series:") !== 0){ NAT.stop(); CAST.send(c); return true; }
      if(!HAS_N || slot !== 0 || !c || !c.url || NAT.off.has(c.url) || !$("stage").classList.contains("single")){ NAT.stop(); return false; }
      const u = c.url, fx = (typeof fileExt === "function" ? fileExt(u) : "");
      const hint = /\.m3u8(\?|$)/i.test(u) ? "hls" : fx === "mpd" ? "dash" : (c.kind === "live" && !/\.ts(\?|$)/i.test(u) && !(typeof FILE_EXT === "function" && FILE_EXT(u))) ? "hls" : "";
      NAT.cur = {c, slot, playId, fail, url:u, triedTs:false}; NAT.live = c.kind === "live"; NAT.id = playId;
      NAT.start(u, hint, c.name);
      return true;
    },
    start(u, hint, title){
      let ref = ""; try{ ref = (typeof refFor === "function" && refFor(NAT.cur.c)) || ""; }catch(e){}
      NAT.active = true; NAT.key = ""; NAT.ready = false; if(!NAT.cur.triedTs || NAT.cur.url === u){ NAT.subBase = ""; NAT.subOff = 0; }
      try{ if(typeof Android.ndeint === "function") Android.ndeint(LS.get("tvDeint", "off") === "adapt"); if(typeof Android.nafr === "function") Android.nafr(LS.get("tvAfr", "on") !== "off"); }catch(e){}
      try{ if(window.__aspect) window.__aspect.apply(false); }catch(e){}
      try{ Android.nplay(u, ref, hint, title || "", Math.round(RES.at(NAT.cur.c.url) * 1000)); }catch(e){ NAT.fallback("sem leitor nativo"); return; }
      clearTimeout(NAT.timer); NAT.timer = setTimeout(() => { if(NAT.active && NAT.cur && !NAT.ready) NAT.fallback("tempo esgotado"); }, 22000);
      NAT.sync(true);
      if(!NAT.poll) NAT.poll = setInterval(() => NAT.sync(false), 160);
    },
    stop(){ clearTimeout(NAT.timer); if(NAT.active){ NAT.saveNow(); NAT.active = false; NAT.cur = null; try{ Android.nstop(); }catch(e){} } },
    fallback(why){
      const cur = NAT.cur; if(!cur) return;
      if(cur.playId !== playSeq[cur.slot]) return;
      NAT.off.add(cur.url); NAT.stop();
      try{ toast("Leitor nativo: " + why + ". A usar o leitor da página…"); }catch(e){}
      window.playChannel(cur.c, cur.slot, true);
    },
    sync(force){
      if(!NAT.active) return;
      const st = $("stage"); if(!st) return;
      const r = st.getBoundingClientRect(); let d = window.devicePixelRatio || 1;
      try{ if(!NAT.si || Date.now() - NAT.siT > 4000){ NAT.si = JSON.parse(Android.screenInfo()); NAT.siT = Date.now(); } if(NAT.si && NAT.si.w && window.innerWidth) d = NAT.si.w / window.innerWidth; }catch(e){}
      const blocked = !!document.querySelector(".epgdlg:not([hidden]),.trkdlg:not([hidden]),#exitDlg:not([hidden])");
      const vis = currentView === "tv" && r.width > 20 && r.height > 20 && !blocked && !document.hidden;
      const x = Math.round(r.left * d), y = Math.round(r.top * d), w = Math.round(r.width * d), h = Math.round(r.height * d);
      const key = x + "," + y + "," + w + "," + h + "," + vis;
      if(force || key !== NAT.key){ NAT.key = key; try{ Android.nrect(x, y, w, h, vis); }catch(e){} }
    },
    saveNow(){ try{ if(!NAT.cur || NAT.live) return; const [p, d, lv] = String(Android.npos()).split("|").map(Number); if(!lv) RES.save(NAT.cur.c, p / 1000, d / 1000); }catch(e){} },
    subBase:"", subOff:0, subLabel:"", subTimer:0,
    subText(text, label){ NAT.subBase = text; NAT.subOff = 0; NAT.subLabel = label || "Português"; try{ $("trkOff").textContent = "0 s"; }catch(e){} try{ Android.nsub(text, NAT.subLabel, "pt"); }catch(e){} },
    shift(d){
      if(!NAT.subBase) return toast("Carrega primeiro um ficheiro de legendas.", true);
      NAT.subOff = Math.round((NAT.subOff + d) * 10) / 10;
      try{ $("trkOff").textContent = (NAT.subOff > 0 ? "+" : "") + NAT.subOff.toLocaleString("pt-PT") + " s"; }catch(e){}
      clearTimeout(NAT.subTimer);
      NAT.subTimer = setTimeout(() => {   /* espera um pouco para juntar vários toques */
        const off = NAT.subOff * 1000;
        const t = NAT.subBase.replace(/(\d{2}):(\d{2}):(\d{2})([,.])(\d{3})/g, (m, h, mi, s, sep, ms) => {
          let v = Math.max(0, ((+h * 60 + +mi) * 60 + +s) * 1000 + +ms + off);
          const H = Math.floor(v / 3600000), M = Math.floor(v / 60000) % 60, S = Math.floor(v / 1000) % 60, MS = Math.floor(v) % 1000;
          const z = (n, l = 2) => String(n).padStart(l, "0");
          return z(H) + ":" + z(M) + ":" + z(S) + sep + z(MS, 3);
        });
        try{ Android.nsub(t, NAT.subLabel, "pt"); }catch(e){}
      }, 700);
    },
    tracks(type){ try{ const j = JSON.parse(Android.ntracks()); return j[type] || []; }catch(e){ return []; } },
    pick(type, i){ try{ Android.ntrack(type, i); }catch(e){} }
  };
  window.__nev = (kind, msg) => {
    if(kind === "open") return window.__openId && window.__openId(msg);
    if(kind === "voice") return window.__voiceDone && window.__voiceDone(msg);
    if(kind === "voice:error"){ try{ toast(msg, true); }catch(e){} return; }
    if(String(kind).indexOf("cast:") === 0) return CAST.ev(kind.slice(5), msg);
    const cur = NAT.cur; if(!NAT.active || !cur) return;
    if(kind === "ready"){ NAT.ready = true; clearTimeout(NAT.timer); }
    else if(kind === "error"){
      if(cur.playId !== playSeq[cur.slot]) return;
      if(cur.c.kind === "live" && /\.m3u8(\?|$)/i.test(cur.url) && /\/live\//.test(cur.url) && !cur.triedTs){
        cur.triedTs = true; NAT.ready = false;
        NAT.start(cur.url.replace(/\.m3u8(\?|$)/i, ".ts$1"), "", cur.c.name); return;
      }
      NAT.fallback(msg || "erro");
    }
    else if(kind === "noaudio"){ try{ toast("Este vídeo tem áudio que a TV não descodifica. Escolhe outra faixa em Áudio.", true); }catch(e){} }
  };


  /* guia: linhas de programas navegáveis pelo comando */
  const _gp = window.gdRenderProg; if(typeof _gp === "function") window.gdRenderProg = function(){ const r = _gp.apply(this, arguments); document.querySelectorAll(".gdp").forEach(e => { e.tabIndex = 0; }); return r; };

  /* parar a reprodução ao sair do canal/filme */
  const stopPlayback = () => { try{ if(window.CAST && CAST.active) Android.cmstop(); }catch(e){} try{ stopSlot(0); lastPlayed[0] = null; epgSlot[0] = null; updateCinemaBar(); }catch(e){} };
  window.__stopPlayback = stopPlayback;

  /* ===== Botão Legendas na barra do leitor ===== */
  (function(){
    const tr = $("chTracks"); if(!tr || $("chSubs")) return;
    const b = document.createElement("button"); b.className = "btn"; b.id = "chSubs"; b.textContent = "💬 Legendas";
    b.onclick = () => { trkOpen(); setTimeout(() => { const f = $("trkSubs").querySelector("button") || $("osGo"); if(f) f.focus({preventScroll:true}); }, 120); };
    tr.after(b);
    const upd = () => { const c = lastPlayed && lastPlayed[0]; b.hidden = !!(c && c.kind === "live"); };
    const _u = window.updateCinemaBar; window.updateCinemaBar = function(){ const r = _u.apply(this, arguments); try{ upd(); }catch(e){} return r; };
    upd();
  })();

  /* ===== Definições: modelos de layout, cor e margens ===== */
  const TPL = [
    ["equilibrado", "Equilibrado", "O padrão: destaque + filas de canais."],
    ["cinema", "Cinema", "Cartões grandes e destaque maior; menos itens por ecrã."],
    ["compacto", "Compacto", "Sem destaque, cartões pequenos: vês muitas categorias de uma vez."],
    ["grelha", "Grelha", "Os canais ficam em grelha, sem deslizar para os lados."],
    ["grande", "Texto grande", "Letra e botões maiores, para ler de longe."]
  ];
  const OVS = [["0", "Sem margem"], ["1", "Margem média"], ["2", "Margem grande"]];
  const TL = window.TVLAYOUT = Object.assign({t:"equilibrado", ov:"0"}, (function(){ try{ return LS.get("tvLayout", {}) || {}; }catch(e){ return {}; } })());
  const applyLayout2 = () => {
    TPL.forEach(([id]) => document.body.classList.toggle("tl-" + id, TL.t === id));
    document.body.classList.remove("ov-0", "ov-1", "ov-2"); document.body.classList.add("ov-" + TL.ov);
    try{ LS.set("tvLayout", {t:TL.t, ov:TL.ov}); }catch(e){}
    document.querySelectorAll("[data-tpl]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.tpl === TL.t)));
    document.querySelectorAll("[data-ov]").forEach(b => b.setAttribute("aria-pressed", String(b.dataset.ov === TL.ov)));
    try{ if(currentView === "tvhome") renderHome(); }catch(e){}
  };
  (function(){
    const st = $("v-settings"); if(!st) return;
    const card = document.createElement("section"); card.className = "setcard panel"; card.id = "tvLayoutCard";
    let h = '<h2>Aparência e layout</h2><p class="small muted" style="margin:0 0 8px">Escolhe um modelo para o ecrã Início. A mudança é imediata.</p><div class="tplGrid">';
    TPL.forEach(([id, nm, ds]) => { h += '<button class="btn tplBtn" data-tpl="' + id + '"><b>' + nm + '</b><small>' + ds + '</small></button>'; });
    h += '</div><h3 style="margin:14px 0 6px">Cor de destaque</h3><div class="tplGrid" id="tvSchemes"></div>';
    h += '<h3 style="margin:14px 0 6px">Margens do ecrã (para TVs que cortam as bordas)</h3><div class="tplGrid">';
    OVS.forEach(([v, nm]) => { h += '<button class="btn tplBtn" data-ov="' + v + '"><b>' + nm + '</b></button>'; });
    h += '</div>';
    card.innerHTML = h;
    const first = [...st.children].find(e => !e.hidden && e.classList && e.classList.contains("setcard"));
    st.insertBefore(card, first || null);
    try{
      const box = $("tvSchemes");
      (typeof SCHEMES !== "undefined" ? SCHEMES : []).forEach(([id, nm, c]) => {
        const b = document.createElement("button"); b.className = "btn tplBtn"; b.dataset.sch = id; b.innerHTML = '<b>' + nm + '</b>';
        b.style.cssText = "border-left:10px solid " + (c && c[1] || "var(--accent)");
        b.onclick = () => { cfg.scheme = id; cfg.light = (id === "claro" || id === "areia"); saveCfg(); applyTheme(); card.querySelectorAll("[data-sch]").forEach(x => x.setAttribute("aria-pressed", String(x.dataset.sch === cfg.scheme))); };
        b.setAttribute("aria-pressed", String(cfg.scheme === id)); box.appendChild(b);
      });
    }catch(e){}
    card.querySelectorAll("[data-tpl]").forEach(b => b.onclick = () => { TL.t = b.dataset.tpl; applyLayout2(); });
    card.querySelectorAll("[data-ov]").forEach(b => b.onclick = () => { TL.ov = b.dataset.ov; applyLayout2(); });
  })();
  applyLayout2();
  const sec = document.createElement("section"); sec.className = "view"; sec.id = "v-tvhome"; sec.hidden = true;
  sec.innerHTML = '<div class="thHero" id="thHero"></div><div id="thRows"></div>';
  $("main").appendChild(sec);

  /* barra de navegação */
  const top = document.querySelector(".top"), sp = top.querySelector(".spacer");
  const nav = document.createElement("nav"); nav.className = "thNav"; nav.setAttribute("aria-label", "Menu");
  [["tvhome","🏠","Início"],["tv","🔎","Explorar"],["guide","📅","Guia"],["settings","⚙","Definições"]].forEach(([v, ic, t]) => {
    const b = document.createElement("button"); b.className = "thTab"; b.dataset.th = v; b.innerHTML = "<span>" + ic + "</span>" + t;
    b.onclick = () => { window.__homeOrigin = false; if(v === "guide") openGuide(); else show(v); };
    nav.appendChild(b);
  });
  top.insertBefore(nav, sp);
  /* Telemóvel: transmitir o ecrã para uma TV (Miracast / Wi-Fi Direct / Cast) */
  let isTvDev = false; try{ isTvDev = !!(Android.isTv && Android.isTv()); }catch(e){}
  if(!isTvDev && typeof Android.cpick === "function"){
    const cb = document.createElement("button"); cb.className = "thTab"; cb.id = "thCast"; cb.innerHTML = "<span>📡</span>Cast";
    cb.onclick = () => { try{ Android.cpick(); }catch(e){ try{ toast("Google Cast indisponível neste telemóvel.", true); }catch(x){} } };
    nav.appendChild(cb);
    if(typeof Android.castScreen === "function"){
      const mb = document.createElement("button"); mb.className = "thTab"; mb.id = "thMirror"; mb.innerHTML = "<span>🖥</span>Espelhar";
      mb.onclick = () => { try{ toast("Escolhe a TV na lista. O ecrã do telemóvel passa a aparecer nela."); }catch(e){} try{ Android.castScreen(); }catch(e){} };
      nav.appendChild(mb);
    }
  }
  { const bs = document.createElement("div"); bs.id = "bStamp"; bs.textContent = "Cockpit TV · versão __BUILD__"; bs.style.cssText = "position:fixed;top:5px;right:12px;z-index:99999;font-size:13px;font-weight:600;color:#fff;opacity:.85;text-shadow:0 1px 3px rgba(0,0,0,.6);pointer-events:none;white-space:nowrap"; document.body.appendChild(bs); }
  const syncNav = () => nav.querySelectorAll(".thTab").forEach(b => b.setAttribute("aria-current", b.dataset.th === currentView ? "page" : "false"));

  /* ===== TV Direto: canais sintonizados pela própria TV (Android TV / Google TV) ===== */
  if(isTvDev){
    const lv = document.createElement("section"); lv.className = "view"; lv.id = "v-tvlive"; lv.hidden = true;
    lv.innerHTML = '<div class="tlWrap"><h2>📡 TV Direto</h2><p id="tvLiveMsg" class="tlMsg"></p>' +
      '<div class="tlBar"><button class="thBtn pri" id="tvLiveOpen">Abrir TV em direto</button><button class="thBtn" id="tvLiveReload">Recarregar canais</button></div>' +
      '<div id="tvLiveBr" class="tlMsg" style="margin:0 0 14px"><b>Canais da TV (Sony Bravia)</b><div class="tlBar" style="margin:8px 0 0"><button class="thBtn" id="brIp"></button><button class="thBtn" id="brPsk"></button><button class="thBtn pri" id="brSave">Guardar e carregar</button></div><div class="tlBar" style="margin:8px 0 0"><button class="thBtn" id="tvvGo">Painel da app por cima da TV</button><button class="thBtn" id="tvvStop">Fechar painel</button></div><div id="tvvMsg" class="tlMsg" style="margin:8px 0 0"></div><div id="brMsg" class="tlMsg" style="margin:8px 0 0"></div></div>' +
      '<div id="tvLiveList" class="tlList"></div><pre id="tvLiveDiag" class="tlMsg" style="font-size:12px;white-space:pre-wrap;opacity:.6;margin-top:18px"></pre></div>';
    $("main").appendChild(lv);
    const st = document.createElement("style");
    st.textContent = '#v-tvlive .tlWrap{padding:24px 32px 60px;max-width:1200px}#v-tvlive h2{margin:0 0 6px;font-size:26px}' +
      '.tlMsg{opacity:.8;margin:0 0 14px;line-height:1.4}.tlBar{display:flex;gap:10px;margin-bottom:16px;flex-wrap:wrap}' +
      '.tlList{display:grid;grid-template-columns:repeat(auto-fill,minmax(240px,1fr));gap:10px}' +
      '.tlList button{display:flex;gap:12px;align-items:center;text-align:left;padding:14px 16px;border-radius:12px;border:2px solid transparent;background:rgba(255,255,255,.07);color:inherit;font-size:17px;cursor:pointer}' +
      '.tlList button:focus,.tlList button:hover{outline:none;border-color:var(--accent,#3b82f6);background:rgba(255,255,255,.14)}' +
      '.tlList .tn{min-width:42px;font-weight:700;opacity:.7}.tlList .pic{width:56px;height:36px;object-fit:contain;flex:none}';
    document.head.appendChild(st);
    const tab = document.createElement("button"); tab.className = "thTab"; tab.dataset.th = "tvlive"; tab.innerHTML = "<span>📡</span>TV Direto";
    tab.onclick = () => { window.__homeOrigin = false; show("tvlive"); };
    const gt = nav.querySelector('[data-th="guide"]'); nav.insertBefore(tab, gt || null);
    const msg = $("tvLiveMsg"), list = $("tvLiveList");
    let loaded = false;
    const load = () => {
      if(BR && BR.ip() && BR.psk() && typeof Android.bravia === "function" && brLoad()) return;
      list.innerHTML = ""; let arr = null, raw = "";
      try{ if(typeof Android.tvChannels !== "function"){ msg.textContent = "Esta versão da app não tem acesso aos canais da TV. Usa 'Abrir TV em direto'."; return; } raw = Android.tvChannels(); arr = JSON.parse(raw); }catch(e){ arr = null; }
      if(arr && !Array.isArray(arr)){ msg.textContent = "A TV não deixou a app ler os canais (" + (arr.error || "sem permissão") + "). Usa 'Abrir TV em direto' para ver os canais na app de TV do sistema."; return; }
      if(!arr || !arr.length){ msg.textContent = "Não encontrei canais acessíveis. Se a TV tem sintonizador, a app de TV do sistema pode não partilhar os canais com apps de terceiros. Usa 'Abrir TV em direto'."; return; }
      arr.sort((a, b) => (parseFloat(a.num) || 1e9) - (parseFloat(b.num) || 1e9) || String(a.name).localeCompare(String(b.name)));
      msg.textContent = arr.length + " canais da TV. OK para ver.";
      const f = document.createDocumentFragment();
      arr.forEach(c => { const b = document.createElement("button"); b.innerHTML = '<span class="tn"></span><span class="tt"></span>'; b.firstChild.textContent = c.num; b.lastChild.textContent = c.name || ("Canal " + c.id); b.onclick = () => { let r = ""; try{ r = Android.tvTune(c.id); }catch(e){ r = "erro"; } try{ toast(String(r).indexOf("ok:") === 0 ? "A abrir " + c.name + "…" : r === "app" ? "A TV não deixou abrir o canal diretamente; abri a app de TV." : "Não consegui abrir o canal.", String(r) === "falhou"); }catch(e){} }; f.appendChild(b); });
      list.appendChild(f); loaded = true;
    };
    /* API Bravia (IP Control): lista os canais da lista própria da Sony e sintoniza-os */
    const BR = {ip:() => LS.get("brIp", "") || "", psk:() => LS.get("brPsk", "") || ""};
    const brCall = (svc, method, params, ver) => { let r; try{ r = JSON.parse(Android.bravia(BR.ip(), BR.psk(), svc, JSON.stringify({method:method, id:1, params:params, version:ver || "1.0"}))); }catch(e){ return {err:"sem resposta (" + e + ")"}; }
      if(r.httpError !== undefined) return {err: r.httpError === 403 ? "403: a Pre-Shared Key está errada ou a autenticação não está em «Pre-Shared Key»" : r.httpError === 0 ? "não consegui ligar à TV em " + BR.ip() + " (" + r.body + ")" : "HTTP " + r.httpError};
      if(r.error) return {err: "erro " + r.error[0] + ": " + r.error[1]};
      return {res: r.result}; };
    /* Canal da lista da TV: sintoniza SEMPRE no sintonizador da TV (nunca troca pelo stream IPTV) */
    const brPlay = (uri, name) => {
      if(brOverlayOn() && typeof Android.overlayStart === "function" && Android.overlayAllowed()){ const ls = (window.__brItems || []).map(c => ({num:String(c.num), name:c.name, uri:c.uri})); if(Android.overlayStart(BR.ip(), BR.psk(), JSON.stringify(ls), uri)){ try{ toast("A sintonizar " + name + " com o painel do Cockpit por cima…"); }catch(e){} return; } } const r = brCall("avContent", "setPlayContent", [{uri:uri}], "1.0"); try{ toast(r.err ? "Não consegui abrir: " + r.err : "A sintonizar " + name + " na TV…", !!r.err); }catch(e){} };
    const brLoad = () => {
      const bm = $("brMsg"); list.innerHTML = ""; bm.textContent = "A ligar à TV…";
      const src = brCall("avContent", "getSourceList", [{scheme:"tv"}], "1.0");
      if(src.err){ bm.textContent = "Falhou: " + src.err; return false; }
      const sources = (src.res[0] || []).map(x => x.source), items = [];
      const errs = [], tried = [];
      const fetchSrc = sc => { let got = 0; for(const ver of ["1.5", "1.2", "1.0"]){ let ok = false; for(let st = 0; st < 2000; st += 50){ const r = brCall("avContent", "getContentList", ver === "1.0" ? [{source:sc, stIdx:st}] : [{source:sc, stIdx:st, cnt:50}], ver); if(r.err){ errs.push(sc + " v" + ver + ": " + r.err); break; } const a = (r.res && r.res[0]) || []; tried.push(sc + " v" + ver + " → " + a.length); ok = true; if(!a.length) break; a.forEach(c => { if((parseFloat(c.dispNum || c.index) || 0) < 800) return; items.push({num:c.dispNum || c.index, name:c.title, uri:c.uri, src:sc}); got++; }); if(a.length < 50) break; } if(got) break; } return got; };
      const srcs = [...new Set(sources.concat(["tv:dvbt", "tv:dvbc", "tv:dvbs"]))];
      srcs.forEach(sc => { if(sc !== "tv:analog" || sources.indexOf(sc) >= 0) fetchSrc(sc); });
      const seen = new Set(); for(let i = items.length - 1; i >= 0; i--){ if(seen.has(items[i].uri)) items.splice(i, 1); else seen.add(items[i].uri); }
      window.__brDebug = {sources:sources, tried:tried, errs:errs};
      window.__brItems = items.slice();
      const ext = brCall("avContent", "getCurrentExternalInputsStatus", [], "1.1");
      const hd = ext.res ? (ext.res[0] || []).filter(x => /hdmi|component|composite|scart/i.test(x.uri)) : [];
      bm.textContent = items.length + " canais (" + sources.join(", ") + ") + " + hd.length + " entradas." + (items.length ? "" : " Detalhe: " + (errs.concat(tried).join(" | ") || "sem resposta") );
      const f = document.createDocumentFragment();
      const mk = (n, t, uri, noPic) => { const b = document.createElement("button"); b.innerHTML = '<span class="tn"></span><span class="tt"></span>'; b.firstChild.textContent = n; b.lastChild.textContent = t; if(!noPic && typeof window.__piconFor === "function"){ const u = window.__piconFor(t); if(u){ const im = document.createElement("img"); im.className = "pic"; im.alt = ""; im.src = u; b.insertBefore(im, b.lastChild); } } b.onclick = () => brPlay(uri, t); f.appendChild(b); };
      items.sort((a, b) => (parseFloat(a.num) || 1e9) - (parseFloat(b.num) || 1e9)).forEach(c => mk(c.num, c.name, c.uri));
      hd.forEach(x => mk("↪", x.title || x.label || x.uri, x.uri, true));
      list.appendChild(f); loaded = true; msg.textContent = items.length ? items.length + " canais da lista da TV. OK para ver." : "A TV respondeu mas sem canais nesta lista."; return true;
    };
    const brShow = () => { $("brIp").textContent = "IP da TV: " + (BR.ip() || "(tocar para escrever)"); $("brPsk").textContent = "Chave: " + (BR.psk() ? "••••••" : "(tocar para escrever)"); };
    try{ if(!BR.ip() && typeof Android.lanIp === "function"){ const ip = Android.lanIp(); if(ip) LS.set("brIp", ip); } }catch(e){}
    const brAsk = (key, title, secret) => { window.__askCb = v => { window.__askCb = null; if(v !== null){ LS.set(key, String(v).trim()); brShow(); } }; try{ Android.askText(title, LS.get(key, "") || "", !!secret); }catch(e){ try{ const v = prompt(title, LS.get(key, "") || ""); if(v !== null){ LS.set(key, v.trim()); brShow(); } }catch(x){} } };
    $("brIp").onclick = () => brAsk("brIp", "IP da TV (ex.: 192.168.1.50)", false);
    $("brPsk").onclick = () => brAsk("brPsk", "Pre-Shared Key da TV", true);
    brShow();
    $("brSave").onclick = () => { brLoad(); };

    /* Experiência TvView: tenta sintonizar ids de canal consecutivos no sintonizador, dentro da app */
    const TV = {run:0, id:0};
    const tvvInput = () => { try{ const d = JSON.parse(Android.tvDiag()); const x = (d.inputs || []).map(t => String(t).split(" | ")[0]).find(t => /DvbTerrCable/.test(t)); if(x) return x; }catch(e){} return "com.sony.dtv.tvinput.tuner/.DvbTerrCableInputService/HW0"; };
    const tvvMsg = t => { const m = $("tvvMsg"); if(m) m.textContent = t; };
    const prevNev = window.__nev;
    window.__nev = (k, m) => { if(String(k).indexOf("tvv:") === 0){ if(TV.run && TV.wait) TV.wait(k, m); return; } return prevNev && prevNev(k, m); };
    /* Painel do Cockpit por cima da TV da Sony (o sintonizador Sony não aceita TvView de apps de terceiros) */
    const brOverlayOn = () => LS.get("brOverlay", true) !== false;
    const ovShow = () => { const b = $("tvvGo"); if(b) b.textContent = "Painel da app por cima da TV: " + (brOverlayOn() ? "Ligado" : "Desligado"); };
    const ovCheck = () => {
      if(typeof Android.overlayAllowed !== "function"){ tvvMsg("Esta versão da app não tem o painel por cima da TV."); return; }
      if(!brOverlayOn()){ tvvMsg("Painel desligado: OK num canal muda a TV para esse canal (sem painel)."); return; }
      if(Android.overlayAllowed()){ tvvMsg("OK num canal: a TV sintoniza-o e o painel do Cockpit aparece por cima (OK muda, CH+/CH− zapping, Voltar fecha)."); return; }
      tvvMsg("Falta a permissão «Sobrepor a outras apps». Se a TV não abrir esse ecrã, ativa-a uma vez a partir de um PC:\n  adb connect " + (BR.ip() || "IP_DA_TV") + "\n  adb shell appops set pt.rui.cockpittv SYSTEM_ALERT_WINDOW allow");
    };
    window.__brOverlayOn = brOverlayOn;
    $("tvvStop").onclick = () => { try{ Android.overlayStop(); }catch(e){} tvvMsg("Painel fechado."); };
    $("tvvGo").onclick = () => {
      LS.set("brOverlay", !brOverlayOn()); ovShow();
      if(brOverlayOn() && typeof Android.overlayAllowed === "function" && !Android.overlayAllowed()){ try{ Android.overlayRequest(); }catch(e){} }
      ovCheck();
    };
    ovShow(); ovCheck();
    const diag = () => { try{ if(typeof Android.tvDiag !== "function") return; const d = JSON.parse(Android.tvDiag()); $("tvLiveDiag").textContent = "Diagnóstico\nEntradas de TV: " + ((d.inputs || []).join("; ") || "nenhuma") + "\nApps que abrem canais: " + ((d.handlers || []).join("; ") || "nenhuma") + (d.error ? "\nErro: " + d.error : ""); }catch(e){} };
    $("tvLiveOpen").onclick = () => { let ok = false; try{ ok = Android.tvOpenLive(); }catch(e){} if(!ok) try{ toast("Não encontrei a app de TV desta TV.", true); }catch(e){} };
    $("tvLiveReload").onclick = load;
    const _sh2 = window.show;
    window.show = function(v){ const r = _sh2.apply(this, arguments); if(currentView === "tvlive"){ syncNav(); if(!loaded) load(); diag(); } return r; };
  }

  /* recentes */
  const REC = "tvRecent";
  const recents = () => LS.get(REC, []) || [];
  const pushRecent = c => { try{ const a = recents().filter(x => x.url !== c.url); a.unshift({name:c.name, logo:c.logo || "", url:c.url, kind:c.kind, group:c.group, id:c.id, free:c.free, intl:c.intl, sid:c.sid}); LS.set(REC, a.slice(0, 24)); }catch(e){} };
  const _pc = window.playChannel;
  window.playChannel = function(c){ try{ if(c && c.url) pushRecent(c); }catch(e){} return _pc.apply(this, arguments); };

  const HOME = {flat:[], lastK:null, kind:(LS.get("thKind", "live") || "live")};
  const KINDS = [["live","📺","Live"],["movie","🎬","Filmes"],["series","🍿","Séries"]];
  const ptGroups = kind => { const m = groupsOf(kind), names = orgGroupList(kind, [...m.keys()], false).filter(isPtGroup); return names.map(n => [n, m.get(n)]); };
  const allCh = () => [...(typeof channels !== "undefined" ? channels : []), ...freeChans, ...intlChans];
  const uniq = l => { const s = new Set(); return l.filter(c => c && c.url && !s.has(c.url) && s.add(c.url)); };
  const groupsOf = kind => { const m = new Map(); channels.filter(c => c.kind === kind).forEach(c => { const g = c.group || "Outros"; if(!m.has(g)) m.set(g, []); m.get(g).push(c); }); return m; };

  function card(c, k, small){
    let sub = c.group || "";
    try{ const nn = nowNext(c); if(nn) sub = hm(nn.now.start) + " " + nn.now.title; }catch(e){}
    if(c._sub) sub = c._sub;
    return '<button class="thCard' + (small ? " sm" : "") + '" data-k="' + k + '"><span class="thArt">' + (c._pct ? '<span class="thBar"><i style="width:' + c._pct + '%"></i></span>' : "") + (c.logo ? '<img src="' + esc(c.logo) + '" alt="" loading="lazy" onerror="this.remove()">' : "") + '<b class="thInit">' + esc((c.name || "?").replace(/[^\p{L}\p{N}]/gu, "").slice(0, 2).toUpperCase()) + '</b></span><span class="thMeta"><b>' + esc(c.name) + '</b><small>' + esc(sub) + '</small></span></button>';
  }
  function row(title, list, more){
    list = uniq(list); if(!list.length) return "";
    const k0 = HOME.flat.length; list.forEach(c => HOME.flat.push(c));
    return '<div class="thRow"><h2>' + title + '</h2><div class="thScroll">' + list.map((c, i) => card(c, k0 + i)).join("") + (more ? '<button class="thCard thMore" data-more="' + more + '"><span>Ver tudo →</span></button>' : "") + '</div></div>';
  }

  /* ===== Lista por operador (MEO / NOS / Vodafone) ===== */
  const OPS = {
    meo:{label:"MEO", src:"MEO: lista oficial de canais (set/26) e grelha de caixa", list:["RTP 1", "RTP 2", "SIC", "TVI", "SIC Notícias", "RTP Notícias|RTP 3", "CNN Portugal|CNN PT", "CMTV", "News Now", "Globo", "11|Canal 11", "V+ TVI|TVI Ficção", "SIC Mulher", "SIC Novelas", "Veja", "Sport TV+", "Sport TV 1", "Sport TV 2", "Sport TV 3", "Sport TV 4", "Sport TV 5", "Sport TV 6", "Benfica TV|BTV", "NBA TV", "Eleven Sports 1|ELEVEN 1", "Eleven Sports 2|ELEVEN 2", "Eleven Sports 3|ELEVEN 3", "A Bola TV", "Porto Canal", "Sporting TV", "W-Sport", "Eurosport 1", "Eurosport 2", "Kombat Sport", "Disney Channel", "Cartoon Network", "Panda Kids", "SIC K", "Nickelodeon", "Disney Junior", "Panda", "Cartoonito", "Nick Jr.", "Baby TV", "Biggs", "Lolly Kids", "TVCine Top", "TVCine Edition", "TVCine Emotion", "TVCine Action", "Cinemundo", "Hollywood", "STAR Movies|FOX Movies", "AMC", "AXN Movies", "STAR Channel|FOX", "STAR Life|FOX Life", "STAR Crime|FOX Crime", "FOX Comedy|STAR Comedy", "AXN", "AXN White", "Syfy", "Dizi Channel|Dizi", "VinTV", "Discovery Channel", "História", "Odisseia", "National Geographic", "National Geographic Wild", "TVI Reality", "RTP Memória", "Canal Q|Q", "SIC Radical", "AMC Break", "Gametoon", "AMC Crime", "TLC", "SIC Caras", "Casa e Cozinha", "24 Kitchen", "Travelxp|Travel Channel", "Fashion TV", "MTV Portugal|MTV", "VH1", "Trace Urban", "MCM Pop", "MCM Top", "Afro Music", "Alma Lusa", "Mezzo", "RTP Açores", "RTP Madeira", "ARTV", "Localvisão TV", "Canção Nova", "UM Europa", "Record Europa|Record TV", "Record News", "Euronews", "RTP África", "TPA Notícias|TPA Internacional", "CNN", "Bloomberg", "Sky News", "BBC World News|BBC World", "France 24", "i24News", "NHK World", "CGTN", "Al Jazeera|AlJazeera", "TRT World", "TVE Internacional|TVEi", "TVE 24h", "TV Galicia", "TV5 Monde", "BFM TV", "BVN", "CCTV 4"]},
    nos:{label:"NOS", src:"NOS: plano de canais digitais (sem caixa)", list:["RTP 1", "RTP 2", "SIC", "TVI", "SIC Notícias", "RTP 3", "CNN Portugal|CNN PT", "CMTV", "Sport TV+", "Globo", "Canal 11|11", "TVI Reality", "SIC Mulher", "SIC Caras", "SIC Radical", "RTP Memória", "Porto Canal", "Sporting TV", "Disney Channel", "Nickelodeon", "Canal Panda|Panda", "Disney Junior", "Cartoon Network", "Nick Jr.", "Biggs", "Hollywood", "AXN Movies", "AXN", "AMC", "FOX", "FOX Life", "AXN White", "Canal Q|Q", "TLC", "MTV Portugal|MTV", "Record TV", "Discovery Channel", "National Geographic", "Odisseia", "Canal História|História", "AMC Break", "24 Kitchen", "Eurosport 1", "Eurosport 2", "Fuel TV", "MTV 00s", "MCM Top", "Mezzo", "MCM Pop", "Record News", "Canal 180", "Kuriakos TV", "Canção Nova", "RTP Madeira", "RTP Açores", "RTP África", "TPA Notícias", "STV Notícias", "Localvisão TV", "Rai Italia", "Euronews", "CNN", "Sky News", "Al Jazeera", "France 24", "CNBC", "Bloomberg", "TVE 24h", "Phoenix InfoNews", "NHK World", "CGTN", "ARTV", "TV Galicia", "TVE Internacional|TVEi", "TV5 Monde", "ARTE", "BVN", "RTL", "DW|Deutsche Welle", "KBS World", "CCTV 4"]},
    vodafone:{label:"Vodafone", src:"Vodafone: grelha sem caixa (ago/2023)", list:["RTP 1", "RTP 2", "SIC", "TVI", "SIC Notícias|SIC N", "RTP 3", "CNN Portugal|CNN", "CMTV", "Sport TV+|SPORTV+", "Globo", "Canal 11|11", "TVI Ficção", "Porto Canal", "SIC Caras", "SIC Radical|SIC R", "SIC Mulher|SIC M", "RTP Memória", "24 Kitchen", "Canal Q", "Eurosport 1|Eurosport", "Eurosport 2", "A Bola TV", "SCP|Sporting TV", "Fuel TV", "Disney Channel", "Disney Junior", "Cartoon Network", "Panda", "Biggs|Panda Biggs", "SIC K", "Cartoonito", "Nickelodeon", "Dizi", "Hollywood", "Cinemundo", "FOX Movies", "FOX", "AXN", "FOX Life", "FOX Crime", "FOX Comedy", "AXN White", "AXN Movies", "Syfy", "AMC", "MTV Portugal|MTV", "MTV 00s|MTV00s", "MCM Top", "C Music", "Trace Urban|Trace", "Trace Toca", "Discovery Channel|Discovery", "National Geographic|Nat Geo", "National Geographic Wild|Nat Geo Wild", "História|Historia", "Odisseia", "AMC Crime", "S+", "Casa e Cozinha", "TVI Reality", "Record TV", "AMC Break", "TLC", "E!", "Fashion TV", "Travel Channel|Travel", "BBC Entertainment", "Food Network", "Ginx", "Insight TV", "Gametoon", "ARTV", "Record News", "Euronews", "Bloomberg", "Sky News", "BBC World News|BBC World", "CNBC", "Al Jazeera|Aljazeera English", "TVE 24h", "DW", "France 24", "RTP Madeira", "RTP Açores", "Localvisão TV", "RTP África", "TPA", "Canal 180|180", "TV Galicia", "TVEi", "TV5 Monde", "RAI Uno|RAI 1", "RT DOC", "Russia Today", "PRO TV International", "NHK World", "Cubavision", "Freedom", "Canção Nova", "Kuriakos TV"]}
  };
  const opKey = () => { try{ return LS.get("tvOp", ""); }catch(e){ return ""; } };
  const opCustom = () => { try{ return String(LS.get("tvOpCustom", "") || ""); }catch(e){ return ""; } };
  const nrm = n => String(n || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/^[\s\W_]*(pt|portugal)\b[\s|:\-\/]*/i, "").replace(/\[[^\]]*\]|\([^)]*\)/g, " ").replace(/\b(fhd|uhd|hd|sd|4k|8k|hevc|h265|raw|plus)\b/g, " ").replace(/[^a-z0-9]+/g, "");
  const opOrder = key => key === "custom" ? opCustom().split(/\r?\n/).map(x => x.trim()).filter(Boolean) : ((OPS[key] || {}).list || []);
  const opTitle = key => key === "custom" ? "Ordem personalizada" : "Canais " + ((OPS[key] || {}).label || "");
  function opChannels(key){
    const live = channels.filter(c => c.kind === "live"); if(!live.length) return [];
    const idx = new Map();
    for(const c of live){ const k = nrm(c.name); if(!k) continue; const a = idx.get(k) || []; a.push(c); idx.set(k, a); }
    const q = c => (/\b(fhd|uhd|4k)\b/i.test(c.name) ? 0 : /\bhd\b/i.test(c.name) ? 1 : 2) + (isPtGroup(c.group) ? 0 : 10);
    const out = [], seen = new Set();
    for(const ent of opOrder(key)){
      let best = null;
      for(const alias of String(ent).split("|")){ const a = idx.get(nrm(alias)); if(a){ for(const c of a) if(!seen.has(c.url) && (!best || q(c) < q(best))) best = c; } }
      if(best){ seen.add(best.url); out.push(best); }
    }
    return out;
  }
  window.__op = {OPS, opKey, opCustom, opChannels, opTitle};
  /* posições das filas (e do ecrã) memorizadas, para voltares ao mesmo sítio */
  HOME.sc = {}; HOME.y = 0; HOME.my = 0;
  const rowKey = r => { const h = r.querySelector("h2"); return HOME.kind + "|" + (h ? h.textContent : ""); };
  document.addEventListener("scroll", e => {
    if(currentView !== "tvhome") return; const t = e.target;
    if(t && t.classList && t.classList.contains("thScroll")){ const r = t.closest(".thRow"); if(r) HOME.sc[rowKey(r)] = t.scrollLeft; }
    else if(t && t.id === "main") HOME.my = t.scrollTop;
    else if(t === document) HOME.y = (document.scrollingElement || document.documentElement).scrollTop;
  }, true);
  const restoreScroll = () => {
    document.querySelectorAll("#thRows .thRow").forEach(r => { const sc = r.querySelector(".thScroll"), v = HOME.sc[rowKey(r)]; if(sc && v) sc.scrollLeft = v; });
    const m = $("main"); if(m && HOME.my) m.scrollTop = HOME.my;
    const d = document.scrollingElement; if(d && HOME.y) d.scrollTop = HOME.y;
  };
  /* o cartão lembrado é identificado pelo canal (url) e pela fila, não pelo índice, que muda quando "Recentes" se atualiza */
  const cardId = el => { try{ const c = HOME.flat[+el.dataset.k]; const r = el.closest(".thRow"); return c ? {u: c.url, r: r ? rowKey(r) : ""} : null; }catch(e){ return null; } };
  const findCard = id => { if(!id) return null; let any = null; for(const el of sec.querySelectorAll("[data-k]")){ const c = HOME.flat[+el.dataset.k]; if(c && c.url === id.u){ const r = el.closest(".thRow"); if(r && rowKey(r) === id.r) return el; any = any || el; } } return any; };
  document.addEventListener("focusin", e => { const t = e.target; if(t && t.dataset && t.dataset.k != null && sec.contains(t)){ HOME.lastK = t.dataset.k; HOME.lastId = cardId(t); } }, true);
  function renderHome(force){
    if(currentView !== "tvhome") return;
    const t0 = Date.now();
    if(!force && HOME._last && t0 - HOME._last < 600){ if(!HOME._pt) HOME._pt = setTimeout(() => { HOME._pt = 0; renderHome(true); }, 650); return; }
    HOME._last = t0;
    let keepSel = null, keepId = null; const ae = document.activeElement;
    if(ae && ae.dataset && ae.dataset.k != null) keepId = cardId(ae);
    if(ae && ae !== document.body && sec.contains(ae) && ae.dataset){ for(const a of ["k", "kind2", "go", "more"]) if(ae.dataset[a] != null){ keepSel = "[data-" + (a === "kind2" ? "kind2" : a) + '="' + ae.dataset[a] + '"]'; break; } }
    const keep = null;
    HOME.flat = [];
    const cur = (lastPlayed && (lastPlayed[0] || lastPlayed[1])) || recents()[0] || null;
    const hasList = channels.length > 0;
    let hero = "";
    if(cur){
      let sub = cur.group || ""; try{ const nn = nowNext(cur); if(nn) sub = hm(nn.now.start) + " " + nn.now.title; }catch(e){}
      HOME.flat.push(cur); const k = HOME.flat.length - 1;
      hero = '<div class="thHeroArt">' + (cur.logo ? '<img src="' + esc(cur.logo) + '" alt="" onerror="this.remove()">' : '<b>' + esc((cur.name || "?").slice(0, 2).toUpperCase()) + '</b>') + '</div><div class="thHeroTx"><small>Continuar a ver</small><h1>' + esc(cur.name) + '</h1><p>' + esc(sub) + '</p><div class="thHeroBt"><button class="thBtn pri" data-k="' + k + '">▶ Ver agora</button><button class="thBtn" data-go="tv">🔎 Explorar canais</button></div></div>';
    } else {
      hero = '<div class="thHeroTx"><small>Cockpit TV</small><h1>Bem-vindo</h1><p>' + (hasList ? "Escolhe um canal em baixo para começar." : "Os canais abertos portugueses já estão disponíveis. Para ver mais, adiciona a tua lista IPTV nas Definições.") + '</p><div class="thHeroBt"><button class="thBtn pri" data-go="tv">🔎 Explorar canais</button><button class="thBtn" data-go="settings">⚙ Definições</button></div></div>';
    }
    const heroChanged = HOME._hh !== hero; if(heroChanged){ $("thHero").innerHTML = hero; HOME._hh = hero; }
    let rows = '<div class="thKinds">' + KINDS.map(([k, ic, t]) => '<button class="thBtn thKind" data-kind2="' + k + '" aria-pressed="' + (HOME.kind === k) + '">' + ic + " " + t + '</button>').join("") + '</div>';
    if(HOME.kind !== "live"){
      const rl = RES.list(HOME.kind).slice(0, 20).map(e => Object.assign({}, e, {_pct:Math.round(e.p / e.d * 100), _sub:(e.group ? e.group + " · " : "") + Math.max(1, Math.round((e.d - e.p) / 60)) + " min restantes"}));
      rows += row("▶ Continuar a ver", rl, "");
    }
    if(HOME.kind === "live"){ const ok = opKey(); if(ok){ const ol = opChannels(ok); if(ol.length) rows += row("📺 " + esc(opTitle(ok)), ol.slice(0, 60), ""); } }
    let pg = ptGroups(HOME.kind), anyCat = false;
    if(!pg.length && HOME.kind !== "live"){
      /* Filmes e séries: as categorias nem sempre começam por «PT». Procura PT/Portugal em qualquer parte do nome; se não houver, mostra as categorias que existirem. */
      const m = groupsOf(HOME.kind), names = orgGroupList(HOME.kind, [...m.keys()], false);
      const re = /(^|[^A-Za-zÀ-ÿ])(PT|PT-PT|PORTUGAL|PORTUGU[EÊ]S|PORTUGUESA|LUSO)([^A-Za-zÀ-ÿ]|$)|🇵🇹/i;
      let sel = names.filter(n => re.test(n));
      if(!sel.length){ sel = names; anyCat = true; }
      pg = sel.map(n => [n, m.get(n)]);
    }
    for(const [g, l] of pg.slice(0, 14)) rows += row(esc(g), l.slice(0, 40), "");
    if(!pg.length && HOME.kind === "live" && !channels.some(c => c.kind === "live")) rows += row("📡 Canais abertos PT", freeChans.filter(c => typeof hState !== "function" || hState(c) !== "dead").slice(0, 40), "free");
    if(!pg.length && !rows.includes("thRow")) rows += '<p class="thEmpty">Sem ' + ((KINDS.find(x => x[0] === HOME.kind) || [])[2] || "conteúdos").toLowerCase() + " carregados. Se a tua lista tem filmes e séries, abre Explorar uma vez para os carregar.</p>";
    if(!rows.includes("thRow") && !rows.includes("thEmpty")) rows += '<p class="thEmpty">' + (typeof freeLoading !== "undefined" && freeLoading ? "A carregar canais…" : "Sem canais para mostrar. Verifica a ligação à internet.") + '</p>';
    const rowsChanged = HOME._rr !== rows; if(rowsChanged){ $("thRows").innerHTML = rows; HOME._rr = rows; }
    if(heroChanged || rowsChanged) restoreScroll();
    if(keepSel && (heroChanged || rowsChanged)){ const el = (keepId && findCard(keepId)) || sec.querySelector(keepSel) || sec.querySelector(".thKind[aria-pressed=true]") || sec.querySelector(".thBtn.pri,.thCard"); if(el) el.focus({preventScroll:true}); }
  }

  function watch(c){
    if(!c) return;
    window.__homeOrigin = true;
    if(c.kind === "series" && c.sid){ openSeries(c); return; }
    playChannel(c);
    setTimeout(() => { if(currentView === "tv"){ if(!document.querySelector(".app").classList.contains("cinema")) setCinema(true); const st = $("stage"); if(st) st.focus({preventScroll:true}); } }, 140);
  }
  sec.addEventListener("click", e => {
    const b = e.target.closest("[data-k],[data-more],[data-go],[data-kind2]"); if(!b) return;
    if(b.dataset.kind2){ HOME.kind = b.dataset.kind2; HOME.lastK = null; try{ LS.set("thKind", HOME.kind); }catch(x){} HOME._hh = HOME._rr = null; renderHome(true); const nb = sec.querySelector('[data-kind2="' + HOME.kind + '"]'); if(nb) nb.focus({preventScroll:true}); return; }
    if(b.dataset.k != null){ HOME.lastK = b.dataset.k; watch(HOME.flat[+b.dataset.k]); }
    else if(b.dataset.more){ window.__homeOrigin = false; show("tv"); const t = document.querySelector('[data-kind="' + b.dataset.more + '"]'); if(t) t.click(); }
    else if(b.dataset.go){ window.__homeOrigin = false; show(b.dataset.go); }
  });

  /* ligações: atualiza o ecrã quando chegam listas */
  let loading = false;
  async function loadAll(){
    if(loading) return; loading = true;
    try{ await ensureFree(false); }catch(e){}
    renderHome();
    try{ await ensureIntl(false); }catch(e){}
    loading = false; renderHome();
  }
  const _show = window.show;
  window.show = function(v){
    const prevV = currentView;
    const r = _show.apply(this, arguments); syncNav();
    if(prevV === "tv" && currentView !== "tv") stopPlayback();
    if(currentView === "tvhome"){
      HOME._hh = HOME._rr = null; renderHome(true); loadAll();
      [60, 250, 700].forEach(ms => setTimeout(() => { if(currentView === "tvhome") restoreScroll(); }, ms));
      setTimeout(() => { if(currentView !== "tvhome") return; const a = document.activeElement; if(a && a !== document.body && sec.contains(a)) return; const k = findCard(HOME.lastId) || (HOME.lastK != null ? sec.querySelector('[data-k="' + HOME.lastK + '"]') : null); (k || sec.querySelector(".thBtn.pri,.thCard") || nav.querySelector(".thTab")).focus({preventScroll:true}); }, 120);
    }
    return r;
  };
  const _ai = window.afterIptv; if(typeof _ai === "function") window.afterIptv = function(){ const r = _ai.apply(this, arguments); try{ renderHome(); }catch(e){} return r; };
  setInterval(() => { if(currentView === "tvhome") renderHome(); }, 60000);
  setTimeout(() => { if(currentView === "tvhome" && (!document.activeElement || document.activeElement === document.body)) (sec.querySelector(".thBtn.pri,.thCard") || nav.querySelector(".thTab")).focus({preventScroll:true}); }, 900);

  /* ===== Detalhes de filmes e séries: sinopse, classificação, trailer; depois decides se vês ===== */
  const DET = window.DET = {open:false, c:null, origin:false, cache:new Map(), tk:0};
  const origPlay = window.playChannel, origSeries = window.openSeries;
  const detId = c => { const m = /\/movie\/[^/]+\/[^/]+\/(\d+)\./.exec(c.url || ""); return m ? m[1] : ""; };
  async function detLoad(c){
    if(DET.cache.has(c.url)) return DET.cache.get(c.url);
    let info = null;
    try{
      if(c.kind === "series" && c.sid){ const j = await xApi("get_series_info", "&series_id=" + c.sid); info = Object.assign({}, j.info || {}); }
      else if(c.kind === "movie"){ const id = detId(c); if(id){ const j = await xApi("get_vod_info", "&vod_id=" + id); info = Object.assign({}, j.info || {}); } }
    }catch(e){}
    info = info || {}; DET.cache.set(c.url, info); return info;
  }
  const dlg = document.createElement("div"); dlg.className = "epgdlg"; dlg.id = "detDlg"; dlg.hidden = true;
  dlg.innerHTML = '<div class="panel detbox" role="dialog" aria-label="Detalhes"><div class="detposter" id="detPoster"></div><div class="dettx"><h2 id="detTitle"></h2><div class="detmeta" id="detMeta"></div><div class="detplot" id="detPlot" tabindex="0"></div><div class="detcrew" id="detCrew"></div><div class="detbt"><button class="btn primary" id="detGo"></button><button class="btn" id="detTrailer">🎞 Trailer</button><button class="btn" id="detClose">Fechar</button></div></div></div>';
  document.body.appendChild(dlg);
  const detClose = () => { dlg.hidden = true; DET.open = false; };
  $("detClose").onclick = () => { detClose(); if(!document.querySelector(".app").classList.contains("cinema")) window.__homeOrigin = false; };
  $("detGo").onclick = () => {
    const c = DET.c; if(!c) return; detClose(); window.__homeOrigin = DET.origin;
    if(c.kind === "series" && c.sid){ origSeries(c); if(currentView !== "tv") show("tv"); return; }
    window.__noDet = true; try{ origPlay(c); }finally{ window.__noDet = false; }
    setTimeout(() => { if(currentView === "tv"){ if(!document.querySelector(".app").classList.contains("cinema")) setCinema(true); const st = $("stage"); if(st) st.focus({preventScroll:true}); } }, 160);
  };
  $("detTrailer").onclick = async () => {
    const c = DET.c; if(!c) return; const t = String(DET.trailer || "").trim();
    let id = /^[\w-]{11}$/.test(t) ? t : ((/(?:v=|youtu\.be\/)([\w-]{11})/.exec(t) || [])[1] || "");
    const q = ((typeof osParse === "function" ? osParse(c.name).title : "") || c.name) + " trailer oficial";
    if(!id && cfg.ytKey){   /* sem trailer no servidor: procura-o no YouTube com a tua chave */
      try{ const r = await fetch("https://www.googleapis.com/youtube/v3/search?part=snippet&maxResults=1&type=video&videoEmbeddable=true&q=" + encodeURIComponent(q) + "&key=" + encodeURIComponent(cfg.ytKey)); const j = await r.json(); id = (((j.items || [])[0] || {}).id || {}).videoId || ""; }catch(e){}
    }
    const url = id ? "https://www.youtube.com/embed/" + id + "?autoplay=1&rel=0&playsinline=1&modestbranding=1" : "https://m.youtube.com/results?search_query=" + encodeURIComponent(q) + "&sp=CAI%3D";   /* ordenado por data: os mais recentes primeiro */
    try{ if(typeof Android.trailer === "function") Android.trailer(url); else window.open(url, "_blank"); }catch(e){ try{ toast("Não consegui abrir o trailer.", true); }catch(x){} }
  };
  async function showDetails(c){
    const tk = ++DET.tk; DET.c = c; DET.origin = !!window.__homeOrigin; DET.open = true; DET.trailer = "";
    const isSeries = c.kind === "series";
    $("detTitle").textContent = c.name; $("detMeta").textContent = c.group || ""; $("detPlot").textContent = "A carregar detalhes…"; $("detCrew").textContent = "";
    $("detPoster").innerHTML = c.logo ? '<img src="' + esc(c.logo) + '" alt="" onerror="this.remove()">' : "<b>" + esc((c.name || "?").slice(0, 2).toUpperCase()) + "</b>";
    const at = RES.at(c.url);
    $("detGo").textContent = isSeries ? "📺 Ver episódios" : at > 0 ? "▶ Continuar" : "▶ Ver agora";
    dlg.hidden = false; setTimeout(() => { if(DET.open) $("detGo").focus({preventScroll:true}); }, 60);
    const i = await detLoad(c); if(tk !== DET.tk || !DET.open) return;
    const y = String(i.releasedate || i.releaseDate || i.year || "").slice(0, 4);
    const rt = parseFloat(i.rating) || (parseFloat(i.rating_5based) || 0) * 2;
    const dur = i.duration || (i.episode_run_time ? i.episode_run_time + " min" : "");
    const meta = [y, dur, i.genre, i.country, i.age ? i.age : ""].filter(Boolean).join(" · ");
    $("detMeta").innerHTML = (rt ? '<b class="detrate">⭐ ' + rt.toFixed(1) + '/10</b> ' : "") + esc(meta || c.group || "");
    $("detPlot").textContent = i.plot || i.description || "Sem sinopse disponível para este título.";
    $("detCrew").innerHTML = (i.director ? "<div><b>Realização:</b> " + esc(i.director) + "</div>" : "") + (i.cast || i.actors ? "<div><b>Elenco:</b> " + esc(i.cast || i.actors) + "</div>" : "");
    DET.trailer = i.youtube_trailer || i.trailer || "";
    const img = i.movie_image || i.cover || (Array.isArray(i.backdrop_path) ? i.backdrop_path[0] : "") || c.logo;
    if(img) $("detPoster").innerHTML = '<img src="' + esc(img) + '" alt="" onerror="this.remove()">';
  }
  window.playChannel = function(c, slot, auto){
    if(c && (c.kind === "movie" || c.kind === "series") && !auto && !window.__noDet && !c._pct && !document.querySelector(".app").classList.contains("cinema") && !(c.kind === "movie" && RES.at(c.url) > 0 && DET.c && DET.c.url === c.url)){ showDetails(c); return; }
    return origPlay.apply(this, arguments);
  };
  window.openSeries = function(c){
    if(c && c.sid && !window.__noDet && !c._pct && !(DET.open === false && DET.skipSeries)){ showDetails(Object.assign({}, c, {kind:"series"})); return; }
    return origSeries.apply(this, arguments);
  };


  /* ===== Ícones nítidos (SVG) no lugar dos emojis do sistema ===== */
  const SV = {
    home:'<path d="M3 11l9-8 9 8"/><path d="M5 10v10h5v-6h4v6h5V10"/>',
    search:'<circle cx="11" cy="11" r="7"/><path d="M21 21l-4.3-4.3"/>',
    guide:'<rect x="3" y="5" width="18" height="16" rx="2.5"/><path d="M3 10h18M8 3v4M16 3v4"/>',
    gear:'<circle cx="12" cy="12" r="3.2"/><path d="M12 2.5v3M12 18.5v3M2.5 12h3M18.5 12h3M5.3 5.3l2.1 2.1M16.6 16.6l2.1 2.1M5.3 18.7l2.1-2.1M16.6 7.4l2.1-2.1"/>',
    play:'<path d="M7 4.5l13 7.5-13 7.5z" fill="currentColor"/>',
    prev:'<path d="M17 5l-10 7 10 7z" fill="currentColor"/>',
    next:'<path d="M7 5l10 7-10 7z" fill="currentColor"/>',
    audio:'<path d="M5 4v16M12 4v16M19 4v16"/><circle cx="5" cy="9" r="2.2" fill="currentColor"/><circle cx="12" cy="15" r="2.2" fill="currentColor"/><circle cx="19" cy="8" r="2.2" fill="currentColor"/>',
    subs:'<path d="M4 5h16v11H10l-4.5 4v-4H4z"/><path d="M8 9h8M8 12h5"/>',
    film:'<rect x="4" y="4" width="16" height="16" rx="2.5"/><path d="M8.5 4v16M15.5 4v16M4 9h4.5M4 15h4.5M15.5 9H20M15.5 15H20"/>',
    cast:'<path d="M3 18a3 3 0 013 3M3 13a8 8 0 018 8M3 8a13 13 0 0113 13"/><path d="M3 5.5V4h18v16h-5.5"/>',
    mirror:'<rect x="3" y="4" width="18" height="12" rx="2.5"/><path d="M8 20h8M12 16v4"/>',
    globe:'<circle cx="12" cy="12" r="9"/><path d="M3 12h18M12 3c3.2 3 3.2 15 0 18M12 3c-3.2 3-3.2 15 0 18"/>',
    star:'<path d="M12 3l2.7 5.6 6.1.9-4.4 4.3 1 6.1L12 17l-5.4 2.9 1-6.1L3.2 9.5l6.1-.9z" fill="currentColor"/>',
    pulse:'<path d="M3 12h4l3-7 4 14 3-7h4"/>',
    tv:'<rect x="3" y="5" width="18" height="12" rx="2.5"/><path d="M8 21h8M12 17v4"/>',
    clap:'<rect x="3" y="9" width="18" height="11" rx="2.5"/><path d="M3 9l2.5-5h4L7 9M9.5 9L12 4h4l-2.5 5M16 9l2.5-5H21l-2 5"/>',
    layers:'<path d="M12 3l9 5-9 5-9-5z"/><path d="M3 13l9 5 9-5"/>',
    clock:'<circle cx="12" cy="12" r="9"/><path d="M12 7v5.2l3.2 2"/>',
    pp:'<path d="M4 4.5l9 7.5-9 7.5z" fill="currentColor"/><path d="M17 5v14M21 5v14"/>',
    stop:'<rect x="6" y="6" width="12" height="12" rx="1.5" fill="currentColor"/>',
    sat:'<circle cx="12" cy="12" r="2" fill="currentColor"/><path d="M7.8 7.8a6 6 0 000 8.4M16.2 7.8a6 6 0 010 8.4M4.9 4.9a10 10 0 000 14.2M19.1 4.9a10 10 0 010 14.2"/>',
    chat:'<path d="M4 5h16v11H10l-4.5 4v-4H4z"/>'
  };
  const EM = {"🏠":"home","🔎":"search","🔍":"search","📅":"guide","⚙":"gear","▶":"play","◀":"prev","🎚":"audio","💬":"subs","🎞":"film","📡":"sat","🖥":"mirror","🌍":"globe","🌎":"globe","★":"star","⭐":"star","🩺":"pulse","📺":"tv","🎬":"clap","🍿":"layers","🕘":"clock","⏯":"pp","⏹":"stop","📖":"layers"};
  const EMRE = new RegExp("(" + Object.keys(EM).join("|") + ")[\\uFE0E\\uFE0F]?", "g");
  const icon = n => '<svg class="ic" viewBox="0 0 24 24" aria-hidden="true">' + (SV[n] || "") + '</svg>';
  const SKIP = "#tvList,#gdList,#gdSched,#orgList,#detPlot,#detCrew,#epgBox,#chName,.thMeta,#trkAudio,#trkSubs,#osRes";
  function iconize(root){
    const w = document.createTreeWalker(root || document.body, NodeFilter.SHOW_TEXT, {acceptNode: n => (n.nodeValue && EMRE.test(n.nodeValue) && (EMRE.lastIndex = 0, true) && n.parentElement && !n.parentElement.closest(SKIP) && n.parentElement.closest("button,h1,h2,h3,.tab,.thTab,.detmeta,label") ) ? NodeFilter.FILTER_ACCEPT : NodeFilter.FILTER_REJECT});
    const list = []; let n; while((n = w.nextNode())) list.push(n);
    list.forEach(t => {
      const frag = document.createElement("span"); frag.style.display = "contents";
      frag.innerHTML = esc(t.nodeValue).replace(EMRE, (m, e) => icon(EM[e]));
      t.replaceWith(frag);
    });
  }
  let icT = 0;
  new MutationObserver(() => { if(icT) return; icT = requestAnimationFrame(() => { icT = 0; try{ iconize(); }catch(e){} }); }).observe(document.body, {childList:true, subtree:true, characterData:true});
  iconize();


  /* ===== Definições organizadas em cartões (que abrem e fecham) ===== */
  (function(){
    const st = $("v-settings"); if(!st || $("tvSetGrid")) return;
    Object.assign(SV, {
      list:'<path d="M8 6h13M8 12h13M8 18h13"/><circle cx="3.5" cy="6" r="1" fill="currentColor"/><circle cx="3.5" cy="12" r="1" fill="currentColor"/><circle cx="3.5" cy="18" r="1" fill="currentColor"/>',
      palette:'<circle cx="12" cy="12" r="9"/><circle cx="8" cy="10" r="1.3" fill="currentColor"/><circle cx="12" cy="7.5" r="1.3" fill="currentColor"/><circle cx="16" cy="10" r="1.3" fill="currentColor"/>',
      save:'<path d="M5 3h11l3 3v15H5z"/><path d="M8 3v6h8V3M8 21v-7h8v7"/>',
      info:'<circle cx="12" cy="12" r="9"/><path d="M12 11v6M12 7.5h.01"/>',
      remote:'<rect x="7" y="2" width="10" height="20" rx="3"/><circle cx="12" cy="8" r="2"/><path d="M12 13v.01M12 17v.01M9 15h.01M15 15h.01"/>',
      chev:'<path d="M9 5l7 7-7 7"/>'
    });
    const META = {"TV e IPTV":["list","Lista IPTV","M3U ou Xtream Codes, guia de programas e qualidade"], "Aparência e layout":["palette","Aparência e layout","Modelos do Início, cor e margens do ecrã"], "Cópia de segurança":["save","Cópia de segurança","Exportar e importar as definições"]};
    const cards = [...st.querySelectorAll(".setcard")].filter(c => !c.hidden);
    const extra = (id, ic, title, sub, html) => { const c = document.createElement("section"); c.className = "setcard panel"; c.id = id; c.innerHTML = "<h2>" + title + "</h2><p class='setsub'>" + sub + "</p>" + html; META[title] = [ic, title, sub]; return c; };
    const keys = [["OK","Abrir / escolher"],["Voltar","Recuar (no Início pede para confirmar a saída)"],["▲ ▼ ◀ ▶","Navegar. No vídeo: ◀ ▶ mudam de canal, ▼ vai aos botões"],["Canal + / −","Mudar de canal"],["Play / Pausa","Pausar o vídeo"],["Avançar / Recuar","Salta 30 s em filmes e séries"],["Info / Guia","Guia de programas do canal"],["Menu","Áudio e legendas, dentro do vídeo"]];
    const remote = extra("setKeys", "remote", "Teclas do comando", "O que faz cada tecla", '<div class="keyList">' + keys.map(k => "<div><b>" + k[0] + "</b><span>" + k[1] + "</span></div>").join("") + "</div>");
    const about = extra("setAbout", "info", "Sobre", "Versão e leitor de vídeo", '<div class="keyList"><div><b>Versão</b><span>' + esc(typeof APP_VERSION !== "undefined" ? APP_VERSION : "") + '</span></div><div><b>Leitor</b><span>' + (HAS_N ? "Nativo (Media3 / ExoPlayer), com recurso ao da página" : "Da página (hls.js / mpegts.js)") + '</span></div><div><b>Teclas</b><span id="kdiag">sem erros</span></div><div><b>Aparelho</b><span>' + (isTvDev ? "Android TV" : "Telemóvel / tablet") + '</span></div></div>');

    Object.assign(SV, {users:'<circle cx="9" cy="8" r="3.5"/><path d="M2.5 20c0-3.6 2.9-6 6.5-6s6.5 2.4 6.5 6"/><circle cx="17.5" cy="9" r="2.5"/><path d="M17 14.2c2.6.2 4.5 2 4.5 5.3"/>'});
    META["Listas e perfis"] = ["users", "Listas e perfis", "Vários fornecedores ou perfis"];
    const prof = extra("setProf", "users", "Listas e perfis", "Vários fornecedores ou perfis", '<div id="profList" class="keyList"></div><label class="f">Nome do perfil<input type="text" id="profName" placeholder="Ex.: Casa, Família, Desporto"></label><div class="row"><button class="btn primary" id="profSave">Guardar a lista atual como perfil</button></div><p class="small muted">Guarda o link M3U ou o servidor Xtream, o utilizador e o guia. Muda de lista com um OK; a anterior continua guardada.</p>');
    const PK = "tvProfiles";
    const pAll = () => { const a = LS.get(PK, []); return Array.isArray(a) ? a : []; };
    const same = (p) => (p.m3u || "") === (cfg.m3u || "") && (p.xs || "") === (cfg.xs || "") && (p.xu || "") === (cfg.xu || "");
    function profRender(){
      const L = pAll(), box = prof.querySelector("#profList");
      box.innerHTML = L.length ? L.map((p, i) => '<div class="profRow"><span><b>' + esc(p.name) + '</b>' + (same(p) ? ' <small>· em uso</small>' : '') + '</span><button class="btn" data-pu="' + i + '">Usar</button><button class="btn" data-pd="' + i + '">Apagar</button></div>').join("") : '<span class="muted">Ainda não há perfis guardados.</span>';
      box.querySelectorAll("[data-pu]").forEach(b => b.onclick = async () => {
        const p = pAll()[+b.dataset.pu]; if(!p) return;
        cfg.m3u = p.m3u || ""; cfg.xs = p.xs || ""; cfg.xu = p.xu || ""; cfg.xp = p.xp || ""; cfg.epg = p.epg || ""; if(p.maxRes) cfg.maxRes = p.maxRes;
        saveCfg(); try{ $("setM3u").value = cfg.m3u; $("setXs").value = cfg.xs; $("setXu").value = cfg.xu; $("setXp").value = cfg.xp; $("setEpg").value = cfg.epg; }catch(e){}
        try{ await IDB.set("channels", []); }catch(e){}
        try{ channels.length = 0; }catch(e){}
        toast("Perfil «" + p.name + "» ativo. A carregar a lista…"); profRender();
        try{ window.__homeOrigin = false; loadIptv(true); show("tvhome"); }catch(e){}
      });
      box.querySelectorAll("[data-pd]").forEach(b => b.onclick = () => { const a = pAll(); a.splice(+b.dataset.pd, 1); LS.set(PK, a); profRender(); });
    }
    prof.querySelector("#profSave").onclick = () => {
      if(!(cfg.m3u || cfg.xs)){ toast("Primeiro guarda uma lista em «Lista IPTV».", true); return; }
      const name = (prof.querySelector("#profName").value || "").trim() || ("Lista " + (pAll().length + 1));
      const a = pAll().filter(p => p.name !== name); a.push({name, m3u:cfg.m3u || "", xs:cfg.xs || "", xu:cfg.xu || "", xp:cfg.xp || "", epg:cfg.epg || "", maxRes:cfg.maxRes}); LS.set(PK, a); prof.querySelector("#profName").value = ""; profRender(); toast("Perfil «" + name + "» guardado.");
    };
    profRender();
    document.head.insertAdjacentHTML("beforeend", "<style>.profRow{display:flex;gap:10px;align-items:center}.profRow span{flex:1;min-width:0}.profRow small{opacity:.7}</style>");

    META["Ordem dos canais"] = ["list", "Ordem dos canais", "Lista no topo por operador"];
    const opc = extra("setOp", "list", "Ordem dos canais", "Lista no topo por operador", '<p class="small muted">Mostra no Início uma lista com os teus canais pela ordem da grelha do operador. A correspondência é feita pelo nome do canal.</p><div id="opBtns" class="keyList"></div><label class="f">Ordem personalizada (um canal por linha; «a|b» para nomes alternativos)<textarea id="opCustom" rows="6" placeholder="RTP 1&#10;RTP 2&#10;SIC&#10;TVI"></textarea></label><p class="small muted" id="opNote"></p>');
    (function(){
      const O = window.__op, box = opc.querySelector("#opBtns"), ta = opc.querySelector("#opCustom"), note = opc.querySelector("#opNote");
      ta.value = O.opCustom();
      const opts = [["", "Desligado"], ["meo", "MEO"], ["nos", "NOS"], ["vodafone", "Vodafone"], ["custom", "Personalizada"]];
      const paint = () => {
        const cur = O.opKey();
        box.innerHTML = opts.map(([k, t]) => '<button class="btn opB' + (cur === k ? " on" : "") + '" data-op="' + k + '" aria-pressed="' + (cur === k) + '">' + (cur === k ? "● " : "○ ") + t + "</button>").join("");
        box.style.flexDirection = "row"; box.style.flexWrap = "wrap";
        box.querySelectorAll("[data-op]").forEach(b => b.onclick = () => { LS.set("tvOp", b.dataset.op); paint(); });
        const n = cur ? O.opChannels(cur).length : 0;
        note.textContent = !cur ? "Sem lista de operador no Início." : (n ? n + " canais da tua lista encontrados." : "Ainda não encontrei canais da tua lista com estes nomes.") + (cur && cur !== "custom" ? " Fonte: " + O.OPS[cur].src + ". Canais premium (ex.: Sport TV) só entram onde a grelha os indica; completa em «Personalizada»." : "");
      };
      ta.oninput = () => { LS.set("tvOpCustom", ta.value); paint(); };
      paint();
    })();
    setInterval(() => { const k = $("kdiag"); if(k) k.textContent = window.__kerr ? "erro: " + window.__kerr : "sem erros"; }, 1500);
    META["Vídeo"] = ["gear", "Vídeo", "Desentrelaçamento"];
    const vid = extra("setVid", "gear", "Vídeo", "Desentrelaçamento", '<p class="small muted">Canais entrelaçados (alguns de TV e desporto em 1080i) podem mostrar “serrilhado” em movimento. «Adaptativo» corrige só os pixels com efeito pente, na GPU. A maioria das TVs já desentrelaça sozinha; ativa só se vires o defeito. Experimental: se o vídeo falhar, volta a «Desligado».</p><div id="vidBtns" class="keyList"></div><p class="small muted" style="margin-top:12px">Taxa de atualização: «Automática» muda o ecrã da TV para a taxa do vídeo (24, 25, 30, 50, 60 Hz ou múltiplos) quando a TV o permite. A TV pode fazer um breve ecrã preto ao mudar.</p><div id="afrBtns" class="keyList"></div>');
    (function(){
      const box = vid.querySelector("#vidBtns");
      const paint = () => { const cur = LS.get("tvDeint", "off"); box.innerHTML = [["off", "Desligado"], ["adapt", "Adaptativo (GPU)"]].map(([k, t]) => '<button class="btn" data-dv="' + k + '" aria-pressed="' + (cur === k) + '">' + (cur === k ? "● " : "○ ") + t + "</button>").join(""); box.style.flexDirection = "row"; box.style.flexWrap = "wrap"; box.querySelectorAll("[data-dv]").forEach(b => b.onclick = () => { LS.set("tvDeint", b.dataset.dv); try{ if(typeof Android.ndeint === "function") Android.ndeint(b.dataset.dv === "adapt"); }catch(e){} paint(); }); };
      paint();
      const ab = vid.querySelector("#afrBtns");
      const paintA = () => { const cur = LS.get("tvAfr", "on"); ab.innerHTML = [["on", "Automática"], ["off", "Desligada"]].map(([k, t]) => '<button class="btn" data-af="' + k + '" aria-pressed="' + (cur === k) + '">' + (cur === k ? "● " : "○ ") + t + "</button>").join(""); ab.style.flexDirection = "row"; ab.style.flexWrap = "wrap"; ab.querySelectorAll("[data-af]").forEach(b => b.onclick = () => { LS.set("tvAfr", b.dataset.af); try{ if(typeof Android.nafr === "function") Android.nafr(b.dataset.af !== "off"); }catch(e){} paintA(); }); };
      paintA();
    })();
    const order = ["TV e IPTV", "Aparência e layout", "Cópia de segurança"];
    const byT = {}; cards.forEach(c => { byT[(c.querySelector("h2") || {}).textContent.trim()] = c; });
    const base = order.map(t => byT[t]).filter(Boolean); const list = base.slice(0, 1).concat([prof, opc], base.slice(1, 2), [vid], base.slice(2), [remote, about]);
    const grid = document.createElement("div"); grid.id = "tvSetGrid";
    const first = cards[0]; if(first && first.parentNode) first.parentNode.insertBefore(grid, first); else st.appendChild(grid);
    list.forEach(card => {
      const t = (card.querySelector("h2") || {}).textContent.trim(), m = META[t] || ["gear", t, ""];
      const sub = card.querySelector(".setsub"); if(sub) sub.remove();
      const body = document.createElement("div"); body.className = "setBody"; body.hidden = true;
      [...card.children].forEach(ch => { if(ch.tagName !== "H2") body.appendChild(ch); });
      const head = document.createElement("button"); head.className = "setHead"; head.setAttribute("aria-expanded", "false");
      head.innerHTML = '<span class="setIc">' + icon(m[0]) + '</span><span class="setT"><b>' + esc(m[1]) + '</b><small>' + esc(m[2]) + '</small></span><span class="chev">' + icon("chev") + '</span>';
      card.appendChild(head); card.appendChild(body); card.classList.add("setfold");
      head.onclick = () => {
        const open = !card.classList.contains("open");
        grid.querySelectorAll(".setcard.open").forEach(o => { o.classList.remove("open"); o.querySelector(".setBody").hidden = true; o.querySelector(".setHead").setAttribute("aria-expanded", "false"); });
        if(open){ card.classList.add("open"); body.hidden = false; head.setAttribute("aria-expanded", "true"); setTimeout(() => card.scrollIntoView({block:"start"}), 30); }
      };
      grid.appendChild(card);
    });
    /* primeira vez (sem lista IPTV): abre logo o cartão da lista */
    try{ if(!(cfg.m3u || cfg.xs)){ const h = grid.querySelector(".setHead"); if(h) h.click(); } }catch(e){}
  })();

  /* ===== Episódio seguinte automático + Saltar intro ===== */
  (function(){
    const st = {off:"", nextAt:0, tick:null, shown:"", act:null};
    const bar = document.createElement("div"); bar.id = "nxBar"; bar.hidden = true;
    bar.innerHTML = '<span id="nxTx"></span><button class="btn" id="nxGo">OK</button><button class="btn" id="nxNo">Cancelar</button>';
    document.body.appendChild(bar);
    document.head.insertAdjacentHTML("beforeend", "<style>#nxBar{position:fixed;right:24px;bottom:26px;z-index:60;display:flex;align-items:center;gap:10px;padding:12px 16px;border-radius:16px;background:#1a2b44ee;box-shadow:0 8px 30px #000a;font-size:18px}#nxBar[hidden]{display:none}body.phone #nxBar{bottom:78px;right:10px;left:10px;font-size:15px}body.vfull #nxBar{display:none}</style>");
    const cur = () => { try{ return lastPlayed && lastPlayed[0]; }catch(e){ return null; } };
    const pos = () => { try{
      if(NATIVE.active && !NATIVE.live && NATIVE.cur){ const a = String(Android.npos()).split("|").map(Number); if(!a[2]) return {p:a[0] / 1000, d:a[1] / 1000}; return null; }
      const v = $("vid0"); if(v && isFinite(v.duration) && v.duration > 0) return {p:v.currentTime, d:v.duration};
    }catch(e){} return null; };
    const seekBy = s => { try{ if(NATIVE.active) Android.nseek(s * 1000); else { const v = $("vid0"); v.currentTime = Math.min(v.duration - 1, v.currentTime + s); } }catch(e){} };
    const idxOf = c => { const L = window.EPL && EPL.list; if(!L || !c) return -1; return L.findIndex(e => e.url === c.url); };
    function hide(){ bar.hidden = true; st.act = null; st.shown = ""; try{ if(typeof Android.nhud === "function") Android.nhud(""); }catch(e){} }
    function show(txt, goLabel, act, noLabel){
      st.act = act; $("nxTx").textContent = txt; $("nxGo").textContent = goLabel; $("nxNo").textContent = noLabel || "Cancelar"; bar.hidden = false;
      try{ if(typeof Android.nhud === "function") Android.nhud(txt + "  ·  OK: " + goLabel); }catch(e){}
    }
    $("nxGo").onclick = () => { const a = st.act; hide(); if(a) a(); };
    $("nxNo").onclick = () => { const c = cur(); if(c) st.off = c.url + "|" + st.shown; hide(); };
    window.__nxKey = k => { if(bar.hidden || !st.act) return false; if(k === "Enter" && document.body.classList.contains("vfull")){ const a = st.act; hide(); a(); return true; } if(k === "GoBack" && document.body.classList.contains("vfull")){ $("nxNo").onclick(); return true; } return false; };
    setInterval(() => {
      const c = cur(); if(!c || c.kind !== "episode"){ if(!bar.hidden) hide(); return; }
      const t = pos(); if(!t){ return; }
      const i = idxOf(c), L = window.EPL && EPL.list;
      const left = t.d - t.p;
      if(i >= 0 && L[i + 1] && t.d > 120 && left <= 12){
        const key = c.url + "|next"; if(st.off === key) return;
        st.shown = "next"; const n = Math.max(0, Math.ceil(left));
        show("Episódio seguinte em " + n + " s", "Ver agora", () => { const nx = L[i + 1]; if(nx) playChannel(nx); }, "Cancelar");
        if(left <= 1.2){ const nx = L[i + 1]; hide(); st.off = key; if(nx) playChannel(nx); }
        return;
      }
      if(t.p > 4 && t.p < 180 && t.d > 600){
        const key = c.url + "|intro"; if(st.off === key) return;
        st.shown = "intro"; show("Saltar intro?", "Saltar 85 s", () => { st.off = c.url + "|intro"; seekBy(85); }, "Não");
        return;
      }
      if(!bar.hidden) hide();
    }, 1000);
  })();

  /* ===== Pesquisa por voz ===== */
  (function(){
    SV.mic = '<rect x="9" y="3" width="6" height="11" rx="3"/><path d="M5 11a7 7 0 0 0 14 0M12 18v3M9 21h6"/>';
    const can = typeof Android.voice === "function";
    const strip = t => String(t || "").toLowerCase().replace(/[.,!?]/g, " ").replace(/\s+/g, " ").trim();
    window.__voice = () => { if(!can){ try{ toast("Pesquisa por voz só existe na app Android.", true); }catch(e){} return; } try{ toast("🎤 A ouvir…"); }catch(e){} try{ Android.voice(); }catch(e){} };
    window.__voiceDone = txt => {
      let q = strip(txt), kind = "live", play = false;
      if(/^(ver|vê|ve|pôr|põe|poe|pôr no|abre|abrir|mostra|mostrar|liga|sintoniza)\b/.test(q)){ play = true; q = q.replace(/^(ver|vê|ve|pôr no|pôr|põe|poe|abre|abrir|mostra|mostrar|liga|sintoniza)\s+/, ""); }
      if(/^(o |a |os |as )?(filme|filmes)\b/.test(q)){ kind = "movie"; q = q.replace(/^(o |a |os |as )?(filmes?)\s*/, ""); }
      else if(/^(o |a |os |as )?(s[ée]rie|s[ée]ries)\b/.test(q)){ kind = "series"; q = q.replace(/^(o |a |os |as )?(s[ée]ries?)\s*/, ""); }
      q = q.replace(/^(o |a |os |as )?(canal)\s+/, "").replace(/^(o |a )\s*/, "").trim();
      if(!q) return;
      try{ toast("🎤 «" + q + "»"); }catch(e){}
      try{ window.__homeOrigin = false; show("tv"); }catch(e){}
      setTimeout(() => {
        try{ const kb = document.querySelector('[data-kind="' + kind + '"]'); if(kb && kb.getAttribute("aria-pressed") !== "true") kb.click(); }catch(e){}
        const inp = $("tvSearch"); if(inp){ inp.value = q; inp.dispatchEvent(new Event("input", {bubbles:true})); }
        if(play){
          setTimeout(() => { try{ const n = (typeof norm === "function" ? norm(q) : q); const best = channels.filter(c => c.kind === kind && (typeof norm === "function" ? norm(c.name) : c.name.toLowerCase()).includes(n)).sort((a, b) => a.name.length - b.name.length)[0]; if(best){ if(best.kind === "series" && best.sid) openSeries(best); else playChannel(best); } }catch(e){} }, 250);
        } else { const f = document.querySelector("#tvList [data-play]"); if(f) f.focus({preventScroll:true}); }
      }, 200);
    };
    /* botão do microfone ao lado da pesquisa */
    const inp = $("tvSearch");
    if(inp && !$("voiceBtn")){
      const b = document.createElement("button"); b.className = "btn"; b.id = "voiceBtn"; b.type = "button"; b.setAttribute("aria-label", "Pesquisa por voz"); b.innerHTML = icon("mic") + " Voz";
      b.onclick = () => window.__voice();
      inp.after(b);
    }
    if(!can){ const b = $("voiceBtn"); if(b) b.hidden = true; }
  })();

  /* ===== Vista dupla: 2 canais lado a lado ===== */
  (function(){
    const cb = $("chSubs") ? $("chSubs").parentNode : (document.querySelector("#v-tv .cinebar")); if(!cb || $("mvBtn")) return;
    SV.dual = '<rect x="3" y="5" width="8" height="14" rx="1.5"/><rect x="13" y="5" width="8" height="14" rx="1.5"/>';
    const mk = (id, html, fn) => { const b = document.createElement("button"); b.className = "btn"; b.id = id; b.type = "button"; b.innerHTML = html; b.onclick = fn; cb.appendChild(b); return b; };
    let on = false;
    const modeBtn = m => document.querySelector('[data-mode="' + m + '"]');
    const paint = () => {
      $("mvBtn").innerHTML = on ? icon("dual") + " Sair" : icon("dual") + " Dupla";
      ["mvT0", "mvT1", "mvAud", "mvMode"].forEach(i => { $(i).hidden = !on; });
      try{ const cur = (["split", "pip", "splitv"].find(m => $("stage").classList.contains(m))) || "split"; $("mvMode").innerHTML = "⧉ " + ({split:"50/50", pip:"PIP", splitv:"Cima/baixo"})[cur]; }catch(e){}
      $("mvT0").setAttribute("aria-pressed", String(tvTarget === 0)); $("mvT1").setAttribute("aria-pressed", String(tvTarget === 1));
      $("mvAud").innerHTML = "🔊 Som " + (audioSlot + 1);
      $("mvT0").classList.toggle("on", tvTarget === 0); $("mvT1").classList.toggle("on", tvTarget === 1);
    };
    let wasCin = false;
    mk("mvBtn", "", () => {
      if(!on){
        const c0 = lastPlayed[0]; on = true;
        wasCin = document.querySelector(".app").classList.contains("cinema");
        try{ NATIVE.stop(); }catch(e){}
        /* a lista de canais tem de estar visível: sai do modo cinema e do ecrã inteiro */
        try{ setCinema(false); }catch(e){} document.body.classList.remove("vfull");
        modeBtn("split").click(); setTarget(1);
        if(c0){ try{ playChannel(c0, 0); }catch(e){} }
        try{ toast("Vista dupla: escolhe na lista o canal do ecrã 2 (OK). «Ecrã 1/2» muda o destino."); }catch(e){}
        setTimeout(() => { const f = document.querySelector("#tvList [data-play]") || document.querySelector("#tvSearch"); if(f) f.focus({preventScroll:true}); }, 200);
      } else {
        const c0 = lastPlayed[0]; on = false;
        try{ stopSlot(1); lastPlayed[1] = null; }catch(e){}
        modeBtn("single").click(); setTarget(0);
        if(c0){ try{ playChannel(c0, 0); }catch(e){} if(wasCin){ try{ setCinema(true); $("stage").focus({preventScroll:true}); }catch(e){} } }
      }
      paint(); try{ updateCinemaBar(); }catch(e){}
    });
    const modes = ["split", "pip", "splitv"], names = {split:"50/50", pip:"PIP", splitv:"Cima/baixo"};
    mk("mvMode", "", () => { const cur = (modes.find(m => $("stage").classList.contains(m))) || "split"; const nx = modes[(modes.indexOf(cur) + 1) % modes.length]; modeBtn(nx).click(); paint(); });
    mk("mvT0", "Ecrã 1", () => { setTarget(0); paint(); });
    mk("mvT1", "Ecrã 2", () => { setTarget(1); paint(); });
    mk("mvAud", "", () => { $("btnSwapAudio").click(); paint(); });
    document.head.insertAdjacentHTML("beforeend", "<style>#mvBtn[hidden],#mvT0[hidden],#mvT1[hidden],#mvAud[hidden],#mvMode[hidden]{display:none!important}.cinebar .btn.on{background:var(--accent);color:var(--accent-ink)}body.android .stage.split .slot{outline:2px solid transparent}body.android .stage.split .slot.active{outline-color:var(--accent);outline-offset:-3px}</style>");
    paint();
    /* Telemóvel: botão Cast no leitor quando há um canal/filme ligado */
    if(!isTvDev && typeof Android.cpick === "function"){
      SV.cast = '<path d="M3 18a3 3 0 0 1 3 3M3 14a7 7 0 0 1 7 7M3 10a11 11 0 0 1 11 11"/><path d="M3 6V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/>';
      const cc = mk("chCast", icon("cast") + " Cast", () => { try{ Android.cpick(); }catch(e){ try{ toast("Google Cast indisponível neste telemóvel.", true); }catch(x){} } });
      const upd = () => { const on = !!(window.CAST && CAST.active), has = !!(lastPlayed && (lastPlayed[0] || lastPlayed[1])); cc.hidden = !(has || on); cc.classList.toggle("on", on); cc.innerHTML = icon("cast") + (on ? " " + (CAST.name || "Cast") : " Cast"); };
      document.head.insertAdjacentHTML("beforeend", "<style>#chCast[hidden]{display:none!important}</style>");
      const _u = window.updateCinemaBar; window.updateCinemaBar = function(){ const r = _u.apply(this, arguments); try{ upd(); }catch(e){} return r; };
      setInterval(upd, 1500); upd();
    }
    /* a vista dupla só faz sentido no Explorar */
    const _sh = window.show; window.show = function(v){ if(on && v !== "tv" && v !== "guide"){ /* mantém */ } return _sh.apply(this, arguments); };
  })();

  /* ===== Picons: logótipos de canais em alta resolução (PT), guardados no aparelho ===== */
  (function(){
    const BASE = "https://cdn.jsdelivr.net/gh/tv-logo/tv-logos@main/countries/portugal/";
    const FB = new Map();            /* candidato -> próximo candidato / logótipo do fornecedor */
    let PIC = {}, MISS = {}, ready = false, dirty = 0, saveT = 0;
    const slug = n => String(n || "").normalize("NFD").replace(/[̀-ͯ]/g, "").toLowerCase()
      .replace(/^[\s\W_]*(pt|portugal)\b[\s|:\-\/]*/i, "").replace(/\[[^\]]*\]|\([^)]*\)/g, " ")
      .replace(/\b(fhd|uhd|hd|sd|4k|8k|hevc|h265|raw)\b/g, " ")
      .replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "");
    const ptc = c => c.kind === "live" && (isPtGroup(c.group) || /^[\s\W_]*(PT|PORTUGAL)\b/i.test(c.name || ""));
    const persist = () => { clearTimeout(saveT); saveT = setTimeout(() => { idle(() => { try{ IDB.set("picons", PIC); IDB.set("picons_miss", MISS); }catch(e){} }); }, 15000); };
    function patch(){
      if(!ready) return;
      try{
        for(const c of channels){
          if(!ptc(c)) continue;
          if(c.logo0 === undefined) c.logo0 = c.logo || "";
          const sl = slug(c.name); if(!sl || sl.length < 2) continue;
          const cand = [...new Set([sl + "-pt.png", sl.replace(/-(\d)/g, "$1") + "-pt.png", sl.replace(/^(canal|tv)-/, "").replace(/-(canal|tv)$/, "") + "-pt.png", sl + ".png"])].map(x => BASE + x);
          const hit = cand.find(u => PIC[u]);
          if(hit){ c.logo = PIC[hit]; continue; }                           /* já guardado no aparelho */
          const left = cand.filter(u => !MISS[u]);                           /* ignora os que já sabemos que não existem */
          if(!left.length){ c.logo = c.logo0; continue; }
          left.forEach((u, i) => FB.set(u, i + 1 < left.length ? left[i + 1] : c.logo0));
          c.logo = left[0];
        }
      }catch(e){}
    }
    /* Para outras listas (TV Direto): devolve o logótipo guardado no aparelho, ou o 1.º endereço a tentar (a cadeia de alternativas e a gravação local tratam do resto) */
    window.__piconFor = name => {
      try{
        const sl = slug(name); if(!sl || sl.length < 2) return "";
        const cand = [...new Set([sl + "-pt.png", sl.replace(/([a-z])(\d)/g, "$1-$2") + "-pt.png", sl.replace(/-(\d)/g, "$1") + "-pt.png", sl.replace(/^(canal|tv)-/, "").replace(/-(canal|tv)$/, "") + "-pt.png", sl + ".png"])].map(x => BASE + x);
        const hit = cand.find(u => PIC[u]); if(hit) return PIC[hit];
        const left = cand.filter(u => !MISS[u]); if(!left.length) return "";
        left.forEach((u, i) => FB.set(u, i + 1 < left.length ? left[i + 1] : ""));
        return left[0];
      }catch(e){ return ""; }
    };
    /* falhou: lembra-se para não voltar a pedir */
    document.addEventListener("error", ev => {
      const im = ev.target; if(!im || im.tagName !== "IMG" || !FB.has(im.src)) return;
      const bad = im.src; if(bad.indexOf(BASE) === 0){ MISS[bad] = 1; dirty++; persist(); }
      const o = FB.get(bad); ev.stopImmediatePropagation();
      if(o) im.src = o; else im.remove();
    }, true);
    /* carregou: guarda uma miniatura pequena (≈160 px) no aparelho, feita quando a TV está livre */
    const q = [];
    let busy = false;
    const idle = fn => (window.requestIdleCallback ? requestIdleCallback(fn, {timeout:4000}) : setTimeout(fn, 600));
    function pump(){
      if(busy || !q.length) return; busy = true;
      idle(async () => {
        const u = q.shift();
        try{
          if(!PIC[u] && Object.keys(PIC).length < 700){
            const r = await fetch(u, {cache:"force-cache"}); const blob = r.ok ? await r.blob() : null;
            if(blob && blob.size < 400000){
              const bm = await createImageBitmap(blob), k = Math.min(1, 160 / Math.max(bm.width, bm.height));
              const cv = document.createElement("canvas"); cv.width = Math.max(1, Math.round(bm.width * k)); cv.height = Math.max(1, Math.round(bm.height * k));
              cv.getContext("2d").drawImage(bm, 0, 0, cv.width, cv.height);
              const d = cv.toDataURL("image/webp", 0.85);
              if(d && d.length < 40000){ PIC[u] = d; dirty++; persist(); }
            }
          }
        }catch(e){}
        busy = false; setTimeout(pump, 250);
      });
    }
    document.addEventListener("load", ev => {
      const im = ev.target; if(!im || im.tagName !== "IMG" || !im.src || im.src.indexOf(BASE) !== 0 || PIC[im.src] || q.includes(im.src)) return;
      if(q.length < 200) q.push(im.src); pump();
    }, true);
    const _ai = window.afterIptv;
    if(typeof _ai === "function") window.afterIptv = function(){ patch(); return _ai.apply(this, arguments); };
    Promise.all([IDB.get("picons"), IDB.get("picons_miss")]).then(([a, m]) => { if(a && typeof a === "object") PIC = a; if(m && typeof m === "object") MISS = m; }).catch(() => {}).then(() => {
      ready = true; patch();
      try{ if(channels.length && currentView === "tvhome") window.show("tvhome"); }catch(e){}
    });
    document.head.insertAdjacentHTML("beforeend", "<style>.thArt img,.gch img,#tvList img{object-fit:contain!important}</style>");
  })();

  /* ===== Telemóvel: deteta ecrã estreito e ajusta o layout sozinho ===== */
  (function(){
    let tvd = false; try{ tvd = !!(Android.isTv && Android.isTv()); }catch(e){}
    const mq = window.matchMedia("(max-width: 900px)");
    /* telemóvel na horizontal: desenha como numa TV (1440 px lógicos) e reduz, para caberem muitos cartões e ícones normais */
    const apply = () => {
      const w = window.innerWidth, hh = window.innerHeight;
      const land = !tvd && w > hh && hh <= 560 && w >= 560;
      const ph = !tvd && !land && (mq.matches || w < 900);
      document.documentElement.style.setProperty("--ps", (w / 1440).toFixed(4));
      document.body.classList.toggle("pland", land);
      document.body.classList.toggle("phone", ph); document.documentElement.classList.toggle("phoneh", ph || land);
    };
    apply(); try{ mq.addEventListener("change", apply); }catch(e){ mq.addListener(apply); }
    window.addEventListener("resize", apply); window.addEventListener("orientationchange", () => setTimeout(apply, 200));
  })();

  /* ===== Formato da imagem (ajustar, zoom/panscan, esticar, 16:9, 4:3, 21:9) e ecrã total no telemóvel ===== */
  (function(){
    const ASP = [["fit", "Ajustar"], ["zoom", "Zoom / Panscan"], ["stretch", "Esticar"], ["16:9", "16:9"], ["4:3", "4:3"], ["21:9", "21:9 cinema"]];
    const kindNow = () => { try{ const c = lastPlayed[0] || (NAT && NAT.cur && NAT.cur.c); return (c && c.kind) || "live"; }catch(e){ return "live"; } };
    const getA = () => LS.get("tvAspect_" + kindNow(), "fit") || "fit";
    const labelOf = k => (ASP.find(a => a[0] === k) || ASP[0])[1];
    const applyWeb = () => {
      const mode = getA();
      document.querySelectorAll("#stage .slot").forEach(slot => {
        const v = slot.querySelector("video"); if(!v) return;
        const r = slot.getBoundingClientRect(), W = r.width, H = r.height;
        const ratio = {"16:9": 16 / 9, "4:3": 4 / 3, "21:9": 21 / 9}[mode];
        if(ratio && W > 0 && H > 0){
          let w = W, h = W / ratio; if(h > H){ h = H; w = H * ratio; }
          Object.assign(v.style, {position: "absolute", width: w + "px", height: h + "px", left: ((W - w) / 2) + "px", top: ((H - h) / 2) + "px"}); v.style.setProperty("object-fit", "fill", "important");
        } else {
          ["position", "width", "height", "left", "top"].forEach(k => { v.style[k] = ""; });
          v.style.setProperty("object-fit", mode === "zoom" ? "cover" : mode === "stretch" ? "fill" : "contain", "important");
        }
      });
    };
    const apply = (say) => {
      const mode = getA();
      try{ if(typeof Android.naspect === "function") Android.naspect(mode, labelOf(mode)); }catch(e){}
      applyWeb();
      const b = $("chAspect"); if(b) b.textContent = "▭ Formato: " + labelOf(mode);
      if(say){ try{ toast("Formato da imagem: " + labelOf(mode)); }catch(e){}
        try{ Android.nhud && Android.nhud("Formato: " + labelOf(mode)); setTimeout(() => { try{ Android.nhud(""); }catch(e){} }, 1500); }catch(e){} }
    };
    const cycle = () => { window.__aspSay = Date.now(); const i = ASP.findIndex(a => a[0] === getA()); LS.set("tvAspect_" + kindNow(), ASP[(i + 1) % ASP.length][0]); apply(true); };
    window.__aspect = {cycle, apply, get: getA};
    /* ecrã total (também no telemóvel, por toque) */
    const isFull = () => document.body.classList.contains("vfull");
    let wasCinema = false;
    const setFull = on => {
      const app = document.querySelector(".app");
      if(on){ wasCinema = app.classList.contains("cinema"); if(!wasCinema) setCinema(true); document.body.classList.add("vfull"); }
      else { document.body.classList.remove("vfull"); if(!wasCinema && app.classList.contains("cinema")) setCinema(false); }
      try{ Android.nfull && Android.nfull(isFull()); }catch(e){}
      setTimeout(() => { try{ NAT.sync(true); }catch(e){} applyWeb(); }, 80);
      const fb = $("chFull"); if(fb) fb.textContent = isFull() ? "✕ Sair do ecrã total" : "⛶ Ecrã total";
    };
    window.__setFull = setFull;
    const bar = $("chTracks") ? $("chTracks").parentNode : document.querySelector(".cinebar");
    if(bar){
      const mk = (id, t, fn) => { if($(id)) return; const b = document.createElement("button"); b.className = "btn"; b.id = id; b.textContent = t; b.onclick = fn; bar.appendChild(b); return b; };
      mk("chAspect", "▭ Formato: " + labelOf(getA()), cycle);
      mk("chFull", "⛶ Ecrã total", () => setFull(!isFull()));
    }
    new MutationObserver(() => { try{ Android.nfull && Android.nfull(isFull()); }catch(e){} const fb = $("chFull"); if(fb) fb.textContent = isFull() ? "✕ Sair do ecrã total" : "⛶ Ecrã total"; }).observe(document.body, {attributes:true, attributeFilter:["class"]});
    /* botões nativos sobre o vídeo */
    window.__aspSay = 0;
    const _n = window.__nev;
    window.__nev = (k, m) => { if(k === "aspect:info") return; if(k === "hdr:dv5"){ try{ toast("Dolby Vision perfil 5: este aparelho não consegue mostrar as cores corretamente. Escolhe outra versão do filme (HDR10 ou normal).", true); }catch(e){} return; }
      if(k === "ui" && false) return; if(k === "ui"){ if(m === "aspect") cycle(); else if(m === "full") setFull(!isFull()); return; } return _n && _n(k, m); };
    /* tecla vermelha do comando = mudar formato */
    document.addEventListener("keydown", e => { if(currentView === "tv" && (e.keyCode === 183 || e.key === "ColorF0Red")){ e.preventDefault(); cycle(); } }, true);
    /* botões flutuantes (leitor da página); o leitor nativo tem os seus próprios */
    document.head.insertAdjacentHTML("beforeend", "<style>#vfCtl{position:fixed;top:10px;right:10px;z-index:75;display:none;gap:8px}body.vfull #vfCtl.on{display:flex}#vfCtl button{background:#000c;color:#fff;border:0;border-radius:10px;padding:12px 16px;font:600 15px system-ui}body.vfull #bStamp{display:none}</style>");
    const fc = document.createElement("div"); fc.id = "vfCtl"; fc.innerHTML = '<button id="vfA">▭ Formato</button><button id="vfX">✕ Sair do ecrã total</button>'; document.body.appendChild(fc);
    let fcT = 0; const showFc = () => { fc.classList.add("on"); clearTimeout(fcT); fcT = setTimeout(() => fc.classList.remove("on"), 3500); };
    $("vfA").onclick = e => { e.stopPropagation(); cycle(); showFc(); }; $("vfX").onclick = e => { e.stopPropagation(); fc.classList.remove("on"); setFull(false); };
    document.addEventListener("click", e => { if(isFull() && e.target.closest && e.target.closest("#stage")) showFc(); }, true);
    new MutationObserver(() => { if(isFull()) showFc(); else fc.classList.remove("on"); }).observe(document.body, {attributes:true, attributeFilter:["class"]});
    /* duplo toque no vídeo (leitor da página) = ecrã total / sair */
    (function(){ let lt = 0; document.addEventListener("touchend", e => { const st = e.target.closest && e.target.closest("#stage"); if(!st || currentView !== "tv") return; const n = Date.now(); if(n - lt < 320){ lt = 0; e.preventDefault(); setFull(!isFull()); } else lt = n; }, {capture:true, passive:false}); })();
    window.addEventListener("resize", applyWeb); setInterval(applyWeb, 1500);
    /* cada vez que um canal/filme começa, aplica o formato guardado */
    const _pc = window.playChannel;
    if(typeof _pc === "function") window.playChannel = function(){ const r = _pc.apply(this, arguments); setTimeout(() => apply(false), 150); setTimeout(() => apply(false), 1200); return r; };
    applyWeb();
  })();

  /* ===== Guia no telemóvel (vertical): primeiro a lista de canais, depois a programação ===== */
  (function(){
    const dlg = $("gdDlg"), list = $("gdList"); if(!dlg || !list) return;
    document.head.insertAdjacentHTML("beforeend", "<style>" +
      "body.phone #gdDlg .gdbox{width:100vw!important;max-width:100vw!important;height:100%!important;max-height:100%!important;border-radius:0!important;padding:12px!important;box-sizing:border-box;gap:8px}" +
      "body.phone #gdDlg .gdgrid{display:flex!important;flex-direction:column;min-height:0;flex:1}" +
      "body.phone #gdDlg .gdside,body.phone #gdDlg .gdmain{flex:1;min-width:0;min-height:0;width:100%}" +
      "body.phone #gdDlg:not(.showd) .gdmain{display:none}body.phone #gdDlg.showd .gdside{display:none}" +
      "body.phone #gdDlg .gch{min-height:52px;font-size:15px}body.phone #gdDlg .gdbox h2{font-size:18px}" +
      "body.phone #gdDlg .gdhead{gap:6px}body.phone #gdDlg .gdhead .btn{padding:8px 12px;min-height:44px}" +
      "body.phone #gdDlg .gdbox input,body.phone #gdDlg .gdbox select{min-width:0;max-width:100%;box-sizing:border-box}" +
      "body.phone #gdDlg .gdbox{background:#0f1726!important}body.phone #gdDlg .gdbox>.row{flex-wrap:nowrap}body.phone #gdDlg .gdbox>.row .btn{min-height:44px}" +
      "body.phone #gdDlg .gdhead{flex-wrap:wrap!important}body.phone #gdDlg .gdname{flex:1 1 100%;order:-1;white-space:normal;font-size:17px}" +
      "body:has(.epgdlg:not([hidden])) #bStamp,body:has(.trkdlg:not([hidden])) #bStamp{display:none}body.phone #bStamp{font-size:10px;top:2px}" +
      "#gdBack{display:none}body.phone #gdBack{display:inline-flex}" +
      "</style>");
    const head = dlg.querySelector(".gdhead");
    if(head && !$("gdBack")){ const b = document.createElement("button"); b.className = "btn"; b.id = "gdBack"; b.textContent = "☰ Canais"; b.onclick = () => dlg.classList.remove("showd"); head.insertBefore(b, head.firstChild); }
    list.addEventListener("click", e => { if(e.target.closest && e.target.closest(".gch")) setTimeout(() => dlg.classList.add("showd"), 0); }, true);
    const _og = window.openGuide; if(typeof _og === "function") window.openGuide = function(){ dlg.classList.remove("showd"); return _og.apply(this, arguments); };
    const gb = $("btnGuide"), cg = $("chGuide"); if(gb) gb.onclick = window.openGuide; if(cg) cg.onclick = window.openGuide;
  })();

  syncNav();
  if(currentView === "tvhome") window.show("tvhome");
})();
</script>
'''

i = h.rfind("</body>")
h = h[:i] + JS + JS2 + h[i:]
os.makedirs(os.path.dirname(out), exist_ok=True)
import time
h = h.replace("__BUILD__", time.strftime("%d/%m %H:%M"))
open(out, "w", encoding="utf-8").write(h)
print("OK ->", os.path.normpath(out), len(h)//1024, "KB")
