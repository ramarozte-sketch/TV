package pt.rui.cockpittv;

import android.app.Activity;
import android.content.ContentValues;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.JavascriptInterface;
import android.webkit.RenderProcessGoneDetail;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.Toast;

import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Cockpit TV: WebView que carrega a parte IPTV do Cockpit (assets/index.html).
 * Faz de "proxy" local: pedidos http(s) GET passam por aqui com o User-Agent do VLC
 * (e o Referer da estação nos canais abertos), por isso não é preciso Cloudflare Worker.
 */
public class MainActivity extends Activity {
    private static final String UA = "VLC/3.0.20 LibVLC/3.0.20";
    private static final String UA_BROWSER = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";
    private static final int REQ_FILE = 11;
    private static final int REQ_SAVE = 12;
    private String pendingName = "";
    private String pendingText = "";

    private NativePlayer np;
    private CastHelper cast;
    private FrameLayout root;
    private WebView web;
    private View customView;
    private WebChromeClient.CustomViewCallback customCb;
    private ValueCallback<Uri[]> fileCb;
    private volatile String ctxRef = "";

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        root = new FrameLayout(this);
        root.setBackgroundColor(0xFF000000);
        setContentView(root);
        buildWeb();
        if (b != null) web.restoreState(b); else web.loadUrl("file:///android_asset/index.html");
    }

    private void buildWeb() {
        web = new WebView(this);
        web.setBackgroundColor(0xFF000000);
        web.setFocusable(true);
        web.setFocusableInTouchMode(true);
        web.requestFocus();
        root.addView(web, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setAllowFileAccess(true);
        s.setAllowFileAccessFromFileURLs(true);
        s.setAllowUniversalAccessFromFileURLs(true);
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
        s.setLoadWithOverviewMode(false);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        web.addJavascriptInterface(new Bridge(), "Android");
        web.setWebViewClient(new Client());
        web.setWebChromeClient(new Chrome());
        web.setDownloadListener((url, ua, cd, mime, len) ->
                Toast.makeText(this, "Descarregamentos diretos não são suportados.", Toast.LENGTH_SHORT).show());
    }

    /* ---------------- ponte JS <-> Android ---------------- */
    private class Bridge {
        @JavascriptInterface
        public void ctx(String ref) {
            ctxRef = ref == null ? "" : ref.trim();
        }

        /** Abre o seletor do Android para o utilizador escolher a pasta e o nome do ficheiro. */
        @JavascriptInterface
        public boolean saveText(String name, String text) {
            pendingName = (name == null || name.isEmpty()) ? "cockpit-iptv-definicoes.json" : name;
            pendingText = text == null ? "" : text;
            runOnUiThread(() -> {
                try {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("application/json");
                    i.putExtra(Intent.EXTRA_TITLE, pendingName);
                    startActivityForResult(i, REQ_SAVE);
                } catch (Exception e) {
                    // Sem seletor de ficheiros (comum em Android TV): guarda em Transferências
                    String where = saveFallback(pendingName, pendingText);
                    jsSaved(where != null, where == null ? "" : where);
                }
            });
            return true;
        }

        @JavascriptInterface
        public void showKeyboard() {
            runOnUiThread(() -> {
                web.requestFocus();
                android.view.inputmethod.InputMethodManager m = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (m != null) { m.restartInput(web); m.showSoftInput(web, android.view.inputmethod.InputMethodManager.SHOW_FORCED); }
            });
        }

        @JavascriptInterface
        public void hideKeyboard() {
            runOnUiThread(() -> {
                android.view.inputmethod.InputMethodManager m = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
                if (m != null) m.hideSoftInputFromWindow(web.getWindowToken(), 0);
            });
        }

        /* ---- leitor nativo (Media3) ---- */
        @JavascriptInterface
        public void nplay(final String url, final String ref, final String hint, final String title, final long startMs) {
            runOnUiThread(() -> {
                try {
                    if (np == null) np = new NativePlayer(MainActivity.this, root, (k, m) -> jsEvent(k, m));
                    np.play(url, ref, hint, title, startMs);
                } catch (Throwable e) {
                    jsEvent("error", "init " + e);
                }
            });
        }

        @JavascriptInterface
        public void nrect(final int x, final int y, final int w, final int h, final boolean vis) {
            runOnUiThread(() -> { if (np != null) np.rect(x, y, w, h, vis); });
        }

        @JavascriptInterface
        public void nstop() {
            runOnUiThread(() -> { if (np != null) np.stop(); });
        }

        @JavascriptInterface
        public void nsub(final String text, final String label, final String lang) {
            runOnUiThread(() -> { if (np != null) np.subtitle(text, label, lang); });
        }

        @JavascriptInterface
        public void ntoggle() {
            runOnUiThread(() -> { if (np != null) np.toggle(); });
        }

        @JavascriptInterface
        public void nseek(final long ms) {
            runOnUiThread(() -> { if (np != null) np.seek(ms); });
        }

        @JavascriptInterface
        public void ntrack(final String type, final int idx) {
            runOnUiThread(() -> { if (np != null) np.pick(type, idx); });
        }

        @JavascriptInterface
        public String npos() {
            NativePlayer n = np;
            return n == null ? "0|0|1" : n.pos();
        }

        @JavascriptInterface
        public String ntracks() {
            NativePlayer n = np;
            return n == null ? "{\"audio\":[],\"text\":[]}" : n.tracks();
        }

        /** Telemóvel: abre o seletor de transmissão do Android (Miracast / Wi-Fi Direct, Google Cast) para espelhar o ecrã numa TV. */
        /* ---- Google Cast (envia o endereço do vídeo para a Google TV) ---- */
        /** Abre um endereço fora da app (ex.: trailer no YouTube). */
        @JavascriptInterface
        public void openUrl(final String url) {
            runOnUiThread(() -> {
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                } catch (Exception e) {
                    Toast.makeText(MainActivity.this, "Não há nenhuma app para abrir o trailer (instala o YouTube).", Toast.LENGTH_LONG).show();
                }
            });
        }

        @JavascriptInterface
        public void cpick() {
            runOnUiThread(() -> {
                try {
                    if (cast == null) cast = new CastHelper(MainActivity.this, (k, m) -> jsEvent("cast:" + k, m));
                    cast.pick();
                } catch (Throwable e) {
                    jsEvent("cast:unavailable", String.valueOf(e));
                }
            });
        }

        @JavascriptInterface
        public void cload(final String url, final String title, final String mime, final boolean live, final long startMs) {
            runOnUiThread(() -> { if (cast != null) cast.load(url, title, mime, live, startMs); });
        }

        @JavascriptInterface
        public void ctoggle() {
            runOnUiThread(() -> { if (cast != null) cast.toggle(); });
        }

        @JavascriptInterface
        public void cmstop() {
            runOnUiThread(() -> { if (cast != null) cast.stopMedia(); });
        }

        @JavascriptInterface
        public void cstop() {
            runOnUiThread(() -> { if (cast != null) cast.stop(); });
        }

        @JavascriptInterface
        public boolean castScreen() {
            final boolean[] ok = {false};
            runOnUiThread(() -> {
                String[] acts = {"android.settings.CAST_SETTINGS", "com.samsung.android.smartmirroring.SETTINGS", android.provider.Settings.ACTION_WIFI_SETTINGS};
                for (String a : acts) {
                    try {
                        startActivity(new Intent(a).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK));
                        ok[0] = true;
                        return;
                    } catch (Exception ignored) { }
                }
                Toast.makeText(MainActivity.this, "Abre o painel rápido do Android e toca em Transmitir / Smart View / Espelhar ecrã.", Toast.LENGTH_LONG).show();
            });
            return true;
        }

        @JavascriptInterface
        public void exitApp() {
            runOnUiThread(() -> finish());
        }

        @JavascriptInterface
        public boolean isTv() {
            android.app.UiModeManager um = (android.app.UiModeManager) getSystemService(UI_MODE_SERVICE);
            return um != null && um.getCurrentModeType() == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION;
        }

        @JavascriptInterface
        public void toast(String msg) {
            runOnUiThread(() -> Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show());
        }
    }

    private void jsEvent(String kind, String msg) {
        final String js = "window.__nev&&window.__nev(" + org.json.JSONObject.quote(kind) + "," + org.json.JSONObject.quote(msg == null ? "" : msg) + ")";
        runOnUiThread(() -> { if (web != null) web.evaluateJavascript(js, null); });
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (np != null) np.pause();
    }

    /* ---------------- "proxy" local ---------------- */
    private class Client extends WebViewClient {
        @Override
        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest req) {
            try {
                Uri u = req.getUrl();
                String scheme = u.getScheme();
                if (scheme == null || !(scheme.equals("http") || scheme.equals("https"))) return null;
                String host = u.getHost() == null ? "" : u.getHost();
                if (host.endsWith("cdnjs.cloudflare.com") || host.endsWith("opensubtitles.com")
                        || host.endsWith("googleapis.com") || host.endsWith("gstatic.com")) return null;
                String method = req.getMethod();
                Map<String, String> rh = req.getRequestHeaders();
                if ("OPTIONS".equalsIgnoreCase(method)) {
                    Map<String, String> h = new HashMap<>();
                    h.put("Access-Control-Allow-Origin", "*");
                    h.put("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
                    String ah = rh == null ? null : rh.get("Access-Control-Request-Headers");
                    h.put("Access-Control-Allow-Headers", ah == null ? "*" : ah);
                    h.put("Access-Control-Max-Age", "86400");
                    return new WebResourceResponse("text/plain", "utf-8", 200, "OK", h, new ByteArrayInputStream(new byte[0]));
                }
                if (!"GET".equalsIgnoreCase(method)) return null;
                String full = u.toString();
                // Vídeo (segmentos .ts/.m3u8/mp4) passa direto pelo WebView; só interceptamos
                // listas/APIs/EPG (para usar o User-Agent do VLC) e os canais que precisam de Referer.
                boolean api = full.matches("(?i).*(player_api\\.php|/get\\.php|panel_api|xmltv|\\.xml(\\.gz)?|\\.m3u(\\?.*)?$|\\.json).*");
                if (!api && ctxRef.isEmpty()) return null;
                return fetch(full, rh);
            } catch (Exception e) {
                return null; // deixa o WebView tentar normalmente
            }
        }

        @Override
        public boolean onRenderProcessGone(WebView view, RenderProcessGoneDetail detail) {
            runOnUiThread(() -> {
                try { root.removeView(web); web.destroy(); } catch (Exception ignored) { }
                buildWeb();
                web.loadUrl("file:///android_asset/index.html");
            });
            return true;
        }

        @Override
        public void onPageStarted(WebView view, String url, Bitmap favicon) {
            ctxRef = "";
        }
    }

    private WebResourceResponse fetch(String url, Map<String, String> rh) {
        try {
            String cur = url;
            HttpURLConnection c = null;
            for (int i = 0; i < 8; i++) {
                c = (HttpURLConnection) new URL(cur).openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(15000);
                c.setReadTimeout(30000);
                c.setRequestMethod("GET");
                // canais abertos (com Referer) devolvem 204 vazio ao VLC: precisam de um User-Agent de browser
                c.setRequestProperty("User-Agent", ctxRef.isEmpty() ? UA : UA_BROWSER);
                c.setRequestProperty("Accept", "*/*");
                if (rh != null) {
                    String range = rh.get("Range");
                    if (range != null) c.setRequestProperty("Range", range);
                    String auth = rh.get("Authorization");
                    if (auth != null) c.setRequestProperty("Authorization", auth);
                }
                String ref = ctxRef;
                if (!ref.isEmpty()) {
                    c.setRequestProperty("Referer", ref);
                    c.setRequestProperty("Origin", ref.replaceAll("^(https?://[^/]+).*$", "$1"));
                }
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) {
                    String loc = c.getHeaderField("Location");
                    c.disconnect();
                    if (loc == null) return null;
                    cur = new URL(new URL(cur), loc).toString();
                    continue;
                }
                break;
            }
            if (c == null) return null;
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) return null;
            String ct = c.getContentType();
            String mime = "application/octet-stream";
            String enc = null;
            if (ct != null) {
                String[] parts = ct.split(";");
                mime = parts[0].trim();
                for (String p : parts) {
                    p = p.trim();
                    if (p.toLowerCase().startsWith("charset=")) enc = p.substring(8).trim();
                }
            }
            Map<String, String> h = new HashMap<>();
            for (Map.Entry<String, List<String>> e : c.getHeaderFields().entrySet()) {
                String k = e.getKey();
                if (k == null || e.getValue() == null || e.getValue().isEmpty()) continue;
                String kl = k.toLowerCase();
                if (kl.equals("content-encoding") || kl.equals("content-length") || kl.equals("transfer-encoding")
                        || kl.equals("connection") || kl.startsWith("access-control-")) continue;
                h.put(k, e.getValue().get(0));
            }
            h.put("Access-Control-Allow-Origin", "*");
            h.put("Access-Control-Expose-Headers", "*");
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            if (in == null) in = new ByteArrayInputStream(new byte[0]);
            String reason = c.getResponseMessage();
            if (reason == null || reason.isEmpty()) reason = code == 206 ? "Partial Content" : (code >= 400 ? "Error" : "OK");
            return new WebResourceResponse(mime, enc, code, reason, h, in);
        } catch (Exception e) {
            return null;
        }
    }

    /* ---------------- janela do WebView (ficheiros, ecrã inteiro) ---------------- */
    private class Chrome extends WebChromeClient {
        @Override
        public boolean onShowFileChooser(WebView w, ValueCallback<Uri[]> cb, FileChooserParams params) {
            if (fileCb != null) fileCb.onReceiveValue(null);
            fileCb = cb;
            try {
                startActivityForResult(params.createIntent(), REQ_FILE);
            } catch (Exception e) {
                fileCb = null;
                return false;
            }
            return true;
        }

        @Override
        public void onShowCustomView(View view, CustomViewCallback cb) {
            if (customView != null) { cb.onCustomViewHidden(); return; }
            customView = view;
            customCb = cb;
            web.setVisibility(View.GONE);
            root.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            immersive();
        }

        @Override
        public void onHideCustomView() {
            hideCustom();
        }
    }

    private void hideCustom() {
        if (customView == null) return;
        root.removeView(customView);
        customView = null;
        web.setVisibility(View.VISIBLE);
        if (customCb != null) { customCb.onCustomViewHidden(); customCb = null; }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE && fileCb != null) {
            fileCb.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(res, data));
            fileCb = null;
            return;
        }
        if (req == REQ_SAVE) {
            if (res != RESULT_OK || data == null || data.getData() == null) { jsSaved(false, ""); return; }
            try (OutputStream os = getContentResolver().openOutputStream(data.getData(), "wt")) {
                if (os == null) throw new IOException("sem saída");
                os.write(pendingText.getBytes(StandardCharsets.UTF_8));
                jsSaved(true, data.getData().getLastPathSegment() == null ? pendingName : data.getData().getLastPathSegment());
            } catch (Exception e) {
                jsSaved(false, "");
            }
            return;
        }
        super.onActivityResult(req, res, data);
    }

    private void jsSaved(boolean ok, String where) {
        String w = where.replace("\\", "\\\\").replace("'", "\\'");
        web.evaluateJavascript("window.androidSaved&&androidSaved(" + ok + ",'" + w + "')", null);
    }

    private String saveFallback(String name, String text) {
        try {
            byte[] data = text.getBytes(StandardCharsets.UTF_8);
            if (Build.VERSION.SDK_INT >= 29) {
                ContentValues cv = new ContentValues();
                cv.put(MediaStore.MediaColumns.DISPLAY_NAME, name);
                cv.put(MediaStore.MediaColumns.MIME_TYPE, "application/json");
                cv.put(MediaStore.MediaColumns.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS);
                Uri u = getContentResolver().insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv);
                if (u == null) return null;
                try (OutputStream os = getContentResolver().openOutputStream(u)) {
                    if (os == null) return null;
                    os.write(data);
                }
                return "Transferências/" + name;
            }
            File dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS);
            if (dir == null || (!dir.exists() && !dir.mkdirs())) dir = getExternalFilesDir(null);
            if (dir == null) return null;
            File f = new File(dir, name);
            try (FileOutputStream os = new FileOutputStream(f)) {
                os.write(data);
            }
            return f.getAbsolutePath();
        } catch (Exception e) {
            return null;
        }
    }

    /* ---------------- botão Voltar e ecrã inteiro ---------------- */
    @Override
    public void onBackPressed() {
        if (customView != null) { hideCustom(); return; }
        web.evaluateJavascript("(function(){try{return window.androidBack()?1:0}catch(e){return 0}})()", v -> {
            if (!"1".equals(v)) finish();
        });
    }

    @Override
    public boolean onKeyDown(int code, KeyEvent ev) {
        if (code == KeyEvent.KEYCODE_ESCAPE) { onBackPressed(); return true; }
        return super.onKeyDown(code, ev);
    }

    private void immersive() {
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                        | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
    }

    @Override
    public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) immersive();
    }

    @Override
    protected void onSaveInstanceState(Bundle out) {
        super.onSaveInstanceState(out);
        if (web != null) web.saveState(out);
    }

    @Override
    protected void onDestroy() {
        if (np != null) { np.release(); np = null; }
        if (cast != null) { cast.release(); cast = null; }
        if (web != null) { root.removeAllViews(); web.destroy(); }
        super.onDestroy();
    }
}
