package pt.rui.cockpittv;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/** v320: «TV Direto» — canais do sintonizador da própria TV (TV Input Framework) e da lista Sony Bravia (IP Control). */
final class TvLive {
    private TvLive() { }

    /** {num, name, id} do sintonizador; lança exceção com o motivo se o sistema não deixar ler. */
    static List<String[]> tunerChannels(Context c) throws Exception {
        List<String[]> out = new ArrayList<>();
        android.database.Cursor cur = null;
        try {
            cur = c.getContentResolver().query(android.media.tv.TvContract.Channels.CONTENT_URI,
                    new String[]{android.media.tv.TvContract.Channels._ID, android.media.tv.TvContract.Channels.COLUMN_DISPLAY_NUMBER, android.media.tv.TvContract.Channels.COLUMN_DISPLAY_NAME}, null, null, null);
            if (cur != null) while (cur.moveToNext() && out.size() < 2000) out.add(new String[]{cur.getString(1) == null ? "" : cur.getString(1), cur.getString(2) == null ? "" : cur.getString(2), String.valueOf(cur.getLong(0))});
        } finally { if (cur != null) try { cur.close(); } catch (Throwable ignored) { } }
        java.util.Collections.sort(out, (a, b) -> { double x = num(a[0]), y = num(b[0]); return x != y ? Double.compare(x, y) : a[1].compareToIgnoreCase(b[1]); });
        return out;
    }
    private static double num(String s) { try { return Double.parseDouble(s); } catch (Throwable e) { return 1e9; } }

    /** Sintoniza um canal do sintonizador (app de TV que sabe abrir canais, sistema, app do fabricante). */
    static String tune(Activity a, long id) {
        final Uri cu = android.media.tv.TvContract.buildChannelUri(id);
        List<Intent> tries = new ArrayList<>();
        try { for (android.content.pm.ResolveInfo r : a.getPackageManager().queryIntentActivities(new Intent(Intent.ACTION_VIEW, cu), 0)) tries.add(new Intent(Intent.ACTION_VIEW, cu).setClassName(r.activityInfo.packageName, r.activityInfo.name)); } catch (Throwable ignored) { }
        tries.add(new Intent(Intent.ACTION_VIEW, cu));
        tries.add(new Intent("com.sony.dtv.tvx.action.VIEW", cu).setPackage("com.sony.dtv.tvx"));
        for (Intent i : tries) { try { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); a.startActivity(i); return "ok"; } catch (Throwable ignored) { } }
        return openLive(a) ? "app" : "falhou";
    }
    static boolean openLive(Activity a) {
        String[] pk = {"com.sony.dtv.tvx", "com.google.android.tv", "com.android.tv", "org.droidtv.playtv", "com.tcl.tv", "com.mediatek.wwtv.tvcenter"};
        for (String p : pk) { try { Intent i = a.getPackageManager().getLaunchIntentForPackage(p); if (i != null) { i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); a.startActivity(i); return true; } } catch (Throwable ignored) { } }
        try { a.startActivity(new Intent(Intent.ACTION_VIEW, android.media.tv.TvContract.Channels.CONTENT_URI).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); return true; } catch (Throwable ignored) { }
        return false;
    }

    /** JSON-RPC à API Bravia. Devolve o objeto (com "httpError" em caso de falha). */
    static JSONObject bravia(String ip, String psk, String service, String method, JSONArray params, String ver) {
        java.net.HttpURLConnection c = null;
        try {
            c = (java.net.HttpURLConnection) new java.net.URL("http://" + ip + "/sony/" + service).openConnection();
            c.setConnectTimeout(4000); c.setReadTimeout(8000); c.setRequestMethod("POST"); c.setDoOutput(true);
            c.setRequestProperty("Content-Type", "application/json");
            if (psk != null && psk.length() > 0) c.setRequestProperty("X-Auth-PSK", psk);
            JSONObject body = new JSONObject().put("method", method).put("id", 1).put("params", params).put("version", ver);
            c.getOutputStream().write(body.toString().getBytes("UTF-8"));
            int code = c.getResponseCode();
            java.io.InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream();
            if (in != null) { byte[] b = new byte[8192]; int n; while ((n = in.read(b)) > 0) o.write(b, 0, n); }
            String r = o.toString("UTF-8");
            if (code >= 400) return new JSONObject().put("httpError", code).put("body", r);
            return new JSONObject(r);
        } catch (Throwable t) {
            try { return new JSONObject().put("httpError", 0).put("body", String.valueOf(t)); } catch (Throwable x) { return new JSONObject(); }
        } finally { if (c != null) c.disconnect(); }
    }
    static String braviaErr(JSONObject r, String ip) {
        if (r.has("httpError")) { int h = r.optInt("httpError"); return h == 403 ? "403: a Pre-Shared Key está errada ou a autenticação não está em «Pre-Shared Key»" : h == 0 ? "não consegui ligar à TV em " + ip + " (" + r.optString("body") + ")" : "HTTP " + h; }
        JSONArray e = r.optJSONArray("error"); if (e != null) return "erro " + e.optInt(0) + ": " + e.optString(1);
        return null;
    }
    /** Canais da lista da TV Sony + entradas externas: {num, nome, uri}. Em caso de erro devolve lista vazia e preenche err[0]. */
    static List<String[]> braviaItems(String ip, String psk, String[] err) {
        List<String[]> items = new ArrayList<>();
        try {
            JSONObject src = bravia(ip, psk, "avContent", "getSourceList", new JSONArray().put(new JSONObject().put("scheme", "tv")), "1.0");
            String e = braviaErr(src, ip); if (e != null) { err[0] = e; return items; }
            List<String> sources = new ArrayList<>();
            JSONArray sa = src.optJSONArray("result") == null ? null : src.optJSONArray("result").optJSONArray(0);
            if (sa != null) for (int i = 0; i < sa.length(); i++) { String s = sa.optJSONObject(i) == null ? "" : sa.optJSONObject(i).optString("source"); if (!s.isEmpty() && !sources.contains(s)) sources.add(s); }
            for (String s : new String[]{"tv:dvbt", "tv:dvbc", "tv:dvbs"}) if (!sources.contains(s)) sources.add(s);
            java.util.HashSet<String> seen = new java.util.HashSet<>();
            for (String sc : sources) {
                for (String ver : new String[]{"1.5", "1.2", "1.0"}) {
                    int got = 0; boolean fail = false;
                    for (int st = 0; st < 2000; st += 50) {
                        JSONObject p = new JSONObject().put("source", sc).put("stIdx", st); if (!"1.0".equals(ver)) p.put("cnt", 50);
                        JSONObject r = bravia(ip, psk, "avContent", "getContentList", new JSONArray().put(p), ver);
                        if (braviaErr(r, ip) != null) { fail = true; break; }
                        JSONArray a = r.optJSONArray("result") == null ? null : r.optJSONArray("result").optJSONArray(0);
                        if (a == null || a.length() == 0) break;
                        for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o == null) continue; String u = o.optString("uri"); if (u.isEmpty() || !seen.add(u)) continue; items.add(new String[]{o.optString("dispNum"), o.optString("title"), u}); got++; }
                        if (a.length() < 50 && !"1.0".equals(ver)) break;
                    }
                    if (got > 0 || !fail) break;
                }
            }
            java.util.Collections.sort(items, (a, b) -> Double.compare(num(a[0]), num(b[0])));
            JSONObject ext = bravia(ip, psk, "avContent", "getCurrentExternalInputsStatus", new JSONArray(), "1.1");
            JSONArray ea = ext.optJSONArray("result") == null ? null : ext.optJSONArray("result").optJSONArray(0);
            if (ea != null) for (int i = 0; i < ea.length(); i++) { JSONObject o = ea.optJSONObject(i); if (o != null && o.optString("uri").matches("(?i).*(hdmi|component|composite|scart).*")) items.add(new String[]{"↪", o.optString("title", o.optString("label", o.optString("uri"))), o.optString("uri")}); }
        } catch (Throwable t) { err[0] = String.valueOf(t); }
        return items;
    }
    static String braviaPlay(String ip, String psk, String uri) {
        try {
            JSONObject r = bravia(ip, psk, "avContent", "setPlayContent", new JSONArray().put(new JSONObject().put("uri", uri)), "1.0");
            String e = braviaErr(r, ip); return e == null ? "ok" : e;
        } catch (Throwable t) { return String.valueOf(t); }
    }
}
