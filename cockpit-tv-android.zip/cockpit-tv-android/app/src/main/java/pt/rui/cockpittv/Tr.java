package pt.rui.cockpittv;

import android.content.Context;

import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * Traduções da interface. A chave é o texto português original; a língua
 * escolhida fica em SharedPreferences "nativeapp" / "ui_lang".
 * Se faltar uma tradução, mostra-se o texto português.
 */
final class Tr {
    static final String[] LANGS = {"pt", "en", "fr", "es", "de"};
    static final String[] LANG_NAMES = {"Português", "English", "Français", "Español", "Deutsch"};
    static String lang = "pt";

    private static final Map<String, String[]> T = new HashMap<>();

    private static void put(String pt, String en, String fr, String es, String de) {
        T.put(pt, new String[]{en, fr, es, de});
    }

    static {
        put("Definições", "Settings", "Paramètres", "Ajustes", "Einstellungen");
        put("Início", "Home", "Accueil", "Inicio", "Start");
        put("Explorar", "Explore", "Explorer", "Explorar", "Entdecken");
        put("Guia", "Guide", "Guide", "Guía", "Programm");
        put("Cinema", "Cinema", "Cinéma", "Cine", "Kino");
        put("Canais", "Channels", "Chaînes", "Canales", "Kanäle");
        put("Filmes", "Movies", "Films", "Películas", "Filme");
        put("Séries", "Series", "Séries", "Series", "Serien");
        put("★ Favoritos", "★ Favourites", "★ Favoris", "★ Favoritos", "★ Favoriten");
        put("🕘 Vistos", "🕘 Watched", "🕘 Vus", "🕘 Vistos", "🕘 Gesehen");
        put("Pesquisar", "Search", "Rechercher", "Buscar", "Suchen");
        put("Cancelar", "Cancel", "Annuler", "Cancelar", "Abbrechen");
        put("Guardar", "Save", "Enregistrer", "Guardar", "Speichern");
        put("Atualizar", "Update", "Actualiser", "Actualizar", "Aktualisieren");
        put("Apagar", "Delete", "Supprimer", "Borrar", "Löschen");
        put("Criar", "Create", "Créer", "Crear", "Erstellen");
        put("Copiar", "Copy", "Copier", "Copiar", "Kopieren");
        put("Copiado.", "Copied.", "Copié.", "Copiado.", "Kopiert.");
        put("Abrir", "Open", "Ouvrir", "Abrir", "Öffnen");
        put("Ajustar", "Adjust", "Ajuster", "Ajustar", "Anpassen");
        put("Automático", "Automatic", "Automatique", "Automático", "Automatisch");
        put("Desligado", "Off", "Désactivé", "Desactivado", "Aus");
        put("Ligado", "On", "Activé", "Activado", "Ein");
        put("Áudio", "Audio", "Audio", "Audio", "Audio");
        put("Legendas", "Subtitles", "Sous-titres", "Subtítulos", "Untertitel");
        put("Som", "Sound", "Son", "Sonido", "Ton");
        put("Aspeto", "Appearance", "Apparence", "Aspecto", "Aussehen");
        put("Cor", "Colour", "Couleur", "Color", "Farbe");
        put("Idioma predefinido", "Default language", "Langue par défaut", "Idioma predeterminado", "Standardsprache");
        put("Idioma da interface", "Interface language", "Langue de l'interface", "Idioma de la interfaz", "Oberflächensprache");
        put("Reinicia a app para aplicar.", "Restart the app to apply.", "Redémarrez l'application pour appliquer.", "Reinicia la aplicación para aplicar.", "Starte die App neu, um die Änderung zu übernehmen.");
        put("Cópia de segurança", "Backup", "Sauvegarde", "Copia de seguridad", "Sicherung");
        put("Controlo parental", "Parental control", "Contrôle parental", "Control parental", "Kindersicherung");
        put("Gravações", "Recordings", "Enregistrements", "Grabaciones", "Aufnahmen");
        put("Filmes e séries", "Movies and series", "Films et séries", "Películas y series", "Filme und Serien");
        put("Início e canais", "Home and channels", "Accueil et chaînes", "Inicio y canales", "Start und Kanäle");
        put("Vídeo e imagem", "Video and picture", "Vidéo et image", "Vídeo e imagen", "Video und Bild");
        put("Som e legendas", "Sound and subtitles", "Son et sous-titres", "Sonido y subtítulos", "Ton und Untertitel");
        put("Lista IPTV e ligação", "IPTV list and connection", "Liste IPTV et connexion", "Lista IPTV y conexión", "IPTV-Liste und Verbindung");
        put("Aspeto: cores e ícones", "Appearance: colours and icons", "Apparence : couleurs et icônes", "Aspecto: colores e iconos", "Aussehen: Farben und Symbole");
        put("Diagnóstico e ajuda", "Diagnostics and help", "Diagnostic et aide", "Diagnóstico y ayuda", "Diagnose und Hilfe");
        put("Continuar a ver", "Continue watching", "Reprendre", "Seguir viendo", "Weiterschauen");
        put("A minha lista", "My list", "Ma liste", "Mi lista", "Meine Liste");
        put("Bem-vindo", "Welcome", "Bienvenue", "Bienvenido", "Willkommen");
        put("Animação", "Animation", "Animation", "Animación", "Animation");
    }

    /** Lê a língua guardada. Chamar no arranque da app. */
    static void load(Context c) {
        String l = c.getSharedPreferences("nativeapp", 0).getString("ui_lang", "pt");
        lang = Arrays.asList(LANGS).contains(l) ? l : "pt";
    }

    static int index() {
        return Math.max(0, Arrays.asList(LANGS).indexOf(lang));
    }

    /** Devolve o texto na língua escolhida; se não houver tradução, o texto português. */
    static String t(String pt) {
        if (pt == null || "pt".equals(lang)) return pt;
        String[] v = T.get(pt);
        int i = index();
        if (v == null || i == 0) return pt;
        String s = v[i - 1];
        return s == null || s.isEmpty() ? pt : s;
    }
}
