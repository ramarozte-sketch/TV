package pt.rui.cockpittv;

import android.content.Context;
import android.opengl.GLES20;

import androidx.media3.common.VideoFrameProcessingException;
import androidx.media3.common.util.GlProgram;
import androidx.media3.common.util.GlUtil;
import androidx.media3.common.util.Size;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.effect.BaseGlShaderProgram;
import androidx.media3.effect.GlEffect;
import androidx.media3.effect.GlShaderProgram;

/**
 * Desentrelaçamento adaptativo (só espacial) feito na GPU.
 * Em cada pixel detecta o "efeito pente" (as duas linhas vizinhas diferem do pixel no mesmo sentido)
 * e só aí interpola a partir das linhas vizinhas, com direção do contorno (edge-directed).
 * Em vídeo progressivo quase não atua. Não é o yadif completo (não usa o campo anterior/seguinte).
 */
@UnstableApi
public final class DeinterlaceEffect implements GlEffect {
    /** v298: modos — 0 adaptativo (só onde há «pente»), 1 linhas (refaz as linhas de um dos campos: sem pente, menos detalhe),
     *  2 mistura (junta os dois campos: sem pente, imagem mais suave), 3 desligado (só nitidez). */
    public static final int ADAPT = 0, LINES = 1, BLEND = 2, NONE = 3;
    private final int mode; private final float sharp;
    public DeinterlaceEffect() { this(ADAPT, 0f); }
    /** @param sharp nitidez extra (0 = nenhuma; 0,3–0,6 ajuda canais SD 720x576 ampliados) */
    public DeinterlaceEffect(int mode, float sharp) { this.mode = mode; this.sharp = sharp; }
    @Override
    public GlShaderProgram toGlShaderProgram(Context context, boolean useHdr) throws VideoFrameProcessingException {
        return new Shader(mode, sharp);
    }

    private static final String VERT =
            "attribute vec4 aFramePosition;\n" +
            "varying vec2 vTex;\n" +
            "void main(){ gl_Position = aFramePosition; vTex = aFramePosition.xy * 0.5 + 0.5; }\n";

    private static final String FRAG =
            "#ifdef GL_FRAGMENT_PRECISION_HIGH\nprecision highp float;\n#else\nprecision mediump float;\n#endif\n" +
            "uniform sampler2D uTexSampler;\n" +
            "uniform vec2 uPx;\n" +
            "uniform float uMode;\n" +
            "uniform float uSharp;\n" +
            "varying vec2 vTex;\n" +
            "float Y(vec3 c){ return dot(c, vec3(0.299, 0.587, 0.114)); }\n" +
            "void main(){\n" +
            "  vec3 c = texture2D(uTexSampler, vTex).rgb;\n" +
            "  vec3 u = texture2D(uTexSampler, vTex + vec2(0.0, uPx.y)).rgb;\n" +
            "  vec3 l = texture2D(uTexSampler, vTex - vec2(0.0, uPx.y)).rgb;\n" +
            "  float yc = Y(c), yu = Y(u), yl = Y(l);\n" +
            "  float comb = (yu - yc) * (yl - yc);\n" +
            "  float agree = abs(yu - yl);\n" +
            "  float k = smoothstep(0.0015, 0.012, comb) * (1.0 - smoothstep(0.25, 0.6, agree));\n" +
            "  if(uMode > 2.5) k = 0.0;\n" +
            "  else if(uMode > 0.5 && uMode < 1.5) k = mod(floor(vTex.y / uPx.y), 2.0) > 0.5 ? 1.0 : 0.0;\n" +
            "  vec3 ul = texture2D(uTexSampler, vTex + vec2(-uPx.x, uPx.y)).rgb;\n" +
            "  vec3 ur = texture2D(uTexSampler, vTex + vec2( uPx.x, uPx.y)).rgb;\n" +
            "  vec3 ll = texture2D(uTexSampler, vTex + vec2(-uPx.x, -uPx.y)).rgb;\n" +
            "  vec3 lr = texture2D(uTexSampler, vTex + vec2( uPx.x, -uPx.y)).rgb;\n" +
            "  float d1 = abs(Y(ul) - Y(lr)), d2 = abs(Y(ur) - Y(ll)), d0 = abs(yu - yl);\n" +
            "  vec3 ip = (u + l) * 0.5;\n" +
            "  if(d1 < d0 && d1 < d2) ip = (ul + lr) * 0.5;\n" +
            "  else if(d2 < d0 && d2 < d1) ip = (ur + ll) * 0.5;\n" +
            "  vec3 o = mix(c, ip, k);\n" +
            "  if(uMode > 1.5 && uMode < 2.5) o = (u + 2.0 * c + l) * 0.25;\n" +
            "  if(uSharp > 0.0){\n" +
            "    vec3 r = texture2D(uTexSampler, vTex + vec2(uPx.x, 0.0)).rgb;\n" +
            "    vec3 g = texture2D(uTexSampler, vTex - vec2(uPx.x, 0.0)).rgb;\n" +
            "    vec3 blur = (u + l + r + g + 4.0 * o) * 0.125;\n" +
            "    o = clamp(o + (o - blur) * uSharp * 2.0, 0.0, 1.0);\n" +
            "  }\n" +
            "  gl_FragColor = vec4(o, 1.0);\n" +
            "}\n";

    private static final class Shader extends BaseGlShaderProgram {
        private final GlProgram program;
        private int w = 1, h = 1;

        private final float fMode, fSharp;
        Shader(int mode, float sharp) throws VideoFrameProcessingException {
            super(false, 1);
            fMode = mode; fSharp = sharp;
            try {
                program = new GlProgram(VERT, FRAG);
                program.setBufferAttribute("aFramePosition", GlUtil.getNormalizedCoordinateBounds(),
                        GlUtil.HOMOGENEOUS_COORDINATE_VECTOR_SIZE);
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e);
            }
        }

        @Override
        public Size configure(int inputWidth, int inputHeight) {
            w = inputWidth; h = inputHeight;
            return new Size(inputWidth, inputHeight);
        }

        @Override
        public void drawFrame(int inputTexId, long presentationTimeUs) throws VideoFrameProcessingException {
            try {
                program.use();
                program.setSamplerTexIdUniform("uTexSampler", inputTexId, 0);
                program.setFloatsUniform("uPx", new float[]{1f / Math.max(1, w), 1f / Math.max(1, h)});
                program.setFloatUniform("uMode", fMode);
                program.setFloatUniform("uSharp", fSharp);
                program.bindAttributesAndUniforms();
                GLES20.glDrawArrays(GLES20.GL_TRIANGLE_STRIP, 0, 4);
            } catch (GlUtil.GlException e) {
                throw new VideoFrameProcessingException(e, presentationTimeUs);
            }
        }

        @Override
        public void release() throws VideoFrameProcessingException {
            super.release();
            try { program.delete(); } catch (GlUtil.GlException e) { throw new VideoFrameProcessingException(e); }
        }
    }
}
