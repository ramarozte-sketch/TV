package pt.rui.cockpittv;

import android.app.Activity;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.Tracks;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Leitor nativo (Media3 / ExoPlayer) que fica por cima da área do vídeo da página.
 * Usa os descodificadores de hardware (MediaCodec), passagem de áudio AC-3/E-AC-3/DTS pela HDMI,
 * buffer afinado para IPTV e ajuste da taxa de imagem do ecrã. Se falhar, a página volta ao leitor web.
 */
@UnstableApi
class NativePlayer {
    interface Listener { void onEvent(String kind, String msg); }

    private static final String UA = "VLC/3.0.20 LibVLC/3.0.20";
    private static final String UA_BROWSER = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    private final Activity act;
    private final FrameLayout root;
    private final Listener listener;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private FrameLayout box;
    private PlayerView view;
    private TextView label;
    private android.view.TextureView ttv;   /* telemóvel: superfície própria, com o tamanho calculado por nós */
    private TextView hud;
    private ExoPlayer player;
    private boolean deint = false;
    private String aspect = "fit", aspectLabel = "Ajustar";
    private boolean full = false;
    private android.widget.LinearLayout ctl;
    private TextView ctlAspect, ctlFull;

    /** Formato da imagem: fit (ajustar), zoom (preencher, corta), stretch (esticar), 16:9, 4:3, 21:9. */
    public void setAspect(String mode, String label) {
        aspect = mode == null || mode.isEmpty() ? "fit" : mode;
        aspectLabel = label == null || label.isEmpty() ? aspect : label;
        ensureViews();
        applyAspect();
        if (ctlAspect != null) ctlAspect.setText("▭ " + aspectLabel);
    }

    public void setFull(boolean f) {
        full = f;
        /* ecrã total: o vídeo também ocupa a zona do recorte da câmara (senão fica uma faixa preta nesse lado) */
        try {
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                android.view.WindowManager.LayoutParams wl = act.getWindow().getAttributes();
                wl.layoutInDisplayCutoutMode = f
                        ? (android.os.Build.VERSION.SDK_INT >= 30 ? android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                                                                  : android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES)
                        : android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
                act.getWindow().setAttributes(wl);
            }
        } catch (Throwable ignored) { }
        applyRect();
        if (ctlFull != null) ctlFull.setText(full ? "✕ Sair do ecrã total" : "⛶ Ecrã total");
    }

    private void applyAspect() {
        if (view == null || box == null) return;
        if (ttv != null) {
            view.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
            applyTexture();
            if (deint) applyDeint();
            view.removeCallbacks(reportAspect);
            view.postDelayed(reportAspect, 600);
            return;
        }
        View sv0 = view.getVideoSurfaceView();
        if (sv0 instanceof android.view.TextureView) {
            /* telemóvel (TextureView): ajustar sempre em FIT e aplicar a escala nós próprios; não depende dos modos do PlayerView */
            view.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
            view.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            view.post(this::applyScale);
            view.removeCallbacks(reportAspect);
            view.postDelayed(reportAspect, 600);
            return;
        }
        int bw = box.getWidth(), bh = box.getHeight();
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        lp.gravity = Gravity.CENTER;
        int mode = AspectRatioFrameLayout.RESIZE_MODE_FIT;
        float r = 0f;
        if ("zoom".equals(aspect)) mode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM;
        else if ("stretch".equals(aspect)) mode = AspectRatioFrameLayout.RESIZE_MODE_FILL;
        else if ("16:9".equals(aspect)) r = 16f / 9f;
        else if ("4:3".equals(aspect)) r = 4f / 3f;
        else if ("21:9".equals(aspect)) r = 21f / 9f;
        if (r > 0f) {
            mode = AspectRatioFrameLayout.RESIZE_MODE_FILL;
            if (bw > 0 && bh > 0) {
                int w = bw, h = Math.round(bw / r);
                if (h > bh) { h = bh; w = Math.round(bh * r); }
                lp.width = w; lp.height = h;
            }
        }
        view.setResizeMode(mode);
        view.setLayoutParams(lp);
        view.removeCallbacks(reportAspect);
        view.postDelayed(reportAspect, 600);
    }

    /** Telemóvel: dá à TextureView o tamanho exato do formato pedido; a TextureView estica a imagem até aos seus limites e a caixa corta o que sobra. */
    private void applyTexture() {
        try {
            if (ttv == null || box == null) return;
            float bw = box.getWidth(), bh = box.getHeight();
            if (bw <= 0 || bh <= 0) return;
            if (deint) { ttv.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)); return; }
            androidx.media3.common.VideoSize vs = player != null ? player.getVideoSize() : null;
            float vw = 0f, vh = 0f;
            if (vs != null && vs.width > 0 && vs.height > 0) { vw = vs.width * (vs.pixelWidthHeightRatio > 0 ? vs.pixelWidthHeightRatio : 1f); vh = vs.height; }
            float tw, th;
            if ("stretch".equals(aspect)) { tw = bw; th = bh; }
            else {
                float r = "16:9".equals(aspect) ? 16f / 9f : "4:3".equals(aspect) ? 4f / 3f : "21:9".equals(aspect) ? 21f / 9f : (vh > 0 ? vw / vh : bw / bh);
                /* retângulo "ajustar" para a proporção r dentro da caixa */
                float fw = bw, fh = bw / r;
                if (fh > bh) { fh = bh; fw = bh * r; }
                if ("zoom".equals(aspect)) {
                    float k = Math.max(bw / fw, bh / fh); tw = fw * k; th = fh * k;
                } else { tw = fw; th = fh; }
            }
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Math.round(tw), Math.round(th));
            lp.gravity = Gravity.CENTER;
            ttv.setLayoutParams(lp);
            ttv.setScaleX(1f); ttv.setScaleY(1f);
        } catch (Throwable ignored) { }
    }

    /** TextureView: escala a superfície (já ajustada em FIT) até ao retângulo pedido pelo formato. */
    private void applyScale() {
        try {
            if (view == null || box == null) return;
            View sv = view.getVideoSurfaceView();
            if (!(sv instanceof android.view.TextureView)) return;
            float bw = box.getWidth(), bh = box.getHeight(), fw = sv.getWidth(), fh = sv.getHeight();
            if (bw <= 0 || bh <= 0 || fw <= 0 || fh <= 0) return;
            float tw = fw, th = fh;
            if ("stretch".equals(aspect)) { tw = bw; th = bh; }
            else if ("zoom".equals(aspect)) { float k = Math.max(bw / fw, bh / fh); tw = fw * k; th = fh * k; }
            else {
                float r = "16:9".equals(aspect) ? 16f / 9f : "4:3".equals(aspect) ? 4f / 3f : "21:9".equals(aspect) ? 21f / 9f : 0f;
                if (r > 0f) { tw = bw; th = bw / r; if (th > bh) { th = bh; tw = bh * r; } }
            }
            sv.setPivotX(fw / 2f); sv.setPivotY(fh / 2f);
            sv.setScaleX(tw / fw); sv.setScaleY(th / fh);
        } catch (Throwable ignored) { }
    }

    private final Runnable reportAspect = this::reportAspectNow;

    private void reportAspectNow() {
        try {
            androidx.media3.common.VideoSize vs = player != null ? player.getVideoSize() : null;
            View sv = ttv != null ? ttv : (view != null ? view.getVideoSurfaceView() : null);
            String info = aspect + "|" + (vs != null ? vs.width + "x" + vs.height : "?") + "|" + (box != null ? box.getWidth() + "x" + box.getHeight() : "?") + "|" + (sv != null ? sv.getWidth() + "x" + sv.getHeight() : "?");
            listener.onEvent("aspect:info", info);
        } catch (Throwable ignored) { }
    }

    private final Runnable hideCtl = () -> { if (ctl != null) ctl.setVisibility(View.GONE); };

    private TextView ctlBtn(String t, final String ev) {
        TextView b = new TextView(act);
        b.setText(t);
        b.setTextColor(Color.WHITE);
        b.setTextSize(15f);
        b.setPadding(28, 16, 28, 16);
        b.setBackgroundColor(0xCC000000);
        b.setOnClickListener(v -> { listener.onEvent("ui", ev); if (box != null) { box.removeCallbacks(hideCtl); box.postDelayed(hideCtl, 3500); } });
        return b;
    }

    private void buildCtl() {
        ctl = new android.widget.LinearLayout(act);
        ctl.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        ctlAspect = ctlBtn("▭ " + aspectLabel, "aspect");
        ctlFull = ctlBtn(full ? "✕ Sair do ecrã total" : "⛶ Ecrã total", "full");
        android.widget.LinearLayout.LayoutParams gap = new android.widget.LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gap.rightMargin = 12;
        ctl.addView(ctlAspect, gap);
        ctl.addView(ctlFull);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.TOP | Gravity.RIGHT;
        lp.topMargin = 16; lp.rightMargin = 16;
        ctl.setVisibility(View.GONE);
        box.addView(ctl, lp);
        /* toque no vídeo mostra/esconde os botões (telemóvel) */
        box.setClickable(true);
        final android.view.GestureDetector gd = new android.view.GestureDetector(act, new android.view.GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(android.view.MotionEvent e) { return true; }
            @Override public boolean onDoubleTap(android.view.MotionEvent e) { listener.onEvent("ui", "full"); return true; }
            @Override public boolean onSingleTapConfirmed(android.view.MotionEvent e) {
                if (ctl.getVisibility() == View.VISIBLE) { ctl.setVisibility(View.GONE); box.removeCallbacks(hideCtl); }
                else { ctl.setVisibility(View.VISIBLE); box.removeCallbacks(hideCtl); box.postDelayed(hideCtl, 3500); }
                return true;
            }
        });
        box.setOnTouchListener((v, ev) -> gd.onTouchEvent(ev));
        box.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> { if ((r - l) != (or - ol) || (b - t) != (ob - ot)) view.post(this::applyAspect); });
    }
    private boolean afr = true;
    private int lastMode = 0;

    /** Acompanhar a taxa de atualização: liga/desliga a troca do modo do ecrã da TV. */
    public void setAfr(boolean on) { afr = on; if (on) matchRefresh(); else setDisplayMode(0); }

    /** Escolhe o modo do ecrã (mesma resolução) cuja taxa é um múltiplo exato da taxa do vídeo (24→24/48/72/120, 25→50, 30→60, 50→50/100...). */
    private void matchRefresh() {
        if (!afr || player == null || android.os.Build.VERSION.SDK_INT < 23) return;
        try {
            Format f = player.getVideoFormat();
            if (f == null || f.frameRate <= 0) return;
            final float fps = f.frameRate;
            android.view.Display d = act.getWindowManager().getDefaultDisplay();
            android.view.Display.Mode cur = d.getMode();
            android.view.Display.Mode best = null; float bestErr = 1e9f; int bestMul = 99;
            for (android.view.Display.Mode m : d.getSupportedModes()) {
                if (m.getPhysicalWidth() != cur.getPhysicalWidth() || m.getPhysicalHeight() != cur.getPhysicalHeight()) continue;
                float r = m.getRefreshRate();
                int mul = Math.max(1, Math.round(r / fps));
                float err = Math.abs(r - fps * mul);
                if (err > 0.6f) continue;              /* 23.976 → 24 e 59.94 → 60 passam */
                if (err < bestErr - 0.05f || (Math.abs(err - bestErr) <= 0.05f && mul < bestMul)) { best = m; bestErr = err; bestMul = mul; }
            }
            if (best != null) setDisplayMode(best.getModeId());
        } catch (Throwable ignored) { }
    }

    private void setDisplayMode(final int id) {
        if (id == lastMode) return;
        lastMode = id;
        act.runOnUiThread(() -> {
            try {
                android.view.WindowManager.LayoutParams lp = act.getWindow().getAttributes();
                lp.preferredDisplayModeId = id;
                act.getWindow().setAttributes(lp);
            } catch (Throwable ignored) { }
        });
    }

    /** Desentrelaçamento adaptativo na GPU (experimental). Falha em silêncio e volta ao vídeo normal. */
    public void setDeint(boolean on) { deint = on; applyDeint(); }

    private boolean fxApplied = false;
    private String fxKey = "";

    /** Com a cadeia de efeitos ligada o vídeo é ajustado à superfície pela própria cadeia; por isso o formato é pedido aqui (Presentation). */
    private androidx.media3.common.Effect presentationFor() {
        try {
            if (box == null || "fit".equals(aspect)) return null;
            int bw = box.getWidth(), bh = box.getHeight();
            if (bw <= 0 || bh <= 0) return null;
            if ("stretch".equals(aspect)) return androidx.media3.effect.Presentation.createForWidthAndHeight(bw, bh, androidx.media3.effect.Presentation.LAYOUT_STRETCH_TO_FIT);
            if ("zoom".equals(aspect)) return androidx.media3.effect.Presentation.createForWidthAndHeight(bw, bh, androidx.media3.effect.Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP);
            float r = "16:9".equals(aspect) ? 16f / 9f : "4:3".equals(aspect) ? 4f / 3f : "21:9".equals(aspect) ? 21f / 9f : 0f;
            if (r <= 0f) return null;
            int w = bw, h = Math.round(bw / r);
            if (h > bh) { h = bh; w = Math.round(bh * r); }
            return androidx.media3.effect.Presentation.createForWidthAndHeight(w, h, androidx.media3.effect.Presentation.LAYOUT_STRETCH_TO_FIT);
        } catch (Throwable t) { return null; }
    }

    private void applyDeint() {
        if (player == null) return;
        try {
            /* Só entra o encadeamento de efeitos quando o desentrelaçamento está ligado: mesmo vazio, esse caminho desenha o vídeo
               ajustado ao tamanho da superfície (barras pretas). */
            if (deint) {
                String key = aspect + "|" + (box != null ? box.getWidth() + "x" + box.getHeight() : "");
                if (fxApplied && key.equals(fxKey)) return;
                java.util.List<androidx.media3.common.Effect> fx = new java.util.ArrayList<>();
                fx.add(new DeinterlaceEffect());
                androidx.media3.common.Effect pres = presentationFor();
                if (pres != null) fx.add(pres);
                player.setVideoEffects(fx);
                fxApplied = true; fxKey = key;
            } else if (fxApplied) {
                player.setVideoEffects(new java.util.ArrayList<androidx.media3.common.Effect>());
                fxApplied = false; fxKey = "";
            }
        } catch (Throwable e) {
            listener.onEvent("deint:error", String.valueOf(e));
        }
    }
    private DefaultTrackSelector selector;
    private int retries = 0;
    private boolean wantVisible = true;
    private final List<Object[]> audio = new ArrayList<>();
    private final List<Object[]> text = new ArrayList<>();
    private String curUrl = "";
    private String curMime = null;
    private volatile String posInfo = "0|0|1";
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (player == null) return;
            long d = player.getDuration();
            posInfo = player.getCurrentPosition() + "|" + (d == C.TIME_UNSET ? 0 : d) + "|" + (player.isCurrentMediaItemLive() ? 1 : 0);
            ui.postDelayed(this, 1000);
        }
    };
    String pos() { return posInfo; }
    private volatile String tracksJson = "{\"audio\":[],\"text\":[]}";
    private final Runnable hideLabel = new Runnable() { @Override public void run() { if (label != null) label.setVisibility(View.GONE); } };

    NativePlayer(Activity act, FrameLayout root, Listener l) {
        this.act = act;
        this.root = root;
        this.listener = l;
    }

    String tracks() { return tracksJson; }

    /** Aviso por cima do vídeo (episódio seguinte, saltar intro). Texto vazio esconde. */
    void hud(String t) {
        ensureViews();
        if (t == null || t.isEmpty()) { hud.setVisibility(View.GONE); return; }
        hud.setText(t);
        hud.setVisibility(View.VISIBLE);
    }

    private void ensureViews() {
        if (box != null) return;
        box = new FrameLayout(act);
        box.setFocusable(false);
        box.setBackgroundColor(Color.BLACK);
        boolean tvDev = false;
        try { android.app.UiModeManager um = (android.app.UiModeManager) act.getSystemService(android.content.Context.UI_MODE_SERVICE); tvDev = um != null && um.getCurrentModeType() == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION; } catch (Throwable ignored) { }
        PlayerView pv = null;
        if (!tvDev) {
            /* telemóvel: superfície TextureView, que respeita zoom/corte/esticar dentro da área do vídeo */
            try { pv = (PlayerView) android.view.LayoutInflater.from(act).inflate(R.layout.player_texture, null); } catch (Throwable ignored) { pv = null; }
        }
        view = pv != null ? pv : new PlayerView(act);
        if (!tvDev && pv != null) {
            ttv = new android.view.TextureView(act);
            ttv.setOpaque(true);
            box.addView(ttv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER));
        }
        view.setClipChildren(false);   /* a escala (esticar/zoom) desenha para lá da área do vídeo ajustado */
        box.setClipChildren(true);
        view.setUseController(false);
        view.setFocusable(false);
        view.setFocusableInTouchMode(false);
        view.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        view.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        view.setShutterBackgroundColor(ttv != null ? Color.TRANSPARENT : Color.BLACK);
        box.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        label = new TextView(act);
        label.setTextColor(Color.WHITE);
        label.setTextSize(22f);
        label.setPadding(28, 14, 28, 14);
        label.setBackgroundColor(0x99000000);
        label.setVisibility(View.GONE);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.leftMargin = 24;
        lp.topMargin = 24;
        box.addView(label, lp);
        hud = new TextView(act);
        hud.setTextColor(Color.WHITE);
        hud.setTextSize(20f);
        hud.setPadding(28, 16, 28, 16);
        hud.setBackgroundColor(0xCC1A2B44);
        hud.setVisibility(View.GONE);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.gravity = Gravity.BOTTOM | Gravity.RIGHT;
        hp.rightMargin = 32;
        hp.bottomMargin = 48;
        box.addView(hud, hp);
        view.addOnLayoutChangeListener((vv, l, t, r2, b2, ol, ot, or2, ob) -> { if (r2 - l != or2 - ol || b2 - t != ob - ot) view.post(this::applyScale); });
        box.addOnLayoutChangeListener((vv, l, t, r2, b2, ol, ot, or2, ob) -> { if (r2 - l != or2 - ol || b2 - t != ob - ot) view.post(this::applyScale); });
        buildCtl();
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(10, 10);
        p.gravity = Gravity.TOP | Gravity.LEFT;
        box.setVisibility(View.INVISIBLE);
        root.addView(box, p);
    }

    private void ensurePlayer(String referer) {
        releasePlayer();
        boolean hasRef = referer != null && !referer.isEmpty();
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent(hasRef ? UA_BROWSER : UA)
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(25000);
        if (hasRef) {
            Map<String, String> h = new HashMap<>();
            h.put("Referer", referer);
            h.put("Origin", referer.replaceAll("^(https?://[^/]+).*$", "$1"));
            http.setDefaultRequestProperties(h);
        }
        DefaultExtractorsFactory ex = new DefaultExtractorsFactory()
                .setConstantBitrateSeekingEnabled(true)
                .setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES
                        | DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS
                        | DefaultTsPayloadReaderFactory.FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS);
        DefaultRenderersFactory rf = new DefaultRenderersFactory(act)
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
                .setEnableDecoderFallback(true)
                .setAllowedVideoJoiningTimeMs(0);   /* arranque mais rápido: não espera pela junção do vídeo */
        selector = new DefaultTrackSelector(act);
        selector.setParameters(selector.buildUponParameters()
                /* 4K: sem limitar a qualidade ao tamanho do ecrã e sempre a melhor versão que o aparelho descodifica */
                .setForceHighestSupportedBitrate(true)
                .setAllowVideoMixedMimeTypeAdaptiveness(true)
                .setAllowVideoNonSeamlessAdaptiveness(true)
                .setExceedRendererCapabilitiesIfNecessary(true)
                .setPreferredAudioLanguage("pt")
                .setPreferredTextLanguage("pt")
                .setSelectUndeterminedTextLanguage(false)
                .build());
        /* Buffers grandes (ficheiros 4K têm 25-80 Mbit/s): começa a ver depressa e aguenta quedas de rede; o limite em bytes evita falta de memória */
        DefaultLoadControl lc = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(25000, 90000, 2000, 5000)
                .setTargetBufferBytes(96 * 1024 * 1024)
                .setPrioritizeTimeOverSizeThresholds(false)
                .setBackBuffer(15000, false)
                .build();
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build();
        player = new ExoPlayer.Builder(act, rf)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(new DefaultDataSource.Factory(act, http), ex))
                .setTrackSelector(selector)
                .setLoadControl(lc)
                .setAudioAttributes(aa, true)
                .setWakeMode(C.WAKE_MODE_NETWORK)
                .build();
        applyDeint();
        player.setSeekParameters(androidx.media3.exoplayer.SeekParameters.CLOSEST_SYNC);   /* saltos rápidos em ficheiros grandes */
        player.setVideoChangeFrameRateStrategy(C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_ONLY_IF_SEAMLESS);
        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_READY) { retries = 0; listener.onEvent("ready", ""); }
                else if (state == Player.STATE_BUFFERING) listener.onEvent("buffering", "");
                else if (state == Player.STATE_ENDED) listener.onEvent("ended", "");
            }

            @Override
            public void onTracksChanged(Tracks t) { rebuildTracks(t); matchRefresh(); }

            @Override
            public void onVideoSizeChanged(androidx.media3.common.VideoSize v) { matchRefresh(); if (view != null) view.postDelayed(NativePlayer.this::applyAspect, 150); }

            @Override
            public void onPlayerError(PlaybackException e) {
                if (player == null) return;
                if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition();
                    player.prepare();
                    return;
                }
                boolean io = e.errorCode >= 2000 && e.errorCode < 3000;
                if (io && retries < 2) {
                    retries++;
                    ui.postDelayed(new Runnable() { @Override public void run() { if (player != null) { player.prepare(); player.play(); } } }, 1200L * retries);
                    return;
                }
                listener.onEvent("error", e.getErrorCodeName());
            }
        });
        view.setPlayer(player);
        if (ttv != null) player.setVideoTextureView(ttv);
    }

    private void releasePlayer() {
        ui.removeCallbacksAndMessages(null);
        if (view != null) view.setPlayer(null);
        if (player != null) {
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }
        audio.clear();
        text.clear();
        tracksJson = "{\"audio\":[],\"text\":[]}";
    }

    void play(String url, String referer, String hint, String title, long startMs) {
        ensureViews();
        retries = 0;
        ensurePlayer(referer);
        MediaItem.Builder b = new MediaItem.Builder().setUri(url);
        curUrl = url;
        curMime = "hls".equals(hint) ? MimeTypes.APPLICATION_M3U8 : "dash".equals(hint) ? MimeTypes.APPLICATION_MPD : null;
        if (curMime != null) b.setMimeType(curMime);
        if (startMs > 0) player.setMediaItem(b.build(), startMs); else player.setMediaItem(b.build());
        player.setPlayWhenReady(true);
        player.prepare();
        posInfo = "0|0|1";
        ui.postDelayed(ticker, 1000);
        box.setVisibility(wantVisible ? View.VISIBLE : View.INVISIBLE);
        if (title != null && !title.isEmpty()) {
            label.setText(title);
            label.setVisibility(View.VISIBLE);
            ui.postDelayed(hideLabel, 2800);
        }
    }

    void stop() {
        releasePlayer();
        setDisplayMode(0);
        if (box != null) box.setVisibility(View.GONE);
    }

    private int[] lastRect = null;

    /** Em ecrã total o leitor ocupa o ecrã inteiro (medido pelo Android, não pela página). */
    private void applyRect() {
        if (box == null) return;
        FrameLayout.LayoutParams p;
        if (full) {
            p = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        } else if (lastRect != null) {
            p = new FrameLayout.LayoutParams(Math.max(lastRect[2], 1), Math.max(lastRect[3], 1));
            p.gravity = Gravity.TOP | Gravity.LEFT;
            p.leftMargin = lastRect[0];
            p.topMargin = lastRect[1];
        } else return;
        box.setLayoutParams(p);
    }

    void rect(int x, int y, int w, int h, boolean visible) {
        if (box == null) return;
        wantVisible = visible;
        lastRect = new int[]{x, y, w, h};
        applyRect();
        if (player != null) box.setVisibility(visible ? View.VISIBLE : View.INVISIBLE);
    }

    /** Legendas externas (SRT/VTT em texto): recria o item mantendo a posição. */
    void subtitle(String text, String label, String lang) {
        if (player == null || curUrl.isEmpty() || text == null || text.isEmpty()) return;
        try {
            boolean vtt = text.trim().startsWith("WEBVTT");
            File f = new File(act.getCacheDir(), vtt ? "sub.vtt" : "sub.srt");
            FileOutputStream o = new FileOutputStream(f);
            o.write(text.getBytes("UTF-8"));
            o.close();
            MediaItem.SubtitleConfiguration sc = new MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(f))
                    .setMimeType(vtt ? MimeTypes.TEXT_VTT : MimeTypes.APPLICATION_SUBRIP)
                    .setLanguage(lang == null || lang.isEmpty() ? "pt" : lang)
                    .setLabel(label == null ? "Legendas" : label)
                    .setSelectionFlags(C.SELECTION_FLAG_DEFAULT | C.SELECTION_FLAG_FORCED)
                    .build();
            MediaItem.Builder b = new MediaItem.Builder().setUri(curUrl).setSubtitleConfigurations(java.util.Collections.singletonList(sc));
            if (curMime != null) b.setMimeType(curMime);
            long pos = player.isCurrentMediaItemLive() ? C.TIME_UNSET : player.getCurrentPosition();
            boolean play = player.getPlayWhenReady();
            player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build());
            if (pos != C.TIME_UNSET) player.setMediaItem(b.build(), pos); else player.setMediaItem(b.build());
            player.prepare();
            player.setPlayWhenReady(play);
        } catch (Exception e) {
            listener.onEvent("suberr", String.valueOf(e));
        }
    }

    void toggle() {
        if (player == null) return;
        if (player.getPlayWhenReady()) player.pause(); else player.play();
    }

    void pause() { if (player != null) player.pause(); }

    void seek(long deltaMs) {
        if (player == null || player.isCurrentMediaItemLive()) return;
        long to = Math.max(0, player.getCurrentPosition() + deltaMs);
        long d = player.getDuration();
        if (d != C.TIME_UNSET && to > d) to = d;
        player.seekTo(to);
    }

    void pick(String type, int idx) {
        if (player == null) return;
        boolean isText = "text".equals(type);
        List<Object[]> list = isText ? text : audio;
        int ttype = isText ? C.TRACK_TYPE_TEXT : C.TRACK_TYPE_AUDIO;
        TrackSelectionParameters.Builder b = player.getTrackSelectionParameters().buildUpon();
        if (idx < 0 || idx >= list.size()) {
            if (isText) b.setTrackTypeDisabled(ttype, true);
        } else {
            Object[] t = list.get(idx);
            Tracks.Group g = (Tracks.Group) t[0];
            int i = (Integer) t[1];
            b.setTrackTypeDisabled(ttype, false);
            b.setOverrideForType(new TrackSelectionOverride(g.getMediaTrackGroup(), i));
        }
        player.setTrackSelectionParameters(b.build());
    }

    private static String q(String s) {
        return "\"" + s.replace("\\", "\\\\").replace("\"", "'").replace("\n", " ") + "\"";
    }

    private static String name(Format f, int n) {
        StringBuilder s = new StringBuilder();
        if (f.label != null && !f.label.isEmpty()) s.append(f.label);
        if (f.language != null && !"und".equals(f.language)) {
            if (s.length() > 0) s.append(" · ");
            s.append(f.language);
        }
        if (f.channelCount > 2) s.append(" · ").append(f.channelCount == 6 ? "5.1" : f.channelCount == 8 ? "7.1" : f.channelCount + "ch");
        String m = f.sampleMimeType;
        if (m != null) {
            String c = MimeTypes.AUDIO_AC3.equals(m) ? "AC-3" : MimeTypes.AUDIO_E_AC3.equals(m) || MimeTypes.AUDIO_E_AC3_JOC.equals(m) ? "E-AC-3"
                    : MimeTypes.AUDIO_AAC.equals(m) ? "AAC" : m.startsWith("audio/") ? m.substring(6).toUpperCase() : "";
            if (!c.isEmpty()) s.append(" · ").append(c);
        }
        return s.length() == 0 ? "Faixa " + (n + 1) : s.toString();
    }

    private void rebuildTracks(Tracks t) {
        audio.clear();
        text.clear();
        StringBuilder a = new StringBuilder(), x = new StringBuilder();
        boolean anyAudio = false, okAudio = false;
        for (Tracks.Group g : t.getGroups()) {
            int type = g.getType();
            if (type == C.TRACK_TYPE_AUDIO) {
                anyAudio = true;
                if (g.isSelected() && g.isSupported()) okAudio = true;
            }
            if (type != C.TRACK_TYPE_AUDIO && type != C.TRACK_TYPE_TEXT) continue;
            for (int i = 0; i < g.length; i++) {
                if (!g.isTrackSupported(i)) continue;
                boolean isAudio = type == C.TRACK_TYPE_AUDIO;
                List<Object[]> list = isAudio ? audio : text;
                StringBuilder sb = isAudio ? a : x;
                if (sb.length() > 0) sb.append(',');
                sb.append("{\"i\":").append(list.size()).append(",\"name\":").append(q(name(g.getTrackFormat(i), list.size())))
                        .append(",\"on\":").append(g.isTrackSelected(i)).append('}');
                list.add(new Object[]{g, i});
            }
        }
        tracksJson = "{\"audio\":[" + a + "],\"text\":[" + x + "]}";
        if (anyAudio && !okAudio) listener.onEvent("noaudio", "");
    }

    void release() {
        releasePlayer();
        if (box != null) { try { root.removeView(box); } catch (Exception ignored) { } box = null; view = null; label = null; }
    }
}
