package pt.rui.cockpittv;

import android.app.Activity;
import android.graphics.Color;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.FrameLayout;
import android.widget.TextView;

import androidx.media3.common.AudioAttributes;
import androidx.media3.common.C;
import androidx.media3.common.Format;
import androidx.media3.common.MediaItem;
import androidx.media3.common.MimeTypes;
import androidx.media3.common.PlaybackException;
import androidx.media3.common.Player;
import androidx.media3.common.TrackSelectionOverride;
import androidx.media3.common.TrackSelectionParameters;
import androidx.media3.common.Tracks;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.datasource.DefaultDataSource;
import androidx.media3.datasource.DefaultHttpDataSource;
import androidx.media3.exoplayer.DefaultLoadControl;
import androidx.media3.exoplayer.DefaultRenderersFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.exoplayer.DecoderCounters;
import androidx.media3.exoplayer.analytics.AnalyticsListener;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.trackselection.DefaultTrackSelector;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.ts.DefaultTsPayloadReaderFactory;
import androidx.media3.ui.AspectRatioFrameLayout;
import androidx.media3.ui.PlayerView;

import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Leitor nativo (Media3 / ExoPlayer) que fica por cima da área do vídeo da página.
 * Usa os descodificadores de hardware (MediaCodec), passagem de áudio AC-3/E-AC-3/DTS pela HDMI,
 * buffer afinado para IPTV e ajuste da taxa de imagem do ecrã. Se falhar, a página volta ao leitor web.
 */
@UnstableApi
class NativePlayer {
    interface Listener { void onEvent(String kind, String msg); }

    private static final String UA = "VLC/3.0.20 LibVLC/3.0.20";
    private static final String UA_BROWSER = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36";

    private final Activity act;
    private final FrameLayout root;
    private final Listener listener;
    private final Handler ui = new Handler(Looper.getMainLooper());

    private FrameLayout box;
    private PlayerView view;
    private TextView label;
    private android.view.SurfaceView hdrSv;   /* telemóvel: superfície para HDR / Dolby Vision (a TextureView mostra cores erradas) */
    private boolean hdrOn = false;
    private boolean hdrContent = false;   /* o vídeo atual é HDR/Dolby Vision (a superfície HDR separada está desligada: no telemóvel estragava a imagem) */
    private static final boolean HDR_SURFACE = false;
    private boolean dv5Warned = false;
    private android.view.TextureView ttv;   /* telemóvel: superfície própria, com o tamanho calculado por nós */
    private TextView hud;
    private ExoPlayer player;
    private boolean deint = false;
    /* v265: acerto do som em ms (+ = a imagem espera, para quando o som chega atrasado), guardado por saída de som */
    static volatile int avOffsetMs = 0;
    private String audDec = "";
    private volatile String avKind = "pcm";   /* o acerto fica guardado à parte para som Dolby/DTS e para o resto (AAC…) */
    private String avKey() {
        try { android.media.AudioManager am = (android.media.AudioManager) act.getSystemService(android.content.Context.AUDIO_SERVICE);
            for (android.media.AudioDeviceInfo d : am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) { int t = d.getType(); if (t == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == 26 || t == 27) return "av_bt_" + avKind; }
        } catch (Throwable ignored) { }
        return "av_spk_" + avKind;
    }
    int getAv() { return avOffsetMs; }
    void setAv(int ms) { avOffsetMs = Math.max(-2000, Math.min(2000, ms)); try { act.getSharedPreferences("np", 0).edit().putInt(avKey(), avOffsetMs).apply(); } catch (Throwable ignored) { } log("acerto do som (" + avKey() + "): " + avOffsetMs + " ms"); }
    /* v267: telemóvel Samsung + som Dolby pelo altifalante: o descodificador Dolby do telemóvel faz o som chegar ~0,8 s antes
       da imagem (confirmado pelo Rui com −800 ms). Fica como ponto de partida; se o acertares à mão, vale o teu valor. */
    private int avDefault(String k) {
        /* só o descodificador Dolby do aparelho (Samsung) precisa do −800 ms; com o FFmpeg da app o som já vem acertado */
        try { if ("av_spk_dolby".equals(k) && !isTvDev() && "samsung".equalsIgnoreCase(android.os.Build.MANUFACTURER)) return -800; } catch (Throwable ignored) { }
        return 0;
    }
    void setDolbySw(boolean on) { try { act.getSharedPreferences("np", 0).edit().putBoolean("dolbySw", on).apply(); } catch (Throwable ignored) { } log("Dolby pela app: " + on); }
    /** Dolby pelo FFmpeg da app: ligado por omissão no telemóvel/tablet, desligado na TV (Definições guardadas em "np"/"dolbySw"). */
    boolean dolbySw() {
        try { android.content.SharedPreferences sp = act.getSharedPreferences("np", 0); if (sp.contains("dolbySw")) return sp.getBoolean("dolbySw", false); } catch (Throwable ignored) { }
        return !isTvDev();
    }
    void loadAv() { try { String k = avKey(); avOffsetMs = act.getSharedPreferences("np", 0).getInt(k, avDefault(k)); } catch (Throwable ignored) { } }
    private int capW = Integer.MAX_VALUE, capH = Integer.MAX_VALUE;
    private boolean srvCap = false; private String srvCapUrl = "";   /* limite posto por o servidor recusar (509) */   /* limite de resolução (vista múltipla) */
    private boolean liveGuess = false, userRewound = false;
    /* correções aos pedaços .ts dos canais HLS (vídeo desfasado do som, SPS de 1080i) */
    private final TsFix.State tsFix = new TsFix.State();
    private String decName = "";

    /** Limita a resolução do vídeo (0 = sem limite). Útil nos frames pequenos da vista múltipla. */
    void setMaxRes(int w, int h) {
        pvCapState = -1;
        capW = w > 0 ? w : Integer.MAX_VALUE;
        capH = h > 0 ? h : Integer.MAX_VALUE;
        try { if (selector != null) selector.setParameters(selector.buildUponParameters().setMaxVideoSize(capW, capH).build()); } catch (Throwable ignored) { }
    }

    private long rendLast = -1; private int rendDead = 0;
    /** Chamado de 5 em 5 s com vários frames: se a imagem não avança (mas o leitor diz que está a dar), religa a superfície e depois recarrega o canal. */
    void checkFrames() {
        try {
            if (player == null || userPaused || !wantVisible || box == null || box.getVisibility() != View.VISIBLE || curUrl.isEmpty() || !player.getPlayWhenReady() || player.getPlaybackState() != Player.STATE_READY || player.getVideoFormat() == null) { rendDead = 0; rendLast = -1; return; }   /* frame escondido: o decodificador pára sozinho, não é falha */
            androidx.media3.exoplayer.DecoderCounters dc = player.getVideoDecoderCounters();
            if (dc == null) return;
            dc.ensureUpdated();
            long n = dc.renderedOutputBufferCount;
            if (n != rendLast) { rendLast = n; rendDead = 0; return; }
            rendDead++;
            log("checkFrames: imagem parada (" + rendDead + ")");
            if (rendDead == 1) reattach.run();
            else if (rendDead >= 2) {
                rendDead = 0;
                MediaItem.Builder b = new MediaItem.Builder().setUri(curUrl);
                if (curMime != null) b.setMimeType(curMime);
                player.setMediaItem(b.build()); player.prepare(); player.play();
            }
        } catch (Throwable ignored) { }
    }

    /** Modo leve (frames extra com 3-4 frames): escolhe sempre a versão de menor débito, para a TV não perder fluidez. */
    void setLite(boolean on) {
        try { if (selector != null) selector.setParameters(selector.buildUponParameters().setForceLowestBitrate(on).setForceHighestSupportedBitrate(!on).build()); } catch (Throwable ignored) { }
    }

    /** Túnel só vale com 1 frame: com vários frames o túnel do principal deixa a imagem a preto (o som continua). */
    private boolean tunnelAllowed = true;
    private boolean texMode = false;
    private Boolean texOverride = null;
    void useTexture(boolean tex) { texOverride = tex; }
    /** TV: SurfaceView (directa, com desentrelaçamento do hardware) com 1 frame; TextureView com 2+ frames (várias SurfaceView deixavam o frame 1 preto).
     *  Devolve true se recriou as vistas (quem chama tem de voltar a abrir o canal). */
    boolean switchSurface(boolean tex) {
        boolean pref = false;
        try { pref = act.getSharedPreferences("np", 0).getBoolean("tvTexture", false); } catch (Throwable ignored) { }
        boolean target = tex || pref || !isTvDev();
        texOverride = tex;
        if (box != null && texMode == target) return false;
        if (box == null) return false;
        release();
        ttv = null; hdrSv = null; hdrOn = false; lastRect = null;
        return true;
    }
    void setTunnelAllowed(boolean allowed) {
        if (tunnelAllowed == allowed) return;
        tunnelAllowed = allowed;
        try {
            if (selector != null) {
                boolean on = allowed && !shareAudio && !deint && isTvDev() && !texMode && act.getSharedPreferences("np", 0).getBoolean("tunnel", false);
                selector.setParameters(selector.buildUponParameters().setTunnelingEnabled(on).build());
            }
        } catch (Throwable ignored) { }
    }

    /** Imagem parada com som (visto ao abrir o 2.º frame): se não saem frames novos em ~3,5 s, religa a superfície e, se for preciso, recarrega o canal. */
    void ensureVideoAlive() {
        try {
            if (player == null || curUrl.isEmpty()) return;
            long c0 = -1;
            androidx.media3.exoplayer.DecoderCounters dc = player.getVideoDecoderCounters();
            if (dc != null) { dc.ensureUpdated(); c0 = dc.renderedOutputBufferCount; }
            final long base = c0;
            ui.postDelayed(() -> {
                try {
                    if (player == null || userPaused || !wantVisible || box == null || box.getVisibility() != View.VISIBLE || !player.getPlayWhenReady() || player.getPlaybackState() != Player.STATE_READY) return;
                    if (player.getVideoFormat() == null) return;   /* só áudio */
                    androidx.media3.exoplayer.DecoderCounters d2 = player.getVideoDecoderCounters();
                    if (d2 == null) return; d2.ensureUpdated();
                    if (d2.renderedOutputBufferCount > base) return;
                    log("frame 1 preto com som: religa superfície e recarrega");
                    reattach.run();
                    ui.postDelayed(() -> {
                        try {
                            if (player == null) return;
                            androidx.media3.exoplayer.DecoderCounters d3 = player.getVideoDecoderCounters();
                            if (d3 != null) { d3.ensureUpdated(); if (d3.renderedOutputBufferCount > base) return; }
                            MediaItem.Builder b = new MediaItem.Builder().setUri(curUrl);
                            if (curMime != null) b.setMimeType(curMime);
                            player.setMediaItem(b.build()); player.prepare(); player.play();
                        } catch (Throwable ignored) { }
                    }, 2000);
                } catch (Throwable ignored) { }
            }, 3500);
        } catch (Throwable ignored) { }
    }

    /** Religa a superfície do vídeo (depois de mudar o número de frames). */
    volatile boolean gotFrame = false;
    /** Já apareceu pelo menos um frame de imagem neste vídeo. */
    boolean hasFrame() { return gotFrame; }

    /** Ecrã total: só religa a superfície se a imagem estiver mesmo parada (religar à força faz o leitor voltar a carregar: soluço de vários segundos). */
    void reattachIfStalled() {
        ui.post(() -> {
            try {
                if (player == null) return;
                androidx.media3.exoplayer.DecoderCounters dc = player.getVideoDecoderCounters();
                if (dc == null) return;
                dc.ensureUpdated();
                final long n0 = dc.renderedOutputBufferCount;
                ui.postDelayed(() -> {
                    try {
                        if (player == null || userPaused) return;
                        androidx.media3.exoplayer.DecoderCounters d2 = player.getVideoDecoderCounters();
                        if (d2 == null) return;
                        d2.ensureUpdated();
                        boolean moving = d2.renderedOutputBufferCount != n0;
                        if (!moving && player.getPlaybackState() == Player.STATE_READY && player.getPlayWhenReady()) {
                            /* v285: nos filmes não religa (no diário a imagem estava a andar: falso alarme logo a seguir a mudar para 24 Hz, e religar já deixou o descodificador da TV preso) */
                            if (vodUrl) { log("ecrã total: sem imagens novas em 0,45 s (filme) — sem religar"); return; }
                            log("ecrã total: imagem parada, religa superfície"); reattach.run();
                        }
                    } catch (Throwable ignored) { }
                }, 450);
            } catch (Throwable ignored) { }
        });
    }
    void reattachSurface() { try { ui.removeCallbacks(reattach); ui.post(reattach); } catch (Throwable ignored) { } }

    private boolean isTvDev() {
        try { android.app.UiModeManager um = (android.app.UiModeManager) act.getSystemService(android.content.Context.UI_MODE_SERVICE); return um != null && um.getCurrentModeType() == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION; } catch (Throwable e) { return false; }
    }

    /** Estatísticas para o ecrã de informação. */
    String stats() {
        try {
            if (player == null) return "Sem vídeo a dar.";
            Format f = player.getVideoFormat(), a = player.getAudioFormat();
            DecoderCounters dc = player.getVideoDecoderCounters();
            if (dc != null) dc.ensureUpdated();
            StringBuilder sb = new StringBuilder();
            if (f != null) {
                sb.append(f.width).append("×").append(f.height);
                if (f.frameRate > 0) sb.append(" · ").append(Math.round(f.frameRate * 10f) / 10f).append(" fps");
                if (f.sampleMimeType != null) sb.append(" · ").append(f.sampleMimeType.replace("video/", ""));
                if (f.bitrate > 0) sb.append(" · ").append(Math.round(f.bitrate / 1e5f) / 10f).append(" Mbps");
            } else sb.append("sem vídeo");
            sb.append("\n");
            if (decName.length() > 0) sb.append(decName).append(" · ");
            if (dc != null) sb.append("perdidos ").append(dc.droppedBufferCount).append(" · ");
            sb.append("buffer ").append(player.getTotalBufferedDuration() / 1000).append(" s");
            if (player.isCurrentMediaItemLive()) { long o = player.getCurrentLiveOffset(); if (o != C.TIME_UNSET) sb.append(" · atraso ").append(Math.round(o / 100f) / 10f).append(" s"); }
            if (a != null && a.sampleMimeType != null) sb.append(" · ").append(a.sampleMimeType.replace("audio/", "")).append(a.channelCount > 0 ? " " + a.channelCount + "c" : "");
            try { if (selector != null && selector.getParameters().tunnelingEnabled) sb.append(" · túnel"); } catch (Throwable ignored) { }
            if (capW != Integer.MAX_VALUE) sb.append(" · máx ").append(capH).append("p");
            { String fx = tsFix.info(); if (fx.length() > 0) sb.append(" · ").append(fx); }
            return sb.toString();
        } catch (Throwable e) { return "Sem estatísticas: " + e; }
    }

    private final Runnable liveCheck = new Runnable() {
        @Override public void run() {
            try {
                if (player == null) return;
                if (liveGuess && !userRewound && !userPaused && player.isCurrentMediaItemLive() && player.getPlaybackState() == Player.STATE_READY) {
                    long off = player.getCurrentLiveOffset();
                    if (off != C.TIME_UNSET && off > 25000) { log("atraso " + off + " ms: salta para o direto"); player.seekToDefaultPosition(); }
                }
            } catch (Throwable ignored) { }
            if (player != null) ui.postDelayed(this, 10000);
        }
    };
    private String aspect = "fit", aspectLabel = "Ajustar";
    private boolean full = false;
    private android.widget.LinearLayout ctl;
    private TextView ctlAspect, ctlFull;

    /** Formato da imagem: fit (ajustar), zoom (preencher, corta), stretch (esticar), 16:9, 4:3, 21:9. */
    public void setAspect(String mode, String label) {
        aspect = mode == null || mode.isEmpty() ? "fit" : mode;
        aspectLabel = label == null || label.isEmpty() ? aspect : label;
        ensureViews();
        applyAspect();
        if (ctlAspect != null) NIcons.set(ctlAspect, "▭  " + aspectLabel);
    }

    private boolean previewMode = false;
    /** Na pré-visualização do Início não há botão de formato (esticar). */
    private boolean wasPv = false;   /* a pré-visualização do Início estava a dar mesmo antes deste pedido */
    private int pvCapState = -1;   /* -1 = por aplicar, 0 = sem limite, 1 = pré-visualização */
    /** Pré-visualização pequena: não vale a pena descodificar 1080p/4K (poupa dados, bateria e CPU). Em ecrã total volta ao automático. */
    private void applyPreviewCap() {
        try {
            if (srvCap) return;
            int want = (previewMode && !full) ? 1 : 0;
            if (want == pvCapState) return;
            if (want == 0) { setMaxRes(0, 0); pvCapState = 0; return; }
            boolean metered = false;
            try { android.net.ConnectivityManager cm = (android.net.ConnectivityManager) act.getSystemService(android.content.Context.CONNECTIVITY_SERVICE); metered = cm != null && cm.isActiveNetworkMetered(); } catch (Throwable ignored) { }
            if (metered) setMaxRes(640, 360); else setMaxRes(960, 540);
            pvCapState = 1;
            log("pré-visualização: limite " + (metered ? "640x360 (dados móveis)" : "960x540"));
        } catch (Throwable ignored) { }
    }

    public void setPreview(boolean p) {
        if (!p && previewMode) wasPv = true;
        previewMode = p;
        applyPreviewCap();
        if (ctlAspect != null) ctlAspect.setVisibility(p ? View.GONE : View.VISIBLE);
    }

    public void setFull(boolean f) {
        full = f;
        applyPreviewCap();
        if (f) matchRefresh();   /* v281: a taxa de atualização só muda em ecrã total */
        /* ecrã total: o vídeo também ocupa a zona do recorte da câmara (senão fica uma faixa preta nesse lado) */
        try {
            if (android.os.Build.VERSION.SDK_INT >= 28) {
                android.view.WindowManager.LayoutParams wl = act.getWindow().getAttributes();
                wl.layoutInDisplayCutoutMode = f
                        ? (android.os.Build.VERSION.SDK_INT >= 30 ? android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS
                                                                  : android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES)
                        : android.view.WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_DEFAULT;
                act.getWindow().setAttributes(wl);
            }
        } catch (Throwable ignored) { }
        applyRect();
        /* v276: ao mudar de tamanho (pré-visualização → ecrã total) o leitor ficava a carregar ~4 s (diário de 4/11): verifica e religa */
        try { arTries = 0; ui.removeCallbacks(afterResize); ui.postDelayed(afterResize, 900); } catch (Throwable ignored) { }
        /* v281: da miniatura para ecrã total (mesma ligação) o som ficava desfasado (RTP 1 UHD): realinha uma vez */
        /* v293: da miniatura para ecrã total na TV a imagem ficava preta (só som): já não faz o salto de ressincronização
           (que na TV deixava a imagem por mostrar) e verifica 1,5 s depois se a imagem está mesmo a aparecer; se não, religa-a */
        if (f && pvToFull) { pvToFull = false; ui.removeCallbacks(fullCheck); ui.postDelayed(fullCheck, 1500); }
        if (ctlFull != null) NIcons.set(ctlFull, full ? "✕  Sair do ecrã total" : "⛶  Ecrã total");
    }

    private void applyAspect() {
        if (view == null || box == null) return;
        if (ttv != null) {
            view.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
            applyTexture();
            applyDeint();
            view.removeCallbacks(reportAspect);
            view.postDelayed(reportAspect, 600);
            return;
        }
        View sv0 = view.getVideoSurfaceView();
        if (sv0 instanceof android.view.TextureView) {
            /* telemóvel (TextureView): ajustar sempre em FIT e aplicar a escala nós próprios; não depende dos modos do PlayerView */
            view.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
            view.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
            view.post(this::applyScale);
            view.removeCallbacks(reportAspect);
            view.postDelayed(reportAspect, 600);
            return;
        }
        int bw = box.getWidth(), bh = box.getHeight();
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        lp.gravity = Gravity.CENTER;
        int mode = AspectRatioFrameLayout.RESIZE_MODE_FIT;
        float r = 0f;
        if ("zoom".equals(aspect)) mode = AspectRatioFrameLayout.RESIZE_MODE_ZOOM;
        else if ("stretch".equals(aspect)) mode = AspectRatioFrameLayout.RESIZE_MODE_FILL;
        else if ("16:9".equals(aspect)) r = 16f / 9f;
        else if ("4:3".equals(aspect)) r = 4f / 3f;
        else if ("21:9".equals(aspect)) r = 21f / 9f;
        if (r > 0f) {
            mode = AspectRatioFrameLayout.RESIZE_MODE_FILL;
            if (bw > 0 && bh > 0) {
                int w = bw, h = Math.round(bw / r);
                if (h > bh) { h = bh; w = Math.round(bh * r); }
                lp.width = w; lp.height = h;
            }
        }
        view.setResizeMode(mode);
        view.setLayoutParams(lp);
        view.removeCallbacks(reportAspect);
        view.postDelayed(reportAspect, 600);
    }

    /** Telemóvel: conteúdo HDR / Dolby Vision vai para uma SurfaceView em modo de cor HDR; o resto continua na TextureView. */
    private void updateHdrSurface() {
        try {
            if (player == null || ttv == null || hdrSv == null) return;
            androidx.media3.common.Format f = player.getVideoFormat();
            if (f == null) return;
            String codecs = f.codecs == null ? "" : f.codecs.toLowerCase(java.util.Locale.ROOT);
            boolean dv = androidx.media3.common.MimeTypes.VIDEO_DOLBY_VISION.equals(f.sampleMimeType) || codecs.startsWith("dvh") || codecs.startsWith("dva");
            boolean hdr = dv || (f.colorInfo != null && (f.colorInfo.colorTransfer == C.COLOR_TRANSFER_ST2084 || f.colorInfo.colorTransfer == C.COLOR_TRANSFER_HLG));
            hdrContent = hdr; applyDeint();
            boolean dv5 = codecs.matches("^dv(he|h1|av|a1)\\.05.*");
            if (dv5 && !dv5Warned) {
                dv5Warned = true;
                listener.onEvent("hdr:dv5", codecs);
                if (label != null) {
                    label.setText("Dolby Vision perfil 5\nEste telemóvel não mostra este perfil com as cores certas.\nUsa uma versão HDR10 ou SDR do ficheiro.");
                    label.setVisibility(View.VISIBLE); label.removeCallbacks(hideLabel); label.postDelayed(hideLabel, 9000);
                }
            } else if (!dv5) dv5Warned = false;
            if (!HDR_SURFACE) return;
            if (hdr == hdrOn) return;
            hdrOn = hdr;
            applyDeint();
            if (hdr) {
                player.setVideoSurfaceView(hdrSv);
                ttv.setVisibility(View.GONE); hdrSv.setVisibility(View.VISIBLE);
                try { act.getWindow().setColorMode(android.content.pm.ActivityInfo.COLOR_MODE_HDR); } catch (Throwable ignored) { }
            } else {
                player.setVideoTextureView(ttv);
                hdrSv.setVisibility(View.GONE); ttv.setVisibility(View.VISIBLE);
                try { act.getWindow().setColorMode(android.content.pm.ActivityInfo.COLOR_MODE_DEFAULT); } catch (Throwable ignored) { }
            }
            applyAspect();
        } catch (Throwable ignored) { }
    }

    /** Telemóvel: dá à TextureView o tamanho exato do formato pedido; a TextureView estica a imagem até aos seus limites e a caixa corta o que sobra. */
    private void applyTexture() {
        try {
            if (ttv == null || box == null) return;
            float bw = box.getWidth(), bh = box.getHeight();
            if (bw <= 0 || bh <= 0) return;
            final View tgt = hdrOn && hdrSv != null ? hdrSv : ttv;
            if (fxApplied) { tgt.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT)); return; }
            androidx.media3.common.VideoSize vs = player != null ? player.getVideoSize() : null;
            float vw = 0f, vh = 0f;
            if (vs != null && vs.width > 0 && vs.height > 0) { vw = vs.width * (vs.pixelWidthHeightRatio > 0 ? vs.pixelWidthHeightRatio : 1f); vh = vs.height; }
            float tw, th;
            if ("stretch".equals(aspect)) { tw = bw; th = bh; }
            else {
                float r = "16:9".equals(aspect) ? 16f / 9f : "4:3".equals(aspect) ? 4f / 3f : "21:9".equals(aspect) ? 21f / 9f : (vh > 0 ? vw / vh : bw / bh);
                /* retângulo "ajustar" para a proporção r dentro da caixa */
                float fw = bw, fh = bw / r;
                if (fh > bh) { fh = bh; fw = bh * r; }
                if ("zoom".equals(aspect)) {
                    float k = Math.max(bw / fw, bh / fh); tw = fw * k; th = fh * k;
                } else { tw = fw; th = fh; }
            }
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(Math.round(tw), Math.round(th));
            lp.gravity = Gravity.CENTER;
            tgt.setLayoutParams(lp);
            tgt.setScaleX(1f); tgt.setScaleY(1f);
        } catch (Throwable ignored) { }
    }

    /** TextureView: escala a superfície (já ajustada em FIT) até ao retângulo pedido pelo formato. */
    private void applyScale() {
        try {
            if (view == null || box == null) return;
            View sv = view.getVideoSurfaceView();
            if (!(sv instanceof android.view.TextureView)) return;
            float bw = box.getWidth(), bh = box.getHeight(), fw = sv.getWidth(), fh = sv.getHeight();
            if (bw <= 0 || bh <= 0 || fw <= 0 || fh <= 0) return;
            float tw = fw, th = fh;
            if ("stretch".equals(aspect)) { tw = bw; th = bh; }
            else if ("zoom".equals(aspect)) { float k = Math.max(bw / fw, bh / fh); tw = fw * k; th = fh * k; }
            else {
                float r = "16:9".equals(aspect) ? 16f / 9f : "4:3".equals(aspect) ? 4f / 3f : "21:9".equals(aspect) ? 21f / 9f : 0f;
                if (r > 0f) { tw = bw; th = bw / r; if (th > bh) { th = bh; tw = bh * r; } }
            }
            sv.setPivotX(fw / 2f); sv.setPivotY(fh / 2f);
            sv.setScaleX(tw / fw); sv.setScaleY(th / fh);
        } catch (Throwable ignored) { }
    }

    private final Runnable reportAspect = this::reportAspectNow;

    private void reportAspectNow() {
        try {
            androidx.media3.common.VideoSize vs = player != null ? player.getVideoSize() : null;
            View sv = ttv != null ? ttv : (view != null ? view.getVideoSurfaceView() : null);
            String info = aspect + "|" + (vs != null ? vs.width + "x" + vs.height : "?") + "|" + (box != null ? box.getWidth() + "x" + box.getHeight() : "?") + "|" + (sv != null ? sv.getWidth() + "x" + sv.getHeight() : "?");
            listener.onEvent("aspect:info", info);
        } catch (Throwable ignored) { }
    }

    private final Runnable hideCtl = () -> { if (ctl != null) ctl.setVisibility(View.GONE); if (this.seekWrap != null) this.seekWrap.setVisibility(View.GONE); };

    /* barra de progresso (filmes/episódios): aparece com os botões, ao tocar no vídeo */
    private android.widget.LinearLayout seekWrap;
    private android.widget.SeekBar seekBar;
    private TextView seekPos, seekDur;
    private boolean seeking = false;
    private long seekTempUntil = 0;

    private static String fmtT(long ms) {
        long s = Math.max(0, ms / 1000), h = s / 3600, m = (s % 3600) / 60, sec = s % 60;
        return h > 0 ? String.format(java.util.Locale.US, "%d:%02d:%02d", h, m, sec) : String.format(java.util.Locale.US, "%d:%02d", m, sec);
    }

    private boolean seekable() {
        try { return player != null && !player.isCurrentMediaItemLive() && player.getDuration() > 0 && player.getDuration() != C.TIME_UNSET; } catch (Throwable e) { return false; }
    }

    private void updateSeekVis() {
        if (seekWrap == null || ctl == null) return;
        boolean want = (ctl.getVisibility() == View.VISIBLE || System.currentTimeMillis() < seekTempUntil) && seekable() && full;   /* v291: fora do ecrã total há a barra do ecrã do canal (uma só barra) */
        seekWrap.setVisibility(want ? View.VISIBLE : View.GONE);
        if (seekWrap.getVisibility() == View.VISIBLE) updateSeekPos();
    }

    private void updateSeekPos() {
        if (seekBar == null || seeking || !seekable()) return;
        long d = player.getDuration(), p = Math.min(player.getCurrentPosition(), d);
        seekBar.setProgress((int) (p * 1000L / d));
        seekPos.setText(fmtT(p));
        seekDur.setText(remain(p, d));
    }
    /** «−1:23:45 · 2:18:06»: o que falta e a duração total. */
    static String remain(long p, long d) { return "−" + fmtT(Math.max(0, d - p)) + "  ·  " + fmtT(d); }

    private void buildSeek() {
        seekWrap = new android.widget.LinearLayout(act);
        seekWrap.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        seekWrap.setGravity(Gravity.CENTER_VERTICAL);
        seekWrap.setBackgroundColor(0xAA000000);
        seekWrap.setPadding(24, 8, 24, 8);
        seekPos = new TextView(act);
        seekPos.setTextColor(Color.WHITE);
        seekPos.setTextSize(15f);
        seekPos.setText("0:00");
        seekDur = new TextView(act);
        seekDur.setTextColor(Color.WHITE);
        seekDur.setTextSize(15f);
        seekDur.setText("0:00");
        seekBar = new android.widget.SeekBar(act);
        seekBar.setMax(1000);
        seekBar.setFocusable(false);
        seekBar.setOnSeekBarChangeListener(new android.widget.SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(android.widget.SeekBar sb, int progress, boolean fromUser) {
                if (fromUser && seekable()) seekPos.setText(fmtT(player.getDuration() * progress / 1000L));
            }
            @Override public void onStartTrackingTouch(android.widget.SeekBar sb) { seeking = true; if (box != null) box.removeCallbacks(hideCtl); }
            @Override public void onStopTrackingTouch(android.widget.SeekBar sb) {
                if (seekable()) player.seekTo(player.getDuration() * sb.getProgress() / 1000L);
                seeking = false;
                if (box != null) { box.removeCallbacks(hideCtl); box.postDelayed(hideCtl, 3500); }
            }
        });
        android.widget.LinearLayout.LayoutParams bp = new android.widget.LinearLayout.LayoutParams(0, ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        bp.leftMargin = 16; bp.rightMargin = 16;
        seekWrap.addView(seekPos);
        seekWrap.addView(seekBar, bp);
        seekWrap.addView(seekDur);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.BOTTOM;
        seekWrap.setVisibility(View.GONE);
        box.addView(seekWrap, lp);
    }

    private TextView ctlBtn(String t, final String ev) {
        TextView b = new TextView(act);
        float d = act.getResources().getDisplayMetrics().density;
        NIcons.set(b, t);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14f);
        b.setTypeface(android.graphics.Typeface.create(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD));
        b.setLetterSpacing(0.02f);
        b.setGravity(Gravity.CENTER);
        b.setPadding((int) (18 * d), (int) (10 * d), (int) (18 * d), (int) (10 * d));
        android.graphics.drawable.GradientDrawable g = new android.graphics.drawable.GradientDrawable();
        g.setColor(0xB3141E32); g.setCornerRadius(28 * d); g.setStroke((int) Math.max(1, d), 0x45FFFFFF);
        b.setBackground(g);
        b.setElevation(6 * d);
        b.setOnTouchListener((v, e) -> {
            int a = e.getActionMasked();
            if (a == android.view.MotionEvent.ACTION_DOWN) v.animate().scaleX(0.94f).scaleY(0.94f).setDuration(90).start();
            else if (a == android.view.MotionEvent.ACTION_UP || a == android.view.MotionEvent.ACTION_CANCEL) v.animate().scaleX(1f).scaleY(1f).setDuration(140).start();
            return false;
        });
        b.setOnClickListener(v -> { listener.onEvent("ui", ev); if (box != null) { box.removeCallbacks(hideCtl); box.postDelayed(hideCtl, 3500); } });
        return b;
    }

    private void buildCtl() {
        ctl = new android.widget.LinearLayout(act) {
            private void sv(int v) { super.setVisibility(v); }
            /* aparece a deslizar de cima com fade; some com fade */
            @Override public void setVisibility(int v) {
                float d = getResources().getDisplayMetrics().density;
                if (v == VISIBLE && getVisibility() != VISIBLE) {
                    sv(v); animate().cancel(); setAlpha(0f); setTranslationY(-14 * d);
                    animate().alpha(1f).translationY(0f).setDuration(240).setInterpolator(new android.view.animation.DecelerateInterpolator()).start();
                } else if (v != VISIBLE && getVisibility() == VISIBLE) {
                    animate().cancel();
                    animate().alpha(0f).translationY(-10 * d).setDuration(180).withEndAction(() -> sv(v)).start();
                } else sv(v);
            }
        };
        ctl.setOrientation(android.widget.LinearLayout.HORIZONTAL);
        ctlAspect = ctlBtn("▭  " + aspectLabel, "aspect");
        ctlFull = ctlBtn(full ? "✕  Sair do ecrã total" : "⛶  Ecrã total", "full");
        android.widget.LinearLayout.LayoutParams gap = new android.widget.LinearLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        gap.rightMargin = 12;
        ctl.addView(ctlAspect, gap);
        if (previewMode) ctlAspect.setVisibility(View.GONE);
        ctl.addView(ctlFull);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.TOP | Gravity.RIGHT;
        lp.topMargin = 16; lp.rightMargin = 16;
        ctl.setVisibility(View.GONE);
        box.addView(ctl, lp);
        buildSeek();
        /* toque no vídeo mostra/esconde os botões (telemóvel) */
        box.setClickable(true);
        final android.view.GestureDetector gd = new android.view.GestureDetector(act, new android.view.GestureDetector.SimpleOnGestureListener() {
            @Override public boolean onDown(android.view.MotionEvent e) { gStart = -1f; gMode = 0; gLastVol = -1; return true; }
            /* ecrã total: deslizar na metade direita = volume, na esquerda = brilho (de baixo para cima aumenta) */
            @Override public boolean onScroll(android.view.MotionEvent e1, android.view.MotionEvent e2, float dx, float dy) {
                try {
                    if (e1 == null || e2 == null || box == null || box.getHeight() <= 0) return false;
                    android.view.View dv = act.getWindow().getDecorView();
                    if (box.getWidth() < dv.getWidth() * 0.85f || box.getHeight() < dv.getHeight() * 0.85f) return false;
                    float ddy = e1.getY() - e2.getY(), ddx = e2.getX() - e1.getX();
                    if (gMode == 0) {
                        if (Math.abs(ddy) < 10 * act.getResources().getDisplayMetrics().density * 0.5f || Math.abs(ddy) < Math.abs(ddx) * 1.2f) return false;   /* v268: começa mais cedo */
                        gMode = e1.getX() < box.getWidth() / 2f ? 2 : 1;
                        if (gMode == 1) {
                            android.media.AudioManager am = (android.media.AudioManager) act.getSystemService(android.content.Context.AUDIO_SERVICE);
                            gStart = am.getStreamVolume(android.media.AudioManager.STREAM_MUSIC);
                        } else {
                            float b = act.getWindow().getAttributes().screenBrightness;
                            if (b < 0) { try { b = android.provider.Settings.System.getInt(act.getContentResolver(), android.provider.Settings.System.SCREEN_BRIGHTNESS) / 255f; } catch (Throwable t) { b = 0.5f; } }
                            gStart = b;
                        }
                    }
                    float frac = ddy / (box.getHeight() * 0.8f);
                    if (gMode == 1) {
                        android.media.AudioManager am = (android.media.AudioManager) act.getSystemService(android.content.Context.AUDIO_SERVICE);
                        int max = am.getStreamMaxVolume(android.media.AudioManager.STREAM_MUSIC);
                        int v = Math.max(0, Math.min(max, Math.round(gStart + frac * max)));
                        if (v != gLastVol) { gLastVol = v; am.setStreamVolume(android.media.AudioManager.STREAM_MUSIC, v, 0); }   /* v268: só quando muda de degrau */
                        lastGestLevel = v / (float) Math.max(1, max); gestIcon = v == 0 ? "🔇" : (lastGestLevel < 0.5f ? "🔉" : "🔊");
                    } else {
                        float b = Math.max(0.02f, Math.min(1f, gStart + frac));
                        userBright = b; gPendBright = b;
                        /* v268: o brilho da janela muda no máximo uma vez por imagem do ecrã (cada mudança obriga a janela a refazer-se) */
                        if (!gBrightPosted) { gBrightPosted = true; box.postOnAnimation(() -> { gBrightPosted = false; try {
                            android.view.WindowManager.LayoutParams lp = act.getWindow().getAttributes();
                            if (Math.abs(lp.screenBrightness - gPendBright) > 0.004f) { lp.screenBrightness = gPendBright; act.getWindow().setAttributes(lp); } } catch (Throwable ignored) { } }); }
                        lastGestLevel = b; gestIcon = "☀️";
                    }
                    showGest(gMode == 1, gMode == 1 ? lastGestLevel : lastGestLevel, gestIcon);
                    return true;
                } catch (Throwable t) { return false; }
            }
            @Override public boolean onDoubleTap(android.view.MotionEvent e) { listener.onEvent("ui", "full"); return true; }
            @Override public boolean onSingleTapConfirmed(android.view.MotionEvent e) {
                try { listener.onEvent("ui", "tap"); } catch (Throwable ignored) { }   /* vários frames: o toque escolhe o frame e o seu som */
                if (!full) return true;   /* fora do ecrã total o ecrã já tem os seus botões (⛶, Ajustar): sem sobreposição «Esticar / Ecrã total» */
                if (ctl.getVisibility() == View.VISIBLE) { ctl.setVisibility(View.GONE); box.removeCallbacks(hideCtl); updateSeekVis(); }
                else { ctl.setVisibility(View.VISIBLE); box.removeCallbacks(hideCtl); box.postDelayed(hideCtl, 3500); updateSeekVis(); }
                return true;
            }
        });
        box.setOnTouchListener((v, ev) -> gd.onTouchEvent(ev));
        box.addOnLayoutChangeListener((v, l, t, r, b, ol, ot, or, ob) -> { if ((r - l) != (or - ol) || (b - t) != (ob - ot)) { view.post(this::applyAspect); } });
    }
    private boolean afr = true;
    private int lastMode = 0;
    /** Brilho escolhido por gesto (-1 = o do sistema); a MainActivity repõe-no depois de escurecer. */
    static float userBright = -1f;
    private float gStart = -1f;
    private int gMode = 0;
    private float lastGestLevel = 0f;
    private int gLastVol = -1; private float gPendBright = -1f; private boolean gBrightPosted = false; private int gHudSide = -1;
    private String gestIcon = "🔊";
    private GestHud gestHud;

    /** Barra moderna de volume (direita) / brilho (esquerda). */
    private void showGest(boolean right, float level, String icon) {
        if (box == null) return;
        if (gestHud == null) {
            gestHud = new GestHud(act);
            box.addView(gestHud);
        }
        /* v268: o lugar da barra só se refaz quando muda de lado (antes refazia o layout a cada movimento do dedo) */
        int side = right ? 1 : 0;
        if (side != gHudSide || gestHud.getVisibility() != View.VISIBLE) {
            gHudSide = side;
            float d = act.getResources().getDisplayMetrics().density;
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams((int) (64 * d), (int) (230 * d));
            lp.gravity = Gravity.CENTER_VERTICAL | (right ? Gravity.RIGHT : Gravity.LEFT);
            lp.leftMargin = (int) (36 * d); lp.rightMargin = (int) (36 * d);
            gestHud.setLayoutParams(lp);
            gestHud.bringToFront();
        }
        gestHud.show(level, icon);
    }

    /** Acompanhar a taxa de atualização: liga/desliga a troca do modo do ecrã da TV. */
    public void setAfr(boolean on) { afr = on; if (on) matchRefresh(); else setDisplayMode(0); }

    /** Escolhe o modo do ecrã (mesma resolução) cuja taxa é um múltiplo exato da taxa do vídeo (24→24/48/72/120, 25→50, 30→60, 50→50/100...). */
    private void matchRefresh() {
        if (!afr || player == null || android.os.Build.VERSION.SDK_INT < 23) return;
        if (previewMode && !full) return;   /* v281: a miniatura do Início não muda o modo da TV (o ecrã total muda) */
        try {
            Format f = player.getVideoFormat();
            if (f == null || f.frameRate <= 0) return;
            final float fps = f.frameRate;
            android.view.Display d = act.getWindowManager().getDefaultDisplay();
            android.view.Display.Mode cur = d.getMode();
            /* v295: se a frequência atual já serve (ex.: TV a 50 Hz e canal a 25 fps), não muda: cada mudança deixa a TV preta 2-4 s */
            { float r0 = cur.getRefreshRate(); int m0 = Math.max(1, Math.round(r0 / fps)); if (Math.abs(r0 - fps * m0) <= 0.6f && m0 <= 2) return; }
            android.view.Display.Mode best = null; float bestErr = 1e9f; int bestMul = 99;
            for (android.view.Display.Mode m : d.getSupportedModes()) {
                if (m.getPhysicalWidth() != cur.getPhysicalWidth() || m.getPhysicalHeight() != cur.getPhysicalHeight()) continue;
                float r = m.getRefreshRate();
                int mul = Math.max(1, Math.round(r / fps));
                float err = Math.abs(r - fps * mul);
                if (err > 0.6f) continue;              /* 23.976 → 24 e 59.94 → 60 passam */
                if (err < bestErr - 0.05f || (Math.abs(err - bestErr) <= 0.05f && mul < bestMul)) { best = m; bestErr = err; bestMul = mul; }
            }
            if (best != null && best.getModeId() != cur.getModeId()) {
                setDisplayMode(best.getModeId());
                final int hz = Math.round(best.getRefreshRate());
                if (label != null && full) { label.setText("A ajustar a TV para " + hz + " Hz…"); label.setVisibility(View.VISIBLE); label.removeCallbacks(hideLabel); label.postDelayed(hideLabel, 4500); }
                log("taxa de atualização: " + Math.round(cur.getRefreshRate()) + " → " + hz + " Hz (vídeo " + fps + " fps)");
            }
        } catch (Throwable ignored) { }
    }

    private void setDisplayMode(final int id) {
        if (id == lastMode) return;
        lastMode = id;
        act.runOnUiThread(() -> {
            try {
                android.view.WindowManager.LayoutParams lp = act.getWindow().getAttributes();
                lp.preferredDisplayModeId = id;
                act.getWindow().setAttributes(lp);
            } catch (Throwable ignored) { }
        });
    }

    /** Desentrelaçamento adaptativo na GPU (experimental). Falha em silêncio e volta ao vídeo normal. */
    public void setDeint(boolean on) { deint = on; applyDeint(); }

    private boolean fxApplied = false;
    private String fxKey = "";

    /** Com a cadeia de efeitos ligada o vídeo é ajustado à superfície pela própria cadeia; por isso o formato é pedido aqui (Presentation). */
    private androidx.media3.common.Effect presentationFor() {
        try {
            if (box == null || "fit".equals(aspect)) return null;
            int bw = box.getWidth(), bh = box.getHeight();
            if (bw <= 0 || bh <= 0) return null;
            if ("stretch".equals(aspect)) return androidx.media3.effect.Presentation.createForWidthAndHeight(bw, bh, androidx.media3.effect.Presentation.LAYOUT_STRETCH_TO_FIT);
            if ("zoom".equals(aspect)) return androidx.media3.effect.Presentation.createForWidthAndHeight(bw, bh, androidx.media3.effect.Presentation.LAYOUT_SCALE_TO_FIT_WITH_CROP);
            float r = "16:9".equals(aspect) ? 16f / 9f : "4:3".equals(aspect) ? 4f / 3f : "21:9".equals(aspect) ? 21f / 9f : 0f;
            if (r <= 0f) return null;
            int w = bw, h = Math.round(bw / r);
            if (h > bh) { h = bh; w = Math.round(bh * r); }
            return androidx.media3.effect.Presentation.createForWidthAndHeight(w, h, androidx.media3.effect.Presentation.LAYOUT_STRETCH_TO_FIT);
        } catch (Throwable t) { return null; }
    }

    private boolean fxBroken = false;   /* a cadeia de efeitos falhou neste aparelho: não voltar a usar */

    /* ===== Aspeto das legendas (tamanho, cor, fundo, contorno, posição) ===== */
    static int subSizePct = 100, subFg = 0xFFFFFFFF, subBg = 0x99000000, subEdge = 0;
    static float subBottom = 0.08f;

    void applySubStyle() {
        try {
            if (view == null) return;
            androidx.media3.ui.SubtitleView sv = view.getSubtitleView();
            if (sv == null) return;
            sv.setApplyEmbeddedStyles(false);
            sv.setApplyEmbeddedFontSizes(false);
            sv.setFractionalTextSize(0.0533f * subSizePct / 100f);
            int edge = subEdge == 1 ? androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_DROP_SHADOW : subEdge == 2 ? androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_OUTLINE : androidx.media3.ui.CaptionStyleCompat.EDGE_TYPE_NONE;
            sv.setStyle(new androidx.media3.ui.CaptionStyleCompat(subFg, subBg, Color.TRANSPARENT, edge, 0xFF000000, null));
            sv.setBottomPaddingFraction(subBottom);
        } catch (Throwable ignored) { }
    }

    public void setSubStyle(int sizePct, int fg, int bg, int edge, float bottom) {
        subSizePct = sizePct; subFg = fg; subBg = bg; subEdge = edge; subBottom = bottom;
        applySubStyle();
    }

    /** v264: no diário, o que importa para o som acertado: formatos, descodificadores, efeitos e saída de som (Bluetooth tem atraso próprio). */
    private void logAv() {
        try {
            StringBuilder sb = new StringBuilder("A/V:");
            androidx.media3.common.Format vf = player.getVideoFormat(), af = player.getAudioFormat();
            if (vf != null) sb.append(" vídeo ").append(vf.sampleMimeType).append(" ").append(vf.width).append("x").append(vf.height).append(vf.frameRate > 0 ? " " + Math.round(vf.frameRate) + "fps" : "");
            if (af != null) sb.append(" · som ").append(af.sampleMimeType).append(" ").append(af.channelCount).append("ch ").append(af.sampleRate).append("Hz");
            if (!audDec.isEmpty()) sb.append(" (").append(audDec).append(")");
            sb.append(" · acerto ").append(avOffsetMs).append(" ms");
            try { androidx.media3.exoplayer.DecoderCounters dc = player.getAudioDecoderCounters(); if (dc != null) sb.append(" · tramas som ").append(dc.renderedOutputBufferCount); } catch (Throwable ignored) { }
            sb.append(fxApplied ? " · efeitos GPU ligados" : " · sem efeitos");
            try {
                android.media.AudioManager am = (android.media.AudioManager) act.getSystemService(android.content.Context.AUDIO_SERVICE);
                String out = "altifalante";
                for (android.media.AudioDeviceInfo d : am.getDevices(android.media.AudioManager.GET_DEVICES_OUTPUTS)) {
                    int t = d.getType();
                    if (t == android.media.AudioDeviceInfo.TYPE_BLUETOOTH_A2DP || t == 26 /* BLE headset */ || t == 27 /* BLE speaker */) { out = "Bluetooth (" + d.getProductName() + ")"; break; }
                    if (t == android.media.AudioDeviceInfo.TYPE_WIRED_HEADPHONES || t == android.media.AudioDeviceInfo.TYPE_USB_HEADSET) out = "auscultadores com fio";
                    if (t == android.media.AudioDeviceInfo.TYPE_HDMI || t == android.media.AudioDeviceInfo.TYPE_HDMI_ARC || t == 29 /* eARC */) out = "HDMI";
                }
                sb.append(" · saída ").append(out);
            } catch (Throwable ignored) { }
            log(sb.toString());
        } catch (Throwable ignored) { }
    }

    private void applyDeint() {
        if (player == null) return;
        try {
            /* A cadeia de efeitos (desentrelaçamento / formato) só entra com o vídeo já conhecido e só em SD/HD: em 4K ou HDR falha a criar a superfície EGL (0x3003). */
            androidx.media3.common.Format vf = player.getVideoFormat();
            /* v264: filmes e séries (ficheiros) são sempre progressivos — a cadeia de efeitos (GPU) só atrasava a imagem face ao som
               no telemóvel (diário: filme .mp4 com som dessincronizado). Fica só para os diretos, onde há 1080i/576i. */
            boolean want = deint && !vodUrl && !hdrContent && !fxBroken && vf != null && vf.height > 0 && vf.height <= 1100 && vf.width <= 2000;
            if (want) {
                String key = aspect + "|" + (box != null ? box.getWidth() + "x" + box.getHeight() : "");
                if (fxApplied && key.equals(fxKey)) return;
                java.util.List<androidx.media3.common.Effect> fx = new java.util.ArrayList<>();
                fx.add(new DeinterlaceEffect());
                androidx.media3.common.Effect pres = presentationFor();
                if (pres != null) fx.add(pres);
                player.setVideoEffects(fx);
                fxApplied = true; fxKey = key;
            } else if (fxApplied) {
                player.setVideoEffects(new java.util.ArrayList<androidx.media3.common.Effect>());
                fxApplied = false; fxKey = "";
            }
        } catch (Throwable e) {
            listener.onEvent("deint:error", String.valueOf(e));
        }
    }
    private DefaultTrackSelector selector;
    private int retries = 0;
    private boolean wantVisible = true;
    private final List<Object[]> audio = new ArrayList<>();
    private final List<Object[]> text = new ArrayList<>();
    private String curUrl = "";
    private String curMime = null;
    private volatile String posInfo = "0|0|1";
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (player == null) return;
            long d = player.getDuration();
            posInfo = player.getCurrentPosition() + "|" + (d == C.TIME_UNSET ? 0 : d) + "|" + (player.isCurrentMediaItemLive() ? 1 : 0) + "|" + (player.getPlayWhenReady() ? 1 : 0);
            watchdog();
            updateSeekVis();
            ui.postDelayed(this, 1000);
        }
    };

    /* Deteção de bloqueio: a reproduzir (ou a carregar) mas sem avançar há 8 s -> recomeça sozinho. */
    /* desligado: o diário mostrou falsos positivos (religava a superfície a reproduzir bem e causava 5 s de paragem) */
    private static final boolean FRAME_WATCHDOG = false;
    private long bufSince = 0;
    private long wdPos = -1, wdFr = -1; private int wdStuck = 0, wdOk = 0, wdTries = 0, vStuck = 0, vTries = 0;
    /* v261: enquanto espera para tentar de novo depois de um erro de rede (ex.: 509) e nos 15 s seguintes, o vigia não mexe:
       o diário mostrou-o a contar a espera como «parado» e a religar a superfície logo a seguir (superfície 0x0 e mais paragens) */
    private long retryGraceUntil = 0;
    private void watchdog() {
        try {
            if (player == null || userPaused || !player.getPlayWhenReady() || !wantVisible) { wdStuck = 0; return; }
            if (android.os.SystemClock.uptimeMillis() < retryGraceUntil) { wdStuck = 0; wdPos = player.getCurrentPosition(); return; }
            if (vodUrl && !everReady) { wdStuck = 0; return; }   /* ainda a arrancar */
            int st = player.getPlaybackState();
            if (st == Player.STATE_ENDED || st == Player.STATE_IDLE && wdTries > 0) { wdStuck = 0; return; }
            long p = player.getCurrentPosition();
            if (p != wdPos) {
                wdPos = p; wdStuck = 0; if (++wdOk >= 5) wdTries = 0;
                /* o tempo avança (há som) mas nenhuma imagem nova há 3 s: a superfície do vídeo congelou */
                long fr = -1;
                try { androidx.media3.exoplayer.DecoderCounters dc = player.getVideoDecoderCounters(); if (dc != null) { dc.ensureUpdated(); fr = dc.renderedOutputBufferCount; } } catch (Throwable ignored) { }
                if (FRAME_WATCHDOG && fr >= 0 && st == Player.STATE_READY && fr == wdFr) {
                    if (++vStuck >= 3) {
                        vStuck = 0; vTries++;
                        if (vTries <= 2) {
                            log("watchdog: imagem parada, religa superfície");
                            if (hdrOn && hdrSv != null) { player.setVideoSurfaceView(null); player.setVideoSurfaceView(hdrSv); }
                            else if (ttv != null) { player.setVideoTextureView(null); player.setVideoTextureView(ttv); }
                        } else if (!curUrl.isEmpty()) {
                            vTries = 0;
                            MediaItem.Builder b = new MediaItem.Builder().setUri(curUrl);
                            if (curMime != null) b.setMimeType(curMime);
                            if (player.isCurrentMediaItemLive()) player.setMediaItem(b.build()); else player.setMediaItem(b.build(), Math.max(0, p - 1000));
                            player.prepare(); player.play();
                        }
                    }
                } else { vStuck = 0; if (fr != wdFr) vTries = 0; }
                wdFr = fr;
                return;
            }
            wdOk = 0;
            if (++wdStuck < (st == Player.STATE_BUFFERING ? (vodUrl ? 12 : 4) : 5)) return;   /* v282: filmes a carregar de servidores lentos: mais paciência */
            wdStuck = 0; wdTries++; log("watchdog: sem avanço, tentativa " + wdTries);
            if (wdTries == 1) {                       /* 1.ª vez: religa a superfície e retoma */
                /* v262: só religa quando há TextureView própria. Na TV a imagem vai para a superfície do PlayerView: setVideoTextureView(null)
                   tirava-a e nunca mais a repunha — ecrã preto só com som (visto no diário depois de um 509) */
                if (ttv != null && !hdrOn && !vodUrl) { player.setVideoTextureView(null); player.setVideoTextureView(ttv); }   /* v282: nos filmes não mexe na superfície (deixava o descodificador da TV preso) */
                if (player.isCurrentMediaItemLive()) player.seekToDefaultPosition(); else player.seekTo(Math.max(0, p));
                player.prepare(); player.play();
            } else if (wdTries == 2 && !curUrl.isEmpty()) {   /* 2.ª vez: recarrega o endereço */
                MediaItem.Builder b = new MediaItem.Builder().setUri(curUrl);
                if (curMime != null) b.setMimeType(curMime);
                boolean live = player.isCurrentMediaItemLive();
                if (live) player.setMediaItem(b.build()); else player.setMediaItem(b.build(), Math.max(0, p - 2000));
                player.prepare(); player.play();
            } else if (wdTries >= 3) {                /* 3.ª vez: avisa a página, que tenta de novo ou muda de leitor */
                wdTries = 0; listener.onEvent("error", "vídeo bloqueado");
            }
        } catch (Throwable ignored) { }
    }
    String pos() { return posInfo; }
    private volatile String tracksJson = "{\"audio\":[],\"text\":[]}";
    private final Runnable hideLabel = new Runnable() { @Override public void run() { if (label != null) label.setVisibility(View.GONE); } };

    NativePlayer(Activity act, FrameLayout root, Listener l) {
        this.act = act;
        this.root = root;
        this.listener = l;
        /* v281: quando a TV muda de modo (taxa de atualização), o som pode ficar desfasado da imagem: volta a acertá-los */
        try {
            final android.hardware.display.DisplayManager dm = (android.hardware.display.DisplayManager) act.getSystemService(android.content.Context.DISPLAY_SERVICE);
            final float[] lastHz = {act.getWindowManager().getDefaultDisplay().getRefreshRate()};
            dm.registerDisplayListener(dispL = new android.hardware.display.DisplayManager.DisplayListener() {
                @Override public void onDisplayAdded(int id) { }
                @Override public void onDisplayRemoved(int id) { }
                @Override public void onDisplayChanged(int id) {
                    try {
                        float hz = act.getWindowManager().getDefaultDisplay().getRefreshRate();
                        if (Math.abs(hz - lastHz[0]) < 0.5f) return;
                        log("modo do ecrã: " + Math.round(lastHz[0]) + " → " + Math.round(hz) + " Hz");
                        lastHz[0] = hz;
                        ui.removeCallbacks(avResync); ui.postDelayed(avResync, 1500);
                    } catch (Throwable ignored) { }
                }
            }, ui);
        } catch (Throwable ignored) { }
    }
    private android.hardware.display.DisplayManager.DisplayListener dispL;
    private boolean codecStuck = false;
    private int decInitFails = 0;
    private boolean pvToFull = false;
    /** Volta a acertar som e imagem: salta para o ponto atual (o leitor esvazia e realinha os dois). */
    final Runnable avResync = new Runnable() { @Override public void run() { avResyncNow(); } };
    private void avResyncNow() {
        try {
            if (player == null || userPaused || player.getPlaybackState() != Player.STATE_READY) return;
            log("ressincroniza som/imagem (salto para o ponto atual)");
            if (player.isCurrentMediaItemLive()) player.seekTo(Math.max(0, player.getCurrentPosition()));
            else player.seekTo(player.getCurrentPosition());
        } catch (Throwable ignored) { }
    }

    String tracks() { return tracksJson; }

    /** Aviso por cima do vídeo (episódio seguinte, saltar intro). Texto vazio esconde. */
    void hud(String t) {
        ensureViews();
        if (t == null || t.isEmpty()) { hud.setVisibility(View.GONE); return; }
        hud.setText(t);
        hud.setVisibility(View.VISIBLE);
    }

    /** Frames extra da vista múltipla: não pedem o foco de áudio (senão pausam os outros) e usam menos memória. */
    boolean shareAudio = false;

    void prepareViews() { ensureViews(); }

    void bringBoxToFront() { if (box != null) box.bringToFront(); }

    private void ensureViews() {
        if (box != null) return;
        box = new FrameLayout(act);
        box.setFocusable(false);
        box.setBackgroundColor(Color.BLACK);
        boolean tvDev = false;
        try { android.app.UiModeManager um = (android.app.UiModeManager) act.getSystemService(android.content.Context.UI_MODE_SERVICE); tvDev = um != null && um.getCurrentModeType() == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION; } catch (Throwable ignored) { }
        PlayerView pv = null;
        /* TV: por defeito também TextureView (como no telemóvel, onde 4 frames funcionam). Com várias SurfaceView, o frame 1 ficava preto com som. */
        texMode = !tvDev || act.getSharedPreferences("np", 0).getBoolean("tvTexture", false) || Boolean.TRUE.equals(texOverride);
        if (texMode) {
            /* superfície TextureView, que respeita zoom/corte/esticar dentro da área do vídeo */
            try { pv = (PlayerView) android.view.LayoutInflater.from(act).inflate(R.layout.player_texture, null); } catch (Throwable ignored) { pv = null; }
        }
        view = pv != null ? pv : new PlayerView(act);
        if (texMode && pv != null) {
            ttv = new android.view.TextureView(act);
            ttv.setOpaque(true);
            box.addView(ttv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER));
            hdrSv = new android.view.SurfaceView(act);
            hdrSv.setVisibility(View.GONE);
            box.addView(hdrSv, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT, Gravity.CENTER));
        }
        view.setClipChildren(false);   /* a escala (esticar/zoom) desenha para lá da área do vídeo ajustado */
        box.setClipChildren(true);
        view.setUseController(false);
        view.setFocusable(false);
        view.setFocusableInTouchMode(false);
        view.setDescendantFocusability(ViewGroup.FOCUS_BLOCK_DESCENDANTS);
        view.setResizeMode(AspectRatioFrameLayout.RESIZE_MODE_FIT);
        view.setShutterBackgroundColor(ttv != null ? Color.TRANSPARENT : Color.BLACK);
        box.addView(view, new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        label = new TextView(act);
        label.setTextColor(Color.WHITE);
        label.setTextSize(22f);
        label.setPadding(28, 14, 28, 14);
        label.setBackgroundColor(0x99000000);
        label.setVisibility(View.GONE);
        FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        lp.gravity = Gravity.TOP | Gravity.LEFT;
        lp.leftMargin = 24;
        lp.topMargin = 24;
        box.addView(label, lp);
        hud = new TextView(act);
        hud.setTextColor(Color.WHITE);
        hud.setTextSize(20f);
        hud.setPadding(28, 16, 28, 16);
        hud.setBackgroundColor(0xCC1A2B44);
        hud.setVisibility(View.GONE);
        FrameLayout.LayoutParams hp = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        hp.gravity = Gravity.BOTTOM | Gravity.RIGHT;
        hp.rightMargin = 32;
        hp.bottomMargin = 48;
        box.addView(hud, hp);
        view.addOnLayoutChangeListener((vv, l, t, r2, b2, ol, ot, or2, ob) -> { if (r2 - l != or2 - ol || b2 - t != ob - ot) view.post(this::applyScale); });
        box.addOnLayoutChangeListener((vv, l, t, r2, b2, ol, ot, or2, ob) -> { if (r2 - l != or2 - ol || b2 - t != ob - ot) view.post(this::applyScale); });
        buildCtl();
        FrameLayout.LayoutParams p = new FrameLayout.LayoutParams(10, 10);
        p.gravity = Gravity.TOP | Gravity.LEFT;
        box.setVisibility(View.INVISIBLE);
        root.addView(box, p);
    }

    private void ensurePlayer(String referer) {
        releasePlayer();
        boolean hasRef = referer != null && !referer.isEmpty();
        DefaultHttpDataSource.Factory http = new DefaultHttpDataSource.Factory()
                .setUserAgent(hasRef ? UA_BROWSER : UA)
                .setAllowCrossProtocolRedirects(true)
                .setConnectTimeoutMs(15000)
                .setReadTimeoutMs(25000);
        if (hasRef) {
            Map<String, String> h = new HashMap<>();
            h.put("Referer", referer);
            h.put("Origin", referer.replaceAll("^(https?://[^/]+).*$", "$1"));
            http.setDefaultRequestProperties(h);
        }
        DefaultExtractorsFactory ex = new DefaultExtractorsFactory()
                .setConstantBitrateSeekingEnabled(true)
                .setTsExtractorFlags(DefaultTsPayloadReaderFactory.FLAG_ALLOW_NON_IDR_KEYFRAMES
                        | DefaultTsPayloadReaderFactory.FLAG_DETECT_ACCESS_UNITS
                        | DefaultTsPayloadReaderFactory.FLAG_ENABLE_HDMV_DTS_AUDIO_STREAMS);
        /* v265: acerto manual do som (ms). O relógio do som é o que manda na imagem: atrasar o relógio atrasa a imagem. */
        DefaultRenderersFactory rf = new DefaultRenderersFactory(act) {
            @Override protected androidx.media3.exoplayer.audio.AudioSink buildAudioSink(android.content.Context ctx, boolean flt, boolean params) {
                androidx.media3.exoplayer.audio.AudioSink base = super.buildAudioSink(ctx, flt, params);
                if (base == null) return null;
                return new androidx.media3.exoplayer.audio.ForwardingAudioSink(base) {
                    @Override public void configure(androidx.media3.common.Format f, int size, int[] ch) throws androidx.media3.exoplayer.audio.AudioSink.ConfigurationException {
                        /* aqui chega o som já descodificado (PCM): o formato original vem do leitor, na thread da interface */
                        ui.post(() -> { try { androidx.media3.common.Format af = player != null ? player.getAudioFormat() : null; String m = af != null && af.sampleMimeType != null ? af.sampleMimeType : "";
                            avKind = (m.contains("ac3") || m.contains("ac4") || m.contains("dts") || m.contains("true-hd")) ? (audDec.toLowerCase().contains("ffmpeg") ? "dolbysw" : "dolby") : "pcm"; } catch (Throwable ignored) { } loadAv(); });
                        super.configure(f, size, ch);
                    }
                    @Override public long getCurrentPositionUs(boolean sourceEnded) {
                        long p = super.getCurrentPositionUs(sourceEnded);
                        if (p == androidx.media3.exoplayer.audio.AudioSink.CURRENT_POSITION_NOT_SET) return p;
                        return Math.max(0, p - avOffsetMs * 1000L);
                    }
                };
            }
        }
                .setExtensionRendererMode(DefaultRenderersFactory.EXTENSION_RENDERER_MODE_ON)
                .setEnableDecoderFallback(true)
                /* v269: som Dolby (AC-3 / E-AC-3) no telemóvel é descodificado pelo FFmpeg da app em vez do descodificador Dolby do
                   aparelho, que dessincronizava o som (~0,8 s nos Samsung). Na TV fica como está: se a TV/barra de som aceitar
                   Dolby, segue direto (passthrough); senão usa o descodificador da TV e, se não houver, o FFmpeg. */
                .setMediaCodecSelector((mime, secure, tunnel) -> {
                    java.util.List<androidx.media3.exoplayer.mediacodec.MediaCodecInfo> l = androidx.media3.exoplayer.mediacodec.MediaCodecSelector.DEFAULT.getDecoderInfos(mime, secure, tunnel);
                    if (dolbySw() && mime != null && (mime.equals(androidx.media3.common.MimeTypes.AUDIO_E_AC3) || mime.equals(androidx.media3.common.MimeTypes.AUDIO_AC3) || mime.equals(androidx.media3.common.MimeTypes.AUDIO_E_AC3_JOC)))
                        return java.util.Collections.emptyList();
                    return l;
                })
                .setAllowedVideoJoiningTimeMs(0);   /* arranque mais rápido: não espera pela junção do vídeo */
        selector = new DefaultTrackSelector(act);
        selector.setParameters(selector.buildUponParameters()
                /* 4K: sem limitar a qualidade ao tamanho do ecrã e sempre a melhor versão que o aparelho descodifica */
                .setForceHighestSupportedBitrate(true)
                .setAllowVideoMixedMimeTypeAdaptiveness(true)
                .setAllowVideoNonSeamlessAdaptiveness(true)
                .setExceedRendererCapabilitiesIfNecessary(true)
                .setMaxVideoSize(capW, capH)
                .setTunnelingEnabled(!shareAudio && !deint && isTvDev() && !texMode && act.getSharedPreferences("np", 0).getBoolean("tunnel", false))
                .setPreferredAudioLanguage("pt")
                .setPreferredTextLanguage("pt")
                .setSelectUndeterminedTextLanguage(false)
                .build());
        /* Buffers grandes (ficheiros 4K têm 25-80 Mbit/s): começa a ver depressa e aguenta quedas de rede; o limite em bytes evita falta de memória */
        DefaultLoadControl lc = new DefaultLoadControl.Builder()
                .setBufferDurationsMs(25000, 90000, liveGuess ? 1000 : 2000, liveGuess ? 3000 : 5000)   /* direto: arranca e recupera mais depressa */
                .setTargetBufferBytes((shareAudio ? 24 : 96) * 1024 * 1024)
                .setPrioritizeTimeOverSizeThresholds(false)
                .setBackBuffer(shareAudio ? 15000 : 120000, false)
                .build();
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(C.USAGE_MEDIA)
                .setContentType(C.AUDIO_CONTENT_TYPE_MOVIE)
                .build();
        player = new ExoPlayer.Builder(act, rf)
                .setMediaSourceFactory(new DefaultMediaSourceFactory(new TsFix.Factory(new DefaultDataSource.Factory(act, http), tsFix), ex))
                .setTrackSelector(selector)
                .setLoadControl(lc)
                .setAudioAttributes(aa, !shareAudio)
                .setWakeMode(C.WAKE_MODE_NETWORK)
                .build();
        applyDeint();
        player.addAnalyticsListener(new AnalyticsListener() {
            @Override public void onVideoDecoderInitialized(AnalyticsListener.EventTime t, String name, long a, long b) { decName = name == null ? "" : name; }
            @Override public void onAudioDecoderInitialized(AnalyticsListener.EventTime t, String name, long a, long b) { audDec = name == null ? "" : name; }
        });
        player.setSeekParameters(androidx.media3.exoplayer.SeekParameters.CLOSEST_SYNC);   /* saltos rápidos em ficheiros grandes */
        player.setVideoChangeFrameRateStrategy(C.VIDEO_CHANGE_FRAME_RATE_STRATEGY_ONLY_IF_SEAMLESS);
        player.addListener(new Player.Listener() {
            @Override
            public void onPlaybackStateChanged(int state) {
                if (state == Player.STATE_BUFFERING) { if (bufSince == 0) bufSince = System.currentTimeMillis(); } else bufSince = 0;
                log("estado=" + (state == Player.STATE_IDLE ? "IDLE" : state == Player.STATE_BUFFERING ? "BUFFERING" : state == Player.STATE_READY ? "READY" : "ENDED"));
                if (state == Player.STATE_READY) { if (retries > 0) retryGraceUntil = Math.max(retryGraceUntil, android.os.SystemClock.uptimeMillis() + 12000); retries = 0; everReady = true; listener.onEvent("ready", ""); }
                else if (state == Player.STATE_BUFFERING) listener.onEvent("buffering", "");
                else if (state == Player.STATE_ENDED) listener.onEvent("ended", "");
            }

            @Override
            public void onPlayWhenReadyChanged(boolean pw, int reason) { log("playWhenReady=" + pw + " motivo=" + reason + (reason == Player.PLAY_WHEN_READY_CHANGE_REASON_AUDIO_FOCUS_LOSS ? " (perdeu foco de áudio)" : "")); }

            @Override
            public void onIsPlayingChanged(boolean p) { log("a reproduzir=" + p); }

            @Override
            public void onRenderedFirstFrame() { gotFrame = true; log("primeiro frame"); logAv(); }

            @Override
            public void onSurfaceSizeChanged(int w, int h) { log("superfície " + w + "x" + h); }

            @Override
            public void onTracksChanged(Tracks t) { rebuildTracks(t); matchRefresh(); updateHdrSurface(); }

            @Override
            public void onVideoSizeChanged(androidx.media3.common.VideoSize v) { matchRefresh(); updateHdrSurface(); if (view != null) view.postDelayed(NativePlayer.this::applyAspect, 150); }

            @Override
            public void onPlayerError(PlaybackException e) {
                if (player == null) return;
                int httpCode = 0;
                try {   /* regista o motivo real: código do erro e, se houver, o código HTTP do servidor */
                    String http = "";
                    for (Throwable c = e; c != null; c = c.getCause()) {
                        if (c instanceof androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) { http = " HTTP " + ((androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) c).responseCode; httpCode = ((androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) c).responseCode;
                            try { android.net.Uri u0 = ((androidx.media3.datasource.HttpDataSource.InvalidResponseCodeException) c).dataSpec.uri; http += " (servidor " + u0.getHost() + (u0.getPort() > 0 ? ":" + u0.getPort() : "") + ")"; } catch (Throwable ignored2) { }
                            break; }
                        if (c.getCause() == c) break;
                    }
                    Throwable rc = e.getCause();
                    log("erro: " + e.getErrorCodeName() + http + (rc != null ? " · " + rc.getClass().getSimpleName() + (rc.getMessage() != null ? ": " + rc.getMessage().replaceAll("https?://\\S+", "…") : "") : ""));
                } catch (Throwable ignored) { }
                /* v282: o descodificador da TV ficou preso (não liberta em 0,5 s); depois disso nenhum vídeo abre: reinicia a app */
                try {
                    String em = String.valueOf(e.getCause() != null ? e.getCause().getMessage() : e.getMessage());
                    if (em.contains("release timed out") || em.contains("Detaching surface timed out")) { codecStuck = true; log("descodificador preso (" + em + ")"); }
                    if (e.errorCode == PlaybackException.ERROR_CODE_DECODER_INIT_FAILED) {
                        decInitFails++;
                        if (codecStuck || decInitFails >= 2) { log("descodificador indisponível: reinicia a app para o libertar"); listener.onEvent("restartapp", curUrl); return; }
                    }
                } catch (Throwable ignored) { }
                if (e.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                    player.seekToDefaultPosition();
                    player.prepare();
                    return;
                }
                if (e.errorCode == PlaybackException.ERROR_CODE_VIDEO_FRAME_PROCESSING_FAILED && !fxBroken) {
                    fxBroken = true;
                    try { player.setVideoEffects(new java.util.ArrayList<androidx.media3.common.Effect>()); } catch (Throwable ignored) { }
                    fxApplied = false; fxKey = "";
                    player.prepare(); player.play();
                    return;
                }
                boolean io = e.errorCode >= 2000 && e.errorCode < 3000;
                int maxRetries = liveGuess ? ((httpCode == 509 || httpCode == 429 || httpCode == 503 || httpCode == 458) ? 8 : 5) : 2;
                if (io && retries < maxRetries) {
                    retries++;
                    long dly = Math.min(8000L, 1000L << Math.min(4, retries - 1));   /* 1 s, 2 s, 4 s, 8 s… */
                    if (httpCode == 509 || httpCode == 429 || httpCode == 503 || httpCode == 458) {
                        /* o servidor está a limitar (509 = largura de banda / ligações): espera mais, para não insistir, e pede menos (720p) */
                        dly = Math.min(20000L, 5000L * retries);
                        if (!srvCap && capW == Integer.MAX_VALUE) { srvCap = true; srvCapUrl = curUrl; setMaxRes(1280, 720); log("servidor a limitar (HTTP " + httpCode + "): resolução limitada a 720p neste canal"); }
                    }
                    retryGraceUntil = android.os.SystemClock.uptimeMillis() + dly + 15000;
                    log("erro de rede, nova tentativa " + retries + "/" + maxRetries + " em " + dly + " ms");
                    try { listener.onEvent("note", (httpCode == 509 || httpCode == 429 || httpCode == 503 || httpCode == 458)
                            ? "O servidor limitou as ligações (" + httpCode + "). A tentar de novo em " + (dly / 1000) + " s…"
                            : "Sem ligação. A tentar de novo em " + (dly / 1000) + " s…"); } catch (Throwable ignored) { }
                    ui.postDelayed(new Runnable() { @Override public void run() { if (player != null) { player.prepare(); player.play(); } } }, dly);
                    return;
                }
                { Throwable c = e.getCause(); String cm = c != null ? (c.getClass().getSimpleName() + (c.getMessage() != null ? ": " + c.getMessage() : "")) : ""; listener.onEvent("error", e.getErrorCodeName() + (cm.isEmpty() ? "" : " (" + cm + ")")); }
            }
        });
        view.setPlayer(player);
        applySubStyle();
        if (ttv != null) {
            hdrOn = false;
            if (hdrSv != null) hdrSv.setVisibility(View.GONE);
            ttv.setVisibility(View.VISIBLE);
            player.setVideoTextureView(ttv);
            try { act.getWindow().setColorMode(android.content.pm.ActivityInfo.COLOR_MODE_DEFAULT); } catch (Throwable ignored) { }
        }
    }

    private void releasePlayer() {
        ui.removeCallbacksAndMessages(null);
        if (view != null) view.setPlayer(null);
        if (player != null) {
            try { player.release(); } catch (Exception ignored) { }
            player = null;
        }
        audio.clear();
        text.clear();
        tracksJson = "{\"audio\":[],\"text\":[]}";
    }

    private static final java.util.concurrent.ExecutorService WARM = java.util.concurrent.Executors.newSingleThreadExecutor();
    private static final java.util.HashMap<String, Long> WARMED = new java.util.HashMap<>();

    /** Aquece DNS/TLS/ligação do canal vizinho (zapping mais rápido): lê só o início da lista. */
    static void warm(final String url, final String referer) {
        if (url == null || !url.startsWith("http")) return;
        String l = url.toLowerCase();
        if (l.contains("/movie/") || l.contains("/series/")) return;
        synchronized (WARMED) {
            Long t = WARMED.get(url);
            if (t != null && System.currentTimeMillis() - t < 60000) return;
            if (WARMED.size() > 60) WARMED.clear();
            WARMED.put(url, System.currentTimeMillis());
        }
        try {
            WARM.execute(new Runnable() { @Override public void run() {
                java.net.HttpURLConnection c = null;
                try {
                    c = (java.net.HttpURLConnection) new java.net.URL(url).openConnection();
                    c.setConnectTimeout(4000); c.setReadTimeout(4000);
                    c.setRequestProperty("User-Agent", "Mozilla/5.0");
                    if (referer != null && !referer.isEmpty()) c.setRequestProperty("Referer", referer);
                    c.setRequestProperty("Range", "bytes=0-4095");
                    java.io.InputStream in = c.getInputStream();
                    byte[] b = new byte[2048]; int n = 0, tot = 0;
                    while (tot < 4096 && (n = in.read(b)) > 0) tot += n;
                    in.close();
                } catch (Throwable ignored) {
                } finally { try { if (c != null) c.disconnect(); } catch (Throwable ignored) { } }
            } });
        } catch (Throwable ignored) { }
    }

    void play(String url, String referer, String hint, String title, long startMs) {
        ensureViews();
        loadAv();
        final boolean fromPv = wasPv || previewMode;
        wasPv = false; previewMode = false;
        try { if (ctlAspect != null) ctlAspect.setVisibility(View.VISIBLE); } catch (Throwable ignored) { }
        /* da miniatura do Início para o ecrã total: o mesmo canal já está a dar, por isso reutiliza a ligação.
           Abrir uma segunda sessão do mesmo canal faz o servidor (1 ligação por conta) responder 509 ao fim de ~40 s. */
        if (fromPv && player != null && url != null && url.equals(curUrl) && startMs <= 0 && everReady && retries == 0
                && player.getPlaybackState() == Player.STATE_READY && pendingStop == null) {
            log("miniatura → ecrã: reutiliza a mesma ligação (sem abrir outra sessão)");
            pvToFull = true;
            try { player.setPlayWhenReady(true); player.setVolume(1f); } catch (Throwable ignored) { }
            userPaused = false;
            try { listener.onEvent("ready", ""); } catch (Throwable ignored) { }   /* esconde «A carregar…» e aplica o volume */
            return;
        }
        if (pendingStop != null) {
            ui.removeCallbacks(pendingStop); pendingStop = null;
            if (player != null && url != null && url.equals(curUrl) && startMs <= 0 && player.getPlaybackState() != Player.STATE_IDLE && player.getPlaybackState() != Player.STATE_ENDED) {
                log("mesmo canal: continua sem recarregar (pré-visualização)");
                try { player.setPlayWhenReady(true); } catch (Throwable ignored) { }
                return;
            }
            stop();
        }
        /* pedido repetido do mesmo canal em menos de 1,2 s (p.ex. página + ecrã nativo): ignora o segundo, evita recarregar e piscar */
        if (player != null && startMs <= 0 && url != null && url.equals(curUrl) && System.currentTimeMillis() - playStart < 1200 && !everReady && player.getPlaybackState() != Player.STATE_IDLE) {
            log("play() repetido ignorado");
            return;
        }
        if (srvCap && (url == null || !url.equals(srvCapUrl))) { srvCap = false; srvCapUrl = ""; setMaxRes(0, 0); }
        log("play() " + (url == null ? "" : url.replaceAll("^https?://[^/]+", "").replaceAll("/[^/]+/[^/]+/", "/…/")) + " hint=" + hint);
        retries = 0; gotFrame = false;
        userPaused = false; wdPos = -1; wdFr = -1; wdStuck = 0; wdOk = 0; wdTries = 0; vStuck = 0; vTries = 0;
        { String l0 = url == null ? "" : url.toLowerCase(); liveGuess = !l0.contains("/movie/") && !l0.contains("/series/") && (l0.contains("/live/") || l0.matches(".*\\.(m3u8|ts)(\\?.*)?$")); }
        userRewound = false;
        ensurePlayer(referer);
        ui.postDelayed(liveCheck, 10000);
        MediaItem.Builder b = new MediaItem.Builder().setUri(url);
        curUrl = url;
        everReady = false;
        playStart = System.currentTimeMillis();
        { String lu = url == null ? "" : url.toLowerCase(); vodUrl = lu.contains("/movie/") || lu.contains("/series/") || lu.matches(".*\\.(mkv|mp4|avi|mov|m4v)(\\?.*)?$"); }
        curMime = "hls".equals(hint) ? MimeTypes.APPLICATION_M3U8 : "dash".equals(hint) ? MimeTypes.APPLICATION_MPD : null;
        { String lu2 = url == null ? "" : url.toLowerCase(); tsFix.reset("hls".equals(hint) || lu2.matches(".*\\.m3u8?(\\?.*)?$")); }
        if (curMime != null) b.setMimeType(curMime);
        if (startMs > 0) player.setMediaItem(b.build(), startMs); else player.setMediaItem(b.build());
        player.setPlayWhenReady(true);
        player.prepare();
        posInfo = "0|0|1";
        ui.postDelayed(ticker, 1000);
        /* começa escondido: a página envia logo a posição certa (evita ficar no sítio antigo, p.ex. o da pré-visualização do Início) */
        if (full) { wantVisible = true; lastVis = true; box.setVisibility(View.VISIBLE); }   /* ecrã total: ninguém volta a enviar a posição, por isso não esconde */
        else { wantVisible = false; lastVis = false; box.setVisibility(View.INVISIBLE); }
        if (title != null && !title.isEmpty()) {
            label.setText(title);
            label.setVisibility(View.VISIBLE);
            ui.postDelayed(hideLabel, 2800);
        }
    }

    /** Volta ao ponto em direto (depois de recuar/pausar). */
    void goLive() {
        try { if (player != null) { player.seekToDefaultPosition(); player.setPlayWhenReady(true); userPaused = false; userRewound = false; } } catch (Throwable ignored) { }
    }

    /** Há um vídeo a dar (usado para entrar em janela flutuante ao sair da app). */
    boolean isActive() {
        try { return player != null && player.getPlayWhenReady() && player.getPlaybackState() != androidx.media3.common.Player.STATE_IDLE && player.getPlaybackState() != androidx.media3.common.Player.STATE_ENDED; } catch (Throwable e) { return false; }
    }

    void volume(float v) {
        try { if (player != null) player.setVolume(Math.max(0f, Math.min(1f, v))); } catch (Throwable e) { }
    }

    void stop() {
        if (pendingStop != null) { ui.removeCallbacks(pendingStop); pendingStop = null; }
        releasePlayer();
        setDisplayMode(0);
        if (box != null) box.setVisibility(View.GONE);
    }

    /* Ao sair do ecrã do canal para o Início: em vez de parar logo, mantém o canal a dar (sem som, fora da vista) uns
       segundos. Se a pré-visualização do Início pedir o mesmo canal, continua sem recarregar (transição imediata). */
    private volatile Runnable pendingStop = null;
    private int[] pageRect = null;   // última janela visível pedida pela página (a miniatura do Início)
    void notePageRect(int x, int y, int w, int h) { if (w > 20 && h > 20) pageRect = new int[]{x, y, w, h}; }
    boolean softStopping() { return pendingStop != null; }
    void stopSoon(long ms) { stopSoon(ms, false); }
    /** restore=true (veio do Início): o canal volta logo, sem som, à janela da miniatura em vez de ficar escondido; a página só confirma o mesmo canal. */
    void stopSoon(long ms, boolean restore) {
        if (player == null) { stop(); return; }
        try { setFull(false); } catch (Throwable ignored) { }
        try { player.setVolume(0f); } catch (Throwable ignored) { }
        if (restore && pageRect != null) {
            lastRect = pageRect.clone(); lastVis = true; wantVisible = true;
            try { applyRect(); if (box != null) box.setVisibility(View.VISIBLE); } catch (Throwable ignored) { }
            log("volta ao Início: canal na janela da miniatura " + pageRect[0] + "," + pageRect[1] + " " + pageRect[2] + "x" + pageRect[3]);
        } else { lastRect = new int[]{0, 0, 1, 1}; try { applyRect(); } catch (Throwable ignored) { } }
        if (pendingStop != null) ui.removeCallbacks(pendingStop);
        pendingStop = () -> { pendingStop = null; log("pré-visualização não pediu o canal: pára"); stop(); if (restore) { try { listener.onEvent("pv:lost", ""); } catch (Throwable ignored) { } } };
        ui.postDelayed(pendingStop, ms);
        log("canal mantido " + ms + " ms para a pré-visualização");
    }

    private int[] lastRect = null;

    /** Em ecrã total o leitor ocupa o ecrã inteiro (medido pelo Android, não pela página). */
    private void applyRect() {
        if (box == null) return;
        FrameLayout.LayoutParams p;
        if (full) {
            p = new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT);
        } else if (lastRect != null) {
            p = new FrameLayout.LayoutParams(Math.max(lastRect[2], 1), Math.max(lastRect[3], 1));
            p.gravity = Gravity.TOP | Gravity.LEFT;
            p.leftMargin = lastRect[0];
            p.topMargin = lastRect[1];
        } else return;
        box.setLayoutParams(p);
    }

    /* diário de eventos do leitor (para diagnosticar paragens): mostrado em Definições › Diagnóstico do vídeo */
    private final java.util.ArrayDeque<String> dbg = new java.util.ArrayDeque<>();
    void log(String m) {
        synchronized (dbg) {
            dbg.addLast(new java.text.SimpleDateFormat("HH:mm:ss.SSS", java.util.Locale.US).format(new java.util.Date()) + " " + m);
            while (dbg.size() > 160) dbg.removeFirst();
        }
    }
    String dbgDump() { synchronized (dbg) { return android.text.TextUtils.join("\n", dbg); } }
    /* 0,6 s depois de a janela do vídeo deixar de mudar: se o leitor ficou a carregar/parado (superfície presa), religa-a; volta a verificar 2,5 s depois */
    private int arTries = 0;
    private final Runnable afterResize = new Runnable() { @Override public void run() {
        if (player == null || userPaused) return;
        try {
            int st = player.getPlaybackState();
            boolean buffering = st == Player.STATE_BUFFERING;
            if (buffering && bufSince != 0 && System.currentTimeMillis() - bufSince < (everReady ? 1200 : 2500)) { ui.postDelayed(this, 600); return; }   /* carregar no início é normal: dá-lhe 2,5 s */
            /* a arrancar: só é «preso» se passaram 8 s desde o play() (arrancar demora 2-3 s e causava religações desnecessárias) */
            if (!everReady && System.currentTimeMillis() - playStart < 8000) { ui.postDelayed(this, 1500); return; }
            boolean bad = player.getPlayWhenReady() && buffering && (everReady || !vodUrl);
            if (bad && arTries < 3) {
                arTries++; log("após redimensionar: leitor preso (estado=" + st + "), tentativa #" + arTries);
                if (hdrOn && hdrSv != null) { player.setVideoSurfaceView(null); player.setVideoSurfaceView(hdrSv); }
                else if (ttv != null) { player.setVideoTextureView(null); player.setVideoTextureView(ttv); }
                if (arTries >= 2) {   /* só religar a superfície não chegou (visto no diário): recria o descodificador e volta ao direto */
                    if (arTries == 2 || curUrl.isEmpty()) { player.seekToDefaultPosition(); player.prepare(); player.play(); }
                    else {
                        MediaItem.Builder b = new MediaItem.Builder().setUri(curUrl);
                        if (curMime != null) b.setMimeType(curMime);
                        if (player.isCurrentMediaItemLive()) player.setMediaItem(b.build()); else player.setMediaItem(b.build(), Math.max(0, player.getCurrentPosition() - 1000));
                        player.prepare(); player.play();
                    }
                }
                ui.postDelayed(this, arTries >= 2 ? 3000 : 1500);
            } else if (!bad) arTries = 0;
        } catch (Throwable ignored) { }
    } };
    private boolean lastVis = true;
    private long playStart = 0;
    private boolean everReady = false, vodUrl = false;   /* filmes/séries grandes demoram a arrancar: não os «recuperar» antes de terem começado */
    /** Religa a superfície do vídeo (a TextureView perde-a quando a caixa fica invisível e volta a aparecer: imagem parada com som). */
    private long fcFrames = -1; private int fcTries = 0;
    private final Runnable fullCheck = new Runnable() { @Override public void run() {
        try {
            if (player == null || !full) return;
            androidx.media3.exoplayer.DecoderCounters dc = player.getVideoDecoderCounters();
            long n = -1; if (dc != null) { dc.ensureUpdated(); n = dc.renderedOutputBufferCount; }
            boolean ready = player.getPlaybackState() == Player.STATE_READY && player.getPlayWhenReady();
            if (fcFrames < 0) { fcFrames = n; ui.postDelayed(this, 700); return; }
            boolean moving = n > fcFrames;
            fcFrames = -1;
            if (!ready) { if (fcTries++ < 4) ui.postDelayed(this, 1000); else fcTries = 0; return; }
            fcTries = 0;
            if (moving && view != null && view.getVideoSurfaceView() != null && view.getVideoSurfaceView().getVisibility() == View.VISIBLE) { log("ecrã total (da miniatura): imagem a aparecer"); return; }
            log("ecrã total (da miniatura): sem imagem visível — religa a imagem ao ecrã");
            rebindView();
        } catch (Throwable ignored) { }
    } };
    /** Volta a ligar o leitor à vista (TV: superfície do PlayerView; telemóvel: TextureView). */
    void rebindView() {
        try {
            if (player == null) return;
            if (ttv != null || (hdrOn && hdrSv != null)) { reattach.run(); return; }
            if (view != null) {
                View sv = view.getVideoSurfaceView();
                if (sv != null) { sv.setVisibility(View.GONE); sv.setVisibility(View.VISIBLE); }
                view.setPlayer(null); view.setPlayer(player);
                if (box != null) { box.setVisibility(View.VISIBLE); box.bringToFront(); }
            }
        } catch (Throwable ignored) { }
    }
    private final Runnable reattach = () -> {
        if (player == null) return;
        try {
            if (hdrOn && hdrSv != null) { player.setVideoSurfaceView(null); player.setVideoSurfaceView(hdrSv); }
            else if (ttv != null) { player.setVideoTextureView(null); player.setVideoTextureView(ttv); }
        } catch (Throwable ignored) { }
    };

    void rect(int x, int y, int w, int h, boolean visible) {
        if (box == null) return;
        if (full && !visible) { log("rect escondido ignorado (ecrã total)"); return; }   /* a página escondia o vídeo ao mudar de canal em ecrã total */
        if (lastRect != null && lastRect[0] == x && lastRect[1] == y && lastRect[2] == w && lastRect[3] == h && lastVis == visible) return;   /* nada mudou: não mexe na vista */
        log("rect " + x + "," + y + " " + w + "x" + h + (visible ? " visível" : " escondido"));
        if (visible) { ui.removeCallbacks(afterResize); ui.postDelayed(afterResize, 600); }
        lastVis = visible;
        wantVisible = visible;
        lastRect = new int[]{x, y, w, h};
        applyRect();
        if (player != null) box.setVisibility(visible ? View.VISIBLE : View.INVISIBLE);
    }

    /** Legendas externas (SRT/VTT em texto): recria o item mantendo a posição. */
    void subtitle(String text, String label, String lang) {
        if (player == null || curUrl.isEmpty() || text == null || text.isEmpty()) return;
        try {
            boolean vtt = text.trim().startsWith("WEBVTT");
            File f = new File(act.getCacheDir(), vtt ? "sub.vtt" : "sub.srt");
            FileOutputStream o = new FileOutputStream(f);
            o.write(text.getBytes("UTF-8"));
            o.close();
            MediaItem.SubtitleConfiguration sc = new MediaItem.SubtitleConfiguration.Builder(Uri.fromFile(f))
                    .setMimeType(vtt ? MimeTypes.TEXT_VTT : MimeTypes.APPLICATION_SUBRIP)
                    .setLanguage(lang == null || lang.isEmpty() ? "pt" : lang)
                    .setLabel(label == null ? "Legendas" : label)
                    .setSelectionFlags(C.SELECTION_FLAG_DEFAULT | C.SELECTION_FLAG_FORCED)
                    .build();
            MediaItem.Builder b = new MediaItem.Builder().setUri(curUrl).setSubtitleConfigurations(java.util.Collections.singletonList(sc));
            if (curMime != null) b.setMimeType(curMime);
            long pos = player.isCurrentMediaItemLive() ? C.TIME_UNSET : player.getCurrentPosition();
            boolean play = player.getPlayWhenReady();
            player.setTrackSelectionParameters(player.getTrackSelectionParameters().buildUpon().setTrackTypeDisabled(C.TRACK_TYPE_TEXT, false).build());
            if (pos != C.TIME_UNSET) player.setMediaItem(b.build(), pos); else player.setMediaItem(b.build());
            player.prepare();
            player.setPlayWhenReady(play);
        } catch (Exception e) {
            listener.onEvent("suberr", String.valueOf(e));
        }
    }

    void toggle() {
        if (player == null) return;
        if (player.getPlayWhenReady()) { userPaused = true; if (player.isCurrentMediaItemLive()) userRewound = true; player.pause(); } else { userPaused = false; player.play(); }
    }

    private boolean userPaused = false;
    /** Depois de rodar o ecrã / mudar o tamanho: volta a ligar a superfície de vídeo e retoma a reprodução (a menos que tenhas pausado). */
    private final Runnable recover = () -> {
        if (player == null) return;
        try {
            if (ttv != null && !hdrOn) { player.setVideoTextureView(null); player.setVideoTextureView(ttv); }
            if (!userPaused) {
                if (player.getPlaybackState() == Player.STATE_IDLE) player.prepare();
                if (!player.getPlayWhenReady()) player.play();
            }
        } catch (Throwable ignored) { }
    };

    /** Ao voltar à app: retoma, a menos que tenhas pausado tu. */
    void resumeAfterBackground() {
        try { if (player != null && !userPaused && !player.getPlayWhenReady()) { log("app voltou ao ecrã: retoma"); player.play(); } } catch (Throwable ignored) { }
    }

    void pause() { log("pause() chamado (app em segundo plano)"); if (player != null) player.pause(); }

    /** v289: mostra a barra de progresso uns segundos (comando da TV). */
    void showSeekBar() {
        if (seekWrap == null || !seekable() || !full) return;
        seekTempUntil = System.currentTimeMillis() + 3500;
        seekWrap.setVisibility(View.VISIBLE);
        updateSeekPos();
        if (box != null) { box.removeCallbacks(hideCtl); box.postDelayed(hideCtl, 3500); }
    }
    boolean canSeek() { return seekable(); }
    private volatile long lastSeekAt = 0;
    void seek(long deltaMs) {
        lastSeekAt = System.currentTimeMillis();
        if (player == null || (player.isCurrentMediaItemLive() && !player.isCurrentMediaItemSeekable())) return;   /* direto HLS com janela: permite recuar (timeshift) */
        if (player.isCurrentMediaItemLive() && deltaMs < 0) userRewound = true;   /* recuaste de propósito: não saltar sozinho para o direto */
        long to = Math.max(0, player.getCurrentPosition() + deltaMs);
        long d = player.getDuration();
        if (d != C.TIME_UNSET && to > d) to = d;
        player.seekTo(to);
        if (seekWrap != null && full) {   /* no comando (TV) mostra a barra um instante (só em ecrã total) */
            seekTempUntil = System.currentTimeMillis() + 3500;
            seekWrap.setVisibility(View.VISIBLE);
            seekBar.setProgress((int) (to * 1000L / Math.max(1, d)));
            seekPos.setText(fmtT(to));
            seekDur.setText(remain(to, d));
            if (box != null) { box.removeCallbacks(hideCtl); box.postDelayed(hideCtl, 3500); }
        }
    }

    void pick(String type, int idx) {
        if (player == null) return;
        boolean isText = "text".equals(type);
        List<Object[]> list = isText ? text : audio;
        int ttype = isText ? C.TRACK_TYPE_TEXT : C.TRACK_TYPE_AUDIO;
        /* filmes e episódios: trocar a faixa não pode mexer na posição */
        final boolean keepPos = !player.isCurrentMediaItemLive() && player.getPlaybackState() != Player.STATE_IDLE && player.getPlaybackState() != Player.STATE_ENDED;
        final long keep = keepPos ? player.getCurrentPosition() : -1, t0 = System.currentTimeMillis();
        final String url0 = curUrl;
        TrackSelectionParameters.Builder b = player.getTrackSelectionParameters().buildUpon();
        if (idx < 0 || idx >= list.size()) {
            if (isText) b.setTrackTypeDisabled(ttype, true);
        } else {
            Object[] t = list.get(idx);
            Tracks.Group g = (Tracks.Group) t[0];
            int i = (Integer) t[1];
            b.setTrackTypeDisabled(ttype, false);
            b.setOverrideForType(new TrackSelectionOverride(g.getMediaTrackGroup(), i));
        }
        player.setTrackSelectionParameters(b.build());
        if (keep > 3000) {
            for (long d : new long[]{600, 1500, 3000, 6000}) {
                ui.postDelayed(() -> {
                    try {
                        if (player == null || lastSeekAt > t0 || !url0.equals(curUrl)) return;
                        long p = player.getCurrentPosition();
                        if (p < keep - 4000) { log("faixa trocada: a posição voltou atrás (" + p / 1000 + " s), repõe " + keep / 1000 + " s"); player.seekTo(keep); }
                    } catch (Throwable ignored) { }
                }, d);
            }
        }
    }

    private static String q(String s) {
        return "\"" + s.replace("\\", "\\\\").replace("\"", "'").replace("\n", " ") + "\"";
    }

    private static String name(Format f, int n) {
        StringBuilder s = new StringBuilder();
        if (f.label != null && !f.label.isEmpty()) s.append(f.label);
        if (f.language != null && !"und".equals(f.language)) {
            if (s.length() > 0) s.append(" · ");
            s.append(f.language);
        }
        if (f.channelCount > 2) s.append(" · ").append(f.channelCount == 6 ? "5.1" : f.channelCount == 8 ? "7.1" : f.channelCount + "ch");
        String m = f.sampleMimeType;
        if (m != null) {
            String c = MimeTypes.AUDIO_AC3.equals(m) ? "AC-3" : MimeTypes.AUDIO_E_AC3.equals(m) || MimeTypes.AUDIO_E_AC3_JOC.equals(m) ? "E-AC-3"
                    : MimeTypes.AUDIO_AAC.equals(m) ? "AAC" : m.startsWith("audio/") ? m.substring(6).toUpperCase() : "";
            if (!c.isEmpty()) s.append(" · ").append(c);
        }
        return s.length() == 0 ? "Faixa " + (n + 1) : s.toString();
    }

    private void rebuildTracks(Tracks t) {
        audio.clear();
        text.clear();
        StringBuilder a = new StringBuilder(), x = new StringBuilder();
        boolean anyAudio = false, okAudio = false;
        for (Tracks.Group g : t.getGroups()) {
            int type = g.getType();
            if (type == C.TRACK_TYPE_AUDIO) {
                anyAudio = true;
                if (g.isSelected() && g.isSupported()) okAudio = true;
            }
            if (type != C.TRACK_TYPE_AUDIO && type != C.TRACK_TYPE_TEXT) continue;
            for (int i = 0; i < g.length; i++) {
                if (!g.isTrackSupported(i)) continue;
                boolean isAudio = type == C.TRACK_TYPE_AUDIO;
                List<Object[]> list = isAudio ? audio : text;
                StringBuilder sb = isAudio ? a : x;
                if (sb.length() > 0) sb.append(',');
                sb.append("{\"i\":").append(list.size()).append(",\"name\":").append(q(name(g.getTrackFormat(i), list.size())))
                        .append(",\"on\":").append(g.isTrackSelected(i)).append('}');
                list.add(new Object[]{g, i});
            }
        }
        tracksJson = "{\"audio\":[" + a + "],\"text\":[" + x + "]}";
        if (anyAudio && !okAudio) listener.onEvent("noaudio", "");
    }

    void release() {
        try { if (dispL != null) ((android.hardware.display.DisplayManager) act.getSystemService(android.content.Context.DISPLAY_SERVICE)).unregisterDisplayListener(dispL); dispL = null; } catch (Throwable ignored) { }
        releasePlayer();
        if (box != null) { try { root.removeView(box); } catch (Exception ignored) { } box = null; view = null; label = null; }
    }
}
