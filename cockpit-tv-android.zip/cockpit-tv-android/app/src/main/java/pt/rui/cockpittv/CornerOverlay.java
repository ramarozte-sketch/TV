package pt.rui.cockpittv;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;

/** v471 (TV): cantos arredondados da janela do vídeo desenhados POR CIMA dela (a SurfaceView não é recortada — o recorte derrubava a app na Bravia).
 *  Cada canto é pintado com a cor do fundo mesmo ao lado, lida do próprio ecrã (já com tudo composto por baixo). */
final class CornerOverlay extends View {
    private final Paint pt = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final int[] col = new int[4];
    private int r;

    CornerOverlay(Context c) {
        super(c);
        setClickable(false); setFocusable(false);
        setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO);
        setVisibility(View.GONE);
    }

    /** Cor composta de `src` no ponto (x,y) de `root` (0 se falhar). */
    private static int sample(View src, FrameLayout root, int x, int y, int base) {
        try {
            int[] a = new int[2], b = new int[2];
            src.getLocationInWindow(a); root.getLocationInWindow(b);
            int sx = x - (a[0] - b[0]), sy = y - (a[1] - b[1]);
            if (sx < 0 || sy < 0 || sx >= src.getWidth() || sy >= src.getHeight()) return 0;
            Bitmap bm = Bitmap.createBitmap(1, 1, Bitmap.Config.ARGB_8888);
            bm.eraseColor(base);
            Canvas cv = new Canvas(bm);
            cv.translate(-sx, -sy);
            src.draw(cv);
            int c = bm.getPixel(0, 0); bm.recycle();
            return c | 0xFF000000;
        } catch (Throwable e) { return 0; }
    }

    /** Mostra os cantos sobre o retângulo (x,y,w,h) de `root`; `src` é a vista cujo fundo deve ser copiado; `base` a cor por baixo de `src`. */
    void show(FrameLayout root, View src, int x, int y, int w, int h, int radius, int base) {
        try {
            if (w < 2 * radius || h < 2 * radius || radius <= 0) { hide(); return; }
            r = radius;
            int o = Math.max(2, radius / 4);
            int[] c = { sample(src, root, x - o, y - o, base), sample(src, root, x + w + o, y - o, base),
                        sample(src, root, x + w + o, y + h + o, base), sample(src, root, x - o, y + h + o, base) };
            boolean any = false;
            for (int i = 0; i < 4; i++) { col[i] = c[i]; if (c[i] != 0) any = true; }
            if (!any) { hide(); return; }
            for (int i = 0; i < 4; i++) if (col[i] == 0) col[i] = col[0] != 0 ? col[0] : (col[1] != 0 ? col[1] : col[2]);
            if (getParent() != root) {
                if (getParent() instanceof android.view.ViewGroup) ((android.view.ViewGroup) getParent()).removeView(this);
                root.addView(this, new FrameLayout.LayoutParams(w, h));
            }
            FrameLayout.LayoutParams lp = new FrameLayout.LayoutParams(w, h);
            lp.gravity = Gravity.TOP | Gravity.LEFT; lp.leftMargin = x; lp.topMargin = y;
            setLayoutParams(lp);
            setVisibility(View.VISIBLE); bringToFront(); invalidate();
        } catch (Throwable ignored) { }
    }

    void hide() { try { setVisibility(View.GONE); } catch (Throwable ignored) { } }
    void raise() { try { if (getVisibility() == View.VISIBLE) bringToFront(); } catch (Throwable ignored) { } }

    @Override protected void onDraw(Canvas cv) {
        int w = getWidth(), h = getHeight();
        if (r <= 0 || w < 2 * r || h < 2 * r) return;
        Path sq = new Path(), q = new Path();
        for (int i = 0; i < 4; i++) {
            boolean right = i == 1 || i == 2, bottom = i >= 2;
            float x = right ? w - r : 0, y = bottom ? h - r : 0;
            sq.reset(); sq.addRect(x, y, x + r, y + r, Path.Direction.CW);
            q.reset(); q.addCircle(right ? w - r : r, bottom ? h - r : r, r, Path.Direction.CW);
            sq.op(q, Path.Op.DIFFERENCE);
            pt.setColor(col[i]);
            cv.drawPath(sq, pt);
        }
    }
}
