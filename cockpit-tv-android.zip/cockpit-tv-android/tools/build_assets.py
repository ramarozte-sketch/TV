#!/usr/bin/env python3
"""Gera app/src/main/assets/index.html (só IPTV) a partir do index.html do Cockpit.
Uso: python3 tools/build_assets.py [caminho/para/cockpit/index.html]"""
import sys, os
src = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), "..", "..", "cockpit", "index.html")
out = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "index.html")
h = open(src, encoding="utf-8").read()

def rep(old, new, count=1):
    global h
    if h.count(old) != count:
        sys.exit("Não encontrei (ou há repetições) de: " + old[:70])
    h = h.replace(old, new)

rep("<head>", '<head>\n<script>window.ANDROID = (typeof Android !== "undefined");</script>')
rep("<title>Cockpit", "<title>Cockpit TV")
rep('id="bootLogo">COCKPIT<', 'id="bootLogo">COCKPIT TV<')
rep("function px(url, ref, ua){\n  if(!url) return url;", "function px(url, ref, ua){\n  if(!url || window.ANDROID) return url;")
rep("function px2(url, ref, ua){\n  if(!url || !cfg.proxy2 || !cfg.proxy) return url;", "function px2(url, ref, ua){\n  if(!url || window.ANDROID || !cfg.proxy2 || !cfg.proxy) return url;")
rep("const HASPX = () => !!(PHONE || cfg.proxy2 || cfg.proxy);", "const HASPX = () => !window.ANDROID && !!(PHONE || cfg.proxy2 || cfg.proxy);")
rep('const PAGE_HTTP = location.protocol === "http:" && !PHONE;', 'const PAGE_HTTP = (location.protocol === "http:" && !PHONE) || !!window.ANDROID;')
rep('let mirrorOn = LS.get("mirror", false);', 'let mirrorOn = LS.get("mirror", false) && !window.ANDROID;')
rep('if(window.top !== window || location.protocol==="file:") return',
    'if(window.ANDROID) return "Não consegui ligar ao servidor (" + e.message + "). Confirma o endereço, o utilizador e a palavra-passe e a ligação à internet.";\n  if(window.top !== window || location.protocol==="file:") return')
rep("function show(view){\n", 'function show(view){\n  if(window.ANDROID && !["settings","tv","tvhome"].includes(view)) view = "tvhome";\n')
rep("applyPassenger(); applyLayout();", 'if(window.ANDROID){ cfg.layout = "classic"; cfg.passenger = false; }\napplyPassenger(); applyLayout();')
rep('\nif(passengerImport()) show("tv");', '\nif(window.ANDROID) show("tvhome");\nelse if(passengerImport()) show("tv");')

CSS = """
/* ===== Cockpit TV (Android) ===== */
body.android .rail,body.android .tsonly,body.android #tsPanel,body.android #chipCar,body.android #chipNet,body.android #lockNow,body.android #teslaFs,body.android #heard,body.android #micBtn{display:none!important}
body.android .app{grid-template-columns:1fr!important;grid-template-rows:54px 1fr!important}
body.android .top{grid-column:1!important;grid-row:1!important;padding:0 14px;gap:10px}
body.android main{grid-column:1!important;grid-row:2!important}
body.android .app.cinema{grid-template-rows:54px 1fr!important}
body.android .clock{font-size:22px}
body.android :focus-visible{outline:4px solid var(--accent)!important;outline-offset:3px;box-shadow:0 0 0 8px color-mix(in srgb,var(--accent) 30%,transparent)}
body.android .item:focus-visible{background:var(--panel-2)}
body.android.tv .app{padding:14px 22px 0;box-sizing:border-box}
body.android.tv .btn,body.android.tv .tab{min-height:46px;padding-block:6px}
body.android.tv .item{min-height:52px}
body.android.tv{font-size:16px}
body.android #btnFull,body.android #btnMirror{display:none!important}
/* ===== Android TV: visual moderno ===== */
body.android{background:radial-gradient(1100px 520px at 85% -8%,color-mix(in srgb,var(--accent) 20%,transparent),transparent),linear-gradient(180deg,#0a101c,#04070d)!important}
body.android .top{background:transparent!important;border:0!important;box-shadow:none!important;height:72px;padding:0 28px;gap:18px}
body.android .top .btn[data-v],body.android #atvHome,body.android #chipDrive,body.android #chipCar,body.android #chipNet{display:none!important}
body.android .clock{font-size:26px;font-weight:700;letter-spacing:.02em}
.thNav{display:flex;gap:8px;margin-left:18px}
.thTab{display:inline-flex;align-items:center;gap:8px;min-height:50px;padding:6px 22px;border:0;border-radius:999px;background:transparent;color:inherit;font:600 18px/1 inherit;opacity:.78}
.thTab span{font-size:20px}
.thTab[aria-current="page"]{background:var(--accent);color:var(--accent-ink);opacity:1}
body.android .thTab:focus-visible{outline:3px solid #fff!important;outline-offset:2px;box-shadow:none;opacity:1}
#v-tvhome{padding:4px 28px 40px;box-sizing:border-box}
.thKinds{display:flex;gap:12px;margin:6px 0 4px}
.thKind{min-width:150px}
.thKind[aria-pressed=true]{background:#7cc4ff;color:#06101f;border-color:#7cc4ff}
.thHero{display:flex;align-items:center;gap:30px;padding:26px 32px;margin:2px 0 14px;border-radius:26px;min-height:210px;background:linear-gradient(120deg,color-mix(in srgb,var(--accent) 38%,#0d1526),#0d1526 72%);box-shadow:0 18px 50px #0007}
.thHeroArt{flex:0 0 250px;aspect-ratio:16/9;border-radius:18px;background:#0b1220cc;display:flex;align-items:center;justify-content:center;overflow:hidden}
.thHeroArt img{max-width:70%;max-height:70%;object-fit:contain}
.thHeroArt b{font-size:44px;opacity:.6}
.thHeroTx{flex:1;min-width:0;display:flex;flex-direction:column;gap:8px}
.thHeroTx small{font-size:15px;letter-spacing:.14em;text-transform:uppercase;opacity:.7}
.thHeroTx h1{margin:0;font-size:38px;line-height:1.1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.thHeroTx p{margin:0;font-size:19px;opacity:.85;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.thHeroBt{display:flex;gap:12px;margin-top:8px;flex-wrap:wrap}
.thBtn{min-height:54px;padding:8px 26px;border:0;border-radius:14px;background:#ffffff1f;color:inherit;font:600 19px/1 inherit}
.thBtn.pri{background:var(--accent);color:var(--accent-ink)}
body.android .thBtn:focus-visible{outline:3px solid #fff!important;outline-offset:3px;box-shadow:none;transform:scale(1.04)}
.thRow h2{margin:18px 4px 2px;font-size:24px;font-weight:700;letter-spacing:.01em;text-transform:none}
@media (max-height:800px){.thHero{min-height:0;padding:14px 24px;gap:20px;margin-bottom:6px}.thHeroArt{flex-basis:170px}.thHeroTx h1{font-size:28px}.thHeroTx p{font-size:16px}.thHeroTx small{font-size:12px}.thHeroBt{margin-top:2px}.thBtn{min-height:44px;padding:6px 20px;font-size:17px}.thKind{min-width:120px}.thRow h2{margin-top:10px;font-size:21px}}
.thScroll{display:flex;gap:18px;overflow-x:auto;padding:12px 10px 26px;scrollbar-width:none;scroll-padding:0 40px}
.thScroll::-webkit-scrollbar{display:none}
.thCard{flex:0 0 244px;border:0;border-radius:18px;background:var(--panel,#121b2e);color:inherit;padding:0;text-align:left;overflow:hidden;transition:transform .14s,box-shadow .14s;box-shadow:0 6px 18px #0006}
.thCard.sm{flex-basis:200px}
body.android .thCard:focus-visible{outline:none!important;transform:scale(1.08);box-shadow:0 0 0 4px var(--accent),0 20px 44px #000b;position:relative;z-index:3}
.thArt{display:flex;align-items:center;justify-content:center;aspect-ratio:16/9;background:linear-gradient(135deg,#1d2a47,#0d1424);position:relative}
.thArt img{max-width:60%;max-height:62%;object-fit:contain}
.thArt img+.thInit{display:none}
.thInit{font-size:34px;font-weight:800;opacity:.45;letter-spacing:.04em}
.thMeta{display:block;padding:10px 14px 13px}
.thMeta b{display:block;font-size:18px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.thMeta small{display:block;margin-top:3px;font-size:14px;opacity:.7;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.thMore{display:flex;align-items:center;justify-content:center;min-height:170px;font:700 20px/1 inherit;background:#ffffff14}
.thEmpty{padding:30px 6px;font-size:20px;opacity:.75}
/* Explorar e leitor: sem confusão de ecrã duplo */
body.android #v-tv>.row .tabs,body.android #btnCinema,body.android #btnSwapAudio,body.android .slot .rot,body.android .slot .lbl,body.android #v-tv .tvwrap>.panel:last-child>.row,body.android #mirDelMinus,body.android #mirDelVal,body.android #mirDelPlus,body.android #v-tv>.row>h1{display:none!important}
body.android #v-tv.cinema .cinebar{display:grid!important;grid-template-columns:repeat(4,minmax(0,1fr));gap:10px;width:min(100%,calc((100vh - 180px) * 16 / 9))!important;margin:12px auto 0!important;flex-wrap:wrap}
body.android #v-tv.cinema .cinebar .cinename{grid-column:1/-1;order:0;text-align:center;font-size:24px;font-weight:700;margin-bottom:2px}
body.android #v-tv.cinema .cinebar .btn{width:100%;white-space:nowrap;justify-content:center}
body.android #v-tv.cinema #chPrev{order:1}body.android #v-tv.cinema #chGuide{order:2}body.android #v-tv.cinema #chTracks{order:3}body.android #v-tv.cinema #chNext{order:4}
body.android #v-tv.cinema .stage{width:min(100%,calc((100vh - 180px) * 16 / 9))!important}
body.android .view{max-width:none!important}
body.android.tv{font-size:18px}
body.android.tv .btn,body.android.tv .tab{min-height:52px!important;font-size:17px}
body.android .panel{border-radius:20px;border:0;background:color-mix(in srgb,var(--panel,#121b2e) 92%,transparent)}

/* ===== Botões uniformes, alinhados e sem sobreposição ===== */
body.android .btn,body.android .tab{min-height:44px!important;padding:8px 14px;font-size:15px;line-height:1.15;box-sizing:border-box;display:inline-flex;align-items:center;justify-content:center;text-align:center;gap:6px}
body.android .row{align-items:center;gap:10px}
body.android #v-tv>.row{display:flex!important;flex-wrap:wrap!important;gap:10px;align-items:center}
body.android #v-tv>.row .tabs{display:flex;gap:6px;flex-wrap:nowrap}
body.android .tvwrap>.panel:first-child .tabs{display:grid!important;grid-template-columns:repeat(3,minmax(0,1fr));gap:6px;overflow:visible!important}
body.android .tvwrap>.panel:first-child .tab{min-width:0;font-size:12px!important;padding:6px 2px!important;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
body.android #freeTools{display:grid!important;grid-template-columns:minmax(0,1fr) auto;gap:8px;align-items:center}
body.android #freeTools .btn{width:100%}
body.android #freeTools #healthMsg{grid-column:1/-1;margin:0}
body.android .tvwrap>.panel:first-child input[type=search],body.android .tvwrap>.panel:first-child select,body.android #btnOrg{width:100%;box-sizing:border-box;min-height:44px!important}
body.android #v-tv:not(.cinema) .cinebar{display:grid!important;grid-template-columns:repeat(4,minmax(0,1fr));gap:8px;align-items:stretch}
body.android #v-tv:not(.cinema) #chPrev{order:1}body.android #v-tv:not(.cinema) #chGuide{order:2}body.android #v-tv:not(.cinema) #chTracks{order:3}body.android #v-tv:not(.cinema) #chNext{order:4}body.android #v-tv:not(.cinema) #mirDelMinus{order:5}body.android #v-tv:not(.cinema) #mirDelVal{order:6;grid-column:span 2;text-align:center;align-self:center}body.android #v-tv:not(.cinema) #mirDelPlus{order:7}
body.android #v-tv:not(.cinema) .cinebar .cinename{grid-column:1/-1;order:0;text-align:center}
body.android #v-tv:not(.cinema) .cinebar .btn{width:100%;white-space:nowrap}
body.android #v-tv:not(.cinema) .cinebar #avDelay,body.android #v-tv:not(.cinema) .cinebar .avd{align-self:center;text-align:center}
body.android .tvwrap>.panel:last-child>.row{display:flex;flex-wrap:wrap;gap:10px;align-items:center}
body.android .setcard .row,body.android #v-settings .row{flex-wrap:wrap}
body.android .epgdlg .row{flex-wrap:wrap}

@media (max-width:1100px){body.android #v-tv>.row{gap:8px;flex-wrap:nowrap}body.android #v-tv>.row .btn,body.android #v-tv>.row .tab{font-size:14px;padding:6px 11px;white-space:nowrap;min-height:42px}body.android #v-tv>.row>h1{display:none}}
@media (max-height:640px){body.android #v-tv>h1,body.android #v-tv .row>h1{display:none}body.android .app{grid-template-rows:48px 1fr!important}}
@media (min-width:600px){
  body.android main{min-height:0;overflow-y:auto}
  body.android #v-tv{height:100%;min-height:0;display:flex;flex-direction:column}
  body.android #v-tv:not([hidden]){display:flex}
  body.android .tvwrap{flex:1;min-height:0;grid-template-columns:minmax(250px,34%) minmax(0,1fr)!important;grid-template-rows:minmax(0,1fr);gap:14px}
  body.android .tvwrap>.panel{min-height:0}
  body.android .tvwrap>.panel:last-child{order:0!important;overflow-y:auto}
  body.android .tvwrap>.panel:first-child{display:flex;flex-direction:column;overflow:hidden;gap:8px;padding:12px}
  body.android .tvwrap>.panel:first-child{overflow-y:auto!important}
  body.android .tvwrap>.panel:first-child>*{flex:none}
  body.android .tvwrap>.panel:first-child>.tabs{order:0}
  body.android .tvwrap>.panel:first-child>#tvGroup{order:1}
  body.android .tvwrap>.panel:first-child>#tvSearch{order:2}
  body.android #tvList{order:3;overflow-y:auto;flex:1 1 auto!important;min-height:min(46vh,340px)}
  body.android #btnOrg{order:4}
  body.android #freeTools{order:5}
  body.android #freeTools[hidden]{display:none!important}
  body.android #tvCount{order:6}
  body.android.tv #tvEmpty{display:none!important}
  body.android.tv .tvwrap>.panel:first-child .tabs{flex-wrap:nowrap;overflow-x:auto;gap:6px}
  body.android.tv .tvwrap>.panel:first-child .tab{font-size:13px;padding:5px 10px;min-height:38px;white-space:nowrap}
  body.android.tv .tvwrap>.panel:first-child input,body.android.tv .tvwrap>.panel:first-child select{min-height:40px;padding-block:6px}
  body.android.tv #btnOrg{white-space:nowrap;font-size:14px;min-height:40px}
  body.android.tv #tvCount{display:none}
}
/* modo cinema (ecrã inteiro do leitor) */
body.android .app.cinema{grid-template-rows:1fr!important}
body.android .app.cinema .top{display:none!important}
body.android .app.cinema main{grid-row:1!important;padding:8px 14px!important}
body.android #v-tv.cinema>.row,body.android #v-tv.cinema>.banner{display:none!important}
body.android #v-tv.cinema .tvwrap{display:block!important;grid-template-columns:1fr!important}
body.android #v-tv.cinema .tvwrap>.panel:first-child{display:none!important}
body.android #v-tv.cinema .tvwrap>.panel:last-child{display:flex!important;flex-direction:column;align-items:center;gap:8px;overflow:visible;padding:0!important;border:0!important;background:none!important;height:100%}
body.android #v-tv.cinema .stage{width:min(100%,calc((100vh - 120px) * 16 / 9))!important;margin:0 auto}
body.android #v-tv.cinema .cinebar{width:100%;flex-wrap:nowrap;gap:10px}
body.android #v-tv.cinema .cinebar .btn{min-height:50px;font-size:16px;padding-inline:16px;white-space:nowrap}
body.android #v-tv.cinema .cinename{flex:1;min-width:0;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;text-align:center}
body.android #v-tv.cinema .tvwrap>.panel:last-child>.row,body.android #v-tv.cinema #epgBox{display:none!important}
/* ecrã inteiro do vídeo (OK no vídeo) */
body.android.vfull #v-tv.cinema .cinebar,body.android.vfull #v-tv.cinema .tvwrap>.panel:last-child>.row{display:none!important}
body.android.vfull .app.cinema main{padding:0!important}
body.android.vfull #v-tv.cinema .tvwrap>.panel:last-child{justify-content:center}
body.android.vfull .app{padding:0!important}
body.android.vfull #v-tv.cinema .stage{position:fixed!important;inset:0;z-index:60;width:100vw!important;height:100vh!important;max-height:none;aspect-ratio:auto!important;border-radius:0!important;margin:0!important;background:#000}
body.android.vfull #stage .slot{width:100%!important;height:100%!important;aspect-ratio:auto!important;border-radius:0!important}
body.android.vfull #stage video{object-fit:contain}
body.android.vfull #stage:focus-visible{outline:none!important;box-shadow:none!important}
#fsName{position:fixed;left:24px;bottom:24px;z-index:80;background:rgba(0,0,0,.72);color:#fff;font:600 24px var(--f-display,sans-serif);padding:10px 20px;border-radius:12px;opacity:0;transition:opacity .25s;pointer-events:none;max-width:80vw;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
#fsName.on{opacity:1}
body.android .top .btn[aria-pressed="true"]{background:var(--accent);color:var(--accent-ink);border-color:var(--accent)}
"""
rep("</style>", CSS + "</style>", count=h.count("</style>")) if h.count("</style>") == 1 else None
if h.count("</style>") != 1:
    i = h.rfind("</style>"); h = h[:i] + CSS + h[i:]

JS = r"""
<script>
/* ===== Cockpit TV (Android): só IPTV ===== */
(function(){
  if(!window.ANDROID) return;
  document.body.classList.add("android");
  const top = document.querySelector(".top"), sp = top.querySelector(".spacer");
  const mk = (txt, v) => { const b = document.createElement("button"); b.className = "btn"; b.textContent = txt; b.onclick = () => show(v); b.dataset.v = v; top.insertBefore(b, sp); return b; };
  const bTv = mk("📺 TV", "tv"), bSet = mk("⚙ Definições", "settings");
  const sync = () => { bTv.setAttribute("aria-pressed", currentView === "tv" ? "true" : "false"); bSet.setAttribute("aria-pressed", currentView === "settings" ? "true" : "false"); };
  const _show = window.show;
  window.show = function(v){ const r = _show.apply(this, arguments); sync(); return r; };
  sync();

  /* Definições: só o que interessa à TV (cartões "TV e IPTV" e "Cópia de segurança") */
  const keep = ["TV e IPTV", "Cópia de segurança"];
  $("v-settings").querySelectorAll(".setgrp, .setcard").forEach(e => {
    if(e.classList.contains("setgrp")){ e.hidden = true; return; }
    const t = (e.querySelector("h2") || {}).textContent || "";
    if(!keep.includes(t.trim())) e.hidden = true;
  });
  const tvCard = [...$("v-settings").querySelectorAll(".setcard")].find(e => (e.querySelector("h2") || {}).textContent.trim() === "TV e IPTV");
  if(tvCard){ const info = document.createElement("p"); info.className = "small muted"; info.style.margin = "0"; info.textContent = "Esta aplicação liga-se diretamente ao servidor IPTV (não precisa de proxy)."; tvCard.insertBefore(info, tvCard.children[1] || null); }

  /* Ficheiro de exportação: o Android abre o seletor para escolheres a pasta e o nome */
  window.androidSaved = (ok, where) => { orgXferMsg(ok ? "Ficheiro guardado: " + where : "Não guardei o ficheiro (cancelaste ou não há seletor de ficheiros). Copia o código da caixa em baixo.", !ok); };
  const eb = $("orgExpFile");
  if(eb){ eb.textContent = "Guardar ficheiro…"; eb.onclick = () => {
    const txt = JSON.stringify(orgExport($("orgInclAcc").checked), null, 1); $("orgXfer").value = txt;
    let ok = false; try{ ok = Android.saveText("cockpit-iptv-definicoes.json", txt); }catch(e){}
    if(!ok) orgXferMsg("Não consegui abrir o seletor. Copia o código da caixa.", true);
  }; }

  /* Informar a parte nativa do Referer a usar nos canais abertos (RTP, SIC, …) */
  const _pc = window.playChannel;
  window.playChannel = function(c){ try{ Android.ctx(refFor(c) || ""); }catch(e){} return _pc.apply(this, arguments); };


  /* ===== Navegação com o comando da TV (D-pad) ===== */
  let dpad = false;
  try{ if(Android.isTv && Android.isTv()){ document.body.classList.add("tv"); dpad = true; } }catch(e){}
  /* Toque ou rato: deixa de ser navegação com o comando. Tocar num campo de texto abre logo o teclado (antes era escondido e ficava a piscar). */
  document.addEventListener("pointerdown", e => {
    dpad = false;
    const t = e.target && e.target.closest ? e.target.closest(TXT) : null;
    if(t){ if(editing && editing !== t) editing = null; t.readOnly = false; }
  }, true);
  const FOC = 'button:not([disabled]),a[href],input:not([type=hidden]):not([disabled]),select:not([disabled]),textarea:not([disabled]),summary,label.btn,[tabindex="0"]';
  const TXT = 'input:not([type]),input[type=text],input[type=search],input[type=url],input[type=password],input[type=email],input[type=number],input[type=tel],textarea';
  const isTxt = el => !!(el && el.matches && el.matches(TXT));
  const prep = () => { document.querySelectorAll("label.btn").forEach(l => { if(!l.hasAttribute("tabindex")) l.tabIndex = 0; }); const st = $("stage"); if(st && !st.hasAttribute("tabindex")) st.tabIndex = 0; };
  prep();
  const vis = el => el.getClientRects().length > 0 && getComputedStyle(el).visibility !== "hidden" && !el.closest("[inert]");
  const openDlg = () => document.querySelector(".epgdlg:not([hidden]),.trkdlg:not([hidden])");
  const focusables = () => [...(openDlg() || document).querySelectorAll(FOC)].filter(vis);
  const cinema = () => document.querySelector(".app").classList.contains("cinema");
  const scrollParent = el => { for(let n = el; n && n !== document.body; n = n.parentElement){ const s = getComputedStyle(n); if(/(auto|scroll)/.test(s.overflowY) && n.scrollHeight > n.clientHeight + 4) return n; } return document.scrollingElement; };
  const kb = (on) => { try{ on ? Android.showKeyboard() : Android.hideKeyboard(); }catch(e){} };

  /* Campos de texto: o foco com as setas não abre o teclado; só o OK começa a escrever */
  let editing = null;
  const startEdit = el => {
    editing = el; el.readOnly = false;
    /* o campo já tinha o foco só de leitura: volta a focar para o Android ligar o teclado ao campo */
    el.blur(); editing = el;
    setTimeout(() => { editing = el; el.readOnly = false; el.focus(); try{ const n = el.value.length; el.setSelectionRange(n, n); }catch(x){} kb(true); setTimeout(() => kb(true), 250); }, 40);
  };
  const endEdit = () => { if(editing){ const el = editing; editing = null; el.readOnly = true; kb(false); } };
  document.addEventListener("focusin", e => { const el = e.target; if(dpad && isTxt(el) && el !== editing){ el.readOnly = true; kb(false); } }, true);
  let refocusing = 0;
  document.addEventListener("focusout", e => { if(e.target === editing && !refocusing){ setTimeout(() => { if(editing === e.target && document.activeElement !== e.target) endEdit(); }, 120); } }, true);

  function move(dx, dy){
    const els = focusables(), cur = document.activeElement;
    if(!cur || cur === document.body || !els.includes(cur)){ if(els[0]) els[0].focus(); return; }
    const cr = cur.getBoundingClientRect(), ccx = cr.left + cr.width/2, ccy = cr.top + cr.height/2;
    let best = null, bs = Infinity;
    for(const el of els){
      if(el === cur) continue;
      const r = el.getBoundingClientRect(), cx = r.left + r.width/2, cy = r.top + r.height/2;
      let main, cross;
      if(dx){ if((cx - ccx) * dx <= 1) continue; main = Math.max(0, dx > 0 ? r.left - cr.right : cr.left - r.right); cross = Math.max(0, r.top - cr.bottom, cr.top - r.bottom); }
      else  { if((cy - ccy) * dy <= 1) continue; main = Math.max(0, dy > 0 ? r.top - cr.bottom : cr.top - r.bottom); cross = Math.max(0, r.left - cr.right, cr.left - r.right); }
      const off = dx ? Math.abs(cy - ccy) : Math.abs(cx - ccx);
      const sc = main + cross * 3 + off * 0.15;
      if(sc < bs){ bs = sc; best = el; }
    }
    if(best){ best.focus({preventScroll:true}); best.scrollIntoView({block:"nearest", inline:"nearest"}); }
    else if(dy){ const sp = scrollParent(cur); if(sp) sp.scrollBy(0, dy * 180); }
  }
  const clickId = id => { const b = $(id); if(b) b.click(); };
  const onStage = () => document.activeElement === $("stage");
  let lastItem = null;
  const fsEl = document.createElement("div"); fsEl.id = "fsName"; document.body.appendChild(fsEl);
  let fsT = 0;
  const flashName = () => { if(!document.body.classList.contains("vfull")) return; fsEl.textContent = $("chName").textContent; fsEl.classList.add("on"); clearTimeout(fsT); fsT = setTimeout(() => fsEl.classList.remove("on"), 2600); };
  const setVfull = on => { document.body.classList.toggle("vfull", !!on); if(on) flashName(); else fsEl.classList.remove("on"); };
  new MutationObserver(flashName).observe($("chName"), {childList:true, characterData:true, subtree:true});

  /* Ao escolher um canal (OK) passa para o ecrã do leitor; Voltar regressa à lista */
  $("tvList").addEventListener("click", e => {
    const b = e.target.closest("[data-play]"); if(!b || !dpad) return;
    lastItem = b;
    setTimeout(() => {
      if($("stage").classList.contains("single") && currentView === "tv"){ setVfull(false); if(!cinema()) setCinema(true); $("stage").focus({preventScroll:true}); }
    }, 60);
  });

  /* Nome da tecla: alguns comandos/TVs enviam key vazio ou "Unidentified" para o OK e para as teclas de multimédia */
  const KC = {13:"Enter", 23:"Enter", 66:"Enter", 160:"Enter", 19:"ArrowUp", 20:"ArrowDown", 21:"ArrowLeft", 22:"ArrowRight", 33:"PageUp", 34:"PageDown", 166:"ChannelUp", 167:"ChannelDown", 85:"MediaPlayPause", 179:"MediaPlayPause", 126:"MediaPlay", 127:"MediaPause", 86:"MediaStop", 90:"MediaFastForward", 89:"MediaRewind", 87:"MediaTrackNext", 88:"MediaTrackPrevious", 175:"Guide", 172:"Guide", 165:"Info", 82:"ContextMenu", 4:"GoBack", 111:"Escape"};
  const keyName = e => { const k = e.key; if(k && k !== "Unidentified" && k !== "Dead") return k === "Return" ? "Enter" : k; if(e.code === "NumpadEnter" || e.code === "Enter") return "Enter"; return KC[e.keyCode || e.which] || k || ""; };
  document.addEventListener("keydown", e => {
    const a = document.activeElement, k = keyName(e);
    if(e.altKey || e.ctrlKey || e.metaKey) return;
    const arrow = {ArrowUp:[0,-1], ArrowDown:[0,1], ArrowLeft:[-1,0], ArrowRight:[1,0]}[k];
    if(arrow || k === "PageUp" || k === "PageDown") dpad = true;
    /* a app original muda de canal com Cima/Baixo: aqui isso fica só para o ecrã do leitor */
    const eat = () => { e.preventDefault(); e.stopImmediatePropagation(); };

    /* escrever num campo */
    if(editing && a === editing){
      if(k === "Enter"){ const el = editing; setTimeout(() => { if(editing === el) endEdit(); }, 30); return; }   /* deixa a pesquisa do campo correr e fecha o teclado */
      if(k === "ArrowUp" || k === "ArrowDown"){ eat(); endEdit(); move(0, arrow[1]); return; }
      return; /* resto das teclas escreve normalmente */
    }
    if(k === "Enter" && isTxt(a) && (a.readOnly || dpad)){ eat(); startEdit(a); return; }

    if(k === "Guide" || k === "Info"){ const g = $("chGuide"); if(g && g.offsetParent){ eat(); g.click(); } return; }
    if(k === "ContextMenu" || k === "Settings"){ eat(); show("settings"); return; }
    if(k === "MediaStop" || k === "GoBack" || k === "Escape"){ eat(); window.androidBack(); return; }
    if(k === "MediaTrackNext"){ eat(); clickId("chNext"); return; }
    if(k === "MediaTrackPrevious"){ eat(); clickId("chPrev"); return; }
    if(k === "MediaFastForward" || k === "MediaRewind"){ const v = $("vid" + (typeof tvTarget === "number" ? tvTarget : 0)); if(v && isFinite(v.duration) && v.duration > 0){ eat(); v.currentTime = Math.max(0, Math.min(v.duration, v.currentTime + (k === "MediaFastForward" ? 30 : -30))); } return; }
    if(k === "ChannelUp"){ eat(); clickId("chNext"); return; }
    if(k === "ChannelDown"){ eat(); clickId("chPrev"); return; }
    if(k === "PageDown" || k === "PageUp"){ eat(); clickId(k === "PageDown" ? "chNext" : "chPrev"); return; }
    if(k === "MediaPlayPause" || k === "MediaPlay" || k === "MediaPause"){
      const v = $("vid" + (typeof tvTarget === "number" ? tvTarget : 0)); if(v){ eat(); (k === "MediaPause" || (k === "MediaPlayPause" && !v.paused)) ? v.pause() : v.play().catch(()=>{}); } return; }

    if(arrow){
      if(arrow[0] && a && a.type === "range") return;
      eat();
      if(onStage() && cinema() && !openDlg()){        /* ecrã do leitor: Cima/Baixo mudam de canal */
        if(arrow[1]) clickId(arrow[1] < 0 ? "chNext" : "chPrev");
        else if(!document.body.classList.contains("vfull")){ const f = $("chGuide"); if(f) f.focus(); }   /* Esq./Dir.: vai para os botões */
        return;
      }
      move(arrow[0], arrow[1]); return;
    }
    if(k === "Enter" && a){
      if(a === $("stage") && cinema()){ eat(); setVfull(!document.body.classList.contains("vfull")); return; }   /* OK no vídeo: ecrã inteiro / sair do ecrã inteiro */
      if(a.type === "checkbox" || a.type === "radio" || a.tagName === "LABEL"){ e.preventDefault(); a.click(); }
    }
  }, true);

  /* Foco inicial e foco ao abrir/fechar janelas */
  setTimeout(() => { if(!document.activeElement || document.activeElement === document.body) bTv.focus(); }, 600);
  let prevFocus = null;
  new MutationObserver(() => {
    prep();
    const d = openDlg();
    if(d && !d.contains(document.activeElement)){ if(!prevFocus) prevFocus = document.activeElement; const f = [...d.querySelectorAll(FOC)].filter(vis)[0]; if(f) f.focus(); }
    else if(!d && prevFocus){ const p = prevFocus; prevFocus = null; if(p !== document.body && document.contains(p) && vis(p)) p.focus(); }
  }).observe(document.body, {subtree:true, attributes:true, attributeFilter:["hidden"]});

  /* Botão Voltar */
  window.androidBack = function(){
    if(editing){ endEdit(); return true; }
    const d = document.querySelector(".epgdlg:not([hidden]),.trkdlg:not([hidden])");
    if(d){ const b = [...d.querySelectorAll("button")].find(x => /^(fechar|✕|×|close)/i.test(x.textContent.trim())); if(b) b.click(); else d.hidden = true; return true; }
    if(document.querySelector(".app").classList.contains("cinema")){
      if(document.body.classList.contains("vfull")){ setVfull(false); $("stage").focus({preventScroll:true}); return true; }
      if(!onStage() && $("stage").offsetParent){ $("stage").focus({preventScroll:true}); return true; }   /* dos botões volta ao vídeo */
      setCinema(false); setVfull(false);
      if(window.__homeOrigin){ window.__homeOrigin = false; show("tvhome"); return true; }
      setTimeout(() => { const it = lastItem && document.contains(lastItem) && vis(lastItem) ? lastItem : null; (it || bTv).focus(); if(it) it.scrollIntoView({block:"nearest"}); }, 60);
      return true;
    }
    if(currentView === "settings"){ show("tvhome"); return true; }
    if(currentView === "tv"){ show("tvhome"); return true; }
    return false;
  };
})();
</script>
"""

JS2 = r'''
<script>
/* ===== Cockpit TV: ecrã Início (estilo Android TV) ===== */
(function(){
  if(!window.ANDROID) return;
  const $ = id => document.getElementById(id);
  const esc = t => String(t == null ? "" : t).replace(/[&<>"]/g, m => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;"}[m]));
  const sec = document.createElement("section"); sec.className = "view"; sec.id = "v-tvhome"; sec.hidden = true;
  sec.innerHTML = '<div class="thHero" id="thHero"></div><div id="thRows"></div>';
  $("main").appendChild(sec);

  /* barra de navegação */
  const top = document.querySelector(".top"), sp = top.querySelector(".spacer");
  const nav = document.createElement("nav"); nav.className = "thNav"; nav.setAttribute("aria-label", "Menu");
  [["tvhome","🏠","Início"],["tv","🔎","Explorar"],["guide","📅","Guia"],["settings","⚙","Definições"]].forEach(([v, ic, t]) => {
    const b = document.createElement("button"); b.className = "thTab"; b.dataset.th = v; b.innerHTML = "<span>" + ic + "</span>" + t;
    b.onclick = () => { window.__homeOrigin = false; if(v === "guide") openGuide(); else show(v); };
    nav.appendChild(b);
  });
  top.insertBefore(nav, sp);
  const syncNav = () => nav.querySelectorAll(".thTab").forEach(b => b.setAttribute("aria-current", b.dataset.th === currentView ? "page" : "false"));

  /* recentes */
  const REC = "tvRecent";
  const recents = () => LS.get(REC, []) || [];
  const pushRecent = c => { try{ const a = recents().filter(x => x.url !== c.url); a.unshift({name:c.name, logo:c.logo || "", url:c.url, kind:c.kind, group:c.group, id:c.id, free:c.free, intl:c.intl, sid:c.sid}); LS.set(REC, a.slice(0, 24)); }catch(e){} };
  const _pc = window.playChannel;
  window.playChannel = function(c){ try{ if(c && c.url) pushRecent(c); }catch(e){} return _pc.apply(this, arguments); };

  const HOME = {flat:[], lastK:null, kind:(LS.get("thKind", "live") || "live")};
  const KINDS = [["live","📺","Live"],["movie","🎬","Filmes"],["series","🍿","Séries"]];
  const ptGroups = kind => { const m = groupsOf(kind), names = orgGroupList(kind, [...m.keys()], false).filter(isPtGroup); return names.map(n => [n, m.get(n)]); };
  const allCh = () => [...(typeof channels !== "undefined" ? channels : []), ...freeChans, ...intlChans];
  const uniq = l => { const s = new Set(); return l.filter(c => c && c.url && !s.has(c.url) && s.add(c.url)); };
  const groupsOf = kind => { const m = new Map(); channels.filter(c => c.kind === kind).forEach(c => { const g = c.group || "Outros"; if(!m.has(g)) m.set(g, []); m.get(g).push(c); }); return m; };

  function card(c, k, small){
    let sub = c.group || "";
    try{ const nn = nowNext(c); if(nn) sub = hm(nn.now.start) + " " + nn.now.title; }catch(e){}
    return '<button class="thCard' + (small ? " sm" : "") + '" data-k="' + k + '"><span class="thArt">' + (c.logo ? '<img src="' + esc(c.logo) + '" alt="" loading="lazy" onerror="this.remove()">' : "") + '<b class="thInit">' + esc((c.name || "?").replace(/[^\p{L}\p{N}]/gu, "").slice(0, 2).toUpperCase()) + '</b></span><span class="thMeta"><b>' + esc(c.name) + '</b><small>' + esc(sub) + '</small></span></button>';
  }
  function row(title, list, more){
    list = uniq(list); if(!list.length) return "";
    const k0 = HOME.flat.length; list.forEach(c => HOME.flat.push(c));
    return '<div class="thRow"><h2>' + title + '</h2><div class="thScroll">' + list.map((c, i) => card(c, k0 + i)).join("") + (more ? '<button class="thCard thMore" data-more="' + more + '"><span>Ver tudo →</span></button>' : "") + '</div></div>';
  }

  function renderHome(){
    if(currentView !== "tvhome") return;
    const keep = document.activeElement && document.activeElement.dataset ? document.activeElement.dataset.k : null;
    HOME.flat = [];
    const cur = (lastPlayed && (lastPlayed[0] || lastPlayed[1])) || recents()[0] || null;
    const hasList = channels.length > 0;
    let hero = "";
    if(cur){
      let sub = cur.group || ""; try{ const nn = nowNext(cur); if(nn) sub = hm(nn.now.start) + " " + nn.now.title; }catch(e){}
      HOME.flat.push(cur); const k = HOME.flat.length - 1;
      hero = '<div class="thHeroArt">' + (cur.logo ? '<img src="' + esc(cur.logo) + '" alt="" onerror="this.remove()">' : '<b>' + esc((cur.name || "?").slice(0, 2).toUpperCase()) + '</b>') + '</div><div class="thHeroTx"><small>Continuar a ver</small><h1>' + esc(cur.name) + '</h1><p>' + esc(sub) + '</p><div class="thHeroBt"><button class="thBtn pri" data-k="' + k + '">▶ Ver agora</button><button class="thBtn" data-go="tv">🔎 Explorar canais</button></div></div>';
    } else {
      hero = '<div class="thHeroTx"><small>Cockpit TV</small><h1>Bem-vindo</h1><p>' + (hasList ? "Escolhe um canal em baixo para começar." : "Os canais abertos portugueses já estão disponíveis. Para ver mais, adiciona a tua lista IPTV nas Definições.") + '</p><div class="thHeroBt"><button class="thBtn pri" data-go="tv">🔎 Explorar canais</button><button class="thBtn" data-go="settings">⚙ Definições</button></div></div>';
    }
    $("thHero").innerHTML = hero;
    let rows = '<div class="thKinds">' + KINDS.map(([k, ic, t]) => '<button class="thBtn thKind" data-kind2="' + k + '" aria-pressed="' + (HOME.kind === k) + '">' + ic + " " + t + '</button>').join("") + '</div>';
    const pg = ptGroups(HOME.kind);
    for(const [g, l] of pg.slice(0, 14)) rows += row(esc(g), l.slice(0, 40), "");
    if(!pg.length && HOME.kind === "live" && !channels.some(c => c.kind === "live")) rows += row("📡 Canais abertos PT", freeChans.filter(c => typeof hState !== "function" || hState(c) !== "dead").slice(0, 40), "free");
    if(!pg.length && !rows.includes("thRow")) rows += '<p class="thEmpty">Sem categorias PT em ' + (KINDS.find(x => x[0] === HOME.kind) || [])[2] + '. Usa Explorar para ver todas.</p>';
    if(!rows.includes("thRow") && !rows.includes("thEmpty")) rows += '<p class="thEmpty">' + (typeof freeLoading !== "undefined" && freeLoading ? "A carregar canais…" : "Sem canais para mostrar. Verifica a ligação à internet.") + '</p>';
    $("thRows").innerHTML = rows;
    if(keep != null){ const el = sec.querySelector('[data-k="' + keep + '"]'); if(el) el.focus({preventScroll:true}); }
  }

  function watch(c){
    if(!c) return;
    window.__homeOrigin = true;
    if(c.kind === "series" && c.sid){ openSeries(c); return; }
    playChannel(c);
    setTimeout(() => { if(currentView === "tv"){ if(!document.querySelector(".app").classList.contains("cinema")) setCinema(true); const st = $("stage"); if(st) st.focus({preventScroll:true}); } }, 140);
  }
  sec.addEventListener("click", e => {
    const b = e.target.closest("[data-k],[data-more],[data-go],[data-kind2]"); if(!b) return;
    if(b.dataset.kind2){ HOME.kind = b.dataset.kind2; HOME.lastK = null; try{ LS.set("thKind", HOME.kind); }catch(x){} renderHome(); const nb = sec.querySelector('[data-kind2="' + HOME.kind + '"]'); if(nb) nb.focus({preventScroll:true}); return; }
    if(b.dataset.k != null){ HOME.lastK = b.dataset.k; watch(HOME.flat[+b.dataset.k]); }
    else if(b.dataset.more){ window.__homeOrigin = false; show("tv"); const t = document.querySelector('[data-kind="' + b.dataset.more + '"]'); if(t) t.click(); }
    else if(b.dataset.go){ window.__homeOrigin = false; show(b.dataset.go); }
  });

  /* ligações: atualiza o ecrã quando chegam listas */
  let loading = false;
  async function loadAll(){
    if(loading) return; loading = true;
    try{ await ensureFree(false); }catch(e){}
    renderHome();
    try{ await ensureIntl(false); }catch(e){}
    loading = false; renderHome();
  }
  const _show = window.show;
  window.show = function(v){
    const r = _show.apply(this, arguments); syncNav();
    if(currentView === "tvhome"){
      renderHome(); loadAll();
      setTimeout(() => { if(currentView !== "tvhome") return; const a = document.activeElement; if(a && a !== document.body && sec.contains(a)) return; const k = HOME.lastK != null ? sec.querySelector('[data-k="' + HOME.lastK + '"]') : null; (k || sec.querySelector(".thBtn.pri,.thCard") || nav.querySelector(".thTab")).focus({preventScroll:true}); }, 120);
    }
    return r;
  };
  const _ai = window.afterIptv; if(typeof _ai === "function") window.afterIptv = function(){ const r = _ai.apply(this, arguments); try{ renderHome(); }catch(e){} return r; };
  setInterval(() => { if(currentView === "tvhome") renderHome(); }, 60000);
  setTimeout(() => { if(currentView === "tvhome" && (!document.activeElement || document.activeElement === document.body)) (sec.querySelector(".thBtn.pri,.thCard") || nav.querySelector(".thTab")).focus({preventScroll:true}); }, 900);
  syncNav();
  if(currentView === "tvhome") window.show("tvhome");
})();
</script>
'''

i = h.rfind("</body>")
h = h[:i] + JS + JS2 + h[i:]
os.makedirs(os.path.dirname(out), exist_ok=True)
open(out, "w", encoding="utf-8").write(h)
print("OK ->", os.path.normpath(out), len(h)//1024, "KB")
