package pt.rui.cockpittv;

import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.util.TypedValue;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.LinearInterpolator;
import android.view.animation.PathInterpolator;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import org.json.JSONObject;

import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Proteção de ecrã: filmes e séries mais bem classificados, com imagem de fundo em movimento lento
 * (Ken Burns) e transições alternadas (dissolver, deslizar com paralaxe, revelar com zoom).
 * Qualquer tecla ou toque sai; OK abre a ficha do título mostrado.
 */
final class ScreenSaver {
    interface Host { void openItem(NativeData.Item it); void closed(); }

    private final Activity act;
    private final NativeData data;
    private final Host host;
    private final List<NativeData.Item> items;
    private final int slideMs;
    private final boolean clockOn;
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newSingleThreadExecutor();

    final FrameLayout root;
    private final ImageView[] img = new ImageView[2];
    private int front = 0, idx = -1, style = 0;
    private final LinearLayout text;
    private final TextView label, title, meta, plot, clock, date, hint;
    private final View progress;
    private NativeData.Item shown;
    private boolean closed = false;
    private final long startedAt = System.currentTimeMillis();
    private final float den;

    /** Slide preparado: título, imagem e textos já traduzidos. */
    private static final class Slide { NativeData.Item it; Bitmap bmp; String meta = "", plot = "", kind = ""; }

    static List<NativeData.Item> pick(NativeData data, String what, boolean kids, java.util.function.Predicate<NativeData.Item> blocked) {
        List<NativeData.Item> all = new ArrayList<>();
        for (String k : new String[]{"movie", "series"}) {
            if ("movie".equals(what) && !"movie".equals(k)) continue;
            if ("series".equals(what) && !"series".equals(k)) continue;
            List<NativeData.Item> l = data.all.get(k);
            if (l != null) all.addAll(l);
        }
        /* uma só passagem: nota calculada uma vez por título (a ordenação antiga recalculava tudo em cada comparação e bloqueava a app) */
        int now = java.util.Calendar.getInstance().get(java.util.Calendar.YEAR);
        List<Object[]> ok = new ArrayList<>(); java.util.Set<String> names = new java.util.HashSet<>();
        for (NativeData.Item it : all) {
            double r = rate(it);
            if (r <= 0 || r > 10 || it.logo == null || it.logo.isEmpty()) continue;
            if (blocked != null && blocked.test(it)) continue;
            if (kids) { String g = (it.name + " " + it.group).toLowerCase(Locale.ROOT); if (!(g.contains("anima") || g.contains("desenhos") || g.contains("cartoon") || g.contains("famil") || g.contains("kids") || g.contains("infant") || g.contains("crian"))) continue; }
            String nk = NativeData.shownName(it.name).toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
            if (!names.add(nk)) continue;   /* a mesma obra em várias qualidades: só uma vez */
            int y = 0; try { String ys = it.year == null ? "" : it.year; y = Integer.parseInt(ys.length() >= 4 ? ys.substring(0, 4) : ys); } catch (Throwable ignored) { }
            double fresh = y <= 0 ? 0 : Math.max(0, 1.5 - (now - y) * 0.15);   /* até +1,5 para os deste ano */
            ok.add(new Object[]{it, r + fresh});
        }
        Collections.sort(ok, (a, b) -> Double.compare((Double) b[1], (Double) a[1]));
        List<NativeData.Item> top = new ArrayList<>();
        for (int i = 0; i < ok.size() && i < 80; i++) top.add((NativeData.Item) ok.get(i)[0]);
        Collections.shuffle(top);
        return top;
    }
    private static double rate(NativeData.Item it) { try { return Double.parseDouble(it.rating.replace(',', '.')); } catch (Throwable e) { return 0; } }

    /* ---- música clássica em fundo (rádio só de música: Radio Swiss Classic, com endereços alternativos) ---- */
    static final String[] MUSIC = {
            "https://stream.srg-ssr.ch/srgssr/rsc_de/mp3/128",
            "https://stream.srg-ssr.ch/srgssr/rsc_de/aac/96",
            "http://stream.srg-ssr.ch/m/rsc_de/mp3_128"};
    private float musicVol = 0f;
    private androidx.media3.exoplayer.ExoPlayer music;
    private int musicIdx = 0;
    private TextView musicLbl;
    private void startMusic(final float target) {
        if (target <= 0f || closed) return;
        try {
            music = new androidx.media3.exoplayer.ExoPlayer.Builder(act).build();
            music.setAudioAttributes(new androidx.media3.common.AudioAttributes.Builder()
                    .setUsage(androidx.media3.common.C.USAGE_MEDIA).setContentType(androidx.media3.common.C.AUDIO_CONTENT_TYPE_MUSIC).build(), true);
            music.setVolume(0f);
            music.addListener(new androidx.media3.common.Player.Listener() {
                @Override public void onPlayerError(androidx.media3.common.PlaybackException e) {
                    NativeData.dbg("proteção de ecrã: música falhou (" + MUSIC[musicIdx] + "): " + e.getErrorCodeName());
                    if (closed || music == null) return;
                    if (++musicIdx >= MUSIC.length) { musicLbl.setVisibility(View.GONE); return; }
                    music.setMediaItem(androidx.media3.common.MediaItem.fromUri(MUSIC[musicIdx])); music.prepare(); music.play();
                }
                @Override public void onIsPlayingChanged(boolean playing) {
                    if (playing && musicLbl != null) { musicLbl.setVisibility(View.VISIBLE); musicLbl.animate().alpha(1f).setDuration(800).start(); }
                }
            });
            music.setMediaItem(androidx.media3.common.MediaItem.fromUri(MUSIC[0]));
            music.prepare(); music.play();
            fade(target, 4000);
            NativeData.dbg("proteção de ecrã: música clássica ligada");
        } catch (Throwable e) { NativeData.dbg("proteção de ecrã: sem música: " + e); }
    }
    /** Sobe ou desce o volume aos poucos (o som entra e sai sem cortes). */
    private void fade(final float to, final long ms) {
        final float from = musicVol; final long t0 = System.currentTimeMillis();
        ui.post(new Runnable() { @Override public void run() {
            if (music == null) return;
            float k = Math.min(1f, (System.currentTimeMillis() - t0) / (float) Math.max(1, ms));
            musicVol = from + (to - from) * k;
            try { music.setVolume(musicVol); } catch (Throwable ignored) { }
            if (k < 1f) ui.postDelayed(this, 50);
        } });
    }
    private void stopMusic() {
        final androidx.media3.exoplayer.ExoPlayer m = music;
        if (m == null) return;
        music = null;
        /* desce o volume em 0,4 s e só depois liberta o leitor */
        final float v0 = musicVol; final long t0 = System.currentTimeMillis();
        new Handler(Looper.getMainLooper()).post(new Runnable() { @Override public void run() {
            float k = Math.min(1f, (System.currentTimeMillis() - t0) / 400f);
            try { m.setVolume(v0 * (1f - k)); } catch (Throwable ignored) { }
            if (k < 1f) new Handler(Looper.getMainLooper()).postDelayed(this, 40);
            else try { m.release(); } catch (Throwable ignored) { }
        } });
    }
    private float musicTarget = 0f;
    void setMusic(float volume) { musicTarget = volume; }

    ScreenSaver(Activity act, NativeData data, List<NativeData.Item> items, int slideSec, boolean clockOn, Host host) {
        this.act = act; this.data = data; this.items = items; this.host = host; this.clockOn = clockOn;
        this.slideMs = Math.max(6, slideSec) * 1000;
        den = act.getResources().getDisplayMetrics().density;
        int acc = NativeHomeActivity.lookAcc();

        root = new FrameLayout(act); root.setBackgroundColor(Color.BLACK); root.setFocusable(true); root.setFocusableInTouchMode(true); root.setClickable(true);
        root.setKeepScreenOn(true);
        for (int i = 0; i < 2; i++) { img[i] = new ImageView(act); img[i].setScaleType(ImageView.ScaleType.CENTER_CROP); img[i].setAlpha(0f); root.addView(img[i], new FrameLayout.LayoutParams(-1, -1)); }
        View shadeL = new View(act); shadeL.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xE6000000, 0x99000000, 0x00000000}));
        root.addView(shadeL, new FrameLayout.LayoutParams(-1, -1));
        View shadeB = new View(act); shadeB.setBackground(new GradientDrawable(GradientDrawable.Orientation.BOTTOM_TOP, new int[]{0xF2000000, 0x66000000, 0x00000000, 0x00000000}));
        root.addView(shadeB, new FrameLayout.LayoutParams(-1, -1));

        text = new LinearLayout(act); text.setOrientation(LinearLayout.VERTICAL);
        int w = act.getResources().getDisplayMetrics().widthPixels;
        label = tv(13, acc, true); label.setLetterSpacing(0.18f);
        title = tv(44, Color.WHITE, true); title.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD)); title.setMaxLines(2); title.setEllipsize(TextUtils.TruncateAt.END); title.setShadowLayer(dp(8), 0, 0, 0xCC000000);
        meta = tv(17, acc, false); meta.setPadding(0, dp(8), 0, 0);
        plot = tv(18, 0xE6FFFFFF, false); plot.setMaxLines(3); plot.setEllipsize(TextUtils.TruncateAt.END); plot.setLineSpacing(0, 1.15f); plot.setPadding(0, dp(14), 0, 0); plot.setShadowLayer(dp(4), 0, 0, 0xCC000000);
        text.addView(label); text.addView(title); text.addView(meta); text.addView(plot);
        FrameLayout.LayoutParams tl = new FrameLayout.LayoutParams((int) (w * (w > dp(900) ? 0.55f : 0.86f)), -2, Gravity.BOTTOM | Gravity.LEFT);
        tl.leftMargin = dp(56); tl.bottomMargin = dp(74);
        root.addView(text, tl);

        LinearLayout ck = new LinearLayout(act); ck.setOrientation(LinearLayout.VERTICAL); ck.setGravity(Gravity.RIGHT);
        clock = tv(54, Color.WHITE, false); clock.setTypeface(Typeface.create("sans-serif-light", Typeface.NORMAL)); clock.setShadowLayer(dp(8), 0, 0, 0xCC000000);
        date = tv(16, 0xCCFFFFFF, false); date.setShadowLayer(dp(4), 0, 0, 0xCC000000);
        ck.addView(clock); ck.addView(date);
        FrameLayout.LayoutParams cl = new FrameLayout.LayoutParams(-2, -2, Gravity.TOP | Gravity.RIGHT); cl.topMargin = dp(34); cl.rightMargin = dp(48);
        root.addView(ck, cl);
        ck.setVisibility(clockOn ? View.VISIBLE : View.GONE);

        hint = tv(14, 0x99FFFFFF, false);
        hint.setText(Tr.t("OK abre o título · qualquer outra tecla sai"));
        FrameLayout.LayoutParams hl = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.RIGHT); hl.rightMargin = dp(48); hl.bottomMargin = dp(30);
        root.addView(hint, hl);
        musicLbl = tv(14, 0xB3FFFFFF, false); musicLbl.setText("♪  Radio Swiss Classic"); musicLbl.setAlpha(0f); musicLbl.setVisibility(View.GONE);
        FrameLayout.LayoutParams ml = new FrameLayout.LayoutParams(-2, -2, Gravity.BOTTOM | Gravity.RIGHT); ml.rightMargin = dp(48); ml.bottomMargin = dp(54);
        root.addView(musicLbl, ml);

        progress = new View(act); progress.setBackgroundColor(acc); progress.setPivotX(0f); progress.setScaleX(0f);
        root.addView(progress, new FrameLayout.LayoutParams(-1, Math.max(2, dp(3)), Gravity.BOTTOM));
        root.setOnClickListener(v -> { if (host != null) host.closed(); });   /* toque: sai */
    }

    private TextView tv(float sp, int color, boolean bold) {
        TextView t = new TextView(act); t.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp * (act.getResources().getDisplayMetrics().widthPixels > dp(1100) ? 1f : 0.8f));
        t.setTextColor(color); if (bold) t.setTypeface(null, Typeface.BOLD); return t;
    }
    private int dp(float v) { return Math.round(v * den); }

    void start() {
        root.setAlpha(0f); root.animate().alpha(1f).setDuration(900).start();
        root.requestFocus();
        tickClock();
        next(true);
        startMusic(musicTarget);
    }
    void stop() {
        closed = true;
        stopMusic();
        ui.removeCallbacksAndMessages(null);
        bg.shutdownNow();
        for (ImageView v : img) v.animate().cancel();
        root.setKeepScreenOn(false);
    }
    NativeData.Item shown() { return shown; }
    void openShown() { if (shown != null && host != null) host.openItem(shown); }

    private void tickClock() {
        if (closed) return;
        java.util.Date d = new java.util.Date();
        Locale l = "pt".equals(Tr.lang) ? new Locale("pt", "PT") : new Locale(Tr.lang);
        clock.setText(new java.text.SimpleDateFormat("HH:mm", l).format(d));
        String ds = new java.text.SimpleDateFormat("EEEE, d MMMM", l).format(d);
        date.setText(ds.isEmpty() ? ds : ds.substring(0, 1).toUpperCase(l) + ds.substring(1));
        /* ao fim de 2 horas deixa a TV seguir as suas regras de poupança (desligar o ecrã) */
        if (System.currentTimeMillis() - startedAt > 2 * 3600_000L) root.setKeepScreenOn(false);
        ui.postDelayed(this::tickClock, 15_000);
    }

    /** Prepara o próximo título por trás (dados, sinopse traduzida e imagem) e faz a transição. */
    private void next(final boolean first) {
        if (closed || items.isEmpty()) return;
        final long t0 = System.currentTimeMillis();
        try { bg.execute(() -> {
            Slide s = null;
            for (int tries = 0; tries < 6 && s == null && !closed; tries++) {
                idx = (idx + 1) % items.size();
                s = load(items.get(idx));
            }
            final Slide fs = s;
            long wait = first ? 0 : Math.max(0, slideMs - (System.currentTimeMillis() - t0));
            ui.postDelayed(() -> { if (!closed && fs != null) show(fs, first); else if (!closed) next(false); }, wait);
        }); } catch (Throwable ignored) { }
    }

    private Slide load(NativeData.Item it) {
        try {
            Slide s = new Slide(); s.it = it;
            JSONObject inf = null;
            if ("series".equals(it.kind)) { try { data.seriesInfo(it, false); inf = data.seriesMeta.get(it.sid); } catch (Throwable ignored) { } }
            else { try { inf = data.vodInfo(it); } catch (Throwable ignored) { } }
            String bk = inf == null ? "" : NativeData.firstImg(inf, "backdrop_path", "backdrop", "movie_image", "cover_big", "cover");
            if (bk == null || bk.isEmpty()) bk = it.logo;
            int w = act.getResources().getDisplayMetrics().widthPixels;
            s.bmp = fetch(bk, w);
            if (s.bmp == null) return null;
            /* para imagens verticais (só capa), usa a capa tal como é: o recorte central chega para o fundo */
            String pl = inf == null ? "" : NativeData.text(inf, "plot", "description", "overview");
            if (pl.isEmpty() && it.plot != null) pl = it.plot;
            if (pl.length() >= 20) { String t = data.trCached(pl); if (t == null) { try { t = data.translatePt(pl); } catch (Throwable ignored) { } } if (t != null && !t.trim().isEmpty()) pl = t; }
            s.plot = pl;
            StringBuilder m = new StringBuilder();
            String y = it.year == null ? "" : it.year; if (y.length() >= 4) m.append(y.substring(0, 4));
            double r = rate(it); if (r > 0) { if (m.length() > 0) m.append("  ·  "); m.append("★ ").append(String.format(Locale.ROOT, "%.1f", r)); }
            String g = inf == null ? "" : NativeData.text(inf, "genre");
            if (!g.isEmpty()) { String gt = data.trCached(g); if (gt == null) { try { gt = data.translatePt(g); } catch (Throwable ignored) { } } if (gt != null && !gt.isEmpty()) g = gt; if (m.length() > 0) m.append("  ·  "); m.append(g); }
            s.meta = m.toString();
            s.kind = "series".equals(it.kind) ? Tr.t("SÉRIE") : Tr.t("FILME");
            return s;
        } catch (Throwable e) { return null; }
    }

    private static Bitmap fetch(String url, int maxW) {
        if (url == null || !url.startsWith("http")) return null;
        HttpURLConnection h = null;
        try {
            h = (HttpURLConnection) new URL(url).openConnection();
            h.setConnectTimeout(6000); h.setReadTimeout(10000); h.setInstanceFollowRedirects(true);
            h.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) CockpitTV");
            InputStream in = h.getInputStream();
            ByteArrayOutputStream bo = new ByteArrayOutputStream(); byte[] buf = new byte[16384]; int n;
            while ((n = in.read(buf)) > 0) { bo.write(buf, 0, n); if (bo.size() > 10 * 1024 * 1024) break; }
            in.close();
            byte[] d = bo.toByteArray();
            BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true;
            BitmapFactory.decodeByteArray(d, 0, d.length, o);
            int ss = 1; while (o.outWidth / (ss * 2) >= maxW) ss *= 2;
            BitmapFactory.Options o2 = new BitmapFactory.Options(); o2.inSampleSize = ss;
            return BitmapFactory.decodeByteArray(d, 0, d.length, o2);
        } catch (Throwable e) { return null; } finally { if (h != null) try { h.disconnect(); } catch (Throwable ignored) { } }
    }

    /* curvas suaves: entra e sai devagar (sem arranques bruscos) */
    private static final PathInterpolator EASE = new PathInterpolator(0.45f, 0f, 0.55f, 1f);
    private static final PathInterpolator EASE_OUT = new PathInterpolator(0.25f, 0.1f, 0.25f, 1f);
    private static final long XFADE = 2400;
    private final android.animation.Animator[] motion = new android.animation.Animator[2];
    private final android.animation.Animator[] fadeA = new android.animation.Animator[2];

    private void show(final Slide s, final boolean first) {
        if (closed) return;
        shown = s.it;
        final int ni = 1 - front;
        final ImageView out = img[front], in = img[ni];
        front = ni;
        if (motion[ni] != null) motion[ni].cancel();
        if (fadeA[ni] != null) fadeA[ni].cancel();
        in.setAlpha(0f);
        in.setLayerType(View.LAYER_TYPE_HARDWARE, null);
        in.setImageBitmap(s.bmp);
        in.bringToFront();
        List<View> over = new ArrayList<>();
        for (int i = 0; i < root.getChildCount(); i++) { View v = root.getChildAt(i); if (v != img[0] && v != img[1]) over.add(v); }
        for (View v : over) v.bringToFront();
        /* espera que a imagem nova esteja desenhada antes de animar (evita pequenos saltos) */
        in.post(() -> in.post(() -> { if (!closed) animateIn(s, first, in, out, ni); }));
    }

    private void animateIn(final Slide s, final boolean first, final ImageView in, final ImageView out, final int ni) {
        int w = root.getWidth() > 0 ? root.getWidth() : act.getResources().getDisplayMetrics().widthPixels;
        int st = first ? 0 : (style++ % 3);
        float s0, s1, x0, x1, y0, y1;
        boolean right = (idx & 1) == 0;
        if (st == 1) {        /* deslize lateral lento (paralaxe) */
            s0 = 1.10f; s1 = 1.12f; x0 = (right ? 1 : -1) * w * 0.05f; x1 = (right ? -1 : 1) * w * 0.02f; y0 = 0; y1 = -dpF(6);
        } else if (st == 2) { /* afastar devagar (revelar) */
            s0 = 1.20f; s1 = 1.06f; x0 = 0; x1 = (right ? -1 : 1) * w * 0.015f; y0 = dpF(6); y1 = -dpF(4);
        } else {              /* aproximar devagar (Ken Burns clássico) */
            s0 = 1.03f; s1 = 1.14f; x0 = (right ? 1 : -1) * w * 0.01f; x1 = (right ? -1 : 1) * w * 0.025f; y0 = 0; y1 = -dpF(10);
        }
        in.setScaleX(s0); in.setScaleY(s0); in.setTranslationX(x0); in.setTranslationY(y0);
        /* um só movimento contínuo durante todo o tempo em que a imagem está no ecrã (incluindo a saída) */
        android.animation.AnimatorSet mv = new android.animation.AnimatorSet();
        mv.playTogether(
                android.animation.ObjectAnimator.ofFloat(in, View.SCALE_X, s0, s1),
                android.animation.ObjectAnimator.ofFloat(in, View.SCALE_Y, s0, s1),
                android.animation.ObjectAnimator.ofFloat(in, View.TRANSLATION_X, x0, x1),
                android.animation.ObjectAnimator.ofFloat(in, View.TRANSLATION_Y, y0, y1));
        mv.setDuration(slideMs + XFADE * 2);
        mv.setInterpolator(new PathInterpolator(0.3f, 0f, 0.7f, 1f));
        mv.start(); motion[ni] = mv;
        /* dissolver cruzado, longo e suave; a imagem que sai continua o seu movimento enquanto desaparece */
        android.animation.ObjectAnimator fin = android.animation.ObjectAnimator.ofFloat(in, View.ALPHA, 0f, 1f);
        fin.setDuration(first ? 1600 : XFADE); fin.setInterpolator(EASE);
        fin.addListener(new AnimatorListenerAdapter() { @Override public void onAnimationEnd(Animator a) { in.setLayerType(View.LAYER_TYPE_NONE, null); } });
        fin.start(); fadeA[ni] = fin;
        if (!first) {
            final int oi = 1 - ni;
            if (fadeA[oi] != null) fadeA[oi].cancel();
            out.setLayerType(View.LAYER_TYPE_HARDWARE, null);
            android.animation.ObjectAnimator fout = android.animation.ObjectAnimator.ofFloat(out, View.ALPHA, out.getAlpha(), 0f);
            fout.setDuration(XFADE); fout.setInterpolator(EASE);
            fout.addListener(new AnimatorListenerAdapter() { @Override public void onAnimationEnd(Animator a) {
                out.setLayerType(View.LAYER_TYPE_NONE, null);
                if (motion[oi] != null && img[front] != out) motion[oi].cancel();
            } });
            fout.start(); fadeA[oi] = fout;
        }

        /* textos: os antigos desvanecem, os novos entram em cascata, devagar */
        final View[] tvs = {label, title, meta, plot};
        for (View v : tvs) v.animate().cancel();
        text.animate().cancel();
        text.animate().alpha(0f).translationY(-dpF(8)).setStartDelay(0).setDuration(first ? 0 : 700).setInterpolator(EASE).withEndAction(() -> {
            if (closed) return;
            label.setText(s.kind); title.setText(NativeData.shownName(s.it.name).replaceAll("\\s*\\(?\\b(19|20)\\d\\d\\)?\\s*$", ""));
            meta.setText(s.meta); meta.setVisibility(s.meta.isEmpty() ? View.GONE : View.VISIBLE);
            plot.setText(s.plot); plot.setVisibility(s.plot.isEmpty() ? View.GONE : View.VISIBLE);
            text.setTranslationY(0); text.setAlpha(1f);
            long d0 = first ? 300 : 500;
            for (View v : tvs) {
                v.setAlpha(0f); v.setTranslationY(dpF(14));
                v.animate().alpha(1f).translationY(0).setStartDelay(d0).setDuration(1100).setInterpolator(EASE_OUT).start();
                d0 += 160;
            }
        }).start();
        /* barra de tempo do título */
        progress.animate().cancel(); progress.setScaleX(0f);
        progress.animate().scaleX(1f).setStartDelay(0).setDuration(slideMs).setInterpolator(new LinearInterpolator()).start();
        next(false);
    }
    private float dpF(float v) { return v * den; }

    /** Adiciona ao ecrã por cima de tudo. */
    void attach(ViewGroup parent) {
        parent.addView(root, new ViewGroup.LayoutParams(-1, -1));
        start();
    }
    void detach() {
        stop();
        final ViewGroup p = root.getParent() instanceof ViewGroup ? (ViewGroup) root.getParent() : null;
        if (p == null) return;
        root.animate().alpha(0f).setDuration(250).withEndAction(() -> { try { p.removeView(root); } catch (Throwable ignored) { } }).start();
    }
}
