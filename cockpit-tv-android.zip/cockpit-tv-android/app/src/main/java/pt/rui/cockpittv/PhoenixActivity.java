package pt.rui.cockpittv;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

/**
 * v282: reinício limpo da app (processo à parte). Quando o descodificador de vídeo da TV fica preso
 * («Player release timed out» e depois «Decoder init failed» em todos os canais), só terminar o processo o liberta.
 * Esta atividade corre noutro processo: termina o principal e volta a abrir a app no canal/filme que estava a dar.
 */
public class PhoenixActivity extends Activity {
    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        overridePendingTransition(0, 0);
        try {
            int pid = getIntent().getIntExtra("pid", -1);
            if (pid > 0) android.os.Process.killProcess(pid);
        } catch (Throwable ignored) { }
        Intent next = getIntent().getParcelableExtra("next");
        if (next == null) next = new Intent(this, NativeHomeActivity.class);
        next.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        final Intent fn = next;
        getWindow().getDecorView().postDelayed(() -> {
            try { startActivity(fn); overridePendingTransition(0, 0); } catch (Throwable ignored) { }
            finish();
            android.os.Process.killProcess(android.os.Process.myPid());
        }, 400);
    }
}
