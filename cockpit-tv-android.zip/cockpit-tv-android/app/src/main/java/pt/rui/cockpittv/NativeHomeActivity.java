package pt.rui.cockpittv;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.drawable.StateListDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.InputType;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.LruCache;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.view.inputmethod.EditorInfo;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/**
 * Cockpit TV nativo (v271): a única app. Canais, filmes, séries (fichas, temporadas, continuar a ver, vistos),
 * favoritos, pesquisa, legendas online, transmitir (Chromecast), «Continuar a ver» no ecrã inicial da TV e definições.
 * A reprodução usa o NativePlayer e o ecrã de canal NativeScreen.
 */
public class NativeHomeActivity extends Activity {
    /* as cores e medidas da app antiga (Início da TV): fundo azul-noite, barra em gradiente, botões em pílula, cartões de 18 dp */
    private static final int BG = 0xFF0A101C, PANEL = 0x660F1622, CARD = 0xFF141C28, ACC = 0xFF7CC4FF, INK = 0xFF06213A, TXT = 0xFFE6EDF6, MUT = 0xFF8C9BB0, OK = 0xFF5CD68A;
    private static final String[] TAB_ID = {"live", "movie", "series", "fav", "recent", "search"};
    private static final String[] TAB_L = {"Canais", "Filmes", "Séries", "★ Favoritos", "🕘 Vistos", "Pesquisar"};
    private static final String[] TAB_ICON = {"Canais", "Filmes", "Séries", "", "", "Pesquisar"};

    private final Handler ui = new Handler(Looper.getMainLooper());
    private final ExecutorService bg = Executors.newFixedThreadPool(3);
    private final ExecutorService img = Executors.newFixedThreadPool(6);
    private final LruCache<String, Bitmap> bmp = new LruCache<String, Bitmap>(28 * 1024 * 1024) {
        @Override protected int sizeOf(String k, Bitmap b) { return b.getByteCount(); }
    };

    private NativeData data;
    private FrameLayout root;
    private LinearLayout body;
    private final TextView[] tabs = new TextView[TAB_ID.length];
    private ListView catList;
    private GridView grid;
    private TextView status, sortBtn;
    private ProgressBar spin;
    private EditText searchBox;
    private View settingsView;
    private FrameLayout details;
    private FrameLayout appLayer;
    /* secções da barra de cima (como na app antiga): Início, Explorar, Guia, Definições, Cast */
    private String section = "home";
    private JSONObject navCfg = new JSONObject();
    private final java.util.Map<String, Bitmap> kindIcons = new java.util.HashMap<>();
    private LinearLayout navBar, browseCol, chipsRow, statusRow, homeCol, homeRows, homeKinds;
    private ScrollView homeScroll;
    private TextView clock, heroLabel, heroTitle, heroSub, heroBtn1, heroBtn2, heroArtIni;
    private FrameLayout heroArt;
    private ImageView heroArtImg;
    /* pré-visualização do Início: canal escolhido (ou o último visto), a lista de onde veio, e o que está a dar */
    private NativeData.Item heroItem = null;
    private List<NativeData.Item> heroList = null;
    private int heroIdx = 0;
    private String pvUrl = null;
    private long pvT0 = 0;
    private boolean pvOff = false, pvLastVis = true;
    private String homeKind = "live";
    private int homeSeq = 0;
    private View lastHomeFocus = null;
    private final java.util.Map<String, String> epgCache = new java.util.HashMap<>();

    private String tab = "live";
    private List<NativeData.Cat> curCats = new ArrayList<>();
    private int curCat = 0;
    private String shownKey = "";
    private List<NativeData.Item> curItems = new ArrayList<>();
    /** série aberta (temporadas na coluna, episódios na grelha); null fora das séries */
    private NativeData.Item openSeries = null;
    private List<NativeData.Item> seriesEps = new ArrayList<>();
    private int seriesCatBefore = 0, seriesPosBefore = 0;
    private int loadSeq = 0;

    private NativePlayer np;
    private NativeScreen nscr;
    private CastHelper cast;
    private boolean castWanted = false;
    private List<NativeData.Item> playing = new ArrayList<>();
    private NativeData.Item nowItem = null;
    private List<String[]> osRes = new ArrayList<>();
    private String pendingOpen = null, pendingQuery = null;

    /** Escala do layout (v273): o desenho é o da app antiga a 1280×720; na TV fica ~0,9, no telemóvel deitado ~0,6, ao alto pela largura. */
    private float S = 1f;
    private void computeScale() {
        android.util.DisplayMetrics m = getResources().getDisplayMetrics();
        float w = m.widthPixels / m.density, h = m.heightPixels / m.density;
        float s = w >= h ? Math.min(w / 1280f, h / 720f) : w / 640f;
        S = Math.max(0.5f, Math.min(1.25f, s));
    }
    private boolean portrait() { android.util.DisplayMetrics m = getResources().getDisplayMetrics(); return m.widthPixels < m.heightPixels; }
    private int dp(float v) { return (int) (v * S * getResources().getDisplayMetrics().density + 0.5f); }
    /** tamanho de letra em píxeis, com a mesma escala */
    private float fz(float sp) { return sp * S * getResources().getDisplayMetrics().density; }

    @Override
    protected void attachBaseContext(android.content.Context base) {
        try {
            float sc = MainActivity.uiScaleOf(base);
            if (Math.abs(sc - 1f) > 0.01f) {
                android.content.res.Configuration cfg = new android.content.res.Configuration(base.getResources().getConfiguration());
                cfg.densityDpi = Math.round(cfg.densityDpi * sc);
                super.attachBaseContext(base.createConfigurationContext(cfg));
                return;
            }
        } catch (Throwable ignored) { }
        super.attachBaseContext(base);
    }

    @Override
    protected void onCreate(Bundle b) {
        super.onCreate(b);
        overridePendingTransition(0, 0);   /* abre direto, sem animação */
        PiconCache.init(this);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        data = new NativeData(this);
        root = new FrameLayout(this);
        root.setBackgroundColor(BG);
        setContentView(root);
        immersive();
        computeScale();
        buildUi();
        readIntent(getIntent());
        if (!data.configured()) {
            /* primeira vez: tenta trazer a lista, os favoritos e os vistos da app antiga (estão guardados no aparelho) */
            setStatus("A procurar os dados da app antiga…", true);
            importOld(ok -> { if (ok) showSection("home"); else showSection("settings"); });
            return;
        }
        if (pendingQuery != null) showTab("search"); else showSection("home");
        afterStart();
        /* v278: telemóvel: o som Dolby (E-AC-3) volta a ser descodificado pela app (o descodificador Dolby do Samsung adianta o som) */
        if (!isTv() && !getSharedPreferences("nativeapp", 0).getBoolean("dolbyMig278", false)) {
            np0().edit().remove("dolbySw").remove("av_spk_dolby").apply();
            getSharedPreferences("nativeapp", 0).edit().putBoolean("dolbyMig278", true).apply();
        }
        if (!getSharedPreferences("nativeapp", 0).getBoolean("extras3Done", false)) importExtras(() -> { opCache = null; if ("home".equals(section)) renderHome(); });
    }

    @Override
    protected void onNewIntent(Intent i) {
        super.onNewIntent(i);
        readIntent(i);
        if (pendingQuery != null) { showTab("search"); }
        afterStart();
    }

    /** cockpittv://play?id=<endereço> (Continuar a ver do ecrã inicial) e pesquisa por voz. */
    private void readIntent(Intent intent) {
        try {
            if (intent == null) return;
            String a = intent.getAction();
            if (a != null && (a.equals(Intent.ACTION_SEARCH) || a.equals("com.google.android.gms.actions.SEARCH_ACTION"))) {
                String q = intent.getStringExtra("query");
                if (q == null || q.isEmpty()) q = intent.getStringExtra(android.app.SearchManager.QUERY);
                if (q != null && !q.trim().isEmpty()) pendingQuery = q.trim();
                return;
            }
            Uri d = intent.getData();
            if (d != null && "cockpittv".equals(d.getScheme())) pendingOpen = d.getQueryParameter("id");
        } catch (Throwable ignored) { }
    }

    private void afterStart() {
        if (pendingQuery != null && searchBox != null) { searchBox.setText(pendingQuery); pendingQuery = null; }
        final String id = pendingOpen; pendingOpen = null;
        if (id == null || id.isEmpty()) return;
        ensureAllLoaded(() -> {
            NativeData.Item it = data.findByUrl(id);
            if (it == null) { Toast.makeText(this, "Já não encontro esse vídeo na lista.", Toast.LENGTH_LONG).show(); return; }
            if ("episode".equals(it.kind) && it.sid.length() > 0) playEpisode(it.sid, it.url);
            else { List<NativeData.Item> one = new ArrayList<>(); one.add(it); play(one, 0, -1); }
        });
    }

    /* ------------------------------------------------------------ importar da app antiga (sem a abrir) */
    private interface Done { void run(boolean ok); }
    private void importOld(final Done done) {
        if (data.importFromWeb()) { done.run(true); return; }   /* a v270 clássica já tinha partilhado os dados */
        final boolean[] fin = {false};
        final Runnable timeout = () -> { if (!fin[0]) { fin[0] = true; done.run(false); } };
        try {
            final WebView w = new WebView(this);
            w.getSettings().setJavaScriptEnabled(true);
            w.getSettings().setDomStorageEnabled(true);
            w.getSettings().setAllowFileAccess(true);
            w.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView v, String u) {
                    v.evaluateJavascript("(function(){try{return JSON.stringify({c:localStorage.getItem('ck_cfg')||'',f:localStorage.getItem('ck_tvfavs')||'[]',r:localStorage.getItem('ck_tvRecent')||'[]'})}catch(e){return ''}})()", val -> {
                        boolean ok = false;
                        try {
                            if (val != null && val.length() > 4 && !"null".equals(val)) {
                                JSONObject o = new JSONObject(new JSONArray("[" + val + "]").getString(0));
                                ok = data.importJson(o.optString("c"), o.optString("f", "[]"), o.optString("r", "[]"));
                            }
                        } catch (Throwable ignored) { }
                        try { w.destroy(); } catch (Throwable ignored) { }
                        if (!fin[0]) { fin[0] = true; ui.removeCallbacks(timeout); done.run(ok); }
                    });
                }
            });
            /* a página antiga corria em file:///android_asset/: o mesmo endereço base dá acesso ao que ela guardou */
            w.loadDataWithBaseURL("file:///android_asset/index.html", "<html><body></body></html>", "text/html", "utf-8", null);
            ui.postDelayed(timeout, 8000);
        } catch (Throwable e) { timeout.run(); }
    }

    /** v274: as escolhas de operador, imagem, som e legendas que estavam na app antiga (uma vez). */
    private void importExtras(final Runnable after) {
        final android.content.SharedPreferences ns = getSharedPreferences("nativeapp", 0);
        try {
            final WebView w = new WebView(this);
            w.getSettings().setJavaScriptEnabled(true);
            w.getSettings().setDomStorageEnabled(true);
            w.setWebViewClient(new WebViewClient() {
                @Override public void onPageFinished(WebView v, String u) {
                    v.evaluateJavascript("(function(){try{var g=function(k){return localStorage.getItem('ck_'+k)};return JSON.stringify({op:g('tvOp'),opc:g('tvOpCustom'),afr:g('tvAfr'),dei:g('tvDeint'),tun:g('tvTunnel'),fsl:g('fsList'),prv:g('tvPrev'),snd:g('tvPrevSnd'),an:g('tvAnim'),vf:g('tvVfx'),tok:g('dbgTok'),org:g('tvOrg'),cty:localStorage.getItem('ck_tvCty'),cfg:g('ck_cfg')||g('cfg')})}catch(e){return ''}})()", val -> {
                        try {
                            JSONObject o = new JSONObject(new JSONArray("[" + val + "]").getString(0));
                            android.content.SharedPreferences.Editor e = ns.edit();
                            android.content.SharedPreferences.Editor n = getSharedPreferences("np", 0).edit();
                            if (!ns.getBoolean("extrasDone", false)) {   /* o resto só na 1.ª vez (não desfaz o que mudaste depois) */
                            String op = js(o, "op"); if (op != null) e.putString("tvOp", op);
                            String opc = js(o, "opc"); if (opc != null) e.putString("tvOpCustom", opc);
                            String prv = js(o, "prv"); if (prv != null) e.putBoolean("tvPrev", !"off".equals(prv));
                            String snd = js(o, "snd"); if (snd != null) e.putBoolean("tvPrevSnd", "on".equals(snd));
                            String afr = js(o, "afr"); if (afr != null) n.putBoolean("afr", !"off".equals(afr));
                            String dei = js(o, "dei"); if (dei != null) n.putBoolean("deint", "adapt".equals(dei));
                            String tun = js(o, "tun"); if (tun != null) n.putBoolean("tunnel", "true".equals(tun));
                            String fsl = js(o, "fsl"); if (fsl != null) n.putString("fsList", "off".equals(fsl) ? "off" : "all");
                            }
                            if (!ns.getBoolean("extras3Done", false)) { String og = js(o, "org"); String cy = o.isNull("cty") ? null : o.optString("cty", null); data.importOrg(og, cy); }
                            String an = js(o, "an"); if (an != null) e.putString("tvAnim", an);
                            String vf = js(o, "vf"); if (vf != null) e.putString("tvVfx", vf);
                            String tok = js(o, "tok"); if (tok != null && tok.length() > 3 && ns.getString("dbgTok", "").isEmpty()) e.putString("dbgTok", tok);
                            String cf = o.optString("cfg", ""); 
                            if (cf.length() > 2) { JSONObject cj = new JSONObject(cf); JSONObject ss = cj.optJSONObject("subStyle"); if (ss != null && !ns.getBoolean("extrasDone", false)) n.putString("subStyle", ss.toString()); String rp = cj.optString("dbgRepo", ""); if (rp.length() > 3) e.putString("dbgRepo", rp); }
                            e.putBoolean("extrasDone", true).putBoolean("extras2Done", true).putBoolean("extras3Done", true).apply(); n.apply();
                        } catch (Throwable ignored) { ns.edit().putBoolean("extrasDone", true).apply(); }
                        try { w.destroy(); } catch (Throwable ignored) { }
                        if (after != null) after.run();
                    });
                }
            });
            w.loadDataWithBaseURL("file:///android_asset/index.html", "<html><body></body></html>", "text/html", "utf-8", null);
        } catch (Throwable e) { ns.edit().putBoolean("extrasDone", true).apply(); }
    }
    /** valor guardado pela página (JSON): "\"meo\"" → meo; null se não existir */
    private static String js(JSONObject o, String k) {
        if (o.isNull(k)) return null;
        String v = o.optString(k, null); if (v == null) return null;
        try { Object x = new JSONArray("[" + v + "]").get(0); return String.valueOf(x); } catch (Throwable e) { return v; }
    }

    /* ------------------------------------------------------------ preferências de som e imagem (v274) */
    private android.content.SharedPreferences np0() { return getSharedPreferences("np", 0); }
    private static final String[] SUB_SIZE_L = {"Pequeno", "Normal", "Grande", "Enorme"};
    private static final int[] SUB_SIZE = {70, 100, 140, 190};
    private static final String[] SUB_COL_L = {"Branco", "Amarelo", "Verde", "Ciano"};
    private static final int[] SUB_COL = {0xFFFFFFFF, 0xFFFFEB3B, 0xFF66FF66, 0xFF00E5FF};
    private static final String[] SUB_BG_L = {"Sem fundo", "Transparente", "Preto"};
    private static final int[] SUB_BG = {0, 0x99000000, 0xFF000000};
    private static final String[] SUB_EDGE_L = {"Nenhum", "Sombra", "Contorno"};
    private static final String[] SUB_POS_L = {"Em baixo", "Meio", "Alto"};
    private static final float[] SUB_POS = {0.08f, 0.2f, 0.35f};
    private int subPref(String k, int def) { try { return new JSONObject(np0().getString("subStyle", "{}")).optInt(k, def); } catch (Throwable e) { return def; } }
    private void setSubPref(String k, int v) { try { JSONObject o = new JSONObject(np0().getString("subStyle", "{}")); o.put(k, v); np0().edit().putString("subStyle", o.toString()).apply(); } catch (Throwable ignored) { } applyPlayerPrefs(); }
    /** Aplica ao leitor: taxa de atualização, desentrelaçamento e aspeto das legendas. */
    private void applyPlayerPrefs() {
        try {
            int sz = SUB_SIZE[cl(subPref("size", 1), 4)], fg = SUB_COL[cl(subPref("color", 0), 4)], bgc = SUB_BG[cl(subPref("bg", 1), 3)], ed = cl(subPref("edge", 1), 3);
            float pos = SUB_POS[cl(subPref("pos", 0), 3)];
            NativePlayer.subSizePct = sz; NativePlayer.subFg = fg; NativePlayer.subBg = bgc; NativePlayer.subEdge = ed; NativePlayer.subBottom = pos;
            if (np != null) {
                np.setSubStyle(sz, fg, bgc, ed, pos);
                np.setAfr(np0().getBoolean("afr", true));
                np.setDeint(np0().getBoolean("deint", false));
            }
        } catch (Throwable ignored) { }
    }
    private static int cl(int v, int n) { return Math.max(0, Math.min(n - 1, v)); }

    /* ------------------------------------------------------------ interface */
    private StateListDrawable sel(int base, int radius) {
        StateListDrawable s = new StateListDrawable();
        GradientDrawable f = new GradientDrawable(); f.setColor(0xFF22364A); f.setStroke(dp(2), ACC); f.setCornerRadius(dp(radius));
        GradientDrawable p = new GradientDrawable(); p.setColor(0xFF1E3044); p.setCornerRadius(dp(radius));
        GradientDrawable n = new GradientDrawable(); n.setColor(base); n.setCornerRadius(dp(radius));
        s.addState(new int[]{android.R.attr.state_focused}, f);
        s.addState(new int[]{android.R.attr.state_selected}, f);
        s.addState(new int[]{android.R.attr.state_pressed}, p);
        s.addState(new int[]{}, n);
        return s;
    }
    private GradientDrawable roundRect(int c, int r) { GradientDrawable g = new GradientDrawable(); g.setColor(c); g.setCornerRadius(dp(r)); return g; }

    /* ------------------------------------------------------------ aspeto (igual ao da app antiga) */
    private static String asset(android.content.Context c, String name) {
        try (InputStream in = c.getAssets().open(name)) {
            java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); byte[] b = new byte[16384]; int n;
            while ((n = in.read(b)) > 0) bo.write(b, 0, n);
            return bo.toString("UTF-8");
        } catch (Throwable e) { return ""; }
    }
    private static Bitmap b64(String s) {
        try { byte[] b = android.util.Base64.decode(s, android.util.Base64.DEFAULT); return BitmapFactory.decodeByteArray(b, 0, b.length); } catch (Throwable e) { return null; }
    }
    private int col(String k, int def) { try { return android.graphics.Color.parseColor(navCfg.optString(k, "")); } catch (Throwable e) { return def; } }

    /** Ícones dos botões do leitor e barra do ecrã do canal: os mesmos da app antiga (guardados na APK). */
    private void loadLook() {
        try { MainActivity.ICONS_JSON = asset(this, "ui/icons.json"); } catch (Throwable ignored) { }
        try { navCfg = new JSONObject(asset(this, "ui/nav.json")); } catch (Throwable ignored) { }
        try { JSONObject k = new JSONObject(asset(this, "ui/kinds.json")); java.util.Iterator<String> it = k.keys(); while (it.hasNext()) { String n = it.next(); Bitmap b = b64(k.optString(n)); if (b != null) kindIcons.put(n, b); } } catch (Throwable ignored) { }
    }
    /** Barra para o ecrã do canal (NativeScreen), com as medidas deste ecrã. */
    private String playerNavJson() {
        try {
            JSONObject o = new JSONObject(navCfg.toString());
            float d = getResources().getDisplayMetrics().density * S;
            boolean phone = getResources().getDisplayMetrics().widthPixels < getResources().getDisplayMetrics().heightPixels;
            o.put("phone", phone); o.put("sc", d); o.put("h", Math.round(72 * d)); o.put("fs", Math.round(16 * d)); o.put("cfs", Math.round(26 * d)); o.put("geo", false);
            return o.toString();
        } catch (Throwable e) { return ""; }
    }

    private GradientDrawable pill(int c, float r) { GradientDrawable g = new GradientDrawable(); g.setColor(c); g.setCornerRadius(dp(r)); return g; }
    private GradientDrawable ring(int c, float r) { GradientDrawable g = pill(c, r); g.setStroke(dp(3), 0xFFFFFFFF); return g; }

    /** Botão como os da app antiga (thBtn): ícone + texto, 14 dp de raio; o principal em azul claro. */
    private TextView thBtn(String text, Bitmap icon, final boolean primary, View.OnClickListener l) {
        final TextView b = new TextView(this);
        b.setText(text); b.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(17)); b.setGravity(Gravity.CENTER_VERTICAL); b.setSingleLine(true);
        b.setPadding(dp(20), dp(6), dp(20), dp(6)); b.setMinHeight(dp(44));
        b.setFocusable(true); b.setClickable(true);
        b.setCompoundDrawablePadding(dp(8));
        setPrimary(b, icon, primary);
        b.setOnFocusChangeListener((v, f) -> {
            boolean pr = Boolean.TRUE.equals(v.getTag());
            v.setBackground(f ? ring(pr ? ACC : 0x33FFFFFF, 14) : pill(pr ? ACC : 0x1FFFFFFF, 14));
            v.animate().scaleX(f ? 1.04f : 1f).scaleY(f ? 1.04f : 1f).setDuration(120).start();
        });
        if (l != null) b.setOnClickListener(l);
        return b;
    }
    private void setPrimary(TextView b, Bitmap icon, boolean primary) {
        b.setTag(primary);
        b.setTextColor(primary ? INK : TXT);
        b.setBackground(b.isFocused() ? ring(primary ? ACC : 0x33FFFFFF, 14) : pill(primary ? ACC : 0x1FFFFFFF, 14));
        if (icon != null) {
            android.graphics.drawable.BitmapDrawable d = new android.graphics.drawable.BitmapDrawable(getResources(), icon);
            d.setBounds(0, 0, dp(20), dp(20));
            d.setColorFilter(primary ? INK : TXT, android.graphics.PorterDuff.Mode.SRC_IN);
            b.setCompoundDrawables(d, null, null, null);
        }
    }

    private void buildUi() {
        loadLook();
        GradientDrawable lin = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{0xFF0A101C, 0xFF04070D});
        GradientDrawable glow = new GradientDrawable(); glow.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        glow.setColors(new int[]{0x337CC4FF, 0x00000000}); glow.setGradientRadius(dp(700)); glow.setGradientCenter(0.85f, -0.08f);
        root.setBackground(new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{lin, glow}));

        /* a interface fica numa camada própria por baixo do vídeo (o leitor junta a sua vista ao root, por cima) */
        appLayer = new FrameLayout(this);
        root.addView(appLayer, 0, new FrameLayout.LayoutParams(-1, -1));
        LinearLayout main = new LinearLayout(this);
        main.setOrientation(LinearLayout.VERTICAL);
        appLayer.addView(main, new FrameLayout.LayoutParams(-1, -1));
        buildNav();
        main.addView(navBar, new LinearLayout.LayoutParams(-1, dp(72)));
        FrameLayout content = new FrameLayout(this);
        main.addView(content, new LinearLayout.LayoutParams(-1, 0, 1));

        /* ---- Início ---- */
        homeScroll = new ScrollView(this);
        homeScroll.setFillViewport(true);
        homeScroll.setVerticalScrollBarEnabled(false);
        homeScroll.setClipToPadding(false);
        homeCol = new LinearLayout(this); homeCol.setOrientation(LinearLayout.VERTICAL);
        homeCol.setPadding(dp(48), dp(8), dp(48), dp(40)); homeCol.setClipChildren(false); homeCol.setClipToPadding(false);
        homeScroll.addView(homeCol);
        /* destaque (thHero): à esquerda a janela 16:9 com a pré-visualização do canal, à direita o texto e os botões */
        LinearLayout hero = new LinearLayout(this); hero.setOrientation(portrait() ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        hero.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable hg = new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF375778, 0xFF0D1526, 0xFF0D1526}); hg.setCornerRadius(dp(26));
        hero.setBackground(hg); hero.setPadding(dp(24), dp(14), dp(24), dp(14)); hero.setElevation(dp(10));
        heroArt = new FrameLayout(this);
        heroArt.setBackground(pill(0xCC0B1220, 8)); heroArt.setClipToOutline(true);
        heroArtImg = new ImageView(this); heroArtImg.setScaleType(ImageView.ScaleType.FIT_CENTER); heroArtImg.setPadding(dp(30), dp(20), dp(30), dp(20));
        heroArt.addView(heroArtImg, new FrameLayout.LayoutParams(-1, -1));
        heroArtIni = new TextView(this); heroArtIni.setTextColor(TXT); heroArtIni.setAlpha(0.6f); heroArtIni.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(44)); heroArtIni.setTypeface(null, Typeface.BOLD);
        heroArt.addView(heroArtIni, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        android.util.DisplayMetrics dm = getResources().getDisplayMetrics();
        int innerW = dm.widthPixels - dp(48) * 2 - dp(24) * 2;
        int aw = portrait() ? innerW : Math.max(dp(280), Math.min(dp(680), (int) (innerW * 0.42f)));
        if (!portrait()) aw = Math.min(aw, (int) ((dm.heightPixels * 0.34f) * 16 / 9));   /* deitado: a janela não passa de ~1/3 da altura, para as filas ficarem à vista */
        LinearLayout.LayoutParams al = new LinearLayout.LayoutParams(aw, aw * 9 / 16);
        if (portrait()) al.bottomMargin = dp(12); else al.rightMargin = dp(20);
        hero.addView(heroArt, al);
        heroArt.setVisibility(View.GONE);
        heroArt.addOnLayoutChangeListener((q0, q1, q2, q3, q4, q5, q6, q7, q8) -> placePreview());
        LinearLayout htx = new LinearLayout(this); htx.setOrientation(LinearLayout.VERTICAL);
        heroLabel = new TextView(this); heroLabel.setText("COCKPIT TV"); heroLabel.setTextColor(TXT); heroLabel.setAlpha(0.7f); heroLabel.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(12)); heroLabel.setLetterSpacing(0.14f); heroLabel.setSingleLine(true);
        heroTitle = new TextView(this); heroTitle.setText("Bem-vindo"); heroTitle.setTextColor(TXT); heroTitle.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(28)); heroTitle.setTypeface(null, Typeface.BOLD); heroTitle.setLetterSpacing(0.03f); heroTitle.setSingleLine(true); heroTitle.setEllipsize(TextUtils.TruncateAt.END);
        heroSub = new TextView(this); heroSub.setText("Escolhe um canal em baixo para começar."); heroSub.setTextColor(TXT); heroSub.setAlpha(0.85f); heroSub.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(16)); heroSub.setMaxLines(2); heroSub.setEllipsize(TextUtils.TruncateAt.END);
        htx.addView(heroLabel);
        LinearLayout.LayoutParams tl = new LinearLayout.LayoutParams(-1, -2); tl.topMargin = dp(4); htx.addView(heroTitle, tl);
        LinearLayout.LayoutParams sl = new LinearLayout.LayoutParams(-1, -2); sl.topMargin = dp(4); htx.addView(heroSub, sl);
        LinearLayout hb = new LinearLayout(this); hb.setClipChildren(false);
        heroBtn1 = thBtn("Explorar canais", kindIcons.get("Explorar canais"), true, v -> heroPrimary());
        heroBtn2 = thBtn("Definições", kindIcons.get("Definições"), false, v -> heroSecondary());
        LinearLayout.LayoutParams bl = new LinearLayout.LayoutParams(-2, dp(44)); bl.rightMargin = dp(12);
        hb.addView(heroBtn1, bl); hb.addView(heroBtn2, new LinearLayout.LayoutParams(-2, dp(44)));
        LinearLayout.LayoutParams hbl = new LinearLayout.LayoutParams(-1, -2); hbl.topMargin = dp(10); htx.addView(hb, hbl);
        hero.addView(htx, new LinearLayout.LayoutParams(portrait() ? -1 : 0, -2, portrait() ? 0 : 1));
        LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(-1, -2); hl.topMargin = dp(2); hl.bottomMargin = dp(6);
        homeCol.addView(hero, hl);
        homeScroll.setOnScrollChangeListener((q0, q1, q2, q3, q4) -> { placePreview(); fxSoon(); });
        homeKinds = new LinearLayout(this); homeKinds.setClipChildren(false); homeKinds.setPadding(0, dp(4), 0, dp(4));
        String[][] K = {{"live", "Canais"}, {"movie", "Filmes"}, {"series", "Séries"}};
        homeKind = getSharedPreferences("nativeapp", 0).getString("homeKind", "live");
        for (final String[] k : K) {
            TextView c = thBtn(k[1], kindIcons.get(k[1]), k[0].equals(homeKind), v -> { if (homeKind.equals(k[0])) return; homeKind = k[0]; getSharedPreferences("nativeapp", 0).edit().putString("homeKind", homeKind).apply(); markKinds(); renderHome(); });
            c.setContentDescription(k[0]);
            LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, dp(44)); cl.rightMargin = dp(12);
            homeKinds.addView(c, cl);
        }
        homeKinds.addView(thBtn("Pesquisar", kindIcons.get("Pesquisar"), false, v -> showTab("search")), new LinearLayout.LayoutParams(-2, dp(44)));
        LinearLayout.LayoutParams kl = new LinearLayout.LayoutParams(-1, -2); kl.topMargin = dp(12); kl.bottomMargin = dp(4);
        homeCol.addView(homeKinds, kl);
        homeRows = new LinearLayout(this); homeRows.setOrientation(LinearLayout.VERTICAL); homeRows.setClipChildren(false);
        homeCol.addView(homeRows, new LinearLayout.LayoutParams(-1, -2));
        content.addView(homeScroll, new FrameLayout.LayoutParams(-1, -1));

        /* ---- Explorar / Guia / Definições ---- */
        browseCol = new LinearLayout(this);
        browseCol.setOrientation(LinearLayout.VERTICAL);
        content.addView(browseCol, new FrameLayout.LayoutParams(-1, -1));
        HorizontalScrollView hs = new HorizontalScrollView(this);
        hs.setHorizontalScrollBarEnabled(false); hs.setClipToPadding(false);
        chipsRow = new LinearLayout(this);
        chipsRow.setPadding(dp(48), dp(12), dp(48), dp(6)); chipsRow.setClipChildren(false);
        for (int i = 0; i < TAB_ID.length; i++) {
            final String id = TAB_ID[i];
            TextView t = thBtn(TAB_L[i], kindIcons.get(TAB_ICON[i]), false, v -> showTab(id));
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(44)); lp.rightMargin = dp(12);
            chipsRow.addView(t, lp);
            tabs[i] = t;
        }
        hs.addView(chipsRow);
        browseCol.addView(hs, new LinearLayout.LayoutParams(-1, -2));

        statusRow = new LinearLayout(this);
        statusRow.setGravity(Gravity.CENTER_VERTICAL);
        statusRow.setPadding(dp(52), dp(2), dp(48), dp(6));
        spin = new ProgressBar(this); spin.setIndeterminate(true); spin.setVisibility(View.GONE);
        statusRow.addView(spin, new LinearLayout.LayoutParams(dp(18), dp(18)));
        status = new TextView(this); status.setTextColor(MUT); status.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(14)); status.setPadding(dp(8), 0, 0, 0);
        status.setSingleLine(true); status.setEllipsize(TextUtils.TruncateAt.END);
        statusRow.addView(status, new LinearLayout.LayoutParams(0, -2, 1));
        sortBtn = thBtn("⇅", null, false, v -> pickSort());
        sortBtn.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(15)); sortBtn.setMinHeight(dp(36));
        sortBtn.setVisibility(View.GONE);
        statusRow.addView(sortBtn, new LinearLayout.LayoutParams(-2, dp(38)));
        browseCol.addView(statusRow, new LinearLayout.LayoutParams(-1, -2));

        searchBox = new EditText(this);
        searchBox.setHint("Nome do canal, filme ou série…"); searchBox.setHintTextColor(MUT); searchBox.setTextColor(TXT); searchBox.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(17));
        searchBox.setSingleLine(true); searchBox.setImeOptions(EditorInfo.IME_ACTION_SEARCH);
        searchBox.setOnEditorActionListener((v, a, e) -> {   /* v278: a lupa do teclado fecha o teclado e mostra os resultados */
            boolean go = a == EditorInfo.IME_ACTION_SEARCH || a == EditorInfo.IME_ACTION_DONE || (e != null && e.getKeyCode() == KeyEvent.KEYCODE_ENTER && e.getAction() == KeyEvent.ACTION_DOWN);
            if (!go) return false;
            hideKb(v);
            ui.removeCallbacks(doSearch); runSearch();
            ui.postDelayed(() -> { if (!curItems.isEmpty()) { grid.requestFocus(); grid.setSelection(0); } }, 150);
            return true;
        });
        searchBox.setBackground(sel(0x1FFFFFFF, 14)); searchBox.setPadding(dp(18), dp(10), dp(18), dp(10));
        searchBox.setVisibility(View.GONE);
        searchBox.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) { ui.removeCallbacks(doSearch); ui.postDelayed(doSearch, 350); }
        });
        LinearLayout.LayoutParams slp = new LinearLayout.LayoutParams(-1, -2); slp.setMargins(dp(48), dp(2), dp(48), dp(8));
        browseCol.addView(searchBox, slp);

        body = new LinearLayout(this);
        body.setPadding(dp(40), 0, dp(40), 0);
        browseCol.addView(body, new LinearLayout.LayoutParams(-1, 0, 1));

        catList = new ListView(this);
        catList.setDivider(null); catList.setSelector(sel(0x00000000, 14)); catList.setDrawSelectorOnTop(false);
        catList.setBackground(pill(0x59141C28, 18)); catList.setPadding(dp(6), dp(6), dp(6), dp(6)); catList.setClipToPadding(false);
        catList.setVerticalScrollBarEnabled(false);
        catList.setAdapter(catAdapter);
        catList.setOnItemClickListener((p, v, pos, id) -> pickCat(pos, true));
        catList.setOnItemLongClickListener((p, v, pos, id) -> { catMenu(pos); return true; });
        catList.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) {
                /* comando da TV: percorrer as categorias já mostra os itens (com um pequeno atraso para não pesar) */
                final int ps = pos; ui.removeCallbacks(catSelRun); catSelRun = () -> pickCat(ps, false); ui.postDelayed(catSelRun, 220);
            }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
        body.addView(catList, new LinearLayout.LayoutParams(dp(270), -1));

        grid = new GridView(this);
        grid.setSelector(sel(0x00000000, 18)); grid.setDrawSelectorOnTop(true);
        grid.setPadding(dp(14), dp(6), dp(8), dp(16)); grid.setClipToPadding(false);
        grid.setVerticalSpacing(dp(14)); grid.setHorizontalSpacing(dp(14));
        grid.setStretchMode(GridView.STRETCH_COLUMN_WIDTH);
        grid.setLayoutAnimation(null); grid.setVerticalScrollBarEnabled(false);
        grid.setAdapter(gridAdapter);
        grid.setOnItemClickListener((p, v, pos, id) -> onItem(pos));
        grid.setOnItemLongClickListener((p, v, pos, id) -> { itemMenu(pos); return true; });
        grid.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(AdapterView<?> p, View v, int pos, long id) { if ("guide".equals(section) && pos >= 0 && pos < curItems.size()) wantEpg(curItems.get(pos)); }
            @Override public void onNothingSelected(AdapterView<?> p) { }
        });
        body.addView(grid, new LinearLayout.LayoutParams(0, -1, 1));
        browseCol.setVisibility(View.GONE);
        ui.post(clockTick);
    }

    /* ------------------------------------------------------------ barra de cima */
    private final java.util.Map<String, View> navTabs = new java.util.HashMap<>();
    private Bitmap navIcon(String id) {
        JSONArray t = navCfg.optJSONArray("tabs"); if (t == null) return null;
        for (int i = 0; i < t.length(); i++) { JSONObject o = t.optJSONObject(i); if (o != null && id.equals(o.optString("id"))) return b64(o.optString("icon")); }
        return null;
    }
    private final Runnable clockTick = new Runnable() { @Override public void run() {
        try { if (clock != null) clock.setText(new java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(new java.util.Date())); } catch (Throwable ignored) { }
        ui.postDelayed(this, 10000);
    } };
    private static String secOf(String navId) { return "tvhome".equals(navId) ? "home" : "tv".equals(navId) ? "explore" : navId; }

    private void buildNav() {
        navBar = new LinearLayout(this);
        navBar.setGravity(Gravity.CENTER_VERTICAL);
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TOP_BOTTOM, new int[]{col("c1", 0xFF2D4966), col("c2", 0xFF18293C)});
        android.graphics.drawable.LayerDrawable ld = new android.graphics.drawable.LayerDrawable(new android.graphics.drawable.Drawable[]{bg, new android.graphics.drawable.ColorDrawable(col("bd", 0xFF49759C))});
        try { ld.setLayerHeight(1, dp(2)); ld.setLayerGravity(1, Gravity.BOTTOM); } catch (Throwable ignored) { }
        navBar.setBackground(ld);
        navBar.setPadding(dp(28), 0, dp(14), 0);
        navBar.setElevation(dp(6));
        clock = new TextView(this);
        clock.setTextColor(0xFFFFFFFF); clock.setTypeface(Typeface.DEFAULT_BOLD); clock.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(26)); clock.setSingleLine(true);
        LinearLayout.LayoutParams cl = new LinearLayout.LayoutParams(-2, -2); cl.rightMargin = dp(24);
        navBar.addView(clock, cl);
        HorizontalScrollView hs = new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); hs.setFillViewport(false);
        LinearLayout tabsL = new LinearLayout(this); tabsL.setGravity(Gravity.CENTER_VERTICAL);
        hs.addView(tabsL);
        JSONArray t = navCfg.optJSONArray("tabs");
        if (t == null || t.length() == 0) {
            t = new JSONArray();
            try { for (String[] x : new String[][]{{"tvhome", "Início"}, {"tv", "Explorar"}, {"guide", "Guia"}, {"settings", "Definições"}, {"cast", "Cast"}}) t.put(new JSONObject().put("id", x[0]).put("label", x[1])); } catch (Throwable ignored) { }
        }
        for (int i = 0; i < t.length(); i++) {
            final JSONObject o = t.optJSONObject(i); if (o == null) continue;
            final String id = o.optString("id");
            final LinearLayout tab = new LinearLayout(this);
            tab.setGravity(Gravity.CENTER); tab.setPadding(dp(22), dp(6), dp(22), dp(6));
            final ImageView iv = new ImageView(this);
            tab.addView(iv, new LinearLayout.LayoutParams(dp(22), dp(22)));
            final TextView lb = new TextView(this);
            lb.setText(o.optString("label")); lb.setSingleLine(true); lb.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(16));
            LinearLayout.LayoutParams ll = new LinearLayout.LayoutParams(-2, -2); ll.leftMargin = dp(8);
            tab.addView(lb, ll);
            tab.setTag(new Object[]{iv, lb, b64(o.optString("icon")), b64(o.optString("iconA"))});
            tab.setFocusable(true); tab.setClickable(true);
            tab.setOnFocusChangeListener((v, f) -> styleTab(tab, id));
            tab.setOnClickListener(v -> {
                if ("cast".equals(id)) { startCast(); return; }
                if ("mirror".equals(id)) return;
                showSection(secOf(id));
            });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(50)); lp.rightMargin = dp(8);
            tabsL.addView(tab, lp);
            navTabs.put(id, tab);
            styleTab(tab, id);
        }
        navBar.addView(hs, new LinearLayout.LayoutParams(0, -1, 1));
    }

    private void styleTab(View tab, String id) {
        Object[] p = (Object[]) tab.getTag();
        boolean cur = secOf(id).equals(section);
        boolean f = tab.isFocused();
        GradientDrawable g = pill(cur ? ACC : (f ? 0x22FFFFFF : 0x00000000), 999);
        if (f) g.setStroke(dp(3), 0xFFFFFFFF);
        tab.setBackground(g);
        tab.setAlpha(cur || f ? 1f : 0.82f);
        Bitmap ic = (Bitmap) (cur && p[3] != null ? p[3] : p[2]);
        ((ImageView) p[0]).setImageBitmap(ic);
        ((TextView) p[1]).setTextColor(cur ? col("ink", INK) : 0xFFE6EEF9);
        ((TextView) p[1]).setTypeface(Typeface.DEFAULT_BOLD);
    }

    /** Muda de secção (Início / Explorar / Guia / Definições), sem animação. */
    private void showSection(String sec) {
        closeDetails();
        section = sec;
        for (java.util.Map.Entry<String, View> e : navTabs.entrySet()) styleTab(e.getValue(), e.getKey());
        boolean home = "home".equals(sec);
        if (!home) stopPreview();
        homeScroll.setVisibility(home ? View.VISIBLE : View.GONE);
        browseCol.setVisibility(home ? View.GONE : View.VISIBLE);
        if (home) { renderHome(); return; }
        if ("settings".equals(sec)) { chipsRow.setVisibility(View.GONE); setPage = ""; showTab("settings"); return; }
        chipsRow.setVisibility("guide".equals(sec) ? View.GONE : View.VISIBLE);
        if ("guide".equals(sec)) { showTab("live"); setStatus("Guia: escolhe uma categoria; o programa a decorrer aparece em cada canal.", false); return; }
        showTab(tab == null || "settings".equals(tab) ? "live" : tab);
    }

    private void markKinds() {
        for (int i = 0; i < homeKinds.getChildCount(); i++) {
            View v = homeKinds.getChildAt(i);
            if (!(v instanceof TextView) || v.getContentDescription() == null) continue;
            String k = v.getContentDescription().toString();
            setPrimary((TextView) v, kindIcons.get(((TextView) v).getText().toString()), k.equals(homeKind));
        }
    }

    private void markTabs() {
        for (int i = 0; i < TAB_ID.length; i++) setPrimary(tabs[i], kindIcons.get(TAB_ICON[i]), TAB_ID[i].equals(tab));
    }

    /* ------------------------------------------------------------ Início: destaque + filas de cartões */
    private static final java.util.regex.Pattern PT = java.util.regex.Pattern.compile("(^|[^A-Za-zÀ-ÿ])(PT|PT-PT|PORTUGAL|PORTUGU[EÊ]S|PORTUGUESA)([^A-Za-zÀ-ÿ]|$)|🇵🇹", java.util.regex.Pattern.CASE_INSENSITIVE);

    private void renderHome() {
        refreshHero();
        if (!data.configured()) { homeRows.removeAllViews(); homeRows.addView(emptyMsg("Sem lista configurada. Abre as Definições.")); return; }
        final String kind = homeKind;
        final int seq = ++homeSeq;
        bg.execute(() -> {
            try { data.load(kind, false); } catch (Throwable ignored) { }
            final List<Object[]> rows = new ArrayList<>();
            if (!"live".equals(kind)) {
                List<NativeData.Item> c = "movie".equals(kind) ? data.continueMovies() : data.continueSeries();
                if (!c.isEmpty()) rows.add(new Object[]{"▶ Continuar a ver", c.subList(0, Math.min(20, c.size())), c.size()});
            }
            List<NativeData.Item> fav = new ArrayList<>();
            for (NativeData.Item x : data.favItems()) if (kind.equals(x.kind)) fav.add(x);
            if (!fav.isEmpty()) rows.add(new Object[]{"⭐ Favoritos", fav.subList(0, Math.min(40, fav.size())), fav.size()});
            List<NativeData.Item> rec = new ArrayList<>(); java.util.Set<String> seen = new java.util.HashSet<>();
            for (NativeData.Item x : data.recents()) {
                NativeData.Item y = x;
                if ("series".equals(kind) && "episode".equals(x.kind)) { y = data.seriesBySid(x.sid); if (y == null) continue; }
                else if (!kind.equals(x.kind)) continue;
                if (seen.add(y.url)) rec.add(y);
                if (rec.size() >= 20) break;
            }
            if (!rec.isEmpty()) rows.add(new Object[]{"🕘 Vistos recentemente", rec, rec.size()});
            if ("live".equals(kind) && !data.opKey().isEmpty()) {
                List<NativeData.Item> ol = opList();
                if (!ol.isEmpty()) rows.add(new Object[]{"📺 " + data.opTitle(data.opKey()), ol.subList(0, Math.min(80, ol.size())), ol.size()});
            }
            List<NativeData.Cat> cats = data.visibleCats(kind);
            if (cats != null) {
                List<NativeData.Cat> sel = new ArrayList<>();
                for (NativeData.Cat c : cats) if (PT.matcher(c.name).find()) sel.add(c);
                if (sel.isEmpty()) sel = cats;
                int n = "live".equals(kind) ? 40 : 25;
                for (int i = 0; i < Math.min(14, sel.size()); i++) { NativeData.Cat c = sel.get(i); rows.add(new Object[]{c.name, c.items.subList(0, Math.min(n, c.items.size())), c.items.size()}); }
            }
            ui.post(() -> { if (seq == homeSeq && "home".equals(section)) buildRows(rows, kind); });
            /* v277: pré-carrega para o disco os logótipos do Início, do operador e dos favoritos (baixa prioridade) */
            java.util.LinkedHashSet<String> pre = new java.util.LinkedHashSet<>();
            for (Object[] r : rows) for (Object o : (List<?>) r[1]) pre.add(data.logo((NativeData.Item) o));
            if ("live".equals(kind)) { for (NativeData.Item x : opList()) pre.add(data.logo(x)); for (NativeData.Item x : data.favItems()) pre.add(data.logo(x)); }
            PiconCache.prefetch(pre);
        });
    }

    private TextView emptyMsg(String s) {
        TextView t = new TextView(this); t.setText(s); t.setTextColor(TXT); t.setAlpha(0.75f); t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(19)); t.setPadding(dp(6), dp(30), dp(6), dp(30));
        return t;
    }

    @SuppressWarnings("unchecked")
    private void buildRows(List<Object[]> rows, String kind) {
        homeRows.removeAllViews();
        lastHomeFocus = null;
        if (rows.isEmpty()) {
            String kl = "live".equals(kind) ? "canais" : "movie".equals(kind) ? "filmes" : "séries";
            homeRows.addView(emptyMsg("Sem " + kl + " carregados. Adiciona a tua lista IPTV nas Definições."));
            return;
        }
        for (Object[] r : rows) {
            final List<NativeData.Item> list = (List<NativeData.Item>) r[1];
            final LinearLayout row = new LinearLayout(this); row.setOrientation(LinearLayout.VERTICAL); row.setClipChildren(false); row.setClipToPadding(false);
            LinearLayout head = new LinearLayout(this); head.setGravity(Gravity.CENTER_VERTICAL);
            TextView h = new TextView(this); h.setText((String) r[0]); h.setTextColor(0xFF8C9BB0); h.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(21)); h.setTypeface(null, Typeface.BOLD); h.setLetterSpacing(0.01f); h.setSingleLine(true); h.setEllipsize(TextUtils.TruncateAt.END);
            head.addView(h, new LinearLayout.LayoutParams(0, -2, 1));
            TextView cnt = new TextView(this); cnt.setText(String.valueOf(r[2])); cnt.setTextColor(0xFF8C9BB0); cnt.setAlpha(0.7f); cnt.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(13)); cnt.setTypeface(null, Typeface.BOLD);
            cnt.setBackground(pill(0x1FFFFFFF, 999)); cnt.setPadding(dp(12), dp(2), dp(12), dp(2));
            head.addView(cnt);
            LinearLayout.LayoutParams hl = new LinearLayout.LayoutParams(-1, -2); hl.setMargins(dp(4), dp(10), dp(4), dp(2));
            row.addView(head, hl);
            HorizontalScrollView sc = new HorizontalScrollView(this); sc.setHorizontalScrollBarEnabled(false); sc.setClipToPadding(false); sc.setClipChildren(false);
            sc.setOnScrollChangeListener((q0, q1, q2, q3, q4) -> fxSoon());
            LinearLayout strip = new LinearLayout(this); strip.setPadding(dp(10), dp(12), dp(10), dp(26)); strip.setClipChildren(false); strip.setClipToPadding(false);
            sc.addView(strip);
            for (int i = 0; i < list.size(); i++) {
                final int idx = i;
                View card = homeCard(list.get(i), v -> onHomeCard(list, idx), row);
                LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(244), -2); lp.rightMargin = dp(18);
                strip.addView(card, lp);
            }
            row.addView(sc, new LinearLayout.LayoutParams(-1, -2));
            row.setTag(Boolean.FALSE);   /* fila com o cartão focado? */
            row.setAlpha(0.85f); row.setScaleX(0.98f); row.setScaleY(0.98f);
            homeRows.addView(row, new LinearLayout.LayoutParams(-1, -2));
        }
        if (!"nenhuma".equals(animPref())) for (int i = 0; i < homeRows.getChildCount(); i++) { View r = homeRows.getChildAt(i); for (View c : cardsOf(r)) { c.setTag(R_REV, Boolean.FALSE); c.setAlpha(0f); } }
        homeRows.post(this::fxNow);
        ui.postDelayed(this::fxNow, 250);
    }

    /* ------------------------------------------------------------ transições dos cartões e efeito das filas (v275, como na app antiga) */
    private static final int R_REV = 0x7f0b0001;   /* etiqueta: cartão já revelado */
    private static final int R_IMG = 0x7f0b0002;   /* etiqueta: carregador do logótipo ainda por correr */
    /** Logótipos dos cartões visíveis e dos próximos (1 ecrã à frente, para os lados e para baixo). */
    private void loadNearImgs() {
        int[] hs = new int[2]; homeScroll.getLocationOnScreen(hs);
        int H = Math.max(1, homeScroll.getHeight());
        for (int i = 0; i < homeRows.getChildCount(); i++) {
            View r = homeRows.getChildAt(i);
            int[] l = new int[2]; r.getLocationOnScreen(l);
            int top = l[1] - hs[1];
            if (top + r.getHeight() < -H || top > 2 * H) continue;
            View sc = ((ViewGroup) r).getChildAt(1);
            int sx = sc.getScrollX(), w = Math.max(1, sc.getWidth());
            for (View c : cardsOf(r)) {
                Object o = c.getTag(R_IMG);
                if (!(o instanceof Runnable)) continue;
                if (c.getRight() < sx - w || c.getLeft() > sx + 2 * w) continue;
                c.setTag(R_IMG, null);
                ((Runnable) o).run();
            }
        }
    }
    static final String[][] ANIMS = {{"suave", "Suave"}, {"cascata", "Cascata"}, {"zoom", "Zoom"}, {"nenhuma", "Sem animação"}};
    static final String[][] VFXS = {{"profundidade", "Profundidade"}, {"onda", "Onda"}, {"parallax", "Parallax"}, {"nenhuma", "Sem efeito"}};
    private String animPref() { return getSharedPreferences("nativeapp", 0).getString("tvAnim", "suave"); }
    private String vfxPref() { return getSharedPreferences("nativeapp", 0).getString("tvVfx", "profundidade"); }
    private boolean fxQueued = false;
    private void fxSoon() { if (fxQueued) return; fxQueued = true; homeScroll.postOnAnimation(() -> { fxQueued = false; fxNow(); }); }
    private List<View> cardsOf(View row) {
        List<View> out = new ArrayList<>();
        try { ViewGroup sc = (ViewGroup) ((ViewGroup) row).getChildAt(1); ViewGroup strip = (ViewGroup) sc.getChildAt(0); for (int i = 0; i < strip.getChildCount(); i++) out.add(strip.getChildAt(i)); } catch (Throwable ignored) { }
        return out;
    }
    private void fxNow() {
        if (homeRows == null || !"home".equals(section)) return;
        try { loadNearImgs(); } catch (Throwable ignored) { }
        revealCards();
        rowsFx();
    }
    /** Cartões que entram no ecrã aparecem com a animação escolhida (repete sempre que voltam a entrar). */
    private void revealCards() {
        String an = animPref();
        android.graphics.Rect vr = new android.graphics.Rect();
        boolean none = "nenhuma".equals(an);
        int batch = 0;
        for (int i = 0; i < homeRows.getChildCount(); i++) {
            for (View c : cardsOf(homeRows.getChildAt(i))) {
                Object rv = c.getTag(R_REV);
                if (none) { if (rv != null) { c.setTag(R_REV, null); c.animate().cancel(); c.setAlpha(1f); c.setTranslationY(0); c.setScaleX(c.isFocused() ? 1.06f : 1f); c.setScaleY(c.isFocused() ? 1.06f : 1f); } continue; }
                boolean vis = c.getGlobalVisibleRect(vr) && vr.width() > c.getWidth() / 5 && vr.height() > c.getHeight() / 5;
                boolean done = Boolean.TRUE.equals(rv);
                if (vis && !done) {
                    c.setTag(R_REV, Boolean.TRUE);
                    if (c.isFocused()) { c.setAlpha(1f); continue; }
                    long delay = "suave".equals(an) ? 0 : Math.min(8, batch) * ("cascata".equals(an) ? 70L : 45L);
                    batch++;
                    c.animate().cancel();
                    if ("zoom".equals(an)) {
                        c.setTranslationY(0); c.setScaleX(0.55f); c.setScaleY(0.55f); c.setAlpha(0f);
                        c.animate().alpha(1f).scaleX(1f).scaleY(1f).setStartDelay(delay).setDuration(550).setInterpolator(new android.view.animation.OvershootInterpolator(1.6f)).start();
                    } else {
                        c.setTranslationY(dp(46)); c.setScaleX(0.94f); c.setScaleY(0.94f); c.setAlpha(0f);
                        c.animate().alpha(1f).translationY(0).scaleX(1f).scaleY(1f).setStartDelay(delay).setDuration("cascata".equals(an) ? 600 : 500).setInterpolator(new android.view.animation.DecelerateInterpolator(2.2f)).start();
                    }
                } else if (!vis && done && !c.isFocused()) {
                    c.setTag(R_REV, Boolean.FALSE);
                    c.animate().cancel(); c.setAlpha(0f);
                }
            }
        }
    }
    /** Efeito ao deslizar: as filas mudam com a distância ao centro do ecrã (profundidade, onda ou parallax). */
    private void rowsFx() {
        String vf = vfxPref();
        int[] hs = new int[2]; homeScroll.getLocationOnScreen(hs);
        float H = Math.max(1, homeScroll.getHeight());
        for (int i = 0; i < homeRows.getChildCount(); i++) {
            View r = homeRows.getChildAt(i);
            boolean foc = Boolean.TRUE.equals(r.getTag());
            float vx = 0, vy = 0, vs = 1, vo = 1;
            if (!"nenhuma".equals(vf)) {
                int[] l = new int[2]; r.getLocationOnScreen(l);
                float c = l[1] - hs[1] + r.getHeight() / 2f;
                float p = Math.max(-1f, Math.min(1f, (c - H * 0.5f) / (H * 0.55f))), ap = Math.abs(p);
                if ("profundidade".equals(vf)) { vs = 1 - ap * 0.07f; vo = 1 - ap * 0.55f; }
                else if ("onda".equals(vf)) { vx = p * (i % 2 == 1 ? 1 : -1) * dp(56); vo = 1 - ap * 0.4f; }
                else if ("parallax".equals(vf)) { float d = Math.max(0, p); vy = -p * dp(16); vs = 1 - d * 0.05f; vo = 1 - d * 0.5f; }
                if (foc) { vo = Math.max(vo, 0.9f); vs = Math.max(vs, 0.97f); }
            }
            r.setPivotX(0); r.setPivotY(r.getHeight() / 2f);
            r.setTranslationX(vx); r.setTranslationY(vy);
            float sc = vs * (foc ? 1f : 0.98f);
            r.setScaleX(sc); r.setScaleY(sc);
            r.setAlpha(vo * (foc ? 1f : 0.85f));
        }
        /* parallax: o destaque esmorece ao subir */
        View hero = homeCol.getChildCount() > 0 ? homeCol.getChildAt(0) : null;
        if (hero != null) {
            float a = 1f;
            if ("parallax".equals(vf)) a = 1f - Math.min(1f, homeScroll.getScrollY() / (float) Math.max(1, hero.getHeight())) * 0.7f;
            hero.setAlpha(a);
        }
    }

    /** Cartão do Início (thCard): arte em cima (logótipo ou capa; sem imagem, as iniciais), nome e grupo em baixo. */
    private View homeCard(final NativeData.Item it, View.OnClickListener click, final View row) {
        final boolean poster = isPoster(it);
        LinearLayout c = new LinearLayout(this); c.setOrientation(LinearLayout.VERTICAL);
        c.setBackground(pill(CARD, 18)); c.setClipToOutline(true); c.setElevation(dp(4));
        GradientDrawable fr = new GradientDrawable(); fr.setCornerRadius(dp(18)); fr.setStroke(dp(3), ACC); fr.setColor(0x00000000);
        final GradientDrawable focusRing = fr;
        FrameLayout art = new FrameLayout(this);
        art.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF1D2A47, 0xFF0D1424}));
        TextView ini = new TextView(this);
        String nm = it.name.replaceAll("^[^\\p{L}\\p{N}]+", "");
        ini.setText(nm.length() >= 2 ? nm.substring(0, 2).toUpperCase() : nm.toUpperCase());
        ini.setTextColor(TXT); ini.setAlpha(0.45f); ini.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(34)); ini.setTypeface(null, Typeface.BOLD); ini.setLetterSpacing(0.04f);
        art.addView(ini, new FrameLayout.LayoutParams(-2, -2, Gravity.CENTER));
        ImageView im = new ImageView(this);
        im.setScaleType(poster ? ImageView.ScaleType.CENTER_CROP : ImageView.ScaleType.FIT_CENTER);
        int pad = poster ? 0 : dp(22); im.setPadding(pad, pad, pad, pad);
        art.addView(im, new FrameLayout.LayoutParams(-1, -1));
        c.addView(art, new LinearLayout.LayoutParams(-1, dp(poster ? 360 : 137)));
        LinearLayout meta = new LinearLayout(this); meta.setOrientation(LinearLayout.VERTICAL); meta.setPadding(dp(14), dp(10), dp(14), dp(13));
        TextView n = new TextView(this);
        boolean fav = data.isFav(it.url), seen = !"live".equals(it.kind) && data.watched(it.url);
        n.setText((fav ? "★ " : "") + (seen ? "✓ " : "") + it.name); n.setTextColor(TXT); n.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(18)); n.setTypeface(null, Typeface.BOLD);
        n.setMaxLines(poster ? 2 : 1); n.setEllipsize(TextUtils.TruncateAt.END);
        TextView g = new TextView(this);
        long ps = "live".equals(it.kind) ? 0 : data.pos(it.url);
        String sub = ps > 0 ? "▶ " + (ps / 60000) + " min · " + it.group : it.group;
        if ("series".equals(it.kind) && data.lastEp(it.sid).length() > 0) sub = "▶ em curso · " + it.group;
        g.setText(sub); g.setTextColor(TXT); g.setAlpha(0.7f); g.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(14)); g.setSingleLine(true); g.setEllipsize(TextUtils.TruncateAt.END);
        meta.addView(n); LinearLayout.LayoutParams gl = new LinearLayout.LayoutParams(-1, -2); gl.topMargin = dp(3); meta.addView(g, gl);
        c.addView(meta, new LinearLayout.LayoutParams(-1, -2));
        c.setFocusable(true); c.setClickable(true);
        c.setOnClickListener(click);
        c.setOnLongClickListener(v -> { homeMenu(it); return true; });
        c.setOnFocusChangeListener((v, f) -> {
            v.setForeground(f ? focusRing : null);
            v.animate().scaleX(f ? 1.06f : 1f).scaleY(f ? 1.06f : 1f).setDuration(120).start();
            v.setElevation(dp(f ? 14 : 4));
            if (f) {
                lastHomeFocus = v;
                if (v.getAlpha() < 1f) { v.animate().cancel(); v.setAlpha(1f); v.setTranslationY(0); }
                for (int i = 0; i < homeRows.getChildCount(); i++) { View r = homeRows.getChildAt(i); r.setTag(r == row ? Boolean.TRUE : Boolean.FALSE); }
                rowsFx();
            }
        });
        data.logo(it);
        if (it.logo != null && it.logo.startsWith("http")) {
            Holder h = new Holder(); h.im = im; h.name = n; h.sub = g;
            final TextView fi = ini;
            final Runnable go = () -> loadImgThen(h, it.logo, () -> fi.setVisibility(im.getDrawable() != null ? View.GONE : View.VISIBLE));
            Bitmap mb = PiconCache.mem(it.logo);
            if (mb != null) { im.setImageBitmap(mb); ini.setVisibility(View.GONE); }
            else c.setTag(R_IMG, go);   /* carrega quando o cartão estiver perto do ecrã (ver loadNearImgs) */
        }
        return c;
    }

    /* ------------------------------------------------------------ destaque e pré-visualização (como na app antiga) */
    private boolean pvPref() { return getSharedPreferences("nativeapp", 0).getBoolean("tvPrev", true); }
    private boolean pvSnd() { return getSharedPreferences("nativeapp", 0).getBoolean("tvPrevSnd", false); }

    /** Destaque: o canal escolhido no Início ou o último visto («Continuar a ver»); sem nenhum, «Bem-vindo». */
    private void refreshHero() {
        if (heroTitle == null) return;
        NativeData.Item cur = heroItem;
        if (cur == null) { List<NativeData.Item> r = data.recents(); if (!r.isEmpty()) cur = r.get(0); heroItem = cur; heroList = null; }
        if (cur == null) {
            heroLabel.setText("COCKPIT TV"); heroTitle.setText("Bem-vindo"); heroSub.setText("Escolhe um canal em baixo para começar.");
            heroBtn1.setText("Explorar canais"); setPrimary(heroBtn1, kindIcons.get("Explorar canais"), true);
            heroBtn2.setText("Definições"); setPrimary(heroBtn2, kindIcons.get("Definições"), false);
            heroArt.setVisibility(View.GONE);
            return;
        }
        heroLabel.setText("CONTINUAR A VER");
        String nm = cur.name; if ("episode".equals(cur.kind) && cur.group.length() > 0) nm = cur.group + " · " + cur.name;
        heroTitle.setText(nm);
        String e = epgCache.get(cur.url);
        heroSub.setText(e != null && !e.isEmpty() ? e : cur.group);
        if ("live".equals(cur.kind) && e == null) wantEpg(cur);
        heroBtn1.setText("▶ Ver agora"); heroBtn1.setCompoundDrawables(null, null, null, null); setPrimary(heroBtn1, null, true);
        heroBtn2.setText("Explorar canais"); setPrimary(heroBtn2, kindIcons.get("Explorar canais"), false);
        heroArt.setVisibility(View.VISIBLE);
        String ini = cur.name.replaceAll("^[^\\p{L}\\p{N}]+", ""); heroArtIni.setText(ini.length() >= 2 ? ini.substring(0, 2).toUpperCase() : ini.toUpperCase());
        heroArtIni.setVisibility(View.VISIBLE); heroArtImg.setImageBitmap(null);
        data.logo(cur);
        if (cur.logo != null && cur.logo.startsWith("http")) {
            Holder h = new Holder(); h.im = heroArtImg;
            loadImgThen(h, cur.logo, () -> heroArtIni.setVisibility(heroArtImg.getDrawable() != null ? View.GONE : View.VISIBLE));
        }
        startPreview();
    }

    private void heroPrimary() {
        NativeData.Item cur = heroItem;
        if (cur == null) { tab = "live"; showSection("explore"); return; }
        if (heroList != null && heroIdx < heroList.size() && heroList.get(heroIdx).url.equals(cur.url)) { onHomeOpen(heroList, heroIdx); return; }
        List<NativeData.Item> one = new ArrayList<>(); one.add(cur);
        if ("live".equals(cur.kind)) {   /* a lista do ecrã total: a categoria do canal */
            List<NativeData.Cat> cs = data.cats.get("live");
            if (cs != null) for (NativeData.Cat c : cs) if (c.name.equals(cur.group)) { int ix = indexOf(c.items, cur.url); if (ix >= 0) { onHomeOpen(c.items, ix); return; } }
        }
        onHomeOpen(one, 0);
    }
    private void heroSecondary() {
        if (heroItem == null) showSection("settings"); else { tab = "live"; showSection("explore"); }
    }

    /** O vídeo pequeno do destaque: só canais em direto, no Início, sem som (opção), pára ao fim de 10 min. */
    private void startPreview() {
        NativeData.Item cur = heroItem;
        boolean ok = cur != null && "live".equals(cur.kind) && "home".equals(section) && details == null && pvPref() && !pvOff
                && (nscr == null || !nscr.isOpen()) && heroArt != null && heroArt.getVisibility() == View.VISIBLE && !isFinishing();
        if (!ok) { stopPreview(); return; }
        try {
            if (np == null) np = new NativePlayer(this, root, (k, m) -> playerEvent(k, m));
            applyPlayerPrefs();
            if (!cur.url.equals(pvUrl)) {
                String u = cur.url.toLowerCase();
                String hint = u.contains(".m3u8") ? "hls" : (!u.matches(".*\\.ts(\\?.*)?$") && !u.matches(".*\\.(mp4|mkv|avi|mov)(\\?.*)?$")) ? "hls" : "";
                np.play(cur.url, "", hint, "", 0);
                pvUrl = cur.url; pvT0 = System.currentTimeMillis();
            }
            np.setPreview(true);
            np.volume(pvSnd() ? 1f : 0f);
            placePreview();
            ui.removeCallbacks(pvLimit); ui.postDelayed(pvLimit, 10 * 60000L);
        } catch (Throwable e) { pvUrl = null; }
    }
    private final Runnable pvLimit = () -> { if (pvUrl != null && (nscr == null || !nscr.isOpen())) { stopPreview(); pvOff = true; } };
    private void stopPreview() {
        ui.removeCallbacks(pvLimit);
        if (pvUrl == null) return;
        pvUrl = null;
        try { if (np != null && (nscr == null || !nscr.isOpen())) { if (isFinishing() || !hasWindowFocus()) np.stop(); else np.stopSoon(30000); } } catch (Throwable ignored) { }
    }
    /** Põe o vídeo por cima da janela do destaque (e esconde-o se a janela sair do ecrã). */
    private void placePreview() {
        if (pvUrl == null || np == null || heroArt == null || (nscr != null && nscr.isOpen())) return;
        int[] a = new int[2], r = new int[2], n = new int[2];
        heroArt.getLocationInWindow(a); root.getLocationInWindow(r); navBar.getLocationInWindow(n);
        int x = a[0] - r[0], y = a[1] - r[1], w = heroArt.getWidth(), h = heroArt.getHeight();
        boolean vis = w > 20 && h > 20 && "home".equals(section) && details == null && heroArt.isShown() && y >= n[1] - r[1] + navBar.getHeight() - dp(2);
        if (!vis && !pvLastVis) return;   /* fora do ecrã e já escondido: não repete (enchia o diário a cada movimento) */
        pvLastVis = vis;
        if (vis) np.notePageRect(x, y, w, h);
        np.rect(x, y, w, h, vis);
    }

    /** Programa a decorrer (pedido só quando o canal é escolhido, guardado para não repetir). */
    private void wantEpg(final NativeData.Item it) {
        if (!"live".equals(it.kind) || epgCache.containsKey(it.url)) return;
        epgCache.put(it.url, "");
        bg.execute(() -> {
            final String t = data.nowNext(it);
            ui.post(() -> {
                epgCache.put(it.url, t);
                if (t.isEmpty()) return;
                if ("home".equals(section) && heroTitle.getText().toString().equals(it.name)) heroSub.setText(t);
                if ("guide".equals(section)) gridAdapter.notifyDataSetChanged();
            });
        });
    }

    private void onHomeCard(List<NativeData.Item> list, int idx) {
        NativeData.Item it = list.get(idx);
        if ("live".equals(it.kind) && pvPref() && (heroItem == null || !heroItem.url.equals(it.url))) {
            /* 1.º OK num canal: passa para a pré-visualização do destaque; 2.º OK (ou «Ver agora»): ecrã total */
            heroItem = it; heroList = list; heroIdx = idx; pvOff = false;
            data.pushRecent(it);
            refreshHero();
            return;
        }
        onHomeOpen(list, idx);
    }

    private void onHomeOpen(List<NativeData.Item> list, int idx) {
        NativeData.Item it = list.get(idx);
        if ("series".equals(it.kind)) { openSeriesDetails(it); return; }
        if ("movie".equals(it.kind) || "vod".equals(it.kind)) { openMovieDetails(list, idx); return; }
        if ("episode".equals(it.kind) && it.sid.length() > 0) { playEpisode(it.sid, it.url); return; }
        play(list, idx, -1);
    }

    private void homeMenu(final NativeData.Item it) {
        final boolean on = data.isFav(it.url);
        List<String> opts = new ArrayList<>();
        opts.add(on ? "Tirar dos favoritos" : "Juntar aos favoritos");
        hideOpts(opts, it);
        final String[] arr = opts.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle(it.name).setItems(arr, (d, w) -> {
            if (doHide(arr[w], it)) return;
            data.toggleFav(it);
            Toast.makeText(this, on ? "Fora dos favoritos" : "★ Nos favoritos", Toast.LENGTH_SHORT).show();
            renderHome();
        }).show();
    }

    private void loadImgThen(final Holder h, final String url, final Runnable after) {
        h.url = url;
        Bitmap c = PiconCache.mem(url);
        if (c != null) { h.im.setImageBitmap(c); after.run(); return; }
        PiconCache.load(url, b -> { if (b != null && url.equals(h.url)) { h.im.setImageBitmap(b); after.run(); } });
    }

    private void hideKb(View v) {
        try { android.view.inputmethod.InputMethodManager m = (android.view.inputmethod.InputMethodManager) getSystemService(INPUT_METHOD_SERVICE); if (m != null) m.hideSoftInputFromWindow(v.getWindowToken(), 0); } catch (Throwable ignored) { }
        try { v.clearFocus(); } catch (Throwable ignored) { }
    }
    private Runnable catSelRun = () -> { };
    private final Runnable doSearch = () -> runSearch();

    private void setStatus(String s, boolean busy) { status.setText(s); spin.setVisibility(busy ? View.VISIBLE : View.GONE); }

    private boolean vodTab() { return "movie".equals(tab) || "series".equals(tab); }
    private void updateSortBtn() {
        boolean on = vodTab() && openSeries == null && catList.getVisibility() == View.VISIBLE;
        sortBtn.setVisibility(on ? View.VISIBLE : View.GONE);
        if (on) sortBtn.setText("⇅ " + NativeData.SORT_L[data.sortMode(tab)]);
    }
    private void pickSort() {
        if (!vodTab()) return;
        final String k = tab;
        new AlertDialog.Builder(this).setTitle("Ordenar").setSingleChoiceItems(NativeData.SORT_L, data.sortMode(k), (d, w) -> {
            d.dismiss();
            data.setSortMode(k, w);
            updateSortBtn();
            shownKey = "";
            pickCat(curCat, false);
            grid.setSelection(0);
        }).show();
    }

    /* ------------------------------------------------------------ separadores */
    private void showTab(String id) {
        closeDetails();
        if (!"settings".equals(id) && ("home".equals(section) || "settings".equals(section))) {
            section = "explore";
            stopPreview();
            for (java.util.Map.Entry<String, View> e : navTabs.entrySet()) styleTab(e.getValue(), e.getKey());
            homeScroll.setVisibility(View.GONE); browseCol.setVisibility(View.VISIBLE); chipsRow.setVisibility(View.VISIBLE);
        }
        statusRow.setVisibility("settings".equals(id) ? View.GONE : View.VISIBLE);
        tab = id;
        openSeries = null;
        loadSeq++;
        getSharedPreferences("nativeapp", 0).edit().putString("tab", id).apply();
        markTabs();
        if (settingsView != null) { body.removeView(settingsView); settingsView = null; }
        catList.setVisibility(View.VISIBLE); grid.setVisibility(View.VISIBLE);
        searchBox.setVisibility(View.GONE);
        curCats = new ArrayList<>(); curItems = new ArrayList<>(); shownKey = "";
        catAdapter.notifyDataSetChanged(); gridAdapter.notifyDataSetChanged();
        switch (id) {
            case "live": case "movie": case "series": loadKind(id, false); break;
            case "fav": case "recent": showFlat(id); break;
            case "search":
                catList.setVisibility(View.GONE);
                searchBox.setVisibility(View.VISIBLE);
                searchBox.requestFocus();
                ensureAllLoaded(() -> runSearch());
                break;
            case "settings": showSettings(); break;
        }
        updateSortBtn();
    }

    /* lista do operador (calculada uma vez por lista carregada) */
    private List<NativeData.Item> opCache = null;
    private String opCacheKey = "";
    private List<NativeData.Item> opList() {
        String k = data.opKey();
        List<NativeData.Item> live = data.all.get("live");
        String ck = k + "|" + (live == null ? 0 : live.size()) + "|" + data.opCustom().hashCode();
        if (opCache == null || !ck.equals(opCacheKey)) {
            List<NativeData.Item> l = k.isEmpty() ? new ArrayList<>() : data.opChannels(k), v = new ArrayList<>();
            for (NativeData.Item x : l) if (!data.hiddenItem(x)) v.add(x);
            opCache = v; opCacheKey = ck;
        }
        return opCache;
    }

    /** Categorias do tipo, com «Continuar a ver» e «Adicionados recentemente» no topo (filmes e séries). */
    private List<NativeData.Cat> withVirtual(String kind) {
        List<NativeData.Cat> out = new ArrayList<>();
        List<NativeData.Cat> base = data.visibleCats(kind);
        if ("live".equals(kind) && !data.opKey().isEmpty()) {   /* operador escolhido: os canais pela ordem da grelha, no topo */
            List<NativeData.Item> ol = opList();
            if (!ol.isEmpty()) { NativeData.Cat c = new NativeData.Cat(); c.id = "__op"; c.name = "📺 " + data.opTitle(data.opKey()); c.items.addAll(ol); out.add(c); }
        }
        if (!"live".equals(kind)) {
            List<NativeData.Item> cont = "movie".equals(kind) ? data.continueMovies() : data.continueSeries();
            if (!cont.isEmpty()) { NativeData.Cat c = new NativeData.Cat(); c.id = "__cont"; c.name = "▶ Continuar a ver"; c.items.addAll(cont); out.add(c); }
            List<NativeData.Item> allk = data.all.get(kind);
            boolean has = false;
            if (allk != null) for (NativeData.Item x : allk) if (x.added > 0) { has = true; break; }
            if (has) {
                List<NativeData.Item> s = NativeData.sorted(allk, 2);
                NativeData.Cat c = new NativeData.Cat(); c.id = "__new"; c.name = "🆕 Adicionados recentemente"; c.items.addAll(s.subList(0, Math.min(200, s.size()))); out.add(c);
            }
        }
        if (base != null) out.addAll(base);
        return out;
    }

    private int savedCatIndex(String kind) {
        String name = getSharedPreferences("nativeapp", 0).getString("catn_" + kind, "");
        for (int i = 0; i < curCats.size(); i++) if (curCats.get(i).name.equals(name)) return i;
        return "live".equals(kind) ? 0 : Math.min(curCats.size() - 1, 0);
    }

    private void loadKind(final String kind, final boolean force) {
        if (!data.configured()) { setStatus("Sem lista configurada — abre ⚙️ Definições.", false); return; }
        final int seq = ++loadSeq;
        if (!force) setStatus("A carregar…", true);
        final long t0 = System.currentTimeMillis();
        bg.execute(() -> {
            String err = null;
            List<NativeData.Cat> vc = null;
            try { data.load(kind, force); vc = withVirtual(kind); } catch (Throwable e) { err = e.getMessage() == null ? String.valueOf(e) : e.getMessage(); }
            final String fe = err; final List<NativeData.Cat> fvc = vc;
            final long ms = System.currentTimeMillis() - t0;
            ui.post(() -> {
                if (seq != loadSeq || !kind.equals(tab) || openSeries != null) return;
                if (fe != null) { if (!force) setStatus("Erro: " + fe, false); return; }
                /* v280: categorias calculadas fora do ecrã; na renovação por trás mantém a categoria e o sítio onde estás */
                String keepName = force && curCat < curCats.size() ? curCats.get(curCat).name : null;
                int keepPos = grid.getFirstVisiblePosition();
                boolean gridFocus = grid.hasFocus();
                curCats = fvc;
                catAdapter.notifyDataSetChanged();
                shownKey = "";
                int ci = -1;
                if (keepName != null) for (int i = 0; i < curCats.size(); i++) if (curCats.get(i).name.equals(keepName)) { ci = i; break; }
                if (ci >= 0) { pickCat(ci, false); grid.setSelection(keepPos); if (gridFocus) grid.requestFocus(); }
                else { ci = Math.max(0, savedCatIndex(kind)); pickCat(ci, false); catList.setSelection(curCat); }
                int n = 0; List<NativeData.Item> al = data.all.get(kind); if (al != null) n = al.size();
                setStatus(n + (kind.equals("live") ? " canais" : kind.equals("movie") ? " filmes" : " séries") + "   ·   OK longo / Menu: opções", false);
                try { if (np != null) np.log("lista " + kind + ": " + n + " itens em " + ms + " ms" + (force ? " (renovada)" : "")); } catch (Throwable ignored) { }
                updateSortBtn();
                if (!force && !data.cacheFresh(kind) && !refreshTried.contains(kind)) { refreshTried.add(kind); loadKind(kind, true); }   /* lista guardada antiga: mostra-a e renova por trás (uma vez) */
            });
        });
    }
    private final java.util.Set<String> refreshTried = new java.util.HashSet<>();

    /** Depois de ver algo: atualiza «Continuar a ver» mantendo a categoria aberta. */
    private void refreshCats() {
        if (!vodTab() || openSeries != null || data.cats.get(tab) == null) return;
        String name = curCat < curCats.size() ? curCats.get(curCat).name : "";
        int keep = grid.getFirstVisiblePosition();
        curCats = withVirtual(tab);
        catAdapter.notifyDataSetChanged();
        int ci = 0; for (int i = 0; i < curCats.size(); i++) if (curCats.get(i).name.equals(name)) { ci = i; break; }
        shownKey = "";
        pickCat(ci, false);
        grid.setSelection(keep);
    }

    private void ensureAllLoaded(final Runnable after) {
        if (!data.configured()) return;
        setStatus("A preparar…", true);
        final int seq = loadSeq;
        bg.execute(() -> {
            for (String k : new String[]{"live", "movie", "series"}) { try { data.load(k, false); } catch (Throwable ignored) { } }
            ui.post(() -> { if (seq == loadSeq) setStatus("", false); after.run(); });
        });
    }

    private void showFlat(final String id) {
        catList.setVisibility(View.GONE);
        if ("recent".equals(id)) {
            curItems = data.recents();
            gridAdapter.notifyDataSetChanged(); setColumns(); grid.setSelection(0);
            setStatus(curItems.isEmpty() ? "Ainda não viste nada." : curItems.size() + " vistos recentemente", false);
            return;
        }
        ensureAllLoaded(() -> {
            if (!"fav".equals(tab)) return;
            curItems = data.favItems();
            gridAdapter.notifyDataSetChanged(); setColumns(); grid.setSelection(0);
            setStatus(curItems.isEmpty() ? "Sem favoritos. Mantém OK (ou Menu) num canal, filme ou série para o marcar." : curItems.size() + " favoritos", false);
        });
    }

    private void runSearch() {
        if (!"search".equals(tab)) return;
        String q = searchBox.getText().toString();
        curItems = data.search(q);
        gridAdapter.notifyDataSetChanged(); setColumns();
        setStatus(q.trim().length() < 2 ? "Escreve pelo menos 2 letras." : curItems.size() + " resultados", false);
    }

    private void pickCat(int pos, boolean focusGrid) {
        if (pos < 0 || pos >= curCats.size()) return;
        NativeData.Cat c = curCats.get(pos);
        boolean virt = c.id.startsWith("__");
        int sm = openSeries == null && vodTab() && !virt ? data.sortMode(tab) : 0;
        String key = tab + "|" + (openSeries == null ? "" : openSeries.sid) + "|" + c.id + "|" + c.name + "|" + sm;
        if (!key.equals(shownKey)) {
            shownKey = key;
            curCat = pos;
            curItems = NativeData.sorted(c.items, sm);
            gridAdapter.notifyDataSetChanged(); setColumns();
            final List<NativeData.Item> pf = curItems;
            PiconCache.cancelPrefetch();
            bg.execute(() -> { java.util.LinkedHashSet<String> u = new java.util.LinkedHashSet<>(); for (NativeData.Item x : pf) { u.add(data.logo(x)); if (u.size() >= 400) break; } PiconCache.prefetch(u); });
            grid.setSelection(openSeries == null ? getSharedPreferences("nativeapp", 0).getInt("pos_" + tab + "_" + c.name, 0) : 0);
            if (openSeries == null) getSharedPreferences("nativeapp", 0).edit().putString("catn_" + tab, c.name).apply();
        }
        curCat = pos;
        catAdapter.notifyDataSetChanged();
        if (focusGrid) grid.requestFocus();
    }

    private void setColumns() {
        boolean poster = !curItems.isEmpty() ? isPoster(curItems.get(0)) : vodTab();
        grid.setColumnWidth(dp(poster ? 150 : 300));
        grid.setNumColumns(GridView.AUTO_FIT);
    }

    /* ------------------------------------------------------------ adaptadores */
    private final BaseAdapter catAdapter = new BaseAdapter() {
        @Override public int getCount() { return curCats.size(); }
        @Override public Object getItem(int i) { return curCats.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public View getView(int i, View v, ViewGroup p) {
            TextView t = (TextView) v;
            if (t == null) {
                t = new TextView(NativeHomeActivity.this);
                t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(16)); t.setPadding(dp(14), dp(12), dp(10), dp(12));
                t.setSingleLine(true); t.setEllipsize(TextUtils.TruncateAt.END);
            }
            NativeData.Cat c = curCats.get(i);
            t.setText(c.name + "  ·  " + c.items.size());
            t.setTextColor(i == curCat ? ACC : TXT);
            t.setTypeface(null, i == curCat ? Typeface.BOLD : Typeface.NORMAL);
            return t;
        }
    };

    private static final class Holder { ImageView im; TextView name, sub; View bar; String url; boolean poster; }

    private final BaseAdapter gridAdapter = new BaseAdapter() {
        @Override public int getCount() { return curItems.size(); }
        @Override public Object getItem(int i) { return curItems.get(i); }
        @Override public long getItemId(int i) { return i; }
        @Override public int getViewTypeCount() { return 2; }
        @Override public int getItemViewType(int i) { return isPoster(curItems.get(i)) ? 1 : 0; }
        @Override public View getView(int i, View v, ViewGroup p) {
            NativeData.Item it = curItems.get(i);
            boolean poster = isPoster(it);
            Holder h = v == null ? null : (Holder) v.getTag();
            if (h == null || h.poster != poster) { v = poster ? makePoster() : makeRow(); h = (Holder) v.getTag(); }
            boolean fav = data.isFav(it.url);
            boolean seen = !"live".equals(it.kind) && data.watched(it.url);
            h.name.setText((fav ? "★ " : "") + (seen ? "✓ " : "") + it.name);
            long ps = "live".equals(it.kind) ? 0 : data.pos(it.url);
            String s;
            if (poster) {
                s = it.year.length() > 0 ? it.year : "";
                if (it.rating.length() > 0 && !"0".equals(it.rating)) s += (s.isEmpty() ? "" : " · ") + "★ " + it.rating;
                if ("series".equals(it.kind)) { String le = data.lastEp(it.sid); if (le.length() > 0) s = "▶ em curso" + (s.isEmpty() ? "" : " · " + s); }
                if (ps > 0) s = "▶ " + (ps / 60000) + " min" + (s.isEmpty() ? "" : " · " + s);
            } else {
                if ("episode".equals(it.kind)) s = ps > 0 ? "▶ continuar aos " + (ps / 60000) + " min" : seen ? "visto" : (it.rating.length() > 0 ? it.rating : "");
                else if ("guide".equals(section) && "live".equals(it.kind)) { String e = epgCache.get(it.url); s = e == null || e.isEmpty() ? (e == null ? "…" : "Sem programa") : e; if (e == null) wantEpg(it); }
                else s = "search".equals(tab) || "fav".equals(tab) || "recent".equals(tab) ? kindLabel(it) + it.group : (it.num > 0 ? "#" + it.num : "");
            }
            h.sub.setText(s); h.sub.setVisibility(s.isEmpty() ? View.GONE : View.VISIBLE);
            h.sub.setTextColor(seen ? OK : MUT);
            loadImg(h, data.logo(it));
            return v;
        }
    };

    private boolean isPoster(NativeData.Item it) { return "movie".equals(it.kind) || "series".equals(it.kind) || "vod".equals(it.kind); }
    private String kindLabel(NativeData.Item it) { return "live".equals(it.kind) ? "📺 " : "episode".equals(it.kind) || "series".equals(it.kind) ? "🎞️ " : "🎬 "; }

    private View makeRow() {
        LinearLayout r = new LinearLayout(this);
        r.setGravity(Gravity.CENTER_VERTICAL);
        r.setPadding(dp(10), dp(8), dp(10), dp(8));
        r.setBackground(roundRect(CARD, 18));
        Holder h = new Holder();
        h.im = new ImageView(this); h.im.setScaleType(ImageView.ScaleType.FIT_CENTER);
        r.addView(h.im, new LinearLayout.LayoutParams(dp(64), dp(40)));
        LinearLayout tx = new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.setPadding(dp(12), 0, 0, 0);
        h.name = new TextView(this); h.name.setTextColor(TXT); h.name.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(15)); h.name.setSingleLine(true); h.name.setEllipsize(TextUtils.TruncateAt.END);
        h.sub = new TextView(this); h.sub.setTextColor(MUT); h.sub.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(12)); h.sub.setSingleLine(true); h.sub.setEllipsize(TextUtils.TruncateAt.END);
        tx.addView(h.name); tx.addView(h.sub);
        r.addView(tx, new LinearLayout.LayoutParams(0, -2, 1));
        r.setTag(h);
        return r;
    }

    private View makePoster() {
        LinearLayout r = new LinearLayout(this);
        r.setOrientation(LinearLayout.VERTICAL);
        r.setPadding(dp(4), dp(4), dp(4), dp(6));
        Holder h = new Holder(); h.poster = true;
        h.im = new ImageView(this); h.im.setScaleType(ImageView.ScaleType.CENTER_CROP);
        h.im.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{0xFF1D2A47, 0xFF0D1424})); h.im.setClipToOutline(true);
        h.im.setOutlineProvider(new android.view.ViewOutlineProvider() { @Override public void getOutline(View v, android.graphics.Outline o) { o.setRoundRect(0, 0, v.getWidth(), v.getHeight(), dp(18)); } });
        r.addView(h.im, new LinearLayout.LayoutParams(-1, dp(220)));
        h.name = new TextView(this); h.name.setTextColor(TXT); h.name.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(13)); h.name.setMaxLines(2); h.name.setEllipsize(TextUtils.TruncateAt.END);
        h.name.setPadding(dp(2), dp(5), dp(2), 0);
        h.sub = new TextView(this); h.sub.setTextColor(MUT); h.sub.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(11.5f)); h.sub.setSingleLine(true); h.sub.setPadding(dp(2), 0, dp(2), 0);
        r.addView(h.name); r.addView(h.sub);
        r.setTag(h);
        return r;
    }

    private void loadImg(final Holder h, final String url) {
        h.url = url;
        if (url == null || url.isEmpty() || !url.startsWith("http")) { h.im.setImageBitmap(null); return; }
        Bitmap c = bmp.get(url);
        if (c != null) { h.im.setImageBitmap(c); return; }
        h.im.setImageBitmap(null);
        if (PiconCache.knownBad(url)) return;
        Bitmap m = PiconCache.mem(url);
        if (m != null) { h.im.setImageBitmap(m); return; }
        PiconCache.load(url, b -> { if (url.equals(h.url) && b != null) h.im.setImageBitmap(b); });   /* v277: os visíveis primeiro, memória partilhada */
    }

    /** Imagem grande (fundo da ficha): descarregada com a resolução certa para o ecrã. */
    private void loadBig(final ImageView v, final String url, final int maxW) {
        if (url == null || !url.startsWith("http")) return;
        final String key = "big:" + url;
        Bitmap c = bmp.get(key);
        if (c != null) { v.setImageBitmap(c); return; }
        img.execute(() -> {
            Bitmap b = null;
            HttpURLConnection h = null;
            try {
                h = (HttpURLConnection) new URL(url).openConnection();
                h.setConnectTimeout(5000); h.setReadTimeout(8000); h.setInstanceFollowRedirects(true);
                h.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android) CockpitTV");
                InputStream in = h.getInputStream();
                java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); byte[] buf = new byte[16384]; int n;
                while ((n = in.read(buf)) > 0) { bo.write(buf, 0, n); if (bo.size() > 8 * 1024 * 1024) break; }
                in.close();
                byte[] d = bo.toByteArray();
                BitmapFactory.Options o = new BitmapFactory.Options(); o.inJustDecodeBounds = true;
                BitmapFactory.decodeByteArray(d, 0, d.length, o);
                int ss = 1; while (o.outWidth / (ss * 2) >= maxW) ss *= 2;
                BitmapFactory.Options o2 = new BitmapFactory.Options(); o2.inSampleSize = ss;
                b = BitmapFactory.decodeByteArray(d, 0, d.length, o2);
            } catch (Throwable ignored) { } finally { if (h != null) try { h.disconnect(); } catch (Throwable ignored) { } }
            final Bitmap fb = b;
            if (fb != null) bmp.put(key, fb);
            ui.post(() -> { if (fb != null) v.setImageBitmap(fb); });
        });
    }

    /* ------------------------------------------------------------ ações nos itens */
    private void onItem(int pos) {
        if (pos < 0 || pos >= curItems.size()) return;
        NativeData.Item it = curItems.get(pos);
        if (openSeries == null && vodTab() || "live".equals(tab)) {
            if (openSeries == null && curCat < curCats.size()) getSharedPreferences("nativeapp", 0).edit().putInt("pos_" + tab + "_" + curCats.get(curCat).name, pos).apply();
        }
        if ("series".equals(it.kind)) { openSeriesDetails(it); return; }
        if ("movie".equals(it.kind) || "vod".equals(it.kind)) { openMovieDetails(curItems, pos); return; }
        if ("episode".equals(it.kind)) {
            if (openSeries != null) { int i = indexOf(seriesEps, it.url); if (i >= 0) { play(seriesEps, i, -1); return; } }
            if (it.sid.length() > 0) { playEpisode(it.sid, it.url); return; }
        }
        play(curItems, pos, -1);
    }

    private static int indexOf(List<NativeData.Item> l, String url) { for (int i = 0; i < l.size(); i++) if (l.get(i).url.equals(url)) return i; return -1; }

    /** Categoria: subir, descer, para o topo ou ocultar (como «Organizar» na app antiga). */
    private void catMenu(final int pos) {
        if (pos < 0 || pos >= curCats.size() || openSeries != null) return;
        final NativeData.Cat c = curCats.get(pos);
        if (c.id.startsWith("__") || !("live".equals(tab) || "movie".equals(tab) || "series".equals(tab))) return;
        final String k = tab;
        final String[] o = {"⤒ Mover para o topo", "↑ Subir", "↓ Descer", "🚫 Ocultar esta categoria"};
        new AlertDialog.Builder(this).setTitle(c.name).setItems(o, (d, w) -> {
            if (w == 0) data.moveCat(k, c.name, Integer.MIN_VALUE);
            else if (w == 1) data.moveCat(k, c.name, -1);
            else if (w == 2) data.moveCat(k, c.name, 1);
            else { data.hideCat(k, c.name); Toast.makeText(this, "Categoria oculta (repor em Definições › Início e canais)", Toast.LENGTH_LONG).show(); }
            String keep = w == 3 ? "" : c.name;
            curCats = withVirtual(k); shownKey = ""; catAdapter.notifyDataSetChanged();
            int ni = 0; for (int i = 0; i < curCats.size(); i++) if (curCats.get(i).name.equals(keep)) { ni = i; break; }
            pickCat(ni, false); catList.setSelection(ni); catList.requestFocus();
            opCache = null;
        }).show();
    }
    /** Ocultar um canal/filme/série ou a sua categoria (Explorar e Início). */
    private void hideOpts(List<String> opts, NativeData.Item it) {
        opts.add("🚫 Ocultar " + ("live".equals(it.kind) ? "este canal" : "series".equals(it.kind) ? "esta série" : "episode".equals(it.kind) ? "este episódio" : "este filme"));
        if (it.group.length() > 0 && !"episode".equals(it.kind)) opts.add("🚫 Ocultar a categoria «" + it.group + "»");
    }
    private boolean doHide(String o, NativeData.Item it) {
        if (!o.startsWith("🚫")) return false;
        if (o.contains("categoria")) data.hideCat("episode".equals(it.kind) ? "series" : it.kind, it.group); else data.hideItem(it.url);
        opCache = null;
        Toast.makeText(this, "Oculto. Para repor: Definições › Início e canais › Ocultos.", Toast.LENGTH_LONG).show();
        if ("home".equals(section)) renderHome(); else if ("search".equals(tab)) runSearch(); else refreshCats();
        return true;
    }

    private void itemMenu(int pos) {
        if (pos < 0 || pos >= curItems.size()) return;
        final NativeData.Item it = curItems.get(pos);
        final boolean vod = !"live".equals(it.kind) && !"series".equals(it.kind);
        List<String> opts = new ArrayList<>();
        opts.add(data.isFav(it.url) ? "Tirar dos favoritos" : "Juntar aos favoritos");
        if (vod) opts.add(data.watched(it.url) ? "Marcar como não visto" : "Marcar como visto");
        if (vod && data.pos(it.url) > 0) opts.add("Ver do início");
        opts.add("series".equals(it.kind) ? "Abrir" : "Ver");
        if (openSeries == null) hideOpts(opts, it);
        final String[] arr = opts.toArray(new String[0]);
        new AlertDialog.Builder(this).setTitle(it.name).setItems(arr, (d, w) -> {
            String o = arr[w];
            if (doHide(o, it)) return;
            if (o.contains("favoritos")) {
                boolean on = data.toggleFav(it);
                Toast.makeText(this, on ? "★ Nos favoritos" : "Fora dos favoritos", Toast.LENGTH_SHORT).show();
                if ("fav".equals(tab)) showFlat("fav"); else gridAdapter.notifyDataSetChanged();
            } else if (o.startsWith("Marcar")) {
                data.setWatched(it.url, !data.watched(it.url));
                gridAdapter.notifyDataSetChanged(); refreshCats();
            } else if (o.equals("Ver do início")) {
                if ("episode".equals(it.kind) && openSeries != null) { int i = indexOf(seriesEps, it.url); if (i >= 0) { play(seriesEps, i, 0); return; } }
                play(curItems, pos, 0);
            } else onItem(pos);
        }).show();
    }

    /* ------------------------------------------------------------ fichas de filmes e séries */
    private void closeDetails() {
        if (details == null) return;
        try { appLayer.removeView(details); } catch (Throwable ignored) { }
        details = null;
        if ("home".equals(section)) ui.post(this::startPreview);
    }

    private interface Fill { void into(LinearLayout buttons, TextView meta, TextView plot, TextView people, ImageView back, ImageView poster); }

    private View firstBtn;
    /** Ecrã de ficha (fundo, capa, título, dados, sinopse e botões). */
    private void showDetails(String title, String posterUrl, Fill f) {
        closeDetails();
        firstBtn = null;
        details = new FrameLayout(this);
        details.setBackgroundColor(BG);
        details.setClickable(true);
        ImageView back = new ImageView(this); back.setScaleType(ImageView.ScaleType.CENTER_CROP); back.setAlpha(0.35f);
        details.addView(back, new FrameLayout.LayoutParams(-1, -1));
        View shade = new View(this);
        shade.setBackground(new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{0xF20B0F14, 0xC00B0F14, 0x400B0F14}));
        details.addView(shade, new FrameLayout.LayoutParams(-1, -1));

        ScrollView sv = new ScrollView(this);
        sv.setFillViewport(true);
        LinearLayout row = new LinearLayout(this);
        row.setPadding(dp(28), dp(26), dp(28), dp(26));
        boolean narrow = getResources().getDisplayMetrics().widthPixels < dp(600);
        row.setOrientation(narrow ? LinearLayout.VERTICAL : LinearLayout.HORIZONTAL);
        ImageView poster = new ImageView(this); poster.setScaleType(ImageView.ScaleType.CENTER_CROP);
        poster.setBackground(roundRect(CARD, 10)); poster.setClipToOutline(true);
        LinearLayout.LayoutParams plp = new LinearLayout.LayoutParams(dp(narrow ? 140 : 200), dp(narrow ? 210 : 300));
        plp.rightMargin = dp(26); plp.bottomMargin = dp(14);
        row.addView(poster, plp);
        Bitmap pc = posterUrl == null ? null : bmp.get(posterUrl);
        if (pc != null) poster.setImageBitmap(pc); else loadBig(poster, posterUrl, dp(200));

        LinearLayout info = new LinearLayout(this); info.setOrientation(LinearLayout.VERTICAL);
        TextView t = new TextView(this); t.setText(title); t.setTextColor(TXT); t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(26)); t.setTypeface(null, Typeface.BOLD);
        info.addView(t);
        TextView meta = new TextView(this); meta.setTextColor(ACC); meta.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(14)); meta.setPadding(0, dp(6), 0, dp(10));
        info.addView(meta);
        LinearLayout buttons = new LinearLayout(this); buttons.setOrientation(LinearLayout.HORIZONTAL);
        HorizontalScrollView bh = new HorizontalScrollView(this); bh.setHorizontalScrollBarEnabled(false); bh.addView(buttons);
        info.addView(bh);
        TextView plot = new TextView(this); plot.setTextColor(TXT); plot.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(15)); plot.setLineSpacing(0, 1.15f); plot.setPadding(0, dp(14), 0, dp(10));
        info.addView(plot);
        TextView people = new TextView(this); people.setTextColor(MUT); people.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(13)); people.setLineSpacing(0, 1.1f);
        info.addView(people);
        row.addView(info, new LinearLayout.LayoutParams(narrow ? -1 : 0, -2, narrow ? 0 : 1));
        sv.addView(row);
        details.addView(sv, new FrameLayout.LayoutParams(-1, -1));
        appLayer.addView(details, new FrameLayout.LayoutParams(-1, -1));
        stopPreview();
        f.into(buttons, meta, plot, people, back, poster);
        if (firstBtn != null) firstBtn.requestFocus();
    }

    private Button dBtn(LinearLayout parent, String text, boolean primary, View.OnClickListener l) {
        Button b = btn(text, l);
        if (primary) b.setBackground(sel(0xFF2B6CB0, 12));
        parent.addView(b);
        if (firstBtn == null) firstBtn = b;
        return b;
    }

    private static String mins(String dur) {
        if (dur == null || dur.isEmpty()) return "";
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("^(\\d+):(\\d+)(?::\\d+)?$").matcher(dur.trim());
        if (m.find()) { int h = Integer.parseInt(m.group(1)), mi = Integer.parseInt(m.group(2)); return (h > 0 ? h + " h " : "") + mi + " min"; }
        return dur;
    }

    private void openMovieDetails(final List<NativeData.Item> list, final int idx) {
        final NativeData.Item m = list.get(idx);
        final int seq = ++loadSeq;
        setStatus("A abrir «" + m.name + "»…", true);
        bg.execute(() -> {
            final JSONObject inf = data.vodInfo(m);
            ui.post(() -> {
                if (seq != loadSeq) return;
                setStatus("", false);
                showDetails(m.name, NativeData.firstImg(inf, "movie_image", "cover_big").isEmpty() ? m.logo : NativeData.firstImg(inf, "movie_image", "cover_big"), (buttons, meta, plot, people, back, poster) -> {
                    StringBuilder mt = new StringBuilder();
                    String yr = inf.optString("releasedate", inf.optString("release_date", m.year));
                    if (yr.length() >= 4) mt.append(yr.substring(0, 4));
                    String rt = inf.optString("rating", m.rating); if (rt.length() > 0 && !"0".equals(rt)) mt.append(mt.length() > 0 ? "  ·  " : "").append("★ ").append(rt);
                    String du = mins(inf.optString("duration")); if (du.length() > 0) mt.append(mt.length() > 0 ? "  ·  " : "").append(du);
                    String ge = inf.optString("genre"); if (ge.length() > 0) mt.append(mt.length() > 0 ? "  ·  " : "").append(ge);
                    if (data.watched(m.url)) mt.append("  ·  ✓ visto");
                    meta.setText(mt);
                    String pl = inf.optString("plot", inf.optString("description")); plot.setText(pl.isEmpty() ? "Sem sinopse." : pl);
                    StringBuilder pe = new StringBuilder();
                    String di = inf.optString("director"); if (di.length() > 0) pe.append("Realização: ").append(di);
                    String ca = inf.optString("cast", inf.optString("actors")); if (ca.length() > 0) pe.append(pe.length() > 0 ? "\n" : "").append("Elenco: ").append(ca);
                    people.setText(pe);
                    loadBig(back, NativeData.firstImg(inf, "backdrop_path", "backdrop", "movie_image"), dp(960));
                    final long ps = data.pos(m.url);
                    if (ps > 0) {
                        dBtn(buttons, "▶ Continuar (" + (ps / 60000) + " min)", true, v -> { closeDetails(); play(list, idx, -1); });
                        dBtn(buttons, "↺ Do início", false, v -> { closeDetails(); play(list, idx, 0); });
                    } else dBtn(buttons, "▶ Ver", true, v -> { closeDetails(); play(list, idx, 0); });
                    final String yt = NativeData.trailerId(inf);
                    if (!yt.isEmpty()) dBtn(buttons, "🎬 Trailer", false, v -> trailer(yt));
                    final Button fb = dBtn(buttons, data.isFav(m.url) ? "★ Nos favoritos" : "☆ Favorito", false, null);
                    fb.setOnClickListener(v -> { boolean on = data.toggleFav(m); fb.setText(on ? "★ Nos favoritos" : "☆ Favorito"); });
                    final Button wb = dBtn(buttons, data.watched(m.url) ? "✓ Visto" : "Marcar como visto", false, null);
                    wb.setOnClickListener(v -> { boolean on = !data.watched(m.url); data.setWatched(m.url, on); wb.setText(on ? "✓ Visto" : "Marcar como visto"); gridAdapter.notifyDataSetChanged(); });
                });
            });
        });
    }

    /** Ficha da série: continuar no episódio certo, episódios por temporada, trailer e favorito. */
    private void openSeriesDetails(final NativeData.Item s) {
        final int seq = ++loadSeq;
        setStatus("A abrir «" + s.name + "»…", true);
        bg.execute(() -> {
            List<NativeData.Cat> seasons = null; String err = null;
            try { seasons = data.seriesInfo(s, false); } catch (Throwable e) { err = String.valueOf(e.getMessage()); }
            final List<NativeData.Cat> fs = seasons; final String fe = err;
            ui.post(() -> {
                if (seq != loadSeq) return;
                if (fs == null || fs.isEmpty()) { setStatus(fe != null ? "Erro: " + fe : "Esta série ainda não tem episódios.", false); return; }
                setStatus("", false);
                final List<NativeData.Item> eps = new ArrayList<>(); for (NativeData.Cat c : fs) eps.addAll(c.items);
                JSONObject inf0 = data.seriesMeta.get(s.sid); final JSONObject inf = inf0 == null ? new JSONObject() : inf0;
                showDetails(s.name, s.logo, (buttons, meta, plot, people, back, poster) -> {
                    StringBuilder mt = new StringBuilder();
                    String yr = inf.optString("releaseDate", inf.optString("release_date", s.year)); if (yr.length() >= 4) mt.append(yr.substring(0, 4));
                    String rt = inf.optString("rating", s.rating); if (rt.length() > 0 && !"0".equals(rt)) mt.append(mt.length() > 0 ? "  ·  " : "").append("★ ").append(rt);
                    mt.append(mt.length() > 0 ? "  ·  " : "").append(fs.size()).append(fs.size() == 1 ? " temporada" : " temporadas").append("  ·  ").append(eps.size()).append(" episódios");
                    String ge = inf.optString("genre"); if (ge.length() > 0) mt.append("  ·  ").append(ge);
                    int seen = 0; for (NativeData.Item e : eps) if (data.watched(e.url)) seen++;
                    if (seen > 0) mt.append("  ·  ✓ ").append(seen).append("/").append(eps.size());
                    meta.setText(mt);
                    String pl = inf.optString("plot", s.plot); plot.setText(pl.isEmpty() ? "Sem sinopse." : pl);
                    StringBuilder pe = new StringBuilder();
                    String di = inf.optString("director"); if (di.length() > 0) pe.append("Realização: ").append(di);
                    String ca = inf.optString("cast"); if (ca.length() > 0) pe.append(pe.length() > 0 ? "\n" : "").append("Elenco: ").append(ca);
                    people.setText(pe);
                    loadBig(back, NativeData.firstImg(inf, "backdrop_path", "cover"), dp(960));
                    /* onde continuar: o último episódio aberto (se ficou a meio) ou o seguinte (se acabou) */
                    String last = data.lastEp(s.sid);
                    int ix = 0; String lbl;
                    int li = last.isEmpty() ? -1 : indexOf(eps, last);
                    if (li >= 0) { ix = data.watched(last) && li + 1 < eps.size() ? li + 1 : li; NativeData.Item e = eps.get(ix); lbl = "▶ Continuar T" + e.season + "·E" + e.ep; }
                    else lbl = "▶ Começar T" + eps.get(0).season + "·E" + eps.get(0).ep;
                    final int fix = ix;
                    dBtn(buttons, lbl, true, v -> { closeDetails(); play(eps, fix, -1); });
                    dBtn(buttons, "☰ Episódios", false, v -> { closeDetails(); showSeasons(s, fs, eps, fix); });
                    final String yt = NativeData.trailerId(inf);
                    if (!yt.isEmpty()) dBtn(buttons, "🎬 Trailer", false, v -> trailer(yt));
                    final Button fb = dBtn(buttons, data.isFav(s.url) ? "★ Nos favoritos" : "☆ Favorito", false, null);
                    fb.setOnClickListener(v -> { boolean on = data.toggleFav(s); fb.setText(on ? "★ Nos favoritos" : "☆ Favorito"); });
                });
            });
        });
    }

    /** Temporadas na coluna, episódios na grelha (abre na temporada do episódio a seguir). */
    private void showSeasons(NativeData.Item s, List<NativeData.Cat> seasons, List<NativeData.Item> eps, int focusEp) {
        if (openSeries == null) { seriesCatBefore = curCat; seriesPosBefore = grid.getFirstVisiblePosition(); }
        String prevTab = tab;
        if (!"series".equals(tab) && catList.getVisibility() != View.VISIBLE) { catList.setVisibility(View.VISIBLE); }
        openSeries = s;
        seriesEps = eps;
        curCats = seasons; shownKey = "";
        catAdapter.notifyDataSetChanged();
        int si = 0; String target = focusEp >= 0 && focusEp < eps.size() ? eps.get(focusEp).url : "";
        for (int i = 0; i < seasons.size(); i++) if (indexOf(seasons.get(i).items, target) >= 0) { si = i; break; }
        pickCat(si, true);
        catList.setSelection(si);
        int ei = indexOf(curItems, target); if (ei >= 0) grid.setSelection(ei);
        updateSortBtn();
        setStatus("🎞️ " + s.name + " · " + seasons.size() + " temporadas   ·   Voltar: " + ("series".equals(prevTab) ? "lista de séries" : "anterior"), false);
    }

    private void closeSeries() {
        openSeries = null;
        if (!"series".equals(tab)) { showTab(tab); return; }
        curCats = withVirtual("series"); shownKey = "";
        catAdapter.notifyDataSetChanged();
        pickCat(Math.min(seriesCatBefore, Math.max(0, curCats.size() - 1)), true);
        catList.setSelection(curCat);
        grid.setSelection(seriesPosBefore);
        updateSortBtn();
        setStatus("", false);
    }

    /** Abre um episódio pelo endereço, com a série toda na lista (o seguinte começa sozinho). */
    private void playEpisode(final String sid, final String url) {
        bg.execute(() -> {
            try { data.load("series", false); } catch (Throwable ignored) { }
            NativeData.Item s = data.seriesBySid(sid);
            List<NativeData.Item> eps = new ArrayList<>();
            if (s != null) try { for (NativeData.Cat c : data.seriesInfo(s, false)) eps.addAll(c.items); } catch (Throwable ignored) { }
            final List<NativeData.Item> fe = eps;
            ui.post(() -> {
                int i = indexOf(fe, url);
                if (i >= 0) { play(fe, i, -1); return; }
                NativeData.Item it = data.findByUrl(url);
                if (it != null) { List<NativeData.Item> one = new ArrayList<>(); one.add(it); play(one, 0, -1); }
            });
        });
    }

    private void trailer(String id) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube:" + id))); return; } catch (Throwable ignored) { }
        try { startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/watch?v=" + id))); }
        catch (Throwable e) { Toast.makeText(this, "Não há nenhuma app para abrir o trailer (instala o YouTube).", Toast.LENGTH_LONG).show(); }
    }

    /* ------------------------------------------------------------ reprodução */
    /** startOverride: -1 = retoma onde ficou; 0 = do início. */
    private void play(List<NativeData.Item> list, int idx, long startOverride) {
        if (nscr != null && nscr.isOpen()) return;
        /* só os itens reproduzíveis, no máximo 1500 à volta do escolhido: é a lista do ecrã total */
        List<NativeData.Item> src = new ArrayList<>(); int start = 0;
        int from = Math.max(0, idx - 750), to = Math.min(list.size(), from + 1500);
        for (int i = from; i < to; i++) { NativeData.Item it = list.get(i); if ("series".equals(it.kind) || it.url.startsWith("series:")) continue; if (i == idx) start = src.size(); src.add(it); }
        if (src.isEmpty()) return;
        JSONArray a = new JSONArray();
        for (int i = 0; i < src.size(); i++) {
            NativeData.Item it = src.get(i);
            try {
                JSONObject o = new JSONObject();
                String nm = it.name;
                if ("episode".equals(it.kind) && it.group.length() > 0) nm = it.group + " · " + it.name;
                o.put("name", nm); o.put("logo", data.logo(it)); o.put("group", it.group); o.put("url", it.url);
                o.put("kind", "live".equals(it.kind) ? "live" : "movie");
                long p = "live".equals(it.kind) ? 0 : (i == start && startOverride >= 0 ? startOverride : data.pos(it.url));
                if (p > 0) o.put("start", p);
                a.put(o);
            } catch (Throwable ignored) { }
        }
        playing = src;
        ui.removeCallbacks(pvLimit);
        pvUrl = null;   /* o leitor passa da pré-visualização para o ecrã total (a mesma ligação, se for o mesmo canal) */
        try {
            if (np == null) np = new NativePlayer(this, root, (k, m) -> playerEvent(k, m));
            applyPlayerPrefs();
            MainActivity.NAV_JSON = playerNavJson();   /* a mesma barra de cima no ecrã do canal */
            nscr = new NativeScreen(this, root, np, (k, m) -> runOnUiThread(() -> onScreen(k, m)));
            nscr.open(a.toString(), start);
            if (nscr.isOpen()) nscr.command("full", "");
        } catch (Throwable e) {
            Toast.makeText(this, "Não consegui abrir: " + e, Toast.LENGTH_LONG).show();
        }
    }

    private void playerEvent(String k, String m) {
        NativeScreen s = nscr;
        if ("suberr".equals(k)) { runOnUiThread(() -> Toast.makeText(this, "Legendas: " + m, Toast.LENGTH_LONG).show()); return; }
        if (s != null && s.isOpen()) { s.onPlayerEvent(k, m); return; }
        if ("ui".equals(k) && pvUrl != null) runOnUiThread(this::heroPrimary);   /* tocar na pré-visualização: ecrã total */
    }

    private NativeData.Item playingByUrl(String url) { for (NativeData.Item it : playing) if (it.url.equals(url)) return it; return null; }

    private void onScreen(String k, String m) {
        switch (k) {
            case "nscreen:play": {
                NativeData.Item it = playingByUrl(m);
                nowItem = it;
                osRes = new ArrayList<>();
                if (it != null) {
                    data.pushRecent(it);
                    if ("episode".equals(it.kind) && it.sid.length() > 0) data.setLastEp(it.sid, it.url);
                    if ("live".equals(it.kind)) fetchEpg(it);
                    else if (data.osAuto() && data.osKey().length() > 0) autoSubs(it);
                    if (cast != null && cast.active()) castNow();
                }
                break;
            }
            case "nscreen:pos": {
                String[] p = m.split("\\|");
                if (p.length >= 3) try {
                    long ps = Long.parseLong(p[1]), du = Long.parseLong(p[2]);
                    data.savePos(p[0], ps, du);
                    NativeData.Item it = playingByUrl(p[0]);
                    if (it != null) watchNext(it, ps, du);
                } catch (Throwable ignored) { }
                break;
            }
            case "nscreen:closed":
                final NativeData.Item closedItem = nowItem;
                boolean keep = "home".equals(section) && closedItem != null && "live".equals(closedItem.kind) && pvPref();
                pvUrl = null;
                if (!keep) try { if (np != null) np.stop(); } catch (Throwable ignored) { }
                nowItem = null;
                if (pendingRebuild && !"home".equals(section)) { pendingRebuild = false; rebuild(); break; }
                if ("home".equals(section)) {
                    if (pendingRebuild) { pendingRebuild = false; rebuild(); break; }
                    if (closedItem != null && "live".equals(closedItem.kind)) {   /* o mesmo canal continua no destaque, sem voltar a ligar */
                        heroItem = closedItem; heroList = playing; heroIdx = Math.max(0, indexOf(playing, closedItem.url)); pvUrl = null;   /* play() do mesmo canal cancela a paragem pendente e continua */
                        refreshHero();
                    }
                    if (lastHomeFocus != null && lastHomeFocus.isAttachedToWindow()) lastHomeFocus.requestFocus();
                } else {
                    gridAdapter.notifyDataSetChanged();
                    if ("recent".equals(tab)) showFlat("recent"); else refreshCats();
                    grid.requestFocus();
                }
                break;
            case "nscreen:nav":
                if ("search".equals(m) || "movie".equals(m) || "series".equals(m) || "live".equals(m)) showTab(m);
                else showSection(secOf(m));
                break;
            case "nscreen:guide":
                showSection("guide");
                break;
            case "nscreen:subsearch": subSearch(); break;
            case "nscreen:subpick": try { subApply(Integer.parseInt(m), false); } catch (Throwable ignored) { } break;
            case "nscreen:act":
                if ("cast".equals(m)) startCast();
                break;
        }
    }

    /** Programa a decorrer e o seguinte (Xtream), mostrado no ecrã do canal. */
    private void fetchEpg(final NativeData.Item it) {
        bg.execute(() -> {
            String t = data.nowNext(it);
            if (t.isEmpty()) return;
            ui.post(() -> {
                try { if (nscr != null && nscr.isOpen()) { JSONObject o = new JSONObject(); o.put(it.url, t); nscr.command("epg", o.toString()); } } catch (Throwable ignored) { }
            });
        });
    }

    /* ------------------------------------------------------------ legendas online */
    private String subQuery(NativeData.Item it) {
        if ("episode".equals(it.kind) && it.group.length() > 0) return it.group + " S" + it.season + "E" + it.ep;
        return it.name;
    }
    private void subSearch() {
        final NativeData.Item it = nowItem;
        if (it == null) return;
        if (data.osKey().isEmpty()) { Toast.makeText(this, "Falta a chave OpenSubtitles em ⚙️ Definições.", Toast.LENGTH_LONG).show(); return; }
        bg.execute(() -> {
            try {
                final List<String[]> r = data.osSearch(subQuery(it));
                ui.post(() -> {
                    if (nowItem != it || nscr == null || !nscr.isOpen()) return;
                    osRes = r;
                    JSONArray a = new JSONArray(); for (String[] x : r) a.put(x[1]);
                    nscr.command("subres", a.toString());
                });
            } catch (final Throwable e) { ui.post(() -> Toast.makeText(this, "Legendas: " + e.getMessage(), Toast.LENGTH_LONG).show()); }
        });
    }
    private void subApply(final int i, final boolean silent) {
        if (i < 0 || i >= osRes.size() || np == null) return;
        final String fid = osRes.get(i)[0];
        final NativeData.Item it = nowItem;
        bg.execute(() -> {
            try {
                final String txt = data.osDownload(fid);
                ui.post(() -> {
                    if (nowItem != it || np == null) return;
                    np.subtitle(txt, "Português · OpenSubtitles", "pt");
                    Toast.makeText(this, "Legendas em português ativadas ✓", Toast.LENGTH_SHORT).show();
                });
            } catch (final Throwable e) { if (!silent) ui.post(() -> Toast.makeText(this, "Legendas: " + e.getMessage(), Toast.LENGTH_LONG).show()); }
        });
    }
    /** Legendas automáticas: procura e aplica a melhor em português pouco depois de começar. */
    private void autoSubs(final NativeData.Item it) {
        ui.postDelayed(() -> {
            if (nowItem != it || nscr == null || !nscr.isOpen()) return;
            bg.execute(() -> {
                try {
                    final List<String[]> r = data.osSearch(subQuery(it));
                    ui.post(() -> { if (nowItem == it && !r.isEmpty()) { osRes = r; subApply(0, true); } });
                } catch (Throwable ignored) { }
            });
        }, 6000);
    }

    /* ------------------------------------------------------------ transmitir (Chromecast) */
    private void startCast() {
        try {
            if (cast == null) cast = new CastHelper(this, (k, m) -> runOnUiThread(() -> onCast(k, m)));
            if (cast.active()) { castNow(); return; }
            castWanted = true;
            cast.pick();
        } catch (Throwable e) { Toast.makeText(this, "Transmitir não está disponível neste aparelho.", Toast.LENGTH_LONG).show(); }
    }
    private void onCast(String k, String m) {
        if ("connected".equals(k)) { Toast.makeText(this, "Ligado a " + m, Toast.LENGTH_SHORT).show(); if (castWanted) castNow(); castWanted = false; }
        else if ("failed".equals(k) || "error".equals(k) || "unavailable".equals(k)) { castWanted = false; Toast.makeText(this, "Transmitir: " + m, Toast.LENGTH_LONG).show(); }
    }
    private void castNow() {
        NativeData.Item it = nowItem;
        if (it == null || cast == null) return;
        String u = it.url.toLowerCase();
        String mime = u.contains(".m3u8") ? "application/x-mpegURL" : u.endsWith(".ts") ? "video/mp2t" : u.endsWith(".mkv") ? "video/x-matroska" : "video/mp4";
        long st = 0;
        try { st = Long.parseLong(np.pos().split("\\|")[0]); } catch (Throwable ignored) { }
        boolean live = "live".equals(it.kind);
        cast.load(it.url, it.name, mime, live, live ? 0 : st);
        try { np.pause(); } catch (Throwable ignored) { }
        Toast.makeText(this, "A transmitir «" + it.name + "»", Toast.LENGTH_SHORT).show();
    }

    /* ------------------------------------------------------------ «Continuar a ver» no ecrã inicial da TV */
    private void watchNext(NativeData.Item it, long pos, long dur) {
        final String id = it.url, name = "episode".equals(it.kind) && it.group.length() > 0 ? it.group + " · " + it.name : it.name, logo = it.logo;
        final boolean remove = dur > 0 && pos > Math.max(dur * 0.93, dur - 120000) || pos < 30000;
        bg.execute(() -> {
            try {
                android.content.ContentResolver cr = getContentResolver();
                long existing = -1;
                android.database.Cursor c = cr.query(androidx.tvprovider.media.tv.TvContractCompat.WatchNextPrograms.CONTENT_URI,
                        androidx.tvprovider.media.tv.WatchNextProgram.PROJECTION, null, null, null);
                if (c != null) {
                    try {
                        while (c.moveToNext()) {
                            androidx.tvprovider.media.tv.WatchNextProgram p = androidx.tvprovider.media.tv.WatchNextProgram.fromCursor(c);
                            if (id.equals(p.getInternalProviderId())) { existing = p.getId(); break; }
                        }
                    } finally { c.close(); }
                }
                if (remove) { if (existing >= 0) cr.delete(androidx.tvprovider.media.tv.TvContractCompat.buildWatchNextProgramUri(existing), null, null); return; }
                androidx.tvprovider.media.tv.WatchNextProgram.Builder b = new androidx.tvprovider.media.tv.WatchNextProgram.Builder();
                b.setType(androidx.tvprovider.media.tv.TvContractCompat.WatchNextPrograms.TYPE_MOVIE);
                b.setWatchNextType(androidx.tvprovider.media.tv.TvContractCompat.WatchNextPrograms.WATCH_NEXT_TYPE_CONTINUE);
                b.setLastEngagementTimeUtcMillis(System.currentTimeMillis());
                b.setTitle(name);
                b.setInternalProviderId(id);
                b.setLastPlaybackPositionMillis((int) pos);
                b.setDurationMillis((int) dur);
                b.setIntentUri(Uri.parse("cockpittv://play?id=" + Uri.encode(id)));
                if (logo != null && logo.startsWith("http")) {
                    b.setPosterArtUri(Uri.parse(logo));
                    b.setPosterArtAspectRatio(androidx.tvprovider.media.tv.TvContractCompat.PreviewPrograms.ASPECT_RATIO_2_3);
                }
                android.content.ContentValues cv = b.build().toContentValues();
                if (existing >= 0) cr.update(androidx.tvprovider.media.tv.TvContractCompat.buildWatchNextProgramUri(existing), cv, null, null);
                else cr.insert(androidx.tvprovider.media.tv.TvContractCompat.WatchNextPrograms.CONTENT_URI, cv);
            } catch (Throwable ignored) { }
        });
    }

    /* ------------------------------------------------------------ definições */
    /* v278: Definições como na app antiga: grelha de secções, cada uma abre a sua página */
    private String setPage = "";
    private static final String[][] SET_PAGES = {
            {"iptv", "Lista IPTV e ligação", "Fornecedor, atualizar listas e importar da app antiga", "iptv"},
            {"home", "Início e canais", "Aparência, operador, países, ordem, ocultos e pré-visualização", "home"},
            {"video", "Vídeo e imagem", "Ecrã total, desentrelaçamento, formato, superfície, túnel e tamanho", "video"},
            {"sound", "Som e legendas", "Dolby, acerto do som, aspeto das legendas e legendas online", "sound"},
            {"vod", "Filmes e séries", "Continuar a ver e marcas de visto", "vod"},
            {"diag", "Diagnóstico e ajuda", "Registo do leitor, envio para o GitHub e versão", "info"}};
    private Bitmap setIcon(String k) {
        try {
            if ("sound".equals(k)) { JSONObject o = new JSONObject(MainActivity.ICONS_JSON); return b64(o.optString("sound")); }
            if ("vod".equals(k)) return kindIcons.get("Filmes");
            JSONObject o = new JSONObject(asset(this, "ui/seticons.json"));
            return b64(o.optString("home".equals(k) ? "home" : "iptv".equals(k) ? "iptv" : "video".equals(k) ? "video" : "info"));
        } catch (Throwable e) { return null; }
    }
    private static String flag(String c) {
        if (c == null || !c.matches("[A-Z]{2}")) return "🌐";
        String x = "UK".equals(c) ? "GB" : c;
        return new String(Character.toChars(127397 + x.charAt(0))) + new String(Character.toChars(127397 + x.charAt(1)));
    }
    private static String ctyName(String c) {
        try { String x = "UK".equals(c) ? "GB" : c; String n = new java.util.Locale("", x).getDisplayCountry(new java.util.Locale("pt", "PT")); return n == null || n.isEmpty() || n.equals(x) ? c : n; } catch (Throwable e) { return c; }
    }

    private void showSettings() {
        catList.setVisibility(View.GONE); grid.setVisibility(View.GONE);
        setStatus("", false);
        ScrollView sv = new ScrollView(this);
        LinearLayout f = new LinearLayout(this);
        f.setOrientation(LinearLayout.VERTICAL);
        f.setPadding(dp(20), dp(8), dp(20), dp(30));
        sv.addView(f);
        final String pg = setPage;
        TextView title = new TextView(this); title.setTextColor(TXT); title.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(28)); title.setTypeface(null, Typeface.BOLD);
        if (pg.isEmpty()) {
            title.setText("Definições");
            f.addView(title);
            boolean two = !portrait();
            LinearLayout rowL = null;
            for (int i = 0; i < SET_PAGES.length; i++) {
                final String[] sp = SET_PAGES[i];
                if (rowL == null || !two || rowL.getChildCount() == 2) { rowL = new LinearLayout(this); LinearLayout.LayoutParams rl = new LinearLayout.LayoutParams(-1, -2); rl.topMargin = dp(16); f.addView(rowL, rl); }
                LinearLayout card = new LinearLayout(this); card.setGravity(Gravity.CENTER_VERTICAL);
                card.setPadding(dp(22), dp(18), dp(22), dp(18));
                card.setBackground(sel(0xFF141C28, 18)); card.setFocusable(true); card.setClickable(true);
                ImageView ic = new ImageView(this); ic.setImageBitmap(setIcon(sp[0])); ic.setPadding(dp(11), dp(11), dp(11), dp(11)); ic.setBackground(pill(0xFF2A3B52, 12));
                card.addView(ic, new LinearLayout.LayoutParams(dp(52), dp(52)));
                LinearLayout tx = new LinearLayout(this); tx.setOrientation(LinearLayout.VERTICAL); tx.setPadding(dp(16), 0, dp(10), 0);
                TextView t = new TextView(this); t.setText(sp[1]); t.setTextColor(TXT); t.setTypeface(null, Typeface.BOLD); t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(21));
                TextView d = new TextView(this); d.setText(sp[2]); d.setTextColor(MUT); d.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(15));
                tx.addView(t); tx.addView(d);
                card.addView(tx, new LinearLayout.LayoutParams(0, -2, 1));
                TextView ch = new TextView(this); ch.setText("›"); ch.setTextColor(MUT); ch.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(28));
                card.addView(ch);
                card.setOnClickListener(v -> openSetPage(sp[0]));
                LinearLayout.LayoutParams cl0 = new LinearLayout.LayoutParams(0, -1, 1);
                if (two && rowL.getChildCount() == 1) cl0.leftMargin = dp(16);
                rowL.addView(card, cl0);
            }
            if (two && rowL != null && rowL.getChildCount() == 1) rowL.addView(new View(this), new LinearLayout.LayoutParams(0, 1, 1));
            settingsView = sv;
            body.addView(sv, new LinearLayout.LayoutParams(-1, -1));
            ui.post(() -> { View c0 = findFocusable(f, setLast); if (c0 != null) c0.requestFocus(); });
            return;
        }
        String pt = ""; for (String[] x : SET_PAGES) if (x[0].equals(pg)) pt = x[1];
        LinearLayout hdr = new LinearLayout(this); hdr.setGravity(Gravity.CENTER_VERTICAL);
        hdr.addView(btn("‹ Definições", v -> openSetPage("")));
        title.setText(pt); title.setPadding(dp(14), 0, 0, 0);
        hdr.addView(title);
        f.addView(hdr);
        if ("iptv".equals(pg)) {
        f.addView(head("Lista IPTV"));
        final EditText xs = field(f, "Servidor Xtream (ex.: http://servidor:8080)", data.server, false);
        final EditText xu = field(f, "Utilizador", data.user, false);
        final EditText xp = field(f, "Palavra-passe", data.pass, true);
        final EditText mm = field(f, "…ou endereço de lista M3U", data.m3u, false);
        LinearLayout row = new LinearLayout(this); row.setPadding(0, dp(12), 0, 0);
        final Button save = btn("Guardar", v -> {
            data.saveCfg(xs.getText().toString(), xu.getText().toString(), xp.getText().toString(), mm.getText().toString());
            Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show();
            if (data.configured()) showSection("home");
        });
        row.addView(save);
        row.addView(btn("Atualizar listas agora", v -> { data.clearCache(); Toast.makeText(this, "As listas vão ser descarregadas de novo", Toast.LENGTH_SHORT).show(); showSection("home"); }));
        row.addView(btn("Importar da app antiga", v -> {
            importOld(res -> { if (res) { data.loadCfg(); data.clearCache(); Toast.makeText(this, "Importado", Toast.LENGTH_SHORT).show(); showSection("home"); } else Toast.makeText(this, "Não encontrei dados da app antiga.", Toast.LENGTH_LONG).show(); });
        }));
        f.addView(row);

        }
        if ("home".equals(pg)) {
        f.addView(head("Início"));
        final CheckBox pv = new CheckBox(this);
        pv.setText("Pré-visualização do canal no destaque (1.º OK mostra, 2.º OK abre)"); pv.setTextColor(TXT); pv.setChecked(pvPref()); pv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(15));
        pv.setOnCheckedChangeListener((b, on) -> getSharedPreferences("nativeapp", 0).edit().putBoolean("tvPrev", on).apply());
        f.addView(pv);
        f.addView(label("Animação dos cartões (canais, filmes e séries) ao aparecerem"));
        final String[] anK = new String[ANIMS.length], anL = new String[ANIMS.length];
        for (int i = 0; i < ANIMS.length; i++) { anK[i] = ANIMS[i][0]; anL[i] = ANIMS[i][1]; }
        f.addView(choice(anL, indexOfS(anK, animPref()), w -> getSharedPreferences("nativeapp", 0).edit().putString("tvAnim", anK[w]).apply()));
        f.addView(label("Efeito das filas ao deslizar"));
        final String[] vfK = new String[VFXS.length], vfL = new String[VFXS.length];
        for (int i = 0; i < VFXS.length; i++) { vfK[i] = VFXS[i][0]; vfL[i] = VFXS[i][1]; }
        f.addView(choice(vfL, indexOfS(vfK, vfxPref()), w -> getSharedPreferences("nativeapp", 0).edit().putString("tvVfx", vfK[w]).apply()));
        f.addView(note("Profundidade: as filas junto às bordas encolhem e ficam transparentes. Onda: ondulam para os lados. Parallax: o destaque esmorece e as filas aproximam-se ao subir."));

        /* ---- Operador ---- */
        f.addView(head("Operador"));
        f.addView(note("Mostra no Início e no topo dos Canais os canais pela ordem da grelha do teu operador (a melhor versão portuguesa que a tua lista tiver)."));
        final String[] opK = {"", "meo", "nos", "vodafone", "custom"};
        final String[] opL = {"Desligado", "MEO", "NOS", "Vodafone", "Personalizada"};
        final EditText opc = new EditText(this);
        opc.setText(data.opCustom()); opc.setHint("Um canal por linha (ex.: RTP 1, SIC, TVI…). Usa | para nomes alternativos."); opc.setHintTextColor(MUT); opc.setTextColor(TXT);
        opc.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(15)); opc.setMinLines(4); opc.setGravity(Gravity.TOP); opc.setBackground(sel(CARD, 10)); opc.setPadding(dp(14), dp(10), dp(14), dp(10));
        opc.setVisibility("custom".equals(data.opKey()) ? View.VISIBLE : View.GONE);
        final TextView opSrc = note("");
        final Runnable opInfo = () -> { JSONObject o = data.ops().optJSONObject(data.opKey()); opSrc.setText(o == null ? "" : "Fonte: " + o.optString("src") + " · " + o.optJSONArray("list").length() + " canais"); opSrc.setVisibility(o == null ? View.GONE : View.VISIBLE); };
        f.addView(choice(opL, indexOfS(opK, data.opKey()), w -> { data.setOp(opK[w], null); opCache = null; opc.setVisibility(w == 4 ? View.VISIBLE : View.GONE); opInfo.run(); int n = opList().size(); Toast.makeText(this, w == 0 ? "Lista do operador desligada" : n + " canais encontrados na tua lista", Toast.LENGTH_SHORT).show(); }));
        f.addView(opSrc); opInfo.run();
        LinearLayout.LayoutParams ocl = new LinearLayout.LayoutParams(-1, -2); ocl.topMargin = dp(8);
        f.addView(opc, ocl);
        opc.setOnFocusChangeListener((v, fo) -> { if (!fo) { data.setOp(data.opKey(), opc.getText().toString()); opCache = null; } });


        /* ---- Países: ordenar e ocultar (como na app antiga) ---- */
        f.addView(head("Países"));
        f.addView(note("Os países vêm dos prefixos das categorias (|PT|, |ES|, …). A ordem e os ocultos valem no Início, Explorar, Guia e Pesquisa."));
        final LinearLayout cl = new LinearLayout(this); cl.setOrientation(LinearLayout.VERTICAL);
        f.addView(cl);
        final Runnable[] paintC = new Runnable[1];
        paintC[0] = () -> {
            cl.removeAllViews();
            List<String[]> cs = data.countries();
            if (cs.isEmpty()) { cl.addView(note("Abre os Canais uma vez para eu ver os países da tua lista.")); return; }
            for (final String[] c : cs.subList(0, Math.min(40, cs.size()))) {
                LinearLayout r = new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(0, dp(3), 0, dp(3));
                boolean hid = data.ctyIsHidden(c[0]);
                TextView t = new TextView(this); t.setText(flag(c[0]) + "  " + ctyName(c[0]) + "  ·  " + c[1] + (hid ? "  · oculto" : "")); t.setTextColor(hid ? MUT : TXT); t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(16));
                r.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
                r.addView(btn("↑", v -> { data.moveCty(c[0], -1); opCache = null; paintC[0].run(); }));
                r.addView(btn("↓", v -> { data.moveCty(c[0], 1); opCache = null; paintC[0].run(); }));
                r.addView(btn(hid ? "👁 Mostrar" : "🚫 Ocultar", v -> { data.toggleCty(c[0]); opCache = null; paintC[0].run(); }));
                cl.addView(r);
            }
        };
        paintC[0].run();
        LinearLayout cr = new LinearLayout(this); cr.setPadding(0, dp(6), 0, 0);
        cr.addView(btn("Repor países", v -> { data.resetCty(); opCache = null; paintC[0].run(); }));
        cr.addView(btn("Repor ordem das categorias", v -> { data.resetOrder(); Toast.makeText(this, "Ordem original das categorias", Toast.LENGTH_SHORT).show(); }));
        f.addView(cr);

        /* ---- Ocultos ---- */
        f.addView(head("Ocultos"));
        f.addView(note("Para ocultar ou ordenar: mantém OK (ou Menu) num canal, filme ou série, ou numa categoria no Explorar."));
        final LinearLayout hl = new LinearLayout(this); hl.setOrientation(LinearLayout.VERTICAL);
        f.addView(hl);
        final Runnable[] paintH = new Runnable[1];
        paintH[0] = () -> {
            hl.removeAllViews();
            int n = data.hiddenItemsCount();
            LinearLayout r0 = new LinearLayout(this); r0.setGravity(Gravity.CENTER_VERTICAL);
            TextView t0 = new TextView(this); t0.setText(n + (n == 1 ? " canal/filme oculto" : " canais/filmes ocultos")); t0.setTextColor(TXT); t0.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(16));
            r0.addView(t0, new LinearLayout.LayoutParams(0, -2, 1));
            if (n > 0) r0.addView(btn("👁 Mostrar todos", v -> { data.showAllItems(); opCache = null; paintH[0].run(); }));
            hl.addView(r0);
            for (final String[] c : data.hiddenCats()) {
                LinearLayout r = new LinearLayout(this); r.setGravity(Gravity.CENTER_VERTICAL); r.setPadding(0, dp(3), 0, dp(3));
                TextView t = new TextView(this); t.setText(("live".equals(c[0]) ? "📺 " : "movie".equals(c[0]) ? "🎬 " : "🎞️ ") + c[1]); t.setTextColor(TXT); t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(16));
                r.addView(t, new LinearLayout.LayoutParams(0, -2, 1));
                r.addView(btn("👁 Mostrar", v -> { data.showCat(c[0], c[1]); opCache = null; paintH[0].run(); }));
                hl.addView(r);
            }
        };
        paintH[0].run();
        }
        if ("video".equals(pg)) {
        /* ---- Imagem ---- */
        f.addView(head("Imagem"));
        f.addView(label("Ajustar a taxa de atualização da TV ao vídeo (25/50/60 Hz)"));
        f.addView(choice(new String[]{"Ligado", "Desligado"}, np0().getBoolean("afr", true) ? 0 : 1, w -> { np0().edit().putBoolean("afr", w == 0).apply(); applyPlayerPrefs(); }));
        f.addView(label("Desentrelaçamento (canais 1080i, ex.: Sport TV)"));
        f.addView(choice(new String[]{"Desligado", "Adaptativo"}, np0().getBoolean("deint", false) ? 1 : 0, w -> { np0().edit().putBoolean("deint", w == 1).apply(); applyPlayerPrefs(); }));
        f.addView(label("Formato da imagem ao entrar em ecrã total"));
        f.addView(choice(new String[]{"Ajustar", "Zoom", "Esticar", "16:9", "4:3", "21:9"}, np0().getInt("aspectFull", 2), w -> np0().edit().putInt("aspectFull", w).apply()));
        f.addView(label("Vista do vídeo (se houver ecrã preto com som ou imagem a piscar)"));
        f.addView(choice(new String[]{"Automático", "Sempre compatível"}, np0().getBoolean("tvTexture", false) ? 1 : 0, w -> { np0().edit().putBoolean("tvTexture", w == 1).apply(); Toast.makeText(this, "Fecha e reabre a app para aplicar.", Toast.LENGTH_LONG).show(); }));
        f.addView(label("Modo túnel (som e imagem pela TV; só se a TV o suportar bem)"));
        f.addView(choice(new String[]{"Desligado", "Ligado"}, np0().getBoolean("tunnel", false) ? 1 : 0, w -> np0().edit().putBoolean("tunnel", w == 1).apply()));
        f.addView(label("Lista de canais em ecrã total (OK abre a lista)"));
        f.addView(choice(new String[]{"Lista de onde veio o canal", "Desligada"}, "off".equals(np0().getString("fsList", "all")) ? 1 : 0, w -> np0().edit().putString("fsList", w == 1 ? "off" : "all").apply()));
        f.addView(label("Tamanho da interface"));
        LinearLayout zr = new LinearLayout(this); zr.setGravity(Gravity.CENTER_VERTICAL);
        final TextView zv = new TextView(this); zv.setTextColor(TXT); zv.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(17)); zv.setPadding(dp(14), 0, dp(14), 0);
        zv.setText(Math.round(MainActivity.uiScaleOf(this) * 100) + " %");
        zr.addView(btn("−", v -> setUi(-0.1f)));
        zr.addView(zv);
        zr.addView(btn("+", v -> setUi(0.1f)));
        zr.addView(btn("Automático", v -> { np0().edit().remove("uiScale").apply(); recreate(); }));
        f.addView(zr);

        }
        if ("sound".equals(pg)) {
        /* ---- Som ---- */
        f.addView(head("Som"));
        f.addView(label("Som Dolby (AC-3 / E-AC-3)"));
        boolean dsw = np0().contains("dolbySw") ? np0().getBoolean("dolbySw", false) : !isTv();
        f.addView(choice(new String[]{"Descodificado pela app (FFmpeg)", "Pelo aparelho / passthrough"}, dsw ? 0 : 1, w -> np0().edit().putBoolean("dolbySw", w == 0).apply()));
        f.addView(label("Acerto do som em relação à imagem (para a saída de som atual)"));
        LinearLayout ar = new LinearLayout(this); ar.setGravity(Gravity.CENTER_VERTICAL);
        final TextView av = new TextView(this); av.setTextColor(TXT); av.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(17)); av.setPadding(dp(14), 0, dp(14), 0);
        final Runnable avShow = () -> av.setText((NativePlayer.avOffsetMs > 0 ? "+" : "") + NativePlayer.avOffsetMs + " ms" + (NativePlayer.avOffsetMs < 0 ? " (som mais tarde)" : NativePlayer.avOffsetMs > 0 ? " (som mais cedo)" : ""));
        ar.addView(btn("−100", v -> { avStep(-100); avShow.run(); }));
        ar.addView(btn("−20", v -> { avStep(-20); avShow.run(); }));
        ar.addView(av);
        ar.addView(btn("+20", v -> { avStep(20); avShow.run(); }));
        ar.addView(btn("+100", v -> { avStep(100); avShow.run(); }));
        ar.addView(btn("0", v -> { avStep(-NativePlayer.avOffsetMs); avShow.run(); }));
        HorizontalScrollView arh = new HorizontalScrollView(this); arh.addView(ar); f.addView(arh);
        try { if (np != null) np.loadAv(); } catch (Throwable ignored) { }
        avShow.run();
        f.addView(note("O valor fica guardado para cada tipo de som (Dolby / estéreo) e saída (altifalante / Bluetooth). No ecrã do vídeo também o podes mudar em Áudio."));
        f.addView(label("Som na pré-visualização do Início"));
        f.addView(choice(new String[]{"Sem som", "Com som"}, pvSnd() ? 1 : 0, w -> { getSharedPreferences("nativeapp", 0).edit().putBoolean("tvPrevSnd", w == 1).apply(); if (np != null && pvUrl != null) np.volume(w == 1 ? 1f : 0f); }));

        /* ---- Legendas ---- */
        f.addView(head("Legendas"));
        f.addView(label("Tamanho")); f.addView(choice(SUB_SIZE_L, subPref("size", 1), w -> setSubPref("size", w)));
        f.addView(label("Cor")); f.addView(choice(SUB_COL_L, subPref("color", 0), w -> setSubPref("color", w)));
        f.addView(label("Fundo")); f.addView(choice(SUB_BG_L, subPref("bg", 1), w -> setSubPref("bg", w)));
        f.addView(label("Contorno")); f.addView(choice(SUB_EDGE_L, subPref("edge", 1), w -> setSubPref("edge", w)));
        f.addView(label("Posição")); f.addView(choice(SUB_POS_L, subPref("pos", 0), w -> setSubPref("pos", w)));

        f.addView(head("Legendas online (OpenSubtitles)"));
        final EditText ok = field(f, "Chave da API (opensubtitles.com → Consumers)", data.osKey(), false);
        final EditText ou = field(f, "Utilizador (opcional, dá mais downloads)", data.osUser(), false);
        final EditText op = field(f, "Palavra-passe", data.osPass(), true);
        final CheckBox auto = new CheckBox(this);
        auto.setText("Pôr legendas em português automaticamente nos filmes e séries"); auto.setTextColor(TXT); auto.setChecked(data.osAuto());
        auto.setPadding(dp(4), dp(8), 0, dp(4));
        f.addView(auto);
        LinearLayout row2 = new LinearLayout(this); row2.setPadding(0, dp(8), 0, 0);
        row2.addView(btn("Guardar legendas", v -> { data.saveOs(ok.getText().toString(), ou.getText().toString(), op.getText().toString(), auto.isChecked()); Toast.makeText(this, "Guardado", Toast.LENGTH_SHORT).show(); }));
        f.addView(row2);

        }
        if ("vod".equals(pg)) {
        f.addView(head("Filmes e séries"));
        LinearLayout row3 = new LinearLayout(this); row3.setPadding(0, dp(4), 0, 0);
        row3.addView(btn("Limpar «Continuar a ver»", v -> {
            getSharedPreferences("nativeapp", 0).edit().putString("pos", "{}").putString("slast", "{}").apply();
            Toast.makeText(this, "Limpo", Toast.LENGTH_SHORT).show();
        }));
        row3.addView(btn("Limpar marcas de visto", v -> { getSharedPreferences("nativeapp", 0).edit().putString("watched", "{}").apply(); Toast.makeText(this, "Limpo", Toast.LENGTH_SHORT).show(); }));
        f.addView(row3);

        }
        if ("diag".equals(pg)) {
        /* ---- Diagnóstico do vídeo (como na app antiga: ver, copiar e enviar o registo para o GitHub) ---- */
        f.addView(head("Diagnóstico do vídeo"));
        f.addView(note("Vê um canal, deixa acontecer o problema, volta aqui e toca em Atualizar ou em Enviar para o GitHub."));
        final TextView dgOut = new TextView(this);
        dgOut.setTextColor(0xFFCFE0F2); dgOut.setTypeface(Typeface.MONOSPACE); dgOut.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(12)); dgOut.setTextIsSelectable(true);
        dgOut.setText("(toca em Atualizar)");
        final TextView dgMsg = note("");
        LinearLayout dr = new LinearLayout(this); dr.setPadding(0, dp(4), 0, dp(4));
        dr.addView(btn("Atualizar", v -> dgOut.setText(diagText())));
        dr.addView(btn("Copiar", v -> { try { ((android.content.ClipboardManager) getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(android.content.ClipData.newPlainText("registo", diagText())); Toast.makeText(this, "Copiado.", Toast.LENGTH_SHORT).show(); } catch (Throwable ignored) { } }));
        Button gh = btn("Enviar para o GitHub", v -> sendLog(dgMsg));
        gh.setBackground(sel(0xFF2B6CB0, 12));
        dr.addView(gh);
        HorizontalScrollView drh = new HorizontalScrollView(this); drh.addView(dr); f.addView(drh);
        f.addView(dgMsg);
        final EditText rp = field(f, "Repositório dos registos", getSharedPreferences("nativeapp", 0).getString("dbgRepo", "ramarozte-sketch/cockpit-logs"), false);
        final EditText tk = field(f, "Token do GitHub (só fica neste aparelho; «Contents: Read and write» só nesse repositório)", getSharedPreferences("nativeapp", 0).getString("dbgTok", ""), true);
        rp.setOnFocusChangeListener((v, fo) -> { if (!fo) getSharedPreferences("nativeapp", 0).edit().putString("dbgRepo", rp.getText().toString().trim()).apply(); });
        tk.setOnFocusChangeListener((v, fo) -> { if (!fo) getSharedPreferences("nativeapp", 0).edit().putString("dbgTok", tk.getText().toString().trim()).apply(); });
        tk.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence q, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence q, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) { getSharedPreferences("nativeapp", 0).edit().putString("dbgTok", e.toString().trim()).apply(); }
        });
        rp.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence q, int a, int b, int c) { }
            @Override public void onTextChanged(CharSequence q, int a, int b, int c) { }
            @Override public void afterTextChanged(Editable e) { getSharedPreferences("nativeapp", 0).edit().putString("dbgRepo", e.toString().trim()).apply(); }
        });
        ScrollView dgs = new ScrollView(this); dgs.setNestedScrollingEnabled(true); dgs.setBackground(pill(0xCC0B1220, 10)); dgs.setPadding(dp(12), dp(10), dp(12), dp(10));
        dgs.setFocusable(true);
        dgs.addView(dgOut);
        LinearLayout.LayoutParams dgl = new LinearLayout.LayoutParams(-1, dp(320)); dgl.topMargin = dp(10);
        f.addView(dgs, dgl);

        TextView ver = new TextView(this);
        String vn = ""; try { vn = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Throwable ignored) { }
        ver.setText("Cockpit TV · " + vn + "\nNo ecrã do vídeo: Áudio (faixas, Dolby e atraso do som), Legendas (embutidas e 🌐 online), ⧉ vários ecrãs e 📡 Transmitir.");
        ver.setTextColor(MUT); ver.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(12)); ver.setPadding(0, dp(18), 0, 0);
        f.addView(ver);

        }

        settingsView = sv;
        body.addView(sv, new LinearLayout.LayoutParams(-1, -1));
        ui.post(() -> { View c0 = findFocusable(f, 1); if (c0 != null) c0.requestFocus(); });
    }
    private int setLast = 0;
    private void openSetPage(String pg) {
        if (!pg.isEmpty()) { for (int i = 0; i < SET_PAGES.length; i++) if (SET_PAGES[i][0].equals(pg)) setLast = i; }
        setPage = pg;
        if (settingsView != null) { body.removeView(settingsView); settingsView = null; }
        showSettings();
    }
    /** n-ésima vista focável (0 = primeira) dentro de v. */
    private View findFocusable(View root0, int n) {
        java.util.ArrayList<View> l = new java.util.ArrayList<>();
        root0.addFocusables(l, View.FOCUS_DOWN);
        if (l.isEmpty()) return null;
        return l.get(Math.max(0, Math.min(n, l.size() - 1)));
    }

    private TextView head(String s) {
        TextView h = new TextView(this);
        h.setText(s); h.setTextColor(TXT); h.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(19)); h.setTypeface(null, Typeface.BOLD); h.setPadding(0, dp(16), 0, dp(2));
        return h;
    }

    /** Informação da app, das listas e do registo do leitor. */
    private String diagText() {
        StringBuilder b = new StringBuilder();
        String vn = ""; try { vn = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Throwable ignored) { }
        android.util.DisplayMetrics m = getResources().getDisplayMetrics();
        Runtime rt = Runtime.getRuntime();
        b.append("Cockpit TV nativo ").append(vn).append(" · ").append(android.os.Build.MANUFACTURER).append(" ").append(android.os.Build.MODEL).append(" · Android ").append(android.os.Build.VERSION.RELEASE).append("\n");
        b.append("ecrã ").append(m.widthPixels).append("x").append(m.heightPixels).append(" · escala ").append(Math.round(S * 100)).append(" % · memória ").append((rt.totalMemory() - rt.freeMemory()) >> 20).append("/").append(rt.maxMemory() >> 20).append(" MB\n");
        for (String k : new String[]{"live", "movie", "series"}) { List<NativeData.Item> l = data.all.get(k); b.append(k).append(": ").append(l == null ? "não carregado" : l.size() + " itens").append(data.cacheFresh(k) ? " (cache recente)" : "").append(" · "); }
        b.append("operador: ").append(data.opKey().isEmpty() ? "desligado" : data.opKey()).append("\n");
        b.append("imagem: taxa auto ").append(np0().getBoolean("afr", true) ? "sim" : "não").append(" · desentrelaçar ").append(np0().getBoolean("deint", false) ? "sim" : "não").append(" · túnel ").append(np0().getBoolean("tunnel", false) ? "sim" : "não").append(" · Dolby pela app ").append(np0().contains("dolbySw") ? np0().getBoolean("dolbySw", false) : !isTv()).append("\n\n");
        b.append(np == null ? "(leitor ainda não iniciado: vê um canal primeiro)" : np.dbgDump());
        return scrub(b.toString());
    }
    /** Tira utilizador, palavra-passe e tokens do registo. */
    private String scrub(String t) {
        t = t.replaceAll("(?i)(/(?:live|movie|series|timeshift)/)([^/?#\\s]+)/([^/?#\\s]+)/", "$1•••/•••/");
        t = t.replaceAll("(?i)([?&](?:username|password|user|pass|pwd|passwd|token|key|k|auth|apikey|api_key|access_token|signature|sig)=)[^&#\"\\s]*", "$1•••");
        t = t.replaceAll("(?i)(Bearer\\s+)[\\w.\\-]+", "$1•••");
        for (String x : new String[]{data.user, data.pass, data.osKey(), data.osPass(), getSharedPreferences("nativeapp", 0).getString("dbgTok", "")}) {
            if (x != null && x.length() >= 4) { t = t.replace(x, "•••"); try { String e = java.net.URLEncoder.encode(x, "UTF-8"); if (!e.equals(x)) t = t.replace(e, "•••"); } catch (Throwable ignored) { } }
        }
        return t;
    }
    /** Envia o registo para o repositório de registos (logs/AAAA-MM-DD_HHMMSS_tv.json), como a app antiga. */
    private void sendLog(final TextView msg) {
        final String tok = getSharedPreferences("nativeapp", 0).getString("dbgTok", "").trim();
        final String repo = getSharedPreferences("nativeapp", 0).getString("dbgRepo", "ramarozte-sketch/cockpit-logs").trim();
        if (tok.isEmpty()) { msg.setText("Falta o token do GitHub (campo aqui por baixo)."); return; }
        msg.setText("A enviar…");
        final String text = diagText();
        final NativeData.Item ch = nowItem != null ? nowItem : (data.recents().isEmpty() ? null : data.recents().get(0));
        bg.execute(() -> {
            String res;
            try {
                JSONObject rep = new JSONObject();
                String vn = ""; try { vn = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; } catch (Throwable ignored) { }
                rep.put("ambiente", new JSONObject().put("versao", vn).put("app", "Cockpit TV (nativa)").put("quando", new java.text.SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ssZ", java.util.Locale.US).format(new java.util.Date()))
                        .put("aparelho", android.os.Build.MANUFACTURER + " " + android.os.Build.MODEL + " · Android " + android.os.Build.VERSION.RELEASE)
                        .put("ecra", getResources().getDisplayMetrics().widthPixels + "x" + getResources().getDisplayMetrics().heightPixels));
                if (ch != null) rep.put("canal", new JSONObject().put("nome", ch.name).put("tipo", ch.kind).put("grupo", ch.group).put("url", ch.url));
                JSONArray nat = new JSONArray(); String[] lines = text.split("\n"); for (int i = Math.max(0, lines.length - 220); i < lines.length; i++) nat.put(lines[i]);
                rep.put("nativo", nat); rep.put("motivo", "manual (app TV nativa)");
                String body = scrub(rep.toString(1));
                String name = new java.text.SimpleDateFormat("yyyy-MM-dd_HHmmss", java.util.Locale.US).format(new java.util.Date()) + "_tv.json";
                HttpURLConnection c = (HttpURLConnection) new URL("https://api.github.com/repos/" + repo + "/contents/logs/" + name).openConnection();
                c.setRequestMethod("PUT"); c.setDoOutput(true); c.setConnectTimeout(10000); c.setReadTimeout(20000);
                c.setRequestProperty("Authorization", "Bearer " + tok); c.setRequestProperty("Accept", "application/vnd.github+json"); c.setRequestProperty("X-GitHub-Api-Version", "2022-11-28"); c.setRequestProperty("Content-Type", "application/json"); c.setRequestProperty("User-Agent", "CockpitTV");
                String payload = new JSONObject().put("message", "Registo da app TV " + name).put("content", android.util.Base64.encodeToString(body.getBytes("UTF-8"), android.util.Base64.NO_WRAP)).toString();
                c.getOutputStream().write(payload.getBytes("UTF-8"));
                int code = c.getResponseCode();
                if (code >= 200 && code < 300) res = "Enviado ✓ logs/" + name;
                else res = "GitHub " + code + (code == 404 ? " (o repositório não existe ou o token não tem acesso)" : code == 401 ? " (token inválido ou expirado)" : "");
                c.disconnect();
            } catch (Throwable e) { res = "Não consegui enviar: " + e.getMessage(); }
            final String fr = res;
            ui.post(() -> { msg.setText(fr); if (fr.startsWith("Enviado")) Toast.makeText(this, "Registo enviado para o GitHub ✓", Toast.LENGTH_SHORT).show(); });
        });
    }

    private interface Pick { void on(int w); }
    /** Fila de botões de escolha (o escolhido em azul, como na app antiga). */
    private View choice(final String[] labels, int cur, final Pick p) {
        HorizontalScrollView hs = new HorizontalScrollView(this); hs.setHorizontalScrollBarEnabled(false); hs.setClipToPadding(false);
        final LinearLayout r = new LinearLayout(this); r.setPadding(0, dp(4), 0, dp(6)); r.setClipChildren(false);
        final int[] sel = {Math.max(0, Math.min(labels.length - 1, cur))};
        for (int i = 0; i < labels.length; i++) {
            final int w = i;
            final TextView b = thBtn(labels[i], null, i == sel[0], null);
            b.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(15)); b.setMinHeight(dp(40));
            b.setOnClickListener(v -> { sel[0] = w; for (int j = 0; j < r.getChildCount(); j++) setPrimary((TextView) r.getChildAt(j), null, j == w); p.on(w); });
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, dp(42)); lp.rightMargin = dp(10);
            r.addView(b, lp);
        }
        hs.addView(r);
        return hs;
    }
    private TextView label(String s) { TextView t = new TextView(this); t.setText(s); t.setTextColor(TXT); t.setAlpha(0.9f); t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(15)); t.setPadding(0, dp(10), 0, dp(2)); return t; }
    private TextView note(String s) { TextView t = new TextView(this); t.setText(s); t.setTextColor(MUT); t.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(13)); t.setPadding(0, dp(2), 0, dp(4)); return t; }
    private static int indexOfS(String[] a, String v) { for (int i = 0; i < a.length; i++) if (a[i].equals(v)) return i; return 0; }
    private boolean isTv() { try { android.app.UiModeManager um = (android.app.UiModeManager) getSystemService(UI_MODE_SERVICE); return um != null && um.getCurrentModeType() == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION; } catch (Throwable e) { return false; } }
    private void setUi(float d) {
        float v = Math.max(0.5f, Math.min(1.6f, MainActivity.uiScaleOf(this) + d));
        np0().edit().putFloat("uiScale", v).apply();
        recreate();
    }
    /** Acerto do som: precisa do leitor para saber a saída atual (altifalante / Bluetooth, Dolby / estéreo). */
    private void avStep(int d) {
        try {
            if (np == null) { np = new NativePlayer(this, root, (k, m) -> playerEvent(k, m)); applyPlayerPrefs(); }
            np.loadAv();
            np.setAv(np.getAv() + d);
        } catch (Throwable ignored) { }
    }

    private EditText field(LinearLayout f, String hint, String val, boolean pw) {
        TextView l = new TextView(this); l.setText(hint); l.setTextColor(MUT); l.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(12.5f)); l.setPadding(0, dp(8), 0, dp(3));
        f.addView(l);
        EditText e = new EditText(this);
        e.setText(val); e.setTextColor(TXT); e.setSingleLine(true);
        e.setInputType(pw ? (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD) : (InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI));
        e.setBackground(sel(CARD, 10)); e.setPadding(dp(14), dp(10), dp(14), dp(10));
        f.addView(e, new LinearLayout.LayoutParams(-1, -2));
        return e;
    }

    private Button btn(String t, View.OnClickListener l) {
        Button b = new Button(this);
        b.setText(t); b.setAllCaps(false); b.setTextColor(TXT); b.setTextSize(android.util.TypedValue.COMPLEX_UNIT_PX, fz(14));
        b.setBackground(sel(0xFF1F2B38, 12)); b.setPadding(dp(16), dp(8), dp(16), dp(8));
        b.setStateListAnimator(null);
        if (l != null) b.setOnClickListener(l);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-2, -2); lp.rightMargin = dp(10);
        b.setLayoutParams(lp);
        return b;
    }

    /* ------------------------------------------------------------ teclas, voltar e ciclo de vida */
    @Override
    public void onBackPressed() {
        if (nscr != null && nscr.isOpen()) { nscr.onBack(); return; }
        if (details != null) { closeDetails(); grid.requestFocus(); return; }
        if (openSeries != null) { closeSeries(); return; }
        if (!"home".equals(section) && grid.hasFocus() && catList.getVisibility() == View.VISIBLE) { catList.requestFocus(); return; }
        if ("settings".equals(section) && !setPage.isEmpty()) { openSetPage(""); return; }
        if (!"home".equals(section)) { showSection("home"); return; }
        if (homeScroll.getScrollY() > 0 && !homeKinds.hasFocus()) { homeScroll.scrollTo(0, 0); View k = homeKinds.getChildAt(0); if (k != null) k.requestFocus(); return; }
        super.onBackPressed();
    }

    @Override
    public boolean onKeyDown(int code, KeyEvent ev) {
        if (code == KeyEvent.KEYCODE_ESCAPE) { onBackPressed(); return true; }
        if (nscr != null && nscr.isOpen()) { if (nscr.onKey(ev)) return true; return super.onKeyDown(code, ev); }
        if (code == KeyEvent.KEYCODE_MENU || code == KeyEvent.KEYCODE_BOOKMARK) {
            if (details == null && grid.hasFocus()) { itemMenu(grid.getSelectedItemPosition()); return true; }
        }
        return super.onKeyDown(code, ev);
    }

    /** Ecrã inteiro sem barras do sistema (como a app antiga): o vídeo em ecrã total ocupa o telemóvel todo. */
    private void immersive() {
        try {
            getWindow().getDecorView().setSystemUiVisibility(
                    View.SYSTEM_UI_FLAG_LAYOUT_STABLE | View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                            | View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        } catch (Throwable ignored) { }
    }

    @Override
    public void onWindowFocusChanged(boolean focus) {
        super.onWindowFocusChanged(focus);
        if (focus) immersive();
    }

    @Override
    public void onConfigurationChanged(android.content.res.Configuration c) {
        super.onConfigurationChanged(c);
        if (nscr != null && nscr.isOpen()) { nscr.onConfigChanged(); pendingRebuild = true; return; }
        rebuild();
    }
    private boolean pendingRebuild = false;
    /** Rodar o telemóvel: refaz a interface com a escala nova (os dados ficam). */
    private void rebuild() {
        try {
            float old = S; computeScale();
            ui.removeCallbacks(clockTick);
            stopPreview();
            details = null; settingsView = null;
            navTabs.clear();
            if (appLayer != null) root.removeView(appLayer);
            buildUi();
            String sec = section; section = "";
            if ("home".equals(sec) || sec.isEmpty()) showSection("home");
            else if ("settings".equals(sec)) showSection("settings");
            else { section = sec; homeScroll.setVisibility(View.GONE); browseCol.setVisibility(View.VISIBLE); chipsRow.setVisibility("guide".equals(sec) ? View.GONE : View.VISIBLE); for (java.util.Map.Entry<String, View> e : navTabs.entrySet()) styleTab(e.getValue(), e.getKey()); showTab(tab); }
        } catch (Throwable ignored) { }
    }

    @Override
    protected void onUserLeaveHint() {
        super.onUserLeaveHint();
        try {
            if (android.os.Build.VERSION.SDK_INT < 26 || np == null || !np.isActive() || nscr == null || !nscr.isOpen()) return;
            android.app.UiModeManager um = (android.app.UiModeManager) getSystemService(UI_MODE_SERVICE);
            if (um != null && um.getCurrentModeType() == android.content.res.Configuration.UI_MODE_TYPE_TELEVISION) return;
            if (!getPackageManager().hasSystemFeature(android.content.pm.PackageManager.FEATURE_PICTURE_IN_PICTURE)) return;
            enterPictureInPictureMode(new android.app.PictureInPictureParams.Builder().setAspectRatio(new android.util.Rational(16, 9)).build());
        } catch (Throwable ignored) { }
    }

    @Override
    public void onPictureInPictureModeChanged(boolean in, android.content.res.Configuration cfg) {
        super.onPictureInPictureModeChanged(in, cfg);
        try { if (nscr != null && nscr.isOpen()) nscr.setSystemPip(in); } catch (Throwable ignored) { }
    }

    @Override
    protected void onStart() {
        super.onStart();
        if (np != null && nscr != null && nscr.isOpen()) np.resumeAfterBackground();
        else if ("home".equals(section)) ui.postDelayed(this::startPreview, 300);
    }

    @Override
    protected void onStop() {
        super.onStop();
        if (nscr != null && nscr.isOpen()) { if (np != null) np.pause(); }
        else stopPreview();
    }

    @Override
    protected void onDestroy() {
        try { if (nscr != null && nscr.isOpen()) nscr.close(); } catch (Throwable ignored) { }
        if (np != null) { np.release(); np = null; }
        if (cast != null) { try { cast.release(); } catch (Throwable ignored) { } cast = null; }
        bg.shutdownNow(); img.shutdownNow();
        super.onDestroy();
    }
}
