#!/usr/bin/env python3
"""Gera app/src/main/assets/index.html (só IPTV) a partir do index.html do Cockpit.
Uso: python3 tools/build_assets.py [caminho/para/cockpit/index.html]"""
import sys, os
src = sys.argv[1] if len(sys.argv) > 1 else os.path.join(os.path.dirname(__file__), "..", "..", "cockpit", "index.html")
out = os.path.join(os.path.dirname(__file__), "..", "app", "src", "main", "assets", "index.html")
h = open(src, encoding="utf-8").read()

def rep(old, new, count=1):
    global h
    if h.count(old) != count:
        sys.exit("Não encontrei (ou há repetições) de: " + old[:70])
    h = h.replace(old, new)

rep("<head>", '<head>\n<script>window.ANDROID = (typeof Android !== "undefined");</script>')
rep("<title>Cockpit", "<title>Cockpit TV")
rep('id="bootLogo">COCKPIT<', 'id="bootLogo">COCKPIT TV<')
rep("if(!url || !cfg.proxy) return url;", "if(!url || !cfg.proxy || window.ANDROID) return url;")
rep("if(!url || !cfg.proxy2) return url;", "if(!url || !cfg.proxy2 || window.ANDROID) return url;")
rep('if(window.top !== window || location.protocol==="file:") return',
    'if(window.ANDROID) return "Não consegui ligar ao servidor (" + e.message + "). Confirma o endereço, o utilizador e a palavra-passe e a ligação à internet.";\n  if(window.top !== window || location.protocol==="file:") return')
rep("function show(view){\n", 'function show(view){\n  if(window.ANDROID && view !== "settings") view = "tv";\n')
rep("applyPassenger(); applyLayout();", 'if(window.ANDROID){ cfg.layout = "classic"; cfg.passenger = false; }\napplyPassenger(); applyLayout();')
rep('\nif(passengerImport()) show("tv");', '\nif(window.ANDROID) show("tv");\nelse if(passengerImport()) show("tv");')

CSS = """
/* ===== Cockpit TV (Android) ===== */
body.android .rail,body.android .tsonly,body.android #tsPanel,body.android #chipCar,body.android #chipNet,body.android #lockNow,body.android #teslaFs,body.android #heard,body.android #micBtn{display:none!important}
body.android .app{grid-template-columns:1fr!important;grid-template-rows:54px 1fr!important}
body.android .top{grid-column:1!important;grid-row:1!important;padding:0 14px;gap:10px}
body.android main{grid-column:1!important;grid-row:2!important}
body.android .app.cinema{grid-template-rows:54px 1fr!important}
body.android .clock{font-size:22px}
body.android :focus-visible{outline:4px solid var(--accent)!important;outline-offset:3px;box-shadow:0 0 0 8px color-mix(in srgb,var(--accent) 30%,transparent)}
body.android .item:focus-visible{background:var(--panel-2)}
body.android.tv .app{padding:14px 22px 0;box-sizing:border-box}
body.android.tv .btn,body.android.tv .tab,body.android.tv .item{min-height:54px}
body.android.tv{font-size:18px}
body.android .top .btn[aria-pressed="true"]{background:var(--accent);color:var(--accent-ink);border-color:var(--accent)}
"""
rep("</style>", CSS + "</style>", count=h.count("</style>")) if h.count("</style>") == 1 else None
if h.count("</style>") != 1:
    i = h.rfind("</style>"); h = h[:i] + CSS + h[i:]

JS = r"""
<script>
/* ===== Cockpit TV (Android): só IPTV ===== */
(function(){
  if(!window.ANDROID) return;
  document.body.classList.add("android");
  const top = document.querySelector(".top"), sp = top.querySelector(".spacer");
  const mk = (txt, v) => { const b = document.createElement("button"); b.className = "btn"; b.textContent = txt; b.onclick = () => show(v); b.dataset.v = v; top.insertBefore(b, sp); return b; };
  const bTv = mk("📺 TV", "tv"), bSet = mk("⚙ Definições", "settings");
  const sync = () => { bTv.setAttribute("aria-pressed", currentView === "tv" ? "true" : "false"); bSet.setAttribute("aria-pressed", currentView === "settings" ? "true" : "false"); };
  const _show = window.show;
  window.show = function(v){ const r = _show.apply(this, arguments); sync(); return r; };
  sync();

  /* Definições: só o que interessa à TV */
  const v = $("v-settings");
  const panels = v.querySelectorAll(".grid2 > .panel");
  const h2txt = el => el.tagName === "H2" ? el.textContent.trim() : "";
  if(panels[0]){
    const kids = [...panels[0].children];
    const iLay = kids.findIndex(e => h2txt(e) === "Layout");
    kids.forEach((e, i) => { if(i <= iLay || e.classList.contains("layouts")) e.hidden = true; });
  }
  if(panels[1]){
    const kids = [...panels[1].children];
    const iProxy = kids.findIndex(e => h2txt(e) === "Proxy");
    const iLoad = kids.findIndex(e => e.querySelector && e.querySelector("#btnLoadIptv"));
    const iStat = kids.findIndex(e => e.id === "iptvStatus");
    kids.forEach((e, i) => { if((iProxy >= 0 && i >= iProxy && i < iLoad) || i > iStat) e.hidden = true; });
    const info = document.createElement("p"); info.className = "small muted"; info.style.margin = "0";
    info.textContent = "Esta aplicação liga-se diretamente ao servidor IPTV (não precisa de proxy).";
    panels[1].insertBefore(info, kids[iLoad]);
  }

  /* Ficheiro de exportação: o Android abre o seletor para escolheres a pasta e o nome */
  window.androidSaved = (ok, where) => { orgXferMsg(ok ? "Ficheiro guardado: " + where : "Não guardei o ficheiro (cancelaste ou não há seletor de ficheiros). Copia o código da caixa em baixo.", !ok); };
  const eb = $("orgExpFile");
  if(eb){ eb.textContent = "Guardar ficheiro…"; eb.onclick = () => {
    const txt = JSON.stringify(orgExport($("orgInclAcc").checked), null, 1); $("orgXfer").value = txt;
    let ok = false; try{ ok = Android.saveText("cockpit-iptv-definicoes.json", txt); }catch(e){}
    if(!ok) orgXferMsg("Não consegui abrir o seletor. Copia o código da caixa.", true);
  }; }

  /* Informar a parte nativa do Referer a usar nos canais abertos (RTP, SIC, …) */
  const _pc = window.playChannel;
  window.playChannel = function(c){ try{ Android.ctx(refFor(c) || ""); }catch(e){} return _pc.apply(this, arguments); };


  /* ===== Navegação com o comando da TV (D-pad) ===== */
  try{ if(Android.isTv && Android.isTv()) document.body.classList.add("tv"); }catch(e){}
  const FOC = 'button:not([disabled]),a[href],input:not([type=hidden]):not([disabled]),select:not([disabled]),textarea:not([disabled]),summary,label.btn,[tabindex="0"]';
  const prep = () => document.querySelectorAll("label.btn").forEach(l => { if(!l.hasAttribute("tabindex")) l.tabIndex = 0; });
  prep();
  const vis = el => el.getClientRects().length > 0 && getComputedStyle(el).visibility !== "hidden" && !el.closest("[inert]");
  const openDlg = () => document.querySelector(".epgdlg:not([hidden]),.trkdlg:not([hidden])");
  const focusables = () => [...(openDlg() || document).querySelectorAll(FOC)].filter(vis);
  const cinema = () => document.querySelector(".app").classList.contains("cinema");
  const scrollParent = el => { for(let n = el; n && n !== document.body; n = n.parentElement){ const s = getComputedStyle(n); if(/(auto|scroll)/.test(s.overflowY) && n.scrollHeight > n.clientHeight + 4) return n; } return document.scrollingElement; };
  function move(dx, dy){
    const els = focusables(), cur = document.activeElement;
    if(!cur || cur === document.body || !els.includes(cur)){ if(els[0]) els[0].focus(); return; }
    const cr = cur.getBoundingClientRect(), ccx = cr.left + cr.width/2, ccy = cr.top + cr.height/2;
    let best = null, bs = Infinity;
    for(const el of els){
      if(el === cur) continue;
      const r = el.getBoundingClientRect(), cx = r.left + r.width/2, cy = r.top + r.height/2;
      let main, cross;
      if(dx){ if((cx - ccx) * dx <= 1) continue; main = Math.max(0, dx > 0 ? r.left - cr.right : cr.left - r.right); cross = Math.max(0, r.top - cr.bottom, cr.top - r.bottom); }
      else  { if((cy - ccy) * dy <= 1) continue; main = Math.max(0, dy > 0 ? r.top - cr.bottom : cr.top - r.bottom); cross = Math.max(0, r.left - cr.right, cr.left - r.right); }
      const off = dx ? Math.abs(cy - ccy) : Math.abs(cx - ccx);
      const sc = main + cross * 3 + off * 0.15;
      if(sc < bs){ bs = sc; best = el; }
    }
    if(best){ best.focus({preventScroll:true}); best.scrollIntoView({block:"nearest", inline:"nearest"}); }
    else if(dy){ const sp = scrollParent(cur); if(sp) sp.scrollBy(0, dy * 180); }
  }
  const clickId = id => { const b = $(id); if(b) b.click(); };
  document.addEventListener("keydown", e => {
    const k = e.key, a = document.activeElement;
    if(e.altKey || e.ctrlKey || e.metaKey) return;
    if(k === "ChannelUp" || k === "PageDown"){ e.preventDefault(); clickId("chNext"); return; }
    if(k === "ChannelDown" || k === "PageUp"){ e.preventDefault(); clickId("chPrev"); return; }
    if(k === "MediaPlayPause" || k === "MediaPlay" || k === "MediaPause"){
      const v = $("vid" + (typeof tvTarget === "number" ? tvTarget : 0)); if(v){ e.preventDefault(); (k === "MediaPause" || (k === "MediaPlayPause" && !v.paused)) ? v.pause() : v.play().catch(()=>{}); } return; }
    const dir = {ArrowUp:[0,-1], ArrowDown:[0,1], ArrowLeft:[-1,0], ArrowRight:[1,0]}[k];
    if(dir){
      const typing = a && (a.tagName === "TEXTAREA" || (a.tagName === "INPUT" && /^(text|search|url|password|email|number|tel)$/.test(a.type)));
      if(dir[0] && (typing || (a && a.type === "range"))) return;
      e.preventDefault();
      if(cinema() && dir[1] && !openDlg()){ clickId(dir[1] < 0 ? "chNext" : "chPrev"); return; }
      move(dir[0], dir[1]); return;
    }
    if(k === "Enter" && a && (a.type === "checkbox" || a.type === "radio" || a.tagName === "LABEL")){ e.preventDefault(); a.click(); }
  }, true);
  /* Foco inicial e foco ao abrir/fechar janelas */
  setTimeout(() => { if(!document.activeElement || document.activeElement === document.body) bTv.focus(); }, 600);
  let prevFocus = null;
  new MutationObserver(() => {
    prep();
    const d = openDlg();
    if(d && !d.contains(document.activeElement)){ if(!prevFocus) prevFocus = document.activeElement; const f = [...d.querySelectorAll(FOC)].filter(vis)[0]; if(f) f.focus(); }
    else if(!d && prevFocus){ const p = prevFocus; prevFocus = null; if(document.contains(p) && vis(p)) p.focus(); }
  }).observe(document.body, {subtree:true, attributes:true, attributeFilter:["hidden"]});

  /* Botão Voltar */
  window.androidBack = function(){
    const d = document.querySelector(".epgdlg:not([hidden]),.trkdlg:not([hidden])");
    if(d){ const b = [...d.querySelectorAll("button")].find(x => /^(fechar|✕|×|close)/i.test(x.textContent.trim())); if(b) b.click(); else d.hidden = true; return true; }
    if(document.querySelector(".app").classList.contains("cinema")){ setCinema(false); return true; }
    if(currentView === "settings"){ show("tv"); return true; }
    return false;
  };
})();
</script>
"""
i = h.rfind("</body>")
h = h[:i] + JS + h[i:]
os.makedirs(os.path.dirname(out), exist_ok=True)
open(out, "w", encoding="utf-8").write(h)
print("OK ->", os.path.normpath(out), len(h)//1024, "KB")
