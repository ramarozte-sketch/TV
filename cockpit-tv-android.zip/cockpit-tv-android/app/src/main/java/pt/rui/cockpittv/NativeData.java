package pt.rui.cockpittv;

import android.content.Context;
import android.content.SharedPreferences;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;

/**
 * App nativa (v270): dados da lista IPTV sem a página web.
 * Lê a configuração que a app clássica guardou (servidor Xtream / M3U, favoritos, vistos), descarrega as listas
 * pela API Xtream (ou M3U), guarda-as em disco (abre instantaneamente da vez seguinte) e organiza por categorias.
 * Tudo corre fora da thread da interface.
 */
final class NativeData {
    static final class Item {
        String name = "", logo = "", group = "", url = "", kind = "live", id = "", sid = "", epgId = "", plot = "", rating = "", year = "";
        int num = 0;
        long added = 0;
        boolean logoDone = false;
        int season = 0, ep = 0;
        JSONObject json() {
            JSONObject o = new JSONObject();
            try { o.put("name", name); o.put("logo", logo); o.put("group", group); o.put("url", url); o.put("kind", kind); o.put("id", id); o.put("sid", sid); o.put("epgId", epgId); o.put("season", season); o.put("ep", ep); } catch (Throwable ignored) { }
            return o;
        }
        static Item from(JSONObject o) {
            Item it = new Item();
            it.name = o.optString("name"); it.logo = o.optString("logo"); it.group = o.optString("group"); it.url = o.optString("url");
            it.kind = o.optString("kind", "live"); it.id = o.optString("id"); it.sid = o.optString("sid"); it.epgId = o.optString("epgId");
            it.season = o.optInt("season"); it.ep = o.optInt("ep");
            if ("vod".equals(it.kind)) it.kind = "movie";
            return it;
        }
    }
    static final class Cat { String id = "", name = ""; final List<Item> items = new ArrayList<>(); }

    private static final long TTL = 12L * 3600 * 1000;
    private static final String UA = "Mozilla/5.0 (Linux; Android) CockpitTV";
    private final Context ctx;
    private final SharedPreferences sp;
    String server = "", user = "", pass = "", m3u = "";
    /** por tipo (live / movie / series): categorias por ordem, com os itens de cada uma */
    final Map<String, List<Cat>> cats = new java.util.concurrent.ConcurrentHashMap<>();
    final Map<String, List<Item>> all = new java.util.concurrent.ConcurrentHashMap<>();

    NativeData(Context c) {
        ctx = c.getApplicationContext();
        sp = ctx.getSharedPreferences("nativeapp", 0);
        loadCfg();
    }

    /* ------------------------------------------------------------ configuração */
    void loadCfg() {
        server = sp.getString("xs", ""); user = sp.getString("xu", ""); pass = sp.getString("xp", ""); m3u = sp.getString("m3u", "");
        /* primeira vez: vem da app clássica (a MainActivity copia o localStorage da página para «webexport») */
        if (server.isEmpty() && m3u.isEmpty()) importFromWeb();
    }
    boolean importFromWeb() {
        SharedPreferences w = ctx.getSharedPreferences("webexport", 0);
        return importJson(w.getString("cfg", ""), w.getString("favs", "[]"), w.getString("recents", "[]"));
    }
    /** Dados da app antiga (localStorage da página): servidor, conta OpenSubtitles, favoritos e vistos. */
    boolean importJson(String c, String favs, String recents) {
        try {
            if (c == null || c.length() < 3) return false;
            JSONObject o = new JSONObject(c);
            if (o.optString("xs").isEmpty() && o.optString("m3u").isEmpty()) return false;
            SharedPreferences.Editor e = sp.edit();
            e.putString("xs", o.optString("xs")).putString("xu", o.optString("xu")).putString("xp", o.optString("xp")).putString("m3u", o.optString("m3u")).putString("epg", o.optString("epg"));
            if (sp.getString("osKey", "").isEmpty()) e.putString("osKey", o.optString("osKey")).putString("osUser", o.optString("osUser")).putString("osPass", o.optString("osPass")).putBoolean("osAuto", o.optBoolean("osAuto"));
            if (!sp.contains("favs") && favs != null) e.putString("favs", favs);
            if (!sp.contains("recents") && recents != null) e.putString("recents", recents);
            e.apply();
            server = o.optString("xs"); user = o.optString("xu"); pass = o.optString("xp"); m3u = o.optString("m3u");
            return server.length() > 0 || m3u.length() > 0;
        } catch (Throwable e) { return false; }
    }
    void saveCfg(String xs, String xu, String xp, String m) {
        sp.edit().putString("xs", xs.trim()).putString("xu", xu.trim()).putString("xp", xp).putString("m3u", m.trim()).apply();
        server = xs.trim(); user = xu.trim(); pass = xp; m3u = m.trim();
        clearCache();
    }
    boolean configured() { return (server.length() > 0 && user.length() > 0) || m3u.length() > 0; }
    private String base() {
        String s = server.trim(); if (s.isEmpty()) return "";
        if (!s.startsWith("http")) s = "http://" + s;
        s = s.replaceAll("/(player_api|get)\\.php.*$", "");
        while (s.endsWith("/")) s = s.substring(0, s.length() - 1);
        return s;
    }
    private String enc(String s) { try { return URLEncoder.encode(s, "UTF-8"); } catch (Throwable e) { return s; } }
    private String api(String action, String extra) { return base() + "/player_api.php?username=" + enc(user) + "&password=" + enc(pass) + "&action=" + action + (extra == null ? "" : extra); }

    /* ------------------------------------------------------------ rede e cache em disco */
    private File cacheFile(String k) { File d = new File(ctx.getFilesDir(), "nlist"); d.mkdirs(); return new File(d, k.replaceAll("[^a-zA-Z0-9_]", "_") + ".json"); }
    void clearCache() { try { File d = new File(ctx.getFilesDir(), "nlist"); File[] fs = d.listFiles(); if (fs != null) for (File f : fs) f.delete(); } catch (Throwable ignored) { } cats.clear(); all.clear(); }
    boolean cacheFresh(String kind) { File f = cacheFile("x_" + kind + "_streams"); return f.exists() && System.currentTimeMillis() - f.lastModified() < TTL; }

    static String http(String u, int timeoutMs) throws Exception {
        HttpURLConnection c = null;
        try {
            String cur = u;
            for (int i = 0; i < 6; i++) {
                c = (HttpURLConnection) new URL(cur).openConnection();
                c.setInstanceFollowRedirects(false);
                c.setConnectTimeout(timeoutMs); c.setReadTimeout(timeoutMs * 3);
                c.setRequestProperty("User-Agent", UA);
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) { String loc = c.getHeaderField("Location"); c.disconnect(); if (loc == null) break; cur = new URL(new URL(cur), loc).toString(); continue; }
                if (code >= 400) throw new Exception("HTTP " + code);
                InputStream in = c.getInputStream();
                BufferedReader r = new BufferedReader(new InputStreamReader(in, "UTF-8"), 65536);
                StringBuilder sb = new StringBuilder(65536); char[] buf = new char[16384]; int n;
                while ((n = r.read(buf)) > 0) sb.append(buf, 0, n);
                r.close();
                return sb.toString();
            }
            throw new Exception("demasiados redirecionamentos");
        } finally { if (c != null) try { c.disconnect(); } catch (Throwable ignored) { } }
    }
    private String cached(String key, String url, boolean force) throws Exception {
        File f = cacheFile(key);
        if (!force && f.exists() && System.currentTimeMillis() - f.lastModified() < TTL) return readFile(f);
        try {
            String s = http(url, 15000);
            try (FileOutputStream o = new FileOutputStream(f)) { o.write(s.getBytes("UTF-8")); }
            return s;
        } catch (Exception e) {
            if (f.exists()) return readFile(f);   /* sem rede: usa a última lista guardada, mesmo antiga */
            throw e;
        }
    }
    private static String readFile(File f) throws Exception {
        try (FileInputStream in = new FileInputStream(f)) { byte[] b = new byte[(int) f.length()]; int o = 0, n; while (o < b.length && (n = in.read(b, o, b.length - o)) > 0) o += n; return new String(b, 0, o, "UTF-8"); }
    }

    /* ------------------------------------------------------------ carregar listas */
    /** kind: live | movie | series. Força a renovação com force=true. */
    /* v280: cada tipo tem o seu cadeado (carregar os 246 mil filmes já não bloqueia os canais) */
    private final Map<String, Object> locks = new java.util.concurrent.ConcurrentHashMap<>();
    private Object lockOf(String k) { Object o = locks.get(k); if (o == null) { o = new Object(); Object p = ((java.util.concurrent.ConcurrentHashMap<String, Object>) locks).putIfAbsent(k, o); if (p != null) o = p; } return o; }
    void load(String kind, boolean force) throws Exception {
        if (!force && cats.containsKey(kind)) return;
        boolean x = server.length() > 0 && user.length() > 0;
        synchronized (lockOf(x ? kind : "m3u")) {
            if (!force && cats.containsKey(kind)) return;
            if (x) loadXtream(kind, force);
            else if (m3u.length() > 0) loadM3u(force);
            else throw new Exception("Sem lista configurada. Abre as Definições.");
        }
    }
    /** Ficheiro da lista no aparelho (descarrega para o disco às partes; sem rede usa o último guardado). */
    private File fetchFile(String key, String url, boolean force) throws Exception {
        File f = cacheFile(key);
        if (!force && f.exists() && f.length() > 0 && System.currentTimeMillis() - f.lastModified() < TTL) return f;
        File tmp = new File(f.getPath() + ".part");
        HttpURLConnection c = null;
        try {
            String cur = url;
            for (int i = 0; i < 6; i++) {
                c = (HttpURLConnection) new URL(cur).openConnection();
                c.setInstanceFollowRedirects(false); c.setConnectTimeout(15000); c.setReadTimeout(45000);
                c.setRequestProperty("User-Agent", UA);
                int code = c.getResponseCode();
                if (code >= 300 && code < 400) { String loc = c.getHeaderField("Location"); c.disconnect(); if (loc == null) break; cur = new URL(new URL(cur), loc).toString(); continue; }
                if (code >= 400) throw new Exception("HTTP " + code);
                try (InputStream in = c.getInputStream(); FileOutputStream o = new FileOutputStream(tmp)) { byte[] b = new byte[65536]; int n; while ((n = in.read(b)) > 0) o.write(b, 0, n); }
                if (tmp.length() < 2) throw new Exception("lista vazia");
                if (!tmp.renameTo(f)) { f.delete(); if (!tmp.renameTo(f)) throw new Exception("não consegui guardar a lista"); }
                return f;
            }
            throw new Exception("demasiados redirecionamentos");
        } catch (Exception e) {
            tmp.delete();
            if (f.exists() && f.length() > 0) return f;   /* sem rede: a última lista guardada, mesmo antiga */
            throw e;
        } finally { if (c != null) try { c.disconnect(); } catch (Throwable ignored) { } }
    }
    private static String jstr(android.util.JsonReader r) throws java.io.IOException {
        android.util.JsonToken t = r.peek();
        if (t == android.util.JsonToken.NULL) { r.nextNull(); return ""; }
        if (t == android.util.JsonToken.STRING || t == android.util.JsonToken.NUMBER) return r.nextString();
        if (t == android.util.JsonToken.BOOLEAN) return String.valueOf(r.nextBoolean());
        r.skipValue(); return "";
    }
    private static final java.util.regex.Pattern YEAR = java.util.regex.Pattern.compile("\\b(19\\d\\d|20\\d\\d)\\b");
    /** Lê a lista em fluxo (sem a carregar inteira para a memória como texto): muito mais rápido e leve nas TVs. */
    private void loadXtream(String kind, boolean force) throws Exception {
        String ca = kind.equals("live") ? "get_live_categories" : kind.equals("movie") ? "get_vod_categories" : "get_series_categories";
        String st = kind.equals("live") ? "get_live_streams" : kind.equals("movie") ? "get_vod_streams" : "get_series";
        File fc = fetchFile("x_" + kind + "_cats", api(ca, null), force);
        File fs = fetchFile("x_" + kind + "_streams", api(st, null), force);
        LinkedHashMap<String, Cat> m = new LinkedHashMap<>();
        try (android.util.JsonReader r = new android.util.JsonReader(new InputStreamReader(new java.io.BufferedInputStream(new FileInputStream(fc), 65536), "UTF-8"))) {
            if (r.peek() == android.util.JsonToken.BEGIN_ARRAY) {
                r.beginArray();
                while (r.hasNext()) {
                    if (r.peek() != android.util.JsonToken.BEGIN_OBJECT) { r.skipValue(); continue; }
                    r.beginObject(); Cat c = new Cat();
                    while (r.hasNext()) { String n = r.nextName(); if ("category_id".equals(n)) c.id = jstr(r); else if ("category_name".equals(n)) c.name = jstr(r); else r.skipValue(); }
                    r.endObject(); m.put(c.id, c);
                }
                r.endArray();
            }
        }
        List<Item> list = new ArrayList<>(kind.equals("movie") ? 200000 : 40000);
        String b = base(), u = enc(user), p = enc(pass);
        String pre = kind.equals("live") ? b + "/live/" + u + "/" + p + "/" : b + "/movie/" + u + "/" + p + "/";
        try (android.util.JsonReader r = new android.util.JsonReader(new InputStreamReader(new java.io.BufferedInputStream(new FileInputStream(fs), 131072), "UTF-8"))) {
            if (r.peek() != android.util.JsonToken.BEGIN_ARRAY) throw new Exception("resposta inesperada do servidor (" + kind + ")");
            r.beginArray();
            while (r.hasNext()) {
                if (r.peek() != android.util.JsonToken.BEGIN_OBJECT) { r.skipValue(); continue; }
                r.beginObject();
                Item it = new Item(); it.kind = kind;
                String cid = "", ext = "", added = "", lm = "", rd = "", sid = "", sidS = "", icon = "", cover = "";
                while (r.hasNext()) {
                    String n = r.nextName();
                    switch (n) {
                        case "name": it.name = jstr(r).trim(); break;
                        case "category_id": cid = jstr(r); break;
                        case "stream_id": sidS = jstr(r); break;
                        case "series_id": sid = jstr(r); break;
                        case "stream_icon": icon = jstr(r); break;
                        case "cover": cover = jstr(r); break;
                        case "epg_channel_id": it.epgId = jstr(r); break;
                        case "num": try { it.num = Integer.parseInt(jstr(r)); } catch (Throwable e) { } break;
                        case "rating": it.rating = jstr(r); break;
                        case "year": it.year = jstr(r); break;
                        case "added": added = jstr(r); break;
                        case "last_modified": lm = jstr(r); break;
                        case "container_extension": ext = jstr(r); break;
                        case "plot": if (kind.equals("series")) it.plot = jstr(r); else r.skipValue(); break;
                        case "releaseDate": case "release_date": rd = jstr(r); break;
                        default: r.skipValue();
                    }
                }
                r.endObject();
                Cat c = m.get(cid); if (c == null) { c = new Cat(); c.id = cid; c.name = "Sem categoria"; m.put(cid, c); }
                it.group = c.name;
                if (kind.equals("live")) {
                    it.id = sidS; it.logo = icon; it.url = pre + it.id + ".m3u8";
                } else if (kind.equals("movie")) {
                    it.id = sidS; it.logo = icon;
                    try { it.added = Long.parseLong(added); } catch (Throwable ignored) { }
                    if (it.year.isEmpty()) { java.util.regex.Matcher ym = YEAR.matcher(it.name); if (ym.find()) it.year = ym.group(1); }
                    if (ext.isEmpty()) ext = "mp4";
                    it.url = pre + it.id + "." + ext;
                } else {
                    it.sid = sid; it.id = sid; it.logo = cover;
                    try { it.added = Long.parseLong(lm); } catch (Throwable ignored) { }
                    if (rd.length() >= 4) it.year = rd.substring(0, 4);
                    it.url = "series:" + sid;
                }
                c.items.add(it); list.add(it);
            }
            r.endArray();
        }
        List<Cat> out = new ArrayList<>();
        for (Cat c : m.values()) if (!c.items.isEmpty()) out.add(c);
        if (kind.equals("live")) betterLogos(list);
        cats.put(kind, out); all.put(kind, list);
    }
    private void loadM3u(boolean force) throws Exception {
        String s = cached("m3u", m3u, force);
        LinkedHashMap<String, Map<String, Cat>> byKind = new LinkedHashMap<>();
        Map<String, List<Item>> lists = new HashMap<>();
        for (String k : new String[]{"live", "movie", "series"}) { byKind.put(k, new LinkedHashMap<>()); lists.put(k, new ArrayList<>()); }
        Item pend = null;
        for (String line : s.split("\n")) {
            line = line.trim();
            if (line.startsWith("#EXTINF")) {
                pend = new Item();
                pend.logo = attr(line, "tvg-logo"); pend.group = attr(line, "group-title"); pend.epgId = attr(line, "tvg-id");
                int k = line.lastIndexOf(','); pend.name = k >= 0 ? line.substring(k + 1).trim() : "";
            } else if (pend != null && line.length() > 0 && !line.startsWith("#")) {
                pend.url = line; String l = line.toLowerCase();
                pend.kind = l.contains("/movie/") ? "movie" : l.contains("/series/") ? "series" : "live";
                if (pend.kind.equals("series")) pend.kind = "movie";   /* M3U: episódios soltos tratados como filmes */
                if (pend.group.isEmpty()) pend.group = "Sem categoria";
                Map<String, Cat> mc = byKind.get(pend.kind);
                Cat c = mc.get(pend.group); if (c == null) { c = new Cat(); c.id = pend.group; c.name = pend.group; mc.put(pend.group, c); }
                c.items.add(pend); lists.get(pend.kind).add(pend);
                pend = null;
            }
        }
        betterLogos(lists.get("live"));
        for (String k : byKind.keySet()) { cats.put(k, new ArrayList<>(byKind.get(k).values())); all.put(k, lists.get(k)); }
    }
    private static String attr(String line, String a) {
        int i = line.indexOf(a + "=\""); if (i < 0) return "";
        int s0 = i + a.length() + 2, e = line.indexOf('"', s0); return e > s0 ? line.substring(s0, e) : "";
    }

    /** Temporadas e episódios de uma série (Xtream get_series_info). */
    final Map<String, JSONObject> seriesMeta = new HashMap<>();
    List<Cat> seriesInfo(Item s, boolean force) throws Exception {
        JSONObject o = new JSONObject(cached("x_series_" + s.sid, api("get_series_info", "&series_id=" + enc(s.sid)), force));
        JSONObject inf0 = o.optJSONObject("info"); if (inf0 != null) seriesMeta.put(s.sid, inf0);
        JSONObject eps = o.optJSONObject("episodes");
        List<Cat> out = new ArrayList<>();
        if (eps == null) return out;
        List<String> keys = new ArrayList<>(); java.util.Iterator<String> itk = eps.keys(); while (itk.hasNext()) keys.add(itk.next());
        java.util.Collections.sort(keys, (a, b) -> { try { return Integer.parseInt(a) - Integer.parseInt(b); } catch (Throwable e) { return a.compareTo(b); } });
        String b = base(), u = enc(user), p = enc(pass);
        for (String k : keys) {
            JSONArray a = eps.optJSONArray(k); if (a == null) continue;
            Cat c = new Cat(); c.id = k; c.name = "Temporada " + k;
            for (int i = 0; i < a.length(); i++) {
                JSONObject e = a.optJSONObject(i); if (e == null) continue;
                Item it = new Item(); it.kind = "episode"; it.id = e.optString("id"); it.sid = s.sid;
                try { it.season = Integer.parseInt(k); } catch (Throwable ignored) { } it.ep = e.optInt("episode_num", i + 1);
                it.name = "T" + k + "·E" + e.optString("episode_num") + " — " + e.optString("title");
                String ext = e.optString("container_extension", "mp4"); if (ext.isEmpty()) ext = "mp4";
                it.url = b + "/series/" + u + "/" + p + "/" + it.id + "." + ext;
                JSONObject inf = e.optJSONObject("info"); it.logo = inf != null ? inf.optString("movie_image", s.logo) : s.logo; if (it.logo.isEmpty()) it.logo = s.logo;
                if (inf != null) { it.plot = text(inf, "plot", "description", "overview"); it.rating = inf.optString("duration"); }
                it.group = s.name;
                c.items.add(it);
            }
            out.add(c);
        }
        return out;
    }

    /** O que está a dar agora e a seguir (Xtream get_short_epg). */
    String nowNext(Item ch) {
        try {
            if (server.isEmpty() || ch.id.isEmpty()) return "";
            JSONObject o = new JSONObject(http(api("get_short_epg", "&stream_id=" + enc(ch.id) + "&limit=2"), 6000));
            JSONArray a = o.optJSONArray("epg_listings"); if (a == null || a.length() == 0) return "";
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < Math.min(2, a.length()); i++) {
                JSONObject e = a.getJSONObject(i);
                String t = b64(e.optString("title")), st = e.optString("start");
                String hm = st.length() >= 16 ? st.substring(11, 16) : "";
                if (sb.length() > 0) sb.append("   ·   a seguir ");
                sb.append(hm).append(" ").append(t);
            }
            return sb.toString();
        } catch (Throwable e) { return ""; }
    }
    private static String b64(String s) { try { return new String(android.util.Base64.decode(s, android.util.Base64.DEFAULT), "UTF-8"); } catch (Throwable e) { return s; } }

    /* ------------------------------------------------------------ favoritos, vistos e posição dos filmes */
    LinkedHashSet<String> favs() {
        LinkedHashSet<String> s = new LinkedHashSet<>();
        try { JSONArray a = new JSONArray(sp.getString("favs", "[]")); for (int i = 0; i < a.length(); i++) s.add(a.getString(i)); } catch (Throwable ignored) { }
        return s;
    }
    boolean isFav(String url) { return favs().contains(url); }
    boolean toggleFav(Item it) {
        LinkedHashSet<String> s = favs(); boolean on;
        if (s.contains(it.url)) { s.remove(it.url); on = false; } else { s.add(it.url); on = true; }
        sp.edit().putString("favs", new JSONArray(s).toString()).apply();
        return on;
    }
    /** Favoritos (todos os tipos), pela ordem em que foram marcados. */
    List<Item> favItems() {
        LinkedHashSet<String> s = favs(); Map<String, Item> by = new HashMap<>();
        for (List<Item> l : all.values()) for (Item it : l) if (s.contains(it.url)) by.put(it.url, it);
        List<Item> out = new ArrayList<>(); for (String u : s) { Item it = by.get(u); if (it != null) out.add(it); }
        return out;
    }
    void pushRecent(Item it) {
        try {
            JSONArray a = new JSONArray(sp.getString("recents", "[]")), b = new JSONArray();
            b.put(it.json());
            for (int i = 0; i < a.length() && b.length() < 40; i++) { JSONObject o = a.optJSONObject(i); if (o != null && !it.url.equals(o.optString("url"))) b.put(o); }
            sp.edit().putString("recents", b.toString()).apply();
        } catch (Throwable ignored) { }
    }
    List<Item> recents() {
        List<Item> out = new ArrayList<>();
        try { JSONArray a = new JSONArray(sp.getString("recents", "[]")); for (int i = 0; i < a.length(); i++) { JSONObject o = a.optJSONObject(i); if (o != null && o.optString("url").length() > 0) out.add(Item.from(o)); } } catch (Throwable ignored) { }
        return out;
    }
    void savePos(String url, long pos, long dur) {
        try {
            JSONObject o = new JSONObject(sp.getString("pos", "{}"));
            boolean done = dur > 0 && pos > Math.max(dur * 0.93, dur - 120000);
            if (done || pos < 30000) o.remove(url); else o.put(url, pos);
            sp.edit().putString("pos", o.toString()).apply();
            if (done) setWatched(url, true);
        } catch (Throwable ignored) { }
    }
    /* ------------------------------------------------------------ filmes e séries (v271) */
    /** Ficha de um filme (Xtream get_vod_info): sinopse, elenco, género, duração, trailer, imagem de fundo. */
    JSONObject vodInfo(Item m) {
        try {
            if (server.isEmpty() || m.id.isEmpty()) return new JSONObject();
            JSONObject o = new JSONObject(cached("x_vod_" + m.id, api("get_vod_info", "&vod_id=" + enc(m.id)), false));
            JSONObject i = o.optJSONObject("info");
            if (i == null) i = new JSONObject();
            JSONObject md = o.optJSONObject("movie_data");   /* alguns servidores põem parte dos dados aqui */
            if (md != null) { java.util.Iterator<String> it = md.keys(); while (it.hasNext()) { String k = it.next(); if (text(i, k).isEmpty()) i.put(k, md.opt(k)); } }
            if (text(i, "plot", "description", "overview").isEmpty()) dbg("filme " + m.id + " sem sinopse no servidor (campos: " + i.names() + ")");
            return i;
        } catch (Throwable e) { dbg("filme " + m.id + ": erro na ficha: " + e.getMessage()); return new JSONObject(); }
    }
    /* ------------------------------------------------------------ v284: sinopses (primeiro campo com texto) e tradução para português */
    static final java.util.ArrayDeque<String> DBG = new java.util.ArrayDeque<>();
    static void dbg(String m) { synchronized (DBG) { DBG.addLast(new java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(new java.util.Date()) + " " + m); while (DBG.size() > 40) DBG.removeFirst(); } }
    static String text(JSONObject i, String... keys) {
        if (i == null) return "";
        for (String k : keys) { String v = i.optString(k, "").trim(); if (v.length() > 1 && !v.equalsIgnoreCase("n/a") && !v.equalsIgnoreCase("null")) return v; }
        return "";
    }
    /** Traduz para português (Google, com o MyMemory de reserva), como a app antiga; guarda no aparelho. Devolve null se não conseguir. */
    String translatePt(String t) {
        if (t == null || t.trim().length() < 3) return null;
        t = t.trim();
        SharedPreferences tc = ctx.getSharedPreferences("trcache", 0);
        String key = "pt|" + Integer.toHexString(t.hashCode()) + "|" + t.length();
        String hit = tc.getString(key, null); if (hit != null) return hit;
        StringBuilder out = new StringBuilder();
        for (String part : chunks(t, 1200)) {
            String r = null;
            try {
                JSONArray j = new JSONArray(http("https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=pt&dt=t&q=" + enc(part), 8000));
                JSONArray a = j.optJSONArray(0); StringBuilder sb = new StringBuilder();
                if (a != null) for (int i = 0; i < a.length(); i++) { JSONArray x = a.optJSONArray(i); if (x != null) sb.append(x.optString(0)); }
                if (sb.length() > 0) r = sb.toString();
            } catch (Throwable ignored) { }
            if (r == null) {
                try {
                    JSONObject j = new JSONObject(http("https://api.mymemory.translated.net/get?q=" + enc(part.length() > 480 ? part.substring(0, 480) : part) + "&langpair=Autodetect|pt-PT", 8000));
                    String o = j.optJSONObject("responseData") == null ? "" : j.optJSONObject("responseData").optString("translatedText");
                    if (o.length() > 0 && !o.matches("(?is).*(MYMEMORY WARNING|INVALID).*")) r = o;
                } catch (Throwable ignored) { }
            }
            if (r == null) return null;
            if (out.length() > 0) out.append(' ');
            out.append(r);
        }
        String res = out.toString();
        tc.edit().putString(key, res).apply();
        return res;
    }
    private static List<String> chunks(String t, int max) {
        List<String> out = new ArrayList<>(); StringBuilder cur = new StringBuilder();
        for (String sn : t.split("(?<=[.!?…])\\s+")) {
            while (sn.length() > max) { if (cur.length() > 0) { out.add(cur.toString()); cur.setLength(0); } out.add(sn.substring(0, max)); sn = sn.substring(max); }
            if (cur.length() + sn.length() + 1 > max) { out.add(cur.toString()); cur.setLength(0); }
            if (cur.length() > 0) cur.append(' ');
            cur.append(sn);
        }
        if (cur.length() > 0) out.add(cur.toString());
        return out;
    }

    static String firstImg(JSONObject i, String... keys) {
        for (String k : keys) {
            Object v = i.opt(k);
            if (v instanceof JSONArray) { JSONArray a = (JSONArray) v; for (int j = 0; j < a.length(); j++) { String s = a.optString(j); if (s.startsWith("http")) return s; } }
            else if (v != null && String.valueOf(v).startsWith("http")) return String.valueOf(v);
        }
        return "";
    }
    static String trailerId(JSONObject i) {
        String t = i.optString("youtube_trailer", i.optString("trailer"));
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?:v=|youtu\\.be/|embed/)([\\w-]{11})").matcher(t);
        if (m.find()) return m.group(1);
        return t.matches("[\\w-]{11}") ? t : "";
    }

    Item findByUrl(String url) {
        for (List<Item> l : all.values()) for (Item it : l) if (it.url.equals(url)) return it;
        for (Item it : recents()) if (it.url.equals(url)) return it;
        return null;
    }
    Item seriesBySid(String sid) {
        List<Item> l = all.get("series"); if (l == null) return null;
        for (Item it : l) if (it.sid.equals(sid)) return it;
        return null;
    }

    /** Vistos até ao fim (filmes e episódios). */
    boolean watched(String url) { try { return new JSONObject(sp.getString("watched", "{}")).has(url); } catch (Throwable e) { return false; } }
    void setWatched(String url, boolean on) {
        try { JSONObject o = new JSONObject(sp.getString("watched", "{}")); if (on) o.put(url, System.currentTimeMillis()); else o.remove(url); sp.edit().putString("watched", o.toString()).apply(); } catch (Throwable ignored) { }
        if (on) { try { JSONObject o = new JSONObject(sp.getString("pos", "{}")); o.remove(url); sp.edit().putString("pos", o.toString()).apply(); } catch (Throwable ignored) { } }
    }
    /** Último episódio aberto de cada série. */
    void setLastEp(String sid, String url) { try { JSONObject o = new JSONObject(sp.getString("slast", "{}")); o.put(sid, url); sp.edit().putString("slast", o.toString()).apply(); } catch (Throwable ignored) { } }
    String lastEp(String sid) { try { return new JSONObject(sp.getString("slast", "{}")).optString(sid, ""); } catch (Throwable e) { return ""; } }

    /** Filmes a meio, do mais recente para o mais antigo. */
    List<Item> continueMovies() {
        List<Item> out = new ArrayList<>(); LinkedHashSet<String> seen = new LinkedHashSet<>();
        for (Item r : recents()) {
            if (!"movie".equals(r.kind) || pos(r.url) <= 0 || !seen.add(r.url)) continue;
            Item full = null; List<Item> l = all.get("movie"); if (l != null) for (Item x : l) if (x.url.equals(r.url)) { full = x; break; }
            out.add(full != null ? full : r);
        }
        return out;
    }
    /** Séries em curso (pela ordem em que foram vistas). */
    List<Item> continueSeries() {
        List<Item> out = new ArrayList<>(); LinkedHashSet<String> seen = new LinkedHashSet<>();
        for (Item r : recents()) {
            if (!"episode".equals(r.kind) || r.sid.isEmpty() || !seen.add(r.sid)) continue;
            Item s = seriesBySid(r.sid);
            if (s != null) out.add(s);
        }
        return out;
    }
    static final String[] SORT_L = {"Ordem do servidor", "A–Z", "Mais recentes", "Melhor avaliação", "Ano"};
    int sortMode(String kind) { return sp.getInt("sort_" + kind, 0); }
    void setSortMode(String kind, int m) { sp.edit().putInt("sort_" + kind, m).apply(); }
    static List<Item> sorted(List<Item> in, int mode) {
        if (mode <= 0) return in;
        List<Item> l = new ArrayList<>(in);
        java.util.Comparator<Item> c;
        if (mode == 1) c = (a, b) -> norm(a.name).compareTo(norm(b.name));
        else if (mode == 2) c = (a, b) -> Long.compare(b.added, a.added);
        else if (mode == 3) c = (a, b) -> Double.compare(num(b.rating), num(a.rating));
        else c = (a, b) -> b.year.compareTo(a.year);
        java.util.Collections.sort(l, c);
        return l;
    }
    private static double num(String s) { try { return Double.parseDouble(s); } catch (Throwable e) { return 0; } }

    /* ------------------------------------------------------------ legendas online (OpenSubtitles, a mesma conta da app antiga) */
    String osKey() { return sp.getString("osKey", ""); }
    boolean osAuto() { return sp.getBoolean("osAuto", false); }
    void saveOs(String key, String u, String p, boolean auto) { sp.edit().putString("osKey", key.trim()).putString("osUser", u.trim()).putString("osPass", p).putBoolean("osAuto", auto).apply(); osToken = ""; }
    String osUser() { return sp.getString("osUser", ""); }
    String osPass() { return sp.getString("osPass", ""); }
    private String osToken = "", osBase = "https://api.opensubtitles.com/api/v1";
    private String osCall(String path, String body) throws Exception {
        HttpURLConnection c = (HttpURLConnection) new URL(osBase + path).openConnection();
        try {
            c.setConnectTimeout(10000); c.setReadTimeout(20000);
            c.setRequestProperty("Api-Key", osKey()); c.setRequestProperty("Accept", "application/json"); c.setRequestProperty("User-Agent", "CockpitTV v1.0");
            if (osToken.length() > 0 && body != null) c.setRequestProperty("Authorization", "Bearer " + osToken);
            if (body != null) { c.setRequestMethod("POST"); c.setDoOutput(true); c.setRequestProperty("Content-Type", "application/json"); c.getOutputStream().write(body.getBytes("UTF-8")); }
            int code = c.getResponseCode();
            InputStream in = code >= 400 ? c.getErrorStream() : c.getInputStream();
            String s = in == null ? "" : readAll(in);
            if (code >= 400) { String m = ""; try { JSONObject j = new JSONObject(s); m = j.optString("message", j.optString("error")); } catch (Throwable ignored) { } throw new Exception(m.isEmpty() ? "HTTP " + code : m); }
            return s;
        } finally { c.disconnect(); }
    }
    private static String readAll(InputStream in) throws Exception {
        java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); byte[] b = new byte[16384]; int n;
        while ((n = in.read(b)) > 0) bo.write(b, 0, n); in.close();
        return bo.toString("UTF-8");
    }
    /** Resultados em português: [{id, label}] (PT primeiro, depois os de confiança e os mais descarregados). */
    List<String[]> osSearch(String raw) throws Exception {
        if (osKey().isEmpty()) throw new Exception("falta a chave da API OpenSubtitles (Definições)");
        String t = java.text.Normalizer.normalize(raw == null ? "" : raw, java.text.Normalizer.Form.NFKD)
                .replaceAll("(?i)\\.(mkv|mp4|avi|mov|m4v|ts|m3u8)$", " ").replaceAll("\\[[^\\]]*\\]|\\([^)]*\\)|\\|[a-zA-Z]{2,3}\\|", " ").replaceAll("[._]+", " ");
        int s = 0, e = 0;
        java.util.regex.Matcher se = java.util.regex.Pattern.compile("(?i)\\bS(\\d{1,2})\\s?E(\\d{1,3})\\b").matcher(t);
        java.util.regex.Matcher se2 = java.util.regex.Pattern.compile("\\bT(\\d{1,2})·E(\\d{1,3})\\b").matcher(raw == null ? "" : raw);
        if (se.find()) { s = Integer.parseInt(se.group(1)); e = Integer.parseInt(se.group(2)); }
        else if (se2.find()) { s = Integer.parseInt(se2.group(1)); e = Integer.parseInt(se2.group(2)); }
        java.util.regex.Matcher ym = java.util.regex.Pattern.compile("\\b(19\\d\\d|20\\d\\d)\\b").matcher(t);
        String year = ym.find() ? ym.group(1) : "";
        t = t.replaceAll("(?i)\\bS\\d{1,2}\\s?E\\d{1,3}\\b", " ").replaceAll("\\bT\\d{1,2}·E\\d{1,3}\\b.*$", " ").replaceAll("\\b(19\\d\\d|20\\d\\d)\\b.*$", " ")
                .replaceAll("(?i)\\b(uhd|fhd|4k|hevc|h ?26[45]|x26[45]|hd|sd|1080p?|720p?|2160p?|bluray|brrip|webrip|web-?dl|hdrip|dvdrip|dublado|legendado|pt-?pt|pt-?br)\\b.*$", " ")
                .replaceAll("[^\\p{L}\\p{N}' ]+", " ").replaceAll("\\s+", " ").trim().toLowerCase();
        if (t.isEmpty()) throw new Exception("título vazio");
        java.util.TreeMap<String, String> p = new java.util.TreeMap<>();   /* a API exige os parâmetros por ordem alfabética */
        p.put("languages", "pt-br,pt-pt"); p.put("query", t);
        if (s > 0) { p.put("season_number", "" + s); p.put("episode_number", "" + e); p.put("type", "episode"); } else if (!year.isEmpty()) p.put("year", year);
        StringBuilder q = new StringBuilder(); for (Map.Entry<String, String> en : p.entrySet()) q.append(q.length() == 0 ? "?" : "&").append(en.getKey()).append("=").append(enc(en.getValue()).replace("+", "%20"));
        JSONArray d = new JSONObject(osCall("/subtitles" + q, null)).optJSONArray("data");
        List<Object[]> rows = new ArrayList<>();
        if (d != null) for (int i = 0; i < d.length(); i++) {
            JSONObject a = d.optJSONObject(i) == null ? null : d.optJSONObject(i).optJSONObject("attributes"); if (a == null) continue;
            JSONArray fs = a.optJSONArray("files"); if (fs == null || fs.length() == 0) continue;
            JSONObject f = fs.optJSONObject(0); String fid = f.optString("file_id"); if (fid.isEmpty()) continue;
            String lang = a.optString("language"); boolean pt = lang.toLowerCase().matches("pt-?pt");
            String rel = a.optString("release", f.optString("file_name"));
            String label = (pt ? "PT" : "BR") + " · " + (rel.length() > 60 ? rel.substring(0, 60) : rel) + "  ↓" + a.optInt("download_count") + (a.optBoolean("from_trusted") ? " ✓" : "");
            int score = (pt ? 1000000000 : 0) + (a.optBoolean("from_trusted") ? 100000000 : 0) - (a.optBoolean("hearing_impaired") ? 50000000 : 0) + Math.min(49999999, a.optInt("download_count"));
            rows.add(new Object[]{score, new String[]{fid, label}});
        }
        java.util.Collections.sort(rows, (x, y) -> Integer.compare((Integer) y[0], (Integer) x[0]));
        List<String[]> out = new ArrayList<>(); for (Object[] r : rows) { out.add((String[]) r[1]); if (out.size() >= 10) break; }
        return out;
    }
    /** Descarrega a legenda escolhida em SRT (texto). */
    String osDownload(String fileId) throws Exception {
        if (osToken.isEmpty() && osUser().length() > 0 && osPass().length() > 0) {
            try {
                JSONObject j = new JSONObject(osCall("/login", new JSONObject().put("username", osUser()).put("password", osPass()).toString()));
                osToken = j.optString("token");
                String bu = j.optString("base_url"); if (bu.length() > 0) osBase = "https://" + bu.replaceAll("^https?://", "").replaceAll("/.*$", "") + "/api/v1";
            } catch (Throwable ignored) { }
        }
        JSONObject j = new JSONObject(osCall("/download", new JSONObject().put("file_id", Long.parseLong(fileId)).put("sub_format", "srt").toString()));
        String link = j.optString("link"); if (link.isEmpty()) throw new Exception("sem ligação de download");
        HttpURLConnection c = (HttpURLConnection) new URL(link).openConnection();
        c.setConnectTimeout(10000); c.setReadTimeout(20000); c.setInstanceFollowRedirects(true);
        byte[] b; try { InputStream in = c.getInputStream(); java.io.ByteArrayOutputStream bo = new java.io.ByteArrayOutputStream(); byte[] buf = new byte[16384]; int n; while ((n = in.read(buf)) > 0) bo.write(buf, 0, n); in.close(); b = bo.toByteArray(); } finally { c.disconnect(); }
        String txt = new String(b, "UTF-8");
        if (txt.contains("\uFFFD")) txt = new String(b, "windows-1252");   /* legendas antigas em Latin-1 */
        return txt;
    }

    /* ------------------------------------------------------------ operador (v274): canais pela ordem da grelha MEO / NOS / Vodafone */
    String opKey() { return sp.getString("tvOp", ""); }
    String opCustom() { return sp.getString("tvOpCustom", ""); }
    void setOp(String k, String custom) { sp.edit().putString("tvOp", k == null ? "" : k).putString("tvOpCustom", custom == null ? opCustom() : custom).apply(); }
    private JSONObject ops;
    JSONObject ops() {
        if (ops == null) { try (InputStream in = ctx.getAssets().open("ui/ops.json")) { ops = new JSONObject(readAll(in)); } catch (Throwable e) { ops = new JSONObject(); } }
        return ops;
    }
    String opTitle(String k) { return "custom".equals(k) ? "Ordem personalizada" : "Canais " + (ops().optJSONObject(k) == null ? k : ops().optJSONObject(k).optString("label")); }
    private static String opNrm(String n) {
        String s = java.text.Normalizer.normalize(n == null ? "" : n, java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase();
        s = s.replaceFirst("^[\\s\\W_]*(pt|portugal)\\b[\\s|:\\-/]*", "");
        s = s.replaceAll("\\[[^\\]]*\\]|\\([^)]*\\)", " ").replaceAll("\\b(fhd|uhd|hd|sd|4k|8k|hevc|h265|raw|plus)\\b", " ");
        return s.replaceAll("[^a-z0-9]+", "");
    }
    private static final java.util.regex.Pattern CTY = java.util.regex.Pattern.compile("^[\\s|\\[]*([A-Za-z]{2,3})\\s*[|:\\]]");
    /** 0 = português (PT, BR, AO, MZ, CV), 1 = sem país, 2 = outro país (fica de fora). */
    private static int opLang(Item c) {
        for (String t : new String[]{c.group, c.name}) {
            java.util.regex.Matcher m = CTY.matcher(t == null ? "" : t);
            if (m.find()) { String k = m.group(1).toUpperCase(); return k.matches("PT|BR|AO|MZ|CV|POR") ? 0 : 2; }
            if (t != null && t.toUpperCase().matches(".*\\b(PORTUGAL|PORTUGU[EÊ]S|PORTUGUESA)\\b.*")) return 0;
        }
        return 1;
    }
    private static int opQ(Item c) {
        String n = c.name == null ? "" : c.name;
        int q = n.matches("(?i).*\\b(fhd|uhd|4k)\\b.*") ? 0 : n.matches("(?i).*\\bhd\\b.*") ? 1 : 2;
        return q + opLang(c) * 10 + (c.group != null && c.group.toUpperCase().matches(".*\\bPT\\b.*|.*PORTUGAL.*") ? 0 : 5);
    }
    /** Canais da lista do operador escolhido, pela ordem da grelha, na melhor versão portuguesa que houver. */
    List<Item> opChannels(String key) {
        List<Item> out = new ArrayList<>();
        List<Item> live = all.get("live"); if (live == null || live.isEmpty() || key == null || key.isEmpty()) return out;
        List<String> order = new ArrayList<>();
        if ("custom".equals(key)) { for (String l : opCustom().split("\\r?\\n")) if (l.trim().length() > 0) order.add(l.trim()); }
        else { JSONObject o = ops().optJSONObject(key); JSONArray a = o == null ? null : o.optJSONArray("list"); if (a != null) for (int i = 0; i < a.length(); i++) order.add(a.optString(i)); }
        Map<String, List<Item>> idx = new HashMap<>();
        for (Item c : live) { String k = opNrm(c.name); if (k.isEmpty()) continue; List<Item> l = idx.get(k); if (l == null) { l = new ArrayList<>(); idx.put(k, l); } l.add(c); }
        java.util.HashSet<String> seen = new java.util.HashSet<>();
        int n = 0;
        for (String ent : order) {
            Item best = null;
            for (String alias : ent.split("\\|")) {
                List<Item> l = idx.get(opNrm(alias)); if (l == null) continue;
                for (Item c : l) if (!seen.contains(c.url) && opLang(c) < 2 && (best == null || opQ(c) < opQ(best))) best = c;
            }
            if (best != null) { seen.add(best.url); out.add(best); }
        }
        return out;
    }

    long pos(String url) { try { return new JSONObject(sp.getString("pos", "{}")).optLong(url, 0); } catch (Throwable e) { return 0; } }

    /** Pesquisa em todos os tipos já carregados (sem acentos, sem maiúsculas). */
    List<Item> search(String q) {
        String n = norm(q); List<Item> out = new ArrayList<>();
        if (n.length() < 2) return out;
        for (String k : new String[]{"live", "movie", "series"}) { List<Item> l = all.get(k); if (l == null) continue; for (Item it : l) { if (norm(it.name).contains(n) && !hiddenItem(it)) { out.add(it); if (out.size() >= 300) return out; } } }
        return out;
    }
    static String norm(String s) { return java.text.Normalizer.normalize(s == null ? "" : s, java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase(); }

    /* ------------------------------------------------------------ v278: picons de qualidade (tv-logo/tv-logos), como a app antiga fazia para os canais PT */
    private static JSONObject LOGOS;
    private static final String LOGO_BASE = "https://cdn.jsdelivr.net/gh/tv-logo/tv-logos@main/countries/";
    private static final String[][] CTY_DIR = {{"PT", "portugal"}, {"BR", "brazil"}, {"ES", "spain"}, {"FR", "france"}, {"DE", "germany"}, {"IT", "italy"}, {"UK", "united-kingdom"}, {"GB", "united-kingdom"},
            {"US", "united-states"}, {"USA", "united-states"}, {"NL", "netherlands"}, {"BE", "belgium"}, {"PL", "poland"}, {"RO", "romania"}, {"TR", "turkey"}, {"GR", "greece"}, {"AR", "argentina"},
            {"MX", "mexico"}, {"CA", "canada"}, {"IN", "india"}, {"AL", "albania"}, {"AT", "austria"}, {"AU", "australia"}, {"BG", "bulgaria"}, {"CL", "chile"}, {"HR", "croatia"}, {"CZ", "czech-republic"},
            {"HU", "hungary"}, {"IE", "ireland"}, {"IL", "israel"}, {"LT", "lithuania"}, {"LU", "luxembourg"}, {"MT", "malta"}, {"NZ", "new-zealand"}, {"PH", "philippines"}, {"RS", "serbia"}, {"SK", "slovakia"},
            {"SI", "slovenia"}, {"ZA", "south-africa"}, {"CH", "switzerland"}, {"UA", "ukraine"}, {"AE", "united-arab-emirates"}, {"RU", "russia"}, {"AZ", "azerbaijan"}, {"LB", "lebanon"}, {"MY", "malaysia"},
            {"SG", "singapore"}, {"ID", "indonesia"}, {"HK", "hong-kong"}, {"CR", "costa-rica"}, {"SE", "nordic"}, {"NO", "nordic"}, {"DK", "nordic"}, {"FI", "nordic"}};
    private static final String[][] LOGO_ALIAS = {{"rtp3", "rtpnoticias"}, {"hollywood", "canalhollywood"}, {"panda", "canalpanda"}, {"11", "canal11"}, {"globo", "globointernacional"},
            {"q", "canalq"}, {"cnn", "cnnportugal"}, {"foxmovies", "starmovies"}, {"fox", "starchannel"}, {"sportv", "sporttv"}, {"elevensports", "elevensports1"}, {"tvi24", "tvi24"},
            {"benficatv", "btv"}, {"benfica", "btv"}, {"discovery", "discoverychannel"}, {"natgeo", "nationalgeographic"}, {"natgeowild", "nationalgeographicwild"}, {"tvciné", "tvcine"},
            {"sporttvmais", "sporttvmais"}, {"sptv1", "sporttv1"}, {"sptv2", "sporttv2"}, {"sptv3", "sporttv3"}, {"sptv4", "sporttv4"}, {"sptv5", "sporttv5"}, {"sporttv", "sporttv1"}};
    private void loadLogos() {
        if (LOGOS != null) return;
        try (InputStream in = ctx.getAssets().open("ui/logos.json")) { LOGOS = new JSONObject(readAll(in)); } catch (Throwable e) { LOGOS = new JSONObject(); }
    }
    private static final java.util.regex.Pattern PFX = java.util.regex.Pattern.compile("^[^A-Za-z]*([A-Za-z]{2,3})\\s*[|:]");
    static String ctyCode(Item c) {
        for (String t : new String[]{c.group, c.name}) {
            if (t == null) continue;
            java.util.regex.Matcher m = PFX.matcher(t);
            if (m.find()) return m.group(1).toUpperCase();
            if (t.toUpperCase().matches(".*\\b(PORTUGAL|PORTUGU[EÊ]S|PORTUGUESA)\\b.*")) return "PT";
        }
        return "";
    }
    static String logoKey(String n) {
        String s = java.text.Normalizer.normalize(n == null ? "" : n, java.text.Normalizer.Form.NFD).replaceAll("\\p{M}", "").toLowerCase();
        s = s.replaceFirst("^[^a-z0-9]*[a-z]{2,3}\\s*[|:]+\\s*", "");
        s = s.replaceAll("\\[[^\\]]*\\]|\\([^)]*\\)", " ").replaceAll("[ᴴᴰᵁ⁴ᴷ]", " ");
        s = s.replaceAll("\\b(fhd|uhd|hd|sd|4k|8k|hevc|h265|h264|raw|1080p|720p|1080|720|50fps|60fps|backup|alt|multi|vip)\\b", " ");
        return s.replaceAll("[^a-z0-9+]", "");
    }
    private String logoIn(String dir, String key) {
        JSONObject m = LOGOS.optJSONObject(dir); if (m == null) return null;
        String f = m.optString(key, null);
        if (f == null || f.isEmpty()) return null;
        return LOGO_BASE + dir + "/" + android.net.Uri.encode(f);
    }
    /** Logótipo da tv-logos para um canal (ou null). */
    String logoFor(Item c, String cty) {
        loadLogos();
        String k = logoKey(c.name);
        if (k.length() < 2) return null;
        java.util.LinkedHashSet<String> keys = new java.util.LinkedHashSet<>();
        keys.add(k); keys.add(k.replace("+", "mais")); keys.add(k.replace("+", "plus")); keys.add(k.replace("+", ""));
        String k2 = k.replace("+", "");
        for (String[] a : LOGO_ALIAS) if (a[0].equals(k2)) keys.add(a[1]);
        if (k2.startsWith("canal") && k2.length() > 6) keys.add(k2.substring(5)); else keys.add("canal" + k2);
        if (k2.endsWith("tv") && k2.length() > 4) keys.add(k2.substring(0, k2.length() - 2)); else keys.add(k2 + "tv");
        java.util.LinkedHashSet<String> dirs = new java.util.LinkedHashSet<>();
        for (String[] d : CTY_DIR) if (d[0].equals(cty)) dirs.add(d[1]);
        if (cty.isEmpty() || "PT".equals(cty)) dirs.add("portugal");
        dirs.add("international"); dirs.add("world-europe");
        if ("PT".equals(cty) || cty.isEmpty()) { dirs.add("spain"); dirs.add("united-kingdom"); dirs.add("united-states"); }
        for (String d : dirs) for (String key : keys) { String u = logoIn(d, key); if (u != null) return u; }
        return null;
    }
    /** v279: só conta os logótipos ao carregar (rápido); a troca pelo logótipo do canal é feita quando o cartão aparece (logo()). */
    private final Map<String, Integer> logoCnt = new java.util.concurrent.ConcurrentHashMap<>();
    private void betterLogos(List<Item> live) {
        if (live == null) return;
        loadLogos();   /* índice dos picons já pronto quando os cartões aparecerem */
        logoCnt.clear();
        for (Item c : live) if (c.logo != null && c.logo.length() > 0) { Integer n = logoCnt.get(c.logo); logoCnt.put(c.logo, n == null ? 1 : n + 1); }
    }
    /** Logótipo a mostrar: o do canal (tv-logos) quando o do servidor é genérico, falta ou o canal é PT. */
    String logo(Item c) {
        if (c == null) return "";
        if (c.logoDone || !"live".equals(c.kind) || !sp.getBoolean("betterLogos", true)) return c.logo;
        c.logoDone = true;
        try {
            String cty = ctyCode(c);
            Integer n = c.logo == null || c.logo.isEmpty() ? Integer.valueOf(0) : logoCnt.get(c.logo);
            boolean generic = c.logo == null || c.logo.isEmpty() || (n != null && n >= 3);
            if (generic || "PT".equals(cty)) { String u = logoFor(c, cty); if (u != null) c.logo = u; }
        } catch (Throwable ignored) { }
        return c.logo;
    }

    /* ------------------------------------------------------------ v278: ordenar e ocultar (categorias, canais e países), formato igual ao da app antiga */
    private JSONObject org;
    JSONObject org() { if (org == null) { try { org = new JSONObject(sp.getString("org", "{}")); } catch (Throwable e) { org = new JSONObject(); } } return org; }
    void saveOrg() { sp.edit().putString("org", org().toString()).apply(); visCache.clear(); }
    private static JSONArray arr(JSONObject o, String k) { JSONArray a = o.optJSONArray(k); if (a == null) { a = new JSONArray(); try { o.put(k, a); } catch (Throwable ignored) { } } return a; }
    private JSONArray arr2(String k, String kind) { JSONObject o = org().optJSONObject(k); if (o == null) { o = new JSONObject(); try { org().put(k, o); } catch (Throwable ignored) { } } return arr(o, kind); }
    private static List<String> list(JSONArray a) { List<String> l = new ArrayList<>(); if (a != null) for (int i = 0; i < a.length(); i++) l.add(a.optString(i)); return l; }
    private void put2(String k, String kind, List<String> l) { try { JSONObject o = org().optJSONObject(k); if (o == null) { o = new JSONObject(); org().put(k, o); } o.put(kind, new JSONArray(l)); } catch (Throwable ignored) { } }
    private JSONObject cty;
    JSONObject cty() { if (cty == null) { try { cty = new JSONObject(sp.getString("cty", "{}")); } catch (Throwable e) { cty = new JSONObject(); } arr(cty, "order"); arr(cty, "hide"); } return cty; }
    void saveCty() { sp.edit().putString("cty", cty().toString()).apply(); visCache.clear(); }
    void importOrg(String orgJson, String ctyJson) {
        try { if (orgJson != null && orgJson.length() > 2) { org = new JSONObject(orgJson); saveOrg(); } } catch (Throwable ignored) { }
        try { if (ctyJson != null && ctyJson.length() > 2) { cty = new JSONObject(ctyJson); arr(cty, "order"); arr(cty, "hide"); saveCty(); } } catch (Throwable ignored) { }
    }
    private static final java.util.regex.Pattern GPFX = java.util.regex.Pattern.compile("^[^A-Za-zÀ-ÿ]*([A-Za-z]{2,3})\\s*(?:\\||:|-|–|—|\\]|\\))");
    /** País de uma categoria pelo prefixo (|PT|, FR:, UK | …); "" sem país. */
    static String ctyOfGroup(String g) {
        if (g == null) return "";
        java.util.regex.Matcher m = GPFX.matcher(g);
        if (m.find()) { String c = m.group(1).toUpperCase(); return "GB".equals(c) ? "UK" : c; }
        if (g.toUpperCase().matches(".*\\b(PORTUGAL|PORTUGU[EÊ]S|PORTUGUESA)\\b.*")) return "PT";
        return "";
    }
    private static boolean isPtGroup(String n) { return n != null && n.matches("(?is)^[\\s\\W_]*(PT|PORTUGAL|PORTUGUES)(?![A-Za-zÀ-ÿ]).*"); }
    int ctyRank(String code) { int i = list(cty().optJSONArray("order")).indexOf(code); return i >= 0 ? i : ("PT".equals(code) ? -1 : 1000); }
    boolean ctyHidden(String code) { return !code.isEmpty() && list(cty().optJSONArray("hide")).contains(code); }
    private java.util.Set<String> chHideSet = null;
    boolean hiddenItem(Item it) {
        if (it == null) return false;
        if (chHideSet == null) chHideSet = new java.util.HashSet<>(list(org().optJSONArray("chHide")));
        if (chHideSet.contains(it.url)) return true;
        String k = "episode".equals(it.kind) ? "series" : it.kind;
        if (list(arr2("grpHide", k)).contains(it.group)) return true;
        return ctyHidden(ctyOfGroup(it.group));
    }
    private final Map<String, List<Cat>> visCache = new HashMap<>();
    /** Categorias pela ordem escolhida (países, depois a tua ordem, depois as PT), sem as ocultas e sem os canais ocultos. */
    synchronized List<Cat> visibleCats(String kind) {
        List<Cat> base = cats.get(kind);
        if (base == null) return null;
        String ck = kind + "|" + System.identityHashCode(base);
        List<Cat> cached = visCache.get(ck);
        if (cached != null) return cached;
        final List<String> ord = list(arr2("grp", kind));
        java.util.Set<String> gh = new java.util.HashSet<>(list(arr2("grpHide", kind)));
        java.util.Set<String> ch = new java.util.HashSet<>(list(org().optJSONArray("chHide")));
        List<Cat> l = new ArrayList<>();
        for (Cat c : base) {
            if (gh.contains(c.name) || ctyHidden(ctyOfGroup(c.name))) continue;
            Cat x = c;
            if (!ch.isEmpty()) {
                boolean any = false; for (Item it : c.items) if (ch.contains(it.url)) { any = true; break; }
                if (any) { x = new Cat(); x.id = c.id; x.name = c.name; for (Item it : c.items) if (!ch.contains(it.url)) x.items.add(it); }
            }
            l.add(x);
        }
        final Map<String, Long> key = new HashMap<>();
        for (Cat c : l) { int i = ord.indexOf(c.name); long gi = i >= 0 ? i : (isPtGroup(c.name) ? -1 : 1000000); key.put(c.name, ctyRank(ctyOfGroup(c.name)) * 10000000L + gi); }
        java.util.Collections.sort(l, (a, b) -> Long.compare(key.get(a.name), key.get(b.name)));   /* estável: a ordem do servidor fica entre iguais */
        visCache.put(ck, l);
        return l;
    }
    private void changed() { saveOrg(); chHideSet = null; }
    void hideCat(String kind, String name) { List<String> h = list(arr2("grpHide", kind)); if (!h.contains(name)) h.add(name); put2("grpHide", kind, h); changed(); }
    void showCat(String kind, String name) { List<String> h = list(arr2("grpHide", kind)); h.remove(name); put2("grpHide", kind, h); changed(); }
    void hideItem(String url) { List<String> h = list(org().optJSONArray("chHide")); if (!h.contains(url)) h.add(url); try { org().put("chHide", new JSONArray(h)); } catch (Throwable ignored) { } changed(); }
    void showAllItems() { try { org().put("chHide", new JSONArray()); } catch (Throwable ignored) { } changed(); }
    void showAllCats() { try { org().put("grpHide", new JSONObject()); } catch (Throwable ignored) { } changed(); }
    int hiddenItemsCount() { return list(org().optJSONArray("chHide")).size(); }
    List<String[]> hiddenCats() { List<String[]> out = new ArrayList<>(); for (String k : new String[]{"live", "movie", "series"}) for (String n : list(arr2("grpHide", k))) out.add(new String[]{k, n}); return out; }
    /** Muda a posição de uma categoria (delta −1/+1, ou Integer.MIN_VALUE = para o topo); grava a ordem atual toda. */
    void moveCat(String kind, String name, int delta) {
        List<Cat> v = visibleCats(kind); if (v == null) return;
        List<String> names = new ArrayList<>(); for (Cat c : v) names.add(c.name);
        int i = names.indexOf(name); if (i < 0) return;
        names.remove(i);
        int j = delta == Integer.MIN_VALUE ? 0 : Math.max(0, Math.min(names.size(), i + delta));
        names.add(j, name);
        for (String o : list(arr2("grp", kind))) if (!names.contains(o)) names.add(o);   /* mantém as posições das ocultas */
        put2("grp", kind, names); changed();
    }
    void resetOrder() { try { org().put("grp", new JSONObject()); } catch (Throwable ignored) { } changed(); }
    /** Países presentes nas categorias (código, nº de categorias), pela ordem atual. */
    List<String[]> countries() {
        final Map<String, Integer> n = new HashMap<>();
        for (String k : new String[]{"live", "movie", "series"}) { List<Cat> l = cats.get(k); if (l == null) continue; for (Cat c : l) { String x = ctyOfGroup(c.name); if (x.isEmpty()) continue; Integer v = n.get(x); n.put(x, v == null ? 1 : v + 1); } }
        List<String> codes = new ArrayList<>(n.keySet());
        java.util.Collections.sort(codes, (a, b) -> ctyRank(a) != ctyRank(b) ? Integer.compare(ctyRank(a), ctyRank(b)) : Integer.compare(n.get(b), n.get(a)));
        List<String[]> out = new ArrayList<>(); for (String c : codes) out.add(new String[]{c, String.valueOf(n.get(c))});
        return out;
    }
    void moveCty(String code, int delta) {
        List<String> codes = new ArrayList<>(); for (String[] x : countries()) codes.add(x[0]);
        int i = codes.indexOf(code); if (i < 0) return;
        codes.remove(i); codes.add(Math.max(0, Math.min(codes.size(), i + delta)), code);
        try { cty().put("order", new JSONArray(codes)); } catch (Throwable ignored) { } saveCty();
    }
    void toggleCty(String code) {
        List<String> h = list(cty().optJSONArray("hide")); if (h.contains(code)) h.remove(code); else h.add(code);
        try { cty().put("hide", new JSONArray(h)); } catch (Throwable ignored) { } saveCty();
    }
    boolean ctyIsHidden(String code) { return ctyHidden(code); }
    void resetCty() { cty = new JSONObject(); arr(cty, "order"); arr(cty, "hide"); saveCty(); }
}
