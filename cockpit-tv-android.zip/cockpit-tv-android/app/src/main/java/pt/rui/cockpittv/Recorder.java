package pt.rui.cockpittv;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.ContentValues;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Build;
import android.os.Environment;
import android.os.IBinder;
import android.net.Uri;
import android.os.PowerManager;
import android.provider.MediaStore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ConcurrentHashMap;

/** v479: gravações agendadas do guia. Guarda a lista, marca o alarme e grava o canal (TS ou HLS) para o armazenamento da app. */
final class Recorder {
    static final long PRE = 60_000L, POST = 120_000L;   /* começa 1 min antes e acaba 2 min depois (as emissões nem sempre são pontuais) */
    static final String ACT = "pt.rui.cockpittv.REC";
    private static final ConcurrentHashMap<String, Boolean> STOP = new ConcurrentHashMap<>();

    static final class Rec {
        String id = "", ch = "", url = "", title = "", st = "sched", file = "", err = "";
        long start, end, bytes, pre = PRE, post = POST;   /* margens em ms, definidas ao agendar */
        JSONObject json() { JSONObject o = new JSONObject(); try { o.put("id", id).put("ch", ch).put("url", url).put("title", title).put("st", st).put("file", file).put("err", err).put("start", start).put("end", end).put("bytes", bytes).put("pre", pre).put("post", post); } catch (Throwable ignored) { } return o; }
        static Rec from(JSONObject o) { Rec r = new Rec(); r.id = o.optString("id"); r.ch = o.optString("ch"); r.url = o.optString("url"); r.title = o.optString("title"); r.st = o.optString("st", "sched"); r.file = o.optString("file"); r.err = o.optString("err"); r.start = o.optLong("start"); r.end = o.optLong("end"); r.bytes = o.optLong("bytes"); r.pre = o.optLong("pre", PRE); r.post = o.optLong("post", POST); return r; }
    }

    static int preMin(Context c) { return sp(c).getInt("preMin", 1); }
    static int postMin(Context c) { return sp(c).getInt("postMin", 2); }
    static void setMargins(Context c, int pre, int post) { sp(c).edit().putInt("preMin", pre).putInt("postMin", post).apply(); }
    /** v482: guardar na pasta pública Movies/CockpitTV (Android 10+) ou só na pasta da app; apagar gravações antigas ao fim de N dias. */
    static boolean canPublic() { return Build.VERSION.SDK_INT >= 29; }
    static boolean pub(Context c) { return canPublic() && sp(c).getBoolean("pub", true); }
    static void setPub(Context c, boolean on) { sp(c).edit().putBoolean("pub", on).apply(); }
    static int keepDays(Context c) { return sp(c).getInt("keepDays", 0); }
    static void setKeepDays(Context c, int d) { sp(c).edit().putInt("keepDays", d).apply(); }
    /** v483: pasta escolhida pelo utilizador (seletor de pastas do Android); tem prioridade sobre as outras. */
    static String tree(Context c) { return sp(c).getString("tree", ""); }
    static String treeName(Context c) { return sp(c).getString("treeName", ""); }
    /** v496: pasta absoluta escolhida no navegador interno (ex.: /storage/XXXX-XXXX/Gravacoes). */
    static String path(Context c) { return sp(c).getString("path", ""); }
    static void setPath(Context c, String abs) { sp(c).edit().putString("path", abs).putString("treeName", abs).apply(); }
    static void setTree(Context c, String uri, String name) { sp(c).edit().putString("tree", uri).putString("treeName", name).apply(); }
    private static String exportTree(Context c, File f) {
        try {
            Uri t = Uri.parse(tree(c));
            Uri parent = android.provider.DocumentsContract.buildDocumentUriUsingTree(t, android.provider.DocumentsContract.getTreeDocumentId(t));
            Uri u = android.provider.DocumentsContract.createDocument(c.getContentResolver(), parent, "video/mp2t", f.getName());
            if (u == null) return null;
            try (OutputStream o = c.getContentResolver().openOutputStream(u); InputStream in = new FileInputStream(f)) { byte[] b = new byte[262144]; int n; while ((n = in.read(b)) > 0) o.write(b, 0, n); }
            f.delete(); return u.toString();
        } catch (Throwable e) { return null; }
    }
    /** v496: copia a gravação acabada para a pasta escolhida (acesso a todos os ficheiros). */
    private static String exportPath(Context c, File f) {
        try {
            File d = new File(path(c));
            if (!d.isDirectory() || !d.canWrite()) return null;
            File out = new File(d, f.getName());
            try (InputStream in = new FileInputStream(f); OutputStream o = new FileOutputStream(out)) { byte[] b = new byte[262144]; int n; while ((n = in.read(b)) > 0) o.write(b, 0, n); }
            f.delete(); return out.getAbsolutePath();
        } catch (Throwable e) { return null; }
    }
    static String where(Context c) { return !path(c).isEmpty() ? "Pasta escolhida: " + path(c) : !tree(c).isEmpty() ? "Pasta escolhida: " + treeName(c) : pub(c) ? "Armazenamento interno › Movies › CockpitTV" : dir(c).getAbsolutePath(); }
    static void deleteStored(Context c, String file) {
        if (file == null || file.isEmpty()) return;
        try {
            if (file.startsWith("content:")) {
                Uri u = Uri.parse(file);
                if (android.provider.DocumentsContract.isDocumentUri(c, u) && !"media".equals(u.getAuthority())) android.provider.DocumentsContract.deleteDocument(c.getContentResolver(), u);
                else c.getContentResolver().delete(u, null, null);
            } else new File(file).delete();
        } catch (Throwable ignored) { }
    }
    /** Copia a gravação acabada para Movies/CockpitTV (visível no gestor de ficheiros e noutros leitores) e apaga a cópia da app. */
    private static String exportPublic(Context c, File f) {
        if (!canPublic()) return null;
        try {
            ContentValues v = new ContentValues();
            v.put(MediaStore.Video.Media.DISPLAY_NAME, f.getName()); v.put(MediaStore.Video.Media.MIME_TYPE, "video/mp2t");
            v.put(MediaStore.Video.Media.RELATIVE_PATH, "Movies/CockpitTV"); v.put(MediaStore.Video.Media.IS_PENDING, 1);
            Uri u = c.getContentResolver().insert(MediaStore.Video.Media.EXTERNAL_CONTENT_URI, v);
            if (u == null) return null;
            try (OutputStream o = c.getContentResolver().openOutputStream(u); InputStream in = new FileInputStream(f)) { byte[] b = new byte[262144]; int n; while ((n = in.read(b)) > 0) o.write(b, 0, n); }
            ContentValues d = new ContentValues(); d.put(MediaStore.Video.Media.IS_PENDING, 0); c.getContentResolver().update(u, d, null, null);
            f.delete(); return u.toString();
        } catch (Throwable e) { return null; }
    }
    /** Apaga as gravações acabadas há mais de N dias (se estiver definido). */
    static void purge(Context c) {
        int days = keepDays(c); if (days <= 0) return;
        long lim = System.currentTimeMillis() - days * 86_400_000L;
        for (Rec r : list(c)) if (("done".equals(r.st) || "fail".equals(r.st)) && r.end < lim) remove(c, r.id, true);
    }
    private static SharedPreferences sp(Context c) { return c.getSharedPreferences("recordings", 0); }
    static synchronized List<Rec> list(Context c) {
        List<Rec> out = new ArrayList<>();
        try { JSONArray a = new JSONArray(sp(c).getString("list", "[]")); for (int i = 0; i < a.length(); i++) out.add(Rec.from(a.getJSONObject(i))); } catch (Throwable ignored) { }
        return out;
    }
    private static synchronized void save(Context c, List<Rec> l) { JSONArray a = new JSONArray(); for (Rec r : l) a.put(r.json()); sp(c).edit().putString("list", a.toString()).apply(); }
    static synchronized void update(Context c, Rec n) { List<Rec> l = list(c); for (int i = 0; i < l.size(); i++) if (l.get(i).id.equals(n.id)) { l.set(i, n); save(c, l); return; } }
    static Rec find(Context c, String id) { for (Rec r : list(c)) if (r.id.equals(id)) return r; return null; }
    static String idOf(String url, long start) { return Integer.toHexString(url.hashCode()) + "_" + (start / 1000); }
    static boolean has(Context c, String url, long start) { Rec r = find(c, idOf(url, start)); return r != null && ("sched".equals(r.st) || "rec".equals(r.st)); }

    static synchronized Rec add(Context c, String ch, String url, String title, long start, long end, long pre, long post) {
        Rec r = new Rec(); r.pre = Math.max(0, pre); r.post = Math.max(0, post); r.id = idOf(url, start); r.ch = ch; r.url = url; r.title = title; r.start = start; r.end = end;
        List<Rec> l = list(c); for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).id.equals(r.id)) l.remove(i);
        l.add(r); save(c, l); arm(c, r); return r;
    }
    static synchronized void remove(Context c, String id, boolean deleteFile) {
        List<Rec> l = list(c);
        for (int i = l.size() - 1; i >= 0; i--) if (l.get(i).id.equals(id)) {
            Rec r = l.get(i); disarm(c, r); STOP.put(id, true);
            if (deleteFile) deleteStored(c, r.file);
            l.remove(i);
        }
        save(c, l);
    }
    static void stop(String id) { STOP.put(id, true); }

    private static PendingIntent pi(Context c, Rec r) {
        Intent i = new Intent(c, RecReceiver.class).setAction(ACT).putExtra("id", r.id);
        return PendingIntent.getBroadcast(c, r.id.hashCode(), i, PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0));
    }
    /** v499: gravação de um canal em direto, até parares (ou 6 horas). Usa o mesmo caminho das gravações agendadas. */
    static final long LIVE_MAX_MS = 6L * 3600_000L;
    static Rec liveActive(Context c, String url) {
        long now = System.currentTimeMillis();
        for (Rec r : list(c)) if (url != null && url.equals(r.url) && ("sched".equals(r.st) || "rec".equals(r.st)) && r.end > now && r.start <= now + 60_000) return r;
        return null;
    }
    static Rec startLive(Context c, String ch, String url, String title) {
        long now = System.currentTimeMillis();
        String t = "Direto " + new SimpleDateFormat("HH.mm", Locale.US).format(now) + " " + title;
        return add(c, ch, url, t, now, now + LIVE_MAX_MS, 0, 0);
    }
    static boolean canExact(Context c) { AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE); return Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms(); }
    static void arm(Context c, Rec r) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            long at = Math.max(System.currentTimeMillis() + 1500, r.start - r.pre);
            if (canExact(c)) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c, r)); else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c, r));
        } catch (Throwable ignored) { }
    }
    static void disarm(Context c, Rec r) { try { ((AlarmManager) c.getSystemService(Context.ALARM_SERVICE)).cancel(pi(c, r)); } catch (Throwable ignored) { } }
    /** Depois de reiniciar o aparelho: volta a marcar os alarmes das gravações que ainda não acabaram. */
    static void rearmAll(Context c) {
        purge(c);
        long now = System.currentTimeMillis();
        for (Rec r : list(c)) {
            if ("sched".equals(r.st) || "rec".equals(r.st)) {
                if (r.end + r.post < now) { r.st = "fail"; r.err = "o aparelho esteve desligado"; update(c, r); } else { r.st = "sched"; update(c, r); arm(c, r); }
            }
        }
    }

    static File dir(Context c) {
        File d = c.getExternalFilesDir(Environment.DIRECTORY_MOVIES);
        if (d == null) d = c.getFilesDir();
        d = new File(d, "Gravações"); d.mkdirs(); return d;
    }

    public static final class RecReceiver extends BroadcastReceiver {   /* v502: público: o Android cria o receptor fora do pacote */
        @Override public void onReceive(Context c, Intent i) {
            try {
                if (Intent.ACTION_BOOT_COMPLETED.equals(i.getAction()) || "android.intent.action.MY_PACKAGE_REPLACED".equals(i.getAction())) { rearmAll(c); return; }
                Intent s = new Intent(c, RecService.class).putExtra("id", i.getStringExtra("id"));
                if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(s); else c.startService(s);
            } catch (Throwable ignored) { }
        }
    }

    public static final class RecService extends Service {   /* v502: público, como o receptor */
        private int running = 0;
        private PowerManager.WakeLock wl;
        @Override public IBinder onBind(Intent i) { return null; }
        @Override public int onStartCommand(Intent in, int flags, int startId) {
            final String id = in == null ? null : in.getStringExtra("id");
            try {
                NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
                if (Build.VERSION.SDK_INT >= 26) nm.createNotificationChannel(new NotificationChannel("rec", "Gravações", NotificationManager.IMPORTANCE_LOW));
                Notification.Builder b = Build.VERSION.SDK_INT >= 26 ? new Notification.Builder(this, "rec") : new Notification.Builder(this);
                b.setContentTitle("A gravar…").setSmallIcon(android.R.drawable.ic_menu_save).setOngoing(true);
                if (Build.VERSION.SDK_INT >= 34) startForeground(7411, b.build(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE); else startForeground(7411, b.build());
            } catch (Throwable ignored) { }
            if (id == null) { stopSelf(); return START_NOT_STICKY; }
            try { if (wl == null) { wl = ((PowerManager) getSystemService(POWER_SERVICE)).newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "cockpittv:rec"); wl.acquire(6 * 3600_000L); } } catch (Throwable ignored) { }
            synchronized (this) { running++; }
            new Thread(() -> {
                try { doRecord(getApplicationContext(), id); } catch (Throwable ignored) { }
                synchronized (RecService.this) { running--; if (running <= 0) { try { if (wl != null && wl.isHeld()) wl.release(); } catch (Throwable ignored) { } stopForeground(true); stopSelf(); } }
            }, "rec-" + id).start();
            return START_NOT_STICKY;
        }
    }

    /* ------------------------------------------------------------ gravação */
    private static String safe(String s) { return s.replaceAll("[^A-Za-z0-9À-ÿ _.-]", "").trim().replaceAll("\\s+", "_"); }
    private static HttpURLConnection open(String u, int to) throws Exception {
        String cur = u;
        for (int i = 0; i < 6; i++) {
            HttpURLConnection c = (HttpURLConnection) new URL(cur).openConnection();
            c.setInstanceFollowRedirects(false); c.setConnectTimeout(to); c.setReadTimeout(to);
            c.setRequestProperty("User-Agent", "VLC/3.0.20 LibVLC/3.0.20");
            int code = c.getResponseCode();
            if (code >= 300 && code < 400) { String loc = c.getHeaderField("Location"); c.disconnect(); if (loc == null) break; cur = new URL(new URL(cur), loc).toString(); continue; }
            if (code >= 400) { c.disconnect(); throw new Exception("HTTP " + code); }
            return c;
        }
        throw new Exception("demasiados redirecionamentos");
    }
    private static String text(String u) throws Exception { HttpURLConnection c = open(u, 15000); try (InputStream in = c.getInputStream()) { java.io.ByteArrayOutputStream o = new java.io.ByteArrayOutputStream(); byte[] b = new byte[8192]; int n; while ((n = in.read(b)) > 0) o.write(b, 0, n); return o.toString("UTF-8"); } finally { c.disconnect(); } }

    static void doRecord(Context c, String id) {
        Rec r = find(c, id); if (r == null) return;
        long now = System.currentTimeMillis(), until = r.end + r.post;
        if (until <= now) { r.st = "fail"; r.err = "o programa já acabou"; update(c, r); return; }
        STOP.remove(id);
        String url = r.url;
        if (url.contains("/live/") && url.endsWith(".m3u8")) url = url.substring(0, url.length() - 5) + ".ts";   /* Xtream: o .ts é o fluxo contínuo */
        File f = new File(dir(c), new SimpleDateFormat("yyyyMMdd_HHmm", Locale.US).format(r.start) + "_" + safe(r.ch) + "_" + safe(r.title) + ".ts");
        r.st = "rec"; r.file = f.getAbsolutePath(); r.err = ""; update(c, r);
        long total = 0; String err = "";
        try (FileOutputStream out = new FileOutputStream(f, true)) {
            if (url.contains(".m3u8")) total = hls(url, out, until, id, r, c);
            else {
                int fails = 0; byte[] buf = new byte[65536];
                while (System.currentTimeMillis() < until && !STOP.containsKey(id) && fails < 8) {
                    HttpURLConnection h = null;
                    try {
                        h = open(url, 20000);
                        try (InputStream in = h.getInputStream()) {
                            int n; long last = 0;
                            while (!STOP.containsKey(id) && System.currentTimeMillis() < until && (n = in.read(buf)) > 0) {
                                out.write(buf, 0, n); total += n; fails = 0;
                                long t = System.currentTimeMillis(); if (t - last > 5000) { last = t; r.bytes = total; update(c, r); }
                            }
                        }
                    } catch (Throwable e) { err = String.valueOf(e.getMessage()); fails++; try { Thread.sleep(3000); } catch (InterruptedException ie) { break; } }
                    finally { if (h != null) h.disconnect(); }
                }
            }
        } catch (Throwable e) { err = String.valueOf(e.getMessage()); }
        Rec fin = find(c, id); if (fin == null) { try { f.delete(); } catch (Throwable ignored) { } return; }   /* apagada durante a gravação */
        fin.bytes = total; fin.file = f.getAbsolutePath();
        if (total < 200_000) { fin.st = "fail"; fin.err = err.isEmpty() ? "o canal não enviou vídeo" : err; try { f.delete(); } catch (Throwable ignored) { } } else {
            fin.st = "done"; fin.err = "";
            String u = !tree(c).isEmpty() ? exportTree(c, f) : null; if (u == null && !path(c).isEmpty()) u = exportPath(c, f); if (u == null && pub(c)) u = exportPublic(c, f); if (u != null) fin.file = u;
        }
        update(c, fin); purge(c);
    }

    /** Canais só em HLS: lê a lista de tempos a tempos e junta os segmentos novos. */
    private static long hls(String pl, FileOutputStream out, long until, String id, Rec r, Context c) throws Exception {
        long total = 0; Set<String> seen = new HashSet<>(); String cur = pl;
        String t = text(cur);
        if (t.contains("#EXT-X-STREAM-INF")) { String best = null; for (String ln : t.split("\n")) { ln = ln.trim(); if (!ln.isEmpty() && !ln.startsWith("#")) best = ln; } if (best != null) cur = new URL(new URL(cur), best).toString(); }   /* última variante (costuma ser a melhor) */
        int fails = 0;
        while (System.currentTimeMillis() < until && !STOP.containsKey(id) && fails < 10) {
            try {
                t = text(cur); double td = 4;
                for (String ln : t.split("\n")) { ln = ln.trim(); if (ln.startsWith("#EXT-X-TARGETDURATION:")) try { td = Double.parseDouble(ln.substring(22)); } catch (Throwable ignored) { } }
                for (String ln : t.split("\n")) {
                    ln = ln.trim(); if (ln.isEmpty() || ln.startsWith("#")) continue;
                    String seg = new URL(new URL(cur), ln).toString(); if (!seen.add(seg)) continue;
                    HttpURLConnection h = open(seg, 20000);
                    try (InputStream in = h.getInputStream()) { byte[] buf = new byte[65536]; int n; while ((n = in.read(buf)) > 0) { out.write(buf, 0, n); total += n; } } finally { h.disconnect(); }
                    r.bytes = total; update(c, r);
                    if (System.currentTimeMillis() >= until || STOP.containsKey(id)) break;
                }
                fails = 0; Thread.sleep((long) (td * 500));
            } catch (InterruptedException ie) { break; } catch (Throwable e) { fails++; try { Thread.sleep(2500); } catch (InterruptedException ie) { break; } }
        }
        return total;
    }
}
